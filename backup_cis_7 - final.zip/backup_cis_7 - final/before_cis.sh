#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Vulnerability Injection Script
# WARNING: Creates intentional security vulnerabilities for CIS testing only
# Use ONLY in isolated lab environments
################################################################################

set -e

LOG_FILE="/var/log/cis_vulnerable_setup.log"

log_message() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo "ERROR: This script must be run as root"
        exit 1
    fi
}

################################################################################
# Install Insecure Services and Packages
################################################################################
install_vulnerable_packages() {
    log_message "Installing insecure packages and services..."
    
    yum install -y openssh-server vsftpd telnet telnet-server \
        xinetd rsh-server rsh talk talk-server ypbind ypserv \
        tftp-server tftp samba cups avahi nfs-utils 2>&1 | tee -a "$LOG_FILE"
    
    log_message "Installed vulnerable packages"
}

################################################################################
# Create Users with Weak Passwords and Bad Permissions
################################################################################
create_insecure_users() {
    log_message "Creating users with weak passwords and insecure permissions..."
    
    # Create users with weak passwords
    declare -a weak_users=("testuser1:123" "admin:password" "service:pass" "backup:backup123")
    
    for user_pass in "${weak_users[@]}"; do
        username=$(echo "$user_pass" | cut -d: -f1)
        password=$(echo "$user_pass" | cut -d: -f2)
        
        if ! id "$username" &>/dev/null; then
            useradd -m "$username" 2>&1 | tee -a "$LOG_FILE"
            echo "$username:$password" | chpasswd
            log_message "Created user: $username with weak password"
        fi
    done
    
    # Give sudo access without password
    echo "testuser1 ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/testuser1
    chmod 0440 /etc/sudoers.d/testuser1
    usermod -aG wheel admin 2>/dev/null
    log_message "Granted passwordless sudo to testuser1"
    
    # Create world-writable home directories
    chmod 777 /home/testuser1 2>/dev/null
    chmod 777 /home/admin 2>/dev/null
    log_message "Set world-writable permissions on home directories"
    
    # Set weak password policies
    sed -i 's/^PASS_MAX_DAYS.*/PASS_MAX_DAYS   365/' /etc/login.defs
    sed -i 's/^PASS_MIN_DAYS.*/PASS_MIN_DAYS   0/' /etc/login.defs
    sed -i 's/^PASS_MIN_LEN.*/PASS_MIN_LEN    5/' /etc/login.defs
    sed -i 's/^PASS_WARN_AGE.*/PASS_WARN_AGE   1/' /etc/login.defs
    log_message "Configured weak password policies"
    
    # Disable account lockout in PAM
    if [ -f /etc/pam.d/system-auth ]; then
        sed -i '/pam_faillock/d' /etc/pam.d/system-auth
        sed -i '/pam_pwquality/d' /etc/pam.d/system-auth
        log_message "Disabled PAM faillock and password quality checks"
    fi
}

################################################################################
# Create Directories with Bad Permissions
################################################################################
create_insecure_directories() {
    log_message "Creating directories with insecure permissions..."
    
    # Create world-writable directories without sticky bit
    mkdir -p /opt/shared /var/data /tmp/public
    chmod 777 /opt/shared
    chmod 777 /var/data
    chmod 777 /tmp/public
    log_message "Created world-writable directories: /opt/shared, /var/data, /tmp/public"
    
    # Remove sticky bit from /tmp
    chmod -t /tmp 2>/dev/null || true
    log_message "Removed sticky bit from /tmp"
    
    # Create sensitive directories with wrong permissions
    mkdir -p /etc/custom_scripts
    chmod 777 /etc/custom_scripts
    log_message "Created /etc/custom_scripts with 777 permissions"
    
    # Set wrong permissions on sensitive files
    chmod 644 /etc/shadow 2>/dev/null || true
    chmod 644 /etc/gshadow 2>/dev/null || true
    chmod 777 /etc/hosts.allow 2>/dev/null || true
    chmod 777 /etc/hosts.deny 2>/dev/null || true
    log_message "Set insecure permissions on /etc/shadow, /etc/gshadow, hosts.allow, hosts.deny"
}

################################################################################
# Configure SSH with Bad Settings
################################################################################
configure_insecure_ssh() {
    log_message "Configuring SSH with insecure settings..."
    
    SSH_CONFIG="/etc/ssh/sshd_config"
    cp "$SSH_CONFIG" "${SSH_CONFIG}.backup.$(date +%Y%m%d)"
    log_message "Backed up SSH config to ${SSH_CONFIG}.backup.$(date +%Y%m%d)"
    
    # Add insecure settings
    cat >> "$SSH_CONFIG" << 'EOF'

# INSECURE SETTINGS FOR CIS TESTING
PermitRootLogin yes
PermitEmptyPasswords yes
PasswordAuthentication yes
ChallengeResponseAuthentication yes
PubkeyAuthentication yes
X11Forwarding yes
MaxAuthTries 10
MaxSessions 20
PermitUserEnvironment yes
Ciphers aes128-cbc,3des-cbc,aes192-cbc,aes256-cbc
MACs hmac-md5,hmac-sha1,umac-64@openssh.com
Protocol 2
HostbasedAuthentication yes
IgnoreRhosts no
Banner none
ClientAliveInterval 0
ClientAliveCountMax 3
LoginGraceTime 120
LogLevel INFO
AllowTcpForwarding yes
GatewayPorts yes
EOF

    systemctl restart sshd 2>&1 | tee -a "$LOG_FILE"
    systemctl enable sshd 2>&1 | tee -a "$LOG_FILE"
    log_message "SSH configured with weak ciphers, PermitRootLogin, and other insecure settings"
}

################################################################################
# Enable Insecure Network Protocols: DCCP, SCTP, RDS, TIPC
################################################################################
configure_insecure_protocols() {
    log_message "Enabling insecure network protocols: DCCP, SCTP, RDS, TIPC..."
    
    # Remove any existing blacklist configurations
    rm -f /etc/modprobe.d/dccp.conf 2>/dev/null
    rm -f /etc/modprobe.d/sctp.conf 2>/dev/null
    rm -f /etc/modprobe.d/rds.conf 2>/dev/null
    rm -f /etc/modprobe.d/tipc.conf 2>/dev/null
    rm -f /etc/modprobe.d/CIS.conf 2>/dev/null
    log_message "Removed any existing protocol blacklist configurations"
    
    # Load the protocols
    modprobe dccp 2>/dev/null && log_message "Loaded dccp module" || log_message "Could not load dccp"
    modprobe sctp 2>/dev/null && log_message "Loaded sctp module" || log_message "Could not load sctp"
    modprobe rds 2>/dev/null && log_message "Loaded rds module" || log_message "Could not load rds"
    modprobe tipc 2>/dev/null && log_message "Loaded tipc module" || log_message "Could not load tipc"
    
    # Ensure they load on boot
    cat > /etc/modules-load.d/insecure-protocols.conf << 'EOF'
dccp
sctp
rds
tipc
EOF
    log_message "Configured insecure protocols to load on boot"
}

################################################################################
# Configure FTP with Insecure Settings
################################################################################
configure_insecure_ftp() {
    log_message "Configuring FTP with insecure settings..."
    
    cat > /etc/vsftpd/vsftpd.conf << 'EOF'
anonymous_enable=YES
local_enable=YES
write_enable=YES
local_umask=022
anon_upload_enable=YES
anon_mkdir_write_enable=YES
anon_other_write_enable=YES
chown_uploads=NO
connect_from_port_20=YES
xferlog_enable=YES
listen=YES
pam_service_name=vsftpd
userlist_enable=NO
tcp_wrappers=NO
allow_writeable_chroot=YES
EOF

    mkdir -p /var/ftp/pub
    chmod 777 /var/ftp/pub
    log_message "Created /var/ftp/pub with 777 permissions"
    
    systemctl enable vsftpd 2>&1 | tee -a "$LOG_FILE"
    systemctl start vsftpd 2>&1 | tee -a "$LOG_FILE"
    log_message "FTP configured with anonymous access and upload enabled"
}

################################################################################
# Configure NIS Client
################################################################################
configure_insecure_nis() {
    log_message "Configuring NIS client..."
    
    if command -v ypbind &>/dev/null; then
        systemctl enable ypbind 2>&1 | tee -a "$LOG_FILE"
        systemctl start ypbind 2>/dev/null || log_message "NIS service started (may not be fully configured)"
        log_message "NIS client enabled"
    else
        log_message "ypbind not available, skipping NIS configuration"
    fi
}

################################################################################
# Configure RSH, Talk and Legacy Services
################################################################################
configure_insecure_legacy_services() {
    log_message "Configuring RSH, Talk and other legacy services..."
    
    # Enable xinetd
    systemctl enable xinetd 2>&1 | tee -a "$LOG_FILE"
    systemctl start xinetd 2>&1 | tee -a "$LOG_FILE"
    log_message "xinetd enabled and started"
    
    # Configure rsh
    if [ -f /etc/xinetd.d/rsh ]; then
        sed -i 's/disable.*=.*/disable = no/' /etc/xinetd.d/rsh
        log_message "Enabled rsh in xinetd"
    fi
    
    # Configure rlogin
    if [ -f /etc/xinetd.d/rlogin ]; then
        sed -i 's/disable.*=.*/disable = no/' /etc/xinetd.d/rlogin
        log_message "Enabled rlogin in xinetd"
    fi
    
    # Configure rexec
    if [ -f /etc/xinetd.d/rexec ]; then
        sed -i 's/disable.*=.*/disable = no/' /etc/xinetd.d/rexec
        log_message "Enabled rexec in xinetd"
    fi
    
    # Configure talk
    if [ -f /etc/xinetd.d/talk ]; then
        sed -i 's/disable.*=.*/disable = no/' /etc/xinetd.d/talk
        log_message "Enabled talk in xinetd"
    fi
    
    # Restart xinetd
    systemctl restart xinetd 2>/dev/null || log_message "xinetd restart attempted"
}

################################################################################
# Disable Firewall and Set Insecure Rules
################################################################################
configure_insecure_firewall() {
    log_message "Disabling firewall and setting insecure iptables rules..."
    
    # Stop and disable firewalld
    systemctl stop firewalld 2>/dev/null || true
    systemctl disable firewalld 2>/dev/null || true
    log_message "firewalld stopped and disabled"
    
    # Flush iptables and set all ACCEPT
    iptables -F
    iptables -X
    iptables -t nat -F
    iptables -t nat -X
    iptables -t mangle -F
    iptables -t mangle -X
    iptables -P INPUT ACCEPT
    iptables -P FORWARD ACCEPT
    iptables -P OUTPUT ACCEPT
    log_message "iptables flushed and set to ACCEPT all traffic"
    
    # Save the insecure rules
    service iptables save 2>/dev/null || true
    
    # Disable nftables if present
    systemctl stop nftables 2>/dev/null || true
    systemctl disable nftables 2>/dev/null || true
    log_message "nftables stopped and disabled"
}

################################################################################
# Configure Insecure Filesystem Mount Options
################################################################################
configure_insecure_mount_options() {
    log_message "Configuring insecure filesystem mount options (removing nodev, nosuid, noexec)..."
    
    # Backup fstab
    cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d)
    log_message "Backed up /etc/fstab to /etc/fstab.backup.$(date +%Y%m%d)"
    
    # Remove secure mount options from /tmp
    sed -i 's/\(.*\/tmp.*\)nodev/\1/' /etc/fstab
    sed -i 's/\(.*\/tmp.*\)nosuid/\1/' /etc/fstab
    sed -i 's/\(.*\/tmp.*\)noexec/\1/' /etc/fstab
    log_message "Removed nodev, nosuid, noexec from /tmp in fstab"
    
    # Same for /var/tmp
    sed -i 's/\(.*\/var\/tmp.*\)nodev/\1/' /etc/fstab
    sed -i 's/\(.*\/var\/tmp.*\)nosuid/\1/' /etc/fstab
    sed -i 's/\(.*\/var\/tmp.*\)noexec/\1/' /etc/fstab
    log_message "Removed nodev, nosuid, noexec from /var/tmp in fstab"
    
    # Same for /dev/shm
    sed -i 's/\(.*\/dev\/shm.*\)nodev/\1/' /etc/fstab
    sed -i 's/\(.*\/dev\/shm.*\)nosuid/\1/' /etc/fstab
    sed -i 's/\(.*\/dev\/shm.*\)noexec/\1/' /etc/fstab
    log_message "Removed nodev, nosuid, noexec from /dev/shm in fstab"
    
    # Same for /home if present
    sed -i 's/\(.*\/home.*\)nodev/\1/' /etc/fstab
    log_message "Removed nodev from /home in fstab (if present)"
    
    # Remount /dev/shm without security options
    if mount | grep -q '/dev/shm'; then
        mount -o remount,rw /dev/shm 2>/dev/null || log_message "Could not remount /dev/shm"
    fi
    
    # Create insecure tmpfs mount
    mkdir -p /mnt/insecure_tmp
    echo "tmpfs /mnt/insecure_tmp tmpfs defaults,rw,suid,exec,dev 0 0" >> /etc/fstab
    mount /mnt/insecure_tmp 2>/dev/null || log_message "Insecure tmpfs will mount on reboot"
    log_message "Created insecure tmpfs at /mnt/insecure_tmp with suid,exec,dev options"
}

################################################################################
# Disable SELinux and Security Features
################################################################################
configure_insecure_system_settings() {
    log_message "Disabling SELinux and other security features..."
    
    # Disable SELinux
    if [ -f /etc/selinux/config ]; then
        sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config
        setenforce 0 2>/dev/null || log_message "SELinux set to permissive (will be disabled after reboot)"
        log_message "SELinux disabled in config"
    fi
    
    # Disable AIDE
    systemctl disable aide 2>/dev/null || true
    systemctl stop aide 2>/dev/null || true
    log_message "AIDE disabled"
    
    # Disable auditd
    systemctl disable auditd 2>/dev/null || log_message "auditd disabled"
    
    # Enable core dumps
    rm -f /etc/security/limits.d/*-nproc.conf
    sed -i '/hard.*core/d' /etc/security/limits.conf
    sed -i '/soft.*core/d' /etc/security/limits.conf
    log_message "Core dumps enabled (removed limits)"
    
    # Disable ASLR
    echo 0 > /proc/sys/kernel/randomize_va_space 2>/dev/null || true
    sed -i '/randomize_va_space/d' /etc/sysctl.conf
    echo "kernel.randomize_va_space = 0" >> /etc/sysctl.conf
    log_message "ASLR disabled (randomize_va_space = 0)"
    
    # Enable IP forwarding
    echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
    sysctl -w net.ipv4.ip_forward=1 2>/dev/null || true
    log_message "IP forwarding enabled"
    
    # Disable SYN cookies
    echo "net.ipv4.tcp_syncookies = 0" >> /etc/sysctl.conf
    sysctl -w net.ipv4.tcp_syncookies=0 2>/dev/null || true
    log_message "SYN cookies disabled"
    
    # Apply sysctl changes
    sysctl -p 2>&1 | tee -a "$LOG_FILE"
    log_message "Applied sysctl changes"
}

################################################################################
# Enable Unnecessary Services
################################################################################
enable_unnecessary_services() {
    log_message "Enabling unnecessary services..."
    
    declare -a services=("cups" "avahi-daemon" "rpcbind" "nfs-server" "nfs-lock" "nfs-idmap")
    
    for service in "${services[@]}"; do
        systemctl enable "$service" 2>/dev/null && log_message "Enabled $service" || log_message "Could not enable $service (may not be installed)"
        systemctl start "$service" 2>/dev/null || log_message "$service started or not available"
    done
}

################################################################################
# Generate Summary Report
################################################################################
generate_summary() {
    echo ""
    echo "================================================================================"
    echo "CIS VULNERABILITY INJECTION COMPLETE"
    echo "================================================================================"
    echo ""
    echo "SUMMARY OF INSECURE CONFIGURATIONS:"
    echo ""
    echo "Users created with weak passwords:"
    echo "  - testuser1:123 (NOPASSWD sudo)"
    echo "  - admin:password"
    echo "  - service:pass"
    echo "  - backup:backup123"
    echo ""
    echo "Insecure services enabled:"
    echo "  - SSH (weak ciphers, PermitRootLogin, PermitEmptyPasswords)"
    echo "  - FTP (anonymous access, uploads enabled)"
    echo "  - RSH, Talk, Telnet via xinetd"
    echo "  - NIS client (ypbind)"
    echo "  - cups, avahi-daemon, rpcbind, NFS"
    echo ""
    echo "Insecure network protocols enabled:"
    echo "  - DCCP, SCTP, RDS, TIPC"
    echo ""
    echo "Filesystem mount violations:"
    echo "  - /tmp, /var/tmp, /dev/shm missing nodev, nosuid, noexec"
    echo "  - /home missing nodev"
    echo "  - /mnt/insecure_tmp created with suid,exec,dev"
    echo ""
    echo "Security features disabled:"
    echo "  - SELinux disabled"
    echo "  - firewalld disabled"
    echo "  - iptables set to ACCEPT all"
    echo "  - AIDE and auditd disabled"
    echo "  - ASLR disabled"
    echo "  - SYN cookies disabled"
    echo ""
    echo "File/directory permission violations:"
    echo "  - /etc/shadow: 644 (should be 000/400)"
    echo "  - /etc/gshadow: 644"
    echo "  - /tmp: sticky bit removed"
    echo "  - /opt/shared, /var/data: 777 permissions"
    echo "  - Home directories: 777 permissions"
    echo ""
    echo "================================================================================"
    echo "Log file: $LOG_FILE"
    echo "================================================================================"
    echo ""
    echo "IMPORTANT: REBOOT REQUIRED for all changes to take effect"
    echo ""
}

################################################################################
# Main Execution
################################################################################
main() {
    check_root
    
    log_message "Starting CIS Oracle Linux 7 vulnerability injection script"
    log_message "================================================================"
    
    install_vulnerable_packages
    create_insecure_users
    create_insecure_directories
    configure_insecure_ssh
    configure_insecure_protocols
    configure_insecure_ftp
    configure_insecure_nis
    configure_insecure_legacy_services
    configure_insecure_firewall
    configure_insecure_mount_options
    configure_insecure_system_settings
    enable_unnecessary_services
    
    log_message "================================================================"
    log_message "Vulnerability injection completed"
    
    generate_summary
}

main "$@"
