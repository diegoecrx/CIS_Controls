#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark - FIXED Remediation Management Script
# Features: Execute, Rollback, Verify remediations with comprehensive error handling
# Generated: 2025-10-13 - FIXED VERSION
# No Color Version - All errors corrected and proper remediation logic implemented
################################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"  # Using FIXED scripts directory
LOG_FILE="$SCRIPT_DIR/cis_remediation_master.log"
VERIFICATION_LOG="$SCRIPT_DIR/cis_verification.log"
ROLLBACK_LOG="$SCRIPT_DIR/cis_rollback.log"
ERROR_LOG="$SCRIPT_DIR/cis_error_analysis.log"  # Enhanced error logging
SECTIONS_FILE="$SCRIPT_DIR/sections.txt"
BACKUP_DIR="/tmp/cis_backup"
STATUS_FILE="$SCRIPT_DIR/cis_status.json"

# Enhanced logging function with error categorization
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [CIS-MASTER] $message" | tee -a "$LOG_FILE"

    # Log errors to error analysis log as well
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [CIS-MASTER] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Display main banner
display_banner() {
    clear
    echo "Script Directory: $SCRIPTS_DIR"
    echo "Backup Directory: $BACKUP_DIR"
    echo "Main Log: $LOG_FILE"
    echo "Error Log: $ERROR_LOG"
    echo ""
}

# Enhanced error checking and script validation
validate_scripts() {
    echo "Validating CIS remediation scripts..."
    log_message "INFO" "Validating scripts in $SCRIPTS_DIR"

    if [ ! -d "$SCRIPTS_DIR" ]; then
        echo "Error: Scripts directory not found: $SCRIPTS_DIR"
        log_message "ERROR" "Scripts directory not found: $SCRIPTS_DIR"
        return 1
    fi

    local script_count=$(find "$SCRIPTS_DIR" -name "*.sh" -type f | wc -l)
    local invalid_scripts=0

    echo "Found $script_count scripts to validate..."

    # Check for common syntax errors in scripts
    for script in "$SCRIPTS_DIR"/*.sh; do
        if [ -f "$script" ]; then
            # Basic syntax check
            if ! bash -n "$script" 2>/dev/null; then
                echo "Syntax error in: $(basename "$script")"
                log_message "ERROR" "Syntax error in script: $(basename "$script")"
                invalid_scripts=$((invalid_scripts + 1))
            fi
        fi
    done

    if [ "$invalid_scripts" -gt 0 ]; then
        echo "Warning: Found $invalid_scripts scripts with syntax errors"
        log_message "WARNING" "Found $invalid_scripts scripts with syntax errors"
    else
        echo "All scripts passed syntax validation"
        log_message "SUCCESS" "All $script_count scripts passed syntax validation"
    fi

    return 0
}

# Set permissions for all scripts
set_permissions() {
    echo "Setting executable permissions for all scripts..."
    log_message "INFO" "Setting permissions for scripts in $SCRIPTS_DIR"

    if [ ! -d "$SCRIPTS_DIR" ]; then
        echo "Error: Scripts directory not found: $SCRIPTS_DIR"
        log_message "ERROR" "Scripts directory not found: $SCRIPTS_DIR"
        return 1
    fi

    # Set permissions using find command as requested
    if find "$SCRIPTS_DIR" -type f -name '*.sh' -print0 | xargs -0 chmod +x; then
        local count=$(find "$SCRIPTS_DIR" -name '*.sh' 2>/dev/null | wc -l)
        echo "Success: Set executable permissions for $count scripts"
        log_message "SUCCESS" "Set permissions for $count scripts in $SCRIPTS_DIR"
        return 0
    else
        echo "Error: Failed to set permissions"
        log_message "ERROR" "Failed to set script permissions"
        return 1
    fi
}

# Display main menu
display_main_menu() {
    echo "============================================"
    echo "| MAIN MENU OPTIONS                     |"
    echo "============================================"
    echo "| 1) Execute Remediations               |"
    echo "| 2) Verify Remediations Status        |"
    echo "| 3) Rollback Remediations             |"
    echo "| 4) Set Script Permissions            |"
    echo "| 5) Validate Scripts                  |"
    echo "| 6) Run Error Analysis                |"
    echo "| 7) View Logs                         |"
    echo "| 8) Exit                              |"
    echo "============================================"
    echo ""
    read -p "Enter your choice [1-8]: " main_choice
}

# Display execution submenu
display_execute_menu() {
    echo ""
    echo "============================================"
    echo "| EXECUTION OPTIONS                     |"
    echo "============================================"
    echo "| 1) Execute ALL scripts (246 total)   |"
    echo "| 2) Execute SELECTED scripts          |"
    echo "| 3) Back to main menu                 |"
    echo "============================================"
    echo ""
    read -p "Enter your choice [1-3]: " exec_choice
}

# Create sections.txt template if it doesn't exist
create_sections_template() {
    if [ ! -f "$SECTIONS_FILE" ]; then
        log_message "INFO" "Creating sections.txt template"
        cat > "$SECTIONS_FILE" << 'EOF'
# CIS Oracle Linux 7 Remediation Scripts - Selective Execution
# Uncomment or add script names you want to execute
# Format: one script name per line (without path)

# SAFE STARTING SCRIPTS (recommended for initial testing)
1.2.1_gpg_keys.sh
1.2.3_gpgcheck_globally_activated.sh
1.7.1_message_day.sh
1.7.2_local_login_warning_banner.sh

# FILESYSTEM AND MOUNT SCRIPTS (Low Risk)
# 1.1.22_sticky_bit_all_world-writable_directories.sh
# 1.1.23_disable_automounting.sh
# 1.1.24_disable_usb_storage.sh

# CRITICAL SCRIPTS (Review carefully - can affect system access)
# 5.3.10_ssh_root_login_disabled.sh
# 4.1.1.1_auditd.sh
# 1.6.1.1_selinux.sh
EOF
        echo "Success: Created sections.txt template with safe defaults enabled"
        echo "Edit sections.txt to customize which scripts to run."
        return 0
    fi
    return 1
}

# Initialize status tracking
init_status_tracking() {
    if [ ! -f "$STATUS_FILE" ]; then
        echo "{" > "$STATUS_FILE"
        echo "  "last_updated": "$(date)"," >> "$STATUS_FILE"
        echo "  "scripts": {}" >> "$STATUS_FILE"
        echo "}" >> "$STATUS_FILE"
        log_message "INFO" "Initialized status tracking file"
    fi

    # Initialize error log
    if [ ! -f "$ERROR_LOG" ]; then
        echo "================== CIS ERROR ANALYSIS LOG ==================" > "$ERROR_LOG"
        echo "Initialized: $(date)" >> "$ERROR_LOG"
        echo "System: $(uname -a)" >> "$ERROR_LOG"
        echo "=============================================================" >> "$ERROR_LOG"
        echo "" >> "$ERROR_LOG"
        log_message "INFO" "Initialized error analysis log"
    fi
}

# Update script status
update_script_status() {
    local script_name="$1"
    local status="$2"
    local exit_code="${3:-0}"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")

    # Enhanced status tracking with exit codes
    echo "$timestamp|$script_name|$status|exit_code:$exit_code" >> "$SCRIPT_DIR/cis_execution_history.log"
    log_message "STATUS" "Updated $script_name status to $status (exit: $exit_code)"
}

# Get list of scripts by criteria
get_scripts_list() {
    local criteria="$1"

    if [ ! -d "$SCRIPTS_DIR" ]; then
        echo "Error: Scripts directory not found: $SCRIPTS_DIR"
        return 1
    fi

    case "$criteria" in
        "all")
            find "$SCRIPTS_DIR" -name "*.sh" -type f -exec basename {} \; | sort
        ;;
        "selected")
            if [ -f "$SECTIONS_FILE" ]; then
                grep -v '^#' "$SECTIONS_FILE" | grep -v '^[[:space:]]*$' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//'
            else
                echo ""
            fi
        ;;
    esac
}

# Enhanced script execution with better error handling
execute_scripts() {
    local script_list="$1"
    local execution_type="$2"
    local total_scripts=0
    local successful_scripts=0
    local failed_scripts=0
    local start_time=$(date)

    # Count total scripts
    total_scripts=$(echo "$script_list" | grep -v '^$' | wc -l)

    if [ "$total_scripts" -eq 0 ]; then
        echo "No scripts to execute"
        return 0
    fi

    log_message "INFO" "Starting execution of $total_scripts scripts - $execution_type"
    echo "========================================"
    echo "Starting $execution_type execution"
    echo "Time: $start_time"
    echo "Scripts to execute: $total_scripts"
    echo "========================================"
    echo ""

    # Execute each script with enhanced error handling
    local counter=1
    while IFS= read -r script_name; do
        [ -z "$script_name" ] && continue

        local script_path="$SCRIPTS_DIR/$script_name"
        echo "[$counter/$total_scripts] Executing: $script_name"

        if [ ! -f "$script_path" ]; then
            echo "  Error: Script not found"
            log_message "ERROR" "Script not found: $script_name"
            update_script_status "$script_name" "NOT_FOUND" "127"
            failed_scripts=$((failed_scripts + 1))
            counter=$((counter + 1))
            continue
        fi

        # Ensure script is executable
        chmod +x "$script_path" 2>/dev/null

        # Pre-execution syntax check
        if ! bash -n "$script_path" 2>/dev/null; then
            echo "  Error: Syntax error in script"
            log_message "ERROR" "Syntax error in script: $script_name"
            update_script_status "$script_name" "SYNTAX_ERROR" "2"
            failed_scripts=$((failed_scripts + 1))
            counter=$((counter + 1))
            continue
        fi

        log_message "INFO" "Starting execution: $script_name"

        # Execute the script and capture both output and errors
        local temp_log=$(mktemp)
        local exit_code=0

        if timeout 600 "$script_path" > "$temp_log" 2>&1; then
            exit_code=0
            echo "  Success"
            log_message "SUCCESS" "Completed successfully: $script_name"
            update_script_status "$script_name" "SUCCESS" "$exit_code"
            successful_scripts=$((successful_scripts + 1))
        else
            exit_code=$?
            echo "  Failed - exit code: $exit_code"
            log_message "ERROR" "Failed: $script_name - exit code: $exit_code"

            # Log detailed error information
            if [ -s "$temp_log" ]; then
                echo "  Error output:" >> "$ERROR_LOG"
                cat "$temp_log" >> "$ERROR_LOG"
                echo "" >> "$ERROR_LOG"
            fi

            update_script_status "$script_name" "FAILED" "$exit_code"
            failed_scripts=$((failed_scripts + 1))
        fi

        # Append script output to main log
        cat "$temp_log" >> "$LOG_FILE"
        rm -f "$temp_log"

        counter=$((counter + 1))
        echo ""
        sleep 1  # Brief pause between scripts
    done <<< "$script_list"

    # Display comprehensive summary
    local end_time=$(date)
    echo "========================================"
    echo "EXECUTION SUMMARY"
    echo "========================================"
    echo "Start time: $start_time"
    echo "End time: $end_time"
    echo "Total scripts: $total_scripts"
    echo "Successful: $successful_scripts"
    echo "Failed: $failed_scripts"

    if [ "$total_scripts" -gt 0 ]; then
        local success_rate=$((successful_scripts * 100 / total_scripts))
        echo "Success rate: $success_rate%"
    fi

    echo ""
    echo "Logs:"
    echo "- Main log: $LOG_FILE"
    echo "- Error log: $ERROR_LOG"
    echo "- Backups: $BACKUP_DIR"
    echo "========================================"

    log_message "INFO" "Execution completed - Success: $successful_scripts - Failed: $failed_scripts"

    # Suggest error analysis if there were failures
    if [ "$failed_scripts" -gt 0 ]; then
        echo ""
        echo "RECOMMENDATION: Run error analysis to identify issues:"
        echo "Select option 6 from main menu or run: ./cis_error_analyzer.sh"
    fi

    echo ""
    read -p "Press Enter to continue..."
}

# Run comprehensive error analysis
run_error_analysis() {
    echo "============================================"
    echo "| ERROR ANALYSIS SYSTEM                 |"
    echo "============================================"
    echo ""

    local analyzer_script="$SCRIPT_DIR/cis_error_analyzer.sh"

    if [ -f "$analyzer_script" ]; then
        echo "Running comprehensive error analysis..."
        if bash "$analyzer_script"; then
            echo ""
            echo "Error analysis completed successfully."
            echo "Check /var/log/cis_error_report.txt for detailed analysis."
        else
            echo "Error analysis failed to complete."
        fi
    else
        echo "Error analyzer script not found. Creating basic analysis..."

        # Basic error analysis if analyzer script is missing
        if [ -f "$LOG_FILE" ]; then
            local cmd_errors=$(grep -c "comando não encontrado" "$LOG_FILE" 2>/dev/null || echo "0")
            local error_count=$(grep -c "\[ERROR\]" "$LOG_FILE" 2>/dev/null || echo "0")
            local success_count=$(grep -c "\[SUCCESS\]" "$LOG_FILE" 2>/dev/null || echo "0")

            echo "Basic Error Summary:"
            echo "- Command not found errors: $cmd_errors"
            echo "- Total errors: $error_count"
            echo "- Total successes: $success_count"

            if [ "$cmd_errors" -gt 0 ]; then
                echo ""
                echo "CRITICAL: Found 'comando não encontrado' errors!"
                echo "This indicates scripts contain unquoted text being executed as commands."
                echo "Solution: Use the FIXED scripts in scripts/ directory."
            fi
        else
            echo "No log file found for analysis."
        fi
    fi

    echo ""
    read -p "Press Enter to continue..."
}

# Verify remediations status (enhanced)
verify_remediations() {
    echo "============================================"
    echo "| VERIFICATION REPORT                   |"
    echo "============================================"
    echo ""

    log_message "INFO" "Starting remediation verification" | tee -a "$VERIFICATION_LOG"

    local success_count=0
    local failed_count=0
    local not_run_count=0

    # Check if execution history exists
    if [ ! -f "$SCRIPT_DIR/cis_execution_history.log" ]; then
        echo "No execution history found. Run some remediations first."
        read -p "Press Enter to continue..."
        return 0
    fi

    echo "Script Status Overview:"
    echo "================================================================="
    printf "%-50s %-15s %-10s %s\n" "Script Name" "Status" "Exit Code" "Last Executed"
    echo "================================================================="

    # Get all available scripts
    local all_scripts=$(get_scripts_list "all")

    while IFS= read -r script_name; do
        [ -z "$script_name" ] && continue

        # Check latest status from execution history
        local latest_status=$(grep "$script_name" "$SCRIPT_DIR/cis_execution_history.log" 2>/dev/null | tail -1)

        if [ -n "$latest_status" ]; then
            local timestamp=$(echo "$latest_status" | cut -d'|' -f1)
            local status=$(echo "$latest_status" | cut -d'|' -f3)
            local exit_info=$(echo "$latest_status" | cut -d'|' -f4)

            case "$status" in
                "SUCCESS")
                    printf "%-50s %-15s %-10s %s\n" "$script_name" "SUCCESS" "$exit_info" "$timestamp"
                    success_count=$((success_count + 1))
                ;;
                "FAILED"|"NOT_FOUND"|"SYNTAX_ERROR")
                    printf "%-50s %-15s %-10s %s\n" "$script_name" "$status" "$exit_info" "$timestamp"
                    failed_count=$((failed_count + 1))
                ;;
            esac
        else
            printf "%-50s %-15s %-10s %s\n" "$script_name" "NOT_RUN" "N/A" "Never executed"
            not_run_count=$((not_run_count + 1))
        fi
    done <<< "$all_scripts"

    echo "================================================================="
    echo ""
    echo "VERIFICATION SUMMARY:"
    echo "Successful: $success_count"
    echo "Failed: $failed_count"
    echo "Not Run: $not_run_count"
    echo ""

    # Generate detailed verification log
    {
        echo "=== CIS Remediation Verification Report ==="
        echo "Generated: $(date)"
        echo "Successful: $success_count"
        echo "Failed: $failed_count"
        echo "Not Run: $not_run_count"
        echo "=================================="
    } >> "$VERIFICATION_LOG"

    log_message "INFO" "Verification completed - Success: $success_count - Failed: $failed_count - Not Run: $not_run_count"
    echo ""
    read -p "Press Enter to continue..."
}

# Rollback remediations (enhanced)
rollback_remediations() {
    echo "============================================"
    echo "| ROLLBACK OPERATIONS                   |"
    echo "============================================"
    echo ""

    log_message "INFO" "Starting rollback operations" | tee -a "$ROLLBACK_LOG"

    if [ ! -d "$BACKUP_DIR" ]; then
        echo "No backup directory found: $BACKUP_DIR"
        echo "No remediations to rollback."
        read -p "Press Enter to continue..."
        return 0
    fi

    local backup_files=$(find "$BACKUP_DIR" -name "*.backup" 2>/dev/null)

    if [ -z "$backup_files" ]; then
        echo "No backup files found in $BACKUP_DIR"
        echo "No remediations to rollback."
        read -p "Press Enter to continue..."
        return 0
    fi

    local backup_count=$(echo "$backup_files" | wc -l)
    echo "Found $backup_count backup files"
    echo ""
    echo "WARNING: This will restore all backed up files to their original state"
    echo "This may undo security hardening configurations!"
    echo ""

    read -p "Are you sure you want to proceed with rollback? (yes/no): " rollback_confirm

    if [ "$rollback_confirm" != "yes" ]; then
        echo "Rollback cancelled."
        return 0
    fi

    echo ""
    echo "Starting rollback process..."
    echo ""

    local success_count=0
    local failed_count=0

    while IFS= read -r backup_file; do
        [ -z "$backup_file" ] && continue

        local filename=$(basename "$backup_file" .backup)
        local target_path=""

        # Enhanced target path detection
        case "$filename" in
            "sshd_config"*) target_path="/etc/ssh/sshd_config" ;;
            "fstab"*) target_path="/etc/fstab" ;;
            "passwd"*) target_path="/etc/passwd" ;;
            "shadow"*) target_path="/etc/shadow" ;;
            "group"*) target_path="/etc/group" ;;
            "login.defs"*) target_path="/etc/login.defs" ;;
            "issue"*) target_path="/etc/issue" ;;
            "motd"*) target_path="/etc/motd" ;;
            *".conf")
                if [[ "$filename" == *".conf" ]]; then
                    target_path="/etc/modprobe.d/$filename"
                fi
            ;;
        esac

        if [ -n "$target_path" ] && [ -f "$target_path" ]; then
            echo "Restoring: $target_path"
            if cp "$backup_file" "$target_path" 2>/dev/null; then
                echo "  Successfully restored"
                log_message "SUCCESS" "Restored $target_path from backup" | tee -a "$ROLLBACK_LOG"
                success_count=$((success_count + 1))
            else
                echo "  Failed to restore"
                log_message "ERROR" "Failed to restore $target_path" | tee -a "$ROLLBACK_LOG"
                failed_count=$((failed_count + 1))
            fi
        else
            echo "Skipping: $backup_file - cannot determine target location or target missing"
            failed_count=$((failed_count + 1))
        fi
    done <<< "$backup_files"

    echo ""
    echo "ROLLBACK SUMMARY:"
    echo "Successfully restored: $success_count files"
    echo "Failed to restore: $failed_count files"
    echo ""
    echo "Note: You may need to restart services for changes to take effect"
    echo "Consider running: systemctl restart sshd"

    log_message "INFO" "Rollback completed - Success: $success_count - Failed: $failed_count"
    echo ""
    read -p "Press Enter to continue..."
}

# Enhanced log viewer
view_logs() {
    echo "============================================"
    echo "| LOG VIEWER                             |"
    echo "============================================"
    echo ""
    echo "1) Main execution log (last 50 lines)"
    echo "2) Error analysis log"
    echo "3) Verification log"
    echo "4) Rollback log"
    echo "5) Execution history"
    echo "6) Show log file sizes"
    echo "7) Back to main menu"
    echo ""

    read -p "Which log would you like to view? [1-7]: " log_choice

    case "$log_choice" in
        1)
            if [ -f "$LOG_FILE" ]; then
                echo "Showing last 50 lines of main log:"
                echo "================================================================="
                tail -50 "$LOG_FILE"
            else
                echo "Main log file not found"
            fi
        ;;
        2)
            if [ -f "$ERROR_LOG" ]; then
                echo "Showing error analysis log:"
                echo "================================================================="
                tail -100 "$ERROR_LOG"
            else
                echo "Error analysis log not found"
            fi
        ;;
        3)
            if [ -f "$VERIFICATION_LOG" ]; then
                echo "Showing verification log:"
                echo "================================================================="
                cat "$VERIFICATION_LOG"
            else
                echo "Verification log not found"
            fi
        ;;
        4)
            if [ -f "$ROLLBACK_LOG" ]; then
                echo "Showing rollback log:"
                echo "================================================================="
                cat "$ROLLBACK_LOG"
            else
                echo "Rollback log not found"
            fi
        ;;
        5)
            if [ -f "$SCRIPT_DIR/cis_execution_history.log" ]; then
                echo "Showing execution history (last 30 entries):"
                echo "================================================================="
                tail -30 "$SCRIPT_DIR/cis_execution_history.log"
            else
                echo "Execution history not found"
            fi
        ;;
        6)
            echo "Log file sizes:"
            echo "================================================================="
            for logfile in "$LOG_FILE" "$ERROR_LOG" "$VERIFICATION_LOG" "$ROLLBACK_LOG"; do
                if [ -f "$logfile" ]; then
                    local size=$(du -h "$logfile" | cut -f1)
                    echo "$(basename "$logfile"): $size"
                fi
            done
        ;;
        7)
            return 0
        ;;
        *)
            echo "Invalid choice"
        ;;
    esac

    echo ""
    read -p "Press Enter to continue..."
}

# Main execution function with enhanced error handling
main() {
    # Check if running as root
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi

    # Create necessary directories and files
    mkdir -p "$BACKUP_DIR"
    init_status_tracking

    # Auto-set permissions and validate scripts on startup
    echo "Initializing CIS Remediation Management System..."
    set_permissions
    validate_scripts
    echo ""

    while true; do
        display_banner
        display_main_menu

        case "$main_choice" in
            1)
                # Execute remediations
                while true; do
                    display_execute_menu

                    case "$exec_choice" in
                        1)
                            echo "Executing ALL scripts..."
                            echo "WARNING: This will execute ALL 246 CIS remediation scripts"
                            echo "This is a comprehensive system hardening that may affect:"
                            echo "- SSH access, services, network configuration"
                            echo "- File permissions, user accounts"
                            echo "- System security policies"
                            echo ""
                            read -p "Are you absolutely sure? (yes/no): " confirm
                            if [ "$confirm" = "yes" ]; then
                                script_list=$(get_scripts_list "all")
                                execute_scripts "$script_list" "ALL_SCRIPTS"
                            fi
                        ;;
                        2)
                            echo "Executing SELECTED scripts..."
                            create_sections_template
                            script_list=$(get_scripts_list "selected")
                            if [ -n "$script_list" ]; then
                                echo "Selected scripts:"
                                echo "$script_list" | sed 's/^/  /'
                                echo ""
                                read -p "Continue? (yes/no): " confirm
                                if [ "$confirm" = "yes" ]; then
                                    execute_scripts "$script_list" "SELECTED_SCRIPTS"
                                fi
                            else
                                echo "No scripts selected. Edit sections.txt first."
                                echo "Default safe scripts are already enabled in sections.txt"
                                read -p "Press Enter to continue..."
                            fi
                        ;;
                        3)
                            break
                        ;;
                        *)
                            echo "Invalid choice"
                            read -p "Press Enter to continue..."
                        ;;
                    esac
                done
            ;;
            2)
                # Verify remediations
                verify_remediations
            ;;
            3)
                # Rollback remediations
                rollback_remediations
            ;;
            4)
                # Set permissions
                set_permissions
                read -p "Press Enter to continue..."
            ;;
            5)
                # Validate scripts
                validate_scripts
                read -p "Press Enter to continue..."
            ;;
            6)
                # Run error analysis
                run_error_analysis
            ;;
            7)
                # View logs
                view_logs
            ;;
            8)
                echo "Exiting CIS Remediation Management System..."
                echo "Thank you for using CIS Oracle Linux 7 hardening tools!"
                log_message "INFO" "System shutdown - user exit"
                exit 0
            ;;
            *)
                echo "Invalid option. Please choose 1-8."
                read -p "Press Enter to continue..."
            ;;
        esac
    done
}

# Run main function
main "$@"
