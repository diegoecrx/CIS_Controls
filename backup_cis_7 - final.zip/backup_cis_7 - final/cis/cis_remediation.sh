#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark - Remediation Management Script
# Features: Execute, Verify, Restore remediations with backup management
# Version: 2.1 - Fixed backup detection - 2025-10-14
# Auto-sets permissions on startup and provides selective restore
################################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"
LOG_FILE="$SCRIPT_DIR/cis_remediation_master.log"
VERIFICATION_LOG="$SCRIPT_DIR/cis_verification.log"
ERROR_LOG="$SCRIPT_DIR/cis_error_analysis.log"
SECTIONS_FILE="$SCRIPT_DIR/sections.txt"
BACKUP_DIR="/tmp/cis_backup"
BACKUP_PATH_FILE="$SCRIPT_DIR/backup_path.txt"
STATUS_FILE="$SCRIPT_DIR/cis_status.json"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [CIS-MASTER] $message" | tee -a "$LOG_FILE"

    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [CIS-MASTER] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Display main banner
display_banner() {
    clear
    echo "======================================================================="
    echo "  CIS Oracle Linux 7 Benchmark - Remediation Management System"
    echo "======================================================================="
    echo ""
    echo "Script Directory: $SCRIPTS_DIR"
    echo "Backup Directory: $BACKUP_DIR"
    echo "Main Log: $LOG_FILE"
    echo "Error Log: $ERROR_LOG"
    echo ""
}

# Set permissions for all scripts (auto-runs on startup)
set_permissions() {
    log_message "INFO" "Auto-setting permissions for scripts in $SCRIPTS_DIR"
    if [ ! -d "$SCRIPTS_DIR" ]; then
        log_message "ERROR" "Scripts directory not found: $SCRIPTS_DIR"
        return 1
    fi

    if find "$SCRIPTS_DIR" -type f -name '*.sh' -print0 | xargs -0 chmod +x 2>/dev/null; then
        local count=$(find "$SCRIPTS_DIR" -name '*.sh' 2>/dev/null | wc -l)
        log_message "SUCCESS" "Set permissions for $count scripts"
        return 0
    else
        log_message "ERROR" "Failed to set script permissions"
        return 1
    fi
}

# Validate scripts
validate_scripts() {
    echo "Validating CIS remediation scripts..."
    log_message "INFO" "Validating scripts in $SCRIPTS_DIR"

    if [ ! -d "$SCRIPTS_DIR" ]; then
        echo "Error: Scripts directory not found: $SCRIPTS_DIR"
        log_message "ERROR" "Scripts directory not found: $SCRIPTS_DIR"
        return 1
    fi

    local script_count=$(find "$SCRIPTS_DIR" -name "*.sh" -type f | wc -l)
    local invalid_scripts=0

    echo "Found $script_count scripts to validate..."

    for script in "$SCRIPTS_DIR"/*.sh; do
        if [ -f "$script" ]; then
            if ! bash -n "$script" 2>/dev/null; then
                echo "Syntax error in: $(basename "$script")"
                log_message "ERROR" "Syntax error in script: $(basename "$script")"
                invalid_scripts=$((invalid_scripts + 1))
            fi
        fi
    done

    if [ "$invalid_scripts" -gt 0 ]; then
        echo "Warning: Found $invalid_scripts scripts with syntax errors"
        log_message "WARNING" "Found $invalid_scripts scripts with syntax errors"
    else
        echo "All scripts passed syntax validation"
        log_message "SUCCESS" "All $script_count scripts passed syntax validation"
    fi

    return 0
}

# Display main menu
display_main_menu() {
    echo "============================================"
    echo "|           MAIN MENU OPTIONS            |"
    echo "============================================"
    echo "| 1) Execute Remediations                |"
    echo "| 2) Verify Remediations Status          |"
    echo "| 3) Restore from Backup                 |"
    echo "| 4) Validate Scripts                    |"
    echo "| 5) Run Error Analysis                  |"
    echo "| 6) View Logs                           |"
    echo "| 7) Exit                                |"
    echo "============================================"
    echo ""
    read -p "Enter your choice [1-7]: " main_choice
}

# Display execution submenu
display_execute_menu() {
    echo ""
    echo "============================================"
    echo "|         EXECUTION OPTIONS              |"
    echo "============================================"
    echo "| 1) Execute ALL scripts                 |"
    echo "| 2) Execute SELECTED scripts            |"
    echo "| 3) Back to main menu                   |"
    echo "============================================"
    echo ""
    read -p "Enter your choice [1-3]: " exec_choice
}

# Create sections.txt template
create_sections_template() {
    if [ ! -f "$SECTIONS_FILE" ]; then
        log_message "INFO" "Creating sections.txt template"
        cat > "$SECTIONS_FILE" << 'EOF'
# CIS Oracle Linux 7 Remediation Scripts - Selective Execution
# Uncomment or add script names you want to execute
# Format: one script name per line (without path)

# SAFE STARTING SCRIPTS (recommended for initial testing)
1.2.1_gpg_keys.sh
1.2.3_gpgcheck_globally_activated.sh
1.7.1_message_day.sh
1.7.2_local_login_warning_banner.sh

# FILESYSTEM AND MOUNT SCRIPTS (Low Risk)
# 1.1.22_sticky_bit_all_world-writable_directories.sh
# 1.1.23_disable_automounting.sh
# 1.1.24_disable_usb_storage.sh

# CRITICAL SCRIPTS (Review carefully - can affect system access)
# 5.3.10_ssh_root_login_disabled.sh
# 4.1.1.1_auditd.sh
# 1.6.1.1_selinux.sh
EOF
        echo "Success: Created sections.txt template with safe defaults enabled"
        return 0
    fi
    return 1
}

# Initialize status tracking
init_status_tracking() {
    if [ ! -f "$STATUS_FILE" ]; then
        echo "{" > "$STATUS_FILE"
        echo "  "last_updated": "$(date)"," >> "$STATUS_FILE"
        echo "  "scripts": {}" >> "$STATUS_FILE"
        echo "}" >> "$STATUS_FILE"
        log_message "INFO" "Initialized status tracking file"
    fi

    if [ ! -f "$ERROR_LOG" ]; then
        echo "================== CIS ERROR ANALYSIS LOG ==================" > "$ERROR_LOG"
        echo "Initialized: $(date)" >> "$ERROR_LOG"
        echo "System: $(uname -a)" >> "$ERROR_LOG"
        echo "=============================================================" >> "$ERROR_LOG"
        echo "" >> "$ERROR_LOG"
        log_message "INFO" "Initialized error analysis log"
    fi
}

# Update script status
update_script_status() {
    local script_name="$1"
    local status="$2"
    local exit_code="${3:-0}"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")

    echo "$timestamp|$script_name|$status|exit_code:$exit_code" >> "$SCRIPT_DIR/cis_execution_history.log"
    log_message "STATUS" "Updated $script_name status to $status (exit: $exit_code)"
}

# Get list of scripts
get_scripts_list() {
    local criteria="$1"

    if [ ! -d "$SCRIPTS_DIR" ]; then
        echo "Error: Scripts directory not found: $SCRIPTS_DIR"
        return 1
    fi

    case "$criteria" in
        "all")
            find "$SCRIPTS_DIR" -name "*.sh" -type f -exec basename {} \; | sort
            ;;
        "selected")
            if [ -f "$SECTIONS_FILE" ]; then
                grep -v '^#' "$SECTIONS_FILE" | grep -v '^[[:space:]]*$' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//'
            else
                echo ""
            fi
            ;;
    esac
}

# Execute scripts
execute_scripts() {
    local script_list="$1"
    local execution_type="$2"
    local total_scripts=0
    local successful_scripts=0
    local failed_scripts=0
    local start_time=$(date)

    total_scripts=$(echo "$script_list" | grep -v '^$' | wc -l)

    if [ "$total_scripts" -eq 0 ]; then
        echo "No scripts to execute"
        return 0
    fi

    log_message "INFO" "Starting execution of $total_scripts scripts - $execution_type"
    echo "========================================"
    echo "Starting $execution_type execution"
    echo "Time: $start_time"
    echo "Scripts to execute: $total_scripts"
    echo "========================================"
    echo ""

    local counter=1
    while IFS= read -r script_name; do
        [ -z "$script_name" ] && continue

        local script_path="$SCRIPTS_DIR/$script_name"

        echo "[$counter/$total_scripts] Executing: $script_name"

        if [ ! -f "$script_path" ]; then
            echo "  Error: Script not found"
            log_message "ERROR" "Script not found: $script_name"
            update_script_status "$script_name" "NOT_FOUND" "127"
            failed_scripts=$((failed_scripts + 1))
            counter=$((counter + 1))
            continue
        fi

        chmod +x "$script_path" 2>/dev/null

        if ! bash -n "$script_path" 2>/dev/null; then
            echo "  Error: Syntax error in script"
            log_message "ERROR" "Syntax error in script: $script_name"
            update_script_status "$script_name" "SYNTAX_ERROR" "2"
            failed_scripts=$((failed_scripts + 1))
            counter=$((counter + 1))
            continue
        fi

        log_message "INFO" "Starting execution: $script_name"

        local temp_log=$(mktemp)
        local exit_code=0

        if timeout 600 "$script_path" > "$temp_log" 2>&1; then
            exit_code=0
            echo "  Success"
            log_message "SUCCESS" "Completed successfully: $script_name"
            update_script_status "$script_name" "SUCCESS" "$exit_code"
            successful_scripts=$((successful_scripts + 1))
        else
            exit_code=$?
            echo "  Failed - exit code: $exit_code"
            log_message "ERROR" "Failed: $script_name - exit code: $exit_code"

            if [ -s "$temp_log" ]; then
                echo "  Error output:" >> "$ERROR_LOG"
                cat "$temp_log" >> "$ERROR_LOG"
                echo "" >> "$ERROR_LOG"
            fi

            update_script_status "$script_name" "FAILED" "$exit_code"
            failed_scripts=$((failed_scripts + 1))
        fi

        cat "$temp_log" >> "$LOG_FILE"
        rm -f "$temp_log"

        counter=$((counter + 1))
        echo ""
        sleep 1
    done <<< "$script_list"

    local end_time=$(date)
    echo "========================================"
    echo "EXECUTION SUMMARY"
    echo "========================================"
    echo "Start time: $start_time"
    echo "End time: $end_time"
    echo "Total scripts: $total_scripts"
    echo "Successful: $successful_scripts"
    echo "Failed: $failed_scripts"

    if [ "$total_scripts" -gt 0 ]; then
        local success_rate=$((successful_scripts * 100 / total_scripts))
        echo "Success rate: $success_rate%"
    fi

    echo ""
    echo "Logs:"
    echo "- Main log: $LOG_FILE"
    echo "- Error log: $ERROR_LOG"
    echo "- Backups: $BACKUP_DIR"
    echo "========================================"

    log_message "INFO" "Execution completed - Success: $successful_scripts - Failed: $failed_scripts"

    if [ "$failed_scripts" -gt 0 ]; then
        echo ""
        echo "RECOMMENDATION: Run error analysis (option 5) to identify issues"
    fi

    echo ""
    read -p "Press Enter to continue..."
}

# Run error analysis
run_error_analysis() {
    echo "============================================"
    echo "|        ERROR ANALYSIS SYSTEM           |"
    echo "============================================"
    echo ""

    if [ -f "$LOG_FILE" ]; then
        local cmd_errors=$(grep -c "comando n�o encontrado" "$LOG_FILE" 2>/dev/null || echo "0")
        local error_count=$(grep -c "\[ERROR\]" "$LOG_FILE" 2>/dev/null || echo "0")
        local success_count=$(grep -c "\[SUCCESS\]" "$LOG_FILE" 2>/dev/null || echo "0")

        echo "Error Summary:"
        echo "- Command not found errors: $cmd_errors"
        echo "- Total errors: $error_count"
        echo "- Total successes: $success_count"

        if [ "$cmd_errors" -gt 0 ]; then
            echo ""
            echo "CRITICAL: Found 'comando n�o encontrado' errors!"
            echo "This indicates scripts contain unquoted text being executed as commands."
        fi
    else
        echo "No log file found for analysis."
    fi

    echo ""
    read -p "Press Enter to continue..."
}

# Verify remediations
verify_remediations() {
    echo "============================================"
    echo "|        VERIFICATION REPORT             |"
    echo "============================================"
    echo ""

    log_message "INFO" "Starting remediation verification" | tee -a "$VERIFICATION_LOG"

    local success_count=0
    local failed_count=0
    local not_run_count=0

    if [ ! -f "$SCRIPT_DIR/cis_execution_history.log" ]; then
        echo "No execution history found. Run some remediations first."
        read -p "Press Enter to continue..."
        return 0
    fi

    echo "Script Status Overview:"
    echo "================================================================="
    printf "%-50s %-15s %-10s %s\n" "Script Name" "Status" "Exit Code" "Last Executed"
    echo "================================================================="

    local all_scripts=$(get_scripts_list "all")

    while IFS= read -r script_name; do
        [ -z "$script_name" ] && continue

        local latest_status=$(grep "$script_name" "$SCRIPT_DIR/cis_execution_history.log" 2>/dev/null | tail -1)

        if [ -n "$latest_status" ]; then
            local timestamp=$(echo "$latest_status" | cut -d'|' -f1)
            local status=$(echo "$latest_status" | cut -d'|' -f3)
            local exit_info=$(echo "$latest_status" | cut -d'|' -f4)

            case "$status" in
                "SUCCESS")
                    printf "%-50s %-15s %-10s %s\n" "$script_name" "SUCCESS" "$exit_info" "$timestamp"
                    success_count=$((success_count + 1))
                    ;;
                "FAILED"|"NOT_FOUND"|"SYNTAX_ERROR")
                    printf "%-50s %-15s %-10s %s\n" "$script_name" "$status" "$exit_info" "$timestamp"
                    failed_count=$((failed_count + 1))
                    ;;
            esac
        else
            printf "%-50s %-15s %-10s %s\n" "$script_name" "NOT_RUN" "N/A" "Never executed"
            not_run_count=$((not_run_count + 1))
        fi
    done <<< "$all_scripts"

    echo "================================================================="
    echo ""
    echo "VERIFICATION SUMMARY:"
    echo "Successful: $success_count"
    echo "Failed: $failed_count"
    echo "Not Run: $not_run_count"
    echo ""

    {
        echo "=== CIS Remediation Verification Report ==="
        echo "Generated: $(date)"
        echo "Successful: $success_count"
        echo "Failed: $failed_count"
        echo "Not Run: $not_run_count"
        echo "=========================================="
    } >> "$VERIFICATION_LOG"

    log_message "INFO" "Verification completed - Success: $success_count - Failed: $failed_count - Not Run: $not_run_count"

    echo ""
    read -p "Press Enter to continue..."
}

# Display available backups and restore
restore_from_backup() {
    echo "============================================"
    echo "|      RESTORE FROM BACKUP               |"
    echo "============================================"
    echo ""

    if [ ! -d "$BACKUP_DIR" ]; then
        echo "No backup directory found: $BACKUP_DIR"
        echo "No backups available to restore."
        read -p "Press Enter to continue..."
        return 0
    fi

    # Count files in backup directory (excluding directories and hidden files)
    local file_count=$(find "$BACKUP_DIR" -maxdepth 1 -type f ! -name ".*" 2>/dev/null | wc -l)

    if [ "$file_count" -eq 0 ]; then
        echo "Backup directory exists but is empty: $BACKUP_DIR"
        echo ""
        echo "Debug information:"
        echo "- Backup directory: $BACKUP_DIR"
        echo "- Directory exists: $([ -d "$BACKUP_DIR" ] && echo "YES" || echo "NO")"
        echo "- Directory permissions: $(ls -ld "$BACKUP_DIR" 2>/dev/null | awk '{print $1}')"
        echo ""
        echo "Listing all contents (including hidden):"
        ls -la "$BACKUP_DIR" 2>/dev/null || echo "Cannot list directory"
        echo ""
        echo "No backups available to restore."
        echo "Backups are created when remediation scripts run."
        read -p "Press Enter to continue..."
        return 0
    fi

    # Find all backup files (any file in the backup directory)
    local backup_files=$(find "$BACKUP_DIR" -maxdepth 1 -type f ! -name ".*" 2>/dev/null | sort)

    # Count and categorize backups
    local total_backups=$(echo "$backup_files" | wc -l)

    echo "Available Backup Files ($total_backups total):"
    echo "================================================================="

    # Categorize backups by service/type
    declare -A categories

    while IFS= read -r backup_file; do
        local filename=$(basename "$backup_file")
        local category="Other"

        case "$filename" in
            *sshd*|*ssh*) category="SSH" ;;
            *cron*) category="Cron" ;;
            *passwd*|*shadow*|*group*) category="Users/Auth" ;;
            *login*|*pam*) category="PAM/Login" ;;
            *audit*) category="Audit" ;;
            *fstab*|*mount*) category="Filesystem" ;;
            *issue*|*motd*|*banner*) category="Banners" ;;
            *sysctl*|*modprobe*) category="Kernel" ;;
            *grub*) category="Bootloader" ;;
            *selinux*) category="SELinux" ;;
        esac

        if [ -z "${categories[$category]}" ]; then
            categories[$category]="$filename"
        else
            categories[$category]="${categories[$category]}|$filename"
        fi
    done <<< "$backup_files"

    # Display categorized backups
    local cat_num=1
    declare -A category_map

    for category in "${!categories[@]}"; do
        echo ""
        echo "[$cat_num] $category Configuration Files:"
        echo "-------------------------------------------"

        IFS='|' read -ra files <<< "${categories[$category]}"
        for file in "${files[@]}"; do
            local filepath="$BACKUP_DIR/$file"
            local filesize=$(du -h "$filepath" 2>/dev/null | cut -f1)
            local filedate=$(stat -c '%y' "$filepath" 2>/dev/null | cut -d' ' -f1,2 | cut -d'.' -f1)
            echo "  - $file ($filesize, $filedate)"
        done

        category_map[$cat_num]="$category"
        cat_num=$((cat_num + 1))
    done

    echo ""
    echo "================================================================="
    echo ""
    echo "Restore Options:"
    echo "  [1-$((cat_num-1))] Restore specific category"
    echo "  [A] Restore ALL backups"
    echo "  [L] List individual files"
    echo "  [Q] Return to main menu"
    echo ""

    read -p "Enter your choice: " restore_choice

    case "$restore_choice" in
        [Qq])
            return 0
            ;;
        [Aa])
            echo ""
            echo "WARNING: This will restore ALL backed up files!"
            read -p "Are you sure? (type YES to confirm): " confirm

            if [ "$confirm" = "YES" ]; then
                restore_all_backups
            else
                echo "Restore cancelled."
            fi
            ;;
        [Ll])
            restore_individual_file
            ;;
        [1-9]|[1-9][0-9])
            if [ -n "${category_map[$restore_choice]}" ]; then
                restore_category "${category_map[$restore_choice]}" "${categories[${category_map[$restore_choice]}]}"
            else
                echo "Invalid category selection."
            fi
            ;;
        *)
            echo "Invalid choice."
            ;;
    esac

    echo ""
    read -p "Press Enter to continue..."
}

# Restore specific category
restore_category() {
    local category="$1"
    local files="$2"

    echo ""
    echo "Restoring $category configuration files..."
    echo ""

    read -p "Proceed with restore? (yes/no): " confirm

    if [ "$confirm" != "yes" ]; then
        echo "Restore cancelled."
        return 0
    fi

    local success=0
    local failed=0

    IFS='|' read -ra file_list <<< "$files"

    for filename in "${file_list[@]}"; do
        local backup_path="$BACKUP_DIR/$filename"
        local target_path=$(get_original_path "$filename")

        if [ -n "$target_path" ]; then
            echo "Restoring: $target_path"

            if cp -f "$backup_path" "$target_path" 2>/dev/null; then
                echo "  Successfully restored"
                log_message "SUCCESS" "Restored $target_path from backup"
                success=$((success + 1))
            else
                echo "  Failed to restore"
                log_message "ERROR" "Failed to restore $target_path"
                failed=$((failed + 1))
            fi
        else
            echo "Skipping $filename - cannot determine target path"
            failed=$((failed + 1))
        fi
    done

    echo ""
    echo "Restore Summary:"
    echo "  Successfully restored: $success files"
    echo "  Failed to restore: $failed files"

    if [ $success -gt 0 ]; then
        echo ""
        echo "IMPORTANT: You may need to restart services for changes to take effect"
        suggest_service_restart "$category"
    fi
}

# Restore all backups
restore_all_backups() {
    echo ""
    echo "Restoring all backup files..."

    local backup_files=$(find "$BACKUP_DIR" -maxdepth 1 -type f ! -name ".*" 2>/dev/null)
    local success=0
    local failed=0

    while IFS= read -r backup_file; do
        [ -z "$backup_file" ] && continue

        local filename=$(basename "$backup_file")
        local target_path=$(get_original_path "$filename")

        if [ -n "$target_path" ]; then
            echo "Restoring: $target_path"

            if cp -f "$backup_file" "$target_path" 2>/dev/null; then
                echo "  Successfully restored"
                log_message "SUCCESS" "Restored $target_path from backup"
                success=$((success + 1))
            else
                echo "  Failed to restore"
                log_message "ERROR" "Failed to restore $target_path"
                failed=$((failed + 1))
            fi
        else
            echo "Skipping $filename - cannot determine target path"
            failed=$((failed + 1))
        fi
    done <<< "$backup_files"

    echo ""
    echo "Restore Summary:"
    echo "  Successfully restored: $success files"
    echo "  Failed to restore: $failed files"

    if [ $success -gt 0 ]; then
        echo ""
        echo "IMPORTANT: You may need to restart services:"
        echo "  systemctl restart sshd"
        echo "  systemctl restart crond"
        echo "  systemctl restart auditd"
    fi
}

# Restore individual file
restore_individual_file() {
    echo ""
    echo "Individual File Restore"
    echo "================================================================="

    local backup_files=$(find "$BACKUP_DIR" -maxdepth 1 -type f ! -name ".*" 2>/dev/null | sort)
    local file_num=1
    declare -A file_map

    echo "Available backup files:"
    echo ""

    while IFS= read -r backup_file; do
        [ -z "$backup_file" ] && continue

        local filename=$(basename "$backup_file")
        local filesize=$(du -h "$backup_file" 2>/dev/null | cut -f1)
        local filedate=$(stat -c '%y' "$backup_file" 2>/dev/null | cut -d' ' -f1,2 | cut -d'.' -f1)
        local target_path=$(get_original_path "$filename")

        echo "[$file_num] $filename"
        echo "    Size: $filesize | Date: $filedate"
        echo "    Will restore to: $target_path"
        echo ""

        file_map[$file_num]="$backup_file"
        file_num=$((file_num + 1))
    done <<< "$backup_files"

    echo "================================================================="
    read -p "Enter file number to restore (or 0 to cancel): " file_choice

    if [ "$file_choice" = "0" ] || [ -z "${file_map[$file_choice]}" ]; then
        echo "Cancelled."
        return 0
    fi

    local selected_backup="${file_map[$file_choice]}"
    local filename=$(basename "$selected_backup")
    local target_path=$(get_original_path "$filename")

    if [ -z "$target_path" ]; then
        echo "Error: Cannot determine target path for $filename"
        return 1
    fi

    echo ""
    echo "Restoring: $target_path"
    read -p "Proceed? (yes/no): " confirm

    if [ "$confirm" = "yes" ]; then
        if cp -f "$selected_backup" "$target_path" 2>/dev/null; then
            echo "Successfully restored $target_path"
            log_message "SUCCESS" "Restored $target_path from backup"

            # Suggest service restart
            case "$filename" in
                *sshd*|*ssh*) echo "Restart SSH: systemctl restart sshd" ;;
                *cron*) echo "Restart Cron: systemctl restart crond" ;;
                *audit*) echo "Restart Audit: systemctl restart auditd" ;;
            esac
        else
            echo "Failed to restore $target_path"
            log_message "ERROR" "Failed to restore $target_path"
        fi
    else
        echo "Restore cancelled."
    fi
}

# Get original path from backup filename using backup_path.txt
get_original_path() {
    local filename="$1"
    local original_path=""

    # First try to read from backup_path.txt if it exists
    if [ -f "$BACKUP_PATH_FILE" ]; then
        # Try exact match first
        original_path=$(grep ":$filename$" "$BACKUP_PATH_FILE" 2>/dev/null | cut -d':' -f1)

        if [ -n "$original_path" ]; then
            echo "$original_path"
            return 0
        fi

        # Try partial match (remove timestamps and extensions)
        local base_name=$(echo "$filename" | sed 's/_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_[0-9][0-9][0-9][0-9][0-9][0-9].*//' | sed 's/\.backup$//')
        original_path=$(grep "^$base_name:" "$BACKUP_PATH_FILE" 2>/dev/null | cut -d':' -f2)

        if [ -n "$original_path" ]; then
            echo "$original_path"
            return 0
        fi
    fi

    # Fallback to pattern matching if not found in backup_path.txt
    case "$filename" in
        sshd_config*) echo "/etc/ssh/sshd_config" ;;
        ssh_config*) echo "/etc/ssh/ssh_config" ;;
        fstab*) echo "/etc/fstab" ;;
        passwd*) echo "/etc/passwd" ;;
        shadow*) echo "/etc/shadow" ;;
        gshadow*) echo "/etc/gshadow" ;;
        group*) echo "/etc/group" ;;
        login.defs*) echo "/etc/login.defs" ;;
        issue*) echo "/etc/issue" ;;
        issue.net*) echo "/etc/issue.net" ;;
        motd*) echo "/etc/motd" ;;
        crontab*) echo "/etc/crontab" ;;
        cron.allow*) echo "/etc/cron.allow" ;;
        cron.deny*) echo "/etc/cron.deny" ;;
        at.allow*) echo "/etc/at.allow" ;;
        at.deny*) echo "/etc/at.deny" ;;
        auditd.conf*) echo "/etc/audit/auditd.conf" ;;
        audit.rules*) echo "/etc/audit/rules.d/audit.rules" ;;
        grub.cfg*) echo "/boot/grub2/grub.cfg" ;;
        selinux_config*|config_selinux*) echo "/etc/selinux/config" ;;
        pam_*) echo "/etc/pam.d/$(echo $filename | sed 's/pam_//' | sed 's/_[0-9].*//')" ;;
        sysctl*) echo "/etc/sysctl.conf" ;;
        *.conf)
            # For .conf files, try /etc or /etc/modprobe.d
            if [ -f "/etc/$filename" ]; then
                echo "/etc/$filename"
            elif [ -f "/etc/modprobe.d/$filename" ]; then
                echo "/etc/modprobe.d/$filename"
            fi
            ;;
        *) 
            # Try to find the file in common locations
            for path in /etc /etc/ssh /etc/audit /etc/pam.d /etc/cron.d /boot/grub2 /etc/selinux; do
                if [ -f "$path/$filename" ]; then
                    echo "$path/$filename"
                    return 0
                fi
            done
            ;;
    esac
}

# Suggest service restart based on category
suggest_service_restart() {
    local category="$1"

    echo ""
    echo "Recommended service restarts for $category:"

    case "$category" in
        "SSH")
            echo "  systemctl restart sshd"
            ;;
        "Cron")
            echo "  systemctl restart crond"
            ;;
        "Audit")
            echo "  systemctl restart auditd"
            ;;
        "PAM/Login")
            echo "  Note: Changes take effect on next login"
            ;;
        "Kernel")
            echo "  sysctl -p  (to reload sysctl settings)"
            ;;
        "Bootloader")
            echo "  Note: Changes take effect on next boot"
            ;;
        "SELinux")
            echo "  Note: May require system reboot"
            ;;
        *)
            echo "  Review logs and restart affected services if needed"
            ;;
    esac
}

# View logs
view_logs() {
    echo "============================================"
    echo "|           LOG VIEWER                   |"
    echo "============================================"
    echo ""
    echo "1) Main execution log (last 50 lines)"
    echo "2) Error analysis log"
    echo "3) Verification log"
    echo "4) Execution history"
    echo "5) Show log file sizes"
    echo "6) Back to main menu"
    echo ""
    read -p "Which log would you like to view? [1-6]: " log_choice

    case "$log_choice" in
        1)
            if [ -f "$LOG_FILE" ]; then
                echo "Showing last 50 lines of main log:"
                echo "================================================================="
                tail -50 "$LOG_FILE"
            else
                echo "Main log file not found"
            fi
            ;;
        2)
            if [ -f "$ERROR_LOG" ]; then
                echo "Showing error analysis log:"
                echo "================================================================="
                tail -100 "$ERROR_LOG"
            else
                echo "Error analysis log not found"
            fi
            ;;
        3)
            if [ -f "$VERIFICATION_LOG" ]; then
                echo "Showing verification log:"
                echo "================================================================="
                cat "$VERIFICATION_LOG"
            else
                echo "Verification log not found"
            fi
            ;;
        4)
            if [ -f "$SCRIPT_DIR/cis_execution_history.log" ]; then
                echo "Showing execution history (last 30 entries):"
                echo "================================================================="
                tail -30 "$SCRIPT_DIR/cis_execution_history.log"
            else
                echo "Execution history not found"
            fi
            ;;
        5)
            echo "Log file sizes:"
            echo "================================================================="
            for logfile in "$LOG_FILE" "$ERROR_LOG" "$VERIFICATION_LOG"; do
                if [ -f "$logfile" ]; then
                    local size=$(du -h "$logfile" | cut -f1)
                    echo "$(basename "$logfile"): $size"
                fi
            done
            ;;
        6)
            return 0
            ;;
        *)
            echo "Invalid choice"
            ;;
    esac

    echo ""
    read -p "Press Enter to continue..."
}

# Main function
main() {
    # Check if running as root
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi

    # Create necessary directories
    mkdir -p "$BACKUP_DIR"
    init_status_tracking

    # Auto-set permissions on startup
    echo "Initializing CIS Remediation Management System..."
    set_permissions
    echo ""

    while true; do
        display_banner
        display_main_menu

        case "$main_choice" in
            1)
                # Execute remediations
                while true; do
                    display_execute_menu

                    case "$exec_choice" in
                        1)
                            echo "Executing ALL scripts..."
                            echo "WARNING: This will execute ALL CIS remediation scripts"
                            echo ""
                            read -p "Are you sure? (yes/no): " confirm

                            if [ "$confirm" = "yes" ]; then
                                script_list=$(get_scripts_list "all")
                                execute_scripts "$script_list" "ALL_SCRIPTS"
                            fi
                            ;;
                        2)
                            echo "Executing SELECTED scripts..."
                            create_sections_template
                            script_list=$(get_scripts_list "selected")

                            if [ -n "$script_list" ]; then
                                echo "Selected scripts:"
                                echo "$script_list" | sed 's/^/  /'
                                echo ""
                                read -p "Continue? (yes/no): " confirm

                                if [ "$confirm" = "yes" ]; then
                                    execute_scripts "$script_list" "SELECTED_SCRIPTS"
                                fi
                            else
                                echo "No scripts selected. Edit sections.txt first."
                                read -p "Press Enter to continue..."
                            fi
                            ;;
                        3)
                            break
                            ;;
                        *)
                            echo "Invalid choice"
                            read -p "Press Enter to continue..."
                            ;;
                    esac
                done
                ;;
            2)
                verify_remediations
                ;;
            3)
                restore_from_backup
                ;;
            4)
                validate_scripts
                read -p "Press Enter to continue..."
                ;;
            5)
                run_error_analysis
                ;;
            6)
                view_logs
                ;;
            7)
                echo "Exiting CIS Remediation Management System..."
                log_message "INFO" "System shutdown - user exit"
                exit 0
                ;;
            *)
                echo "Invalid option. Please choose 1-7."
                read -p "Press Enter to continue..."
                ;;
        esac
    done
}

# Run main function
main "$@"
