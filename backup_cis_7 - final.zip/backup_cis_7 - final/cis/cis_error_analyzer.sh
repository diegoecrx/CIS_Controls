#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 - Enhanced Error Analysis and Logging System
# This script analyzes errors from CIS remediation execution and provides
# detailed debugging information for fixing issues
###############################################################################

ERROR_LOG="/var/log/cis_error_analysis.log"
MAIN_LOG="/var/log/cis_remediation.log"
ANALYSIS_REPORT="/var/log/cis_error_report.txt"

# Initialize error analysis log
init_error_log() {
    echo "================== CIS ERROR ANALYSIS SYSTEM ==================" > "$ERROR_LOG"
    echo "Initialized: $(date)" >> "$ERROR_LOG"
    echo "System: $(uname -a)" >> "$ERROR_LOG"  
    echo "Bash Version: $BASH_VERSION" >> "$ERROR_LOG"
    echo "=============================================================" >> "$ERROR_LOG"
    echo "" >> "$ERROR_LOG"
}

# Enhanced error categorization and logging
log_detailed_error() {
    local script_name="$1"
    local line_number="$2"
    local error_type="$3" 
    local error_message="$4"
    local bash_error="$5"
    local suggested_fix="$6"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")

    cat >> "$ERROR_LOG" << EOF
=================== ERROR REPORT ===================
Timestamp: $timestamp
Script: $script_name
Line Number: $line_number
Error Type: $error_type
Error Message: $error_message
Bash Error: $bash_error
Suggested Fix: $suggested_fix
System State: $(systemctl is-system-running 2>/dev/null || echo "unknown")
Memory Usage: $(free -m | grep Mem: | awk '{print $3"/"$2" MB"}')
Disk Usage: $(df -h / | tail -1 | awk '{print $5}')
====================================================
EOF
}

# Analyze common error patterns from logs
analyze_error_patterns() {
    echo "Analyzing error patterns from CIS remediation logs..." | tee -a "$ANALYSIS_REPORT"

    if [ ! -f "$MAIN_LOG" ]; then
        echo "No main log file found at $MAIN_LOG" | tee -a "$ANALYSIS_REPORT"
        return 1
    fi

    echo "" >> "$ANALYSIS_REPORT"
    echo "=== ERROR PATTERN ANALYSIS ===" >> "$ANALYSIS_REPORT"
    echo "Generated: $(date)" >> "$ANALYSIS_REPORT"
    echo "" >> "$ANALYSIS_REPORT"

    # Look for "comando não encontrado" errors (Portuguese "command not found")
    local cmd_errors=$(grep -c "comando não encontrado" "$MAIN_LOG" 2>/dev/null || echo "0")
    echo "Command Not Found Errors: $cmd_errors" >> "$ANALYSIS_REPORT"

    if [ "$cmd_errors" -gt 0 ]; then
        echo "" >> "$ANALYSIS_REPORT"
        echo "Scripts with Command Not Found errors:" >> "$ANALYSIS_REPORT"
        grep -B2 -A1 "comando não encontrado" "$MAIN_LOG" | grep -E "Starting execution:|comando não encontrado" >> "$ANALYSIS_REPORT" 2>/dev/null
        echo "" >> "$ANALYSIS_REPORT"
        echo "DIAGNOSIS: Scripts contain unquoted text being interpreted as commands" >> "$ANALYSIS_REPORT"
        echo "FIX: Review and fix script templates to properly quote all text" >> "$ANALYSIS_REPORT"
        echo "" >> "$ANALYSIS_REPORT"
    fi

    # Look for permission errors
    local perm_errors=$(grep -c -i "permission denied\|cannot access" "$MAIN_LOG" 2>/dev/null || echo "0")
    echo "Permission Errors: $perm_errors" >> "$ANALYSIS_REPORT"

    # Look for service errors
    local service_errors=$(grep -c -i "failed to start\|failed to enable\|service failed" "$MAIN_LOG" 2>/dev/null || echo "0")
    echo "Service Management Errors: $service_errors" >> "$ANALYSIS_REPORT"

    # Look for file not found errors
    local file_errors=$(grep -c -i "no such file\|file not found" "$MAIN_LOG" 2>/dev/null || echo "0") 
    echo "File Not Found Errors: $file_errors" >> "$ANALYSIS_REPORT"

    # Success rate analysis
    local success_count=$(grep -c "\[SUCCESS\]" "$MAIN_LOG" 2>/dev/null || echo "0")
    local error_count=$(grep -c "\[ERROR\]" "$MAIN_LOG" 2>/dev/null || echo "0")
    local total=$((success_count + error_count))

    echo "" >> "$ANALYSIS_REPORT"
    echo "=== EXECUTION STATISTICS ===" >> "$ANALYSIS_REPORT"
    echo "Successful Operations: $success_count" >> "$ANALYSIS_REPORT"
    echo "Failed Operations: $error_count" >> "$ANALYSIS_REPORT"

    if [ "$total" -gt 0 ]; then
        local success_rate=$((success_count * 100 / total))
        echo "Success Rate: $success_rate%" >> "$ANALYSIS_REPORT"
    fi

    echo "" >> "$ANALYSIS_REPORT"
    echo "=== MOST COMMON SCRIPT FAILURES ===" >> "$ANALYSIS_REPORT"
    grep "\[ERROR\]" "$MAIN_LOG" 2>/dev/null | cut -d']' -f3 | cut -d' ' -f2 | sort | uniq -c | sort -nr | head -10 >> "$ANALYSIS_REPORT" 2>/dev/null

    echo "" >> "$ANALYSIS_REPORT"
    echo "Analysis complete. Check $ERROR_LOG for detailed error information." >> "$ANALYSIS_REPORT"
}

# Generate remediation suggestions
generate_remediation_suggestions() {
    echo "" >> "$ANALYSIS_REPORT" 
    echo "=== REMEDIATION SUGGESTIONS ===" >> "$ANALYSIS_REPORT"

    cat >> "$ANALYSIS_REPORT" << 'EOF'

1. COMMAND NOT FOUND ERRORS:
   - Problem: Unquoted text in scripts being executed as commands
   - Solution: Review script templates and properly quote all comments and text
   - Example: Change 'MaxSessions: comando não encontrado' to properly quoted comments

2. PERMISSION ERRORS:
   - Problem: Insufficient permissions or wrong ownership
   - Solution: Ensure scripts run as root and files have correct permissions
   - Check: ls -la /etc/ssh/sshd_config (should be readable by root)

3. SERVICE ERRORS:
   - Problem: Services not starting or configuration issues
   - Solution: Check service status and configuration files before restart
   - Debug: systemctl status <service-name> -l

4. FILE ERRORS:
   - Problem: Configuration files missing or in different locations
   - Solution: Check file existence before attempting modifications
   - Add: Conditional checks for file existence in scripts

RECOMMENDED NEXT STEPS:
1. Use the FIXED scripts in scripts/ directory
2. Test in non-production environment first
3. Run scripts individually to identify specific issues
4. Check system logs: journalctl -xe for additional error details
5. Ensure all scripts have execute permissions: chmod +x scripts/*.sh

EOF

    echo "Remediation suggestions added to report."
}

# Main error analysis function
main() {
    echo "Starting CIS Error Analysis System..."

    # Initialize logs
    init_error_log

    # Clear previous analysis report
    > "$ANALYSIS_REPORT"

    # Perform analysis
    analyze_error_patterns
    generate_remediation_suggestions

    echo ""
    echo "Error analysis complete!"
    echo "Reports generated:"
    echo "- Detailed error log: $ERROR_LOG"
    echo "- Analysis report: $ANALYSIS_REPORT"
    echo ""
    echo "To view the analysis report:"
    echo "cat $ANALYSIS_REPORT"
}

# Run main function
main "$@"
