#!/bin/bash

SCRIPT_NAME="4.2.3_permissions_all_logfiles.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
LOG_DIR="/var/log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 4.2.3 - Ensure permissions on all logfiles are configured"
    echo ""

    # Check if /var/log directory exists
    if [ ! -d "$LOG_DIR" ]; then
        echo "ERROR: Log directory $LOG_DIR not found"
        log_message "ERROR" "Log directory not found"
        return 1
    fi

    echo "Scanning log files in $LOG_DIR..."
    echo ""

    # Find all files in /var/log (excluding directories and special files)
    # We focus on regular files that are likely log files
    LOGFILES=$(find "$LOG_DIR" -type f 2>/dev/null)

    if [ -z "$LOGFILES" ]; then
        echo "No log files found in $LOG_DIR"
        log_message "WARNING" "No log files found"
        return 0
    fi

    # Count total files
    TOTAL_FILES=$(echo "$LOGFILES" | wc -l)
    echo "Found $TOTAL_FILES log files"
    echo ""

    # Create a report of current permissions before making changes
    REPORT_FILE="$BACKUP_DIR/logfile_permissions_before.$(date +%Y%m%d_%H%M%S).txt"
    echo "Creating permission report: $REPORT_FILE"
    echo "Log File Permissions Report - Before Remediation" > "$REPORT_FILE"
    echo "Generated: $(date)" >> "$REPORT_FILE"
    echo "======================================================" >> "$REPORT_FILE"
    find "$LOG_DIR" -type f -exec ls -l {} \; >> "$REPORT_FILE" 2>/dev/null

    echo "Processing log files..."
    echo ""

    MODIFIED_COUNT=0
    SKIPPED_COUNT=0
    ERROR_COUNT=0

    # Process each log file
    while IFS= read -r logfile; do
        # Skip if file doesn't exist (race condition)
        [ ! -f "$logfile" ] && continue

        # Get current permissions in octal format
        CURRENT_PERMS=$(stat -c '%a' "$logfile" 2>/dev/null)
        
        if [ -z "$CURRENT_PERMS" ]; then
            ((ERROR_COUNT++))
            continue
        fi

        # Check if permissions are more permissive than 0640
        # We need to ensure group-write and world permissions are removed
        # Extract the permission digits
        OWNER_PERM=${CURRENT_PERMS:0:1}
        GROUP_PERM=${CURRENT_PERMS:1:1}
        OTHER_PERM=${CURRENT_PERMS:2:1}

        # Check if permissions need to be restricted
        NEEDS_CHANGE=0

        # Group should not have write permission (check if bit 1 is set)
        if [ $((GROUP_PERM & 2)) -ne 0 ]; then
            NEEDS_CHANGE=1
        fi

        # Other should have no permissions
        if [ "$OTHER_PERM" != "0" ]; then
            NEEDS_CHANGE=1
        fi

        if [ $NEEDS_CHANGE -eq 1 ]; then
            # Set permissions to 0640 (owner: rw, group: r, other: none)
            if chmod 0640 "$logfile" 2>/dev/null; then
                ((MODIFIED_COUNT++))
                log_message "INFO" "Modified permissions: $logfile ($CURRENT_PERMS -> 0640)"
            else
                ((ERROR_COUNT++))
                log_message "ERROR" "Failed to modify permissions: $logfile"
            fi
        else
            ((SKIPPED_COUNT++))
        fi
    done <<< "$LOGFILES"

    echo ""
    echo "Summary:"
    echo "--------"
    echo "Total files processed: $TOTAL_FILES"
    echo "Files modified: $MODIFIED_COUNT"
    echo "Files already compliant: $SKIPPED_COUNT"
    if [ $ERROR_COUNT -gt 0 ]; then
        echo "Errors encountered: $ERROR_COUNT"
    fi
    echo ""

    # Create post-remediation report
    REPORT_FILE_AFTER="$BACKUP_DIR/logfile_permissions_after.$(date +%Y%m%d_%H%M%S).txt"
    echo "Creating post-remediation report: $REPORT_FILE_AFTER"
    echo "Log File Permissions Report - After Remediation" > "$REPORT_FILE_AFTER"
    echo "Generated: $(date)" >> "$REPORT_FILE_AFTER"
    echo "======================================================" >> "$REPORT_FILE_AFTER"
    find "$LOG_DIR" -type f -exec ls -l {} \; >> "$REPORT_FILE_AFTER" 2>/dev/null

    # Check for any remaining issues
    echo ""
    echo "Verifying permissions..."
    REMAINING_ISSUES=$(find "$LOG_DIR" -type f -perm /027 2>/dev/null | wc -l)
    
    if [ $REMAINING_ISSUES -eq 0 ]; then
        echo "All log files have appropriate permissions"
        log_message "SUCCESS" "All log files have secure permissions"
    else
        echo "WARNING: $REMAINING_ISSUES files still have overly permissive permissions"
        echo "These files may require manual review:"
        find "$LOG_DIR" -type f -perm /027 -ls 2>/dev/null
        log_message "WARNING" "$REMAINING_ISSUES files with overly permissive permissions"
    fi

    echo ""
    echo "Status: COMPLIANT"
    echo "Log files are configured with secure permissions (0640 or more restrictive)"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
