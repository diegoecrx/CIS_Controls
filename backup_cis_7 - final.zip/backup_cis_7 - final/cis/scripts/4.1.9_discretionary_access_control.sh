#!/bin/bash

SCRIPT_NAME="4.1.9_discretionary_access_control.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_RULES="/etc/audit/rules.d/dac_modifications.rules"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 4.1.9 - Ensure discretionary access control permission modification events are collected"
    echo ""

    # Check if auditd is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "auditd is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "auditd not installed - control not applicable"
        return 0
    fi

    # Create rules directory if it doesn't exist
    mkdir -p /etc/audit/rules.d 2>/dev/null

    # Backup existing DAC rules file if it exists
    if [ -f "$AUDIT_RULES" ]; then
        cp "$AUDIT_RULES" "$BACKUP_DIR/dac_modifications.rules.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up existing DAC modification rules file"
    fi

    echo "Configuring audit rules for discretionary access control modifications..."
    echo ""

    # Determine system architecture
    ARCH=$(uname -m)
    if [ "$ARCH" = "x86_64" ]; then
        ARCH_BITS="b64"
    else
        ARCH_BITS="b32"
    fi

    # Create comprehensive audit rules for DAC modifications
    cat > "$AUDIT_RULES" << EOF
## Audit rules for Discretionary Access Control (DAC) modifications (CIS 4.1.9)
## Monitor changes to file permissions, ownership, and ACLs

# Monitor chmod system calls (change file permissions)
-a always,exit -F arch=b32 -S chmod,fchmod,fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S chmod,fchmod,fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod

# Monitor chown system calls (change file ownership)
-a always,exit -F arch=b32 -S chown,fchown,fchownat,lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S chown,fchown,fchownat,lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod

# Monitor setxattr system calls (set extended attributes/ACLs)
-a always,exit -F arch=b32 -S setxattr,lsetxattr,fsetxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S setxattr,lsetxattr,fsetxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod

# Monitor removexattr system calls (remove extended attributes/ACLs)
-a always,exit -F arch=b32 -S removexattr,lremovexattr,fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S removexattr,lremovexattr,fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
EOF

    if [ $? -eq 0 ]; then
        echo "Created audit rules file: $AUDIT_RULES"
        log_message "SUCCESS" "Created DAC modification audit rules"
    else
        echo "ERROR: Failed to create audit rules file"
        log_message "ERROR" "Failed to create audit rules file"
        return 1
    fi

    echo ""
    echo "Audit rules configured:"
    echo "----------------------"
    echo "- chmod, fchmod, fchmodat - File permission changes"
    echo "- chown, fchown, fchownat, lchown - File ownership changes"
    echo "- setxattr, lsetxattr, fsetxattr - Extended attribute/ACL additions"
    echo "- removexattr, lremovexattr, fremovexattr - Extended attribute/ACL removals"
    echo ""

    # Load the new audit rules
    echo "Loading audit rules..."
    if augenrules --load >/dev/null 2>&1; then
        echo "Audit rules loaded successfully"
        log_message "SUCCESS" "Audit rules loaded successfully"
    else
        echo "WARNING: Failed to load audit rules automatically"
        echo "Run 'augenrules --load' or 'service auditd restart' to apply changes"
        log_message "WARNING" "Manual audit rules reload required"
    fi

    # Verify auditd service is enabled and running
    if systemctl is-enabled auditd >/dev/null 2>&1; then
        echo "auditd service is enabled"
    else
        echo "WARNING: auditd service is not enabled - enabling now..."
        systemctl enable auditd >/dev/null 2>&1
        log_message "INFO" "Enabled auditd service"
    fi

    if systemctl is-active auditd >/dev/null 2>&1; then
        echo "auditd service is running"
    else
        echo "WARNING: auditd service is not running - starting now..."
        systemctl start auditd >/dev/null 2>&1
        log_message "INFO" "Started auditd service"
    fi

    # Display verification command
    echo ""
    echo "Verification:"
    echo "Run 'auditctl -l | grep perm_mod' to verify rules are active"
    echo ""
    echo "Status: COMPLIANT"
    echo "DAC permission modification events are now being audited"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
