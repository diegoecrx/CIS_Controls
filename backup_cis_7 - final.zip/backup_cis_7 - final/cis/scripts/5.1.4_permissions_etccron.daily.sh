#!/bin/bash

SCRIPT_NAME="5.1.4_permissions_etccron.daily.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
CRON_DAILY="/etc/cron.daily"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.1.4 - Ensure permissions on /etc/cron.daily are configured"
    echo ""

    # Check if /etc/cron.daily directory exists
    if [ ! -d "$CRON_DAILY" ]; then
        echo "Directory $CRON_DAILY does not exist"
        echo "Creating directory..."
        
        if mkdir -p "$CRON_DAILY" 2>/dev/null; then
            echo "Created directory $CRON_DAILY"
            log_message "SUCCESS" "Created cron.daily directory"
        else
            echo "ERROR: Failed to create directory"
            log_message "ERROR" "Failed to create cron.daily directory"
            return 1
        fi
    else
        echo "Directory $CRON_DAILY exists"
    fi

    # Get current permissions, owner, and group
    CURRENT_PERMS=$(stat -c '%a' "$CRON_DAILY" 2>/dev/null)
    CURRENT_OWNER=$(stat -c '%U' "$CRON_DAILY" 2>/dev/null)
    CURRENT_GROUP=$(stat -c '%G' "$CRON_DAILY" 2>/dev/null)

    echo ""
    echo "Current configuration:"
    echo "  Permissions: $CURRENT_PERMS"
    echo "  Owner: $CURRENT_OWNER"
    echo "  Group: $CURRENT_GROUP"
    echo ""

    CHANGES_MADE=0

    # Check and fix ownership (should be root:root)
    if [ "$CURRENT_OWNER" != "root" ] || [ "$CURRENT_GROUP" != "root" ]; then
        echo "Setting ownership to root:root..."
        
        if chown root:root "$CRON_DAILY" 2>/dev/null; then
            echo "Ownership changed to root:root"
            log_message "SUCCESS" "Changed ownership to root:root"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to change ownership"
            log_message "ERROR" "Failed to change ownership"
            return 1
        fi
    else
        echo "Ownership is correct (root:root)"
    fi

    # Check and fix permissions (should be 0700)
    if [ "$CURRENT_PERMS" != "700" ]; then
        echo "Setting permissions to 0700..."
        
        if chmod 0700 "$CRON_DAILY" 2>/dev/null; then
            echo "Permissions changed to 0700"
            log_message "SUCCESS" "Changed permissions to 0700"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to change permissions"
            log_message "ERROR" "Failed to change permissions"
            return 1
        fi
    else
        echo "Permissions are correct (0700)"
    fi

    # Check files inside the directory
    echo ""
    echo "Checking scripts in $CRON_DAILY..."
    
    SCRIPT_COUNT=$(find "$CRON_DAILY" -type f 2>/dev/null | wc -l)
    
    if [ $SCRIPT_COUNT -gt 0 ]; then
        echo "Found $SCRIPT_COUNT script(s) in directory"
        
        # Set secure permissions on all files in the directory
        find "$CRON_DAILY" -type f -exec chmod 0700 {} \; 2>/dev/null
        find "$CRON_DAILY" -type f -exec chown root:root {} \; 2>/dev/null
        
        echo "Set secure permissions (0700) and ownership (root:root) on all scripts"
        log_message "INFO" "Secured $SCRIPT_COUNT scripts in cron.daily"
    else
        echo "No scripts found in directory"
    fi

    # Verify the changes
    echo ""
    echo "Verification:"
    echo "-------------"
    
    NEW_PERMS=$(stat -c '%a' "$CRON_DAILY" 2>/dev/null)
    NEW_OWNER=$(stat -c '%U' "$CRON_DAILY" 2>/dev/null)
    NEW_GROUP=$(stat -c '%G' "$CRON_DAILY" 2>/dev/null)

    echo "  Directory permissions: $NEW_PERMS"
    echo "  Directory owner: $NEW_OWNER"
    echo "  Directory group: $NEW_GROUP"
    echo ""

    # Final compliance check
    if [ "$NEW_PERMS" = "700" ] && [ "$NEW_OWNER" = "root" ] && [ "$NEW_GROUP" = "root" ]; then
        echo "Status: COMPLIANT"
        echo "/etc/cron.daily has secure permissions (0700) and ownership (root:root)"
        
        if [ $CHANGES_MADE -eq 1 ]; then
            log_message "SUCCESS" "Remediation applied successfully"
        else
            log_message "SUCCESS" "Directory was already compliant"
        fi
    else
        echo "Status: NON-COMPLIANT"
        echo "Failed to configure /etc/cron.daily properly"
        log_message "ERROR" "Failed to achieve compliance"
        return 1
    fi

    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
