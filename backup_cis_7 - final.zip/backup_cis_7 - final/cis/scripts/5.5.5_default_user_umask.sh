#!/bin/bash

SCRIPT_NAME="5.5.5_default_user_umask.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
BASHRC="/etc/bashrc"
PROFILE="/etc/profile"
UMASK_VALUE="027"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.5.5 - Ensure default user umask is configured"
    echo ""

    CHANGES_MADE=0

    # Configure /etc/bashrc
    echo "Configuring umask in $BASHRC..."
    echo ""

    if [ -f "$BASHRC" ]; then
        # Backup bashrc
        cp "$BASHRC" "$BACKUP_DIR/bashrc.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $BASHRC"

        # Check if umask is already configured
        CURRENT_UMASK=$(grep -E "^[[:space:]]*umask[[:space:]]+" "$BASHRC" | grep -v "^#" | head -1 | awk '{print $2}')

        if [ -n "$CURRENT_UMASK" ]; then
            echo "umask is currently set to: $CURRENT_UMASK"
            
            # Convert to decimal for comparison
            CURRENT_DEC=$((8#$CURRENT_UMASK))
            TARGET_DEC=$((8#$UMASK_VALUE))
            
            if [ "$CURRENT_DEC" -ge "$TARGET_DEC" ]; then
                echo "umask is compliant (027 or more restrictive)"
                log_message "INFO" "bashrc umask already compliant"
            else
                echo "umask is too permissive, changing to $UMASK_VALUE..."
                sed -i "s/^[[:space:]]*umask[[:space:]]\+[0-9]\+/umask $UMASK_VALUE/" "$BASHRC"
                echo "Updated umask in $BASHRC"
                log_message "SUCCESS" "Updated umask in bashrc"
                CHANGES_MADE=1
            fi
        else
            echo "umask not configured in $BASHRC"
            echo "Adding umask configuration..."
            
            cat >> "$BASHRC" << EOF

# CIS 5.5.5 - Set default umask
umask $UMASK_VALUE
EOF
            
            echo "Added umask $UMASK_VALUE to $BASHRC"
            log_message "SUCCESS" "Added umask to bashrc"
            CHANGES_MADE=1
        fi
    else
        echo "WARNING: $BASHRC not found"
        log_message "WARNING" "bashrc not found"
    fi

    echo ""

    # Configure /etc/profile
    echo "Configuring umask in $PROFILE..."
    echo ""

    if [ -f "$PROFILE" ]; then
        # Backup profile
        cp "$PROFILE" "$BACKUP_DIR/profile.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $PROFILE"

        # Check if umask is already configured
        CURRENT_UMASK=$(grep -E "^[[:space:]]*umask[[:space:]]+" "$PROFILE" | grep -v "^#" | head -1 | awk '{print $2}')

        if [ -n "$CURRENT_UMASK" ]; then
            echo "umask is currently set to: $CURRENT_UMASK"
            
            # Convert to decimal for comparison
            CURRENT_DEC=$((8#$CURRENT_UMASK))
            TARGET_DEC=$((8#$UMASK_VALUE))
            
            if [ "$CURRENT_DEC" -ge "$TARGET_DEC" ]; then
                echo "umask is compliant (027 or more restrictive)"
                log_message "INFO" "profile umask already compliant"
            else
                echo "umask is too permissive, changing to $UMASK_VALUE..."
                sed -i "s/^[[:space:]]*umask[[:space:]]\+[0-9]\+/umask $UMASK_VALUE/" "$PROFILE"
                echo "Updated umask in $PROFILE"
                log_message "SUCCESS" "Updated umask in profile"
                CHANGES_MADE=1
            fi
        else
            echo "umask not configured in $PROFILE"
            echo "Adding umask configuration..."
            
            cat >> "$PROFILE" << EOF

# CIS 5.5.5 - Set default umask
umask $UMASK_VALUE
EOF
            
            echo "Added umask $UMASK_VALUE to $PROFILE"
            log_message "SUCCESS" "Added umask to profile"
            CHANGES_MADE=1
        fi
    else
        echo "ERROR: $PROFILE not found"
        log_message "ERROR" "profile not found"
        return 1
    fi

    # Check /etc/profile.d/*.sh files for conflicting umask settings
    echo ""
    echo "Checking /etc/profile.d/*.sh files for conflicting umask..."
    
    PROFILE_D_FILES=$(find /etc/profile.d -name "*.sh" -type f 2>/dev/null)
    
    if [ -n "$PROFILE_D_FILES" ]; then
        while IFS= read -r file; do
            WEAK_UMASK=$(grep -E "^[[:space:]]*umask[[:space:]]+" "$file" 2>/dev/null | grep -v "^#" | awk '{print $2}')
            
            if [ -n "$WEAK_UMASK" ]; then
                WEAK_DEC=$((8#$WEAK_UMASK))
                TARGET_DEC=$((8#$UMASK_VALUE))
                
                if [ "$WEAK_DEC" -lt "$TARGET_DEC" ]; then
                    echo "WARNING: $file has weak umask ($WEAK_UMASK)"
                    echo "Commenting out weak umask in $(basename $file)..."
                    
                    cp "$file" "$BACKUP_DIR/$(basename $file).$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
                    sed -i "s/^[[:space:]]*umask[[:space:]]\+[0-9]\+/#&/" "$file"
                    
                    log_message "WARNING" "Commented weak umask in $(basename $file)"
                    CHANGES_MADE=1
                fi
            fi
        done <<< "$PROFILE_D_FILES"
    fi

    # Verify configuration
    echo ""
    echo "Verification:"
    echo "-------------"

    if [ -f "$BASHRC" ]; then
        BASHRC_UMASK=$(grep -E "^[[:space:]]*umask[[:space:]]+" "$BASHRC" | grep -v "^#" | head -1 | awk '{print $2}')
        echo "bashrc umask: ${BASHRC_UMASK:-NOT SET}"
    fi

    if [ -f "$PROFILE" ]; then
        PROFILE_UMASK=$(grep -E "^[[:space:]]*umask[[:space:]]+" "$PROFILE" | grep -v "^#" | head -1 | awk '{print $2}')
        echo "profile umask: ${PROFILE_UMASK:-NOT SET}"
    fi

    echo ""

    # Check compliance
    COMPLIANT=1
    
    if [ -n "$BASHRC_UMASK" ]; then
        BASHRC_DEC=$((8#$BASHRC_UMASK))
        TARGET_DEC=$((8#$UMASK_VALUE))
        if [ "$BASHRC_DEC" -lt "$TARGET_DEC" ]; then
            COMPLIANT=0
        fi
    else
        COMPLIANT=0
    fi
    
    if [ -n "$PROFILE_UMASK" ]; then
        PROFILE_DEC=$((8#$PROFILE_UMASK))
        if [ "$PROFILE_DEC" -lt "$TARGET_DEC" ]; then
            COMPLIANT=0
        fi
    else
        COMPLIANT=0
    fi

    if [ $COMPLIANT -eq 1 ]; then
        echo "Status: COMPLIANT"
        echo "Default umask is 027 or more restrictive"
        echo ""
        echo "File permissions with umask $UMASK_VALUE:"
        echo "  - New files: 640 (rw-r-----)"
        echo "  - New directories: 750 (rwxr-x---)"
        log_message "SUCCESS" "umask configured properly"
    else
        echo "Status: NON-COMPLIANT"
        echo "umask is not properly configured"
        log_message "ERROR" "umask configuration incomplete"
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. Changes take effect for NEW shell sessions only"
    echo "2. Existing sessions will not be affected"
    echo "3. Users can override umask in their ~/.bashrc"
    echo "4. umask affects new files and directories only"
    echo "5. Existing files retain their current permissions"
    echo ""

    if [ $CHANGES_MADE -eq 1 ]; then
        echo "Changes have been applied. Users must start new shell sessions."
        log_message "SUCCESS" "Remediation completed with changes"
    else
        echo "No changes were necessary."
        log_message "SUCCESS" "System already compliant"
    fi

    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
