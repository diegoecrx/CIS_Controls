#!/bin/bash

SCRIPT_NAME="2.2.1.3_ntp.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

backup_file() {
    [ -f "$1" ] || return 1
    cp "$1" "$BACKUP_DIR/$(basename $1).$(date +%Y%m%d_%H%M%S).backup"
}

configure_ntp() {
    local ntp_conf="/etc/ntp.conf"
    
    backup_file "$ntp_conf"
    
    # Add NTP servers if not present
    if ! grep -q "^server" "$ntp_conf"; then
        cat >> "$ntp_conf" << 'EOF'

# CIS 2.2.1.3 - NTP Configuration
server 0.pool.ntp.org iburst
server 1.pool.ntp.org iburst
server 2.pool.ntp.org iburst
server 3.pool.ntp.org iburst
EOF
        log_message "SUCCESS" "Added NTP servers"
    fi
    
    # Restrict access
    if ! grep -q "^restrict default" "$ntp_conf"; then
        cat >> "$ntp_conf" << 'EOF'

# Restrict NTP access
restrict default kod nomodify notrap nopeer noquery
restrict -6 default kod nomodify notrap nopeer noquery
restrict 127.0.0.1
restrict -6 ::1
EOF
        log_message "SUCCESS" "Added NTP restrictions"
    fi
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.1.3 - Configure NTP"
    echo ""
    
    # Check if chronyd is running (preferred over ntpd)
    if systemctl is-active chronyd &>/dev/null; then
        echo "chronyd is running (preferred time sync)"
        echo "Status: COMPLIANT"
        log_message "INFO" "chronyd already configured"
        return 0
    fi
    
    # Install and configure ntp
    if ! rpm -q ntp &>/dev/null; then
        echo "Installing ntp..."
        yum install -y ntp &>/dev/null
        log_message "SUCCESS" "Installed ntp"
    fi
    
    configure_ntp
    
    # Enable and start ntpd
    systemctl enable ntpd &>/dev/null
    systemctl start ntpd &>/dev/null
    
    echo "NTP configured and started"
    echo "Status: COMPLIANT"
    echo ""
    
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
