#!/bin/bash

SCRIPT_NAME="6.2.11_all_users_home_directories_exist.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_home_directories_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.11 - Ensure all users' home directories exist"
    echo ""
    echo "NOTE: This is primarily an AUDIT control"
    echo "Home directories will be created only with explicit confirmation"
    echo ""

    log_message "INFO" "Starting home directory audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.11 Home Directory Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies users whose home directories do not exist.

EOF

    echo "Checking user home directories..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    MISSING_HOMES=0
    SYSTEM_USERS=0
    REGULAR_USERS=0

    # Read /etc/passwd and check each user's home directory
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Determine if this is a system user (UID < 1000) or regular user
        if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
            USER_TYPE="SYSTEM"
            ((SYSTEM_USERS++))
        else
            USER_TYPE="REGULAR"
            if [ "$uid" -ge 1000 ]; then
                ((REGULAR_USERS++))
            fi
        fi
        
        # Check if home directory exists
        if [ ! -d "$homedir" ]; then
            echo "[$USER_TYPE] User: $username (UID:$uid) - Home directory missing: $homedir" | tee -a "$AUDIT_REPORT"
            ((MISSING_HOMES++))
        fi
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Total system users checked: $SYSTEM_USERS
Total regular users checked: $REGULAR_USERS
Missing home directories: $MISSING_HOMES

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "System users checked: $SYSTEM_USERS"
    echo "Regular users checked: $REGULAR_USERS"
    echo "Missing home directories: $MISSING_HOMES"
    echo ""

    if [ $MISSING_HOMES -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "All users have existing home directories"
        log_message "SUCCESS" "All home directories exist"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: REVIEW REQUIRED"
        echo "$MISSING_HOMES user(s) have missing home directories"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $MISSING_HOMES missing home directories"
    fi

    # Ask if user wants to create missing directories
    echo ""
    echo "IMPORTANT: Creating home directories should be done carefully!"
    echo ""
    echo "Options:"
    echo "  1) Create missing home directories (with confirmation for each)"
    echo "  2) Exit without creating directories (manual review recommended)"
    echo ""
    read -p "Enter choice [1-2] (default: 2): " CHOICE
    CHOICE=${CHOICE:-2}

    if [ "$CHOICE" = "1" ]; then
        echo ""
        echo "Creating missing home directories..."
        echo ""
        
        CREATED=0
        SKIPPED=0
        
        # Re-read passwd and create missing directories with confirmation
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ ! -d "$homedir" ]; then
                # Determine user type for display
                if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                    USER_TYPE="system user"
                else
                    USER_TYPE="regular user"
                fi
                
                echo "User: $username ($USER_TYPE, UID:$uid)"
                echo "Missing directory: $homedir"
                read -p "Create this directory? [y/N]: " CONFIRM
                
                if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
                    # Create directory
                    if mkdir -p "$homedir" 2>/dev/null; then
                        # Set ownership
                        chown "$username:$username" "$homedir" 2>/dev/null
                        # Set permissions to 750 (rwxr-x---)
                        chmod 750 "$homedir" 2>/dev/null
                        
                        echo "Created: $homedir (owner: $username, permissions: 750)"
                        log_message "SUCCESS" "Created home directory for $username: $homedir"
                        ((CREATED++))
                    else
                        echo "ERROR: Failed to create $homedir"
                        log_message "ERROR" "Failed to create home directory for $username"
                    fi
                else
                    echo "Skipped: $homedir"
                    ((SKIPPED++))
                fi
                echo ""
            fi
        done < /etc/passwd
        
        echo "Summary:"
        echo "  Created: $CREATED"
        echo "  Skipped: $SKIPPED"
        log_message "SUCCESS" "Created $CREATED home directories, skipped $SKIPPED"
        
    else
        echo ""
        echo "No directories created. Manual review recommended."
        echo ""
        echo "To manually create a home directory:"
        echo "  1. mkdir -p /path/to/home"
        echo "  2. chown username:username /path/to/home"
        echo "  3. chmod 750 /path/to/home"
        echo "  4. Consider copying skeleton files from /etc/skel"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. System users (UID < 1000) may intentionally have non-existent home directories"
    echo "2. Some service accounts don't need home directories"
    echo "3. Verify the legitimacy of each user before creating directories"
    echo "4. New home directories should be populated with skeleton files if needed"
    echo "5. Review /etc/skel for default user files and configurations"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
