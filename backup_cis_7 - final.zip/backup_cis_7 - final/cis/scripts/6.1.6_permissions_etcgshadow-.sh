#!/bin/bash

SCRIPT_NAME="6.1.6_permissions_etcgshadow.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
GSHADOW_FILE="/etc/gshadow"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.1.6 - Ensure permissions on /etc/gshadow are configured"
    echo ""

    # Check if gshadow file exists
    if [ ! -f "$GSHADOW_FILE" ]; then
        echo "ERROR: $GSHADOW_FILE not found"
        log_message "ERROR" "gshadow file not found"
        return 1
    fi

    echo "$GSHADOW_FILE exists"
    echo ""

    # Get current permissions, owner, and group
    CURRENT_PERMS=$(stat -c '%a' "$GSHADOW_FILE" 2>/dev/null)
    CURRENT_OWNER=$(stat -c '%U' "$GSHADOW_FILE" 2>/dev/null)
    CURRENT_GROUP=$(stat -c '%G' "$GSHADOW_FILE" 2>/dev/null)

    echo "Current status:"
    echo "  Permissions: $CURRENT_PERMS"
    echo "  Owner: $CURRENT_OWNER"
    echo "  Group: $CURRENT_GROUP"
    echo ""

    CHANGES_MADE=0

    # Check and fix ownership
    if [ "$CURRENT_OWNER" != "root" ] || [ "$CURRENT_GROUP" != "root" ]; then
        echo "Fixing ownership to root:root..."
        
        if chown root:root "$GSHADOW_FILE" 2>/dev/null; then
            echo "Changed ownership to root:root"
            log_message "SUCCESS" "Changed ownership of gshadow to root:root"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to change ownership"
            log_message "ERROR" "Failed to change ownership of gshadow"
            return 1
        fi
    else
        echo "Ownership is correct (root:root)"
    fi

    echo ""

    # Check and fix permissions
    # Convert to decimal for comparison
    CURRENT_PERMS_DEC=$((8#$CURRENT_PERMS))
    
    # CIS recommends 0000 (most restrictive) or 0---- (read by root only)
    # We'll set to 0000 for maximum security
    if [ $CURRENT_PERMS_DEC -ne 0 ]; then
        echo "Fixing permissions to 0000..."
        
        if chmod 0000 "$GSHADOW_FILE" 2>/dev/null; then
            echo "Changed permissions to 0000"
            log_message "SUCCESS" "Changed permissions of gshadow to 0000"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to change permissions"
            log_message "ERROR" "Failed to change permissions of gshadow"
            return 1
        fi
    else
        echo "Permissions are correct (0000)"
    fi

    # Verify final state
    echo ""
    echo "Verification:"
    echo "-------------"

    FINAL_PERMS=$(stat -c '%a' "$GSHADOW_FILE" 2>/dev/null)
    FINAL_OWNER=$(stat -c '%U' "$GSHADOW_FILE" 2>/dev/null)
    FINAL_GROUP=$(stat -c '%G' "$GSHADOW_FILE" 2>/dev/null)

    echo "Final status:"
    echo "  Permissions: $FINAL_PERMS"
    echo "  Owner: $FINAL_OWNER"
    echo "  Group: $FINAL_GROUP"
    echo ""

    # Check compliance
    FINAL_PERMS_DEC=$((8#$FINAL_PERMS))
    
    if [ "$FINAL_OWNER" = "root" ] && [ "$FINAL_GROUP" = "root" ] && [ $FINAL_PERMS_DEC -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "/etc/gshadow is properly secured"
        log_message "SUCCESS" "gshadow properly secured"
    else
        echo "Status: NON-COMPLIANT"
        echo "WARNING: /etc/gshadow is not properly secured"
        log_message "ERROR" "gshadow not properly secured"
        return 1
    fi

    echo ""
    
    if [ $CHANGES_MADE -eq 1 ]; then
        echo "Changes have been applied successfully"
        log_message "SUCCESS" "Remediation completed with changes"
    else
        echo "No changes were necessary"
        log_message "SUCCESS" "System already compliant"
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. /etc/gshadow contains group password information"
    echo "2. Permissions 0000 ensure only root (via capabilities) can access"
    echo "3. This file is critical for group authentication security"
    echo "4. Regular users should never have access to this file"
    echo ""

    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
