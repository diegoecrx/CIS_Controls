#!/bin/bash

SCRIPT_NAME="2.3.5_ldap_client.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.3.5 - Remove LDAP Client"
    echo ""
    
    local packages=("openldap-clients")
    local found=0
    
    for pkg in "${packages[@]}"; do
        if rpm -q "$pkg" &>/dev/null; then
            echo "$pkg is installed"
            found=1
            
            yum remove -y "$pkg" &>/dev/null
            log_message "SUCCESS" "Removed $pkg"
            echo "$pkg removed"
        fi
    done
    
    if [ $found -eq 0 ]; then
        echo "LDAP client not installed"
        log_message "INFO" "LDAP client not present"
    fi
    
    echo "Status: COMPLIANT"
    echo ""
    
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
