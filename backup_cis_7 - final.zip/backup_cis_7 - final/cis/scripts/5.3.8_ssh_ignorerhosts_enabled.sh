#!/bin/bash

SCRIPT_NAME="5.3.8_ssh_ignorerhosts_enabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.8 - Ensure SSH IgnoreRhosts is enabled"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH to ignore .rhosts and .shosts files..."
    echo ""

    # Check current IgnoreRhosts setting
    CURRENT_SETTING=$(grep -i "^IgnoreRhosts" "$SSHD_CONFIG" 2>/dev/null | head -1 | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "IgnoreRhosts is not explicitly configured (default: yes)"
        echo "Adding explicit configuration..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.8 - Ignore rhosts and shosts files" >> "$SSHD_CONFIG"
        echo "IgnoreRhosts yes" >> "$SSHD_CONFIG"
        
        echo "Added 'IgnoreRhosts yes' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added IgnoreRhosts yes directive"
        
    elif [ "$CURRENT_SETTING" = "yes" ]; then
        echo "IgnoreRhosts is already set to 'yes'"
        log_message "INFO" "IgnoreRhosts already enabled"
        
    else
        echo "IgnoreRhosts is currently set to: $CURRENT_SETTING"
        echo "Changing to 'yes'..."
        
        sed -i 's/^IgnoreRhosts.*/IgnoreRhosts yes/' "$SSHD_CONFIG"
        
        echo "Changed IgnoreRhosts to 'yes'"
        log_message "SUCCESS" "Changed IgnoreRhosts to yes"
    fi

    # Also comment out any IgnoreRhosts no directives to prevent conflicts
    sed -i 's/^IgnoreRhosts[[:space:]]\+no/#IgnoreRhosts no/' "$SSHD_CONFIG"

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^IgnoreRhosts" "$SSHD_CONFIG" | grep -v "^#" | head -1 | awk '{print $2}')
    
    if [ -n "$FINAL_SETTING" ] && [ "$FINAL_SETTING" = "yes" ]; then
        echo "IgnoreRhosts is set to: yes"
        echo ""
        echo "Status: COMPLIANT"
        echo "SSH will ignore .rhosts and .shosts files"
        log_message "SUCCESS" "IgnoreRhosts is enabled"
    elif [ -z "$FINAL_SETTING" ]; then
        echo "ERROR: IgnoreRhosts directive not found"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "ERROR" "IgnoreRhosts directive missing"
    else
        echo "WARNING: IgnoreRhosts is set to: $FINAL_SETTING"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "WARNING" "IgnoreRhosts not set to 'yes'"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    echo "NOTE: Enabling IgnoreRhosts prevents:"
    echo "  - Use of insecure .rhosts files for authentication"
    echo "  - Use of .shosts files for host-based authentication"
    echo "  - Authentication based on hostname/IP trust relationships"
    echo "  - Bypassing proper SSH key or password authentication"
    echo ""
    echo "These legacy authentication methods are considered insecure"
    echo "and should not be used in modern environments"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
