#!/bin/bash

SCRIPT_NAME="5.4.3_password_hashing_algorithm_sha-512.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
LIBUSER_CONF="/etc/libuser.conf"
LOGIN_DEFS="/etc/login.defs"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.4.3 - Ensure password hashing algorithm is SHA-512"
    echo ""

    CHANGES_MADE=0

    # Configure /etc/libuser.conf
    echo "Configuring password hashing in $LIBUSER_CONF..."
    echo ""

    if [ -f "$LIBUSER_CONF" ]; then
        # Backup libuser.conf
        cp "$LIBUSER_CONF" "$BACKUP_DIR/libuser.conf.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $LIBUSER_CONF"

        # Check current crypt_style setting
        CURRENT_CRYPT=$(grep -i "^crypt_style" "$LIBUSER_CONF" 2>/dev/null | head -1 | awk -F= '{print $2}' | tr -d ' ')

        if [ -z "$CURRENT_CRYPT" ]; then
            echo "crypt_style not configured in $LIBUSER_CONF"
            echo "Adding crypt_style = sha512..."

            # Check if [defaults] section exists
            if grep -q "^\[defaults\]" "$LIBUSER_CONF"; then
                # Add after [defaults] section
                sed -i '/^\[defaults\]/a crypt_style = sha512' "$LIBUSER_CONF"
            else
                # Add [defaults] section with crypt_style
                echo "" >> "$LIBUSER_CONF"
                echo "[defaults]" >> "$LIBUSER_CONF"
                echo "crypt_style = sha512" >> "$LIBUSER_CONF"
            fi

            echo "Added crypt_style = sha512 to $LIBUSER_CONF"
            log_message "SUCCESS" "Added crypt_style = sha512 to libuser.conf"
            CHANGES_MADE=1

        elif [ "$CURRENT_CRYPT" = "sha512" ]; then
            echo "crypt_style is already set to sha512"
            log_message "INFO" "libuser.conf already configured correctly"

        else
            echo "crypt_style is currently: $CURRENT_CRYPT"
            echo "Changing to sha512..."
            sed -i 's/^crypt_style.*/crypt_style = sha512/' "$LIBUSER_CONF"
            echo "Changed crypt_style to sha512"
            log_message "SUCCESS" "Changed crypt_style to sha512"
            CHANGES_MADE=1
        fi
    else
        echo "WARNING: $LIBUSER_CONF not found"
        log_message "WARNING" "libuser.conf not found"
    fi

    echo ""

    # Configure /etc/login.defs
    echo "Configuring password hashing in $LOGIN_DEFS..."
    echo ""

    if [ -f "$LOGIN_DEFS" ]; then
        # Backup login.defs
        cp "$LOGIN_DEFS" "$BACKUP_DIR/login.defs.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $LOGIN_DEFS"

        # Check current ENCRYPT_METHOD setting
        CURRENT_ENCRYPT=$(grep -i "^ENCRYPT_METHOD" "$LOGIN_DEFS" 2>/dev/null | head -1 | awk '{print $2}')

        if [ -z "$CURRENT_ENCRYPT" ]; then
            echo "ENCRYPT_METHOD not configured in $LOGIN_DEFS"
            echo "Adding ENCRYPT_METHOD SHA512..."
            echo "" >> "$LOGIN_DEFS"
            echo "# CIS 5.4.3 - Use SHA-512 for password hashing" >> "$LOGIN_DEFS"
            echo "ENCRYPT_METHOD SHA512" >> "$LOGIN_DEFS"
            echo "Added ENCRYPT_METHOD SHA512 to $LOGIN_DEFS"
            log_message "SUCCESS" "Added ENCRYPT_METHOD SHA512 to login.defs"
            CHANGES_MADE=1

        elif [ "$CURRENT_ENCRYPT" = "SHA512" ]; then
            echo "ENCRYPT_METHOD is already set to SHA512"
            log_message "INFO" "login.defs already configured correctly"

        else
            echo "ENCRYPT_METHOD is currently: $CURRENT_ENCRYPT"
            echo "Changing to SHA512..."
            sed -i 's/^ENCRYPT_METHOD.*/ENCRYPT_METHOD SHA512/' "$LOGIN_DEFS"
            echo "Changed ENCRYPT_METHOD to SHA512"
            log_message "SUCCESS" "Changed ENCRYPT_METHOD to SHA512"
            CHANGES_MADE=1
        fi
    else
        echo "ERROR: $LOGIN_DEFS not found"
        log_message "ERROR" "login.defs not found"
        return 1
    fi

    # Verify configuration
    echo ""
    echo "Verification:"
    echo "-------------"

    if [ -f "$LIBUSER_CONF" ]; then
        FINAL_CRYPT=$(grep -i "^crypt_style" "$LIBUSER_CONF" 2>/dev/null | head -1 | awk -F= '{print $2}' | tr -d ' ')
        echo "libuser.conf crypt_style: ${FINAL_CRYPT:-NOT SET}"
    fi

    if [ -f "$LOGIN_DEFS" ]; then
        FINAL_ENCRYPT=$(grep -i "^ENCRYPT_METHOD" "$LOGIN_DEFS" 2>/dev/null | head -1 | awk '{print $2}')
        echo "login.defs ENCRYPT_METHOD: ${FINAL_ENCRYPT:-NOT SET}"
    fi

    echo ""

    # Check compliance
    COMPLIANT=1
    if [ -f "$LIBUSER_CONF" ]; then
        if [ "$FINAL_CRYPT" != "sha512" ]; then
            COMPLIANT=0
        fi
    fi
    if [ "$FINAL_ENCRYPT" != "SHA512" ]; then
        COMPLIANT=0
    fi

    if [ $COMPLIANT -eq 1 ]; then
        echo "Status: COMPLIANT"
        echo "Password hashing is configured to use SHA-512"
        log_message "SUCCESS" "SHA-512 password hashing configured"
    else
        echo "Status: NON-COMPLIANT"
        echo "Password hashing is not properly configured"
        log_message "ERROR" "SHA-512 configuration incomplete"
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. This change affects NEW passwords only"
    echo "2. Existing password hashes are not automatically updated"
    echo "3. Users must change their passwords to use SHA-512 hashing"
    echo "4. To force password update, run: chage -d 0 <username>"
    echo ""

    if [ $CHANGES_MADE -eq 1 ]; then
        echo "Changes have been applied. No system restart required."
        log_message "SUCCESS" "Remediation completed with changes"
    else
        echo "No changes were necessary."
        log_message "SUCCESS" "System already compliant"
    fi

    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
