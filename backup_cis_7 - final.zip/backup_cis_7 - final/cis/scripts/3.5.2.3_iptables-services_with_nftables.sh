#!/bin/bash

SCRIPT_NAME="3.5.2.3_iptables-services_with_nftables.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.2.3 - Ensure iptables-services not installed with nftables"
    echo ""
    
    # Check if nftables is installed and active
    if rpm -q nftables >/dev/null 2>&1; then
        log_message "INFO" "nftables is installed"
        
        # Check if iptables-services is installed
        if rpm -q iptables-services >/dev/null 2>&1; then
            log_message "WARNING" "iptables-services is installed alongside nftables"
            
            # Stop iptables services if running
            if systemctl is-active iptables >/dev/null 2>&1; then
                systemctl stop iptables >/dev/null 2>&1
                echo "iptables service stopped"
            fi
            
            if systemctl is-active ip6tables >/dev/null 2>&1; then
                systemctl stop ip6tables >/dev/null 2>&1
                echo "ip6tables service stopped"
            fi
            
            # Remove iptables-services package
            yum remove -y iptables-services >/dev/null 2>&1
            echo "iptables-services package removed"
            log_message "SUCCESS" "iptables-services removed"
        else
            echo "iptables-services not installed"
            log_message "INFO" "iptables-services not present"
        fi
        
        # Ensure nftables is enabled and running
        if ! systemctl is-enabled nftables >/dev/null 2>&1; then
            systemctl enable nftables >/dev/null 2>&1
            log_message "SUCCESS" "Enabled nftables"
        fi
        
        if ! systemctl is-active nftables >/dev/null 2>&1; then
            systemctl start nftables >/dev/null 2>&1
            log_message "SUCCESS" "Started nftables"
        fi
        
        echo "nftables is active and enabled"
        echo "Status: COMPLIANT"
    else
        echo "nftables is not installed"
        log_message "WARNING" "nftables not installed - this control requires nftables"
        echo "Status: NOT APPLICABLE"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
