#!/bin/bash

SCRIPT_NAME="2.2.13_net-snmp.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.13 - Remove net-snmp"
    echo ""
    
    if ! rpm -q net-snmp &>/dev/null; then
        echo "net-snmp not installed"
        echo "Status: COMPLIANT"
        log_message "INFO" "net-snmp not present"
    else
        echo "net-snmp is installed"
        
        systemctl stop snmpd 2>/dev/null
        systemctl disable snmpd 2>/dev/null
        
        yum remove -y net-snmp &>/dev/null
        log_message "SUCCESS" "Removed net-snmp"
        
        echo "net-snmp removed"
        echo "Status: COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
