#!/bin/bash

SCRIPT_NAME="2.2.3_avahi_server.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.3 - Remove Avahi Server"
    echo ""
    
    if ! rpm -q avahi &>/dev/null; then
        echo "Avahi not installed"
        echo "Status: COMPLIANT"
        log_message "INFO" "Avahi not present"
    else
        echo "Avahi is installed"
        
        systemctl stop avahi-daemon 2>/dev/null
        systemctl disable avahi-daemon 2>/dev/null
        systemctl stop avahi-daemon.socket 2>/dev/null
        systemctl disable avahi-daemon.socket 2>/dev/null
        
        yum remove -y avahi &>/dev/null
        log_message "SUCCESS" "Removed Avahi"
        
        echo "Avahi removed"
        echo "Status: COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
