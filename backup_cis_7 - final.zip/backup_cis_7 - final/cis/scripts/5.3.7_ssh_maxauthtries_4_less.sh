#!/bin/bash

SCRIPT_NAME="5.3.7_ssh_maxauthtries_4_less.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.7 - Ensure SSH MaxAuthTries is set to 4 or less"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH MaxAuthTries..."
    echo ""

    # Check current MaxAuthTries setting
    CURRENT_SETTING=$(grep -i "^MaxAuthTries" "$SSHD_CONFIG" 2>/dev/null | head -1 | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "MaxAuthTries is not explicitly configured (default: 6)"
        echo "Adding recommended configuration (4)..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.7 - Set MaxAuthTries to 4 or less" >> "$SSHD_CONFIG"
        echo "MaxAuthTries 4" >> "$SSHD_CONFIG"
        
        echo "Added 'MaxAuthTries 4' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added MaxAuthTries 4 directive"
        
    else
        echo "MaxAuthTries is currently set to: $CURRENT_SETTING"
        
        # Check if current setting is compliant (4 or less)
        if [ "$CURRENT_SETTING" -le 4 ] 2>/dev/null && [ "$CURRENT_SETTING" -gt 0 ]; then
            echo "MaxAuthTries is compliant (4 or less)"
            log_message "INFO" "MaxAuthTries already compliant: $CURRENT_SETTING"
        else
            echo "MaxAuthTries is too high (should be 4 or less)"
            echo "Changing to 4..."
            
            sed -i 's/^MaxAuthTries.*/MaxAuthTries 4/' "$SSHD_CONFIG"
            
            echo "Changed MaxAuthTries to 4"
            log_message "SUCCESS" "Changed MaxAuthTries to 4"
        fi
    fi

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^MaxAuthTries" "$SSHD_CONFIG" | grep -v "^#" | head -1 | awk '{print $2}')
    
    if [ -n "$FINAL_SETTING" ]; then
        echo "MaxAuthTries is set to: $FINAL_SETTING"
        echo ""
        
        # Check if final setting is compliant
        if [ "$FINAL_SETTING" -le 4 ] 2>/dev/null && [ "$FINAL_SETTING" -gt 0 ]; then
            echo "Status: COMPLIANT"
            echo "SSH MaxAuthTries is configured appropriately"
            echo ""
            echo "Configuration details:"
            echo "  - Maximum authentication attempts per connection: $FINAL_SETTING"
            echo "  - Server will disconnect after $FINAL_SETTING failed attempts"
            echo "  - This slows down brute-force password attacks"
            log_message "SUCCESS" "MaxAuthTries configured properly: $FINAL_SETTING"
        else
            echo "Status: NON-COMPLIANT"
            echo "MaxAuthTries ($FINAL_SETTING) exceeds recommended limit (4)"
            log_message "ERROR" "MaxAuthTries exceeds limit: $FINAL_SETTING"
        fi
    else
        echo "MaxAuthTries is not configured"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "ERROR" "MaxAuthTries not configured"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
