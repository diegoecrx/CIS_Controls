#!/bin/bash

SCRIPT_NAME="5.6_root_login_restricted_system_console.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SECURETTY="/etc/securetty"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.6 - Ensure root login is restricted to system console"
    echo ""

    # Check if securetty file exists
    if [ ! -f "$SECURETTY" ]; then
        echo "Creating $SECURETTY file..."
        touch "$SECURETTY"
        log_message "INFO" "Created $SECURETTY file"
    else
        echo "$SECURETTY exists"
        
        # Backup the file
        cp "$SECURETTY" "$BACKUP_DIR/securetty.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $SECURETTY"
    fi

    # Show current configuration
    echo ""
    echo "Current $SECURETTY contents:"
    echo "----------------------------"
    
    if [ -s "$SECURETTY" ]; then
        cat "$SECURETTY" | head -20
        LINE_COUNT=$(wc -l < "$SECURETTY")
        if [ "$LINE_COUNT" -gt 20 ]; then
            echo "... (showing first 20 of $LINE_COUNT lines)"
        fi
    else
        echo "(file is empty - root login completely disabled)"
    fi

    echo ""
    echo "IMPORTANT: Configuration Decision Required"
    echo "==========================================="
    echo ""
    echo "This control restricts where root can log in directly."
    echo ""
    echo "Recommended approach: EMPTY /etc/securetty"
    echo "  - Prevents ALL direct root logins"
    echo "  - Forces use of 'su' or 'sudo' from regular accounts"
    echo "  - Provides better audit trails and accountability"
    echo "  - Aligned with security best practices"
    echo ""
    echo "Alternative approach: Allow console login only"
    echo "  - Permits root login on physical console (tty1)"
    echo "  - Useful for emergency recovery scenarios"
    echo "  - Less secure than empty file"
    echo ""
    echo "Current recommendation: Leave file empty or configure console-only access"
    echo ""

    # Ask for configuration choice
    echo "Select configuration:"
    echo "  1) Empty file (disable ALL direct root logins) - RECOMMENDED"
    echo "  2) Allow console access only (tty1)"
    echo "  3) Keep current configuration"
    echo ""
    read -p "Enter choice [1-3] (default: 1): " CHOICE
    CHOICE=${CHOICE:-1}

    case $CHOICE in
        1)
            echo ""
            echo "Configuring: Empty file (disable all direct root logins)"
            
            # Empty the file
            > "$SECURETTY"
            
            echo "Emptied $SECURETTY"
            echo "Direct root login is now disabled on all terminals"
            log_message "SUCCESS" "Configured empty securetty - all direct root login disabled"
            ;;
            
        2)
            echo ""
            echo "Configuring: Console access only (tty1)"
            
            # Configure console-only access
            cat > "$SECURETTY" << 'EOF'
# CIS 5.6 - Restrict root login to system console
# Only allow root login on physical console
console
EOF
            
            echo "Configured $SECURETTY for console-only access"
            echo "Root can now only login directly from physical console"
            log_message "SUCCESS" "Configured securetty for console-only access"
            ;;
            
        3)
            echo ""
            echo "Keeping current configuration unchanged"
            log_message "INFO" "User chose to keep current configuration"
            ;;
            
        *)
            echo ""
            echo "Invalid choice. No changes made."
            log_message "WARNING" "Invalid choice - no changes made"
            ;;
    esac

    # Verify final configuration
    echo ""
    echo "Final Configuration:"
    echo "--------------------"
    
    if [ ! -s "$SECURETTY" ]; then
        echo "Status: COMPLIANT (Recommended)"
        echo "$SECURETTY is empty"
        echo "All direct root logins are disabled"
        echo "Administrators must use 'su' or 'sudo'"
        log_message "SUCCESS" "securetty configured - all direct root login disabled"
    else
        echo "Status: CONFIGURED"
        echo "$SECURETTY contains:"
        cat "$SECURETTY"
        echo ""
        echo "Root login restricted to listed terminals"
        log_message "INFO" "securetty configured with specific terminals"
    fi

    echo ""
    echo "CRITICAL WARNINGS:"
    echo "=================="
    echo "1. Ensure you have a regular user account with sudo access"
    echo "2. Test sudo access BEFORE logging out"
    echo "3. Keep an active root session open while testing"
    echo "4. Have physical/console access available for recovery"
    echo "5. SSH root login may still be controlled by SSH configuration"
    echo ""
    echo "To verify sudo access, run: sudo -l"
    echo "To configure sudo, edit: /etc/sudoers using visudo"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
