#!/bin/bash

SCRIPT_NAME="2.2.8_ftp_server.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.8 - Remove FTP Server"
    echo ""
    
    local packages=("vsftpd")
    local found=0
    
    for pkg in "${packages[@]}"; do
        if rpm -q "$pkg" &>/dev/null; then
            echo "$pkg is installed"
            found=1
            
            systemctl stop vsftpd 2>/dev/null
            systemctl disable vsftpd 2>/dev/null
            
            yum remove -y "$pkg" &>/dev/null
            log_message "SUCCESS" "Removed $pkg"
            echo "$pkg removed"
        fi
    done
    
    if [ $found -eq 0 ]; then
        echo "FTP server not installed"
        log_message "INFO" "FTP not present"
    fi
    
    echo "Status: COMPLIANT"
    echo ""
    
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
