#!/bin/bash

SCRIPT_NAME="5.5.4_default_user_shell_timeout.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
BASHRC="/etc/bashrc"
PROFILE="/etc/profile"
TIMEOUT_VALUE=900

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.5.4 - Ensure default user shell timeout is configured"
    echo ""

    CHANGES_MADE=0

    # Configure /etc/bashrc
    echo "Configuring shell timeout in $BASHRC..."
    echo ""

    if [ -f "$BASHRC" ]; then
        # Backup bashrc
        cp "$BASHRC" "$BACKUP_DIR/bashrc.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $BASHRC"

        # Check if TMOUT is already configured
        if grep -q "^[[:space:]]*TMOUT=" "$BASHRC" || grep -q "^[[:space:]]*readonly TMOUT" "$BASHRC" || grep -q "^[[:space:]]*export TMOUT" "$BASHRC"; then
            echo "TMOUT is already configured in $BASHRC"
            
            # Get current value
            CURRENT_TMOUT=$(grep -E "^[[:space:]]*(TMOUT=|readonly TMOUT=|export TMOUT=)" "$BASHRC" | head -1 | sed 's/.*TMOUT=//' | sed 's/[^0-9].*//')
            echo "Current TMOUT value: ${CURRENT_TMOUT:-NOT SET}"
            
            if [ -n "$CURRENT_TMOUT" ] && [ "$CURRENT_TMOUT" -le "$TIMEOUT_VALUE" ] && [ "$CURRENT_TMOUT" -gt 0 ]; then
                echo "TMOUT value is compliant (${CURRENT_TMOUT} seconds)"
                log_message "INFO" "bashrc TMOUT already compliant"
            else
                echo "Updating TMOUT to $TIMEOUT_VALUE seconds..."
                sed -i "s/^[[:space:]]*TMOUT=.*/TMOUT=$TIMEOUT_VALUE/" "$BASHRC"
                sed -i "s/^[[:space:]]*readonly TMOUT=.*/readonly TMOUT=$TIMEOUT_VALUE/" "$BASHRC"
                sed -i "s/^[[:space:]]*export TMOUT=.*/export TMOUT=$TIMEOUT_VALUE/" "$BASHRC"
                echo "Updated TMOUT in $BASHRC"
                log_message "SUCCESS" "Updated TMOUT in bashrc"
                CHANGES_MADE=1
            fi
        else
            echo "TMOUT not configured in $BASHRC"
            echo "Adding TMOUT configuration..."
            
            cat >> "$BASHRC" << EOF

# CIS 5.5.4 - Set shell timeout
TMOUT=$TIMEOUT_VALUE
readonly TMOUT
export TMOUT
EOF
            
            echo "Added TMOUT=$TIMEOUT_VALUE to $BASHRC"
            log_message "SUCCESS" "Added TMOUT to bashrc"
            CHANGES_MADE=1
        fi
    else
        echo "WARNING: $BASHRC not found"
        log_message "WARNING" "bashrc not found"
    fi

    echo ""

    # Configure /etc/profile
    echo "Configuring shell timeout in $PROFILE..."
    echo ""

    if [ -f "$PROFILE" ]; then
        # Backup profile
        cp "$PROFILE" "$BACKUP_DIR/profile.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $PROFILE"

        # Check if TMOUT is already configured
        if grep -q "^[[:space:]]*TMOUT=" "$PROFILE" || grep -q "^[[:space:]]*readonly TMOUT" "$PROFILE" || grep -q "^[[:space:]]*export TMOUT" "$PROFILE"; then
            echo "TMOUT is already configured in $PROFILE"
            
            # Get current value
            CURRENT_TMOUT=$(grep -E "^[[:space:]]*(TMOUT=|readonly TMOUT=|export TMOUT=)" "$PROFILE" | head -1 | sed 's/.*TMOUT=//' | sed 's/[^0-9].*//')
            echo "Current TMOUT value: ${CURRENT_TMOUT:-NOT SET}"
            
            if [ -n "$CURRENT_TMOUT" ] && [ "$CURRENT_TMOUT" -le "$TIMEOUT_VALUE" ] && [ "$CURRENT_TMOUT" -gt 0 ]; then
                echo "TMOUT value is compliant (${CURRENT_TMOUT} seconds)"
                log_message "INFO" "profile TMOUT already compliant"
            else
                echo "Updating TMOUT to $TIMEOUT_VALUE seconds..."
                sed -i "s/^[[:space:]]*TMOUT=.*/TMOUT=$TIMEOUT_VALUE/" "$PROFILE"
                sed -i "s/^[[:space:]]*readonly TMOUT=.*/readonly TMOUT=$TIMEOUT_VALUE/" "$PROFILE"
                sed -i "s/^[[:space:]]*export TMOUT=.*/export TMOUT=$TIMEOUT_VALUE/" "$PROFILE"
                echo "Updated TMOUT in $PROFILE"
                log_message "SUCCESS" "Updated TMOUT in profile"
                CHANGES_MADE=1
            fi
        else
            echo "TMOUT not configured in $PROFILE"
            echo "Adding TMOUT configuration..."
            
            cat >> "$PROFILE" << EOF

# CIS 5.5.4 - Set shell timeout
TMOUT=$TIMEOUT_VALUE
readonly TMOUT
export TMOUT
EOF
            
            echo "Added TMOUT=$TIMEOUT_VALUE to $PROFILE"
            log_message "SUCCESS" "Added TMOUT to profile"
            CHANGES_MADE=1
        fi
    else
        echo "ERROR: $PROFILE not found"
        log_message "ERROR" "profile not found"
        return 1
    fi

    # Verify configuration
    echo ""
    echo "Verification:"
    echo "-------------"

    if [ -f "$BASHRC" ]; then
        BASHRC_TMOUT=$(grep -E "^[[:space:]]*(TMOUT=|readonly TMOUT=|export TMOUT=)" "$BASHRC" | head -1 | sed 's/.*TMOUT=//' | sed 's/[^0-9].*//')
        echo "bashrc TMOUT: ${BASHRC_TMOUT:-NOT SET} seconds"
    fi

    if [ -f "$PROFILE" ]; then
        PROFILE_TMOUT=$(grep -E "^[[:space:]]*(TMOUT=|readonly TMOUT=|export TMOUT=)" "$PROFILE" | head -1 | sed 's/.*TMOUT=//' | sed 's/[^0-9].*//')
        echo "profile TMOUT: ${PROFILE_TMOUT:-NOT SET} seconds"
    fi

    echo ""

    # Check compliance
    COMPLIANT=1
    if [ -z "$BASHRC_TMOUT" ] || [ "$BASHRC_TMOUT" -gt "$TIMEOUT_VALUE" ] || [ "$BASHRC_TMOUT" -eq 0 ]; then
        COMPLIANT=0
    fi
    if [ -z "$PROFILE_TMOUT" ] || [ "$PROFILE_TMOUT" -gt "$TIMEOUT_VALUE" ] || [ "$PROFILE_TMOUT" -eq 0 ]; then
        COMPLIANT=0
    fi

    if [ $COMPLIANT -eq 1 ]; then
        echo "Status: COMPLIANT"
        echo "Shell timeout is configured (${TIMEOUT_VALUE} seconds = $((TIMEOUT_VALUE/60)) minutes)"
        log_message "SUCCESS" "Shell timeout configured properly"
    else
        echo "Status: NON-COMPLIANT"
        echo "Shell timeout is not properly configured"
        log_message "ERROR" "Shell timeout configuration incomplete"
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. Changes take effect for NEW shell sessions only"
    echo "2. Existing sessions will not be affected"
    echo "3. Users can override TMOUT in their ~/.bashrc (unless readonly)"
    echo "4. readonly TMOUT prevents users from changing the value"
    echo "5. Shell will automatically logout after $TIMEOUT_VALUE seconds of inactivity"
    echo ""

    if [ $CHANGES_MADE -eq 1 ]; then
        echo "Changes have been applied. Users must start new shell sessions."
        log_message "SUCCESS" "Remediation completed with changes"
    else
        echo "No changes were necessary."
        log_message "SUCCESS" "System already compliant"
    fi

    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
