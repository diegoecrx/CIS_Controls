#!/bin/bash

SCRIPT_NAME="3.2.2_packet_redirect_sending_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.2.2 - Disable Packet Redirect Sending"
    echo ""
    
    # Create sysctl config
    cat > /etc/sysctl.d/60-disable-send-redirects.conf <<EOF
# Disable sending of ICMP redirects
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
EOF
    
    # Apply immediately
    sysctl -w net.ipv4.conf.all.send_redirects=0 &>/dev/null
    sysctl -w net.ipv4.conf.default.send_redirects=0 &>/dev/null
    
    log_message "SUCCESS" "ICMP redirect sending disabled"
    echo "Send redirects disabled on all interfaces"
    echo "Send redirects disabled for default"
    echo "Status: COMPLIANT"
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
