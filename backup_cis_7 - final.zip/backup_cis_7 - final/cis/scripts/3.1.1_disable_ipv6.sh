#!/bin/bash

SCRIPT_NAME="3.1.1_disable_ipv6.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.1.1 - Disable IPv6"
    echo ""
    
    # Backup grub config
    cp /etc/default/grub "$BACKUP_DIR/grub.backup.$(date +%s)" 2>/dev/null
    
    # Add IPv6 disable to GRUB
    if ! grep -q "ipv6.disable=1" /etc/default/grub; then
        sed -i 's/GRUB_CMDLINE_LINUX="\(.*\)"/GRUB_CMDLINE_LINUX="\1 ipv6.disable=1"/' /etc/default/grub
        grub2-mkconfig -o /boot/grub2/grub.cfg &>/dev/null
        log_message "SUCCESS" "Added ipv6.disable=1 to GRUB"
        echo "IPv6 disabled in GRUB configuration"
    else
        echo "IPv6 already disabled in GRUB"
    fi
    
    # Disable via sysctl
    cat > /etc/sysctl.d/60-disable-ipv6.conf <<EOF
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
EOF
    
    sysctl -w net.ipv6.conf.all.disable_ipv6=1 &>/dev/null
    sysctl -w net.ipv6.conf.default.disable_ipv6=1 &>/dev/null
    
    echo "IPv6 disabled via sysctl"
    echo "Status: COMPLIANT (reboot required for GRUB changes)"
    log_message "SUCCESS" "IPv6 disabled"
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
