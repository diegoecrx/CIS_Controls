#!/bin/bash

SCRIPT_NAME="2.2.7_dns_server.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.7 - Remove DNS Server"
    echo ""
    
    if ! rpm -q bind &>/dev/null; then
        echo "BIND DNS server not installed"
        echo "Status: COMPLIANT"
        log_message "INFO" "BIND not present"
    else
        echo "BIND DNS server is installed"
        
        systemctl stop named 2>/dev/null
        systemctl disable named 2>/dev/null
        
        yum remove -y bind &>/dev/null
        log_message "SUCCESS" "Removed BIND"
        
        echo "BIND DNS server removed"
        echo "Status: COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
