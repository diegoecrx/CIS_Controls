#!/bin/bash

SCRIPT_NAME="6.2.13_users_home_directories_permissions_750_more_restrictive.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_home_permissions_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.13 - Ensure users' home directories permissions are 750 or more restrictive"
    echo ""

    log_message "INFO" "Starting home directory permissions audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.13 Home Directory Permissions Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies home directories with permissions more permissive than 750.

EOF

    echo "Checking home directory permissions..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    ISSUES_FOUND=0
    CHECKED=0
    COMPLIANT=0

    # Target permissions: 750 (rwxr-x---)
    TARGET_PERMS_DEC=$((8#750))

    # Read /etc/passwd and check each user's home directory permissions
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Skip system users with UID < 1000 (except root)
        if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
            continue
        fi
        
        # Skip if home directory doesn't exist
        if [ ! -d "$homedir" ]; then
            continue
        fi
        
        ((CHECKED++))
        
        # Get current permissions
        CURRENT_PERMS=$(stat -c '%a' "$homedir" 2>/dev/null)
        CURRENT_PERMS_DEC=$((8#$CURRENT_PERMS))
        
        # Check if permissions are more permissive than 750
        # We need to check each permission bit (owner, group, others)
        # More permissive means: group has write, or others have any permission
        
        # Extract permission components
        OWNER_PERMS=$((CURRENT_PERMS_DEC / 64))
        GROUP_PERMS=$(((CURRENT_PERMS_DEC / 8) % 8))
        OTHER_PERMS=$((CURRENT_PERMS_DEC % 8))
        
        # Check if non-compliant (group write or others any)
        if [ $GROUP_PERMS -ge 6 ] || [ $OTHER_PERMS -gt 0 ]; then
            echo "[NON-COMPLIANT] $username: $homedir (current: $CURRENT_PERMS)" | tee -a "$AUDIT_REPORT"
            ((ISSUES_FOUND++))
        else
            ((COMPLIANT++))
        fi
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Home directories checked: $CHECKED
Compliant: $COMPLIANT
Non-compliant (too permissive): $ISSUES_FOUND

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Home directories checked: $CHECKED"
    echo "Compliant: $COMPLIANT"
    echo "Non-compliant: $ISSUES_FOUND"
    echo ""

    if [ $ISSUES_FOUND -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "All home directories have appropriate permissions"
        log_message "SUCCESS" "All home directories properly secured"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT"
        echo "$ISSUES_FOUND home director(ies) have overly permissive permissions"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $ISSUES_FOUND directories with weak permissions"
    fi

    # Ask if user wants to fix permissions
    echo ""
    echo "Fix overly permissive home directory permissions?"
    echo ""
    read -p "Set permissions to 750 for non-compliant directories? [y/N]: " CONFIRM

    if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
        echo ""
        echo "Fixing home directory permissions..."
        echo ""
        
        FIXED=0
        FAILED=0
        
        # Re-read passwd and fix permissions
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            # Skip system users
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            # Skip if doesn't exist
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            CURRENT_PERMS=$(stat -c '%a' "$homedir" 2>/dev/null)
            CURRENT_PERMS_DEC=$((8#$CURRENT_PERMS))
            
            # Extract components
            GROUP_PERMS=$(((CURRENT_PERMS_DEC / 8) % 8))
            OTHER_PERMS=$((CURRENT_PERMS_DEC % 8))
            
            # Fix if non-compliant
            if [ $GROUP_PERMS -ge 6 ] || [ $OTHER_PERMS -gt 0 ]; then
                echo "Fixing: $homedir (was $CURRENT_PERMS)"
                
                if chmod 750 "$homedir" 2>/dev/null; then
                    NEW_PERMS=$(stat -c '%a' "$homedir")
                    echo "  Changed to: $NEW_PERMS"
                    log_message "SUCCESS" "Fixed permissions for $username: $homedir"
                    ((FIXED++))
                else
                    echo "  ERROR: Failed to change permissions"
                    log_message "ERROR" "Failed to fix permissions for $username: $homedir"
                    ((FAILED++))
                fi
            fi
        done < /etc/passwd
        
        echo ""
        echo "Remediation Summary:"
        echo "  Fixed: $FIXED"
        echo "  Failed: $FAILED"
        log_message "SUCCESS" "Fixed $FIXED home directories, $FAILED failures"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "To manually fix permissions:"
        echo "  chmod 750 /path/to/home/directory"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. Permissions 750 (rwxr-x---) mean:"
    echo "   - Owner: full access (read, write, execute)"
    echo "   - Group: read and execute only"
    echo "   - Others: no access"
    echo "2. This prevents unauthorized users from accessing home directories"
    echo "3. Group members can access if they share the user's primary group"
    echo "4. More restrictive permissions (700) remove group access entirely"
    echo "5. Some applications may require specific permissions - test thoroughly"
    echo ""

    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
