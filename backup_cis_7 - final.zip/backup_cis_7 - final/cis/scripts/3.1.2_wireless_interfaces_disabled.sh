#!/bin/bash

SCRIPT_NAME="3.1.2_wireless_interfaces_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.1.2 - Disable Wireless Interfaces"
    echo ""
    
    # Check for wireless interfaces
    wireless_interfaces=$(nmcli device status | grep wifi | awk '{print $1}')
    
    if [ -z "$wireless_interfaces" ]; then
        echo "No wireless interfaces found"
        echo "Status: COMPLIANT"
        log_message "INFO" "No wireless interfaces present"
    else
        echo "Wireless interfaces found:"
        echo "$wireless_interfaces"
        echo ""
        
        # Disable each wireless interface
        for iface in $wireless_interfaces; do
            nmcli radio wifi off 2>/dev/null
            ip link set "$iface" down 2>/dev/null
            echo "Disabled interface: $iface"
            log_message "SUCCESS" "Disabled $iface"
        done
        
        # Blacklist wireless drivers
        echo "blacklist iwlwifi" >> /etc/modprobe.d/wireless-blacklist.conf
        echo "blacklist ath9k" >> /etc/modprobe.d/wireless-blacklist.conf
        echo "blacklist ath5k" >> /etc/modprobe.d/wireless-blacklist.conf
        echo "blacklist rtw88" >> /etc/modprobe.d/wireless-blacklist.conf
        
        log_message "SUCCESS" "Blacklisted wireless drivers"
        echo "Wireless drivers blacklisted"
        echo "Status: COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
