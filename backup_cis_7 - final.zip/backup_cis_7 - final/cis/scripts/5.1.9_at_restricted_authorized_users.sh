#!/bin/bash

SCRIPT_NAME="5.1.9_at_restricted_authorized_users.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AT_ALLOW="/etc/at.allow"
AT_DENY="/etc/at.deny"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.1.9 - Ensure at is restricted to authorized users"
    echo ""

    # Check if at package is installed
    if ! rpm -q at >/dev/null 2>&1; then
        echo "at package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "at not installed - control not applicable"
        return 0
    fi

    echo "at package is installed"
    echo ""

    CHANGES_MADE=0

    # Check if at.deny exists and remove it
    if [ -f "$AT_DENY" ]; then
        echo "Found $AT_DENY - backing up and removing..."
        cp "$AT_DENY" "$BACKUP_DIR/at.deny.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        
        if rm -f "$AT_DENY" 2>/dev/null; then
            echo "Removed $AT_DENY"
            log_message "SUCCESS" "Removed at.deny file"
            CHANGES_MADE=1
        else
            echo "WARNING: Failed to remove $AT_DENY"
            log_message "WARNING" "Failed to remove at.deny"
        fi
    else
        echo "$AT_DENY does not exist (correct)"
    fi

    echo ""

    # Check if at.allow exists
    if [ ! -f "$AT_ALLOW" ]; then
        echo "Creating $AT_ALLOW..."
        
        # Create at.allow with root as default authorized user
        echo "root" > "$AT_ALLOW" 2>/dev/null
        
        if [ $? -eq 0 ]; then
            echo "Created $AT_ALLOW with root as authorized user"
            log_message "SUCCESS" "Created at.allow file"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to create $AT_ALLOW"
            log_message "ERROR" "Failed to create at.allow"
            return 1
        fi
    else
        echo "$AT_ALLOW already exists"
        
        # Display current authorized users
        echo ""
        echo "Current authorized users:"
        cat "$AT_ALLOW" 2>/dev/null | while read user; do
            echo "  - $user"
        done
    fi

    echo ""

    # Get current permissions and ownership of at.allow
    if [ -f "$AT_ALLOW" ]; then
        CURRENT_PERMS=$(stat -c '%a' "$AT_ALLOW" 2>/dev/null)
        CURRENT_OWNER=$(stat -c '%U' "$AT_ALLOW" 2>/dev/null)
        CURRENT_GROUP=$(stat -c '%G' "$AT_ALLOW" 2>/dev/null)

        echo "Current $AT_ALLOW configuration:"
        echo "  Permissions: $CURRENT_PERMS"
        echo "  Owner: $CURRENT_OWNER"
        echo "  Group: $CURRENT_GROUP"
        echo ""

        # Set correct ownership (root:root)
        if [ "$CURRENT_OWNER" != "root" ] || [ "$CURRENT_GROUP" != "root" ]; then
            echo "Setting ownership to root:root..."
            
            if chown root:root "$AT_ALLOW" 2>/dev/null; then
                echo "Ownership changed to root:root"
                log_message "SUCCESS" "Changed at.allow ownership to root:root"
                CHANGES_MADE=1
            else
                echo "ERROR: Failed to change ownership"
                log_message "ERROR" "Failed to change at.allow ownership"
                return 1
            fi
        else
            echo "Ownership is correct (root:root)"
        fi

        # Set correct permissions (0600)
        if [ "$CURRENT_PERMS" != "600" ]; then
            echo "Setting permissions to 0600..."
            
            if chmod 0600 "$AT_ALLOW" 2>/dev/null; then
                echo "Permissions changed to 0600"
                log_message "SUCCESS" "Changed at.allow permissions to 0600"
                CHANGES_MADE=1
            else
                echo "ERROR: Failed to change permissions"
                log_message "ERROR" "Failed to change at.allow permissions"
                return 1
            fi
        else
            echo "Permissions are correct (0600)"
        fi
    fi

    # Verify final configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    if [ -f "$AT_ALLOW" ]; then
        NEW_PERMS=$(stat -c '%a' "$AT_ALLOW" 2>/dev/null)
        NEW_OWNER=$(stat -c '%U' "$AT_ALLOW" 2>/dev/null)
        NEW_GROUP=$(stat -c '%G' "$AT_ALLOW" 2>/dev/null)
        
        echo "at.allow: EXISTS"
        echo "  Permissions: $NEW_PERMS"
        echo "  Owner: $NEW_OWNER"
        echo "  Group: $NEW_GROUP"
    else
        echo "at.allow: MISSING (ERROR)"
    fi
    
    if [ -f "$AT_DENY" ]; then
        echo "at.deny: EXISTS (should not exist)"
    else
        echo "at.deny: REMOVED (correct)"
    fi

    echo ""

    # Final compliance check
    if [ -f "$AT_ALLOW" ] && [ ! -f "$AT_DENY" ]; then
        FINAL_PERMS=$(stat -c '%a' "$AT_ALLOW" 2>/dev/null)
        FINAL_OWNER=$(stat -c '%U' "$AT_ALLOW" 2>/dev/null)
        FINAL_GROUP=$(stat -c '%G' "$AT_ALLOW" 2>/dev/null)
        
        if [ "$FINAL_PERMS" = "600" ] && [ "$FINAL_OWNER" = "root" ] && [ "$FINAL_GROUP" = "root" ]; then
            echo "Status: COMPLIANT"
            echo "at command is restricted to authorized users only"
            
            if [ $CHANGES_MADE -eq 1 ]; then
                log_message "SUCCESS" "Remediation applied successfully"
            else
                log_message "SUCCESS" "System was already compliant"
            fi
        else
            echo "Status: PARTIAL COMPLIANCE"
            echo "at.allow exists but has incorrect permissions or ownership"
            log_message "WARNING" "Partial compliance - check permissions"
        fi
    else
        echo "Status: NON-COMPLIANT"
        echo "Configuration is not correct"
        log_message "ERROR" "Failed to achieve compliance"
        return 1
    fi

    echo ""
    echo "NOTE: To add authorized users to at, edit $AT_ALLOW and add one username per line"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
