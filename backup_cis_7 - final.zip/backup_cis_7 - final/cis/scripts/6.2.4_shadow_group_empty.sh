#!/bin/bash

SCRIPT_NAME="6.2.4_shadow_group_empty.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_shadow_group_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.4 - Ensure shadow group is empty"
    echo ""

    log_message "INFO" "Starting shadow group audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.4 Shadow Group Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies users assigned to the shadow group.

EOF

    echo "Checking shadow group membership..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    # Get shadow group GID
    SHADOW_GID=$(getent group shadow | cut -d: -f3)
    
    if [ -z "$SHADOW_GID" ]; then
        echo "Shadow group does not exist on this system"
        echo "Status: NOT APPLICABLE"
        log_message "INFO" "Shadow group not found - control not applicable"
        return 0
    fi

    echo "Shadow group found (GID: $SHADOW_GID)" | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    # Get shadow group line from /etc/group
    SHADOW_GROUP_LINE=$(getent group shadow)
    
    # Extract members (4th field, colon-separated)
    SHADOW_MEMBERS=$(echo "$SHADOW_GROUP_LINE" | cut -d: -f4)

    # Count members
    if [ -z "$SHADOW_MEMBERS" ]; then
        MEMBER_COUNT=0
    else
        MEMBER_COUNT=$(echo "$SHADOW_MEMBERS" | tr ',' '\n' | wc -l)
    fi

    # Also check for users with shadow as their primary group
    PRIMARY_GROUP_USERS=0
    PRIMARY_GROUP_USER_LIST=""
    
    while IFS=: read -r username password uid gid comment homedir shell; do
        [ -z "$username" ] && continue
        
        if [ "$gid" = "$SHADOW_GID" ]; then
            echo "[PRIMARY GROUP] User: $username (UID: $uid) has shadow as primary group" | tee -a "$AUDIT_REPORT"
            PRIMARY_GROUP_USER_LIST="$PRIMARY_GROUP_USER_LIST $username"
            ((PRIMARY_GROUP_USERS++))
        fi
    done < /etc/passwd

    # Display members
    if [ $MEMBER_COUNT -gt 0 ]; then
        echo "Shadow group members (supplementary):" | tee -a "$AUDIT_REPORT"
        echo "$SHADOW_MEMBERS" | tr ',' '\n' | while read -r member; do
            [ -z "$member" ] && continue
            USER_INFO=$(getent passwd "$member")
            if [ -n "$USER_INFO" ]; then
                UID=$(echo "$USER_INFO" | cut -d: -f3)
                echo "  - $member (UID: $UID)" | tee -a "$AUDIT_REPORT"
            else
                echo "  - $member (user not found in passwd)" | tee -a "$AUDIT_REPORT"
            fi
        done
    fi

    TOTAL_USERS=$((MEMBER_COUNT + PRIMARY_GROUP_USERS))

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Shadow group GID: $SHADOW_GID
Supplementary members: $MEMBER_COUNT
Primary group members: $PRIMARY_GROUP_USERS
Total users in shadow group: $TOTAL_USERS

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Shadow group GID: $SHADOW_GID"
    echo "Supplementary members: $MEMBER_COUNT"
    echo "Primary group members: $PRIMARY_GROUP_USERS"
    echo "Total users: $TOTAL_USERS"
    echo ""

    if [ $TOTAL_USERS -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "Shadow group is empty"
        log_message "SUCCESS" "Shadow group is empty"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT"
        echo "$TOTAL_USERS user(s) assigned to shadow group"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $TOTAL_USERS users in shadow group"
    fi

    # Ask if user wants to remove users from shadow group
    echo ""
    echo "IMPORTANT: The shadow group provides read access to /etc/shadow"
    echo "Users should NOT be in this group unless absolutely necessary."
    echo ""
    echo "Remove users from shadow group?"
    echo ""
    read -p "Remove all users from shadow group? [y/N]: " CONFIRM

    if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
        echo ""
        echo "Removing users from shadow group..."
        echo ""
        
        REMOVED_SUPPLEMENTARY=0
        FIXED_PRIMARY=0
        FAILED=0
        
        # Remove supplementary group members
        if [ $MEMBER_COUNT -gt 0 ]; then
            echo "$SHADOW_MEMBERS" | tr ',' '\n' | while read -r member; do
                [ -z "$member" ] && continue
                
                echo "Removing $member from shadow group (supplementary)..."
                if gpasswd -d "$member" shadow 2>/dev/null; then
                    echo "  Success"
                    log_message "SUCCESS" "Removed $member from shadow group"
                    ((REMOVED_SUPPLEMENTARY++))
                else
                    echo "  ERROR: Failed to remove"
                    log_message "ERROR" "Failed to remove $member from shadow group"
                    ((FAILED++))
                fi
            done
        fi
        
        # Fix users with shadow as primary group
        if [ $PRIMARY_GROUP_USERS -gt 0 ]; then
            for username in $PRIMARY_GROUP_USER_LIST; do
                [ -z "$username" ] && continue
                
                echo "Changing primary group for $username (currently shadow)..."
                
                # Get user's UID
                USER_UID=$(id -u "$username" 2>/dev/null)
                
                if [ -z "$USER_UID" ]; then
                    echo "  ERROR: User not found"
                    ((FAILED++))
                    continue
                fi
                
                # Determine appropriate new primary group
                # For regular users (UID >= 1000), create/use user private group
                if [ "$USER_UID" -ge 1000 ]; then
                    # Check if user private group exists
                    if getent group "$username" > /dev/null 2>&1; then
                        NEW_GID=$(getent group "$username" | cut -d: -f3)
                    else
                        # Create user private group
                        echo "  Creating user private group: $username"
                        groupadd -g "$USER_UID" "$username" 2>/dev/null
                        NEW_GID=$USER_UID
                    fi
                else
                    # For system users, use 'users' or 'nogroup'
                    if getent group users > /dev/null 2>&1; then
                        NEW_GID=$(getent group users | cut -d: -f3)
                        NEW_GROUP_NAME="users"
                    elif getent group nogroup > /dev/null 2>&1; then
                        NEW_GID=$(getent group nogroup | cut -d: -f3)
                        NEW_GROUP_NAME="nogroup"
                    else
                        echo "  ERROR: No suitable fallback group found"
                        ((FAILED++))
                        continue
                    fi
                fi
                
                # Change primary group
                if usermod -g "$NEW_GID" "$username" 2>/dev/null; then
                    echo "  Changed primary group to GID $NEW_GID"
                    log_message "SUCCESS" "Changed primary group for $username from shadow to GID $NEW_GID"
                    ((FIXED_PRIMARY++))
                else
                    echo "  ERROR: Failed to change primary group"
                    log_message "ERROR" "Failed to change primary group for $username"
                    ((FAILED++))
                fi
            done
        fi
        
        echo ""
        echo "Remediation Summary:"
        echo "  Removed from supplementary: $REMOVED_SUPPLEMENTARY"
        echo "  Fixed primary group: $FIXED_PRIMARY"
        echo "  Failed: $FAILED"
        log_message "SUCCESS" "Removed $REMOVED_SUPPLEMENTARY supplementary and fixed $FIXED_PRIMARY primary group assignments"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "To manually remove users from shadow group:"
        echo "  gpasswd -d username shadow"
        echo ""
        echo "To change a user's primary group:"
        echo "  usermod -g newgroup username"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. The shadow group provides read access to /etc/shadow"
    echo "2. Only system daemons should use this group (via GID, not membership)"
    echo "3. Regular users should NEVER be in the shadow group"
    echo "4. Access to /etc/shadow exposes password hashes"
    echo "5. Users removed from shadow group retain normal system access"
    echo "6. Primary group changes are logged and reversible"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
