#!/bin/bash

SCRIPT_NAME="6.2.14_users_dot_files_group_world_writable.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_dotfiles_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.14 - Ensure users' dot files are not group or world writable"
    echo ""

    log_message "INFO" "Starting dot files audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.14 Dot Files Permissions Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies dot files that are group or world writable.

EOF

    echo "Checking dot files permissions..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    ISSUES_FOUND=0
    USERS_CHECKED=0
    FILES_CHECKED=0

    # Read /etc/passwd and check each user's dot files
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Skip system users with UID < 1000 (except root)
        if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
            continue
        fi
        
        # Skip if home directory doesn't exist
        if [ ! -d "$homedir" ]; then
            continue
        fi
        
        ((USERS_CHECKED++))
        
        # Find all dot files (hidden files starting with .)
        # Exclude . and .. directories
        find "$homedir" -maxdepth 1 -name ".*" -type f 2>/dev/null | while read -r dotfile; do
            ((FILES_CHECKED++))
            
            # Get current permissions
            CURRENT_PERMS=$(stat -c '%a' "$dotfile" 2>/dev/null)
            
            if [ -z "$CURRENT_PERMS" ]; then
                continue
            fi
            
            CURRENT_PERMS_DEC=$((8#$CURRENT_PERMS))
            
            # Extract permission components
            GROUP_PERMS=$(((CURRENT_PERMS_DEC / 8) % 8))
            OTHER_PERMS=$((CURRENT_PERMS_DEC % 8))
            
            # Check if group or world writable (write bit set)
            GROUP_WRITABLE=$((GROUP_PERMS & 2))
            WORLD_WRITABLE=$((OTHER_PERMS & 2))
            
            if [ $GROUP_WRITABLE -ne 0 ] || [ $WORLD_WRITABLE -ne 0 ]; then
                FILENAME=$(basename "$dotfile")
                echo "[WRITABLE] $username: $FILENAME ($CURRENT_PERMS) - Full path: $dotfile" | tee -a "$AUDIT_REPORT"
                ((ISSUES_FOUND++))
            fi
        done
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Users checked: $USERS_CHECKED
Writable dot files found: $ISSUES_FOUND

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Users checked: $USERS_CHECKED"
    echo "Writable dot files found: $ISSUES_FOUND"
    echo ""

    if [ $ISSUES_FOUND -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "No group or world writable dot files found"
        log_message "SUCCESS" "All dot files properly secured"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT"
        echo "$ISSUES_FOUND dot file(s) are group or world writable"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $ISSUES_FOUND writable dot files"
    fi

    # Ask if user wants to fix permissions
    echo ""
    echo "Fix writable dot files permissions?"
    echo ""
    read -p "Remove group and world write permissions? [y/N]: " CONFIRM

    if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
        echo ""
        echo "Fixing dot files permissions..."
        echo ""
        
        FIXED=0
        FAILED=0
        
        # Re-scan and fix permissions
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            # Skip system users
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            # Skip if doesn't exist
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            # Find and fix writable dot files
            find "$homedir" -maxdepth 1 -name ".*" -type f 2>/dev/null | while read -r dotfile; do
                CURRENT_PERMS=$(stat -c '%a' "$dotfile" 2>/dev/null)
                
                if [ -z "$CURRENT_PERMS" ]; then
                    continue
                fi
                
                CURRENT_PERMS_DEC=$((8#$CURRENT_PERMS))
                GROUP_PERMS=$(((CURRENT_PERMS_DEC / 8) % 8))
                OTHER_PERMS=$((CURRENT_PERMS_DEC % 8))
                GROUP_WRITABLE=$((GROUP_PERMS & 2))
                WORLD_WRITABLE=$((OTHER_PERMS & 2))
                
                if [ $GROUP_WRITABLE -ne 0 ] || [ $WORLD_WRITABLE -ne 0 ]; then
                    echo "Fixing: $dotfile (was $CURRENT_PERMS)"
                    
                    # Remove group and world write permissions using go-w
                    if chmod go-w "$dotfile" 2>/dev/null; then
                        NEW_PERMS=$(stat -c '%a' "$dotfile")
                        echo "  Changed to: $NEW_PERMS"
                        log_message "SUCCESS" "Fixed permissions for $dotfile"
                        ((FIXED++))
                    else
                        echo "  ERROR: Failed to change permissions"
                        log_message "ERROR" "Failed to fix permissions for $dotfile"
                        ((FAILED++))
                    fi
                fi
            done
        done < /etc/passwd
        
        echo ""
        echo "Remediation Summary:"
        echo "  Fixed: $FIXED"
        echo "  Failed: $FAILED"
        log_message "SUCCESS" "Fixed $FIXED dot files, $FAILED failures"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "To manually fix permissions:"
        echo "  chmod go-w /path/to/.dotfile"
        echo "  or"
        echo "  chmod 600 /path/to/.dotfile (most restrictive)"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. Dot files (.bashrc, .profile, .ssh/*, etc.) control user environment"
    echo "2. Group/world writable dot files allow unauthorized modification"
    echo "3. Attackers can inject malicious commands into writable dot files"
    echo "4. This can lead to privilege escalation or account compromise"
    echo "5. Recommended permissions: 600 (owner read/write only)"
    echo "6. Some dot files may need 644 if they're referenced by other processes"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
