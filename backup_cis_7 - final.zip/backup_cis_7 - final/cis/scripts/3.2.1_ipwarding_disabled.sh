#!/bin/bash

SCRIPT_NAME="3.2.1_ipforwarding_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.2.1 - Disable IP Forwarding"
    echo ""
    
    # Create sysctl config
    cat > /etc/sysctl.d/60-disable-ip-forwarding.conf <<EOF
# Disable IPv4 forwarding
net.ipv4.ip_forward = 0

# Disable IPv6 forwarding
net.ipv6.conf.all.forwarding = 0
EOF
    
    # Apply immediately
    sysctl -w net.ipv4.ip_forward=0 &>/dev/null
    sysctl -w net.ipv6.conf.all.forwarding=0 &>/dev/null
    
    log_message "SUCCESS" "IP forwarding disabled"
    echo "IPv4 forwarding: disabled"
    echo "IPv6 forwarding: disabled"
    echo "Status: COMPLIANT"
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
