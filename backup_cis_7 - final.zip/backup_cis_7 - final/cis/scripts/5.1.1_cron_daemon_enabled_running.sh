#!/bin/bash

SCRIPT_NAME="5.1.1_cron_daemon_enabled_running.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.1.1 - Ensure cron daemon is enabled and running"
    echo ""

    # Check if cronie package is installed
    if ! rpm -q cronie >/dev/null 2>&1; then
        echo "cronie package is not installed"
        echo "Installing cronie package..."
        
        if yum install -y cronie >/dev/null 2>&1; then
            echo "cronie package installed successfully"
            log_message "SUCCESS" "Installed cronie package"
        else
            echo "ERROR: Failed to install cronie package"
            log_message "ERROR" "Failed to install cronie package"
            return 1
        fi
    else
        echo "cronie package is already installed"
    fi

    echo ""
    echo "Checking cron daemon status..."
    echo ""

    # Check if crond service is enabled
    if systemctl is-enabled crond >/dev/null 2>&1; then
        echo "crond service is already enabled"
        log_message "INFO" "crond service already enabled"
    else
        echo "crond service is not enabled - enabling now..."
        
        if systemctl enable crond >/dev/null 2>&1; then
            echo "crond service enabled successfully"
            log_message "SUCCESS" "Enabled crond service"
        else
            echo "ERROR: Failed to enable crond service"
            log_message "ERROR" "Failed to enable crond service"
            return 1
        fi
    fi

    # Check if crond service is running
    if systemctl is-active crond >/dev/null 2>&1; then
        echo "crond service is already running"
        log_message "INFO" "crond service already running"
    else
        echo "crond service is not running - starting now..."
        
        if systemctl start crond >/dev/null 2>&1; then
            echo "crond service started successfully"
            log_message "SUCCESS" "Started crond service"
        else
            echo "ERROR: Failed to start crond service"
            log_message "ERROR" "Failed to start crond service"
            return 1
        fi
    fi

    echo ""
    echo "Verification:"
    echo "-------------"
    
    # Display service status
    ENABLED_STATUS=$(systemctl is-enabled crond 2>/dev/null)
    ACTIVE_STATUS=$(systemctl is-active crond 2>/dev/null)
    
    echo "Service enabled: $ENABLED_STATUS"
    echo "Service active: $ACTIVE_STATUS"
    
    # Additional verification - check if crond process is running
    if pgrep -x crond >/dev/null 2>&1; then
        echo "crond process is running"
        CROND_PID=$(pgrep -x crond)
        echo "Process ID: $CROND_PID"
    else
        echo "WARNING: crond process not found"
        log_message "WARNING" "crond process not found"
    fi

    echo ""
    
    # Final compliance check
    if [ "$ENABLED_STATUS" = "enabled" ] && [ "$ACTIVE_STATUS" = "active" ]; then
        echo "Status: COMPLIANT"
        echo "cron daemon is enabled and running"
        log_message "SUCCESS" "cron daemon is enabled and running"
    else
        echo "Status: NON-COMPLIANT"
        echo "cron daemon is not properly configured"
        log_message "ERROR" "cron daemon not properly configured"
        return 1
    fi

    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
