#!/bin/bash

SCRIPT_NAME="3.5.3.2.5_iptables_rules_saved.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.3.2.5 - Ensure iptables rules are saved"
    echo ""
    
    # Check if iptables-services is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "iptables-services not installed"
        log_message "ERROR" "iptables-services not installed"
        echo "Status: NOT APPLICABLE"
        return 1
    fi
    
    # Save current IPv4 iptables rules
    if iptables-save > /etc/sysconfig/iptables 2>/dev/null; then
        echo "IPv4 iptables rules saved to /etc/sysconfig/iptables"
        log_message "SUCCESS" "IPv4 iptables rules saved"
    else
        echo "Failed to save IPv4 iptables rules"
        log_message "ERROR" "Failed to save IPv4 rules"
    fi
    
    # Save current IPv6 ip6tables rules
    if ip6tables-save > /etc/sysconfig/ip6tables 2>/dev/null; then
        echo "IPv6 ip6tables rules saved to /etc/sysconfig/ip6tables"
        log_message "SUCCESS" "IPv6 ip6tables rules saved"
    else
        echo "Failed to save IPv6 ip6tables rules"
        log_message "ERROR" "Failed to save IPv6 rules"
    fi
    
    # Verify files exist
    if [ -f /etc/sysconfig/iptables ] && [ -f /etc/sysconfig/ip6tables ]; then
        echo "Both rule files exist and are saved"
        echo "Status: COMPLIANT"
    else
        echo "One or more rule files missing"
        echo "Status: REVIEW REQUIRED"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
