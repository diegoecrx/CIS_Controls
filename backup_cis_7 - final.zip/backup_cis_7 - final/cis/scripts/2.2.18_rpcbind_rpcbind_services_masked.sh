#!/bin/bash

SCRIPT_NAME="2.2.18_rpcbind_rpcbind_services_masked.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.18 - Mask rpcbind Services"
    echo ""
    
    local services=("rpcbind.service" "rpcbind.socket")
    local masked_count=0
    
    for svc in "${services[@]}"; do
        if systemctl list-unit-files | grep -q "$svc"; then
            systemctl stop "$svc" 2>/dev/null
            systemctl mask "$svc" 2>/dev/null
            
            if systemctl is-masked "$svc" &>/dev/null; then
                echo "$svc masked"
                log_message "SUCCESS" "Masked $svc"
                masked_count=$((masked_count + 1))
            else
                echo "Failed to mask $svc"
                log_message "ERROR" "Failed to mask $svc"
            fi
        else
            echo "$svc not present"
            masked_count=$((masked_count + 1))
        fi
    done
    
    if [ $masked_count -eq ${#services[@]} ]; then
        echo "Status: COMPLIANT"
    else
        echo "Status: NON-COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
