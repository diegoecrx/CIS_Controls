#!/bin/bash

SCRIPT_NAME="3.5.2.10_nftables_service_enabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.2.10 - Ensure nftables service is enabled"
    echo ""
    
    # Check if nftables is installed, install if not
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "nftables is not installed - installing..."
        log_message "INFO" "Installing nftables package"
        
        if yum install -y nftables >/dev/null 2>&1; then
            echo "nftables installed successfully"
            log_message "SUCCESS" "nftables package installed"
        else
            echo "Failed to install nftables"
            log_message "ERROR" "Failed to install nftables package"
            echo "Status: FAILED"
            return 1
        fi
    else
        echo "nftables is already installed"
        log_message "INFO" "nftables already installed"
    fi
    
    # Enable nftables service
    if systemctl is-enabled nftables >/dev/null 2>&1; then
        echo "nftables service is already enabled"
        log_message "INFO" "nftables already enabled"
    else
        systemctl enable nftables >/dev/null 2>&1
        log_message "SUCCESS" "Enabled nftables service"
        echo "nftables service enabled"
    fi
    
    # Start nftables service if not running
    if systemctl is-active nftables >/dev/null 2>&1; then
        echo "nftables service is already running"
    else
        systemctl start nftables >/dev/null 2>&1
        log_message "SUCCESS" "Started nftables service"
        echo "nftables service started"
    fi
    
    echo "Status: COMPLIANT"
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
