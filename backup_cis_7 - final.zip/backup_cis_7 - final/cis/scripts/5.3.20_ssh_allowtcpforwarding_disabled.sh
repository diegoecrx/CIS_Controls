#!/bin/bash

SCRIPT_NAME="5.3.20_ssh_allowtcpforwarding_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.20 - Ensure SSH AllowTcpForwarding is disabled"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH to disable TCP forwarding..."
    echo ""

    # Check current AllowTcpForwarding setting
    CURRENT_SETTING=$(grep -i "^AllowTcpForwarding" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "AllowTcpForwarding is not explicitly configured (default: yes)"
        echo "Adding explicit configuration..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.20 - Disable SSH TCP Forwarding" >> "$SSHD_CONFIG"
        echo "AllowTcpForwarding no" >> "$SSHD_CONFIG"
        
        echo "Added 'AllowTcpForwarding no' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added AllowTcpForwarding no directive"
        
    elif [ "$CURRENT_SETTING" = "no" ]; then
        echo "AllowTcpForwarding is already set to 'no'"
        log_message "INFO" "AllowTcpForwarding already disabled"
        
    else
        echo "AllowTcpForwarding is currently set to: $CURRENT_SETTING"
        echo "Changing to 'no'..."
        
        sed -i 's/^AllowTcpForwarding.*/AllowTcpForwarding no/' "$SSHD_CONFIG"
        
        echo "Changed AllowTcpForwarding to 'no'"
        log_message "SUCCESS" "Changed AllowTcpForwarding to no"
    fi

    # Also comment out any AllowTcpForwarding yes directives to prevent conflicts
    sed -i 's/^AllowTcpForwarding[[:space:]]\+yes/#AllowTcpForwarding yes/' "$SSHD_CONFIG"

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^AllowTcpForwarding" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ "$FINAL_SETTING" = "no" ]; then
        echo "AllowTcpForwarding is set to: no"
        echo ""
        echo "Status: COMPLIANT"
        echo "SSH TCP forwarding is disabled"
        log_message "SUCCESS" "AllowTcpForwarding is disabled"
    else
        echo "WARNING: Could not verify AllowTcpForwarding setting"
        echo "Current value: $FINAL_SETTING"
        log_message "WARNING" "Could not verify AllowTcpForwarding setting"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    echo "NOTE: Disabling TCP forwarding prevents:"
    echo "  - Port forwarding (-L, -R, -D options)"
    echo "  - SSH tunneling to bypass firewalls"
    echo "  - Using SSH as a SOCKS proxy"
    echo "  - Dynamic port forwarding"
    echo ""
    echo "If your organization requires SSH tunneling, consider using"
    echo "Match directives to allow it only for specific users or groups"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
