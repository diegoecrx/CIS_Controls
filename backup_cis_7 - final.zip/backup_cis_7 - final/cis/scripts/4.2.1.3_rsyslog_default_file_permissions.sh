#!/bin/bash

SCRIPT_NAME="4.2.1.3_rsyslog_default_file_permissions.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
RSYSLOG_CONF="/etc/rsyslog.conf"
RSYSLOG_D="/etc/rsyslog.d"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 4.2.1.3 - Ensure rsyslog default file permissions configured"
    echo ""

    # Check if rsyslog is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo "rsyslog is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "rsyslog not installed - control not applicable"
        return 0
    fi

    # Backup rsyslog.conf
    if [ -f "$RSYSLOG_CONF" ]; then
        cp "$RSYSLOG_CONF" "$BACKUP_DIR/rsyslog.conf.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $RSYSLOG_CONF"
    else
        echo "ERROR: $RSYSLOG_CONF not found"
        log_message "ERROR" "rsyslog configuration file not found"
        return 1
    fi

    echo "Configuring rsyslog default file permissions..."
    echo ""

    # Check if $FileCreateMode directive already exists
    if grep -q '^\$FileCreateMode' "$RSYSLOG_CONF"; then
        CURRENT_MODE=$(grep '^\$FileCreateMode' "$RSYSLOG_CONF" | awk '{print $2}')
        echo "Current FileCreateMode: $CURRENT_MODE"
        
        # Update existing directive
        sed -i 's/^\$FileCreateMode.*/$FileCreateMode 0640/' "$RSYSLOG_CONF"
        echo "Updated FileCreateMode to 0640"
        log_message "SUCCESS" "Updated existing FileCreateMode to 0640"
    else
        # Add directive at the beginning of the file (after comments)
        # Find the first non-comment, non-empty line
        LINE_NUM=$(grep -n -m 1 '^[^#]' "$RSYSLOG_CONF" | cut -d: -f1)
        
        if [ -n "$LINE_NUM" ]; then
            sed -i "${LINE_NUM}i\$FileCreateMode 0640" "$RSYSLOG_CONF"
        else
            # If no non-comment line found, append to file
            echo '$FileCreateMode 0640' >> "$RSYSLOG_CONF"
        fi
        
        echo "Added FileCreateMode 0640 to $RSYSLOG_CONF"
        log_message "SUCCESS" "Added FileCreateMode 0640 directive"
    fi

    # Check for any configuration files in rsyslog.d directory
    if [ -d "$RSYSLOG_D" ]; then
        CONF_FILES=$(find "$RSYSLOG_D" -name "*.conf" 2>/dev/null)
        
        if [ -n "$CONF_FILES" ]; then
            echo ""
            echo "Checking rsyslog.d configuration files..."
            
            for conf_file in $CONF_FILES; do
                # Backup each configuration file
                cp "$conf_file" "$BACKUP_DIR/$(basename $conf_file).$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
                
                # Check and update FileCreateMode in each file
                if grep -q '^\$FileCreateMode' "$conf_file"; then
                    sed -i 's/^\$FileCreateMode.*/$FileCreateMode 0640/' "$conf_file"
                    echo "Updated FileCreateMode in $(basename $conf_file)"
                    log_message "INFO" "Updated FileCreateMode in $(basename $conf_file)"
                fi
            done
        fi
    fi

    echo ""
    echo "Verifying configuration..."
    if grep -q '^\$FileCreateMode 0640' "$RSYSLOG_CONF"; then
        echo "FileCreateMode 0640 is configured in $RSYSLOG_CONF"
    else
        echo "WARNING: FileCreateMode verification failed"
        log_message "WARNING" "FileCreateMode verification failed"
    fi

    # Restart rsyslog service to apply changes
    echo ""
    echo "Restarting rsyslog service..."
    if systemctl restart rsyslog >/dev/null 2>&1; then
        echo "rsyslog service restarted successfully"
        log_message "SUCCESS" "rsyslog service restarted"
    else
        echo "WARNING: Failed to restart rsyslog service"
        echo "Run 'systemctl restart rsyslog' manually to apply changes"
        log_message "WARNING" "Manual rsyslog restart required"
    fi

    # Verify rsyslog service is enabled and running
    if systemctl is-enabled rsyslog >/dev/null 2>&1; then
        echo "rsyslog service is enabled"
    else
        echo "WARNING: rsyslog service is not enabled"
        log_message "WARNING" "rsyslog service not enabled"
    fi

    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "rsyslog service is running"
    else
        echo "WARNING: rsyslog service is not running"
        log_message "WARNING" "rsyslog service not running"
    fi

    echo ""
    echo "Status: COMPLIANT"
    echo "New log files will be created with 0640 permissions (owner: rw, group: r, other: none)"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
