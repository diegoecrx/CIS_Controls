#!/bin/bash

SCRIPT_NAME="2.4_nonessential_services_removed_masked.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.4 - Ensure Nonessential Services are Removed or Masked"
    echo ""
    
    # List all enabled services
    enabled_services=$(systemctl list-unit-files --state=enabled --type=service | awk 'NR>1 && !/^UNIT/ {print $1}' | grep -v '@')
    
    echo "Enabled services requiring review:"
    echo "$enabled_services"
    echo ""
    
    echo "This control requires manual review of enabled services."
    echo "Review each service and remove or mask if not required:"
    echo "  - To remove: yum remove <package>"
    echo "  - To mask: systemctl mask <service>"
    echo ""
    
    echo "Common nonessential services to consider:"
    echo "  - autofs (automounting)"
    echo "  - bluetooth"
    echo "  - rpcbind (if not using NFS)"
    echo "  - cups (if not printing)"
    echo "  - avahi-daemon (if not using mDNS)"
    echo ""
    
    echo "Status: MANUAL REVIEW REQUIRED"
    log_message "INFO" "Manual review required for nonessential services"
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
