# Fix the f-string syntax error in the template
def generate_script_template_section5(row_data):
    """Generate a bash script based on the template and row data for Section 5 - Fixed version"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    remediation_name = str(row_data['remediation_name']) if pd.notna(row_data['remediation_name']) else "CIS Control"
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    profile = str(row_data['profile']) if pd.notna(row_data['profile']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Determine if automated or manual
    is_automated = 'automated' in str(script_name).lower() if pd.notna(script_name) else True
    
    # Extract profile levels
    server_level = ""
    workstation_level = ""
    
    if profile and "Level 1 - Server" in profile:
        server_level = "Level 1"
    elif profile and "Level 2 - Server" in profile:
        server_level = "Level 2"
        
    if profile and "Level 1 - Workstation" in profile:
        workstation_level = "Level 1"
    elif profile and "Level 2 - Workstation" in profile:
        workstation_level = "Level 2"
    
    # Build the script content (minimal version to avoid f-string issues)
    script_content = '''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 5
# SCRIPT_NAME_PLACEHOLDER
# REMEDIATION_NAME_PLACEHOLDER
# 
# This script implements logging and auditing controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="SCRIPT_NAME_PLACEHOLDER"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="SERVER_LEVEL_PLACEHOLDER"
profile_workstation="WORKSTATION_LEVEL_PLACEHOLDER"
default_value="DEFAULT_VALUE_PLACEHOLDER"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
    
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Backup function
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi
    
    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"
    
    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Service management
manage_service() {
    local action="$1"
    local service_name="$2"
    
    case "$action" in
        "enable"|"disable"|"start"|"stop"|"restart"|"reload")
            if systemctl "$action" "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "$action service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to $action service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management
manage_package() {
    local action="$1"
    local package_name="$2"
    
    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi
            
            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi
            
            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# Configuration editing
edit_config_file() {
    local config_file="$1"
    local setting_name="$2"
    local setting_value="$3"
    
    if [ ! -f "$config_file" ]; then
        log_message "ERROR" "Configuration file not found: $config_file"
        return 1
    fi
    
    backup_file "$config_file"
    
    # Remove existing entries
    sed -i "/^#*[[:space:]]*$setting_name/d" "$config_file" 2>/dev/null
    
    # Add new setting
    echo "$setting_name $setting_value" >> "$config_file"
    log_message "SUCCESS" "Added $setting_name $setting_value to $config_file"
    return 0
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"
    
    # Description: DESCRIPTION_PLACEHOLDER
    
    REMEDIATION_LOGIC_PLACEHOLDER
    
    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi
    
    main_remediation
    exit $?
fi
'''

    # Replace placeholders
    script_content = script_content.replace('SCRIPT_NAME_PLACEHOLDER', script_name)
    script_content = script_content.replace('REMEDIATION_NAME_PLACEHOLDER', remediation_name)
    script_content = script_content.replace('SERVER_LEVEL_PLACEHOLDER', server_level)
    script_content = script_content.replace('WORKSTATION_LEVEL_PLACEHOLDER', workstation_level)
    script_content = script_content.replace('DEFAULT_VALUE_PLACEHOLDER', default_value)
    script_content = script_content.replace('DESCRIPTION_PLACEHOLDER', description)
    
    return script_content

# Test with first row
test_row = df_section5.iloc[0].to_dict()
test_script = generate_script_template_section5(test_row)
print("Generated template test successful!")
print(f"Template length: {len(test_script.split('\\n'))} lines")