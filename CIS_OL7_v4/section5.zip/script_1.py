# Create directory for section5 scripts
section5_dir = 'section5_scripts'
os.makedirs(section5_dir, exist_ok=True)

# Generate script template for Section 5 - focusing on logging and auditing
def generate_script_template_section5(row_data):
    """Generate a bash script based on the template and row data for Section 5"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    remediation_name = str(row_data['remediation_name']) if pd.notna(row_data['remediation_name']) else "CIS Control"
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    profile = str(row_data['profile']) if pd.notna(row_data['profile']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Determine if automated or manual
    is_automated = 'automated' in str(script_name).lower() if pd.notna(script_name) else True
    
    # Extract profile levels
    server_level = ""
    workstation_level = ""
    
    if profile and "Level 1 - Server" in profile:
        server_level = "Level 1"
    elif profile and "Level 2 - Server" in profile:
        server_level = "Level 2"
        
    if profile and "Level 1 - Workstation" in profile:
        workstation_level = "Level 1"
    elif profile and "Level 2 - Workstation" in profile:
        workstation_level = "Level 2"
    
    # Build the script content
    script_content = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 5
# {script_name}
# {remediation_name}
# 
# This script implements logging and auditing controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="{script_name}"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="{server_level}"
profile_workstation="{workstation_level}"
default_value="{default_value}"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {{
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}}

# Enhanced logging function with error categorization
log_message() {{
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
    
    # Also log to error log if it's an error
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}}

# Enhanced backup function with validation
backup_file() {{
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi
    
    if [ ! -r "$file_path" ]; then
        log_message "ERROR" "Cannot read file for backup: $file_path"
        return 1
    fi
    
    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"
    
    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        echo "$BACKUP_DIR/$backup_name"  # Return backup path
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}}

# Service management with proper error handling
manage_service() {{
    local action="$1"
    local service_name="$2"
    
    case "$action" in
        "enable")
            if systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already enabled"
                return 0
            fi
            
            if systemctl enable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Enabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to enable service: $service_name"
                return 1
            fi
        ;;
        "disable")
            if ! systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already disabled"
                return 0
            fi
            
            if systemctl disable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Disabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to disable service: $service_name"
                return 1
            fi
        ;;
        "start")
            if systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already running"
                return 0
            fi
            
            if systemctl start "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Started service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to start service: $service_name"
                return 1
            fi
        ;;
        "stop")
            if ! systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already stopped"
                return 0
            fi
            
            if systemctl stop "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Stopped service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to stop service: $service_name"
                return 1
            fi
        ;;
        "restart")
            if systemctl restart "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Restarted service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to restart service: $service_name"
                return 1
            fi
        ;;
        "reload")
            if systemctl reload "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Reloaded service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to reload service: $service_name"
                return 1
            fi
        ;;
    esac
}}

# Package management function
manage_package() {{
    local action="$1"
    local package_name="$2"
    
    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi
            
            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi
            
            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}}

# Configuration file editor with validation
edit_config_file() {{
    local config_file="$1"
    local setting_name="$2"
    local setting_value="$3"
    local comment_prefix="${{4:-#}}"
    
    if [ ! -f "$config_file" ]; then
        log_message "ERROR" "Configuration file not found: $config_file"
        return 1
    fi
    
    # Backup the file first
    local backup_path
    backup_path=$(backup_file "$config_file")
    if [ $? -ne 0 ]; then
        log_message "ERROR" "Cannot proceed without backup"
        return 1
    fi
    
    # Check if setting already exists and is correctly configured
    if grep -q "^$setting_name[[:space:]]*$setting_value" "$config_file"; then
        log_message "INFO" "Setting $setting_name is already correctly configured"
        return 0
    fi
    
    # Remove any existing commented or incorrect lines
    sed -i "/^$comment_prefix*[[:space:]]*$setting_name/d" "$config_file" 2>/dev/null
    
    # Add the correct setting
    if echo "$setting_name $setting_value" >> "$config_file"; then
        log_message "SUCCESS" "Added $setting_name $setting_value to $config_file"
        return 0
    else
        log_message "ERROR" "Failed to add setting to $config_file"
        return 1
    fi
}}

# Logging configuration function
configure_logging() {{
    local log_type="$1"    # rsyslog, auditd, journald
    local config_param="$2"
    local config_value="$3"
    local config_file="$4"
    
    log_message "INFO" "Configuring $log_type: $config_param = $config_value"
    
    case "$log_type" in
        "rsyslog")
            config_file="${{config_file:-/etc/rsyslog.conf}}"
            if edit_config_file "$config_file" "$config_param" "$config_value"; then
                # Restart rsyslog to apply changes
                if manage_service "restart" "rsyslog"; then
                    log_message "SUCCESS" "Rsyslog configuration applied"
                    return 0
                else
                    log_message "ERROR" "Failed to restart rsyslog service"
                    return 1
                fi
            fi
        ;;
        "auditd")
            config_file="${{config_file:-/etc/audit/auditd.conf}}"
            if edit_config_file "$config_file" "$config_param" "$config_value" ""; then
                # Restart auditd to apply changes
                if service auditd restart 2>/dev/null; then
                    log_message "SUCCESS" "Auditd configuration applied"
                    return 0
                else
                    log_message "ERROR" "Failed to restart auditd service"
                    return 1
                fi
            fi
        ;;
        "journald")
            config_file="${{config_file:-/etc/systemd/journald.conf}}"
            if edit_config_file "$config_file" "$config_param" "$config_value"; then
                # Restart journald to apply changes
                if manage_service "restart" "systemd-journald"; then
                    log_message "SUCCESS" "Journald configuration applied"
                    return 0
                else
                    log_message "ERROR" "Failed to restart journald service"
                    return 1
                fi
            fi
        ;;
    esac
    
    return 1
}}

# Audit rule management
manage_audit_rule() {{
    local action="$1"
    local rule="$2"
    local rules_file="/etc/audit/rules.d/cis.rules"
    
    case "$action" in
        "add")
            # Create rules file if it doesn't exist
            if [ ! -f "$rules_file" ]; then
                touch "$rules_file"
                log_message "INFO" "Created audit rules file: $rules_file"
            fi
            
            # Check if rule already exists
            if grep -q "^$rule" "$rules_file"; then
                log_message "INFO" "Audit rule already exists: $rule"
                return 0
            fi
            
            # Add rule
            echo "$rule" >> "$rules_file"
            log_message "SUCCESS" "Added audit rule: $rule"
            
            # Load rules
            if augenrules --load >/dev/null 2>&1; then
                log_message "SUCCESS" "Loaded audit rules"
                return 0
            else
                log_message "ERROR" "Failed to load audit rules"
                return 1
            fi
        ;;
        "remove")
            if [ -f "$rules_file" ]; then
                if sed -i "/^$(echo "$rule" | sed 's/[[\\/.*^$()+?{|]/\\&/g')/d" "$rules_file" 2>/dev/null; then
                    log_message "SUCCESS" "Removed audit rule: $rule"
                    augenrules --load >/dev/null 2>&1
                    return 0
                fi
            fi
            log_message "INFO" "Audit rule not found or already removed: $rule"
            return 0
        ;;
    esac
}}

# File permissions management
set_file_permissions() {{
    local target_path="$1"
    local permissions="$2"
    local owner="$3"
    local group="$4"
    
    log_message "INFO" "Setting permissions on $target_path"
    
    # Check if target exists
    if [ ! -e "$target_path" ]; then
        log_message "ERROR" "Target path does not exist: $target_path"
        return 1
    fi
    
    # Set ownership if specified
    if [ -n "$owner" ] && [ -n "$group" ]; then
        if chown "$owner:$group" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set ownership $owner:$group on $target_path"
        else
            log_message "ERROR" "Failed to set ownership on $target_path"
            return 1
        fi
    fi
    
    # Set permissions if specified
    if [ -n "$permissions" ]; then
        if chmod "$permissions" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set permissions $permissions on $target_path"
        else
            log_message "ERROR" "Failed to set permissions on $target_path"
            return 1
        fi
    fi
    
    return 0
}}
'''

    # Add specific remediation logic based on script type
    if is_automated:
        script_content += f'''
# Main automated remediation function
main_remediation() {{
    log_message "INFO" "Starting automated remediation: $SCRIPT_NAME"
    
    # Set error handling
    set -e
    trap 'log_message "ERROR" "Script failed at line $LINENO"; exit 1' ERR
    
    # {remediation_name}
    # Description: {description}
    
    REMEDIATION_LOGIC_PLACEHOLDER
    
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        log_message "SUCCESS" "Automated remediation completed successfully: $SCRIPT_NAME"
    else
        log_message "ERROR" "Automated remediation failed: $SCRIPT_NAME (exit code: $exit_code)"
    fi
    
    return $exit_code
}}

# Execute main function if script is run directly
if [ "${{BASH_SOURCE[0]}}" = "${{0}}" ]; then
    # Verify running as root
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi
    
    # Execute automated remediation
    main_remediation
    exit $?
fi
'''
    else:
        script_content += f'''
# User interaction for manual remediation
user_menu() {{
    echo "=============================================="
    echo "Manual Remediation: $SCRIPT_NAME"
    echo "{remediation_name}"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "{description}"
    echo ""
    echo "Configuration file: $config_file"
    echo "Profile Server: $profile_srv"  
    echo "Profile Workstation: $profile_workstation"
    echo "Default value: $default_value"
    echo ""
    echo "Please choose an option:"
    echo "1) Execute/Force the remediation (will create backup)"
    echo "2) Show remediation commands only (no execution)"
    echo "3) Exit"
    echo ""
    read -p "Enter your choice [1-3]: " choice
    
    case $choice in
        1)
            execute_remediation
        ;;
        2)  
            show_remediation_commands
        ;;
        3)
            echo "Exiting..."
            exit 0
        ;;
        *)
            echo "Invalid option. Please try again."
            user_menu
        ;;
    esac
}}

# Execute manual remediation with backup
execute_remediation() {{
    log_message "INFO" "Starting manual remediation execution: $SCRIPT_NAME"
    
    # Create backup before executing
    if [ -n "$config_file" ] && [ -f "$config_file" ]; then
        backup_file "$config_file"
        if [ $? -ne 0 ]; then
            log_message "ERROR" "Failed to create backup. Aborting remediation."
            return 1
        fi
    fi
    
    # Set error handling
    set -e
    trap 'log_message "ERROR" "Manual remediation failed at line $LINENO"; exit 1' ERR
    
    # {remediation_name}
    # Description: {description}
    
    REMEDIATION_LOGIC_PLACEHOLDER
    
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        log_message "SUCCESS" "Manual remediation executed successfully: $SCRIPT_NAME"
        echo "Remediation completed successfully!"
    else
        log_message "ERROR" "Manual remediation failed: $SCRIPT_NAME (exit code: $exit_code)"
        echo "Remediation failed! Check logs for details."
    fi
    
    return $exit_code
}}

# Show remediation commands without execution
show_remediation_commands() {{
    log_message "INFO" "Showing remediation commands for: $SCRIPT_NAME"
    
    echo "=============================================="
    echo "REMEDIATION COMMANDS (NOT EXECUTED)"
    echo "=============================================="
    echo ""
    echo "Configuration file path: $config_file"
    echo "Original file location: $config_file"
    echo ""
    echo "Commands that would be executed:"
    echo ""
    
    SHOW_COMMANDS_PLACEHOLDER
    
    echo "=============================================="
    echo "END OF COMMANDS"
    echo "=============================================="
}}

# Execute main function if script is run directly
if [ "${{BASH_SOURCE[0]}}" = "${{0}}" ]; then
    # Verify running as root  
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi
    
    # Start user menu for manual remediation
    user_menu
fi
'''

    return script_content

# Test template generation with first row
test_row = df_section5.iloc[0].to_dict()
test_script = generate_script_template_section5(test_row)
print("Generated template preview (first 30 lines):")
print("\n".join(test_script.split("\n")[:30]))
print("...")
print(f"Total lines: {len(test_script.split('\n'))}")