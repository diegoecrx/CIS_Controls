#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 5
# 5.1.1.3_journald_to_send_logs_to_rsyslog_manual
# 5.1.1.3 Ensure journald is configured to send logs to rsyslog (Manual)
# 
# This script implements logging and auditing controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="5.1.1.3_journald_to_send_logs_to_rsyslog_manual"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 1"
profile_workstation="Level 1"
default_value=""

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Backup function
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Service management
manage_service() {
    local action="$1"
    local service_name="$2"

    case "$action" in
        "enable"|"disable"|"start"|"stop"|"restart"|"reload")
            if systemctl "$action" "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "$action service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to $action service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management
manage_package() {
    local action="$1"
    local package_name="$2"

    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi

            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi

            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# Configuration editing
edit_config_file() {
    local config_file="$1"
    local setting_name="$2"
    local setting_value="$3"

    if [ ! -f "$config_file" ]; then
        log_message "ERROR" "Configuration file not found: $config_file"
        return 1
    fi

    backup_file "$config_file"

    # Remove existing entries
    sed -i "/^#*[[:space:]]*$setting_name/d" "$config_file" 2>/dev/null

    # Add new setting
    echo "$setting_name $setting_value" >> "$config_file"
    log_message "SUCCESS" "Added $setting_name $setting_value to $config_file"
    return 0
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"

    # Description: Data from systemd-journald may be stored in volatile memory or persisted locally on
the server. Utilities exist to accept remote export of systemd-journald logs, however,
use of the rsyslog service provides a consistent means of log collection and export.

    
    # CIS 5.1.1.3: Ensure journald is configured to send logs to rsyslog
    log_message "INFO" "Configuring journald to forward logs to rsyslog"
    config_file="/etc/systemd/journald.conf"

    if edit_config_file "/etc/systemd/journald.conf" "ForwardToSyslog" "yes"; then
        if manage_service "restart" "systemd-journald"; then
            log_message "SUCCESS" "Journald configured to forward to rsyslog"
        else
            log_message "ERROR" "Failed to restart journald service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to configure journald"
        return 1
    fi

    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi

    main_remediation
    exit $?
fi
