#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 5
# 5.2.1.3_audit_backlog_limit_is_sufficient_automated
# 5.2.1.3 Ensure audit_backlog_limit is sufficient (Automated)
# 
# This script implements logging and auditing controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="5.2.1.3_audit_backlog_limit_is_sufficient_automated"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 2"
profile_workstation="Level 2"
default_value=""

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Backup function
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Service management
manage_service() {
    local action="$1"
    local service_name="$2"

    case "$action" in
        "enable"|"disable"|"start"|"stop"|"restart"|"reload")
            if systemctl "$action" "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "$action service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to $action service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management
manage_package() {
    local action="$1"
    local package_name="$2"

    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi

            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi

            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# Configuration editing
edit_config_file() {
    local config_file="$1"
    local setting_name="$2"
    local setting_value="$3"

    if [ ! -f "$config_file" ]; then
        log_message "ERROR" "Configuration file not found: $config_file"
        return 1
    fi

    backup_file "$config_file"

    # Remove existing entries
    sed -i "/^#*[[:space:]]*$setting_name/d" "$config_file" 2>/dev/null

    # Add new setting
    echo "$setting_name $setting_value" >> "$config_file"
    log_message "SUCCESS" "Added $setting_name $setting_value to $config_file"
    return 0
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"

    # Description: The audit_backlog_limit parameter determines how auditd records can be held in the
auditd backlog. The default setting of 64 may be insufficient to store all audit events
during boot.

    
    # CIS 5.2.1.3: Ensure auditing for processes that start prior to auditd is enabled
    log_message "INFO" "Enabling auditing for early processes"

    # Add audit=1 to kernel parameters
    if grep -q "audit=1" /proc/cmdline; then
        log_message "INFO" "Audit parameter already enabled in kernel"
    else
        # Backup grub configuration
        backup_file "/etc/default/grub"

        # Add audit=1 to GRUB_CMDLINE_LINUX
        if grep -q "GRUB_CMDLINE_LINUX=" "/etc/default/grub"; then
            sed -i 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="audit=1 /' "/etc/default/grub"
        else
            echo 'GRUB_CMDLINE_LINUX="audit=1"' >> "/etc/default/grub"
        fi

        # Update grub configuration
        if grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1; then
            log_message "SUCCESS" "Added audit=1 to kernel parameters"
            log_message "WARNING" "Reboot required to apply kernel parameter changes"
        else
            log_message "ERROR" "Failed to update grub configuration"
            return 1
        fi
    fi

    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi

    main_remediation
    exit $?
fi
