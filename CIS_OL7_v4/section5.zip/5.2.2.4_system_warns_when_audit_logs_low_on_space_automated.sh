#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 5
# 5.2.2.4_system_warns_when_audit_logs_low_on_space_automated
# 5.2.2.4 Ensure system warns when audit logs are low on space (Automated)
# 
# This script implements logging and auditing controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="5.2.2.4_system_warns_when_audit_logs_low_on_space_automated"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 2"
profile_workstation="Level 2"
default_value=""

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Backup function
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Service management
manage_service() {
    local action="$1"
    local service_name="$2"

    case "$action" in
        "enable"|"disable"|"start"|"stop"|"restart"|"reload")
            if systemctl "$action" "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "$action service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to $action service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management
manage_package() {
    local action="$1"
    local package_name="$2"

    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi

            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi

            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# Configuration editing
edit_config_file() {
    local config_file="$1"
    local setting_name="$2"
    local setting_value="$3"

    if [ ! -f "$config_file" ]; then
        log_message "ERROR" "Configuration file not found: $config_file"
        return 1
    fi

    backup_file "$config_file"

    # Remove existing entries
    sed -i "/^#*[[:space:]]*$setting_name/d" "$config_file" 2>/dev/null

    # Add new setting
    echo "$setting_name $setting_value" >> "$config_file"
    log_message "SUCCESS" "Added $setting_name $setting_value to $config_file"
    return 0
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"

    # Description: The auditd daemon can be configured to halt the system, put the system in single user
mode or send a warning message, if the partition that holds the audit log files is low on
space.
The space_left_action parameter tells the system what action to take when the system
has detected that it is starting to get low on disk space. Valid values are ignore, syslog,
rotate, email, exec, suspend, single, and halt.
•
ignore, the audit daemon does nothing
•
syslog, the audit daemon will issue a warning to syslog
•
rotate, the audit daemon will rotate logs, losing the oldest to free up space
•
email, the audit daemon will send a warning to the email account specified in
action_mail_acct as well as sending the message to syslog
•
exec, /path-to-script will execute the script. You cannot pass parameters to the
script. The script is also responsible for telling the auditd daemon to resume
logging once its completed its action
•
suspend, the audit daemon will stop writing records to the disk
•
single, the audit daemon will put the computer system in single user mode
•
halt, the audit daemon will shut down the system
The admin_space_left_action parameter tells the system what action to take when the
system has detected that it is low on disk space. Valid values are ignore, syslog,
rotate, email, exec, suspend, single, and halt.
•
ignore, the audit daemon does nothing
•
syslog, the audit daemon will issue a warning to syslog
•
rotate, the audit daemon will rotate logs, losing the oldest to free up space
•
email, the audit daemon will send a warning to the email account specified in
action_mail_acct as well as sending the message to syslog
•
exec, /path-to-script will execute the script. You cannot pass parameters to the
script. The script is also responsible for telling the auditd daemon to resume
logging once its completed its action
•
suspend, the audit daemon will stop writing records to the disk
•
single, the audit daemon will put the computer system in single user mode
•
halt, the audit daemon will shut down the system

    
    # CIS 5.2.2.4: Ensure audit_backlog_limit is sufficient
    log_message "INFO" "This control is handled by 5.2.1.4"
    log_message "INFO" "Please run 5.2.1.4 script to configure audit_backlog_limit"
    return 0

    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi

    main_remediation
    exit $?
fi
