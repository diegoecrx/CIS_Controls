# Create specific remediation logic for Section 5 CIS controls (Logging and Auditing)
def get_specific_remediation_logic_section5(row_data):
    """Generate specific remediation logic based on Section 5 CIS control type"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    
    # Rsyslog Configuration (5.1.1.x)
    if script_id == '5.1.1.1':
        return '''
    # CIS 5.1.1.1: Ensure rsyslog is installed
    log_message "INFO" "Installing rsyslog package"
    
    if manage_package "install" "rsyslog"; then
        log_message "SUCCESS" "Rsyslog package installed successfully"
    else
        log_message "ERROR" "Failed to install rsyslog package"
        return 1
    fi'''
    
    elif script_id == '5.1.1.2':
        return '''
    # CIS 5.1.1.2: Ensure rsyslog service is enabled
    log_message "INFO" "Enabling and starting rsyslog service"
    config_file="/etc/systemd/system/multi-user.target.wants/rsyslog.service"
    
    if manage_service "enable" "rsyslog"; then
        if manage_service "start" "rsyslog"; then
            log_message "SUCCESS" "Rsyslog service enabled and started"
        else
            log_message "ERROR" "Failed to start rsyslog service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to enable rsyslog service"
        return 1
    fi'''
    
    elif script_id == '5.1.1.3':
        return '''
    # CIS 5.1.1.3: Ensure journald is configured to send logs to rsyslog
    log_message "INFO" "Configuring journald to forward logs to rsyslog"
    config_file="/etc/systemd/journald.conf"
    
    if edit_config_file "/etc/systemd/journald.conf" "ForwardToSyslog" "yes"; then
        if manage_service "restart" "systemd-journald"; then
            log_message "SUCCESS" "Journald configured to forward to rsyslog"
        else
            log_message "ERROR" "Failed to restart journald service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to configure journald"
        return 1
    fi'''
    
    elif script_id == '5.1.1.4':
        return '''
    # CIS 5.1.1.4: Ensure rsyslog default file permissions are configured
    log_message "INFO" "Configuring rsyslog default file permissions"
    config_file="/etc/rsyslog.conf"
    
    if edit_config_file "/etc/rsyslog.conf" "$FileCreateMode" "0640"; then
        if manage_service "restart" "rsyslog"; then
            log_message "SUCCESS" "Rsyslog file permissions configured"
        else
            log_message "ERROR" "Failed to restart rsyslog"
            return 1
        fi
    else
        log_message "ERROR" "Failed to configure rsyslog permissions"
        return 1
    fi'''
    
    elif script_id == '5.1.1.5':
        return '''
    # CIS 5.1.1.5: Ensure logging is configured
    log_message "INFO" "Configuring system logging"
    config_file="/etc/rsyslog.conf"
    
    log_message "WARNING" "Manual configuration required for logging setup"
    log_message "INFO" "Please review and configure /etc/rsyslog.conf according to organizational needs"
    
    # Basic logging configuration
    backup_file "/etc/rsyslog.conf"
    
    # Ensure basic log files are configured
    if ! grep -q "auth,authpriv.*" "/etc/rsyslog.conf"; then
        echo "auth,authpriv.*    /var/log/auth.log" >> "/etc/rsyslog.conf"
        log_message "SUCCESS" "Added auth logging configuration"
    fi
    
    if manage_service "restart" "rsyslog"; then
        log_message "SUCCESS" "Rsyslog restarted with new configuration"
    fi'''
    
    elif script_id == '5.1.1.6':
        return '''
    # CIS 5.1.1.6: Ensure rsyslog is configured to send logs to a remote log host
    log_message "INFO" "Configuring rsyslog remote logging"
    config_file="/etc/rsyslog.conf"
    
    log_message "WARNING" "Manual configuration required for remote log host"
    log_message "INFO" "Please specify remote log host IP/hostname"
    
    backup_file "/etc/rsyslog.conf"
    
    # Add template for remote logging (requires manual specification of host)
    echo "# Remote logging configuration - specify your log host" >> "/etc/rsyslog.conf"
    echo "# *.* @@loghost.example.com:514" >> "/etc/rsyslog.conf"
    
    log_message "SUCCESS" "Remote logging template added to rsyslog.conf"
    log_message "INFO" "Please edit /etc/rsyslog.conf to specify your remote log host"'''
    
    elif script_id == '5.1.1.7':
        return '''
    # CIS 5.1.1.7: Ensure rsyslog is not configured to receive logs from a remote client
    log_message "INFO" "Ensuring rsyslog does not accept remote logs"
    config_file="/etc/rsyslog.conf"
    
    backup_file "/etc/rsyslog.conf"
    
    # Comment out or remove remote log reception
    sed -i 's/^$ModLoad imudp/#&/' "/etc/rsyslog.conf"
    sed -i 's/^$UDPServerRun/#&/' "/etc/rsyslog.conf"
    sed -i 's/^$ModLoad imtcp/#&/' "/etc/rsyslog.conf"
    sed -i 's/^$InputTCPServerRun/#&/' "/etc/rsyslog.conf"
    
    if manage_service "restart" "rsyslog"; then
        log_message "SUCCESS" "Rsyslog configured to not accept remote logs"
    else
        log_message "ERROR" "Failed to restart rsyslog"
        return 1
    fi'''
    
    # Journal Configuration (5.1.2.x)
    elif script_id.startswith('5.1.2.'):
        journald_configs = {
            '5.1.2.1.1': ('Storage', 'persistent'),
            '5.1.2.1.2': ('Compress', 'yes'),
            '5.1.2.1.3': ('Seal', 'yes'),
            '5.1.2.1.4': ('ForwardToSyslog', 'yes'),
            '5.1.2.2': ('ForwardToWall', 'no'),
            '5.1.2.3': ('MaxLevelStore', 'info'),
            '5.1.2.4': ('MaxLevelSyslog', 'info')
        }
        
        if script_id in journald_configs:
            param, value = journald_configs[script_id]
            return f'''
    # CIS {script_id}: Configure journald {param}
    log_message "INFO" "Configuring journald {param} = {value}"
    config_file="/etc/systemd/journald.conf"
    
    if edit_config_file "/etc/systemd/journald.conf" "{param}" "{value}"; then
        if manage_service "restart" "systemd-journald"; then
            log_message "SUCCESS" "Journald {param} configured successfully"
        else
            log_message "ERROR" "Failed to restart journald service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to configure journald {param}"
        return 1
    fi'''
    
    # Logrotate Configuration (5.1.3)
    elif script_id == '5.1.3':
        return '''
    # CIS 5.1.3: Ensure logrotate is configured
    log_message "INFO" "Configuring logrotate"
    config_file="/etc/logrotate.conf"
    
    # Ensure logrotate is installed
    if manage_package "install" "logrotate"; then
        log_message "SUCCESS" "Logrotate package installed"
    fi
    
    # Basic logrotate configuration
    backup_file "/etc/logrotate.conf"
    
    # Ensure proper rotation settings exist
    if ! grep -q "weekly" "/etc/logrotate.conf"; then
        sed -i 's/^#*weekly/weekly/' "/etc/logrotate.conf"
        log_message "SUCCESS" "Set weekly rotation in logrotate.conf"
    fi
    
    if ! grep -q "rotate 4" "/etc/logrotate.conf"; then
        sed -i 's/^#*rotate [0-9]*/rotate 4/' "/etc/logrotate.conf"
        log_message "SUCCESS" "Set rotation count to 4 in logrotate.conf"
    fi
    
    log_message "SUCCESS" "Logrotate configuration completed"'''
    
    # Auditd Configuration (5.2.x)
    elif script_id.startswith('5.2.'):
        if script_id == '5.2.1.1':
            return '''
    # CIS 5.2.1.1: Ensure auditd is installed
    log_message "INFO" "Installing auditd package"
    
    if manage_package "install" "audit"; then
        if manage_package "install" "audit-libs"; then
            log_message "SUCCESS" "Auditd packages installed successfully"
        fi
    else
        log_message "ERROR" "Failed to install auditd packages"
        return 1
    fi'''
        
        elif script_id == '5.2.1.2':
            return '''
    # CIS 5.2.1.2: Ensure auditd service is enabled and active
    log_message "INFO" "Enabling and starting auditd service"
    
    if manage_service "enable" "auditd"; then
        if service auditd start 2>/dev/null; then
            log_message "SUCCESS" "Auditd service enabled and started"
        else
            log_message "ERROR" "Failed to start auditd service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to enable auditd service"
        return 1
    fi'''
        
        elif script_id == '5.2.1.3':
            return '''
    # CIS 5.2.1.3: Ensure auditing for processes that start prior to auditd is enabled
    log_message "INFO" "Enabling auditing for early processes"
    
    # Add audit=1 to kernel parameters
    if grep -q "audit=1" /proc/cmdline; then
        log_message "INFO" "Audit parameter already enabled in kernel"
    else
        # Backup grub configuration
        backup_file "/etc/default/grub"
        
        # Add audit=1 to GRUB_CMDLINE_LINUX
        if grep -q "GRUB_CMDLINE_LINUX=" "/etc/default/grub"; then
            sed -i 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="audit=1 /' "/etc/default/grub"
        else
            echo 'GRUB_CMDLINE_LINUX="audit=1"' >> "/etc/default/grub"
        fi
        
        # Update grub configuration
        if grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1; then
            log_message "SUCCESS" "Added audit=1 to kernel parameters"
            log_message "WARNING" "Reboot required to apply kernel parameter changes"
        else
            log_message "ERROR" "Failed to update grub configuration"
            return 1
        fi
    fi'''
        
        elif script_id == '5.2.1.4':
            return '''
    # CIS 5.2.1.4: Ensure audit_backlog_limit is sufficient
    log_message "INFO" "Configuring audit backlog limit"
    
    # Add audit_backlog_limit to kernel parameters
    if grep -q "audit_backlog_limit=" /proc/cmdline; then
        log_message "INFO" "Audit backlog limit already configured"
    else
        backup_file "/etc/default/grub"
        
        # Add audit_backlog_limit=8192 to GRUB_CMDLINE_LINUX
        sed -i 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="audit_backlog_limit=8192 /' "/etc/default/grub"
        
        if grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1; then
            log_message "SUCCESS" "Set audit_backlog_limit=8192"
            log_message "WARNING" "Reboot required to apply changes"
        else
            log_message "ERROR" "Failed to update grub configuration"
            return 1
        fi
    fi'''
        
        # Auditd configuration parameters
        elif script_id == '5.2.2.1':
            return '''
    # CIS 5.2.2.1: Ensure audit log storage size is configured
    log_message "INFO" "Configuring audit log storage size"
    config_file="/etc/audit/auditd.conf"
    
    if edit_config_file "/etc/audit/auditd.conf" "max_log_file" "50"; then
        log_message "SUCCESS" "Set audit log size to 50MB"
        if service auditd restart 2>/dev/null; then
            log_message "SUCCESS" "Auditd restarted with new configuration"
        fi
    else
        log_message "ERROR" "Failed to configure audit log size"
        return 1
    fi'''
        
        elif script_id == '5.2.2.2':
            return '''
    # CIS 5.2.2.2: Ensure audit logs are not automatically deleted
    log_message "INFO" "Configuring audit log retention"
    config_file="/etc/audit/auditd.conf"
    
    if edit_config_file "/etc/audit/auditd.conf" "max_log_file_action" "keep_logs"; then
        log_message "SUCCESS" "Configured audit logs to be kept"
        if service auditd restart 2>/dev/null; then
            log_message "SUCCESS" "Auditd restarted with new configuration"
        fi
    else
        log_message "ERROR" "Failed to configure audit log retention"
        return 1
    fi'''
        
        elif script_id == '5.2.2.3':
            return '''
    # CIS 5.2.2.3: Ensure system is disabled when audit logs are full
    log_message "INFO" "Configuring system behavior when audit logs are full"
    config_file="/etc/audit/auditd.conf"
    
    if edit_config_file "/etc/audit/auditd.conf" "space_left_action" "email"; then
        if edit_config_file "/etc/audit/auditd.conf" "action_mail_acct" "root"; then
            if edit_config_file "/etc/audit/auditd.conf" "admin_space_left_action" "halt"; then
                log_message "SUCCESS" "Configured audit full disk actions"
                if service auditd restart 2>/dev/null; then
                    log_message "SUCCESS" "Auditd restarted with new configuration"
                fi
            fi
        fi
    else
        log_message "ERROR" "Failed to configure audit full disk actions"
        return 1
    fi'''
        
        elif script_id == '5.2.2.4':
            return '''
    # CIS 5.2.2.4: Ensure audit_backlog_limit is sufficient
    log_message "INFO" "This control is handled by 5.2.1.4"
    log_message "INFO" "Please run 5.2.1.4 script to configure audit_backlog_limit"
    return 0'''
    
    # System Activity Audit Rules (5.2.3.x)
    elif script_id.startswith('5.2.3.'):
        audit_rules = {
            '5.2.3.1': '-w /etc/passwd -p wa -k identity',
            '5.2.3.2': '-w /etc/group -p wa -k identity',
            '5.2.3.3': '-w /etc/gshadow -p wa -k identity',
            '5.2.3.4': '-w /etc/shadow -p wa -k identity',
            '5.2.3.5': '-w /etc/security/opasswd -p wa -k identity',
            '5.2.3.6': '-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale',
            '5.2.3.7': '-w /etc/issue -p wa -k system-locale',
            '5.2.3.8': '-w /etc/hosts -p wa -k system-locale',
            '5.2.3.9': '-w /etc/sysconfig/network -p wa -k system-locale',
            '5.2.3.10': '-w /etc/localtime -p wa -k time-change',
            '5.2.3.11': '-w /var/log/lastlog -p wa -k logins',
            '5.2.3.12': '-w /var/run/faillock/ -p wa -k logins',
            '5.2.3.13': '-w /var/log/tallylog -p wa -k logins',
            '5.2.3.14': '-a always,exit -F arch=b64 -S mount -k mounts',
            '5.2.3.15': '-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -k delete',
            '5.2.3.16': '-w /etc/sudoers -p wa -k scope',
            '5.2.3.17': '-w /var/log/sudo.log -p wa -k actions',
            '5.2.3.18': '-w /sbin/insmod -p x -k modules',
            '5.2.3.19': '-a always,exit -F arch=b64 -S init_module -S delete_module -k modules',
            '5.2.3.20': '-e 2'
        }
        
        if script_id in audit_rules:
            rule = audit_rules[script_id]
            rule_description = {
                '5.2.3.1': 'password file changes',
                '5.2.3.2': 'group file changes', 
                '5.2.3.3': 'gshadow file changes',
                '5.2.3.4': 'shadow file changes',
                '5.2.3.5': 'opasswd file changes',
                '5.2.3.6': 'system locale changes',
                '5.2.3.7': 'issue file changes',
                '5.2.3.8': 'hosts file changes',
                '5.2.3.9': 'network configuration changes',
                '5.2.3.10': 'time changes',
                '5.2.3.11': 'lastlog changes',
                '5.2.3.12': 'faillock changes',
                '5.2.3.13': 'tallylog changes',
                '5.2.3.14': 'mount operations',
                '5.2.3.15': 'file deletion events',
                '5.2.3.16': 'sudoers changes',
                '5.2.3.17': 'sudo log changes',
                '5.2.3.18': 'kernel module loading',
                '5.2.3.19': 'kernel module changes',
                '5.2.3.20': 'audit configuration immutable'
            }.get(script_id, 'audit events')
            
            return f'''
    # CIS {script_id}: Audit {rule_description}
    log_message "INFO" "Adding audit rule for {rule_description}"
    
    rules_file="/etc/audit/rules.d/cis.rules"
    
    # Create rules file if it doesn't exist
    if [ ! -f "$rules_file" ]; then
        touch "$rules_file"
        log_message "INFO" "Created audit rules file: $rules_file"
    fi
    
    # Add rule if it doesn't exist
    if ! grep -q "^{rule}" "$rules_file"; then
        echo "{rule}" >> "$rules_file"
        log_message "SUCCESS" "Added audit rule: {rule}"
        
        # Load rules
        if augenrules --load >/dev/null 2>&1; then
            log_message "SUCCESS" "Loaded audit rules"
        else
            log_message "ERROR" "Failed to load audit rules"
            return 1
        fi
    else
        log_message "INFO" "Audit rule already exists: {rule}"
    fi'''
    
    # Default case for unknown controls
    else:
        return f'''
    # CIS {script_id}: Section 5 logging and auditing remediation
    config_file=""
    
    log_message "INFO" "Applying remediation for: {script_id}"
    log_message "INFO" "Description: {description[:100]}..."
    
    # This control may require manual configuration
    log_message "WARNING" "Please review CIS benchmark documentation for specific requirements"
    log_message "INFO" "Remediation guidance: {remediation[:200] if remediation else 'See CIS documentation'}"
    
    return 2  # Manual intervention may be required'''

# Test specific logic generation
test_logic = get_specific_remediation_logic_section5(df_section5.iloc[0].to_dict())
print("Sample specific remediation logic for rsyslog installation:")
print(test_logic)