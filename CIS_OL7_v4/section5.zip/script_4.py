# Generate all Section 5 scripts
scripts_generated_section5 = []
failed_scripts_section5 = []

print("=== GENERATING SECTION 5 SCRIPTS ===")

for index, row in df_section5.iterrows():
    try:
        # Generate base script
        script_content = generate_script_template_section5(row.to_dict())
        
        # Get specific remediation logic
        specific_logic = get_specific_remediation_logic_section5(row.to_dict())
        
        # Insert the logic
        script_content = script_content.replace('REMEDIATION_LOGIC_PLACEHOLDER', specific_logic)
        
        # Write script to file
        script_filename = f"{section5_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        # Make script executable
        os.chmod(script_filename, 0o755)
        
        scripts_generated_section5.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'filename': script_filename,
            'type': 'automated' if 'automated' in row['script_name'].lower() else 'manual'
        })
        
        if index < 10:  # Show first 10 for brevity
            print(f"Generated: {os.path.basename(script_filename)}")
        elif index == 10:
            print("... (continuing generation)")
        
    except Exception as e:
        failed_scripts_section5.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'error': str(e)
        })
        print(f"Failed to generate {row['id']}: {str(e)}")

print(f"\nSection 5 Generation Results:")
print(f"Successfully generated: {len(scripts_generated_section5)} scripts")
print(f"Failed to generate: {len(failed_scripts_section5)} scripts")

if failed_scripts_section5:
    print("\nFailed scripts:")
    for fail in failed_scripts_section5:
        print(f"  - {fail['id']}: {fail['error']}")

# Get final counts for verification
all_section5_scripts = glob.glob(f'{section5_dir}/*.sh')
print(f"Total Section 5 scripts in directory: {len(all_section5_scripts)}")

# Count by type
automated_scripts_section5 = [f for f in all_section5_scripts if 'automated' in f]
manual_scripts_section5 = [f for f in all_section5_scripts if 'manual' in f]

print(f"Automated scripts: {len(automated_scripts_section5)}")
print(f"Manual scripts: {len(manual_scripts_section5)}")

# Categorize scripts by functionality
rsyslog_scripts = [f for f in all_section5_scripts if '5.1.1.' in f]
journald_scripts = [f for f in all_section5_scripts if '5.1.2.' in f]
logrotate_scripts = [f for f in all_section5_scripts if '5.1.3' in f]
auditd_scripts = [f for f in all_section5_scripts if '5.2.' in f]

print(f"\n=== SECTION 5 BREAKDOWN BY CATEGORY ===")
print(f"Rsyslog Configuration (5.1.1.x): {len(rsyslog_scripts)} scripts")
print(f"Journald Configuration (5.1.2.x): {len(journald_scripts)} scripts")
print(f"Logrotate Configuration (5.1.3): {len(logrotate_scripts)} scripts")
print(f"Auditd Configuration (5.2.x): {len(auditd_scripts)} scripts")

print(f"\n✅ Section 5 script generation completed!")
print(f"All {len(all_section5_scripts)} scripts implement logging and auditing security measures.")