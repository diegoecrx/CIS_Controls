import pandas as pd
import os
import zipfile
import glob

# Read the new section2.xlsx file
df_section2 = pd.read_excel('section2.xlsx')

print("=== SECTION 2 EXCEL FILE STRUCTURE ===")
print(f"Shape: {df_section2.shape}")
print(f"Columns: {list(df_section2.columns)}")
print("\n=== FIRST FEW ROWS ===")
print(df_section2.head())

print("\n=== DATA TYPES ===")
print(df_section2.dtypes)

print("\n=== COLUMN ANALYSIS ===")
for col in df_section2.columns:
    print(f"\n--- {col} ---")
    print(f"Unique values: {df_section2[col].nunique()}")
    print(f"Sample values: {df_section2[col].dropna().head(3).tolist()}")

print("\n=== SCRIPT NAME PATTERNS ===")
automated_count = sum(1 for name in df_section2['script_name'] if 'automated' in name.lower())
manual_count = sum(1 for name in df_section2['script_name'] if 'manual' in name.lower())

print(f"Automated scripts: {automated_count}")
print(f"Manual scripts: {manual_count}")
print(f"Total scripts to generate: {len(df_section2)}")