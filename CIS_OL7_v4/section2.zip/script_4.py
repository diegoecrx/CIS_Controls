# Fix the failed scripts by looking at what IDs failed and checking their data
print("=== DEBUGGING FAILED SCRIPTS ===")

failed_ids_section2 = ['2.2.17', '2.2.18', '2.2.19', '2.2.20', '2.2.21', '2.2.22']

for failed_id in failed_ids_section2:
    row = df_section2[df_section2['id'] == failed_id].iloc[0]
    print(f"\n--- {failed_id} ---")
    print(f"script_name: {repr(row['script_name'])}")
    print(f"remediation: {repr(row['remediation'])}")

# Complete the specific logic for missing IDs
def get_specific_remediation_logic_section2_fixed(row_data):
    """Generate specific remediation logic based on Section 2 CIS control type - Fixed version"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Time synchronization controls (2.1.x)
    if script_id == '2.1.1':
        return '''
    # CIS 2.1.1: Ensure time synchronization is in use
    log_message "INFO" "Installing and configuring time synchronization with chrony"
    
    if manage_package "install" "chrony"; then
        if manage_service "enable" "chronyd"; then
            if manage_service "start" "chronyd"; then
                log_message "SUCCESS" "Chrony time synchronization configured and started"
            fi
        fi
    else
        log_message "ERROR" "Failed to install chrony package"
        return 1
    fi'''
    
    elif script_id == '2.1.2':
        return '''
    # CIS 2.1.2: Ensure chrony is configured
    config_file="/etc/chrony.conf"
    
    log_message "INFO" "Configuring chrony with appropriate time servers"
    
    # Backup chrony configuration
    if backup_file "/etc/chrony.conf"; then
        # Add or modify server entries
        if ! grep -q "^server\\|^pool" /etc/chrony.conf; then
            echo "# CIS 2.1.2: Configure time servers" >> /etc/chrony.conf
            echo "server 0.pool.ntp.org iburst" >> /etc/chrony.conf
            echo "server 1.pool.ntp.org iburst" >> /etc/chrony.conf
            log_message "SUCCESS" "Added NTP servers to chrony configuration"
        else
            log_message "INFO" "Time servers already configured in chrony.conf"
        fi
        
        # Restart chrony to apply changes
        if systemctl restart chronyd; then
            log_message "SUCCESS" "Chrony restarted with new configuration"
        else
            log_message "ERROR" "Failed to restart chrony service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to backup chrony configuration"
        return 1
    fi'''
    
    elif script_id == '2.1.3':
        return '''
    # CIS 2.1.3: Ensure chrony is not run as the root user
    config_file="/etc/sysconfig/chronyd"
    default_value="OPTIONS=\\"-u chrony\\""
    
    log_message "INFO" "Configuring chrony to run as non-root user"
    
    # Ensure chronyd runs as chrony user
    if [ -f /etc/sysconfig/chronyd ]; then
        backup_file "/etc/sysconfig/chronyd"
    fi
    
    # Set or update OPTIONS to run as chrony user
    echo 'OPTIONS="-u chrony"' > /etc/sysconfig/chronyd
    
    # Restart chrony service to apply changes
    if systemctl try-reload-or-restart chronyd; then
        log_message "SUCCESS" "Chrony configured to run as non-root user"
    else
        log_message "ERROR" "Failed to restart chrony service"
        return 1
    fi'''
    
    # Service removal controls (2.2.x) - Complete mapping
    elif script_id == '2.2.1':
        return '''
    # CIS 2.2.1: Ensure autofs services are not in use
    log_message "INFO" "Disabling autofs services"
    
    for service in autofs.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Autofs services have been disabled"'''
    
    elif script_id == '2.2.2':
        return '''
    # CIS 2.2.2: Ensure Avahi daemon services are not in use
    log_message "INFO" "Disabling Avahi daemon services"
    
    for service in avahi-daemon.service avahi-daemon.socket; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Avahi daemon services have been disabled"'''
    
    elif script_id == '2.2.3':
        return '''
    # CIS 2.2.3: Ensure DHCP server services are not in use
    log_message "INFO" "Disabling DHCP server services"
    
    for service in dhcpd.service dhcpd6.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "DHCP server services have been disabled"'''
    
    elif script_id == '2.2.4':
        return '''
    # CIS 2.2.4: Ensure DNS server services are not in use
    log_message "INFO" "Disabling DNS server services"
    
    for service in named.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "DNS server services have been disabled"'''
    
    elif script_id == '2.2.5':
        return '''
    # CIS 2.2.5: Ensure dnsmasq services are not in use
    log_message "INFO" "Disabling dnsmasq services"
    
    for service in dnsmasq.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Dnsmasq services have been disabled"'''
    
    elif script_id == '2.2.6':
        return '''
    # CIS 2.2.6: Ensure Samba file server services are not in use
    log_message "INFO" "Disabling Samba file server services"
    
    for service in smb.service nmb.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Samba file server services have been disabled"'''
    
    elif script_id == '2.2.7':
        return '''
    # CIS 2.2.7: Ensure FTP server services are not in use
    log_message "INFO" "Disabling FTP server services"
    
    for service in vsftpd.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "FTP server services have been disabled"'''
    
    elif script_id == '2.2.8':
        return '''
    # CIS 2.2.8: Ensure message access server services are not in use
    log_message "INFO" "Disabling message access server services"
    
    for service in dovecot.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Message access server services have been disabled"'''
    
    elif script_id == '2.2.9':
        return '''
    # CIS 2.2.9: Ensure network file system services are not in use
    log_message "INFO" "Disabling network file system services"
    
    for service in nfs-server.service nfs-utils.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Network file system services have been disabled"'''
    
    elif script_id == '2.2.10':
        return '''
    # CIS 2.2.10: Ensure NIS server services are not in use
    log_message "INFO" "Disabling NIS server services"
    
    for service in ypserv.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "NIS server services have been disabled"'''
    
    elif script_id == '2.2.11':
        return '''
    # CIS 2.2.11: Ensure print server services are not in use
    log_message "INFO" "Disabling print server services"
    
    for service in cups.service cups.socket cups.path; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Print server services have been disabled"'''
    
    elif script_id == '2.2.12':
        return '''
    # CIS 2.2.12: Ensure rpcbind services are not in use
    log_message "INFO" "Disabling rpcbind services"
    
    for service in rpcbind.service rpcbind.socket; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Rpcbind services have been disabled"'''
    
    elif script_id == '2.2.13':
        return '''
    # CIS 2.2.13: Ensure rsync services are not in use
    log_message "INFO" "Disabling rsync services"
    
    for service in rsync.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Rsync services have been disabled"'''
    
    elif script_id == '2.2.14':
        return '''
    # CIS 2.2.14: Ensure SNMP services are not in use
    log_message "INFO" "Disabling SNMP services"
    
    for service in snmpd.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "SNMP services have been disabled"'''
    
    elif script_id == '2.2.15':
        return '''
    # CIS 2.2.15: Ensure telnet server services are not in use
    log_message "INFO" "Disabling telnet server services"
    
    for service in telnet.socket; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Telnet server services have been disabled"'''
    
    elif script_id == '2.2.16':
        return '''
    # CIS 2.2.16: Ensure TFTP server services are not in use
    log_message "INFO" "Disabling TFTP server services"
    
    for service in tftp.socket; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "TFTP server services have been disabled"'''
    
    # Now handle the failed ones that need specific logic
    elif script_id == '2.2.17':
        return '''
    # CIS 2.2.17: Ensure mail transfer agents are configured for local-only mode
    config_file="/etc/postfix/main.cf"
    
    log_message "INFO" "Configuring mail transfer agent for local-only mode"
    
    # Configure Postfix for local-only delivery
    if [ -f /etc/postfix/main.cf ]; then
        backup_file "/etc/postfix/main.cf"
        
        # Set inet_interfaces to loopback-only
        if grep -q "^inet_interfaces" /etc/postfix/main.cf; then
            sed -i 's/^inet_interfaces.*/inet_interfaces = loopback-only/' /etc/postfix/main.cf
        else
            echo "inet_interfaces = loopback-only" >> /etc/postfix/main.cf
        fi
        
        # Restart postfix service
        if systemctl restart postfix; then
            log_message "SUCCESS" "Postfix configured for local-only mode"
        else
            log_message "ERROR" "Failed to restart postfix service"
            return 1
        fi
    else
        log_message "WARNING" "Postfix configuration file not found"
    fi'''
    
    elif script_id == '2.2.18':
        return '''
    # CIS 2.2.18: Ensure web proxy server services are not in use
    log_message "INFO" "Disabling web proxy server services"
    
    for service in squid.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Web proxy server services have been disabled"'''
    
    elif script_id == '2.2.19':
        return '''
    # CIS 2.2.19: Ensure web server services are not in use
    log_message "INFO" "Disabling web server services"
    
    for service in httpd.service nginx.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Web server services have been disabled"'''
    
    elif script_id == '2.2.20':
        return '''
    # CIS 2.2.20: Ensure xinetd services are not in use
    log_message "INFO" "Disabling xinetd services"
    
    for service in xinetd.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "Xinetd services have been disabled"'''
    
    elif script_id == '2.2.21':
        return '''
    # CIS 2.2.21: Ensure X Window System is not installed
    log_message "INFO" "Removing X Window System packages"
    
    # List of X11 packages to remove
    x11_packages="xorg-x11-server-common xorg-x11-server-Xorg"
    
    for package in $x11_packages; do
        if rpm -q "$package" >/dev/null 2>&1; then
            if manage_package "remove" "$package"; then
                log_message "SUCCESS" "Removed X11 package: $package"
            fi
        else
            log_message "INFO" "X11 package not installed: $package"
        fi
    done
    
    log_message "SUCCESS" "X Window System packages have been removed"'''
    
    elif script_id == '2.2.22':
        return '''
    # CIS 2.2.22: Ensure network time protocol is configured
    config_file="/etc/chrony.conf"
    
    log_message "INFO" "Verifying NTP is properly configured"
    
    # This is covered by 2.1.x controls, so we verify the configuration
    if systemctl is-active chronyd >/dev/null 2>&1; then
        if grep -q "^server\\|^pool" /etc/chrony.conf; then
            log_message "SUCCESS" "NTP is properly configured via chrony"
        else
            log_message "WARNING" "Chrony is running but no time servers configured"
            return 2
        fi
    else
        log_message "ERROR" "Chrony service is not running"
        return 1
    fi'''
    
    # Client package removal (2.3.x)
    elif script_id == '2.3.1':
        return '''
    # CIS 2.3.1: Ensure FTP client is not installed
    log_message "INFO" "Removing FTP client packages"
    
    if manage_package "remove" "ftp"; then
        log_message "SUCCESS" "FTP client package removed"
    else
        log_message "INFO" "FTP client package not installed"
    fi'''
    
    elif script_id == '2.3.2':
        return '''
    # CIS 2.3.2: Ensure LDAP client is not installed
    log_message "INFO" "Removing LDAP client packages"
    
    if manage_package "remove" "openldap-clients"; then
        log_message "SUCCESS" "LDAP client packages removed"
    else
        log_message "INFO" "LDAP client packages not installed"
    fi'''
    
    elif script_id == '2.3.3':
        return '''
    # CIS 2.3.3: Ensure NIS client is not installed
    log_message "INFO" "Removing NIS client packages"
    
    if manage_package "remove" "ypbind"; then
        log_message "SUCCESS" "NIS client packages removed"
    else
        log_message "INFO" "NIS client packages not installed"
    fi'''
    
    elif script_id == '2.3.4':
        return '''
    # CIS 2.3.4: Ensure telnet client is not installed
    log_message "INFO" "Removing telnet client packages"
    
    if manage_package "remove" "telnet"; then
        log_message "SUCCESS" "Telnet client packages removed"
    else
        log_message "INFO" "Telnet client packages not installed"
    fi'''
    
    elif script_id == '2.3.5':
        return '''
    # CIS 2.3.5: Ensure TFTP client is not installed
    log_message "INFO" "Removing TFTP client packages"
    
    if manage_package "remove" "tftp"; then
        log_message "SUCCESS" "TFTP client packages removed"
    else
        log_message "INFO" "TFTP client packages not installed"
    fi'''
    
    # Default case
    else:
        return f'''
    # CIS {script_id}: Section 2 remediation
    config_file=""
    
    log_message "INFO" "Applying remediation for: {script_id}"
    log_message "INFO" "Remediation steps: {remediation[:200] if remediation else 'See CIS benchmark documentation'}"
    
    # TODO: Implement specific remediation logic for this CIS control
    # Description: {description}
    
    log_message "WARNING" "Specific remediation logic needs to be implemented for this control"
    return 2  # Manual intervention may be required'''

print("\nFixed remediation logic function created. Now generating failed scripts...")

# Generate the failed scripts with the fixed logic
for failed_id in failed_ids_section2:
    try:
        row = df_section2[df_section2['id'] == failed_id].iloc[0]
        
        # Generate base script
        script_content = generate_script_template_section2(row.to_dict())
        
        # Get specific remediation logic with fixed function
        specific_logic = get_specific_remediation_logic_section2_fixed(row.to_dict())
        
        # Insert the specific logic into the template
        script_content = script_content.replace(
            '    # TODO: Add specific remediation logic here based on the CIS control\n    # This will be customized for each specific script',
            specific_logic
        )
        
        # Write script to file
        script_filename = f"{section2_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        os.chmod(script_filename, 0o755)
        print(f"Fixed and generated: {script_filename}")
        
        # Update our success list
        scripts_generated_section2.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'filename': script_filename,
            'type': 'automated'
        })
        
    except Exception as e:
        print(f"Still failed to generate {failed_id}: {str(e)}")

print(f"\nFinal Section 2 Generation Results:")
print(f"Total scripts now generated: {len(glob.glob(f'{section2_dir}/*.sh'))}")