# Create a comprehensive summary and package for Section 2
print("=== SECTION 2 GENERATION COMPLETE ===")

# Get final counts
all_section2_scripts = glob.glob(f'{section2_dir}/*.sh')
print(f"Total Section 2 scripts generated: {len(all_section2_scripts)}")

# Count by type
automated_scripts_section2 = [f for f in all_section2_scripts if 'automated' in f]
manual_scripts_section2 = [f for f in all_section2_scripts if 'manual' in f]

print(f"Automated scripts: {len(automated_scripts_section2)}")
print(f"Manual scripts: {len(manual_scripts_section2)}")

# Create a comprehensive summary
section2_summary = {
    'total_rows_processed': len(df_section2),
    'scripts_generated': len(all_section2_scripts),
    'automated_scripts': len(automated_scripts_section2),
    'manual_scripts': len(manual_scripts_section2),
    'success_rate': f"{(len(all_section2_scripts)/len(df_section2))*100:.1f}%"
}

print(f"\n=== SECTION 2 SUMMARY ===")
for key, value in section2_summary.items():
    print(f"{key}: {value}")

print(f"\n=== SECTION 2 SCRIPT CATEGORIES ===")
categories_section2 = {
    "Time Synchronization (2.1.x)": "NTP/Chrony configuration and security",
    "Service Removal (2.2.x)": "Disable unnecessary network services",
    "Client Package Removal (2.3.x)": "Remove unnecessary client packages"
}

for category, description in categories_section2.items():
    print(f"✓ {category}: {description}")

# Create README for Section 2
readme_section2 = f"""# Oracle Linux 7 CIS Benchmark Section 2 - Services

## Overview
This package contains {len(all_section2_scripts)} bash scripts for CIS Oracle Linux 7 Benchmark Section 2 controls. These scripts focus on securing system services and removing unnecessary network services.

## Script Statistics
- **Total Scripts**: {len(all_section2_scripts)}
- **Automated Scripts**: {len(automated_scripts_section2)}
- **Manual Scripts**: {len(manual_scripts_section2)}
- **Success Rate**: {(len(all_section2_scripts)/len(df_section2))*100:.1f}%

## Categories

### Time Synchronization (2.1.x)
- **2.1.1**: Install and configure time synchronization
- **2.1.2**: Configure chrony with appropriate servers
- **2.1.3**: Ensure chrony runs as non-root user

### Service Security (2.2.x)
Scripts to disable or secure unnecessary network services:
- **Autofs, Avahi, DHCP, DNS**: Network infrastructure services
- **FTP, HTTP, Mail, Samba**: File and web services  
- **NIS, LDAP, Telnet, SNMP**: Legacy and insecure services
- **Print, RPC, X11**: Desktop and legacy services

### Client Package Removal (2.3.x)
- **FTP, LDAP, NIS, Telnet, TFTP**: Remove unnecessary client packages

## Key Features

✅ **Service Management**: Stop, disable, and mask services
✅ **Package Management**: Remove unnecessary packages safely
✅ **Configuration Security**: Secure service configurations
✅ **Comprehensive Logging**: Detailed operation tracking
✅ **Backup Protection**: Automatic backup before changes
✅ **Error Handling**: Robust error detection and recovery

## Usage Examples

### Automated Scripts
```bash
# Configure time synchronization
sudo ./2.1.1_time_synchronization_is_in_use_automated.sh

# Disable FTP services
sudo ./2.2.7_ftp_server_services_automated.sh

# Remove telnet client
sudo ./2.3.4_telnet_client_not_installed_automated.sh
```

### Manual Scripts
```bash
# Interactive service management
sudo ./2.2.22_only_approved_services_listening_on_a_network_interface_manual.sh
```

## Service Impact Considerations

⚠️ **Important Notes**:
- Scripts will stop and disable services that may be in use
- Some services may have package dependencies
- Review service usage before running scripts
- Test in non-production environment first
- Check logs for any warnings or errors

## Generated Scripts

{chr(10).join([f"- {os.path.basename(script)}" for script in sorted(all_section2_scripts)])}

---
*Section 2 scripts generated from CIS Oracle Linux 7 Benchmark*
*Generation completed: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""

# Write README
with open(f'{section2_dir}/README.md', 'w') as f:
    f.write(readme_section2)

# Update the summary CSV with all scripts
all_section2_script_data = []
for script_file in all_section2_scripts:
    script_name = os.path.basename(script_file).replace('.sh', '')
    script_type = 'automated' if 'automated' in script_name else 'manual'
    script_id = script_name.split('_')[0]
    
    all_section2_script_data.append({
        'id': script_id,
        'script_name': script_name,
        'filename': script_file,
        'type': script_type
    })

final_summary_df_section2 = pd.DataFrame(all_section2_script_data)
final_summary_df_section2.to_csv(f'{section2_dir}/section2_final_summary.csv', index=False)

print(f"\n=== DELIVERABLES (Section 2 Only) ===")
print(f"📁 {section2_dir}/ - Directory containing all Section 2 scripts")
print(f"📊 section2_final_summary.csv - Complete script inventory")
print(f"📋 README.md - Section 2 documentation")
print(f"🔧 {len(all_section2_scripts)} bash scripts ready for use")

print(f"\n=== SECTION 2 SCRIPT LIST ===")
for script in sorted(all_section2_scripts):
    basename = os.path.basename(script)
    script_type = "AUTO" if 'automated' in basename else "MANUAL"
    print(f"[{script_type}] {basename}")

print("\n✅ Section 2 script generation completed successfully!")
print("All scripts follow the same template structure with comprehensive error handling,")
print("logging, backup functionality, and service management capabilities.")