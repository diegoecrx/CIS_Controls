# Generate all Section 2 scripts
scripts_generated_section2 = []
failed_scripts_section2 = []

for index, row in df_section2.iterrows():
    try:
        # Generate base script
        script_content = generate_script_template_section2(row.to_dict())
        
        # Get specific remediation logic
        specific_logic = get_specific_remediation_logic_section2(row.to_dict())
        
        # Insert the specific logic into the template
        if 'automated' in row['script_name'].lower():
            # Replace the TODO comment in automated scripts
            script_content = script_content.replace(
                '    # TODO: Add specific remediation logic here based on the CIS control\n    # This will be customized for each specific script',
                specific_logic
            )
        else:
            # Replace the TODO comment in manual scripts
            script_content = script_content.replace(
                '    # TODO: Add specific manual remediation logic here\n    # This will be customized for each specific script',
                specific_logic
            )
            
            # Also update the show commands section for manual scripts
            show_commands_logic = specific_logic.replace('log_message', 'echo "# Command:"').replace('if ', 'echo "if ')
            script_content = script_content.replace(
                '    # TODO: Add specific command display logic here\n    # This will show the exact commands without executing them',
                f'    echo "The following remediation would be performed:"\\n{show_commands_logic}'
            )
        
        # Write script to file
        script_filename = f"{section2_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        # Make script executable
        os.chmod(script_filename, 0o755)
        
        scripts_generated_section2.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'filename': script_filename,
            'type': 'automated' if 'automated' in row['script_name'].lower() else 'manual'
        })
        
        print(f"Generated: {script_filename}")
        
    except Exception as e:
        failed_scripts_section2.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'error': str(e)
        })
        print(f"Failed to generate {row['id']}: {str(e)}")

print(f"\nSection 2 Generation Results:")
print(f"Successfully generated: {len(scripts_generated_section2)} scripts")
print(f"Failed to generate: {len(failed_scripts_section2)} scripts")

if failed_scripts_section2:
    print("\nFailed scripts:")
    for fail in failed_scripts_section2:
        print(f"  - {fail['id']}: {fail['error']}")

# Create summary for Section 2
summary_data_section2 = []
for script in scripts_generated_section2:
    summary_data_section2.append(script)
    
summary_df_section2 = pd.DataFrame(summary_data_section2)
summary_df_section2.to_csv(f'{section2_dir}/section2_script_generation_summary.csv', index=False)

print(f"\nSection 2 scripts summary:")
print(summary_df_section2.groupby('type').size())

# List all generated files
print(f"\nAll Section 2 scripts generated:")
for script in scripts_generated_section2:
    print(f"  - {os.path.basename(script['filename'])}")