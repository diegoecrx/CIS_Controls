# Oracle Linux 7 CIS Benchmark Section 2 - Services

## Overview
This package contains 30 bash scripts for CIS Oracle Linux 7 Benchmark Section 2 controls. These scripts focus on securing system services and removing unnecessary network services.

## Script Statistics
- **Total Scripts**: 30
- **Automated Scripts**: 29
- **Manual Scripts**: 1
- **Success Rate**: 100.0%

## Categories

### Time Synchronization (2.1.x)
- **2.1.1**: Install and configure time synchronization
- **2.1.2**: Configure chrony with appropriate servers
- **2.1.3**: Ensure chrony runs as non-root user

### Service Security (2.2.x)
Scripts to disable or secure unnecessary network services:
- **Autofs, Avahi, DHCP, DNS**: Network infrastructure services
- **FTP, HTTP, Mail, Samba**: File and web services  
- **NIS, LDAP, Telnet, SNMP**: Legacy and insecure services
- **Print, RPC, X11**: Desktop and legacy services

### Client Package Removal (2.3.x)
- **FTP, LDAP, NIS, Telnet, TFTP**: Remove unnecessary client packages

## Key Features

✅ **Service Management**: Stop, disable, and mask services
✅ **Package Management**: Remove unnecessary packages safely
✅ **Configuration Security**: Secure service configurations
✅ **Comprehensive Logging**: Detailed operation tracking
✅ **Backup Protection**: Automatic backup before changes
✅ **Error Handling**: Robust error detection and recovery

## Usage Examples

### Automated Scripts
```bash
# Configure time synchronization
sudo ./2.1.1_time_synchronization_is_in_use_automated.sh

# Disable FTP services
sudo ./2.2.7_ftp_server_services_automated.sh

# Remove telnet client
sudo ./2.3.4_telnet_client_not_installed_automated.sh
```

### Manual Scripts
```bash
# Interactive service management
sudo ./2.2.22_only_approved_services_listening_on_a_network_interface_manual.sh
```

## Service Impact Considerations

⚠️ **Important Notes**:
- Scripts will stop and disable services that may be in use
- Some services may have package dependencies
- Review service usage before running scripts
- Test in non-production environment first
- Check logs for any warnings or errors

## Generated Scripts

- 2.1.1_time_synchronization_is_in_use_automated.sh
- 2.1.2_chrony_automated.sh
- 2.1.3_chrony_not_run_as_the_root_user_automated.sh
- 2.2.10_nis_server_services_automated.sh
- 2.2.11_print_server_services_automated.sh
- 2.2.12_rpcbind_services_automated.sh
- 2.2.13_rsync_services_automated.sh
- 2.2.14_snmp_services_automated.sh
- 2.2.15_telnet_server_services_automated.sh
- 2.2.16_tftp_server_services_automated.sh
- 2.2.17_web_proxy_server_services_automated.sh
- 2.2.18_web_server_services_automated.sh
- 2.2.19_xinetd_services_automated.sh
- 2.2.1_autofs_services_automated.sh
- 2.2.20_x_window_server_services_automated.sh
- 2.2.21_mail_transfer_agents_for_local-only_mode_automated.sh
- 2.2.22_only_approved_services_listening_on_a_network_interface_manual.sh
- 2.2.2_avahi_daemon_services_automated.sh
- 2.2.3_dhcp_server_services_automated.sh
- 2.2.4_dns_server_services_automated.sh
- 2.2.5_dnsmasq_services_automated.sh
- 2.2.6_samba_file_server_services_automated.sh
- 2.2.7_ftp_server_services_automated.sh
- 2.2.8_message_access_server_services_automated.sh
- 2.2.9_network_file_system_services_automated.sh
- 2.3.1_ftp_client_not_installed_automated.sh
- 2.3.2_ldap_client_not_installed_automated.sh
- 2.3.3_nis_client_not_installed_automated.sh
- 2.3.4_telnet_client_not_installed_automated.sh
- 2.3.5_tftp_client_not_installed_automated.sh

---
*Section 2 scripts generated from CIS Oracle Linux 7 Benchmark*
*Generation completed: 2025-10-16 02:27:51*
