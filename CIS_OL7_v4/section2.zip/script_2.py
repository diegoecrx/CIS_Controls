# Now create specific remediation logic for Section 2 CIS controls
def get_specific_remediation_logic_section2(row_data):
    """Generate specific remediation logic based on Section 2 CIS control type"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Time synchronization controls (2.1.x)
    if script_id == '2.1.1':
        return '''
    # CIS 2.1.1: Ensure time synchronization is in use
    log_message "INFO" "Installing and configuring time synchronization with chrony"
    
    if manage_package "install" "chrony"; then
        if manage_service "enable" "chronyd"; then
            if manage_service "start" "chronyd"; then
                log_message "SUCCESS" "Chrony time synchronization configured and started"
            fi
        fi
    else
        log_message "ERROR" "Failed to install chrony package"
        return 1
    fi'''
    
    elif script_id == '2.1.2':
        return '''
    # CIS 2.1.2: Ensure chrony is configured
    config_file="/etc/chrony.conf"
    
    log_message "INFO" "Configuring chrony with appropriate time servers"
    
    # Backup chrony configuration
    if backup_file "/etc/chrony.conf"; then
        # Add or modify server entries
        if ! grep -q "^server\\|^pool" /etc/chrony.conf; then
            echo "# CIS 2.1.2: Configure time servers" >> /etc/chrony.conf
            echo "server 0.pool.ntp.org iburst" >> /etc/chrony.conf
            echo "server 1.pool.ntp.org iburst" >> /etc/chrony.conf
            log_message "SUCCESS" "Added NTP servers to chrony configuration"
        else
            log_message "INFO" "Time servers already configured in chrony.conf"
        fi
        
        # Restart chrony to apply changes
        if systemctl restart chronyd; then
            log_message "SUCCESS" "Chrony restarted with new configuration"
        else
            log_message "ERROR" "Failed to restart chrony service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to backup chrony configuration"
        return 1
    fi'''
    
    elif script_id == '2.1.3':
        return '''
    # CIS 2.1.3: Ensure chrony is not run as the root user
    config_file="/etc/sysconfig/chronyd"
    default_value="OPTIONS=\\"-u chrony\\""
    
    log_message "INFO" "Configuring chrony to run as non-root user"
    
    # Ensure chronyd runs as chrony user
    if [ -f /etc/sysconfig/chronyd ]; then
        backup_file "/etc/sysconfig/chronyd"
    fi
    
    # Set or update OPTIONS to run as chrony user
    echo 'OPTIONS="-u chrony"' > /etc/sysconfig/chronyd
    
    # Restart chrony service to apply changes
    if systemctl try-reload-or-restart chronyd; then
        log_message "SUCCESS" "Chrony configured to run as non-root user"
    else
        log_message "ERROR" "Failed to restart chrony service"
        return 1
    fi'''
    
    # Service removal controls (2.2.x)
    elif script_id.startswith('2.2.'):
        service_mappings = {
            '2.2.1': ('autofs', 'autofs.service'),
            '2.2.2': ('avahi', 'avahi-daemon.service'),
            '2.2.3': ('dhcp', 'dhcpd.service'),
            '2.2.4': ('bind', 'named.service'),
            '2.2.5': ('vsftpd', 'vsftpd.service'),
            '2.2.6': ('httpd', 'httpd.service'),
            '2.2.7': ('dovecot', 'dovecot.service'),
            '2.2.8': ('samba', 'smb.service'),
            '2.2.9': ('squid', 'squid.service'),
            '2.2.10': ('ypserv', 'ypserv.service'),
            '2.2.11': ('rsh-server', 'rsh.socket'),
            '2.2.12': ('talk-server', 'ntalk.service'),
            '2.2.13': ('telnet-server', 'telnet.socket'),
            '2.2.14': ('tftp-server', 'tftp.socket'),
            '2.2.15': ('rsync', 'rsync.service'),
            '2.2.16': ('net-snmp', 'snmpd.service')
        }
        
        if script_id in service_mappings:
            package, service = service_mappings[script_id]
            return f'''
    # CIS {script_id}: Remove/disable {package} service
    log_message "INFO" "Removing/disabling {package} service"
    
    # Stop the service if running
    if systemctl is-active {service} >/dev/null 2>&1; then
        if manage_service "stop" "{service}"; then
            log_message "SUCCESS" "Stopped {service}"
        fi
    fi
    
    # Disable the service
    if manage_service "disable" "{service}"; then
        log_message "SUCCESS" "Disabled {service}"
    fi
    
    # Mask the service to prevent accidental start
    if manage_service "mask" "{service}"; then
        log_message "SUCCESS" "Masked {service}"
    fi
    
    # Optionally remove the package (commented out to avoid dependency issues)
    # if manage_package "remove" "{package}"; then
    #     log_message "SUCCESS" "Removed {package} package"
    # fi
    
    log_message "SUCCESS" "{package} service has been secured"'''
    
    # Special cases for certain services
    elif script_id == '2.2.17':  # NIS client
        return '''
    # CIS 2.2.17: Ensure NIS client is not in use
    log_message "INFO" "Disabling NIS client services"
    
    # Stop and disable ypbind service
    for service in ypbind.service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    # Remove ypbind package if not needed
    # manage_package "remove" "ypbind"
    
    log_message "SUCCESS" "NIS client services have been disabled"'''
    
    elif script_id == '2.2.18':  # Telnet client
        return '''
    # CIS 2.2.18: Ensure telnet client is not in use
    log_message "INFO" "Removing telnet client"
    
    if manage_package "remove" "telnet"; then
        log_message "SUCCESS" "Telnet client package removed"
    else
        log_message "INFO" "Telnet client package not installed"
    fi'''
    
    elif script_id == '2.2.19':  # LDAP client
        return '''
    # CIS 2.2.19: Ensure LDAP client is not in use
    log_message "INFO" "Removing LDAP client packages"
    
    # Remove openldap-clients package
    if manage_package "remove" "openldap-clients"; then
        log_message "SUCCESS" "LDAP client packages removed"
    else
        log_message "INFO" "LDAP client packages not installed"
    fi'''
    
    elif script_id == '2.2.20':  # RPC
        return '''
    # CIS 2.2.20: Ensure RPC is not in use
    log_message "INFO" "Disabling RPC services"
    
    # Stop and disable rpcbind service
    for service in rpcbind.service rpcbind.socket; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            manage_service "stop" "$service"
        fi
        manage_service "disable" "$service"
        manage_service "mask" "$service"
    done
    
    log_message "SUCCESS" "RPC services have been disabled"'''
    
    # Default case for unknown controls
    else:
        return f'''
    # CIS {script_id}: Section 2 remediation
    config_file=""
    
    log_message "INFO" "Applying remediation for: {script_id}"
    log_message "INFO" "Remediation steps: {remediation[:200] if remediation else 'See CIS benchmark documentation'}"
    
    # TODO: Implement specific remediation logic for this CIS control
    # Description: {description}
    
    log_message "WARNING" "Specific remediation logic needs to be implemented for this control"
    return 2  # Manual intervention may be required'''

# Test the specific logic generation
test_logic = get_specific_remediation_logic_section2(df_section2.iloc[0].to_dict())
print("Sample specific remediation logic:")
print(test_logic)