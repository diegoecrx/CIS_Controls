# Oracle Linux 7 CIS Benchmark Remediation Scripts

## Overview
This package contains 70 bash scripts generated automatically from the CIS Oracle Linux 7 Benchmark spreadsheet. Each script implements specific CIS controls with comprehensive error handling, logging, and backup functionality.

## Script Statistics
- **Total Scripts**: 70
- **Automated Scripts**: 66 
- **Manual Scripts**: 4
- **Success Rate**: 100.0%

## Script Categories

- **Kernel Module Controls**: 1.1.1.x - Disable unnecessary filesystem kernel modules
- **Partition Security**: 1.1.2.x - Secure partition mounting options
- **Package Management**: 1.2.x - GPG verification and repository management
- **Bootloader Security**: 1.3.x - Bootloader password and permissions
- **Kernel Parameters**: 1.4.x - ASLR, ptrace restrictions, core dumps
- **SELinux Configuration**: 1.5.1.x - SELinux installation, mode, and policy
- **Warning Banners**: 1.6.x - Login banners and access messages
- **GUI Security**: 1.7.x - GNOME Display Manager configuration

## Features

✓ Comprehensive error handling and logging
✓ Automatic backup creation before modifications
✓ Profile-based configuration (Level 1/2, Server/Workstation)
✓ Automated execution for 'automated' scripts
✓ Interactive menu for 'manual' scripts
✓ Root privilege verification
✓ Configuration file validation
✓ Service and package management functions
✓ Kernel module blacklisting capabilities
✓ Detailed success/error reporting

## Usage

### Automated Scripts
```bash
sudo ./script_name_automated.sh
```
- Automatically applies remediation
- Creates backups before changes
- Comprehensive logging

### Manual Scripts  
```bash
sudo ./script_name_manual.sh
```
- Interactive menu system
- Option to show commands without execution
- User-controlled remediation

## Parameters

Each script includes these configurable parameters:
- `config_file`: Target configuration file path
- `profile_srv`: Server profile level (Level 1/2)
- `profile_workstation`: Workstation profile level (Level 1/2) 
- `default_value`: CIS recommended default value

## Logging

- **General Logs**: `/var/log/cis_remediation.log`
- **Error Logs**: `/var/log/cis_error_analysis.log`
- **Backups**: `/tmp/cis_backup/`

## Template Structure

All scripts are based on the provided template (`5.3.10_ssh_root_login_disabled.sh`) and include:
- Comprehensive error handling
- Automatic backup functionality
- Detailed logging with timestamps
- Service and package management functions
- Configuration file editing with validation
- Root privilege verification

## Generated Files

### Script Files (70 files)
- 1.1.1.1_cramfs_kernel_module_not_available_automated.sh
- 1.1.1.2_freevxfs_kernel_module_not_available_automated.sh
- 1.1.1.3_hfs_kernel_module_not_available_automated.sh
- 1.1.1.4_hfsplus_kernel_module_not_available_automated.sh
- 1.1.1.5_jffs2_kernel_module_not_available_automated.sh
- 1.1.1.6_squashfs_kernel_module_not_available_automated.sh
- 1.1.1.7_udf_kernel_module_not_available_automated.sh
- 1.1.1.8_usb-storage_kernel_module_not_available_automated.sh
- 1.1.2.1.1_tmp_is_a_separate_partition_automated.sh
- 1.1.2.1.2_nodev_option_set_on_tmp_partition_automated.sh
- 1.1.2.1.3_nosuid_option_set_on_tmp_partition_automated.sh
- 1.1.2.1.4_noexec_option_set_on_tmp_partition_automated.sh
- 1.1.2.2.1_dev_shm_is_a_separate_partition_automated.sh
- 1.1.2.2.2_nodev_option_set_on_dev_shm_partition_automated.sh
- 1.1.2.2.3_nosuid_option_set_on_dev_shm_partition_automated.sh
- 1.1.2.2.4_noexec_option_set_on_dev_shm_partition_automated.sh
- 1.1.2.3.1_separate_partition_exists_for_home_automated.sh
- 1.1.2.3.2_nodev_option_set_on_home_partition_automated.sh
- 1.1.2.3.3_nosuid_option_set_on_home_partition_automated.sh
- 1.1.2.4.1_separate_partition_exists_for_var_automated.sh
- 1.1.2.4.2_nodev_option_set_on_var_partition_automated.sh
- 1.1.2.4.3_nosuid_option_set_on_var_partition_automated.sh
- 1.1.2.5.1_separate_partition_exists_for_var_tmp_automated.sh
- 1.1.2.5.2_nodev_option_set_on_var_tmp_partition_automated.sh
- 1.1.2.5.3_nosuid_option_set_on_var_tmp_partition_automated.sh
- 1.1.2.5.4_noexec_option_set_on_var_tmp_partition_automated.sh
- 1.1.2.6.1_separate_partition_exists_for_var_log_automated.sh
- 1.1.2.6.2_nodev_option_set_on_var_log_partition_automated.sh
- 1.1.2.6.3_nosuid_option_set_on_var_log_partition_automated.sh
- 1.1.2.6.4_noexec_option_set_on_var_log_partition_automated.sh
- 1.1.2.7.1_separate_partition_exists_for_var_log_audit_automated.sh
- 1.1.2.7.2_nodev_option_set_on_var_log_audit_partition_automated.sh
- 1.1.2.7.3_nosuid_option_set_on_var_log_audit_partition_automated.sh
- 1.1.2.7.4_noexec_option_set_on_var_log_audit_partition_automated.sh
- 1.2.1_gpg_keys_manual.sh
- 1.2.2_gpgcheck_is_globally_activated_automated.sh
- 1.2.3_repo_gpgcheck_is_globally_activated_manual.sh
- 1.2.4_package_manager_repositories_manual.sh
- 1.2.5_updates,_patches,_and_additional_security_software_installed_manual.sh
- 1.3.1_bootloader_password_is_set_automated.sh
- 1.3.2_permissions_on_bootloader_config_automated.sh
- 1.3.3_authentication_required_for_single_user_mode_automated.sh
- 1.4.1_address_space_layout_randomization_aslr_is_enabled_automated.sh
- 1.4.2_ptrace_scope_is_restricted_automated.sh
- 1.4.3_core_dump_backtraces_disabled_automated.sh
- 1.4.4_core_dump_storage_is_disabled_automated.sh
- 1.5.1.1_selinux_is_installed_automated.sh
- 1.5.1.2_selinux_not_disabled_in_bootloader_configuration_automated.sh
- 1.5.1.3_selinux_policy_automated.sh
- 1.5.1.4_the_selinux_mode_not_disabled_automated.sh
- 1.5.1.5_the_selinux_mode_is_enforcing_automated.sh
- 1.5.1.6_no_unconfined_services_exist_automated.sh
- 1.5.1.7_the_mcs_translation_service_mcstrans_not_installed_automated.sh
- 1.5.1.8_setroubleshoot_not_installed_automated.sh
- 1.6.1_message_of_the_day_properly_automated.sh
- 1.6.2_local_login_warning_banner_properly_automated.sh
- 1.6.3_remote_login_warning_banner_properly_automated.sh
- 1.6.4_access_to_etc_motd_automated.sh
- 1.6.5_access_to_etc_issue_automated.sh
- 1.6.6_access_to_etc_issue.net_automated.sh
- 1.7.10_xdmcp_not_enabled_automated.sh
- 1.7.1_gnome_display_manager_is_removed_automated.sh
- 1.7.2_gdm_login_banner_automated.sh
- 1.7.3_gdm_disable-user-list_option_is_enabled_automated.sh
- 1.7.4_gdm_screen_locks_when_the_user_is_idle_automated.sh
- 1.7.5_gdm_screen_locks_cannot_be_overridden_automated.sh
- 1.7.6_gdm_automatic_mounting_of_removable_media_is_disabled_automated.sh
- 1.7.7_gdm_disabling_automatic_mounting_of_removable_media_not_overridden_automated.sh
- 1.7.8_gdm_autorun-never_is_enabled_automated.sh
- 1.7.9_gdm_autorun-never_not_overridden_automated.sh

### Supporting Files
- `script_analysis.csv`: Detailed analysis of each CIS control
- `script_generation_summary.csv`: Generation process summary
- `original_template.sh`: Original template file for reference

## Important Notes

1. **Run as Root**: All scripts require root privileges
2. **Test First**: Test scripts in a non-production environment
3. **Review Logs**: Check logs for any issues or warnings
4. **Backup Policy**: Scripts automatically backup modified files
5. **Manual Review**: Some controls may require manual intervention

## Support

For issues or questions regarding specific CIS controls, refer to the official CIS Oracle Linux 7 Benchmark documentation.

---
*Scripts generated automatically from Oracle Linux 7 CIS Benchmark spreadsheet*
*Generation completed: 2025-10-15 20:48:11*
