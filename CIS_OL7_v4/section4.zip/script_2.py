# Create specific remediation logic for Section 4 CIS controls
def get_specific_remediation_logic_section4(row_data):
    """Generate specific remediation logic based on Section 4 CIS control type"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Cron Configuration (4.1.1.x)
    if script_id == '4.1.1.1':
        return '''
    # CIS 4.1.1.1: Ensure cron daemon is enabled and active
    log_message "INFO" "Configuring cron daemon to be enabled and active"
    
    # Unmask cron service if masked
    if manage_service "unmask" "crond"; then
        log_message "SUCCESS" "Cron service unmasked"
    fi
    
    # Enable cron service
    if manage_service "enable" "crond"; then
        # Start cron service
        if manage_service "start" "crond"; then
            log_message "SUCCESS" "Cron daemon is now enabled and active"
        else
            log_message "ERROR" "Failed to start cron daemon"
            return 1
        fi
    else
        log_message "ERROR" "Failed to enable cron daemon"
        return 1
    fi'''
    
    elif script_id.startswith('4.1.1.') and script_id != '4.1.1.1':
        # Cron directory/file permissions (4.1.1.2 through 4.1.1.8)
        path_mappings = {
            '4.1.1.2': ('/etc/crontab', '600', 'root', 'root'),
            '4.1.1.3': ('/etc/cron.hourly', '700', 'root', 'root'),
            '4.1.1.4': ('/etc/cron.daily', '700', 'root', 'root'),
            '4.1.1.5': ('/etc/cron.weekly', '700', 'root', 'root'),
            '4.1.1.6': ('/etc/cron.monthly', '700', 'root', 'root'),
            '4.1.1.7': ('/etc/cron.d', '700', 'root', 'root'),
            '4.1.1.8': ('/etc/cron.allow', '640', 'root', 'root')
        }
        
        if script_id in path_mappings:
            target_path, permissions, owner, group = path_mappings[script_id]
            return f'''
    # CIS {script_id}: Configure permissions on {target_path}
    config_file="{target_path}"
    
    log_message "INFO" "Setting proper permissions on {target_path}"
    
    # Create file if it doesn't exist (for cron.allow)
    if [ "{target_path}" = "/etc/cron.allow" ] && [ ! -f "{target_path}" ]; then
        touch "{target_path}"
        log_message "INFO" "Created {target_path}"
    fi
    
    # Set permissions and ownership
    if set_permissions "{target_path}" "{permissions}" "{owner}" "{group}"; then
        log_message "SUCCESS" "Configured {target_path} with proper permissions"
        
        # Verify permissions
        actual_perms=$(stat -c "%a" "{target_path}" 2>/dev/null)
        if [ "$actual_perms" = "{permissions}" ]; then
            log_message "SUCCESS" "Verified {target_path} permissions: {permissions}"
        else
            log_message "WARNING" "Permission verification failed: expected {permissions}, got $actual_perms"
        fi
    else
        log_message "ERROR" "Failed to configure {target_path}"
        return 1
    fi'''
    
    # At/Cron User Restrictions (4.1.2.x)
    elif script_id == '4.1.2.1':
        return '''
    # CIS 4.1.2.1: Ensure at is restricted to authorized users
    log_message "INFO" "Restricting at command to authorized users"
    
    # Remove at.deny if it exists
    if [ -f /etc/at.deny ]; then
        rm -f /etc/at.deny
        log_message "SUCCESS" "Removed /etc/at.deny"
    fi
    
    # Create or secure at.allow
    if [ ! -f /etc/at.allow ]; then
        touch /etc/at.allow
        log_message "INFO" "Created /etc/at.allow"
    fi
    
    # Set proper permissions on at.allow
    if set_permissions "/etc/at.allow" "640" "root" "root"; then
        log_message "SUCCESS" "Configured /etc/at.allow with proper permissions"
    else
        log_message "ERROR" "Failed to configure /etc/at.allow"
        return 1
    fi'''
    
    elif script_id == '4.1.2.2':
        return '''
    # CIS 4.1.2.2: Ensure cron is restricted to authorized users  
    log_message "INFO" "Restricting cron to authorized users"
    
    # Remove cron.deny if it exists
    if [ -f /etc/cron.deny ]; then
        rm -f /etc/cron.deny
        log_message "SUCCESS" "Removed /etc/cron.deny"
    fi
    
    # Ensure cron.allow exists and is properly configured
    if [ ! -f /etc/cron.allow ]; then
        touch /etc/cron.allow
        log_message "INFO" "Created /etc/cron.allow"
    fi
    
    # Set proper permissions on cron.allow (already handled in 4.1.1.8)
    if set_permissions "/etc/cron.allow" "640" "root" "root"; then
        log_message "SUCCESS" "Configured /etc/cron.allow with proper permissions"
    else
        log_message "ERROR" "Failed to configure /etc/cron.allow"
        return 1
    fi'''
    
    # SSH Configuration (4.2.x and 4.3.x)
    elif script_id == '4.2.1':
        return '''
    # CIS 4.2.1: Ensure permissions on /etc/ssh/sshd_config are configured
    config_file="/etc/ssh/sshd_config"
    
    log_message "INFO" "Setting proper permissions on SSH daemon configuration"
    
    if set_permissions "/etc/ssh/sshd_config" "600" "root" "root"; then
        log_message "SUCCESS" "Configured /etc/ssh/sshd_config with proper permissions"
        
        # Verify SSH configuration is still valid
        if sshd -t 2>/dev/null; then
            log_message "SUCCESS" "SSH configuration is valid"
        else
            log_message "ERROR" "SSH configuration validation failed"
            return 1
        fi
    else
        log_message "ERROR" "Failed to configure SSH daemon configuration permissions"
        return 1
    fi'''
    
    elif script_id.startswith('4.2.') and script_id != '4.2.1':
        # SSH configuration parameters
        ssh_configs = {
            '4.2.2': ('LogLevel', 'INFO'),
            '4.2.3': ('X11Forwarding', 'no'),
            '4.2.4': ('MaxAuthTries', '4'),
            '4.2.5': ('IgnoreRhosts', 'yes'),
            '4.2.6': ('HostbasedAuthentication', 'no'),
            '4.2.7': ('PermitRootLogin', 'no'),
            '4.2.8': ('PermitEmptyPasswords', 'no'),
            '4.2.9': ('PermitUserEnvironment', 'no'),
            '4.2.10': ('Ciphers', 'chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr'),
            '4.2.11': ('MACs', 'hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256'),
            '4.2.12': ('KexAlgorithms', 'curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group14-sha256,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group-exchange-sha256'),
            '4.2.13': ('ClientAliveInterval', '300'),
            '4.2.14': ('ClientAliveCountMax', '0'),
            '4.2.15': ('LoginGraceTime', '60'),
            '4.2.16': ('Banner', '/etc/issue.net'),
            '4.2.17': ('UsePAM', 'yes'),
            '4.2.18': ('AllowTcpForwarding', 'no'),
            '4.2.19': ('maxstartups', '10:30:60'),
            '4.2.20': ('MaxSessions', '4')
        }
        
        if script_id in ssh_configs:
            param, value = ssh_configs[script_id]
            return f'''
    # CIS {script_id}: Configure SSH {param}
    config_file="/etc/ssh/sshd_config"
    
    log_message "INFO" "Configuring SSH {param} = {value}"
    
    if configure_ssh "{param}" "{value}"; then
        log_message "SUCCESS" "SSH {param} configured successfully"
        
        # Verify configuration is active
        if systemctl is-active sshd >/dev/null 2>&1; then
            log_message "INFO" "SSH service is active - configuration applied"
        else
            log_message "WARNING" "SSH service is not active"
        fi
    else
        log_message "ERROR" "Failed to configure SSH {param}"
        return 1
    fi'''
    
    # PAM Configuration (4.3.x)
    elif script_id.startswith('4.3.'):
        pam_configs = {
            '4.3.1': ('password-auth', 'pwquality'),
            '4.3.2': ('system-auth', 'pwhistory'),
            '4.3.3': ('password-auth', 'faillock'),
            '4.3.4': ('system-auth', 'pwquality')
        }
        
        if script_id in pam_configs:
            pam_file, module = pam_configs[script_id]
            return f'''
    # CIS {script_id}: Configure PAM {module} in {pam_file}
    config_file="/etc/pam.d/{pam_file}"
    
    log_message "INFO" "Configuring PAM {module} module"
    log_message "WARNING" "PAM configuration requires manual review"
    log_message "INFO" "Please review and configure PAM according to organizational policy"
    
    # Create backup of PAM files
    backup_file "/etc/pam.d/{pam_file}"
    backup_file "/etc/pam.d/system-auth"
    
    log_message "INFO" "PAM configuration backups created"
    log_message "INFO" "Manual PAM configuration required for {module} module"
    
    return 2  # Manual intervention required'''
    
    # User Account and Environment (4.4.x and 4.5.x)
    elif script_id.startswith('4.4.') or script_id.startswith('4.5.'):
        user_configs = {
            '4.4.1': ('PASS_MAX_DAYS', '365'),
            '4.4.2': ('PASS_MIN_DAYS', '7'),
            '4.4.3': ('PASS_WARN_AGE', '7'),
            '4.4.4': ('inactive_days', '30'),
            '4.5.1': ('UMASK', '027'),
            '4.5.2': ('TMOUT', '900'),
            '4.5.3': ('root_path', 'secure'),
            '4.5.4': ('system_accounts', 'nologin')
        }
        
        if script_id == '4.4.1':
            return '''
    # CIS 4.4.1: Ensure password expiration is 365 days or less
    config_file="/etc/login.defs"
    
    log_message "INFO" "Setting password maximum age to 365 days"
    
    # Configure PASS_MAX_DAYS in login.defs
    if edit_config_file "/etc/login.defs" "PASS_MAX_DAYS" "365"; then
        log_message "SUCCESS" "Password maximum age set to 365 days"
        
        # Update existing users with unlimited password age
        for user in $(awk -F: '($5 > 365 || $5 == -1) {print $1}' /etc/shadow); do
            if chage -M 365 "$user" 2>/dev/null; then
                log_message "SUCCESS" "Updated password age for user: $user"
            fi
        done
    else
        log_message "ERROR" "Failed to configure password maximum age"
        return 1
    fi'''
        
        elif script_id == '4.4.2':
            return '''
    # CIS 4.4.2: Ensure password minimum age is 7 days or more
    config_file="/etc/login.defs"
    
    log_message "INFO" "Setting password minimum age to 7 days"
    
    if edit_config_file "/etc/login.defs" "PASS_MIN_DAYS" "7"; then
        log_message "SUCCESS" "Password minimum age set to 7 days"
    else
        log_message "ERROR" "Failed to configure password minimum age"
        return 1
    fi'''
        
        elif script_id == '4.4.3':
            return '''
    # CIS 4.4.3: Ensure password expiration warning days is 7 or more
    config_file="/etc/login.defs"
    
    log_message "INFO" "Setting password expiration warning to 7 days"
    
    if edit_config_file "/etc/login.defs" "PASS_WARN_AGE" "7"; then
        log_message "SUCCESS" "Password expiration warning set to 7 days"
    else
        log_message "ERROR" "Failed to configure password expiration warning"
        return 1
    fi'''
        
        elif script_id == '4.4.4':
            return '''
    # CIS 4.4.4: Ensure inactive password lock is 30 days or less
    log_message "INFO" "Setting inactive password lock to 30 days"
    
    # Set system default for inactive accounts
    if useradd -D -f 30 2>/dev/null; then
        log_message "SUCCESS" "System default inactive period set to 30 days"
        
        # Update existing users with no inactive period set
        for user in $(awk -F: '($7 == "" || $7 == -1) && $1 != "root" {print $1}' /etc/shadow); do
            if chage -I 30 "$user" 2>/dev/null; then
                log_message "SUCCESS" "Set inactive period for user: $user"
            fi
        done
    else
        log_message "ERROR" "Failed to configure inactive password lock"
        return 1
    fi'''
        
        elif script_id == '4.5.1':
            return '''
    # CIS 4.5.1: Ensure default user umask is 027 or more restrictive
    log_message "INFO" "Setting default umask to 027"
    
    # Configure umask in /etc/bashrc
    if grep -q "^umask" /etc/bashrc; then
        sed -i 's/^umask.*/umask 027/' /etc/bashrc
    else
        echo "umask 027" >> /etc/bashrc
    fi
    
    # Configure umask in /etc/profile
    if grep -q "^umask" /etc/profile; then
        sed -i 's/^umask.*/umask 027/' /etc/profile
    else
        echo "umask 027" >> /etc/profile
    fi
    
    log_message "SUCCESS" "Default umask set to 027"'''
        
        elif script_id == '4.5.2':
            return '''
    # CIS 4.5.2: Ensure default user shell timeout is 900 seconds or less
    log_message "INFO" "Setting default shell timeout to 900 seconds"
    
    # Configure TMOUT in /etc/bashrc
    if grep -q "^TMOUT" /etc/bashrc; then
        sed -i 's/^TMOUT.*/TMOUT=900/' /etc/bashrc
    else
        echo "TMOUT=900" >> /etc/bashrc
        echo "export TMOUT" >> /etc/bashrc
        echo "readonly TMOUT" >> /etc/bashrc
    fi
    
    # Configure TMOUT in /etc/profile
    if grep -q "^TMOUT" /etc/profile; then
        sed -i 's/^TMOUT.*/TMOUT=900/' /etc/profile
    else
        echo "TMOUT=900" >> /etc/profile
        echo "export TMOUT" >> /etc/profile
        echo "readonly TMOUT" >> /etc/profile
    fi
    
    log_message "SUCCESS" "Shell timeout set to 900 seconds"'''
        
        elif script_id == '4.5.3':
            return '''
    # CIS 4.5.3: Ensure default group for the root account is GID 0
    log_message "INFO" "Ensuring root account has GID 0"
    
    # Check current root GID
    root_gid=$(id -g root)
    
    if [ "$root_gid" = "0" ]; then
        log_message "SUCCESS" "Root account already has GID 0"
    else
        # Change root primary group to 0
        if usermod -g 0 root 2>/dev/null; then
            log_message "SUCCESS" "Root account GID set to 0"
        else
            log_message "ERROR" "Failed to set root account GID to 0"
            return 1
        fi
    fi'''
        
        elif script_id == '4.5.4':
            return '''
    # CIS 4.5.4: Ensure default user shell timeout is configured
    log_message "INFO" "Reviewing system accounts for proper shell configuration"
    
    # Find system accounts with interactive shells
    system_accounts=$(awk -F: '($3 < 1000 && $7 !~ /nologin|false/) {print $1 ":" $7}' /etc/passwd | grep -v "^root:")
    
    if [ -n "$system_accounts" ]; then
        log_message "WARNING" "Found system accounts with interactive shells:"
        echo "$system_accounts" | while read account; do
            username=$(echo "$account" | cut -d: -f1)
            shell=$(echo "$account" | cut -d: -f2)
            log_message "WARNING" "User: $username has shell: $shell"
            
            # Set shell to nologin for system accounts
            if usermod -s /sbin/nologin "$username" 2>/dev/null; then
                log_message "SUCCESS" "Set nologin shell for system account: $username"
            fi
        done
    else
        log_message "SUCCESS" "All system accounts have appropriate shells"
    fi'''
    
    # Root Access (4.6.x)
    elif script_id == '4.6':
        return '''
    # CIS 4.6: Ensure root login is restricted to system console
    config_file="/etc/securetty"
    
    log_message "INFO" "Restricting root login to system console"
    
    # Backup current securetty
    backup_file "/etc/securetty"
    
    # Create restrictive securetty with only console access
    cat > /etc/securetty << 'EOF'
console
tty1
tty2
tty3
tty4
tty5
tty6
EOF
    
    # Set proper permissions
    if set_permissions "/etc/securetty" "600" "root" "root"; then
        log_message "SUCCESS" "Root login restricted to system console"
    else
        log_message "ERROR" "Failed to configure /etc/securetty"
        return 1
    fi'''
    
    # Sudo Configuration (4.7.x)
    elif script_id == '4.7':
        return '''
    # CIS 4.7: Ensure access to the su command is restricted
    log_message "INFO" "Restricting access to su command"
    
    # Configure PAM for su command restrictions
    pam_su_file="/etc/pam.d/su"
    
    # Backup PAM su configuration
    backup_file "$pam_su_file"
    
    # Add pam_wheel.so requirement
    if ! grep -q "auth.*required.*pam_wheel.so" "$pam_su_file"; then
        echo "auth            required        pam_wheel.so use_uid" >> "$pam_su_file"
        log_message "SUCCESS" "Added pam_wheel requirement to su"
    else
        log_message "INFO" "pam_wheel already configured for su"
    fi
    
    # Ensure wheel group exists
    if ! getent group wheel >/dev/null; then
        groupadd wheel
        log_message "SUCCESS" "Created wheel group"
    fi
    
    log_message "WARNING" "Add authorized users to wheel group manually"
    log_message "INFO" "Use: usermod -aG wheel <username>"'''
    
    # Default case for unknown controls
    else:
        return f'''
    # CIS {script_id}: Section 4 access control remediation
    config_file=""
    
    log_message "INFO" "Applying remediation for: {script_id}"
    log_message "INFO" "Remediation steps: {remediation[:200] if remediation else 'See CIS benchmark documentation'}"
    
    # TODO: Implement specific remediation logic for this CIS control
    # Description: {description}
    
    log_message "WARNING" "Specific remediation logic needs to be implemented for this control"
    return 2  # Manual intervention may be required'''

# Test specific logic generation
test_logic = get_specific_remediation_logic_section4(df_section4.iloc[0].to_dict())
print("Sample specific remediation logic for cron daemon:")
print(test_logic)