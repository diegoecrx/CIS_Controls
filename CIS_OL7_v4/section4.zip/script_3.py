# Generate all Section 4 scripts
scripts_generated_section4 = []
failed_scripts_section4 = []

print("=== GENERATING SECTION 4 SCRIPTS ===")

for index, row in df_section4.iterrows():
    try:
        # Generate base script
        script_content = generate_script_template_section4(row.to_dict())
        
        # Get specific remediation logic
        specific_logic = get_specific_remediation_logic_section4(row.to_dict())
        
        # Insert the specific logic into the template
        if 'automated' in row['script_name'].lower():
            # Replace the TODO comment in automated scripts
            script_content = script_content.replace(
                '    # TODO: Add specific remediation logic here based on the CIS control\n    # This will be customized for each specific script',
                specific_logic
            )
        else:
            # Replace the TODO comment in manual scripts
            script_content = script_content.replace(
                '    # TODO: Add specific manual remediation logic here\n    # This will be customized for each specific script',
                specific_logic
            )
            
            # Also update the show commands section for manual scripts
            show_commands_logic = specific_logic.replace('log_message', 'echo "# Command:"').replace('if ', 'echo "if ')
            script_content = script_content.replace(
                '    # TODO: Add specific command display logic here\n    # This will show the exact commands without executing them',
                f'    echo "The following remediation would be performed:"\\n{show_commands_logic}'
            )
        
        # Write script to file
        script_filename = f"{section4_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        # Make script executable
        os.chmod(script_filename, 0o755)
        
        scripts_generated_section4.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'filename': script_filename,
            'type': 'automated' if 'automated' in row['script_name'].lower() else 'manual'
        })
        
        if index < 10:  # Show first 10 for brevity
            print(f"Generated: {os.path.basename(script_filename)}")
        elif index == 10:
            print("... (continuing generation)")
        
    except Exception as e:
        failed_scripts_section4.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'error': str(e)
        })
        print(f"Failed to generate {row['id']}: {str(e)}")

print(f"\nSection 4 Generation Results:")
print(f"Successfully generated: {len(scripts_generated_section4)} scripts")
print(f"Failed to generate: {len(failed_scripts_section4)} scripts")

if failed_scripts_section4:
    print("\nFailed scripts:")
    for fail in failed_scripts_section4:
        print(f"  - {fail['id']}: {fail['error']}")

# Get final counts for verification
all_section4_scripts = glob.glob(f'{section4_dir}/*.sh')
print(f"Total Section 4 scripts in directory: {len(all_section4_scripts)}")

# Count by type
automated_scripts_section4 = [f for f in all_section4_scripts if 'automated' in f]
manual_scripts_section4 = [f for f in all_section4_scripts if 'manual' in f]

print(f"Automated scripts: {len(automated_scripts_section4)}")
print(f"Manual scripts: {len(manual_scripts_section4)}")

# Categorize scripts by functionality
cron_scripts = [f for f in all_section4_scripts if '4.1.' in f]
ssh_scripts = [f for f in all_section4_scripts if '4.2.' in f]
pam_scripts = [f for f in all_section4_scripts if '4.3.' in f]
user_scripts = [f for f in all_section4_scripts if '4.4.' in f or '4.5.' in f]
access_scripts = [f for f in all_section4_scripts if '4.6' in f or '4.7' in f]

print(f"\n=== SECTION 4 BREAKDOWN BY CATEGORY ===")
print(f"Cron Configuration (4.1.x): {len(cron_scripts)} scripts")
print(f"SSH Configuration (4.2.x): {len(ssh_scripts)} scripts")
print(f"PAM Configuration (4.3.x): {len(pam_scripts)} scripts") 
print(f"User/Password Controls (4.4.x/4.5.x): {len(user_scripts)} scripts")
print(f"Access Controls (4.6/4.7): {len(access_scripts)} scripts")

print(f"\n✅ Section 4 script generation completed!")
print(f"All {len(all_section4_scripts)} scripts implement access control and authentication security measures.")