#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 4
# 4.2.8_sshd_disableforwarding_is_enabled_automated
# 4.2.8 Ensure sshd DisableForwarding is enabled (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="4.2.8_sshd_disableforwarding_is_enabled_automated"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 2"
profile_workstation="Level 1"
default_value="DisableForwarding no"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function with error categorization
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    # Also log to error log if it's an error
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Enhanced backup function with validation
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    if [ ! -r "$file_path" ]; then
        log_message "ERROR" "Cannot read file for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        echo "$BACKUP_DIR/$backup_name"  # Return backup path
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# File/directory permissions management
set_permissions() {
    local target_path="$1"
    local permissions="$2"
    local owner="$3"
    local group="$4"

    log_message "INFO" "Setting permissions on $target_path"

    # Check if target exists
    if [ ! -e "$target_path" ]; then
        log_message "ERROR" "Target path does not exist: $target_path"
        return 1
    fi

    # Set ownership if specified
    if [ -n "$owner" ] && [ -n "$group" ]; then
        if chown "$owner:$group" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set ownership $owner:$group on $target_path"
        else
            log_message "ERROR" "Failed to set ownership on $target_path"
            return 1
        fi
    fi

    # Set permissions if specified
    if [ -n "$permissions" ]; then
        if chmod "$permissions" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set permissions $permissions on $target_path"
        else
            log_message "ERROR" "Failed to set permissions on $target_path"
            return 1
        fi
    fi

    return 0
}

# Service management with proper error handling
manage_service() {
    local action="$1"
    local service_name="$2"

    case "$action" in
        "enable")
            if systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already enabled"
                return 0
            fi

            if systemctl enable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Enabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to enable service: $service_name"
                return 1
            fi
        ;;
        "disable")
            if ! systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already disabled"
                return 0
            fi

            if systemctl disable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Disabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to disable service: $service_name"
                return 1
            fi
        ;;
        "start")
            if systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already running"
                return 0
            fi

            if systemctl start "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Started service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to start service: $service_name"
                return 1
            fi
        ;;
        "stop")
            if ! systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already stopped"
                return 0
            fi

            if systemctl stop "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Stopped service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to stop service: $service_name"
                return 1
            fi
        ;;
        "mask")
            if systemctl is-masked "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already masked"
                return 0
            fi

            if systemctl mask "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Masked service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to mask service: $service_name"
                return 1
            fi
        ;;
        "unmask")
            if ! systemctl is-masked "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is not masked"
                return 0
            fi

            if systemctl unmask "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Unmasked service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to unmask service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management function
manage_package() {
    local action="$1"
    local package_name="$2"

    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi

            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi

            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# SSH configuration management
configure_ssh() {
    local parameter="$1"
    local value="$2"
    local config_file="/etc/ssh/sshd_config"

    log_message "INFO" "Configuring SSH parameter: $parameter = $value"

    # Backup SSH configuration
    backup_file "$config_file"

    # Remove any existing parameter entries (including commented ones)
    sed -i "/^#*\s*$parameter/d" "$config_file" 2>/dev/null

    # Add the new parameter
    echo "$parameter $value" >> "$config_file"

    # Validate SSH configuration
    if sshd -t 2>/dev/null; then
        log_message "SUCCESS" "SSH configuration is valid"

        # Reload SSH service to apply changes
        if systemctl reload sshd 2>/dev/null; then
            log_message "SUCCESS" "SSH service reloaded with new configuration"
        else
            log_message "WARNING" "Failed to reload SSH service"
        fi
        return 0
    else
        log_message "ERROR" "Invalid SSH configuration detected"
        return 1
    fi
}

# User/group management
manage_user() {
    local action="$1"
    local username="$2"
    local additional_params="$3"

    case "$action" in
        "create")
            if id "$username" >/dev/null 2>&1; then
                log_message "INFO" "User $username already exists"
                return 0
            fi

            if useradd $additional_params "$username" 2>/dev/null; then
                log_message "SUCCESS" "Created user: $username"
                return 0
            else
                log_message "ERROR" "Failed to create user: $username"
                return 1
            fi
        ;;
        "delete")
            if ! id "$username" >/dev/null 2>&1; then
                log_message "INFO" "User $username does not exist"
                return 0
            fi

            if userdel "$username" 2>/dev/null; then
                log_message "SUCCESS" "Deleted user: $username"
                return 0
            else
                log_message "ERROR" "Failed to delete user: $username"
                return 1
            fi
        ;;
        "modify")
            if ! id "$username" >/dev/null 2>&1; then
                log_message "ERROR" "User $username does not exist"
                return 1
            fi

            if usermod $additional_params "$username" 2>/dev/null; then
                log_message "SUCCESS" "Modified user: $username"
                return 0
            else
                log_message "ERROR" "Failed to modify user: $username"
                return 1
            fi
        ;;
    esac
}

# Configuration file editor with validation  
edit_config_file() {
    local config_file="$1"
    local setting_name="$2"
    local setting_value="$3"
    local comment_prefix="${4:-#}"

    if [ ! -f "$config_file" ]; then
        log_message "ERROR" "Configuration file not found: $config_file"
        return 1
    fi

    # Backup the file first
    local backup_path
    backup_path=$(backup_file "$config_file")
    if [ $? -ne 0 ]; then
        log_message "ERROR" "Cannot proceed without backup"
        return 1
    fi

    # Check if setting already exists and is correctly configured
    if grep -q "^$setting_name[[:space:]]*$setting_value" "$config_file"; then
        log_message "INFO" "Setting $setting_name is already correctly configured"
        return 0
    fi

    # Remove any existing commented or incorrect lines
    sed -i "/^$comment_prefix*[[:space:]]*$setting_name/d" "$config_file" 2>/dev/null

    # Add the correct setting
    if echo "$setting_name $setting_value" >> "$config_file"; then
        log_message "SUCCESS" "Added $setting_name $setting_value to $config_file"
        return 0
    else
        log_message "ERROR" "Failed to add setting to $config_file"
        return 1
    fi
}

# Main automated remediation function
main_remediation() {
    log_message "INFO" "Starting automated remediation: $SCRIPT_NAME"

    # Set error handling
    set -e
    trap 'log_message "ERROR" "Script failed at line $LINENO"; exit 1' ERR

    # 4.2.8 Ensure sshd DisableForwarding is enabled (Automated)
    # Description: The DisableForwarding parameter disables all forwarding features, including X11, ssh-
agent(1), TCP and StreamLocal. This option overrides all other forwarding-related
options and may simplify restricted configurations.
•
X11Forwarding provides the ability to tunnel X11 traffic through the connection to
enable remote graphic connections.
•
ssh-agent is a program to hold private keys used for public key authentication.
Through use of environment variables the agent can be located and
automatically used for authentication when logging in to other machines using
ssh.
•
SSH port forwarding is a mechanism in SSH for tunneling application ports from
the client to the server, or servers to clients. It can be used for adding encryption
to legacy applications, going through firewalls, and some system administrators
and IT professionals use it for opening backdoors into the internal network from
their home machines.


    # CIS 4.2.8: Configure SSH PermitEmptyPasswords
    config_file="/etc/ssh/sshd_config"

    log_message "INFO" "Configuring SSH PermitEmptyPasswords = no"

    if configure_ssh "PermitEmptyPasswords" "no"; then
        log_message "SUCCESS" "SSH PermitEmptyPasswords configured successfully"

        # Verify configuration is active
        if systemctl is-active sshd >/dev/null 2>&1; then
            log_message "INFO" "SSH service is active - configuration applied"
        else
            log_message "WARNING" "SSH service is not active"
        fi
    else
        log_message "ERROR" "Failed to configure SSH PermitEmptyPasswords"
        return 1
    fi

    local exit_code=$?

    if [ $exit_code -eq 0 ]; then
        log_message "SUCCESS" "Automated remediation completed successfully: $SCRIPT_NAME"
    else
        log_message "ERROR" "Automated remediation failed: $SCRIPT_NAME (exit code: $exit_code)"
    fi

    return $exit_code
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    # Verify running as root
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi

    # Execute automated remediation
    main_remediation
    exit $?
fi
