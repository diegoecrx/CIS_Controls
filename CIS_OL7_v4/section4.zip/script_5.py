# The issue is in our template generation - let's fix the root cause
# The problem is in the string replacement where we're trying to check if a substring exists in None

# Let's create a completely fixed version that handles None values properly
def generate_script_template_section4_fixed(row_data):
    """Generate a bash script based on the template and row data for Section 4 - Fixed version"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    remediation_name = str(row_data['remediation_name']) if pd.notna(row_data['remediation_name']) else "CIS Control"
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    profile = str(row_data['profile']) if pd.notna(row_data['profile']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Determine if automated or manual - handle None values safely
    is_automated = 'automated' in str(script_name).lower() if pd.notna(script_name) else True
    
    # Extract profile levels
    server_level = ""
    workstation_level = ""
    
    if profile and "Level 1 - Server" in profile:
        server_level = "Level 1"
    elif profile and "Level 2 - Server" in profile:
        server_level = "Level 2"
        
    if profile and "Level 1 - Workstation" in profile:
        workstation_level = "Level 1"
    elif profile and "Level 2 - Workstation" in profile:
        workstation_level = "Level 2"
    
    # Build the script content with minimal template
    script_content = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 4
# {script_name}
# {remediation_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="{script_name}"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="{server_level}"
profile_workstation="{workstation_level}"
default_value="{default_value}"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {{
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}}

# Enhanced logging function
log_message() {{
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
    
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}}

# Backup function
backup_file() {{
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi
    
    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"
    
    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}}

# Service management
manage_service() {{
    local action="$1"
    local service_name="$2"
    
    case "$action" in
        "enable"|"disable"|"start"|"stop"|"mask"|"unmask")
            if systemctl "$action" "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "$action service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to $action service: $service_name"
                return 1
            fi
        ;;
    esac
}}

# Main remediation function
main_remediation() {{
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"
    
    # Description: {description}
    
    REMEDIATION_LOGIC_PLACEHOLDER
    
    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}}

# Execute main function if script is run directly
if [ "${{BASH_SOURCE[0]}}" = "${{0}}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi
    
    main_remediation
    exit $?
fi
'''
    
    return script_content

# Generate all remaining failed scripts with the fixed template
successful_final = 0
print("=== GENERATING REMAINING SCRIPTS WITH FIXED TEMPLATE ===")

for failed_id in failed_ids_section4:
    try:
        if failed_id not in df_section4['id'].values:
            continue
            
        row = df_section4[df_section4['id'] == failed_id].iloc[0]
        
        # Generate base script with fixed template
        script_content = generate_script_template_section4_fixed(row.to_dict())
        
        # Get specific remediation logic
        specific_logic = get_specific_remediation_logic_section4_complete(row.to_dict())
        
        # Insert the logic
        script_content = script_content.replace('REMEDIATION_LOGIC_PLACEHOLDER', specific_logic)
        
        # Write script to file
        script_filename = f"{section4_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        os.chmod(script_filename, 0o755)
        successful_final += 1
        
        if successful_final <= 5:
            print(f"Generated: {os.path.basename(script_filename)}")
        elif successful_final == 6:
            print("... (continuing)")
        
    except Exception as e:
        print(f"Final attempt failed for {failed_id}: {str(e)}")

print(f"\nSuccessfully generated {successful_final} additional scripts")

# Get final comprehensive count
final_all_scripts = glob.glob(f'{section4_dir}/*.sh')
print(f"Total Section 4 scripts: {len(final_all_scripts)}")

# Create comprehensive summary and documentation
section4_summary = {
    'total_rows_processed': len(df_section4),
    'scripts_generated': len(final_all_scripts),
    'automated_scripts': len([f for f in final_all_scripts if 'automated' in f]),
    'manual_scripts': len([f for f in final_all_scripts if 'manual' in f]),
    'success_rate': f"{(len(final_all_scripts)/len(df_section4))*100:.1f}%"
}

print(f"\n=== SECTION 4 FINAL SUMMARY ===")
for key, value in section4_summary.items():
    print(f"{key}: {value}")

# Categorize all scripts
all_cron_scripts = [f for f in final_all_scripts if '4.1.' in f]
all_ssh_scripts = [f for f in final_all_scripts if '4.2.' in f] 
all_pam_scripts = [f for f in final_all_scripts if '4.3.' in f]
all_user_scripts = [f for f in final_all_scripts if '4.4.' in f or '4.5.' in f]

print(f"\n=== FINAL BREAKDOWN BY CATEGORY ===")
print(f"Cron & Job Scheduling (4.1.x): {len(all_cron_scripts)} scripts")
print(f"SSH Configuration (4.2.x): {len(all_ssh_scripts)} scripts")
print(f"PAM & Authentication (4.3.x): {len(all_pam_scripts)} scripts")
print(f"User Account & Password (4.4.x/4.5.x): {len(all_user_scripts)} scripts")

print(f"\n✅ Section 4 generation completed!")
print(f"Generated {len(final_all_scripts)} access control and authentication scripts")