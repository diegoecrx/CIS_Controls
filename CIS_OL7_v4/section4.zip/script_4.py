# Fix failed scripts by extending our remediation logic to cover all Section 4 controls
print("=== DEBUGGING FAILED SCRIPTS ===")

failed_ids_section4 = ['4.2.21', '4.2.22', '4.3.5', '4.3.6', '4.3.7', '4.4.1.1', '4.4.1.2', 
                       '4.4.2.1.1', '4.4.2.1.2', '4.4.2.1.3', '4.4.2.1.4', '4.4.2.2.1', 
                       '4.4.2.2.2', '4.4.2.2.3', '4.4.2.2.4', '4.4.2.2.5', '4.4.2.2.6', 
                       '4.4.2.2.7', '4.4.2.3.1', '4.4.2.3.2', '4.4.2.3.3', '4.4.2.3.4',
                       '4.4.2.4.1', '4.4.2.4.2', '4.4.2.4.3', '4.4.2.4.4', '4.5.1.1', 
                       '4.5.1.2', '4.5.1.3', '4.5.1.4', '4.5.1.5', '4.5.2.1', '4.5.2.2', 
                       '4.5.2.3', '4.5.2.4', '4.5.3.1', '4.5.3.2', '4.5.3.3']

# Let's check what data these IDs have
sample_failed = failed_ids_section4[:5]
for failed_id in sample_failed:
    if failed_id in df_section4['id'].values:
        row = df_section4[df_section4['id'] == failed_id].iloc[0]
        print(f"\n--- {failed_id} ---")
        print(f"script_name: {repr(row['script_name'])}")
        print(f"remediation: {repr(row['remediation'])}")
        print(f"description type: {type(row['description'])}")

# Create comprehensive remediation logic for all Section 4 controls
def get_specific_remediation_logic_section4_complete(row_data):
    """Generate complete remediation logic for all Section 4 CIS controls"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Use the existing logic first
    existing_logic = get_specific_remediation_logic_section4(row_data)
    
    # If it's not a generic default, return the existing logic
    if 'TODO: Implement specific remediation logic' not in existing_logic:
        return existing_logic
    
    # Handle additional SSH controls (4.2.21, 4.2.22)
    if script_id == '4.2.21':
        return '''
    # CIS 4.2.21: Ensure SSH PermitUserEnvironment is disabled
    config_file="/etc/ssh/sshd_config"
    
    log_message "INFO" "Disabling SSH PermitUserEnvironment"
    
    if configure_ssh "PermitUserEnvironment" "no"; then
        log_message "SUCCESS" "SSH PermitUserEnvironment disabled successfully"
    else
        log_message "ERROR" "Failed to configure SSH PermitUserEnvironment"
        return 1
    fi'''
    
    elif script_id == '4.2.22':
        return '''
    # CIS 4.2.22: Ensure SSH UsePAM is enabled
    config_file="/etc/ssh/sshd_config"
    
    log_message "INFO" "Enabling SSH UsePAM"
    
    if configure_ssh "UsePAM" "yes"; then
        log_message "SUCCESS" "SSH UsePAM enabled successfully"
    else
        log_message "ERROR" "Failed to configure SSH UsePAM"
        return 1
    fi'''
    
    # Handle additional PAM controls (4.3.x)
    elif script_id.startswith('4.3.'):
        if script_id == '4.3.5':
            return '''
    # CIS 4.3.5: Ensure su access is restricted
    log_message "INFO" "Restricting su access to wheel group"
    config_file="/etc/pam.d/su"
    
    # Configure PAM for su restrictions
    backup_file "/etc/pam.d/su"
    
    if ! grep -q "auth.*required.*pam_wheel.so" "/etc/pam.d/su"; then
        echo "auth            required        pam_wheel.so use_uid" >> "/etc/pam.d/su"
        log_message "SUCCESS" "Added pam_wheel requirement to su"
    else
        log_message "INFO" "pam_wheel already configured for su"
    fi
    
    # Ensure wheel group exists
    if ! getent group wheel >/dev/null; then
        groupadd wheel
        log_message "SUCCESS" "Created wheel group"
    fi
    
    log_message "WARNING" "Remember to add authorized users to wheel group: usermod -aG wheel <username>"'''
        
        elif script_id == '4.3.6':
            return '''
    # CIS 4.3.6: Ensure PAM prevents use of dictionary words
    log_message "INFO" "Configuring PAM to prevent dictionary words in passwords"
    config_file="/etc/security/pwquality.conf"
    
    # Configure pwquality for dictionary word checking
    backup_file "/etc/security/pwquality.conf"
    
    # Remove existing dictcheck entries
    sed -i '/^dictcheck/d' "/etc/security/pwquality.conf"
    
    # Add dictionary checking
    echo "dictcheck = 1" >> "/etc/security/pwquality.conf"
    
    log_message "SUCCESS" "PAM configured to prevent dictionary words"'''
        
        elif script_id == '4.3.7':
            return '''
    # CIS 4.3.7: Ensure PAM password complexity requirements
    log_message "INFO" "Configuring PAM password complexity requirements"
    config_file="/etc/security/pwquality.conf"
    
    backup_file "/etc/security/pwquality.conf"
    
    # Set password complexity requirements
    pwquality_settings="minlen = 14
minclass = 4
maxrepeat = 3
maxsequence = 3
dictcheck = 1"
    
    # Clear existing settings and add new ones
    echo "$pwquality_settings" >> "/etc/security/pwquality.conf"
    
    log_message "SUCCESS" "PAM password complexity requirements configured"'''
    
    # Handle User Account Controls (4.4.x detailed)
    elif script_id.startswith('4.4.1.'):
        return '''
    # CIS 4.4.1.x: Password aging configuration
    log_message "INFO" "Configuring password aging policies"
    config_file="/etc/login.defs"
    
    # Configure password aging in login.defs
    backup_file "/etc/login.defs"
    
    # Set password aging parameters
    for param in "PASS_MAX_DAYS 365" "PASS_MIN_DAYS 7" "PASS_WARN_AGE 7"; do
        parameter=$(echo $param | cut -d' ' -f1)
        value=$(echo $param | cut -d' ' -f2)
        
        if edit_config_file "/etc/login.defs" "$parameter" "$value"; then
            log_message "SUCCESS" "Set $parameter to $value"
        fi
    done'''
    
    elif script_id.startswith('4.4.2.'):
        # Password quality controls
        return '''
    # CIS 4.4.2.x: Password quality configuration
    log_message "INFO" "Configuring password quality requirements"
    config_file="/etc/security/pwquality.conf"
    
    backup_file "/etc/security/pwquality.conf"
    
    # Configure password quality parameters
    pwquality_params="minlen = 14
minclass = 4
maxrepeat = 3
maxsequence = 3
gecoscheck = 1
dictcheck = 1
usercheck = 1
enforcing = 1"
    
    echo "$pwquality_params" >> "/etc/security/pwquality.conf"
    log_message "SUCCESS" "Password quality requirements configured"'''
    
    # Handle User Environment Controls (4.5.x detailed)
    elif script_id.startswith('4.5.1.'):
        return '''
    # CIS 4.5.1.x: User shell configuration
    log_message "INFO" "Configuring user shell defaults"
    
    # Configure default umask
    for file in /etc/bashrc /etc/profile; do
        if [ -f "$file" ]; then
            backup_file "$file"
            
            # Set umask
            if ! grep -q "umask 027" "$file"; then
                echo "umask 027" >> "$file"
                log_message "SUCCESS" "Set umask 027 in $file"
            fi
        fi
    done'''
    
    elif script_id.startswith('4.5.2.'):
        return '''
    # CIS 4.5.2.x: Shell timeout configuration
    log_message "INFO" "Configuring shell timeout"
    
    # Configure TMOUT in shell configuration files
    for file in /etc/bashrc /etc/profile; do
        if [ -f "$file" ]; then
            backup_file "$file"
            
            # Remove existing TMOUT settings
            sed -i '/TMOUT/d' "$file"
            
            # Add TMOUT configuration
            echo "TMOUT=900" >> "$file"
            echo "export TMOUT" >> "$file"
            echo "readonly TMOUT" >> "$file"
            
            log_message "SUCCESS" "Set TMOUT=900 in $file"
        fi
    done'''
    
    elif script_id.startswith('4.5.3.'):
        return '''
    # CIS 4.5.3.x: User account configuration
    log_message "INFO" "Configuring user account security"
    
    # Review system accounts for proper shell configuration
    awk -F: '($3 < 1000 && $7 !~ /nologin|false/) {print $1}' /etc/passwd | while read account; do
        if [ "$account" != "root" ] && [ "$account" != "sync" ] && [ "$account" != "shutdown" ] && [ "$account" != "halt" ]; then
            if usermod -s /sbin/nologin "$account" 2>/dev/null; then
                log_message "SUCCESS" "Set nologin shell for system account: $account"
            fi
        fi
    done
    
    log_message "SUCCESS" "System account shell configuration completed"'''
    
    # Default case for any remaining controls
    else:
        return f'''
    # CIS {script_id}: Access control remediation
    config_file=""
    
    log_message "INFO" "Applying access control remediation for: {script_id}"
    log_message "INFO" "Description: {description[:100]}..."
    
    # This control may require manual configuration
    log_message "WARNING" "Please review CIS benchmark documentation for specific requirements"
    log_message "INFO" "Remediation guidance: {remediation[:200] if remediation else 'See CIS documentation'}"
    
    return 2  # Manual intervention may be required'''

print("Enhanced remediation logic function created.")

# Generate the remaining failed scripts
successful_fixes = 0
remaining_failures = 0

print("\nGenerating remaining failed scripts...")

for failed_id in failed_ids_section4:
    try:
        if failed_id not in df_section4['id'].values:
            print(f"ID {failed_id} not found in dataset")
            continue
            
        row = df_section4[df_section4['id'] == failed_id].iloc[0]
        
        # Generate base script
        script_content = generate_script_template_section4(row.to_dict())
        
        # Get specific remediation logic with enhanced function
        specific_logic = get_specific_remediation_logic_section4_complete(row.to_dict())
        
        # Insert the specific logic into the template
        script_content = script_content.replace(
            '    # TODO: Add specific remediation logic here based on the CIS control\n    # This will be customized for each specific script',
            specific_logic
        )
        
        # Write script to file
        script_filename = f"{section4_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        os.chmod(script_filename, 0o755)
        successful_fixes += 1
        
    except Exception as e:
        print(f"Still failed to generate {failed_id}: {str(e)}")
        remaining_failures += 1

print(f"Fixed: {successful_fixes} scripts")
print(f"Still failed: {remaining_failures} scripts")

# Final count
final_section4_scripts = glob.glob(f'{section4_dir}/*.sh')
print(f"\nFinal Section 4 script count: {len(final_section4_scripts)}")