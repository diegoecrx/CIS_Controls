import pandas as pd
import os
import glob

# Read the Section 4 spreadsheet
df_section4 = pd.read_excel('section4.xlsx')

print("=== SECTION 4 EXCEL FILE STRUCTURE ===")
print(f"Shape: {df_section4.shape}")
print(f"Columns: {list(df_section4.columns)}")
print("\n=== FIRST FEW ROWS ===")
print(df_section4.head())

print("\n=== DATA TYPES ===")
print(df_section4.dtypes)

print("\n=== COLUMN ANALYSIS ===")
for col in df_section4.columns:
    print(f"\n--- {col} ---")
    if col in df_section4.columns:
        print(f"Unique values: {df_section4[col].nunique()}")
        sample_values = df_section4[col].dropna().head(3).tolist()
        print(f"Sample values: {sample_values}")

print("\n=== SCRIPT NAME PATTERNS ===")
if 'script_name' in df_section4.columns:
    automated_count = sum(1 for name in df_section4['script_name'].dropna() if 'automated' in str(name).lower())
    manual_count = sum(1 for name in df_section4['script_name'].dropna() if 'manual' in str(name).lower())
    
    print(f"Automated scripts: {automated_count}")
    print(f"Manual scripts: {manual_count}")
    print(f"Total scripts to generate: {len(df_section4)}")

print("\n=== ID PATTERNS ===")
if 'id' in df_section4.columns:
    id_samples = df_section4['id'].dropna().head(10).tolist()
    print(f"ID samples: {id_samples}")
    
print("\n=== PROFILE PATTERNS ===")
if 'profile' in df_section4.columns:
    profile_patterns = df_section4['profile'].value_counts()
    print(profile_patterns.head(10))