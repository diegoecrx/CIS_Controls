# Create directory for section6 scripts
section6_dir = 'section6_scripts'
os.makedirs(section6_dir, exist_ok=True)

# Generate script template for Section 6 - focusing on system maintenance
def generate_script_template_section6(row_data):
    """Generate a bash script based on the template and row data for Section 6"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    remediation_name = str(row_data['remediation_name']) if pd.notna(row_data['remediation_name']) else "CIS Control"
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    profile = str(row_data['profile']) if pd.notna(row_data['profile']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Determine if automated or manual
    is_automated = 'automated' in str(script_name).lower() if pd.notna(script_name) else True
    
    # Extract profile levels
    server_level = ""
    workstation_level = ""
    
    if profile and "Level 1 - Server" in profile:
        server_level = "Level 1"
    elif profile and "Level 2 - Server" in profile:
        server_level = "Level 2"
        
    if profile and "Level 1 - Workstation" in profile:
        workstation_level = "Level 1"
    elif profile and "Level 2 - Workstation" in profile:
        workstation_level = "Level 2"
    
    # Build the script content (minimal version to avoid issues)
    script_content = '''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 6
# SCRIPT_NAME_PLACEHOLDER
# REMEDIATION_NAME_PLACEHOLDER
# 
# This script implements system maintenance controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="SCRIPT_NAME_PLACEHOLDER"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="SERVER_LEVEL_PLACEHOLDER"
profile_workstation="WORKSTATION_LEVEL_PLACEHOLDER"
default_value="DEFAULT_VALUE_PLACEHOLDER"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
    
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Backup function
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi
    
    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"
    
    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# File/directory permissions management
set_permissions() {
    local target_path="$1"
    local permissions="$2"
    local owner="$3"
    local group="$4"
    
    log_message "INFO" "Setting permissions on $target_path"
    
    # Check if target exists
    if [ ! -e "$target_path" ]; then
        log_message "ERROR" "Target path does not exist: $target_path"
        return 1
    fi
    
    # Set ownership if specified
    if [ -n "$owner" ] && [ -n "$group" ]; then
        if chown "$owner:$group" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set ownership $owner:$group on $target_path"
        else
            log_message "ERROR" "Failed to set ownership on $target_path"
            return 1
        fi
    fi
    
    # Set permissions if specified
    if [ -n "$permissions" ]; then
        if chmod "$permissions" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set permissions $permissions on $target_path"
        else
            log_message "ERROR" "Failed to set permissions on $target_path"
            return 1
        fi
    fi
    
    return 0
}

# User and group management
check_user_group() {
    local username="$1"
    local groupname="$2"
    
    if [ -n "$username" ]; then
        if ! id "$username" >/dev/null 2>&1; then
            log_message "WARNING" "User $username does not exist"
            return 1
        fi
    fi
    
    if [ -n "$groupname" ]; then
        if ! getent group "$groupname" >/dev/null 2>&1; then
            log_message "WARNING" "Group $groupname does not exist"
            return 1
        fi
    fi
    
    return 0
}

# Find and fix file permissions
fix_file_permissions() {
    local search_path="$1"
    local find_criteria="$2"
    local fix_action="$3"
    
    log_message "INFO" "Searching for files matching criteria: $find_criteria"
    
    local count=0
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            log_message "INFO" "Processing file: $file"
            case "$fix_action" in
                "fix_permissions")
                    chmod go-w "$file" 2>/dev/null && ((count++))
                    ;;
                "remove_suid")
                    chmod u-s "$file" 2>/dev/null && ((count++))
                    ;;
                "remove_sgid")
                    chmod g-s "$file" 2>/dev/null && ((count++))
                    ;;
                "add_sticky")
                    chmod +t "$file" 2>/dev/null && ((count++))
                    ;;
            esac
        fi
    done < <(find "$search_path" $find_criteria -print0 2>/dev/null)
    
    log_message "SUCCESS" "Processed $count files"
    return 0
}

# World writable files and directories management
secure_world_writable() {
    local search_path="${1:-/}"
    
    log_message "INFO" "Securing world writable files and directories"
    
    # Array to store excluded paths
    local -a exclude_paths=(
        "! -path /run/user/*"
        "! -path /proc/*"
        "! -path */containerd/*"
        "! -path */kubelet/pods/*"
        "! -path /sys/kernel/security/apparmor/*"
        "! -path /snap/*"
        "! -path /sys/fs/cgroup/memory/*"
        "! -path /sys/fs/selinux/*"
        "! -path /tmp/*"
        "! -path /var/tmp/*"
    )
    
    # Find world writable files and fix them
    log_message "INFO" "Finding and fixing world writable files..."
    local file_count=0
    while IFS= read -r -d '' file; do
        if [ -f "$file" ] && [ -w "$file" ]; then
            log_message "INFO" "Removing world write permission from: $file"
            if chmod o-w "$file" 2>/dev/null; then
                ((file_count++))
            fi
        fi
    done < <(find "$search_path" -type f -perm -0002 "${exclude_paths[@]}" -print0 2>/dev/null)
    
    # Find world writable directories and add sticky bit
    log_message "INFO" "Finding and securing world writable directories..."
    local dir_count=0
    while IFS= read -r -d '' dir; do
        if [ -d "$dir" ]; then
            # Check if sticky bit is already set
            if [ ! $(($(stat -c "%a" "$dir" 2>/dev/null || echo 0) & 01000)) -gt 0 ]; then
                log_message "INFO" "Adding sticky bit to directory: $dir"
                if chmod +t "$dir" 2>/dev/null; then
                    ((dir_count++))
                fi
            fi
        fi
    done < <(find "$search_path" -type d -perm -0002 "${exclude_paths[@]}" -print0 2>/dev/null)
    
    log_message "SUCCESS" "Secured $file_count world writable files and $dir_count directories"
    return 0
}

# Find files without owner or group
find_unowned_files() {
    local search_path="${1:-/}"
    local action="${2:-report}"
    
    log_message "INFO" "Searching for unowned/ungrouped files in $search_path"
    
    local unowned_count=0
    local ungrouped_count=0
    
    # Find files without valid owner
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            log_message "WARNING" "Unowned file found: $file"
            ((unowned_count++))
            if [ "$action" = "fix" ]; then
                log_message "INFO" "Setting owner to root for: $file"
                chown root "$file" 2>/dev/null
            fi
        fi
    done < <(find "$search_path" -nouser -print0 2>/dev/null)
    
    # Find files without valid group
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            log_message "WARNING" "Ungrouped file found: $file"
            ((ungrouped_count++))
            if [ "$action" = "fix" ]; then
                log_message "INFO" "Setting group to root for: $file"
                chgrp root "$file" 2>/dev/null
            fi
        fi
    done < <(find "$search_path" -nogroup -print0 2>/dev/null)
    
    log_message "INFO" "Found $unowned_count unowned files and $ungrouped_count ungrouped files"
    return 0
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"
    
    # Description: DESCRIPTION_PLACEHOLDER
    
    REMEDIATION_LOGIC_PLACEHOLDER
    
    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi
    
    main_remediation
    exit $?
fi
'''

    # Replace placeholders
    script_content = script_content.replace('SCRIPT_NAME_PLACEHOLDER', script_name)
    script_content = script_content.replace('REMEDIATION_NAME_PLACEHOLDER', remediation_name)
    script_content = script_content.replace('SERVER_LEVEL_PLACEHOLDER', server_level)
    script_content = script_content.replace('WORKSTATION_LEVEL_PLACEHOLDER', workstation_level)
    script_content = script_content.replace('DEFAULT_VALUE_PLACEHOLDER', default_value)
    script_content = script_content.replace('DESCRIPTION_PLACEHOLDER', description)
    
    return script_content

# Test with first row
test_row = df_section6.iloc[0].to_dict()
test_script = generate_script_template_section6(test_row)
print("Generated Section 6 template test successful!")
print(f"Template length: {len(test_script.split('\\n'))} lines")