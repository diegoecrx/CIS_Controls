# Oracle Linux 7 CIS Benchmark Section 6 - System Maintenance

## Overview
This package contains 25 bash scripts for CIS Oracle Linux 7 Benchmark Section 6 controls. These scripts focus on system maintenance, file permissions, and user/group integrity checks.

## Script Statistics
- **Total Scripts**: 25
- **Automated Scripts**: 23
- **Manual Scripts**: 2
- **Success Rate**: 100.0%

## Categories

### 🔐 System File Permissions (6.1.x) - 14 scripts
- **Critical System Files**: Set proper permissions on /etc/passwd, /etc/shadow, /etc/group, /etc/gshadow
- **Backup File Security**: Secure backup files (passwd-, shadow-, group-, gshadow-)
- **World Writable Files**: Identify and secure world-writable files and directories
- **File Ownership**: Find and fix unowned/ungrouped files and directories
- **SUID/SGID Review**: Audit SUID and SGID files for security risks

### 👥 User and Group Settings (6.2.x) - 11 scripts
- **Password Integrity**: Ensure password fields are properly configured
- **Duplicate Detection**: Find and report duplicate UIDs, GIDs, usernames, and group names
- **Root Account Security**: Verify root account uniqueness and PATH integrity
- **User Directory Security**: Check user home directory permissions and ownership
- **System Account Review**: Audit system accounts and access configurations

## Key Features

✅ **File Permission Management**: Automated setting of critical system file permissions
✅ **World Writable Security**: Comprehensive scanning and securing of world-writable files
✅ **Ownership Verification**: Detection and correction of unowned files and directories  
✅ **SUID/SGID Auditing**: Complete review of privileged executable files
✅ **User Integrity Checks**: Duplicate user/group detection and resolution
✅ **Root Security**: PATH integrity and account uniqueness verification
✅ **Comprehensive Logging**: Detailed operation tracking and security reporting

## Generated Scripts Detail

### System File Permission Controls
- 6.1.10_permissions_on_etc_security_opasswd_automated.sh
- 6.1.11_world_writable_files_and_directories_secured_automated.sh
- 6.1.12_no_unowned_or_ungrouped_files_or_directories_exist_automated.sh
- 6.1.13_suid_and_sgid_files_reviewed_manual.sh
- 6.1.14_audit_system_file_permissions_manual.sh
- 6.1.1_permissions_on_etc_passwd_automated.sh
- 6.1.2_permissions_on_etc_passwd-_automated.sh
- 6.1.3_permissions_on_etc_group_automated.sh
- 6.1.4_permissions_on_etc_group-_automated.sh
- 6.1.5_permissions_on_etc_shadow_automated.sh
- 6.1.6_permissions_on_etc_shadow-_automated.sh
- 6.1.7_permissions_on_etc_gshadow_automated.sh
- 6.1.8_permissions_on_etc_gshadow-_automated.sh
- 6.1.9_permissions_on_etc_shells_automated.sh

### User and Group Setting Controls  
- 6.2.10_local_interactive_user_home_directories_automated.sh
- 6.2.11_local_interactive_user_dot_files_access_automated.sh
- 6.2.1_accounts_in_etc_passwd_use_shadowed_passwords_automated.sh
- 6.2.2_etc_shadow_password_fields_not_empty_automated.sh
- 6.2.3_all_groups_in_etc_passwd_exist_in_etc_group_automated.sh
- 6.2.4_no_duplicate_uids_exist_automated.sh
- 6.2.5_no_duplicate_gids_exist_automated.sh
- 6.2.6_no_duplicate_user_names_exist_automated.sh
- 6.2.7_no_duplicate_group_names_exist_automated.sh
- 6.2.8_root_path_integrity_automated.sh
- 6.2.9_root_is_the_only_uid_0_account_automated.sh

## Usage Examples

### Automated Scripts
```bash
# Set critical file permissions
sudo ./6.1.1_permissions_on_etc_passwd_automated.sh
sudo ./6.1.5_permissions_on_etc_shadow_automated.sh

# Secure world writable files
sudo ./6.1.11_world_writable_files_and_directories_secured_automated.sh

# Fix unowned files
sudo ./6.1.12_no_unowned_or_ungrouped_files_or_directories_exist_automated.sh

# Check for duplicate users/groups
sudo ./6.2.4_no_duplicate_uids_exist_automated.sh
sudo ./6.2.8_root_path_integrity_automated.sh
```

### Manual Scripts
```bash
# Review SUID/SGID files
sudo ./6.1.13_suid_and_sgid_files_reviewed_manual.sh

# Audit system file permissions
sudo ./6.1.14_audit_system_file_permissions_manual.sh
```

## Critical System Files Managed

The Section 6 scripts secure these essential system files:
- **/etc/passwd**: User account information (644 permissions)
- **/etc/shadow**: Encrypted passwords (000/640 permissions)
- **/etc/group**: Group information (644 permissions) 
- **/etc/gshadow**: Group passwords (000/640 permissions)
- **/etc/security/opasswd**: Previous passwords (600 permissions)
- **Backup files**: All corresponding backup files (passwd-, shadow-, etc.)

## Security Features

### File Permission Enforcement
- **Automated Permission Setting**: Scripts automatically apply correct permissions
- **Permission Verification**: Built-in verification of applied permissions
- **Backup Protection**: Secure backup files with restrictive permissions

### World Writable File Security
- **Comprehensive Scanning**: System-wide search excluding safe locations
- **Smart Exclusions**: Avoids system directories like /proc, /sys, /run
- **Automated Remediation**: Removes world-write permissions from files
- **Sticky Bit Management**: Adds sticky bit to world-writable directories

### User/Group Integrity
- **Duplicate Detection**: Identifies duplicate UIDs, GIDs, usernames, groups
- **Password Field Validation**: Ensures no empty password fields
- **Root Account Protection**: Verifies root is the only UID 0 account
- **PATH Security**: Validates root PATH for security issues

## Configuration Impact

⚠️ **Important System Maintenance Considerations**:
- Scripts modify critical system file permissions
- World writable file changes may affect application functionality
- Unowned file ownership changes may impact system services
- Always test in non-production environment first
- Create full system backup before running scripts
- Some changes may require system restart for full effect

## Advanced Security Checks

### SUID/SGID File Review
- **Complete System Scan**: Finds all SUID and SGID files
- **Security Assessment**: Reports potentially risky privileged files
- **Manual Review Process**: Provides list for administrative review

### System File Audit
- **Critical File Verification**: Checks permissions on essential system files
- **Compliance Reporting**: Detailed compliance status for each file
- **Issue Detection**: Identifies permission and ownership problems

### User Directory Security
- **Home Directory Permissions**: Verifies proper user directory permissions
- **Dot File Security**: Checks hidden configuration file permissions
- **Interactive User Focus**: Concentrates on actual user accounts

---
*Section 6 scripts generated from CIS Oracle Linux 7 Benchmark*
*Generation completed: 2025-10-16 03:49:19*
*Successfully implemented 25 out of 25 controls*
