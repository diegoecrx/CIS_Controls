#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 6
# 6.1.10_permissions_on_etc_security_opasswd_automated
# 6.1.10 Ensure permissions on /etc/security/opasswd are configured (Automated)
# 
# This script implements system maintenance controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="6.1.10_permissions_on_etc_security_opasswd_automated"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 1"
profile_workstation="Level 1"
default_value="/etc/security/opasswd Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Backup function
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# File/directory permissions management
set_permissions() {
    local target_path="$1"
    local permissions="$2"
    local owner="$3"
    local group="$4"

    log_message "INFO" "Setting permissions on $target_path"

    # Check if target exists
    if [ ! -e "$target_path" ]; then
        log_message "ERROR" "Target path does not exist: $target_path"
        return 1
    fi

    # Set ownership if specified
    if [ -n "$owner" ] && [ -n "$group" ]; then
        if chown "$owner:$group" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set ownership $owner:$group on $target_path"
        else
            log_message "ERROR" "Failed to set ownership on $target_path"
            return 1
        fi
    fi

    # Set permissions if specified
    if [ -n "$permissions" ]; then
        if chmod "$permissions" "$target_path" 2>/dev/null; then
            log_message "SUCCESS" "Set permissions $permissions on $target_path"
        else
            log_message "ERROR" "Failed to set permissions on $target_path"
            return 1
        fi
    fi

    return 0
}

# User and group management
check_user_group() {
    local username="$1"
    local groupname="$2"

    if [ -n "$username" ]; then
        if ! id "$username" >/dev/null 2>&1; then
            log_message "WARNING" "User $username does not exist"
            return 1
        fi
    fi

    if [ -n "$groupname" ]; then
        if ! getent group "$groupname" >/dev/null 2>&1; then
            log_message "WARNING" "Group $groupname does not exist"
            return 1
        fi
    fi

    return 0
}

# Find and fix file permissions
fix_file_permissions() {
    local search_path="$1"
    local find_criteria="$2"
    local fix_action="$3"

    log_message "INFO" "Searching for files matching criteria: $find_criteria"

    local count=0
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            log_message "INFO" "Processing file: $file"
            case "$fix_action" in
                "fix_permissions")
                    chmod go-w "$file" 2>/dev/null && ((count++))
                    ;;
                "remove_suid")
                    chmod u-s "$file" 2>/dev/null && ((count++))
                    ;;
                "remove_sgid")
                    chmod g-s "$file" 2>/dev/null && ((count++))
                    ;;
                "add_sticky")
                    chmod +t "$file" 2>/dev/null && ((count++))
                    ;;
            esac
        fi
    done < <(find "$search_path" $find_criteria -print0 2>/dev/null)

    log_message "SUCCESS" "Processed $count files"
    return 0
}

# World writable files and directories management
secure_world_writable() {
    local search_path="${1:-/}"

    log_message "INFO" "Securing world writable files and directories"

    # Array to store excluded paths
    local -a exclude_paths=(
        "! -path /run/user/*"
        "! -path /proc/*"
        "! -path */containerd/*"
        "! -path */kubelet/pods/*"
        "! -path /sys/kernel/security/apparmor/*"
        "! -path /snap/*"
        "! -path /sys/fs/cgroup/memory/*"
        "! -path /sys/fs/selinux/*"
        "! -path /tmp/*"
        "! -path /var/tmp/*"
    )

    # Find world writable files and fix them
    log_message "INFO" "Finding and fixing world writable files..."
    local file_count=0
    while IFS= read -r -d '' file; do
        if [ -f "$file" ] && [ -w "$file" ]; then
            log_message "INFO" "Removing world write permission from: $file"
            if chmod o-w "$file" 2>/dev/null; then
                ((file_count++))
            fi
        fi
    done < <(find "$search_path" -type f -perm -0002 "${exclude_paths[@]}" -print0 2>/dev/null)

    # Find world writable directories and add sticky bit
    log_message "INFO" "Finding and securing world writable directories..."
    local dir_count=0
    while IFS= read -r -d '' dir; do
        if [ -d "$dir" ]; then
            # Check if sticky bit is already set
            if [ ! $(($(stat -c "%a" "$dir" 2>/dev/null || echo 0) & 01000)) -gt 0 ]; then
                log_message "INFO" "Adding sticky bit to directory: $dir"
                if chmod +t "$dir" 2>/dev/null; then
                    ((dir_count++))
                fi
            fi
        fi
    done < <(find "$search_path" -type d -perm -0002 "${exclude_paths[@]}" -print0 2>/dev/null)

    log_message "SUCCESS" "Secured $file_count world writable files and $dir_count directories"
    return 0
}

# Find files without owner or group
find_unowned_files() {
    local search_path="${1:-/}"
    local action="${2:-report}"

    log_message "INFO" "Searching for unowned/ungrouped files in $search_path"

    local unowned_count=0
    local ungrouped_count=0

    # Find files without valid owner
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            log_message "WARNING" "Unowned file found: $file"
            ((unowned_count++))
            if [ "$action" = "fix" ]; then
                log_message "INFO" "Setting owner to root for: $file"
                chown root "$file" 2>/dev/null
            fi
        fi
    done < <(find "$search_path" -nouser -print0 2>/dev/null)

    # Find files without valid group
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            log_message "WARNING" "Ungrouped file found: $file"
            ((ungrouped_count++))
            if [ "$action" = "fix" ]; then
                log_message "INFO" "Setting group to root for: $file"
                chgrp root "$file" 2>/dev/null
            fi
        fi
    done < <(find "$search_path" -nogroup -print0 2>/dev/null)

    log_message "INFO" "Found $unowned_count unowned files and $ungrouped_count ungrouped files"
    return 0
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"

    # Description: /etc/security/opasswd and it's backup /etc/security/opasswd.old hold user's
previous passwords if pam_unix or pam_pwhistory is in use on the system

    
    # CIS 6.1.10: Ensure permissions on /etc/security/opasswd are configured
    log_message "INFO" "Configuring permissions on /etc/security/opasswd"
    config_file="/etc/security/opasswd"

    if [ -f "/etc/security/opasswd" ]; then
        if set_permissions "/etc/security/opasswd" "600" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/security/opasswd permissions"
        else
            log_message "ERROR" "Failed to configure /etc/security/opasswd permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/security/opasswd does not exist"
    fi

    # Also check for backup file
    if [ -f "/etc/security/opasswd.old" ]; then
        if set_permissions "/etc/security/opasswd.old" "600" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/security/opasswd.old permissions"
        fi
    fi

    log_message "SUCCESS" "Remediation completed: $SCRIPT_NAME"
    return 0
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        exit 1
    fi

    main_remediation
    exit $?
fi
