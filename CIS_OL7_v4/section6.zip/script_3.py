# Generate all Section 6 scripts
scripts_generated_section6 = []
failed_scripts_section6 = []

print("=== GENERATING SECTION 6 SCRIPTS ===")

for index, row in df_section6.iterrows():
    try:
        # Generate base script
        script_content = generate_script_template_section6(row.to_dict())
        
        # Get specific remediation logic
        specific_logic = get_specific_remediation_logic_section6(row.to_dict())
        
        # Insert the logic
        script_content = script_content.replace('REMEDIATION_LOGIC_PLACEHOLDER', specific_logic)
        
        # Write script to file
        script_filename = f"{section6_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        # Make script executable
        os.chmod(script_filename, 0o755)
        
        scripts_generated_section6.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'filename': script_filename,
            'type': 'automated' if 'automated' in row['script_name'].lower() else 'manual'
        })
        
        if index < 10:  # Show first 10 for brevity
            print(f"Generated: {os.path.basename(script_filename)}")
        elif index == 10:
            print("... (continuing generation)")
        
    except Exception as e:
        failed_scripts_section6.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'error': str(e)
        })
        print(f"Failed to generate {row['id']}: {str(e)}")

print(f"\nSection 6 Generation Results:")
print(f"Successfully generated: {len(scripts_generated_section6)} scripts")
print(f"Failed to generate: {len(failed_scripts_section6)} scripts")

if failed_scripts_section6:
    print("\nFailed scripts:")
    for fail in failed_scripts_section6:
        print(f"  - {fail['id']}: {fail['error']}")

# Get final counts for verification
all_section6_scripts = glob.glob(f'{section6_dir}/*.sh')
print(f"Total Section 6 scripts in directory: {len(all_section6_scripts)}")

# Count by type
automated_scripts_section6 = [f for f in all_section6_scripts if 'automated' in f]
manual_scripts_section6 = [f for f in all_section6_scripts if 'manual' in f]

print(f"Automated scripts: {len(automated_scripts_section6)}")
print(f"Manual scripts: {len(manual_scripts_section6)}")

# Categorize scripts by functionality
file_perms_scripts = [f for f in all_section6_scripts if '6.1.' in f]
user_group_scripts = [f for f in all_section6_scripts if '6.2.' in f]

print(f"\n=== SECTION 6 BREAKDOWN BY CATEGORY ===")
print(f"System File Permissions (6.1.x): {len(file_perms_scripts)} scripts")
print(f"User and Group Settings (6.2.x): {len(user_group_scripts)} scripts")

print(f"\n✅ Section 6 script generation completed!")
print(f"All {len(all_section6_scripts)} scripts implement system maintenance security measures.")