import pandas as pd
import os
import glob

# Read the Section 6 spreadsheet
df_section6 = pd.read_excel('section6.xlsx')

print("=== SECTION 6 EXCEL FILE STRUCTURE ===")
print(f"Shape: {df_section6.shape}")
print(f"Columns: {list(df_section6.columns)}")
print("\n=== FIRST FEW ROWS ===")
print(df_section6.head())

print("\n=== DATA TYPES ===")
print(df_section6.dtypes)

print("\n=== COLUMN ANALYSIS ===")
for col in df_section6.columns:
    print(f"\n--- {col} ---")
    if col in df_section6.columns:
        print(f"Unique values: {df_section6[col].nunique()}")
        sample_values = df_section6[col].dropna().head(3).tolist()
        print(f"Sample values: {sample_values}")

print("\n=== SCRIPT NAME PATTERNS ===")
if 'script_name' in df_section6.columns:
    automated_count = sum(1 for name in df_section6['script_name'].dropna() if 'automated' in str(name).lower())
    manual_count = sum(1 for name in df_section6['script_name'].dropna() if 'manual' in str(name).lower())
    
    print(f"Automated scripts: {automated_count}")
    print(f"Manual scripts: {manual_count}")
    print(f"Total scripts to generate: {len(df_section6)}")

print("\n=== ID PATTERNS ===")
if 'id' in df_section6.columns:
    id_samples = df_section6['id'].dropna().head(10).tolist()
    print(f"ID samples: {id_samples}")
    
print("\n=== PROFILE PATTERNS ===")
if 'profile' in df_section6.columns:
    profile_patterns = df_section6['profile'].value_counts()
    print(profile_patterns.head(10))