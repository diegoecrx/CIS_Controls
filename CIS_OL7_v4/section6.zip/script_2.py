# Create specific remediation logic for Section 6 CIS controls (System Maintenance)
def get_specific_remediation_logic_section6(row_data):
    """Generate specific remediation logic based on Section 6 CIS control type"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # System File Permissions (6.1.x)
    if script_id == '6.1.1':
        return '''
    # CIS 6.1.1: Ensure permissions on /etc/passwd are configured
    log_message "INFO" "Configuring permissions on /etc/passwd"
    config_file="/etc/passwd"
    
    if set_permissions "/etc/passwd" "644" "root" "root"; then
        # Verify permissions
        actual_perms=$(stat -c "%a" "/etc/passwd")
        if [ "$actual_perms" = "644" ]; then
            log_message "SUCCESS" "Verified /etc/passwd permissions: 644"
        else
            log_message "WARNING" "Permission verification failed: expected 644, got $actual_perms"
        fi
    else
        log_message "ERROR" "Failed to configure /etc/passwd permissions"
        return 1
    fi'''
    
    elif script_id == '6.1.2':
        return '''
    # CIS 6.1.2: Ensure permissions on /etc/shadow are configured
    log_message "INFO" "Configuring permissions on /etc/shadow"
    config_file="/etc/shadow"
    
    if set_permissions "/etc/shadow" "000" "root" "root"; then
        actual_perms=$(stat -c "%a" "/etc/shadow")
        if [ "$actual_perms" = "000" ] || [ "$actual_perms" = "640" ]; then
            log_message "SUCCESS" "Verified /etc/shadow permissions: $actual_perms"
        else
            log_message "WARNING" "Permission verification failed: expected 000 or 640, got $actual_perms"
        fi
    else
        log_message "ERROR" "Failed to configure /etc/shadow permissions"
        return 1
    fi'''
    
    elif script_id == '6.1.3':
        return '''
    # CIS 6.1.3: Ensure permissions on /etc/group are configured
    log_message "INFO" "Configuring permissions on /etc/group"
    config_file="/etc/group"
    
    if set_permissions "/etc/group" "644" "root" "root"; then
        actual_perms=$(stat -c "%a" "/etc/group")
        if [ "$actual_perms" = "644" ]; then
            log_message "SUCCESS" "Verified /etc/group permissions: 644"
        else
            log_message "WARNING" "Permission verification failed: expected 644, got $actual_perms"
        fi
    else
        log_message "ERROR" "Failed to configure /etc/group permissions"
        return 1
    fi'''
    
    elif script_id == '6.1.4':
        return '''
    # CIS 6.1.4: Ensure permissions on /etc/gshadow are configured
    log_message "INFO" "Configuring permissions on /etc/gshadow"
    config_file="/etc/gshadow"
    
    if set_permissions "/etc/gshadow" "000" "root" "root"; then
        actual_perms=$(stat -c "%a" "/etc/gshadow")
        if [ "$actual_perms" = "000" ] || [ "$actual_perms" = "640" ]; then
            log_message "SUCCESS" "Verified /etc/gshadow permissions: $actual_perms"
        else
            log_message "WARNING" "Permission verification failed: expected 000 or 640, got $actual_perms"
        fi
    else
        log_message "ERROR" "Failed to configure /etc/gshadow permissions"
        return 1
    fi'''
    
    elif script_id == '6.1.5':
        return '''
    # CIS 6.1.5: Ensure permissions on /etc/passwd- are configured
    log_message "INFO" "Configuring permissions on /etc/passwd-"
    config_file="/etc/passwd-"
    
    if [ -f "/etc/passwd-" ]; then
        if set_permissions "/etc/passwd-" "644" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/passwd- permissions"
        else
            log_message "ERROR" "Failed to configure /etc/passwd- permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/passwd- does not exist"
    fi'''
    
    elif script_id == '6.1.6':
        return '''
    # CIS 6.1.6: Ensure permissions on /etc/shadow- are configured
    log_message "INFO" "Configuring permissions on /etc/shadow-"
    config_file="/etc/shadow-"
    
    if [ -f "/etc/shadow-" ]; then
        if set_permissions "/etc/shadow-" "000" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/shadow- permissions"
        else
            log_message "ERROR" "Failed to configure /etc/shadow- permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/shadow- does not exist"
    fi'''
    
    elif script_id == '6.1.7':
        return '''
    # CIS 6.1.7: Ensure permissions on /etc/group- are configured
    log_message "INFO" "Configuring permissions on /etc/group-"
    config_file="/etc/group-"
    
    if [ -f "/etc/group-" ]; then
        if set_permissions "/etc/group-" "644" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/group- permissions"
        else
            log_message "ERROR" "Failed to configure /etc/group- permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/group- does not exist"
    fi'''
    
    elif script_id == '6.1.8':
        return '''
    # CIS 6.1.8: Ensure permissions on /etc/gshadow- are configured
    log_message "INFO" "Configuring permissions on /etc/gshadow-"
    config_file="/etc/gshadow-"
    
    if [ -f "/etc/gshadow-" ]; then
        if set_permissions "/etc/gshadow-" "000" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/gshadow- permissions"
        else
            log_message "ERROR" "Failed to configure /etc/gshadow- permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/gshadow- does not exist"
    fi'''
    
    elif script_id == '6.1.9':
        return '''
    # CIS 6.1.9: Ensure permissions on /etc/motd are configured
    log_message "INFO" "Configuring permissions on /etc/motd"
    config_file="/etc/motd"
    
    if [ -f "/etc/motd" ]; then
        if set_permissions "/etc/motd" "644" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/motd permissions"
        else
            log_message "ERROR" "Failed to configure /etc/motd permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/motd does not exist"
    fi'''
    
    elif script_id == '6.1.10':
        return '''
    # CIS 6.1.10: Ensure permissions on /etc/security/opasswd are configured
    log_message "INFO" "Configuring permissions on /etc/security/opasswd"
    config_file="/etc/security/opasswd"
    
    if [ -f "/etc/security/opasswd" ]; then
        if set_permissions "/etc/security/opasswd" "600" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/security/opasswd permissions"
        else
            log_message "ERROR" "Failed to configure /etc/security/opasswd permissions"
            return 1
        fi
    else
        log_message "INFO" "File /etc/security/opasswd does not exist"
    fi
    
    # Also check for backup file
    if [ -f "/etc/security/opasswd.old" ]; then
        if set_permissions "/etc/security/opasswd.old" "600" "root" "root"; then
            log_message "SUCCESS" "Configured /etc/security/opasswd.old permissions"
        fi
    fi'''
    
    elif script_id == '6.1.11':
        return '''
    # CIS 6.1.11: Ensure world writable files and directories are secured
    log_message "INFO" "Securing world writable files and directories"
    
    if secure_world_writable "/"; then
        log_message "SUCCESS" "World writable files and directories have been secured"
    else
        log_message "ERROR" "Failed to secure some world writable files/directories"
        return 1
    fi'''
    
    elif script_id == '6.1.12':
        return '''
    # CIS 6.1.12: Ensure no unowned or ungrouped files or directories exist
    log_message "INFO" "Finding and fixing unowned/ungrouped files"
    
    # First, report unowned files
    find_unowned_files "/" "report"
    
    # Ask for confirmation before fixing (in automated mode, auto-fix)
    log_message "WARNING" "Found unowned/ungrouped files - setting ownership to root"
    
    if find_unowned_files "/" "fix"; then
        log_message "SUCCESS" "Fixed ownership for unowned/ungrouped files"
    else
        log_message "ERROR" "Failed to fix some unowned/ungrouped files"
        return 1
    fi'''
    
    elif script_id == '6.1.13':
        return '''
    # CIS 6.1.13: Ensure SUID and SGID files are reviewed
    log_message "INFO" "Reviewing SUID and SGID files"
    
    # Find SUID files
    log_message "INFO" "Searching for SUID files..."
    suid_count=0
    while IFS= read -r -d '' file; do
        if [ -f "$file" ]; then
            log_message "INFO" "SUID file found: $file"
            ((suid_count++))
        fi
    done < <(find / -type f -perm -4000 -print0 2>/dev/null)
    
    # Find SGID files
    log_message "INFO" "Searching for SGID files..."
    sgid_count=0
    while IFS= read -r -d '' file; do
        if [ -f "$file" ]; then
            log_message "INFO" "SGID file found: $file"
            ((sgid_count++))
        fi
    done < <(find / -type f -perm -2000 -print0 2>/dev/null)
    
    log_message "SUCCESS" "Found $suid_count SUID files and $sgid_count SGID files"
    log_message "WARNING" "Please review these files and remove SUID/SGID bits if not needed"'''
    
    elif script_id == '6.1.14':
        return '''
    # CIS 6.1.14: Audit system file permissions
    log_message "INFO" "Auditing system file permissions"
    
    # Check critical system files
    critical_files=(
        "/etc/passwd:644:root:root"
        "/etc/shadow:000:root:root"
        "/etc/group:644:root:root"
        "/etc/gshadow:000:root:root"
        "/etc/hosts:644:root:root"
        "/etc/fstab:644:root:root"
        "/etc/sudoers:440:root:root"
        "/boot/grub2/grub.cfg:600:root:root"
    )
    
    issues_found=0
    for file_spec in "${critical_files[@]}"; do
        IFS=':' read -r file_path expected_perms expected_owner expected_group <<< "$file_spec"
        
        if [ -f "$file_path" ]; then
            actual_perms=$(stat -c "%a" "$file_path" 2>/dev/null)
            actual_owner=$(stat -c "%U" "$file_path" 2>/dev/null)
            actual_group=$(stat -c "%G" "$file_path" 2>/dev/null)
            
            if [ "$actual_perms" != "$expected_perms" ] || 
               [ "$actual_owner" != "$expected_owner" ] || 
               [ "$actual_group" != "$expected_group" ]; then
                log_message "WARNING" "Permission issue: $file_path (expected: $expected_perms:$expected_owner:$expected_group, actual: $actual_perms:$actual_owner:$actual_group)"
                ((issues_found++))
            else
                log_message "SUCCESS" "Permissions correct: $file_path"
            fi
        else
            log_message "INFO" "File not found: $file_path"
        fi
    done
    
    if [ $issues_found -eq 0 ]; then
        log_message "SUCCESS" "All checked system files have correct permissions"
    else
        log_message "WARNING" "Found $issues_found permission issues"
    fi'''
    
    # User and Group Reviews (6.2.x)
    elif script_id.startswith('6.2.'):
        user_controls = {
            '6.2.1': 'password_fields',
            '6.2.2': 'shadow_password_fields', 
            '6.2.3': 'group_fields',
            '6.2.4': 'gshadow_fields',
            '6.2.5': 'duplicate_uid',
            '6.2.6': 'duplicate_gid',
            '6.2.7': 'duplicate_usernames',
            '6.2.8': 'duplicate_groupnames',
            '6.2.9': 'root_path',
            '6.2.10': 'user_home_directories',
            '6.2.11': 'user_home_permissions',
            '6.2.12': 'user_dot_files',
            '6.2.13': 'forward_files',
            '6.2.14': 'netrc_files',
            '6.2.15': 'rhosts_files'
        }
        
        if script_id == '6.2.1':
            return '''
    # CIS 6.2.1: Ensure password fields are not empty
    log_message "INFO" "Checking for empty password fields"
    
    empty_passwords=0
    while IFS=':' read -r username password rest; do
        if [ -z "$password" ] || [ "$password" = "" ]; then
            log_message "WARNING" "User $username has empty password field"
            ((empty_passwords++))
        fi
    done < /etc/shadow
    
    if [ $empty_passwords -eq 0 ]; then
        log_message "SUCCESS" "No empty password fields found"
    else
        log_message "ERROR" "Found $empty_passwords users with empty password fields"
        return 1
    fi'''
        
        elif script_id == '6.2.2':
            return '''
    # CIS 6.2.2: Ensure shadow password fields are not empty
    log_message "INFO" "Checking shadow password fields"
    
    # This is similar to 6.2.1 but focuses on shadow file specifically
    shadow_issues=0
    while IFS=':' read -r username password lastchange mindays maxdays warndays inactive expire reserved; do
        if [ -z "$password" ] && [ "$username" != "halt" ] && [ "$username" != "shutdown" ] && [ "$username" != "sync" ]; then
            log_message "WARNING" "User $username has empty password in shadow file"
            ((shadow_issues++))
        fi
    done < /etc/shadow
    
    if [ $shadow_issues -eq 0 ]; then
        log_message "SUCCESS" "No shadow password field issues found"
    else
        log_message "WARNING" "Found $shadow_issues shadow password issues"
    fi'''
        
        elif script_id == '6.2.5':
            return '''
    # CIS 6.2.5: Ensure no duplicate UIDs exist
    log_message "INFO" "Checking for duplicate UIDs"
    
    duplicate_uids=$(awk -F: '{print $3}' /etc/passwd | sort | uniq -d)
    
    if [ -z "$duplicate_uids" ]; then
        log_message "SUCCESS" "No duplicate UIDs found"
    else
        log_message "ERROR" "Duplicate UIDs found:"
        for uid in $duplicate_uids; do
            log_message "ERROR" "UID $uid is used by:"
            awk -F: "\$3 == $uid {print \$1}" /etc/passwd | while read user; do
                log_message "ERROR" "  - $user"
            done
        done
        return 1
    fi'''
        
        elif script_id == '6.2.6':
            return '''
    # CIS 6.2.6: Ensure no duplicate GIDs exist  
    log_message "INFO" "Checking for duplicate GIDs"
    
    duplicate_gids=$(awk -F: '{print $3}' /etc/group | sort | uniq -d)
    
    if [ -z "$duplicate_gids" ]; then
        log_message "SUCCESS" "No duplicate GIDs found"
    else
        log_message "ERROR" "Duplicate GIDs found:"
        for gid in $duplicate_gids; do
            log_message "ERROR" "GID $gid is used by:"
            awk -F: "\$3 == $gid {print \$1}" /etc/group | while read group; do
                log_message "ERROR" "  - $group"
            done
        done
        return 1
    fi'''
        
        elif script_id == '6.2.7':
            return '''
    # CIS 6.2.7: Ensure no duplicate usernames exist
    log_message "INFO" "Checking for duplicate usernames"
    
    duplicate_users=$(awk -F: '{print $1}' /etc/passwd | sort | uniq -d)
    
    if [ -z "$duplicate_users" ]; then
        log_message "SUCCESS" "No duplicate usernames found"
    else
        log_message "ERROR" "Duplicate usernames found: $duplicate_users"
        return 1
    fi'''
        
        elif script_id == '6.2.8':
            return '''
    # CIS 6.2.8: Ensure no duplicate group names exist
    log_message "INFO" "Checking for duplicate group names"
    
    duplicate_groups=$(awk -F: '{print $1}' /etc/group | sort | uniq -d)
    
    if [ -z "$duplicate_groups" ]; then
        log_message "SUCCESS" "No duplicate group names found"
    else
        log_message "ERROR" "Duplicate group names found: $duplicate_groups"
        return 1
    fi'''
        
        elif script_id == '6.2.9':
            return '''
    # CIS 6.2.9: Ensure root PATH integrity
    log_message "INFO" "Checking root PATH integrity"
    
    path_issues=0
    
    # Check if PATH contains current directory
    if echo "$PATH" | grep -q "::"; then
        log_message "ERROR" "Root PATH contains empty directory (::)"
        ((path_issues++))
    fi
    
    if echo "$PATH" | grep -q "^:"; then
        log_message "ERROR" "Root PATH starts with colon"
        ((path_issues++))
    fi
    
    if echo "$PATH" | grep -q ":$"; then
        log_message "ERROR" "Root PATH ends with colon"
        ((path_issues++))
    fi
    
    # Check each directory in PATH
    IFS=':' read -ra DIRS <<< "$PATH"
    for dir in "${DIRS[@]}"; do
        if [ -d "$dir" ]; then
            perm=$(stat -c "%a" "$dir" 2>/dev/null)
            owner=$(stat -c "%U" "$dir" 2>/dev/null)
            
            if [ $((perm & 22)) -ne 0 ]; then
                log_message "ERROR" "Directory $dir is group/world writable"
                ((path_issues++))
            fi
            
            if [ "$owner" != "root" ]; then
                log_message "ERROR" "Directory $dir is not owned by root"
                ((path_issues++))
            fi
        fi
    done
    
    if [ $path_issues -eq 0 ]; then
        log_message "SUCCESS" "Root PATH integrity verified"
    else
        log_message "ERROR" "Found $path_issues PATH integrity issues"
        return 1
    fi'''
        
        else:
            return f'''
    # CIS {script_id}: User and group configuration audit
    log_message "INFO" "Auditing user and group configurations for {script_id}"
    
    log_message "WARNING" "This control requires manual review"
    log_message "INFO" "Please review user and group configurations according to CIS guidelines"
    
    return 2  # Manual review required'''
    
    # Default case for unknown controls
    else:
        return f'''
    # CIS {script_id}: Section 6 system maintenance remediation
    config_file=""
    
    log_message "INFO" "Applying remediation for: {script_id}"
    log_message "INFO" "Description: {description[:100]}..."
    
    # This control may require manual configuration
    log_message "WARNING" "Please review CIS benchmark documentation for specific requirements"
    log_message "INFO" "Remediation guidance: {remediation[:200] if remediation else 'See CIS documentation'}"
    
    return 2  # Manual intervention may be required'''

# Test specific logic generation
test_logic = get_specific_remediation_logic_section6(df_section6.iloc[0].to_dict())
print("Sample specific remediation logic for /etc/passwd permissions:")
print(test_logic)