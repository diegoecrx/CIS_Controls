#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 3
# 3.4.3.2_iptables_flushed_with_nftables_manual
# 3.4.3.2 Ensure iptables are flushed with nftables (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="3.4.3.2_iptables_flushed_with_nftables_manual"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 1"
profile_workstation="Level 1"
default_value=""

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function with error categorization
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    # Also log to error log if it's an error
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Enhanced backup function with validation
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    if [ ! -r "$file_path" ]; then
        log_message "ERROR" "Cannot read file for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        echo "$BACKUP_DIR/$backup_name"  # Return backup path
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Sysctl parameter configuration function
configure_sysctl() {
    local param_name="$1"
    local param_value="$2"
    local config_file="${3:-/etc/sysctl.conf}"

    log_message "INFO" "Configuring sysctl parameter: $param_name = $param_value"

    # Backup sysctl configuration
    backup_file "$config_file"

    # Remove any existing parameter entries
    sed -i "/^$param_name/d" "$config_file" 2>/dev/null

    # Add the new parameter
    echo "$param_name = $param_value" >> "$config_file"

    # Apply immediately
    if sysctl -w "$param_name=$param_value" >/dev/null 2>&1; then
        log_message "SUCCESS" "Applied sysctl parameter: $param_name = $param_value"
        return 0
    else
        log_message "ERROR" "Failed to apply sysctl parameter: $param_name"
        return 1
    fi
}

# Network interface management
manage_network_interface() {
    local action="$1"
    local interface="$2"

    case "$action" in
        "disable")
            if ip link show "$interface" >/dev/null 2>&1; then
                if ip link set "$interface" down 2>/dev/null; then
                    log_message "SUCCESS" "Disabled network interface: $interface"
                    return 0
                else
                    log_message "ERROR" "Failed to disable interface: $interface"
                    return 1
                fi
            else
                log_message "INFO" "Interface does not exist: $interface"
                return 0
            fi
        ;;
        "enable")
            if ip link show "$interface" >/dev/null 2>&1; then
                if ip link set "$interface" up 2>/dev/null; then
                    log_message "SUCCESS" "Enabled network interface: $interface"
                    return 0
                else
                    log_message "ERROR" "Failed to enable interface: $interface"
                    return 1
                fi
            else
                log_message "ERROR" "Interface does not exist: $interface"
                return 1
            fi
        ;;
    esac
}

# Service management with proper error handling
manage_service() {
    local action="$1"
    local service_name="$2"

    case "$action" in
        "enable")
            if systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already enabled"
                return 0
            fi

            if systemctl enable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Enabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to enable service: $service_name"
                return 1
            fi
        ;;
        "disable")
            if ! systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already disabled"
                return 0
            fi

            if systemctl disable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Disabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to disable service: $service_name"
                return 1
            fi
        ;;
        "start")
            if systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already running"
                return 0
            fi

            if systemctl start "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Started service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to start service: $service_name"
                return 1
            fi
        ;;
        "stop")
            if ! systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already stopped"
                return 0
            fi

            if systemctl stop "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Stopped service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to stop service: $service_name"
                return 1
            fi
        ;;
        "mask")
            if systemctl is-masked "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already masked"
                return 0
            fi

            if systemctl mask "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Masked service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to mask service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management function
manage_package() {
    local action="$1"
    local package_name="$2"

    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi

            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi

            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# Kernel module blacklist function
blacklist_module() {
    local module_name="$1"
    local blacklist_file="/etc/modprobe.d/blacklist-$module_name.conf"

    log_message "INFO" "Blacklisting kernel module: $module_name"

    # Check if already blacklisted
    if [ -f "$blacklist_file" ] && grep -q "install $module_name /bin/false" "$blacklist_file"; then
        log_message "INFO" "Module $module_name is already blacklisted"
        return 0
    fi

    # Create blacklist entry
    if echo "install $module_name /bin/false" > "$blacklist_file"; then
        log_message "SUCCESS" "Created blacklist file: $blacklist_file"

        # Also add explicit blacklist
        echo "blacklist $module_name" >> "$blacklist_file"

        # Remove module if currently loaded
        if lsmod | grep -q "^$module_name "; then
            if modprobe -r "$module_name" 2>/dev/null; then
                log_message "SUCCESS" "Removed loaded module: $module_name"
            else
                log_message "WARNING" "Could not remove currently loaded module: $module_name"
            fi
        fi
        return 0
    else
        log_message "ERROR" "Failed to create blacklist file: $blacklist_file"
        return 1
    fi
}

# IPv6 configuration function
configure_ipv6() {
    local action="$1"  # "disable" or "enable"

    case "$action" in
        "disable")
            log_message "INFO" "Disabling IPv6"

            # Configure sysctl parameters to disable IPv6
            configure_sysctl "net.ipv6.conf.all.disable_ipv6" "1"
            configure_sysctl "net.ipv6.conf.default.disable_ipv6" "1"

            # Also add to GRUB boot parameters
            if [ -f /etc/default/grub ]; then
                backup_file "/etc/default/grub"
                if ! grep -q "ipv6.disable=1" /etc/default/grub; then
                    sed -i 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="ipv6.disable=1 /' /etc/default/grub
                    grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1
                    log_message "SUCCESS" "Added IPv6 disable parameter to GRUB"
                fi
            fi
        ;;
        "enable")
            log_message "INFO" "Enabling IPv6"

            # Configure sysctl parameters to enable IPv6
            configure_sysctl "net.ipv6.conf.all.disable_ipv6" "0"
            configure_sysctl "net.ipv6.conf.default.disable_ipv6" "0"
        ;;
    esac
}

# User interaction for manual remediation
user_menu() {
    echo "=============================================="
    echo "Manual Remediation: $SCRIPT_NAME"
    echo "3.4.3.2 Ensure iptables are flushed with nftables (Manual)"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "nftables is a replacement for iptables, ip6tables, ebtables and arptables"
    echo ""
    echo "Configuration file: $config_file"
    echo "Profile Server: $profile_srv"  
    echo "Profile Workstation: $profile_workstation"
    echo "Default value: $default_value"
    echo ""
    echo "Please choose an option:"
    echo "1) Execute/Force the remediation (will create backup)"
    echo "2) Show remediation commands only (no execution)"
    echo "3) Exit"
    echo ""
    read -p "Enter your choice [1-3]: " choice

    case $choice in
        1)
            execute_remediation
        ;;
        2)  
            show_remediation_commands
        ;;
        3)
            echo "Exiting..."
            exit 0
        ;;
        *)
            echo "Invalid option. Please try again."
            user_menu
        ;;
    esac
}

# Execute manual remediation with backup
execute_remediation() {
    log_message "INFO" "Starting manual remediation execution: $SCRIPT_NAME"

    # Create backup before executing
    if [ -n "$config_file" ] && [ -f "$config_file" ]; then
        backup_file "$config_file"
        if [ $? -ne 0 ]; then
            log_message "ERROR" "Failed to create backup. Aborting remediation."
            return 1
        fi
    fi

    # Set error handling
    set -e
    trap 'log_message "ERROR" "Manual remediation failed at line $LINENO"; exit 1' ERR

    # 3.4.3.2 Ensure iptables are flushed with nftables (Manual)
    # Description: nftables is a replacement for iptables, ip6tables, ebtables and arptables


    # CIS 3.4.3.2: Firewall configuration
    log_message "INFO" "Configuring firewall settings for 3.4.3.2"
    log_message "WARNING" "Manual firewall configuration required"
    log_message "INFO" "Please configure according to organizational security policy"

    # Firewall configuration is highly environment-specific
    # Please customize according to your organization's requirements

    return 2  # Manual intervention required

    local exit_code=$?

    if [ $exit_code -eq 0 ]; then
        log_message "SUCCESS" "Manual remediation executed successfully: $SCRIPT_NAME"
        echo "Remediation completed successfully!"
    else
        log_message "ERROR" "Manual remediation failed: $SCRIPT_NAME (exit code: $exit_code)"
        echo "Remediation failed! Check logs for details."
    fi

    return $exit_code
}

# Show remediation commands without execution
show_remediation_commands() {
    log_message "INFO" "Showing remediation commands for: $SCRIPT_NAME"

    echo "=============================================="
    echo "REMEDIATION COMMANDS (NOT EXECUTED)"
    echo "=============================================="
    echo ""
    echo "Configuration file path: $config_file"
    echo "Original file location: $config_file"
    echo ""
    echo "Commands that would be executed:"
    echo ""

    echo "The following remediation would be performed:"\n
    # CIS 3.4.3.2: Firewall configuration
    echo "# Command:" "INFO" "Configuring firewall settings for 3.4.3.2"
    echo "# Command:" "WARNING" "Manual firewall configuration required"
    echo "# Command:" "INFO" "Please configure according to organizational security policy"

    # Firewall configuration is highly environment-specific
    # Please customize according to your organization's requirements

    return 2  # Manual intervention required

    echo "=============================================="
    echo "END OF COMMANDS"
    echo "=============================================="
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    # Verify running as root  
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi

    # Start user menu for manual remediation
    user_menu
fi
