#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark - Section 3
# 3.4.3.3_an_nftables_table_exists_automated
# 3.4.3.3 Ensure an nftables table exists (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

# Script Configuration
SCRIPT_NAME="3.4.3.3_an_nftables_table_exists_automated"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Parameters
config_file=""
profile_srv="Level 1"
profile_workstation="Level 1"
default_value=""

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function with error categorization
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    # Also log to error log if it's an error
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Enhanced backup function with validation
backup_file() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    if [ ! -r "$file_path" ]; then
        log_message "ERROR" "Cannot read file for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        echo "$BACKUP_DIR/$backup_name"  # Return backup path
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Sysctl parameter configuration function
configure_sysctl() {
    local param_name="$1"
    local param_value="$2"
    local config_file="${3:-/etc/sysctl.conf}"

    log_message "INFO" "Configuring sysctl parameter: $param_name = $param_value"

    # Backup sysctl configuration
    backup_file "$config_file"

    # Remove any existing parameter entries
    sed -i "/^$param_name/d" "$config_file" 2>/dev/null

    # Add the new parameter
    echo "$param_name = $param_value" >> "$config_file"

    # Apply immediately
    if sysctl -w "$param_name=$param_value" >/dev/null 2>&1; then
        log_message "SUCCESS" "Applied sysctl parameter: $param_name = $param_value"
        return 0
    else
        log_message "ERROR" "Failed to apply sysctl parameter: $param_name"
        return 1
    fi
}

# Network interface management
manage_network_interface() {
    local action="$1"
    local interface="$2"

    case "$action" in
        "disable")
            if ip link show "$interface" >/dev/null 2>&1; then
                if ip link set "$interface" down 2>/dev/null; then
                    log_message "SUCCESS" "Disabled network interface: $interface"
                    return 0
                else
                    log_message "ERROR" "Failed to disable interface: $interface"
                    return 1
                fi
            else
                log_message "INFO" "Interface does not exist: $interface"
                return 0
            fi
        ;;
        "enable")
            if ip link show "$interface" >/dev/null 2>&1; then
                if ip link set "$interface" up 2>/dev/null; then
                    log_message "SUCCESS" "Enabled network interface: $interface"
                    return 0
                else
                    log_message "ERROR" "Failed to enable interface: $interface"
                    return 1
                fi
            else
                log_message "ERROR" "Interface does not exist: $interface"
                return 1
            fi
        ;;
    esac
}

# Service management with proper error handling
manage_service() {
    local action="$1"
    local service_name="$2"

    case "$action" in
        "enable")
            if systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already enabled"
                return 0
            fi

            if systemctl enable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Enabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to enable service: $service_name"
                return 1
            fi
        ;;
        "disable")
            if ! systemctl is-enabled "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already disabled"
                return 0
            fi

            if systemctl disable "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Disabled service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to disable service: $service_name"
                return 1
            fi
        ;;
        "start")
            if systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already running"
                return 0
            fi

            if systemctl start "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Started service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to start service: $service_name"
                return 1
            fi
        ;;
        "stop")
            if ! systemctl is-active "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already stopped"
                return 0
            fi

            if systemctl stop "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Stopped service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to stop service: $service_name"
                return 1
            fi
        ;;
        "mask")
            if systemctl is-masked "$service_name" >/dev/null 2>&1; then
                log_message "INFO" "Service $service_name is already masked"
                return 0
            fi

            if systemctl mask "$service_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Masked service: $service_name"
                return 0
            else
                log_message "ERROR" "Failed to mask service: $service_name"
                return 1
            fi
        ;;
    esac
}

# Package management function
manage_package() {
    local action="$1"
    local package_name="$2"

    case "$action" in
        "install")
            if rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is already installed"
                return 0
            fi

            if yum install -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Installed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to install package: $package_name"
                return 1
            fi
        ;;
        "remove")
            if ! rpm -q "$package_name" >/dev/null 2>&1; then
                log_message "INFO" "Package $package_name is not installed"
                return 0
            fi

            if yum remove -y "$package_name" >/dev/null 2>&1; then
                log_message "SUCCESS" "Removed package: $package_name"
                return 0
            else
                log_message "ERROR" "Failed to remove package: $package_name"
                return 1
            fi
        ;;
    esac
}

# Kernel module blacklist function
blacklist_module() {
    local module_name="$1"
    local blacklist_file="/etc/modprobe.d/blacklist-$module_name.conf"

    log_message "INFO" "Blacklisting kernel module: $module_name"

    # Check if already blacklisted
    if [ -f "$blacklist_file" ] && grep -q "install $module_name /bin/false" "$blacklist_file"; then
        log_message "INFO" "Module $module_name is already blacklisted"
        return 0
    fi

    # Create blacklist entry
    if echo "install $module_name /bin/false" > "$blacklist_file"; then
        log_message "SUCCESS" "Created blacklist file: $blacklist_file"

        # Also add explicit blacklist
        echo "blacklist $module_name" >> "$blacklist_file"

        # Remove module if currently loaded
        if lsmod | grep -q "^$module_name "; then
            if modprobe -r "$module_name" 2>/dev/null; then
                log_message "SUCCESS" "Removed loaded module: $module_name"
            else
                log_message "WARNING" "Could not remove currently loaded module: $module_name"
            fi
        fi
        return 0
    else
        log_message "ERROR" "Failed to create blacklist file: $blacklist_file"
        return 1
    fi
}

# IPv6 configuration function
configure_ipv6() {
    local action="$1"  # "disable" or "enable"

    case "$action" in
        "disable")
            log_message "INFO" "Disabling IPv6"

            # Configure sysctl parameters to disable IPv6
            configure_sysctl "net.ipv6.conf.all.disable_ipv6" "1"
            configure_sysctl "net.ipv6.conf.default.disable_ipv6" "1"

            # Also add to GRUB boot parameters
            if [ -f /etc/default/grub ]; then
                backup_file "/etc/default/grub"
                if ! grep -q "ipv6.disable=1" /etc/default/grub; then
                    sed -i 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="ipv6.disable=1 /' /etc/default/grub
                    grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1
                    log_message "SUCCESS" "Added IPv6 disable parameter to GRUB"
                fi
            fi
        ;;
        "enable")
            log_message "INFO" "Enabling IPv6"

            # Configure sysctl parameters to enable IPv6
            configure_sysctl "net.ipv6.conf.all.disable_ipv6" "0"
            configure_sysctl "net.ipv6.conf.default.disable_ipv6" "0"
        ;;
    esac
}

# Main automated remediation function
main_remediation() {
    log_message "INFO" "Starting automated remediation: $SCRIPT_NAME"

    # Set error handling
    set -e
    trap 'log_message "ERROR" "Script failed at line $LINENO"; exit 1' ERR

    # 3.4.3.3 Ensure an nftables table exists (Automated)
    # Description: Tables hold chains. Each table only has one address family and only applies to packets
of this family. Tables can have one of five families.


    # CIS 3.4.3.3: Firewall configuration
    log_message "INFO" "Configuring firewall settings for 3.4.3.3"
    log_message "WARNING" "Manual firewall configuration required"
    log_message "INFO" "Please configure according to organizational security policy"

    # Firewall configuration is highly environment-specific
    # Please customize according to your organization's requirements

    return 2  # Manual intervention required

    local exit_code=$?

    if [ $exit_code -eq 0 ]; then
        log_message "SUCCESS" "Automated remediation completed successfully: $SCRIPT_NAME"
    else
        log_message "ERROR" "Automated remediation failed: $SCRIPT_NAME (exit code: $exit_code)"
    fi

    return $exit_code
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    # Verify running as root
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi

    # Execute automated remediation
    main_remediation
    exit $?
fi
