# Oracle Linux 7 CIS Benchmark Section 3 - Network Configuration

## Overview
This package contains 46 bash scripts for CIS Oracle Linux 7 Benchmark Section 3 controls. These scripts focus on network security configuration, protocol hardening, and firewall management.

## Script Statistics
- **Total Scripts**: 46
- **Automated Scripts**: 39
- **Manual Scripts**: 7
- **Success Rate**: 100.0%

## Categories

### Network Configuration (3.1.x) - 3 scripts
- **IPv6 Management**: Identify and configure IPv6 status
- **Wireless Security**: Disable wireless interfaces and blacklist drivers
- **Bluetooth Control**: Disable bluetooth services and packages

### Uncommon Network Protocols (3.2.x) - 4 scripts
Blacklist unnecessary and potentially vulnerable kernel modules:
- **DCCP**: Datagram Congestion Control Protocol
- **TIPC**: Transparent Inter-Process Communication  
- **RDS**: Reliable Datagram Sockets
- **SCTP**: Stream Control Transmission Protocol

### Network Parameters (3.3.x) - 11 scripts
Configure kernel network security parameters via sysctl:
- **IP Forwarding**: Disable packet forwarding
- **ICMP Controls**: Configure ICMP redirect and broadcast handling
- **Source Routing**: Disable source routed packets
- **TCP Security**: Enable SYN cookies and reverse path filtering
- **IPv6 Security**: Configure IPv6-specific parameters

### Firewall Configuration (3.4.x) - 28 scripts
Multiple firewall implementations with comprehensive rules:
- **Firewalld**: Modern firewall management with zones
- **nftables**: Next-generation packet filtering framework
- **iptables**: Traditional Linux firewall with IPv4/IPv6 support

## Key Features

✅ **Network Interface Management**: Control wireless, bluetooth, and other interfaces
✅ **Protocol Security**: Disable unnecessary network protocols
✅ **Kernel Parameter Tuning**: Secure network stack configuration
✅ **Firewall Implementation**: Multiple firewall solution support
✅ **IPv6 Readiness**: Comprehensive IPv6 security controls
✅ **Module Blacklisting**: Prevent loading of insecure kernel modules
✅ **Sysctl Integration**: Persistent kernel parameter configuration

## Usage Examples

### Automated Scripts
```bash
# Disable wireless interfaces
sudo ./3.1.2_wireless_interfaces_disabled_automated.sh

# Configure network parameters
sudo ./3.3.1_ip_forwarding_is_disabled_automated.sh

# Install and configure firewall
sudo ./3.4.2.1_firewalld_is_installed_automated.sh
```

### Manual Scripts
```bash
# Review IPv6 configuration
sudo ./3.1.1_ipv6_status_is_identified_manual.sh

# Configure firewall rules
sudo ./3.4.2.3_firewalld_drops_unnecessary_services_and_ports_manual.sh
```

## Network Security Impact

⚠️ **Important Considerations**:
- Scripts modify kernel network parameters
- Firewall changes may affect network connectivity
- Wireless and bluetooth disabling impacts device functionality
- IPv6 changes require careful planning
- Test all changes in non-production environment first

## Script Categories Detail

### Network Configuration Controls
- 3.1.1_ipv6_status_is_identified_manual.sh
- 3.1.2_wireless_interfaces_disabled_automated.sh
- 3.1.3_bluetooth_services_automated.sh

### Protocol Security Controls  
- 3.2.1_dccp_kernel_module_not_available_automated.sh
- 3.2.2_tipc_kernel_module_not_available_automated.sh
- 3.2.3_rds_kernel_module_not_available_automated.sh
- 3.2.4_sctp_kernel_module_not_available_automated.sh

### Network Parameter Controls
- 3.3.10_tcp_syn_cookies_is_enabled_automated.sh
- 3.3.11_ipv6_router_advertisements_not_accepted_automated.sh
- 3.3.1_ip_forwarding_is_disabled_automated.sh
- 3.3.2_packet_redirect_sending_is_disabled_automated.sh
- 3.3.3_bogus_icmp_responses_ignored_automated.sh
- 3.3.4_broadcast_icmp_requests_ignored_automated.sh
- 3.3.5_icmp_redirects_not_accepted_automated.sh
- 3.3.6_secure_icmp_redirects_not_accepted_automated.sh
- 3.3.7_reverse_path_filtering_is_enabled_automated.sh
- 3.3.8_source_routed_packets_not_accepted_automated.sh
- 3.3.9_suspicious_packets_logged_automated.sh

### Firewall Configuration Controls
- 3.4.1.1_iptables_is_installed_automated.sh
- 3.4.1.2_a_single_firewall_configuration_utility_is_in_use_automated.sh
- 3.4.2.1_firewalld_is_installed_automated.sh
- 3.4.2.2_firewalld_service_enabled_and_running_automated.sh
- 3.4.2.3_firewalld_drops_unnecessary_services_and_ports_manual.sh
- 3.4.2.4_network_interfaces_assigned_to_appropriate_zone_manual.sh
- 3.4.3.1_nftables_is_installed_automated.sh
- 3.4.3.2_iptables_flushed_with_nftables_manual.sh
- 3.4.3.3_an_nftables_table_exists_automated.sh
- 3.4.3.4_nftables_base_chains_exist_automated.sh
- 3.4.3.5_nftables_loopback_traffic_automated.sh
- 3.4.3.6_nftables_outbound_and_established_connections_manual.sh
- 3.4.3.7_nftables_default_deny_firewall_policy_automated.sh
- 3.4.3.8_nftables_service_is_enabled_and_active_automated.sh
- 3.4.3.9_nftables_rules_permanent_automated.sh
- 3.4.4.1.1_iptables_packages_installed_automated.sh
- 3.4.4.2.1_iptables_loopback_traffic_automated.sh
- 3.4.4.2.2_iptables_outbound_and_established_connections_manual.sh
- 3.4.4.2.3_iptables_rules_exist_for_all_open_ports_automated.sh
- 3.4.4.2.4_iptables_default_deny_firewall_policy_automated.sh
- 3.4.4.2.5_iptables_rules_saved_automated.sh
- 3.4.4.2.6_iptables_service_is_enabled_and_active_automated.sh
- 3.4.4.3.1_ip6tables_loopback_traffic_automated.sh
- 3.4.4.3.2_ip6tables_outbound_and_established_connections_manual.sh
- 3.4.4.3.3_ip6tables_firewall_rules_exist_for_all_open_ports_automated.sh
- 3.4.4.3.4_ip6tables_default_deny_firewall_policy_automated.sh
- 3.4.4.3.5_ip6tables_rules_saved_automated.sh
- 3.4.4.3.6_ip6tables_is_enabled_and_active_automated.sh

## Sysctl Parameters Configured

The Section 3 scripts configure these critical network security parameters:
- `net.ipv4.ip_forward = 0` - Disable IP forwarding
- `net.ipv4.conf.all.send_redirects = 0` - Disable ICMP redirects
- `net.ipv4.conf.all.accept_source_route = 0` - Disable source routing
- `net.ipv4.conf.all.accept_redirects = 0` - Disable redirect acceptance
- `net.ipv4.conf.all.log_martians = 1` - Log suspicious packets
- `net.ipv4.tcp_syncookies = 1` - Enable SYN flood protection
- `net.ipv6.conf.all.accept_ra = 0` - Disable IPv6 router advertisements

---
*Section 3 scripts generated from CIS Oracle Linux 7 Benchmark*
*Generation completed: 2025-10-16 02:44:19*
