# Generate all Section 3 scripts
scripts_generated_section3 = []
failed_scripts_section3 = []

for index, row in df_section3.iterrows():
    try:
        # Generate base script
        script_content = generate_script_template_section3(row.to_dict())
        
        # Get specific remediation logic
        specific_logic = get_specific_remediation_logic_section3(row.to_dict())
        
        # Insert the specific logic into the template
        if 'automated' in row['script_name'].lower():
            # Replace the TODO comment in automated scripts
            script_content = script_content.replace(
                '    # TODO: Add specific remediation logic here based on the CIS control\n    # This will be customized for each specific script',
                specific_logic
            )
        else:
            # Replace the TODO comment in manual scripts
            script_content = script_content.replace(
                '    # TODO: Add specific manual remediation logic here\n    # This will be customized for each specific script',
                specific_logic
            )
            
            # Also update the show commands section for manual scripts
            show_commands_logic = specific_logic.replace('log_message', 'echo "# Command:"').replace('if ', 'echo "if ')
            script_content = script_content.replace(
                '    # TODO: Add specific command display logic here\n    # This will show the exact commands without executing them',
                f'    echo "The following remediation would be performed:"\\n{show_commands_logic}'
            )
        
        # Write script to file
        script_filename = f"{section3_dir}/{row['script_name']}.sh"
        with open(script_filename, 'w') as f:
            f.write(script_content)
            
        # Make script executable
        os.chmod(script_filename, 0o755)
        
        scripts_generated_section3.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'filename': script_filename,
            'type': 'automated' if 'automated' in row['script_name'].lower() else 'manual'
        })
        
        print(f"Generated: {os.path.basename(script_filename)}")
        
    except Exception as e:
        failed_scripts_section3.append({
            'id': row['id'],
            'script_name': row['script_name'],
            'error': str(e)
        })
        print(f"Failed to generate {row['id']}: {str(e)}")

print(f"\nSection 3 Generation Results:")
print(f"Successfully generated: {len(scripts_generated_section3)} scripts")
print(f"Failed to generate: {len(failed_scripts_section3)} scripts")

if failed_scripts_section3:
    print("\nFailed scripts:")
    for fail in failed_scripts_section3:
        print(f"  - {fail['id']}: {fail['error']}")

# Get final counts for verification
all_section3_scripts = glob.glob(f'{section3_dir}/*.sh')
print(f"Total Section 3 scripts in directory: {len(all_section3_scripts)}")

# Count by type
automated_scripts_section3 = [f for f in all_section3_scripts if 'automated' in f]
manual_scripts_section3 = [f for f in all_section3_scripts if 'manual' in f]

print(f"Automated scripts: {len(automated_scripts_section3)}")
print(f"Manual scripts: {len(manual_scripts_section3)}")

# Show sample of generated scripts
print(f"\nSample of generated Section 3 scripts:")
for script in sorted(all_section3_scripts)[:10]:
    basename = os.path.basename(script)
    script_type = "AUTO" if 'automated' in basename else "MANUAL"
    print(f"[{script_type}] {basename}")

if len(all_section3_scripts) > 10:
    print(f"... and {len(all_section3_scripts) - 10} more scripts")

print(f"\n✅ Section 3 script generation completed!")
print(f"All {len(all_section3_scripts)} scripts follow the template structure with network security controls.")