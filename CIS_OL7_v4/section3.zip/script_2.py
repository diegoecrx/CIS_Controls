# Create specific remediation logic for Section 3 CIS controls
def get_specific_remediation_logic_section3(row_data):
    """Generate specific remediation logic based on Section 3 CIS control type"""
    
    script_id = row_data['id']
    script_name = row_data['script_name']
    description = str(row_data['description']) if pd.notna(row_data['description']) else "No description available"
    remediation = str(row_data['remediation']) if pd.notna(row_data['remediation']) else ""
    default_value = str(row_data['default_value']) if pd.notna(row_data['default_value']) else ""
    
    # Network Configuration (3.1.x)
    if script_id == '3.1.1':
        return '''
    # CIS 3.1.1: Ensure IPv6 status is identified
    log_message "INFO" "Identifying IPv6 status on the system"
    
    echo "Current IPv6 Status:"
    echo "==================="
    
    # Check if IPv6 is enabled in kernel
    if [ -f /proc/sys/net/ipv6/conf/all/disable_ipv6 ]; then
        ipv6_disabled=$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6)
        if [ "$ipv6_disabled" = "1" ]; then
            echo "IPv6 is DISABLED in kernel"
        else
            echo "IPv6 is ENABLED in kernel"
        fi
    fi
    
    # Check IPv6 interfaces
    echo "IPv6 Interfaces:"
    ip -6 addr show 2>/dev/null || echo "No IPv6 interfaces found"
    
    # Check IPv6 in GRUB
    echo "GRUB IPv6 Configuration:"
    if grep -q "ipv6.disable=1" /proc/cmdline 2>/dev/null; then
        echo "IPv6 is disabled via GRUB boot parameter"
    else
        echo "IPv6 is not disabled via GRUB"
    fi
    
    log_message "INFO" "IPv6 status identification completed - review output above"
    echo "Please review the IPv6 status and configure according to organizational policy"
    
    return 0  # Always successful for identification'''
    
    elif script_id == '3.1.2':
        return '''
    # CIS 3.1.2: Ensure wireless interfaces are disabled
    log_message "INFO" "Disabling wireless interfaces"
    
    # Find wireless interfaces
    wireless_interfaces=$(find /sys/class/net/*/wireless -type d 2>/dev/null | cut -d'/' -f5 | sort -u)
    
    if [ -z "$wireless_interfaces" ]; then
        log_message "INFO" "No wireless interfaces found"
        return 0
    fi
    
    # Disable each wireless interface
    for interface in $wireless_interfaces; do
        log_message "INFO" "Processing wireless interface: $interface"
        
        # Bring interface down
        if manage_network_interface "disable" "$interface"; then
            log_message "SUCCESS" "Disabled wireless interface: $interface"
        fi
        
        # Find and blacklist the driver module
        driver_path="/sys/class/net/$interface/device/driver/module"
        if [ -L "$driver_path" ]; then
            module_name=$(basename $(readlink -f "$driver_path"))
            if blacklist_module "$module_name"; then
                log_message "SUCCESS" "Blacklisted wireless module: $module_name"
            fi
        fi
    done
    
    log_message "SUCCESS" "Wireless interface remediation completed"'''
    
    elif script_id == '3.1.3':
        return '''
    # CIS 3.1.3: Ensure bluetooth services are not in use
    log_message "INFO" "Disabling bluetooth services"
    
    # Stop bluetooth service
    if manage_service "stop" "bluetooth.service"; then
        log_message "SUCCESS" "Stopped bluetooth service"
    fi
    
    # Disable bluetooth service
    if manage_service "disable" "bluetooth.service"; then
        log_message "SUCCESS" "Disabled bluetooth service"
    fi
    
    # Mask bluetooth service
    if manage_service "mask" "bluetooth.service"; then
        log_message "SUCCESS" "Masked bluetooth service"
    fi
    
    # Optional: Remove bluez package (commented to avoid dependency issues)
    # if manage_package "remove" "bluez"; then
    #     log_message "SUCCESS" "Removed bluez package"
    # fi
    
    log_message "SUCCESS" "Bluetooth services have been disabled"'''
    
    # Uncommon Network Protocols (3.2.x)
    elif script_id.startswith('3.2.'):
        protocol_mappings = {
            '3.2.1': 'dccp',
            '3.2.2': 'tipc', 
            '3.2.3': 'rds',
            '3.2.4': 'sctp'
        }
        
        if script_id in protocol_mappings:
            protocol = protocol_mappings[script_id]
            return f'''
    # CIS {script_id}: Ensure {protocol} kernel module is not available
    log_message "INFO" "Disabling {protocol} kernel module"
    
    if blacklist_module "{protocol}"; then
        log_message "SUCCESS" "Successfully blacklisted {protocol} module"
    else
        log_message "ERROR" "Failed to blacklist {protocol} module"
        return 1
    fi'''
    
    # Network Parameters (3.3.x)
    elif script_id.startswith('3.3.'):
        network_params = {
            '3.3.1': ('net.ipv4.ip_forward', '0'),
            '3.3.2': ('net.ipv6.conf.all.forwarding', '0'),
            '3.3.3': ('net.ipv4.conf.all.send_redirects', '0'),
            '3.3.4': ('net.ipv4.conf.default.send_redirects', '0'),
            '3.3.5': ('net.ipv4.conf.all.accept_source_route', '0'),
            '3.3.6': ('net.ipv4.conf.default.accept_source_route', '0'),
            '3.3.7': ('net.ipv6.conf.all.accept_source_route', '0'),
            '3.3.8': ('net.ipv6.conf.default.accept_source_route', '0'),
            '3.3.9': ('net.ipv4.conf.all.accept_redirects', '0'),
            '3.3.10': ('net.ipv4.conf.default.accept_redirects', '0'),
            '3.3.11': ('net.ipv6.conf.all.accept_redirects', '0'),
            '3.3.12': ('net.ipv6.conf.default.accept_redirects', '0'),
            '3.3.13': ('net.ipv4.conf.all.secure_redirects', '0'),
            '3.3.14': ('net.ipv4.conf.default.secure_redirects', '0'),
            '3.3.15': ('net.ipv4.conf.all.log_martians', '1'),
            '3.3.16': ('net.ipv4.conf.default.log_martians', '1'),
            '3.3.17': ('net.ipv4.icmp_echo_ignore_broadcasts', '1'),
            '3.3.18': ('net.ipv4.icmp_ignore_bogus_error_responses', '1'),
            '3.3.19': ('net.ipv4.conf.all.rp_filter', '1'),
            '3.3.20': ('net.ipv4.conf.default.rp_filter', '1'),
            '3.3.21': ('net.ipv4.tcp_syncookies', '1'),
            '3.3.22': ('net.ipv6.conf.all.accept_ra', '0'),
            '3.3.23': ('net.ipv6.conf.default.accept_ra', '0')
        }
        
        if script_id in network_params:
            param_name, param_value = network_params[script_id]
            return f'''
    # CIS {script_id}: Configure network parameter {param_name}
    config_file="/etc/sysctl.conf"
    
    log_message "INFO" "Configuring {param_name} = {param_value}"
    
    if configure_sysctl "{param_name}" "{param_value}"; then
        log_message "SUCCESS" "Successfully configured {param_name}"
        
        # Verify the setting
        current_value=$(sysctl -n {param_name} 2>/dev/null)
        if [ "$current_value" = "{param_value}" ]; then
            log_message "SUCCESS" "Verified {param_name} = {param_value}"
        else
            log_message "WARNING" "Current value differs: {param_name} = $current_value"
        fi
    else
        log_message "ERROR" "Failed to configure {param_name}"
        return 1
    fi'''
    
    # Firewall Configuration (3.4.x and 3.5.x)
    elif script_id.startswith('3.4.') or script_id.startswith('3.5.'):
        firewall_configs = {
            '3.4.1': 'firewalld_installed',
            '3.4.2': 'firewalld_service',
            '3.4.3': 'firewalld_default_zone',
            '3.4.4': 'firewalld_network_interfaces',
            '3.4.5': 'firewalld_unnecessary_services',
            '3.4.6': 'firewalld_unnecessary_ports',
            '3.5.1': 'iptables_installed',
            '3.5.2': 'iptables_default_deny',
            '3.5.3': 'iptables_loopback_configured'
        }
        
        if script_id == '3.4.1':
            return '''
    # CIS 3.4.1: Ensure firewalld is installed
    log_message "INFO" "Installing firewalld package"
    
    if manage_package "install" "firewalld"; then
        log_message "SUCCESS" "Firewalld package installed"
    else
        log_message "ERROR" "Failed to install firewalld package"
        return 1
    fi'''
        
        elif script_id == '3.4.2':
            return '''
    # CIS 3.4.2: Ensure firewalld service is enabled and active
    log_message "INFO" "Enabling and starting firewalld service"
    
    if manage_service "enable" "firewalld"; then
        if manage_service "start" "firewalld"; then
            log_message "SUCCESS" "Firewalld service enabled and started"
        else
            log_message "ERROR" "Failed to start firewalld service"
            return 1
        fi
    else
        log_message "ERROR" "Failed to enable firewalld service"
        return 1
    fi'''
        
        elif script_id == '3.5.1':
            return '''
    # CIS 3.5.1: Ensure iptables is installed
    log_message "INFO" "Installing iptables package"
    
    if manage_package "install" "iptables"; then
        if manage_package "install" "iptables-services"; then
            log_message "SUCCESS" "Iptables packages installed"
        fi
    else
        log_message "ERROR" "Failed to install iptables packages"
        return 1
    fi'''
        
        else:
            return f'''
    # CIS {script_id}: Firewall configuration
    log_message "INFO" "Configuring firewall settings for {script_id}"
    log_message "WARNING" "Manual firewall configuration required"
    log_message "INFO" "Please configure according to organizational security policy"
    
    # Firewall configuration is highly environment-specific
    # Please customize according to your organization's requirements
    
    return 2  # Manual intervention required'''
    
    # Default case for unknown controls
    else:
        return f'''
    # CIS {script_id}: Section 3 network remediation
    config_file=""
    
    log_message "INFO" "Applying remediation for: {script_id}"
    log_message "INFO" "Remediation steps: {remediation[:200] if remediation else 'See CIS benchmark documentation'}"
    
    # TODO: Implement specific remediation logic for this CIS control
    # Description: {description}
    
    log_message "WARNING" "Specific remediation logic needs to be implemented for this control"
    return 2  # Manual intervention may be required'''

# Test specific logic generation
test_logic = get_specific_remediation_logic_section3(df_section3.iloc[1].to_dict())
print("Sample specific remediation logic for wireless interfaces:")
print(test_logic)