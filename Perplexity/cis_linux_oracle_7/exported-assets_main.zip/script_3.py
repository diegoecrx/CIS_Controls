
# Create a sample cis_sections.txt with example entries and create a quick reference card
sample_sections = """# CIS Oracle Linux 7 Benchmark - Script Execution List
# Format: One script name per line
# Comments start with #
# Empty lines are ignored

# Section 1.1 - Filesystem Configuration
1.1.2_tmp.sh
1.1.3_noexec_tmp_partition.sh
1.1.4_nodev_tmp_partition.sh
1.1.5_nosuid_tmp_partition.sh
1.1.6_devshm.sh
1.1.7_noexec_devshm_partition.sh
1.1.8_nodev_devshm_partition.sh
1.1.9_nosuid_devshm_partition.sh

# Section 5.3 - SSH Configuration
5.3.10_ssh_root_login_disabled.sh
5.3.11_ssh_permitemptypasswords_disabled.sh
5.3.12_ssh_permituserenvironment_disabled.sh

# Add more scripts as needed...
"""

# Write sample file
with open('cis_sections_example.txt', 'w') as f:
    f.write(sample_sections)

# Create quick reference card
quick_ref = """╔═══════════════════════════════════════════════════════════════════════════════╗
║                    CIS_MAIN.SH - QUICK REFERENCE CARD                         ║
╚═══════════════════════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────────────────────────┐
│ BASIC USAGE                                                                   │
└─────────────────────────────────────────────────────────────────────────────┘

  Execute Script:           sudo ./cis_main.sh
  Unattended Mode:          echo "yes" | sudo ./cis_main.sh
  Check Status:             tail -f cis_events.log

┌─────────────────────────────────────────────────────────────────────────────┐
│ LOG FORMAT                                                                    │
└─────────────────────────────────────────────────────────────────────────────┘

  Format:  DD/MM/YYYY HH:MM script_name cis_main.sh result
  
  Example:
    12/10/2025 21:30 1.1.2_tmp.sh cis_main.sh success
    12/10/2025 21:30 1.1.3_noexec_tmp_partition.sh cis_main.sh pending
    12/10/2025 21:31 1.1.4_nodev_tmp_partition.sh cis_main.sh failed

┌─────────────────────────────────────────────────────────────────────────────┐
│ RESULT TYPES                                                                  │
└─────────────────────────────────────────────────────────────────────────────┘

  success  ✓  Remediation applied successfully          (exit code: 0)
  pending  ⚠  Manual action required                    (exit code: 2)
  failed   ✗  Remediation failed or error occurred      (exit code: 1)

┌─────────────────────────────────────────────────────────────────────────────┐
│ FILE STRUCTURE                                                                │
└─────────────────────────────────────────────────────────────────────────────┘

  Required Files:
    • cis_main.sh              - Main execution script
    • cis_sections.txt         - List of scripts to execute
    • [remediation scripts]    - Individual CIS scripts
  
  Generated Files:
    • cis_events.log           - Execution results log

┌─────────────────────────────────────────────────────────────────────────────┐
│ MONITORING COMMANDS                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

  Live monitoring:          tail -f cis_events.log
  Count completed:          grep -c "cis_main.sh" cis_events.log
  Count successes:          grep -c "success" cis_events.log
  Count pending:            grep -c "pending" cis_events.log  
  Count failures:           grep -c "failed" cis_events.log
  View summary:             tail -1 cis_events.log | grep SUMMARY

┌─────────────────────────────────────────────────────────────────────────────┐
│ EXECUTION OUTPUT                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

  [001/246] Executing: 1.1.2_tmp.sh                          [SUCCESS]
  [002/246] Executing: 1.1.3_noexec_tmp_partition.sh         [PENDING]
  [003/246] Executing: 1.1.4_nodev_tmp_partition.sh          [FAILED]

  Colors:
    GREEN   - Success
    YELLOW  - Pending
    RED     - Failed
    BLUE    - Info

┌─────────────────────────────────────────────────────────────────────────────┐
│ PREREQUISITES                                                                 │
└─────────────────────────────────────────────────────────────────────────────┘

  ✓ Run as root (sudo)
  ✓ cis_sections.txt exists in same directory
  ✓ All referenced scripts exist and are accessible
  ✓ Write permission for cis_events.log

┌─────────────────────────────────────────────────────────────────────────────┐
│ CUSTOMIZATION                                                                 │
└─────────────────────────────────────────────────────────────────────────────┘

  Edit cis_sections.txt:    Add/remove scripts to execute
  Skip confirmation:        Comment out lines 181-186 in cis_main.sh
  Change delay:             Modify sleep value at line 260
  Disable colors:           Remove color codes from script

┌─────────────────────────────────────────────────────────────────────────────┐
│ TROUBLESHOOTING                                                               │
└─────────────────────────────────────────────────────────────────────────────┘

  Permission denied:        chmod +x cis_main.sh && sudo ./cis_main.sh
  Script not found:         Verify script paths in cis_sections.txt
  Cannot write log:         Check permissions on cis_events.log
  Missing sections file:    Create cis_sections.txt with script names

┌─────────────────────────────────────────────────────────────────────────────┐
│ EXIT CODES                                                                    │
└─────────────────────────────────────────────────────────────────────────────┘

  0  - All scripts executed successfully (no failures)
  1  - One or more scripts failed

┌─────────────────────────────────────────────────────────────────────────────┐
│ SUMMARY REPORT                                                                │
└─────────────────────────────────────────────────────────────────────────────┘

  ═══════════════════════════════════════════════════════════
    Execution Summary
  ═══════════════════════════════════════════════════════════
    Total Scripts:   246
    Success:         200
    Pending:         30
    Failed:          16
    Skipped:         0
  ───────────────────────────────────────────────────────────
    Success Rate:    81%
  ═══════════════════════════════════════════════════════════

╔═══════════════════════════════════════════════════════════════════════════════╗
║ For detailed documentation, see: CIS_MAIN_USAGE_GUIDE.md                     ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

# Write quick reference
with open('CIS_MAIN_QUICK_REFERENCE.txt', 'w') as f:
    f.write(quick_ref)

print("✓ Created cis_sections_example.txt")
print("✓ Created CIS_MAIN_QUICK_REFERENCE.txt")
print("\nAll files created successfully!")
print("\n" + "=" * 60)
print("FILES CREATED:")
print("=" * 60)
print("1. cis_main.sh                    - Main execution script")
print("2. cis_sections.txt               - Full list of 246 scripts")
print("3. cis_sections_example.txt       - Example sections file")
print("4. CIS_MAIN_USAGE_GUIDE.md        - Detailed usage guide")
print("5. CIS_MAIN_QUICK_REFERENCE.txt   - Quick reference card")
print("=" * 60)
