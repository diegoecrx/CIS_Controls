# CIS Main Execution Script - Usage Guide

## Overview
The `cis_main.sh` script executes all CIS remediation scripts listed in `cis_sections.txt` and logs results to `cis_events.log`.

## Files Required

### 1. cis_main.sh
Main execution script that orchestrates all remediations.

### 2. cis_sections.txt
Text file containing one script name per line:
```
1.1.2_tmp.sh
1.1.3_noexec_tmp_partition.sh
1.1.4_nodev_tmp_partition.sh
...
```

### 3. Individual remediation scripts
All scripts referenced in cis_sections.txt must be in the same directory.

## Usage

### Basic Execution
```bash
# Make script executable
chmod +x cis_main.sh

# Execute as root
sudo ./cis_main.sh
```

### Unattended Execution
To skip the confirmation prompt, comment out lines 181-186 in cis_main.sh or use:
```bash
echo "yes" | sudo ./cis_main.sh
```

## Log Format

### cis_events.log Structure
```
# CIS Remediation Execution - 12/10/2025 21:30:00
12/10/2025 21:30 START cis_main.sh execution_started
12/10/2025 21:30 1.1.2_tmp.sh cis_main.sh success
12/10/2025 21:30 1.1.3_noexec_tmp_partition.sh cis_main.sh pending
12/10/2025 21:31 1.1.4_nodev_tmp_partition.sh cis_main.sh failed
12/10/2025 21:45 END cis_main.sh execution_completed
12/10/2025 21:45 SUMMARY cis_main.sh total:246 success:200 pending:30 failed:16
```

### Log Fields
1. **Date/Time**: DD/MM/YYYY HH:MM
2. **Script Name**: Name of executed script
3. **Executor**: cis_main.sh (or the script name if from individual script)
4. **Result**: success, pending, failed, or status info

## Result Types

### success
Script executed successfully, remediation applied.
- Exit code: 0
- Display: GREEN [SUCCESS]

### pending
Script executed but remediation is pending (manual action required).
- Exit code: 2
- Display: YELLOW [PENDING]

### failed
Script failed to execute or remediation failed.
- Exit code: 1 or any non-zero except 2
- Display: RED [FAILED]

## Output Display

### During Execution
```
================================================================================
  CIS Oracle Linux 7 Benchmark - Main Remediation Executor
================================================================================
  Script:        cis_main.sh
  Sections File: cis_sections.txt
  Log File:      cis_events.log
  Start Time:    12/10/2025 21:30:00
================================================================================

[OK] Prerequisites validated

[INFO] Found 246 scripts to execute

Execute all 246 scripts? (yes/no): yes

[001/246] Executing: 1.1.2_tmp.sh                                    [SUCCESS]
[002/246] Executing: 1.1.3_noexec_tmp_partition.sh                  [PENDING]
[003/246] Executing: 1.1.4_nodev_tmp_partition.sh                   [SUCCESS]
...
```

### Summary Report
```
================================================================================
  Execution Summary
================================================================================
  Total Scripts:   246
  Success:         200
  Pending:         30
  Failed:          16
  Skipped:         0
-------------------------------------------------------------------------------
  Success Rate:    81%
================================================================================
  Log File:        cis_events.log
  End Time:        12/10/2025 21:45:30
================================================================================
```

## Exit Codes

- **0**: All scripts succeeded
- **1**: One or more scripts failed

## Error Handling

### Script Not Found
```
[003/246] Executing: missing_script.sh                       [FAILED - NOT FOUND]
```
Result logged as: `failed`

### Script Not Executable
```
[004/246] Executing: readonly_script.sh                  [FAILED - NOT EXECUTABLE]
```
The script attempts to make it executable first. If that fails, result logged as: `failed`

### Script Execution Error
```
[005/246] Executing: error_script.sh                     [FAILED - EXIT CODE: 127]
```
Result logged as: `failed`

## Monitoring Execution

### Real-time Log Monitoring
In another terminal:
```bash
tail -f cis_events.log
```

### Check Progress
```bash
# Count completed scripts
grep -c "cis_main.sh" cis_events.log

# Count results by type
grep "success" cis_events.log | wc -l
grep "pending" cis_events.log | wc -l
grep "failed" cis_events.log | wc -l
```

### Generate Report
```bash
# Summary from log
tail -1 cis_events.log | grep SUMMARY
```

## Customization

### Modify cis_sections.txt
To execute only specific scripts, edit cis_sections.txt:
```
# Filesystem controls only
1.1.2_tmp.sh
1.1.3_noexec_tmp_partition.sh
1.1.4_nodev_tmp_partition.sh

# SSH hardening
5.3.10_ssh_root_login_disabled.sh
5.3.11_ssh_permitemptypasswords_disabled.sh
```

### Skip Confirmation
Edit line 181-186 in cis_main.sh:
```bash
# Comment out this block for unattended execution
# read -p "Execute all $TOTAL_SCRIPTS scripts? (yes/no): " confirm
# if [[ "$confirm" != "yes" ]]; then
#     echo "${YELLOW}[CANCELLED]${NC} Execution cancelled by user"
#     exit 0
# fi
```

### Change Delay Between Scripts
Edit line 260 in cis_main.sh:
```bash
# Current: 0.5 seconds
sleep 0.5

# Change to 2 seconds
sleep 2
```

## Troubleshooting

### Permission Denied
```bash
# Ensure script is executable
chmod +x cis_main.sh

# Run as root
sudo ./cis_main.sh
```

### Log File Issues
```bash
# Check log file permissions
ls -l cis_events.log

# Create log file manually if needed
touch cis_events.log
chmod 644 cis_events.log
```

### Missing Sections File
```bash
# Create cis_sections.txt
ls -1 *.sh | grep -v "cis_main.sh" > cis_sections.txt
```

## Best Practices

1. **Backup First**: Create system backup before execution
2. **Test Environment**: Run in test environment first
3. **Review Logs**: Always review cis_events.log after execution
4. **Staged Execution**: Execute sections separately by modifying cis_sections.txt
5. **Monitor Resources**: Watch system resources during execution
6. **Review Pending**: Investigate all "pending" results for manual actions needed
7. **Handle Failures**: Review and fix "failed" results, then re-run

## Integration Examples

### Cron Job (Scheduled Execution)
```bash
# Run daily at 2 AM
0 2 * * * /path/to/cis_main.sh >> /var/log/cis_execution.log 2>&1
```

### Ansible Integration
```yaml
- name: Execute CIS Remediation
  command: /path/to/cis_main.sh
  args:
    chdir: /path/to/scripts
  become: yes
  register: cis_result
```

### Bash Wrapper
```bash
#!/bin/bash
# wrapper_cis.sh

# Pre-execution tasks
echo "Starting CIS remediation..."
systemctl snapshot cis-pre-remediation

# Execute
cd /path/to/cis/scripts
./cis_main.sh

# Post-execution tasks
if [ $? -eq 0 ]; then
    echo "CIS remediation completed successfully"
    # Send notification
    mail -s "CIS Remediation Success" admin@example.com < cis_events.log
else
    echo "CIS remediation completed with errors"
    # Send alert
    mail -s "CIS Remediation FAILED" admin@example.com < cis_events.log
fi
```

## Support

For issues or questions, review:
1. cis_events.log - Execution log
2. Individual script logs - Script-specific details
3. System logs - /var/log/messages, /var/log/secure
