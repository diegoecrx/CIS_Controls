
# First, let's check if there's a cis_sections.txt file uploaded, if not we'll create a sample one
import os

# Check for existing file
if not os.path.exists('cis_sections.txt'):
    print("cis_sections.txt not found. Creating sample file from Excel data...")
    
    # Read the Excel file to get all script names
    import pandas as pd
    df = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v3.1.1.xlsx')
    
    # Create cis_sections.txt with all script names
    with open('cis_sections.txt', 'w') as f:
        for script_name in df['script_name']:
            f.write(f"{script_name}\n")
    
    print(f"✓ Created cis_sections.txt with {len(df)} script names")
else:
    print("✓ cis_sections.txt found")

# Read the file to show preview
with open('cis_sections.txt', 'r') as f:
    lines = f.readlines()
    print(f"\nTotal scripts in cis_sections.txt: {len(lines)}")
    print("\nFirst 10 entries:")
    for line in lines[:10]:
        print(f"  {line.strip()}")
