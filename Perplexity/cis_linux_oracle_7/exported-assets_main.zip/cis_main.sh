#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark - Main Execution Script
# Script: cis_main.sh
# Purpose: Execute all CIS remediation scripts listed in cis_sections.txt
# Logs results to: cis_events.log
# Result types: success, pending, failed
################################################################################

# Script configuration
SCRIPT_NAME="cis_main.sh"
SECTIONS_FILE="cis_sections.txt"
LOG_FILE="cis_events.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Result counters
TOTAL_SCRIPTS=0
SUCCESS_COUNT=0
PENDING_COUNT=0
FAILED_COUNT=0
SKIPPED_COUNT=0

# Colors for output (optional)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

################################################################################
# Logging function - matches the format from individual scripts
################################################################################
log_event() {
    local script="$1"
    local result="$2"
    local timestamp=$(date +"%d/%m/%Y %H:%M")

    # Log format: DD/MM/YYYY HH:MM script_name cis_main.sh result
    echo "$timestamp $script $SCRIPT_NAME $result" >> "$LOG_FILE"
}

################################################################################
# Display banner
################################################################################
show_banner() {
    echo "================================================================================"
    echo "  CIS Oracle Linux 7 Benchmark - Main Remediation Executor"
    echo "================================================================================"
    echo "  Script:        $SCRIPT_NAME"
    echo "  Sections File: $SECTIONS_FILE"
    echo "  Log File:      $LOG_FILE"
    echo "  Start Time:    $(date +"%d/%m/%Y %H:%M:%S")"
    echo "================================================================================"
    echo
}

################################################################################
# Validate prerequisites
################################################################################
validate_prerequisites() {
    local errors=0

    # Check if running as root
    if [ "$EUID" -ne 0 ]; then
        echo "${RED}[ERROR]${NC} This script must be run as root"
        errors=$((errors + 1))
    fi

    # Check if sections file exists
    if [ ! -f "$SECTIONS_FILE" ]; then
        echo "${RED}[ERROR]${NC} Sections file not found: $SECTIONS_FILE"
        errors=$((errors + 1))
    fi

    # Check if log file is writable
    touch "$LOG_FILE" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "${RED}[ERROR]${NC} Cannot write to log file: $LOG_FILE"
        errors=$((errors + 1))
    fi

    if [ $errors -gt 0 ]; then
        echo "${RED}[FATAL]${NC} Prerequisites check failed. Exiting."
        exit 1
    fi

    echo "${GREEN}[OK]${NC} Prerequisites validated"
    echo
}

################################################################################
# Count total scripts
################################################################################
count_scripts() {
    TOTAL_SCRIPTS=$(grep -c "^[^#]" "$SECTIONS_FILE" 2>/dev/null || echo 0)
    echo "${BLUE}[INFO]${NC} Found $TOTAL_SCRIPTS scripts to execute"
    echo
}

################################################################################
# Execute individual script
################################################################################
execute_script() {
    local script_name="$1"
    local script_num="$2"
    local result="pending"

    # Remove any leading/trailing whitespace
    script_name=$(echo "$script_name" | xargs)

    # Skip empty lines and comments
    if [ -z "$script_name" ] || [[ "$script_name" =~ ^# ]]; then
        return
    fi

    # Full path to script
    local script_path="$SCRIPT_DIR/$script_name"

    # Display progress
    printf "${BLUE}[%03d/%03d]${NC} Executing: %-60s " "$script_num" "$TOTAL_SCRIPTS" "$script_name"

    # Check if script exists
    if [ ! -f "$script_path" ]; then
        result="failed"
        echo "${RED}[FAILED - NOT FOUND]${NC}"
        log_event "$script_name" "$result"
        FAILED_COUNT=$((FAILED_COUNT + 1))
        SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
        return 1
    fi

    # Check if script is executable
    if [ ! -x "$script_path" ]; then
        # Try to make it executable
        chmod +x "$script_path" 2>/dev/null
        if [ $? -ne 0 ]; then
            result="failed"
            echo "${RED}[FAILED - NOT EXECUTABLE]${NC}"
            log_event "$script_name" "$result"
            FAILED_COUNT=$((FAILED_COUNT + 1))
            SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
            return 1
        fi
    fi

    # Execute the script and capture exit code
    "$script_path" > /dev/null 2>&1
    local exit_code=$?

    # Determine result based on exit code
    case $exit_code in
        0)
            result="success"
            echo "${GREEN}[SUCCESS]${NC}"
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
            ;;
        1)
            result="failed"
            echo "${RED}[FAILED]${NC}"
            FAILED_COUNT=$((FAILED_COUNT + 1))
            ;;
        2)
            result="pending"
            echo "${YELLOW}[PENDING]${NC}"
            PENDING_COUNT=$((PENDING_COUNT + 1))
            ;;
        *)
            result="failed"
            echo "${RED}[FAILED - EXIT CODE: $exit_code]${NC}"
            FAILED_COUNT=$((FAILED_COUNT + 1))
            ;;
    esac

    # Log the result
    log_event "$script_name" "$result"

    # Small delay to prevent system overload
    sleep 0.5

    return $exit_code
}

################################################################################
# Display summary
################################################################################
show_summary() {
    local end_time=$(date +"%d/%m/%Y %H:%M:%S")

    echo
    echo "================================================================================"
    echo "  Execution Summary"
    echo "================================================================================"
    echo "  Total Scripts:   $TOTAL_SCRIPTS"
    echo "  ${GREEN}Success:         $SUCCESS_COUNT${NC}"
    echo "  ${YELLOW}Pending:         $PENDING_COUNT${NC}"
    echo "  ${RED}Failed:          $FAILED_COUNT${NC}"
    echo "  Skipped:         $SKIPPED_COUNT"
    echo "-------------------------------------------------------------------------------"

    # Calculate success rate
    if [ $TOTAL_SCRIPTS -gt 0 ]; then
        local success_rate=$((SUCCESS_COUNT * 100 / TOTAL_SCRIPTS))
        echo "  Success Rate:    ${success_rate}%"
    fi

    echo "================================================================================"
    echo "  Log File:        $LOG_FILE"
    echo "  End Time:        $end_time"
    echo "================================================================================"
    echo

    # Log summary to events log
    log_event "SUMMARY" "total:$TOTAL_SCRIPTS success:$SUCCESS_COUNT pending:$PENDING_COUNT failed:$FAILED_COUNT"
}

################################################################################
# Main execution
################################################################################
main() {
    # Display banner
    show_banner

    # Validate prerequisites
    validate_prerequisites

    # Count scripts
    count_scripts

    # Confirmation prompt (optional - comment out for unattended execution)
    read -p "Execute all $TOTAL_SCRIPTS scripts? (yes/no): " confirm
    if [[ "$confirm" != "yes" ]]; then
        echo "${YELLOW}[CANCELLED]${NC} Execution cancelled by user"
        exit 0
    fi
    echo

    # Initialize log with execution header
    echo "# CIS Remediation Execution - $(date +"%d/%m/%Y %H:%M:%S")" >> "$LOG_FILE"
    log_event "START" "execution_started"

    # Execute each script from the sections file
    local script_num=0
    while IFS= read -r script_name || [ -n "$script_name" ]; do
        # Skip empty lines and comments
        [[ -z "$script_name" || "$script_name" =~ ^[[:space:]]*# ]] && continue

        script_num=$((script_num + 1))
        execute_script "$script_name" "$script_num"
    done < "$SECTIONS_FILE"

    # Log end of execution
    log_event "END" "execution_completed"

    # Display summary
    show_summary

    # Exit with appropriate code
    if [ $FAILED_COUNT -eq 0 ]; then
        exit 0
    else
        exit 1
    fi
}

################################################################################
# Execute main function
################################################################################
main "$@"
