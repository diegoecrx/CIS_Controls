#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: 1.1.3_noexec_tmp_partition.sh
# CIS ID: 1.1.3
# Description: CIS 1.1.3 remediation
# Generated: 2025-10-12 21:13:09
################################################################################

# Script variables
SCRIPT_NAME="1.1.3_noexec_tmp_partition.sh"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}

# Backup function
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
# Initialize result tracking
result="success"

# CIS Remediation: Configure /tmp with secure mount options
MOUNT_POINT="/tmp"
FSTAB="/etc/fstab"

log_message "INFO" "Configuring secure mount options for $MOUNT_POINT"

# Backup fstab before making changes
backup_file "$FSTAB"

# Check if mount point entry exists in fstab
if grep -q "\s$MOUNT_POINT\s" "$FSTAB"; then
    log_message "INFO" "$MOUNT_POINT entry found in fstab"

    # REMEDIATION ACTION: Add secure mount options (noexec, nodev, nosuid)
    # These options prevent execution of binaries, device files, and setuid programs
    if ! grep "\s$MOUNT_POINT\s" "$FSTAB" | grep -q "noexec\|nodev\|nosuid"; then
        # Update existing entry with secure options
        sed -i.bak "/$MOUNT_POINT/ s/defaults/defaults,nosuid,nodev,noexec/" "$FSTAB" && \
        log_message "SUCCESS" "Updated $MOUNT_POINT entry in fstab with secure options" || \
        { result="failed"; log_message "ERROR" "Failed to update fstab"; }
    else
        log_message "INFO" "$MOUNT_POINT already has secure mount options"
    fi
else
    log_message "INFO" "Adding $MOUNT_POINT entry to fstab"
    # REMEDIATION ACTION: Add new mount entry with secure options
    echo "tmpfs $MOUNT_POINT tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0" >> "$FSTAB" && \
    log_message "SUCCESS" "Added $MOUNT_POINT entry to fstab with secure options" || \
    { result="failed"; log_message "ERROR" "Failed to add fstab entry"; }
fi

# REMEDIATION ACTION: Remount with new secure options
echo "[INFO] Remounting $MOUNT_POINT with secure options"
if mountpoint -q "$MOUNT_POINT"; then
    mount -o remount,noexec,nodev,nosuid "$MOUNT_POINT" && \
    log_message "SUCCESS" "$MOUNT_POINT remounted with secure options" || \
    { result="failed"; log_message "ERROR" "Failed to remount $MOUNT_POINT"; }
else
    log_message "INFO" "$MOUNT_POINT is not currently mounted"
fi

# Verify mount options
echo "[INFO] Current $MOUNT_POINT mount options:"
mount | grep " $MOUNT_POINT " || log_message "WARNING" "$MOUNT_POINT not currently mounted"

# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "Remediation completed successfully"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
