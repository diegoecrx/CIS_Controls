# Create rollback script
rollback_script = """#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark - Rollback Script
# Restores original configurations from backup
# Generated: October 12, 2025
################################################################################

LOG_FILE="rollback_results.log"
RESTORED_FILES=0
FAILED_RESTORATIONS=0

# Logging function
log_rollback() {
    local level="$1"
    shift  
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [ROLLBACK] $message" | tee -a "$LOG_FILE"
}

echo "=============================================="
echo "CIS Remediation Rollback Script"
echo "=============================================="
echo "Start Time: $(date)"
echo "=============================================="

log_rollback "INFO" "Starting rollback process"

# Find available backup directories
backup_dirs=($(find /tmp -maxdepth 1 -type d -name "cis_backup_*" 2>/dev/null | sort -r))

if [ ${#backup_dirs[@]} -eq 0 ]; then
    echo "ERROR: No CIS backup directories found in /tmp/"
    log_rollback "ERROR" "No backup directories found"
    exit 1
fi

echo "Available backup directories:"
for i in "${!backup_dirs[@]}"; do
    backup_date=$(basename "${backup_dirs[$i]}" | sed 's/cis_backup_//')
    echo "  $((i+1)). ${backup_dirs[$i]} (Created: $backup_date)"
done

echo
read -p "Select backup directory to restore from (1-${#backup_dirs[@]}): " choice

if [[ ! "$choice" =~ ^[0-9]+$ ]] || [ "$choice" -lt 1 ] || [ "$choice" -gt ${#backup_dirs[@]} ]; then
    echo "ERROR: Invalid selection"
    exit 1
fi

selected_backup="${backup_dirs[$((choice-1))]}"
echo "Selected backup: $selected_backup"
log_rollback "INFO" "Selected backup directory: $selected_backup"

# Confirm rollback
echo
echo "WARNING: This will restore files from backup, potentially undoing CIS remediations."
read -p "Continue with rollback? (yes/no): " confirm
if [[ $confirm != "yes" ]]; then
    echo "Rollback cancelled by user."
    exit 0
fi

echo
echo "Starting rollback process..."

# Restore files from backup
cd "$selected_backup"

for backup_file in *.backup; do
    if [ -f "$backup_file" ]; then
        original_file="${backup_file%.backup}"
        
        # Determine original file path
        case "$original_file" in
            "sshd_config")
                target_path="/etc/ssh/sshd_config"
                ;;
            "sudoers")
                target_path="/etc/sudoers"
                ;;
            "auditd.conf")
                target_path="/etc/audit/auditd.conf"
                ;;
            "rsyslog.conf")
                target_path="/etc/rsyslog.conf"
                ;;
            "fstab")
                target_path="/etc/fstab"
                ;;
            "grub.cfg")
                target_path="/boot/grub2/grub.cfg"
                ;;
            *.conf)
                if [[ "$original_file" =~ (cramfs|squashfs|udf|dccp|sctp)\.conf ]]; then
                    target_path="/etc/modprobe.d/$original_file"
                else
                    target_path="/etc/$original_file"
                fi
                ;;
            *)
                # Try to find the original location
                target_path=$(find /etc -name "$original_file" -type f 2>/dev/null | head -1)
                if [ -z "$target_path" ]; then
                    log_rollback "WARNING" "Cannot determine original location for: $original_file"
                    continue
                fi
                ;;
        esac
        
        echo -n "Restoring $target_path... "
        
        if [ -f "$target_path" ]; then
            # Backup current file before rollback
            cp "$target_path" "$target_path.pre-rollback" 2>/dev/null || true
            
            # Restore from backup
            if cp "$backup_file" "$target_path" 2>/dev/null; then
                echo "SUCCESS"
                log_rollback "SUCCESS" "Restored: $target_path"
                RESTORED_FILES=$((RESTORED_FILES + 1))
            else
                echo "FAILED"
                log_rollback "ERROR" "Failed to restore: $target_path"
                FAILED_RESTORATIONS=$((FAILED_RESTORATIONS + 1))
            fi
        else
            echo "TARGET NOT FOUND"
            log_rollback "WARNING" "Target file not found: $target_path"
        fi
    fi
done

# Restart critical services after rollback
echo
echo "Restarting services..."

services_to_restart=("sshd" "auditd" "rsyslog" "firewalld")

for service in "${services_to_restart[@]}"; do
    if systemctl is-active "$service" >/dev/null 2>&1; then
        echo -n "Restarting $service... "
        if systemctl restart "$service" >/dev/null 2>&1; then
            echo "SUCCESS"
            log_rollback "SUCCESS" "Restarted service: $service"
        else
            echo "FAILED"
            log_rollback "ERROR" "Failed to restart service: $service"
        fi
    fi
done

# Remove disabled kernel modules configuration if needed
echo
echo "Cleaning up module configurations..."

module_configs=("/etc/modprobe.d/cramfs.conf" "/etc/modprobe.d/squashfs.conf" "/etc/modprobe.d/udf.conf" "/etc/modprobe.d/dccp.conf" "/etc/modprobe.d/sctp.conf")

for config in "${module_configs[@]}"; do
    if [ -f "$config" ] && grep -q "install .* /bin/true" "$config" 2>/dev/null; then
        echo -n "Removing $config... "
        if rm "$config" 2>/dev/null; then
            echo "SUCCESS"
            log_rollback "SUCCESS" "Removed: $config"
        else
            echo "FAILED"  
            log_rollback "ERROR" "Failed to remove: $config"
        fi
    fi
done

echo
echo "=============================================="
echo "Rollback Summary"
echo "=============================================="
echo "Files Restored: $RESTORED_FILES"
echo "Failed Restorations: $FAILED_RESTORATIONS"
echo "Backup Used: $selected_backup"
echo "End Time: $(date)"

log_rollback "INFO" "Rollback process completed"
log_rollback "INFO" "Files restored: $RESTORED_FILES"
log_rollback "INFO" "Failed restorations: $FAILED_RESTORATIONS"

if [ $FAILED_RESTORATIONS -eq 0 ]; then
    echo "Status: ✓ ROLLBACK COMPLETED SUCCESSFULLY"
    exit 0
else
    echo "Status: ✗ SOME ROLLBACKS FAILED"
    echo "Check $LOG_FILE for details"
    exit 1
fi

echo "=============================================="
"""

# Write rollback script
rollback_script_path = os.path.join(scripts_dir, 'rollback_remediations.sh')
with open(rollback_script_path, 'w') as f:
    f.write(rollback_script)
os.chmod(rollback_script_path, 0o755)

print("Created rollback_remediations.sh")