# Create master execution script
master_script = """#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark - Master Remediation Script
# Executes all 246 CIS remediation scripts in order
# Generated: October 12, 2025
################################################################################

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="master_remediation.log"
TOTAL_SCRIPTS=246
CURRENT_SCRIPT=0
FAILED_SCRIPTS=()
SUCCESS_COUNT=0

# Logging function
log_master() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [MASTER] $message" | tee -a "$LOG_FILE"
}

# Progress display
show_progress() {
    local current=$1
    local total=$2
    local percent=$((current * 100 / total))
    local bar_length=50
    local filled_length=$((percent * bar_length / 100))
    
    printf "\\r["
    printf "%*s" "$filled_length" | tr ' ' '='
    printf "%*s" $((bar_length - filled_length)) | tr ' ' '-'
    printf "] %d%% (%d/%d)" "$percent" "$current" "$total"
}

echo "=============================================="
echo "CIS Oracle Linux 7 Benchmark Remediation"
echo "=============================================="
echo "Total Scripts: $TOTAL_SCRIPTS"
echo "Start Time: $(date)"
echo "=============================================="

log_master "INFO" "Starting master remediation process"
log_master "INFO" "Total scripts to execute: $TOTAL_SCRIPTS"

# Confirm execution
read -p "This will execute ALL $TOTAL_SCRIPTS CIS remediation scripts. Continue? (yes/no): " confirm
if [[ $confirm != "yes" ]]; then
    echo "Execution cancelled by user."
    exit 0
fi

# Execute scripts in order
cd "$SCRIPT_DIR"

for script_file in $(ls -1 *.sh | grep -v "run_all_remediations.sh" | sort -V); do
    if [ -x "$script_file" ]; then
        CURRENT_SCRIPT=$((CURRENT_SCRIPT + 1))
        
        log_master "INFO" "[$CURRENT_SCRIPT/$TOTAL_SCRIPTS] Executing: $script_file"
        show_progress $CURRENT_SCRIPT $TOTAL_SCRIPTS
        
        if ./"$script_file" >> "$LOG_FILE" 2>&1; then
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
            log_master "SUCCESS" "[$CURRENT_SCRIPT/$TOTAL_SCRIPTS] Completed: $script_file"
        else
            FAILED_SCRIPTS+=("$script_file")
            log_master "ERROR" "[$CURRENT_SCRIPT/$TOTAL_SCRIPTS] Failed: $script_file"
        fi
        
        # Brief pause to prevent system overload
        sleep 1
    else
        log_master "WARNING" "Script not executable: $script_file"
    fi
done

echo
echo "=============================================="
echo "CIS Remediation Summary"
echo "=============================================="
echo "Total Scripts: $TOTAL_SCRIPTS"
echo "Successful: $SUCCESS_COUNT"
echo "Failed: ${#FAILED_SCRIPTS[@]}"
echo "End Time: $(date)"

log_master "INFO" "Remediation process completed"
log_master "INFO" "Success: $SUCCESS_COUNT/$TOTAL_SCRIPTS scripts"
log_master "INFO" "Failed: ${#FAILED_SCRIPTS[@]} scripts"

if [ ${#FAILED_SCRIPTS[@]} -gt 0 ]; then
    echo
    echo "Failed Scripts:"
    for failed in "${FAILED_SCRIPTS[@]}"; do
        echo "  - $failed"
        log_master "ERROR" "Failed script: $failed"
    done
    echo
    echo "Check $LOG_FILE for detailed error information"
    exit 1
else
    echo
    echo "✓ All remediation scripts completed successfully!"
    echo "Check $LOG_FILE for detailed execution log"
    exit 0
fi
"""

# Write master script
master_script_path = os.path.join(scripts_dir, 'run_all_remediations.sh')
with open(master_script_path, 'w') as f:
    f.write(master_script)
os.chmod(master_script_path, 0o755)

print("Created run_all_remediations.sh")