#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: 3.4.2_sctp_disabled.sh
# CIS ID: 3.4.2
# Description: CIS 3.4.2 remediation
# Generated: 2025-10-12 21:13:09
################################################################################

# Script variables
SCRIPT_NAME="3.4.2_sctp_disabled.sh"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}

# Backup function
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
# Initialize result tracking
result="success"

# CIS Remediation: Disable sctp kernel module
CONF_FILE="/etc/modprobe.d/sctp.conf"
MODULE_NAME="sctp"

log_message "INFO" "Disabling $MODULE_NAME kernel module"

# REMEDIATION STEP 1: Create or update modprobe configuration
# This prevents the module from being loaded by adding 'install sctp /bin/true'
echo "[INFO] Configuring $CONF_FILE to disable $MODULE_NAME module"

backup_file "$CONF_FILE"

if [ ! -f "$CONF_FILE" ]; then
    # Create new configuration file
    echo "install $MODULE_NAME /bin/true" > "$CONF_FILE" && \
    log_message "SUCCESS" "Created $CONF_FILE with disable directive" || \
    { result="failed"; log_message "ERROR" "Failed to create $CONF_FILE"; }
else
    # Check if configuration already exists
    if ! grep -q "^install $MODULE_NAME /bin/true" "$CONF_FILE"; then
        # Append configuration to existing file
        echo "install $MODULE_NAME /bin/true" >> "$CONF_FILE" && \
        log_message "SUCCESS" "Added $MODULE_NAME disable directive to $CONF_FILE" || \
        { result="failed"; log_message "ERROR" "Failed to update $CONF_FILE"; }
    else
        log_message "INFO" "$MODULE_NAME already disabled in $CONF_FILE"
    fi
fi

# REMEDIATION STEP 2: Unload the module if currently loaded
# The 'rmmod' command removes the kernel module from memory
echo "[INFO] Checking if $MODULE_NAME module is loaded"
if lsmod | grep -q "^$MODULE_NAME"; then
    # REMEDIATION ACTION: Unload the kernel module
    log_message "INFO" "Unloading $MODULE_NAME module"
    rmmod "$MODULE_NAME" 2>/dev/null && \
    log_message "SUCCESS" "$MODULE_NAME module unloaded successfully" || \
    log_message "WARNING" "$MODULE_NAME module could not be unloaded (may be in use)"
else
    log_message "INFO" "$MODULE_NAME module not currently loaded"
fi

# Verify the configuration
echo "[INFO] Verification: Checking module status"
if [ -f "$CONF_FILE" ] && grep -q "install $MODULE_NAME /bin/true" "$CONF_FILE"; then
    log_message "SUCCESS" "$MODULE_NAME module disable configuration verified"
else
    result="failed"
    log_message "ERROR" "Module disable configuration verification failed"
fi

# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "Remediation completed successfully"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
