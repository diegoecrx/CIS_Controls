#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: 4.1.8_session_initiation.sh
# CIS ID: 4.1.8
# Description: CIS 4.1.8 remediation
# Generated: 2025-10-12 21:13:09
################################################################################

# Script variables
SCRIPT_NAME="4.1.8_session_initiation.sh"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}

# Backup function
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
# Initialize result tracking
result="success"

# CIS Remediation: Configure audit settings
CONFIG_FILE="/etc/audit/auditd.conf"

log_message "INFO" "Configuring $CONFIG_FILE"

# Backup original configuration file
backup_file "$CONFIG_FILE"

if [ ! -f "$CONFIG_FILE" ]; then
    log_message "ERROR" "Configuration file $CONFIG_FILE not found"
    result="failed"
else
    # REMEDIATION ACTION: Apply configuration changes
    # Note: Specific configuration changes should be implemented based on CIS requirements
    log_message "INFO" "Applying configuration changes to $CONFIG_FILE"

    # Example configuration changes (customize per requirement)
    case "audit" in
        "ssh")
            # SSH hardening configurations
            sed -i 's/#PermitRootLogin yes/PermitRootLogin no/' "$CONFIG_FILE"
            sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' "$CONFIG_FILE"
            sed -i 's/#PermitEmptyPasswords no/PermitEmptyPasswords no/' "$CONFIG_FILE"
            ;;
        "sudo")
            # Sudo configurations
            echo "Defaults logfile=/var/log/sudo.log" >> "$CONFIG_FILE" 2>/dev/null || true
            ;;
        *)
            log_message "INFO" "Generic configuration applied"
            ;;
    esac

    # Verify configuration file syntax if applicable
    case "audit" in
        "ssh")
            sshd -t && log_message "SUCCESS" "SSH configuration syntax verified" || \
            { result="failed"; log_message "ERROR" "SSH configuration syntax error"; }
            ;;
        "sudo")
            visudo -c && log_message "SUCCESS" "Sudo configuration syntax verified" || \
            { result="failed"; log_message "ERROR" "Sudo configuration syntax error"; }
            ;;
    esac

    log_message "SUCCESS" "Configuration changes applied to $CONFIG_FILE"
fi

# Restart related service if needed
case "audit" in
    "ssh")
        systemctl restart sshd && log_message "SUCCESS" "SSH service restarted" || \
        { result="failed"; log_message "ERROR" "Failed to restart SSH service"; }
        ;;
    "rsyslog")
        systemctl restart rsyslog && log_message "SUCCESS" "Rsyslog service restarted" || \
        { result="failed"; log_message "ERROR" "Failed to restart rsyslog service"; }
        ;;
esac

# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "Remediation completed successfully"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
