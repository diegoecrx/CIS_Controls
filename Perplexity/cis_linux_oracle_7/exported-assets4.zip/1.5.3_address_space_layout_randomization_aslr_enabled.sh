#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: 1.5.3_address_space_layout_randomization_aslr_enabled.sh
# CIS ID: 1.5.3
# Description: CIS 1.5.3 remediation
# Generated: 2025-10-12 21:13:09
################################################################################

# Script variables
SCRIPT_NAME="1.5.3_address_space_layout_randomization_aslr_enabled.sh"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}

# Backup function
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
# Initialize result tracking
result="success"

# CIS Remediation: Configure kernel parameters via sysctl
SYSCTL_CONF="/etc/sysctl.d/99-cis.conf"

log_message "INFO" "Configuring kernel parameters"

# Backup existing sysctl configuration
backup_file "$SYSCTL_CONF"
backup_file "/etc/sysctl.conf"

# Create CIS sysctl configuration file
touch "$SYSCTL_CONF"


# REMEDIATION ACTION: Set kernel.randomize_va_space = 2
echo "Setting kernel.randomize_va_space = 2"
if ! grep -q "^kernel.randomize_va_space" "$SYSCTL_CONF"; then
    echo "kernel.randomize_va_space = 2" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added kernel.randomize_va_space = 2 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add kernel.randomize_va_space to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^kernel.randomize_va_space.*/kernel.randomize_va_space = 2/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated kernel.randomize_va_space = 2 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update kernel.randomize_va_space in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "kernel.randomize_va_space=2" && \
log_message "SUCCESS" "Applied kernel.randomize_va_space = 2 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply kernel.randomize_va_space = 2"; }

# REMEDIATION ACTION: Set kernel.randomize_va_space = 2
echo "Setting kernel.randomize_va_space = 2"
if ! grep -q "^kernel.randomize_va_space" "$SYSCTL_CONF"; then
    echo "kernel.randomize_va_space = 2" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added kernel.randomize_va_space = 2 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add kernel.randomize_va_space to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^kernel.randomize_va_space.*/kernel.randomize_va_space = 2/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated kernel.randomize_va_space = 2 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update kernel.randomize_va_space in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "kernel.randomize_va_space=2" && \
log_message "SUCCESS" "Applied kernel.randomize_va_space = 2 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply kernel.randomize_va_space = 2"; }

# REMEDIATION ACTION: Reload all sysctl parameters
echo "[INFO] Reloading all sysctl parameters"
sysctl -p "$SYSCTL_CONF" && \
log_message "SUCCESS" "All sysctl parameters reloaded" || \
{ result="failed"; log_message "ERROR" "Failed to reload sysctl parameters"; }

# Verify parameters are set correctly
echo "[INFO] Verifying sysctl parameters:"
sysctl kernel.randomize_va_space || true
sysctl kernel.randomize_va_space || true

# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "Remediation completed successfully"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
