#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: 1.8.2_gdm_login_banner.sh
# CIS ID: 1.8.2
# Description: CIS 1.8.2 remediation
# Generated: 2025-10-12 21:13:09
################################################################################

# Script variables
SCRIPT_NAME="1.8.2_gdm_login_banner.sh"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}

# Backup function
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
# Initialize result tracking
result="success"

# CIS Remediation: Disable and mask unnecessary services

SERVICE_NAME="unknown_service"

log_message "INFO" "Processing service: $SERVICE_NAME"

# REMEDIATION ACTION: Stop the service if it's running
if systemctl is-active --quiet "$SERVICE_NAME"; then
    log_message "INFO" "Stopping $SERVICE_NAME service"
    systemctl stop "$SERVICE_NAME" && \
    log_message "SUCCESS" "$SERVICE_NAME service stopped" || \
    { result="failed"; log_message "ERROR" "Failed to stop $SERVICE_NAME"; }
else
    log_message "INFO" "$SERVICE_NAME service is not running"
fi

# REMEDIATION ACTION: Disable the service from starting at boot
if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
    log_message "INFO" "Disabling $SERVICE_NAME service"
    systemctl disable "$SERVICE_NAME" && \
    log_message "SUCCESS" "$SERVICE_NAME service disabled" || \
    { result="failed"; log_message "ERROR" "Failed to disable $SERVICE_NAME"; }
else
    log_message "INFO" "$SERVICE_NAME service is not enabled"
fi

# REMEDIATION ACTION: Mask the service to prevent it from being started
systemctl mask "$SERVICE_NAME" 2>/dev/null && \
log_message "SUCCESS" "$SERVICE_NAME service masked" || \
log_message "INFO" "$SERVICE_NAME service masking attempted"

# Verify service status
echo "[INFO] Final status of $SERVICE_NAME:"
systemctl status "$SERVICE_NAME" --no-pager -l || true

# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "Remediation completed successfully"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
