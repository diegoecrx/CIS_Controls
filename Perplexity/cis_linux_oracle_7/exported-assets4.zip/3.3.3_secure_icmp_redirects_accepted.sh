#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: 3.3.3_secure_icmp_redirects_accepted.sh
# CIS ID: 3.3.3
# Description: CIS 3.3.3 remediation
# Generated: 2025-10-12 21:13:09
################################################################################

# Script variables
SCRIPT_NAME="3.3.3_secure_icmp_redirects_accepted.sh"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}

# Backup function
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
# Initialize result tracking
result="success"

# CIS Remediation: Configure kernel parameters via sysctl
SYSCTL_CONF="/etc/sysctl.d/99-cis.conf"

log_message "INFO" "Configuring kernel parameters"

# Backup existing sysctl configuration
backup_file "$SYSCTL_CONF"
backup_file "/etc/sysctl.conf"

# Create CIS sysctl configuration file
touch "$SYSCTL_CONF"


# REMEDIATION ACTION: Set net.ipv4.conf.all.secure_redirects = 0
echo "Setting net.ipv4.conf.all.secure_redirects = 0"
if ! grep -q "^net.ipv4.conf.all.secure_redirects" "$SYSCTL_CONF"; then
    echo "net.ipv4.conf.all.secure_redirects = 0" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added net.ipv4.conf.all.secure_redirects = 0 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add net.ipv4.conf.all.secure_redirects to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^net.ipv4.conf.all.secure_redirects.*/net.ipv4.conf.all.secure_redirects = 0/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated net.ipv4.conf.all.secure_redirects = 0 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update net.ipv4.conf.all.secure_redirects in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "net.ipv4.conf.all.secure_redirects=0" && \
log_message "SUCCESS" "Applied net.ipv4.conf.all.secure_redirects = 0 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply net.ipv4.conf.all.secure_redirects = 0"; }

# REMEDIATION ACTION: Set net.ipv4.conf.default.secure_redirects = 0
echo "Setting net.ipv4.conf.default.secure_redirects = 0"
if ! grep -q "^net.ipv4.conf.default.secure_redirects" "$SYSCTL_CONF"; then
    echo "net.ipv4.conf.default.secure_redirects = 0" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added net.ipv4.conf.default.secure_redirects = 0 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add net.ipv4.conf.default.secure_redirects to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^net.ipv4.conf.default.secure_redirects.*/net.ipv4.conf.default.secure_redirects = 0/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated net.ipv4.conf.default.secure_redirects = 0 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update net.ipv4.conf.default.secure_redirects in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "net.ipv4.conf.default.secure_redirects=0" && \
log_message "SUCCESS" "Applied net.ipv4.conf.default.secure_redirects = 0 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply net.ipv4.conf.default.secure_redirects = 0"; }

# REMEDIATION ACTION: Set net.ipv4.conf.all.secure_redirects = 0
echo "Setting net.ipv4.conf.all.secure_redirects = 0"
if ! grep -q "^net.ipv4.conf.all.secure_redirects" "$SYSCTL_CONF"; then
    echo "net.ipv4.conf.all.secure_redirects = 0" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added net.ipv4.conf.all.secure_redirects = 0 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add net.ipv4.conf.all.secure_redirects to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^net.ipv4.conf.all.secure_redirects.*/net.ipv4.conf.all.secure_redirects = 0/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated net.ipv4.conf.all.secure_redirects = 0 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update net.ipv4.conf.all.secure_redirects in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "net.ipv4.conf.all.secure_redirects=0" && \
log_message "SUCCESS" "Applied net.ipv4.conf.all.secure_redirects = 0 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply net.ipv4.conf.all.secure_redirects = 0"; }

# REMEDIATION ACTION: Set net.ipv4.conf.default.secure_redirects = 0
echo "Setting net.ipv4.conf.default.secure_redirects = 0"
if ! grep -q "^net.ipv4.conf.default.secure_redirects" "$SYSCTL_CONF"; then
    echo "net.ipv4.conf.default.secure_redirects = 0" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added net.ipv4.conf.default.secure_redirects = 0 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add net.ipv4.conf.default.secure_redirects to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^net.ipv4.conf.default.secure_redirects.*/net.ipv4.conf.default.secure_redirects = 0/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated net.ipv4.conf.default.secure_redirects = 0 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update net.ipv4.conf.default.secure_redirects in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "net.ipv4.conf.default.secure_redirects=0" && \
log_message "SUCCESS" "Applied net.ipv4.conf.default.secure_redirects = 0 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply net.ipv4.conf.default.secure_redirects = 0"; }

# REMEDIATION ACTION: Set net.ipv4.route.flush = 1
echo "Setting net.ipv4.route.flush = 1"
if ! grep -q "^net.ipv4.route.flush" "$SYSCTL_CONF"; then
    echo "net.ipv4.route.flush = 1" >> "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Added net.ipv4.route.flush = 1 to $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to add net.ipv4.route.flush to $SYSCTL_CONF"; }
else
    # Update existing parameter
    sed -i "s/^net.ipv4.route.flush.*/net.ipv4.route.flush = 1/" "$SYSCTL_CONF" && \
    log_message "SUCCESS" "Updated net.ipv4.route.flush = 1 in $SYSCTL_CONF" || \
    { result="failed"; log_message "ERROR" "Failed to update net.ipv4.route.flush in $SYSCTL_CONF"; }
fi

# Apply the parameter immediately
sysctl -w "net.ipv4.route.flush=1" && \
log_message "SUCCESS" "Applied net.ipv4.route.flush = 1 to running kernel" || \
{ result="failed"; log_message "ERROR" "Failed to apply net.ipv4.route.flush = 1"; }

# REMEDIATION ACTION: Reload all sysctl parameters
echo "[INFO] Reloading all sysctl parameters"
sysctl -p "$SYSCTL_CONF" && \
log_message "SUCCESS" "All sysctl parameters reloaded" || \
{ result="failed"; log_message "ERROR" "Failed to reload sysctl parameters"; }

# Verify parameters are set correctly
echo "[INFO] Verifying sysctl parameters:"
sysctl net.ipv4.conf.all.secure_redirects || true
sysctl net.ipv4.conf.default.secure_redirects || true
sysctl net.ipv4.conf.all.secure_redirects || true
sysctl net.ipv4.conf.default.secure_redirects || true
sysctl net.ipv4.route.flush || true

# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "Remediation completed successfully"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
