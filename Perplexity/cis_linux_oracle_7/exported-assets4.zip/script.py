import pandas as pd
import os
import zipfile
from datetime import datetime
import re

# Read the Excel file
df = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v3.1.1.xlsx')

# Create directory for scripts
scripts_dir = 'cis_remediation_scripts'
os.makedirs(scripts_dir, exist_ok=True)

def clean_script_name(name):
    """Clean script name to be filesystem safe"""
    return re.sub(r'[^\w\-_\.]', '_', name)

def create_script_header(script_name, cis_id="", description=""):
    """Create standardized script header"""
    return f"""#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark Remediation Script
# Script: {script_name}
# CIS ID: {cis_id}
# Description: {description}
# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
################################################################################

# Exit on error (commented out for flexibility in some remediations)
# set -e

# Script variables
SCRIPT_NAME="{script_name}"
LOG_FILE="cis_remediation.log"
BACKUP_DIR="/tmp/cis_backup_$(date +%Y%m%d_%H%M%S)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Logging function
log_message() {{
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"
}}

# Backup function
backup_file() {{
    local file="$1"
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/$(basename $file).backup" 2>/dev/null || true
        log_message "INFO" "Backed up $file"
    fi
}}

# Start script execution
log_message "INFO" "Starting remediation script"
echo "============================================"
echo "CIS Remediation: $SCRIPT_NAME"
echo "============================================"
"""

def create_script_footer(success_msg="Remediation completed successfully"):
    return f"""
# Script completion
if [ "$result" = "success" ]; then
    log_message "SUCCESS" "{success_msg}"
    echo "============================================"
    echo "✓ Remediation completed successfully"
    echo "Logs: $LOG_FILE"
    echo "Backups: $BACKUP_DIR"
    echo "============================================"
    exit 0
else
    log_message "ERROR" "Remediation failed or incomplete"
    echo "============================================"
    echo "✗ Remediation encountered errors"
    echo "Check $LOG_FILE for details"
    echo "Backups available in: $BACKUP_DIR"
    echo "============================================"
    exit 1
fi
"""

print(f"Creating all {len(df)} CIS remediation scripts...")
print("=" * 80)

# Counter for progress
script_count = 0
failed_scripts = []

# Process all scripts
for idx, row in df.iterrows():
    try:
        script_name = str(row['script_name']).strip()
        remediation = str(row['Remediation']).strip()
        
        # Extract CIS ID from script name
        cis_id_match = re.search(r'(\d+\.\d+\.\d+(?:\.\d+)?)', script_name)
        cis_id = cis_id_match.group(1) if cis_id_match else ""
        
        # Clean script name for filesystem
        safe_script_name = clean_script_name(script_name)
        if not safe_script_name.endswith('.sh'):
            safe_script_name += '.sh'
        
        script_path = os.path.join(scripts_dir, safe_script_name)
        
        # Generate script content based on remediation type
        script_content = generate_script_content(script_name, cis_id, remediation)
        
        # Write script to file
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        # Make script executable
        os.chmod(script_path, 0o755)
        
        script_count += 1
        if script_count % 50 == 0:
            print(f"Created {script_count}/{len(df)} scripts...")
            
    except Exception as e:
        failed_scripts.append((script_name, str(e)))
        print(f"Failed to create {script_name}: {e}")

print(f"\nScript Creation Summary:")
print(f"✓ Successfully created: {script_count} scripts")
print(f"✗ Failed: {len(failed_scripts)} scripts")

if failed_scripts:
    print("\nFailed scripts:")
    for name, error in failed_scripts[:5]:  # Show first 5 failures
        print(f"  - {name}: {error}")

def generate_script_content(script_name, cis_id, remediation):
    """Generate script content based on remediation instructions"""
    
    # Start with header
    description = f"CIS {cis_id} remediation"
    content = create_script_header(script_name, cis_id, description)
    
    # Initialize result variable
    content += "\n# Initialize result tracking\nresult=\"success\"\n\n"
    
    # Parse remediation and create appropriate commands
    if "modprobe" in remediation.lower() and any(fs in remediation.lower() for fs in ['cramfs', 'squashfs', 'udf', 'dccp', 'sctp']):
        content += generate_module_disable_script(remediation)
    elif "/tmp" in remediation and "mount" in remediation.lower():
        content += generate_mount_script(remediation, "/tmp")
    elif "fstab" in remediation.lower() and "mount" in remediation.lower():
        content += generate_fstab_script(remediation)
    elif "systemctl" in remediation.lower():
        content += generate_systemctl_script(remediation)
    elif "firewall" in remediation.lower() or "iptables" in remediation.lower():
        content += generate_firewall_script(remediation)
    elif "sysctl" in remediation.lower():
        content += generate_sysctl_script(remediation)
    elif any(service in remediation.lower() for service in ['ssh', 'cron', 'sudo', 'audit']):
        content += generate_config_file_script(remediation)
    else:
        content += generate_generic_script(remediation)
    
    # Add footer
    content += create_script_footer()
    
    return content

# Let me implement the generation functions
def generate_module_disable_script(remediation):
    """Generate script for disabling kernel modules"""
    
    # Extract module name
    module_match = re.search(r'install (\w+) /bin/true', remediation)
    if not module_match:
        # Try to find module in rmmod command
        module_match = re.search(r'rmmod (\w+)', remediation)
    
    module_name = module_match.group(1) if module_match else "unknown_module"
    
    return f'''# CIS Remediation: Disable {module_name} kernel module
CONF_FILE="/etc/modprobe.d/{module_name}.conf"
MODULE_NAME="{module_name}"

log_message "INFO" "Disabling $MODULE_NAME kernel module"

# REMEDIATION STEP 1: Create or update modprobe configuration
# This prevents the module from being loaded by adding 'install {module_name} /bin/true'
echo "[INFO] Configuring $CONF_FILE to disable $MODULE_NAME module"

backup_file "$CONF_FILE"

if [ ! -f "$CONF_FILE" ]; then
    # Create new configuration file
    echo "install $MODULE_NAME /bin/true" > "$CONF_FILE" && \\
    log_message "SUCCESS" "Created $CONF_FILE with disable directive" || \\
    {{ result="failed"; log_message "ERROR" "Failed to create $CONF_FILE"; }}
else
    # Check if configuration already exists
    if ! grep -q "^install $MODULE_NAME /bin/true" "$CONF_FILE"; then
        # Append configuration to existing file
        echo "install $MODULE_NAME /bin/true" >> "$CONF_FILE" && \\
        log_message "SUCCESS" "Added $MODULE_NAME disable directive to $CONF_FILE" || \\
        {{ result="failed"; log_message "ERROR" "Failed to update $CONF_FILE"; }}
    else
        log_message "INFO" "$MODULE_NAME already disabled in $CONF_FILE"
    fi
fi

# REMEDIATION STEP 2: Unload the module if currently loaded
# The 'rmmod' command removes the kernel module from memory
echo "[INFO] Checking if $MODULE_NAME module is loaded"
if lsmod | grep -q "^$MODULE_NAME"; then
    # REMEDIATION ACTION: Unload the kernel module
    log_message "INFO" "Unloading $MODULE_NAME module"
    rmmod "$MODULE_NAME" 2>/dev/null && \\
    log_message "SUCCESS" "$MODULE_NAME module unloaded successfully" || \\
    log_message "WARNING" "$MODULE_NAME module could not be unloaded (may be in use)"
else
    log_message "INFO" "$MODULE_NAME module not currently loaded"
fi

# Verify the configuration
echo "[INFO] Verification: Checking module status"
if [ -f "$CONF_FILE" ] && grep -q "install $MODULE_NAME /bin/true" "$CONF_FILE"; then
    log_message "SUCCESS" "$MODULE_NAME module disable configuration verified"
else
    result="failed"
    log_message "ERROR" "Module disable configuration verification failed"
fi

'''

# Continue implementing other generation functions...