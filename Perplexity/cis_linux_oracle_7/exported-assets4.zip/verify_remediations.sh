#!/bin/bash

################################################################################
# CIS Oracle Linux 7 Benchmark - Verification Script
# Verifies successful implementation of CIS remediations
# Generated: October 12, 2025
################################################################################

LOG_FILE="verification_results.log"
PASSED_CHECKS=0
FAILED_CHECKS=0
TOTAL_CHECKS=0

# Logging function
log_verify() {
    local level="$1"
    shift
    local message="$@"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [VERIFY] $message" | tee -a "$LOG_FILE"
}

# Check function
check_item() {
    local check_name="$1"
    local check_command="$2"
    local expected_result="$3"

    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

    echo -n "Checking $check_name... "

    if eval "$check_command" >/dev/null 2>&1; then
        echo "PASS"
        log_verify "PASS" "$check_name"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        echo "FAIL"
        log_verify "FAIL" "$check_name"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi
}

echo "=============================================="
echo "CIS Oracle Linux 7 Benchmark Verification"
echo "=============================================="
echo "Start Time: $(date)"
echo "=============================================="

log_verify "INFO" "Starting CIS compliance verification"

echo
echo "Section 1.1 - Filesystem Configuration"
echo "--------------------------------------"

# 1.1.1.x - Filesystem modules
check_item "cramfs disabled" "grep -q '^install cramfs /bin/true' /etc/modprobe.d/cramfs.conf" "true"
check_item "squashfs disabled" "grep -q '^install squashfs /bin/true' /etc/modprobe.d/squashfs.conf" "true"  
check_item "udf disabled" "grep -q '^install udf /bin/true' /etc/modprobe.d/udf.conf" "true"

# 1.1.2-5 - /tmp mount options
check_item "/tmp noexec option" "mount | grep -q '/tmp.*noexec'" "true"
check_item "/tmp nodev option" "mount | grep -q '/tmp.*nodev'" "true"
check_item "/tmp nosuid option" "mount | grep -q '/tmp.*nosuid'" "true"

echo
echo "Section 2.2 - Services"
echo "----------------------"

# Common services that should be disabled
services_to_check=(
    "xinetd"
    "avahi-daemon" 
    "cups"
    "dhcpd"
    "slapd"
    "named"
    "vsftpd"
    "httpd"
    "dovecot"
    "smb"
    "squid"
    "snmpd"
    "ypserv"
    "rsh.socket"
    "rlogin.socket"
    "rexec.socket"
    "telnet.socket"
)

for service in "${services_to_check[@]}"; do
    check_item "$service disabled" "! systemctl is-enabled $service >/dev/null 2>&1" "true"
done

echo
echo "Section 3.3 - Network Parameters"
echo "--------------------------------"

# Network security parameters
network_params=(
    "net.ipv4.ip_forward:0"
    "net.ipv4.conf.all.send_redirects:0" 
    "net.ipv4.conf.default.send_redirects:0"
    "net.ipv4.conf.all.accept_source_route:0"
    "net.ipv4.conf.default.accept_source_route:0"
    "net.ipv4.conf.all.accept_redirects:0"
    "net.ipv4.conf.default.accept_redirects:0"
    "net.ipv4.conf.all.secure_redirects:0"
    "net.ipv4.conf.default.secure_redirects:0"
    "net.ipv4.conf.all.log_martians:1"
    "net.ipv4.conf.default.log_martians:1"
    "net.ipv4.icmp_echo_ignore_broadcasts:1"
    "net.ipv4.icmp_ignore_bogus_error_responses:1"
    "net.ipv4.conf.all.rp_filter:1"
    "net.ipv4.conf.default.rp_filter:1"
    "net.ipv4.tcp_syncookies:1"
)

for param in "${network_params[@]}"; do
    param_name="${param%:*}"
    expected_value="${param#*:}"
    check_item "sysctl $param_name" "[ '$(sysctl -n $param_name 2>/dev/null)' = '$expected_value' ]" "true"
done

echo
echo "Section 4.1 - Auditd"
echo "--------------------"

check_item "auditd installed" "rpm -q audit >/dev/null 2>&1" "true"
check_item "auditd enabled" "systemctl is-enabled auditd >/dev/null 2>&1" "true"
check_item "auditd running" "systemctl is-active auditd >/dev/null 2>&1" "true"

echo
echo "Section 5.3 - SSH Configuration"
echo "-------------------------------"

ssh_config="/etc/ssh/sshd_config"
if [ -f "$ssh_config" ]; then
    check_item "SSH Protocol 2" "grep -q '^Protocol 2' $ssh_config || ! grep -q '^Protocol ' $ssh_config" "true"
    check_item "SSH PermitRootLogin disabled" "grep -q '^PermitRootLogin no' $ssh_config" "true"
    check_item "SSH PermitEmptyPasswords disabled" "grep -q '^PermitEmptyPasswords no' $ssh_config" "true"
    check_item "SSH X11Forwarding disabled" "grep -q '^X11Forwarding no' $ssh_config" "true"
else
    log_verify "WARNING" "SSH configuration file not found: $ssh_config"
fi

echo
echo "Section 6.1 - File Permissions"
echo "------------------------------"

# Critical file permissions
file_perms=(
    "/etc/passwd:644"
    "/etc/shadow:000"
    "/etc/group:644"
    "/etc/gshadow:000"
)

for item in "${file_perms[@]}"; do
    file="${item%:*}"
    expected_perm="${item#*:}"
    if [ -f "$file" ]; then
        actual_perm=$(stat -c "%a" "$file" 2>/dev/null)
        check_item "$file permissions ($expected_perm)" "[ '$actual_perm' = '$expected_perm' ]" "true"
    else
        log_verify "WARNING" "File not found: $file"
    fi
done

echo
echo "=============================================="
echo "Verification Summary"
echo "=============================================="
echo "Total Checks: $TOTAL_CHECKS"
echo "Passed: $PASSED_CHECKS"
echo "Failed: $FAILED_CHECKS"

if [ $FAILED_CHECKS -eq 0 ]; then
    echo "Status: ✓ ALL CHECKS PASSED"
    log_verify "SUCCESS" "All verification checks passed ($PASSED_CHECKS/$TOTAL_CHECKS)"
    exit 0
else
    echo "Status: ✗ SOME CHECKS FAILED"
    echo "Check $LOG_FILE for detailed results"
    log_verify "WARNING" "Some verification checks failed ($FAILED_CHECKS/$TOTAL_CHECKS)"
    exit 1
fi

echo "End Time: $(date)"
echo "=============================================="
