# 1.1.3.ps1
(& {
  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $after = 1
  
  if ($role -in 4, 5) {
    Import-Module ActiveDirectory -ErrorAction Stop
    $currentPolicy = Get-ADDefaultDomainPasswordPolicy
    $current = $currentPolicy.MinPasswordAge.Days
    Set-ADDefaultDomainPasswordPolicy -Identity $currentPolicy.DistinguishedName -MinPasswordAge (New-TimeSpan -Days $after)
    
    Write-Output "Control: 1.1.3 (L1) Ensure 'Minimum password age' is set to '1 or more day(s)' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Password Policy\Minimum password age"
    Write-Output "Name: MinimumPasswordAge"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  } else {
    $tempPath = $env:TEMP
    $beforeInf = Join-Path $tempPath 'before_policy.inf'
    $afterInf = Join-Path $tempPath 'minpasswordage.inf'
    
    secedit /export /cfg $beforeInf /areas SECURITYPOLICY /quiet | Out-Null
    $beforeLine = Select-String -Path $beforeInf -Pattern '^MinimumPasswordAge\s*=\s*(\d+)' | Select-Object -First 1
    $current = if ($beforeLine) { [int]$beforeLine.Matches[0].Groups[1].Value } else { 0 }
    
    Set-Content -Path $afterInf -Encoding ascii -Value @(
      '[Unicode]',
      'Unicode=yes',
      '[System Access]',
      "MinimumPasswordAge = $after",
      '[Version]',
      'signature="$CHICAGO$"',
      'Revision=1'
    )
    
    secedit /configure /db "$tempPath\secedit.sdb" /cfg $afterInf /areas SECURITYPOLICY /quiet | Out-Null
    
    Write-Output "Control: 1.1.3 (L1) Ensure 'Minimum password age' is set to '1 or more day(s)' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Password Policy\Minimum password age"
    Write-Output "Name: MinimumPasswordAge"
    Write-Output "Current: $current"
    Write-Output "After: $after"
    
    Remove-Item $beforeInf, $afterInf -Force -ErrorAction SilentlyContinue
  }
})
