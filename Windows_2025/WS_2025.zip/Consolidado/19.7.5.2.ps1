# 19.7.5.2.ps1
# Note: This script modifies HKCU (user registry). Run in user context or modify to use HKLM for machine-wide policy.
(& {
  $regKey = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments"
  $regValue = "ScanWithAntiVirus"
  $after = 3
  $valueType = "DWord"

  try {
    # Ensure registry path exists
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    # Get current value
    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    # Apply remediation
    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type $valueType -Force

    Write-Output "Control: 19.7.5.2 (L1) Ensure 'Notify antivirus programs when opening attachments' is set to 'Enabled' (Automated)"
    Write-Output "Path:  User Configuration\Policies\Administrative Templates"
    Write-Output "Name: ScanWithAntiVirus"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 19.7.5.2 (L1) Ensure 'Notify antivirus programs when opening attachments' is set to 'Enabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
