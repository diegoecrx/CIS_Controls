
import pandas as pd

# Read the Excel file for section 5
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section5.xlsx', sheet_name='Recommendations')

# Display all details
print("Section 5 - Complete Details\n")
print("="*80)

for idx in range(len(df)):
    print(f"\nScript {idx + 1}:")
    print(f"Script Name: {df.loc[idx, 'script_name']}")
    print(f"Control Name: {df.loc[idx, 'control_name']}")
    print(f"Profile: {df.loc[idx, 'profile_applicability']}")
    print(f"Remediation: {df.loc[idx, 'remediation'][:300]}...")
    print(f"Default Value: {df.loc[idx, 'default_value']}")
    print("-"*80)
