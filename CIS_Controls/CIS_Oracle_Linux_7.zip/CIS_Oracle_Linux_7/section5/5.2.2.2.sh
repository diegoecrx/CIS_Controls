#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 5.2.2.2.sh
# CIS Control - 5.2.2.2 Ensure audit logs are not automatically deleted (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="5.2.2.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "5.2.2.2 Ensure audit logs are not automatically deleted (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures audit logs are not automatically deleted."
echo ""

log_message "Starting remediation: Prevent audit log deletion"

FILE="/etc/audit/auditd.conf"
backup_file "$FILE"

sed -i 's/^max_log_file_action\s*=.*/max_log_file_action = keep_logs/' "$FILE"

echo "✓ Audit log deletion prevented"
grep "^max_log_file_action" "$FILE"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
