#!/bin/bash

SCRIPT_NAME="5.3.5_ssh_loglevel_appropriate.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.5 - Ensure SSH LogLevel is appropriate"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH LogLevel..."
    echo ""

    # Check current LogLevel setting
    CURRENT_SETTING=$(grep -i "^LogLevel" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "LogLevel is not explicitly configured (default: INFO)"
        echo "Adding explicit configuration..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.5 - Set appropriate SSH log level" >> "$SSHD_CONFIG"
        echo "LogLevel INFO" >> "$SSHD_CONFIG"
        
        echo "Added 'LogLevel INFO' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added LogLevel INFO directive"
        
    else
        echo "LogLevel is currently set to: $CURRENT_SETTING"
        
        # Convert to uppercase for comparison
        CURRENT_UPPER=$(echo "$CURRENT_SETTING" | tr '[:lower:]' '[:upper:]')
        
        # Check if current setting is compliant (INFO or VERBOSE)
        if [ "$CURRENT_UPPER" = "INFO" ] || [ "$CURRENT_UPPER" = "VERBOSE" ]; then
            echo "LogLevel is compliant ($CURRENT_SETTING)"
            log_message "INFO" "LogLevel already compliant: $CURRENT_SETTING"
        else
            echo "LogLevel is not compliant (should be INFO or VERBOSE)"
            echo "Changing to INFO..."
            
            sed -i 's/^LogLevel.*/LogLevel INFO/' "$SSHD_CONFIG"
            
            echo "Changed LogLevel to INFO"
            log_message "SUCCESS" "Changed LogLevel to INFO"
        fi
    fi

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^LogLevel" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ -n "$FINAL_SETTING" ]; then
        FINAL_UPPER=$(echo "$FINAL_SETTING" | tr '[:lower:]' '[:upper:]')
        
        echo "LogLevel is set to: $FINAL_SETTING"
        echo ""
        
        if [ "$FINAL_UPPER" = "INFO" ] || [ "$FINAL_UPPER" = "VERBOSE" ]; then
            echo "Status: COMPLIANT"
            echo "SSH logging is configured appropriately"
            
            echo ""
            echo "LogLevel details:"
            if [ "$FINAL_UPPER" = "INFO" ]; then
                echo "  - Logs connection attempts and authentication events"
                echo "  - Recommended for most environments"
                echo "  - Balanced between security and log volume"
            else
                echo "  - Provides detailed debugging information"
                echo "  - Useful for troubleshooting"
                echo "  - May generate larger log volumes"
            fi
            
            log_message "SUCCESS" "LogLevel configured properly: $FINAL_SETTING"
        else
            echo "Status: NON-COMPLIANT"
            echo "LogLevel should be INFO or VERBOSE"
            log_message "ERROR" "LogLevel is not compliant: $FINAL_SETTING"
        fi
    else
        echo "LogLevel is not configured"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "ERROR" "LogLevel not configured"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    echo "NOTE: SSH logs are typically written to:"
    echo "  - /var/log/secure (RHEL/CentOS/Oracle Linux)"
    echo "  - /var/log/auth.log (Debian/Ubuntu)"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
