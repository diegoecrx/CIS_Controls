
import pandas as pd
import os

# Read the new Section 5 spreadsheet
df_section5 = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section5.xlsx', sheet_name='Recommendations')

# Display overview
print("=" * 100)
print("CIS ORACLE LINUX 7 BENCHMARK - SECTION 5 ANALYSIS")
print("=" * 100)
print(f"\nTotal number of remediations in Section 5: {len(df_section5)}")
print("\nAll controls:")
print("=" * 100)

for idx in range(len(df_section5)):
    row = df_section5.iloc[idx]
    control_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    print(f"{idx + 1}. {row['script_name']:20s} | {control_type:10s} | {row['control_name']}")

# Count manual vs automated
manual_count = df_section5[df_section5['control_name'].str.contains('Manual', case=False, na=False)].shape[0]
automated_count = df_section5[df_section5['control_name'].str.contains('Automated', case=False, na=False)].shape[0]

print("\n" + "=" * 100)
print(f"Manual controls: {manual_count}")
print(f"Automated controls: {automated_count}")
print(f"Total: {len(df_section5)}")

# Save for processing
df_section5.to_csv('section5_remediation_data.csv', index=False)
print("\n✓ Section 5 data loaded and ready for script generation")
