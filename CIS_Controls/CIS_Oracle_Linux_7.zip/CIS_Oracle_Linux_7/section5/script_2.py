
import pandas as pd
import zipfile
import os

df = pd.read_csv('section5_remediation_data.csv')

# Create summary CSV for Section 5
summary_data = []
for idx, row in df.iterrows():
    script_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    summary_data.append({
        'Script': f"{row['script_name']}.sh",
        'Control': row['control_name'],
        'Type': script_type,
        'Profile': 'Level 2 - Server & Workstation'
    })

summary_df = pd.DataFrame(summary_data)
summary_df.to_csv('section5_scripts/Section5_Script_Summary.csv', index=False)

print("Creating Section 5 downloadable archive...")
print("=" * 100)

# Create comprehensive README
readme_content = '''# CIS Oracle Linux 7 Benchmark Remediation Scripts - Section 5

## Overview
This archive contains 59 bash remediation scripts for CIS Oracle Linux 7 Benchmark v4.0.0 Section 5 (Logging and Auditing).

## Contents
- 59 remediation scripts (5.1.1.1.sh through 5.3.2.sh)
- Original spreadsheet with remediation details
- Script summary CSV

## Script Categories

### 5.1.1.x - Configure rsyslog (7 scripts)
- rsyslog installation and service enablement
- journald to rsyslog forwarding
- Default file permissions
- Logging configuration
- Remote log forwarding
- Disable remote log reception

### 5.1.2.x - Configure journald (10 scripts)
- systemd-journal-remote configuration
- Journal service enablement
- Log compression
- Persistent storage
- Log rotation policies

### 5.1.3-4 - Log File Management (2 scripts)
- logrotate configuration
- Log file permissions

### 5.2.1.x - Configure auditd (4 scripts)
- Audit package installation
- Early boot auditing
- Audit backlog limit
- Auditd service enablement

### 5.2.2.x - Configure auditd Storage (4 scripts)
- Log storage size
- Log retention policies
- System behavior when logs are full
- Low space warnings

### 5.2.3.x - Configure auditd Rules (21 scripts)
Comprehensive audit rules for:
- sudoers changes
- User actions
- Date/time modifications
- Network changes
- Privileged command execution
- File access attempts
- User/group modifications
- DAC permission changes
- File system mounts
- Session initiation
- Login/logout events
- File deletions
- MAC policy changes
- Specific command auditing (chcon, setfacl, chacl, usermod)
- Kernel module operations
- Configuration immutability

### 5.2.4.x - Configure auditd File Access (10 scripts)
- Audit log directory permissions
- Audit log file permissions and ownership
- Audit configuration file permissions and ownership
- Audit tool permissions and ownership

### 5.3.x - Configure AIDE (2 scripts)
- AIDE installation and initialization
- Automated filesystem integrity checks

## Usage

### Prerequisites
- Oracle Linux 7
- Root privileges
- Bash shell
- Sufficient disk space for audit logs

### Running Scripts

1. Extract the archive:
   ```bash
   unzip CIS_Oracle_Linux_7_Section5_Remediation_Scripts.zip
   cd section5_scripts
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Run individual scripts:
   ```bash
   sudo ./5.1.1.1.sh
   ```

4. Run by category:
   ```bash
   # rsyslog configuration
   for script in 5.1.1.*.sh; do sudo ./$script; done
   
   # journald configuration
   for script in 5.1.2.*.sh; do sudo ./$script; done
   
   # auditd installation and configuration
   for script in 5.2.1.*.sh 5.2.2.*.sh; do sudo ./$script; done
   
   # auditd rules (BE CAREFUL - many rules)
   for script in 5.2.3.*.sh; do sudo ./$script; done
   
   # auditd file permissions
   for script in 5.2.4.*.sh; do sudo ./$script; done
   
   # AIDE
   for script in 5.3.*.sh; do sudo ./$script; done
   ```

### Important Notes

1. **Backup your system** before running remediation scripts
2. **Audit rules are extensive** - they will generate large log files
3. **Monitor disk space** carefully after enabling auditing
4. **Test in non-production** environments first
5. Scripts create backups in `/tmp/cis_backup/`
6. Logs are written to `/var/log/cis_remediation.log`

### Script Features

Each script includes:
- Root privilege check
- Backup functionality (one backup per day per file)
- Action execution
- Configuration changes
- Service management
- Comprehensive logging
- Error handling

### Script Types

- **Automated (48 scripts)**: Executes remediation automatically
- **Manual (11 scripts)**: Requires administrator review and decisions

### Backup Location
- `/tmp/cis_backup/` - Contains backups of modified files with timestamps

### Log Files
- `/var/log/cis_remediation.log` - General execution log
- `/var/log/cis_error.log` - Error messages

## Logging Strategy

Choose between rsyslog and journald as your primary logging solution:

### Option 1: rsyslog (Traditional)
```bash
sudo ./5.1.1.1.sh  # Install rsyslog
sudo ./5.1.1.2.sh  # Enable rsyslog (manual decision)
sudo ./5.1.1.4.sh  # Configure permissions
# Configure journald to forward to rsyslog (5.1.1.3)
```

### Option 2: journald (Modern)
```bash
sudo ./5.1.2.2.sh  # Enable journald
sudo ./5.1.2.3.sh  # Enable compression
sudo ./5.1.2.4.sh  # Enable persistent storage
# Disable rsyslog if not needed
```

### Option 3: Hybrid (Both)
```bash
# Enable both and configure journald to forward to rsyslog
# Provides redundancy and compatibility
```

## Auditing Considerations

### Audit Rules (5.2.3.x)
- Generate **extensive** logs
- Can impact system performance
- Require significant disk space
- Monitor `/var/log/audit/` size regularly

### Recommended Order
1. Install and configure auditd (5.2.1.x)
2. Configure storage (5.2.2.x)
3. Add audit rules gradually (5.2.3.x)
4. Configure file permissions (5.2.4.x)
5. Monitor disk usage

### Disk Space Management
```bash
# Check audit log disk usage
du -sh /var/log/audit/

# Monitor in real-time
watch -n 60 'du -sh /var/log/audit/'

# Configure auditd storage (5.2.2.x scripts)
# Set appropriate max_log_file and space_left values
```

## AIDE Configuration

AIDE (Advanced Intrusion Detection Environment) provides file integrity monitoring:

```bash
# Install and initialize AIDE (takes several minutes)
sudo ./5.3.1.sh

# Configure automated checks
sudo ./5.3.2.sh

# Manual AIDE check
sudo aide --check

# Update AIDE database after legitimate changes
sudo aide --update
sudo mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
```

## Performance Impact

Logging and auditing have performance implications:

### rsyslog/journald
- **Low impact** on system performance
- **Moderate** disk I/O
- **High** disk space consumption

### auditd
- **Moderate to High** performance impact
- **High** disk I/O
- **Very High** disk space consumption
- More rules = more impact

### AIDE
- **High** CPU/disk impact during scans
- **Low** impact when not running
- Schedule during off-peak hours

## Troubleshooting

### Audit Rules Not Loading
```bash
# Check audit status
auditctl -l

# Reload rules
augenrules --load

# Check for errors
systemctl status auditd
```

### Disk Space Issues
```bash
# Immediate: Reduce audit log size
vi /etc/audit/auditd.conf
# Adjust: max_log_file, max_log_file_action

# Long-term: Add dedicated partition for /var/log/audit
# (See Section 1 partition scripts)
```

### Log Rotation Issues
```bash
# Check logrotate configuration
cat /etc/logrotate.conf
ls -l /etc/logrotate.d/

# Manual rotation
logrotate -f /etc/logrotate.conf
```

## Support

For issues or questions:
1. Review the CIS Oracle Linux 7 Benchmark documentation
2. Check script comments for specific remediation details
3. Review logs for error messages
4. Monitor disk space continuously
5. Adjust audit rules based on your requirements

## Disclaimer

These scripts are provided as-is for CIS benchmark compliance. Always:
- Test thoroughly in development environments
- Monitor disk space after enabling auditing
- Review and understand audit rules before applying
- Maintain proper backups
- Follow your organization's change management procedures
- Balance security requirements with performance impact

**Extensive auditing can fill disk space quickly and impact performance.**

## Version
- CIS Benchmark: Oracle Linux 7 v4.0.0
- Section: 5 (Logging and Auditing)
- Generated: 2025-10-20

---
Generated with automated bash script creator for CIS compliance
'''

# Create the archive
archive_name = 'section5_scripts/CIS_Oracle_Linux_7_Section5_Remediation_Scripts.zip'

with zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    script_dir = 'section5_scripts'
    scripts = sorted([f for f in os.listdir(script_dir) if f.endswith('.sh')])
    
    for script in scripts:
        script_path = os.path.join(script_dir, script)
        zipf.write(script_path, f'section5_scripts/{script}')
        print(f"  Added: {script}")
    
    # Add the original spreadsheet
    zipf.write('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section5.xlsx', 
               'section5_scripts/CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section5.xlsx')
    print(f"  Added: CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section5.xlsx")
    
    # Add README
    zipf.writestr('section5_scripts/README.md', readme_content)
    print(f"  Added: README.md")
    
    # Add summary CSV
    zipf.write('section5_scripts/Section5_Script_Summary.csv', 
               'section5_scripts/Section5_Script_Summary.csv')
    print(f"  Added: Section5_Script_Summary.csv")

print("=" * 100)

# Get archive info
archive_size = os.path.getsize(archive_name)
print(f"\n✓ Archive created successfully!")
print(f"  File: {archive_name}")
print(f"  Size: {archive_size:,} bytes ({archive_size/1024:.2f} KB)")

print("\n" + "=" * 100)
print("SECTION 5 GENERATION COMPLETE!")
print("=" * 100)
print(f"\nGenerated Files:")
print(f"1. section5_scripts/ folder - Contains all 59 individual scripts")
print(f"2. CIS_Oracle_Linux_7_Section5_Remediation_Scripts.zip - Complete archive")
print(f"3. Section5_Script_Summary.csv - Quick reference list")
