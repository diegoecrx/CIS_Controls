#!/bin/bash

SCRIPT_NAME="5.3.6_ssh_x11warding_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.6 - Ensure SSH X11 forwarding is disabled"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH to disable X11 forwarding..."
    echo ""

    # Check current X11Forwarding setting - FIXED: Use head -1 to get only first match
    CURRENT_SETTING=$(grep -i "^X11Forwarding" "$SSHD_CONFIG" 2>/dev/null | head -1 | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "X11Forwarding is not explicitly configured"
        echo "Adding explicit configuration..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.6 - Disable SSH X11 Forwarding" >> "$SSHD_CONFIG"
        echo "X11Forwarding no" >> "$SSHD_CONFIG"
        
        echo "Added 'X11Forwarding no' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added X11Forwarding no directive"
        
    elif [ "$CURRENT_SETTING" = "no" ]; then
        echo "X11Forwarding is already set to 'no'"
        log_message "INFO" "X11Forwarding already disabled"
        
    else
        echo "X11Forwarding is currently set to: $CURRENT_SETTING"
        echo "Changing to 'no'..."
        
        sed -i 's/^X11Forwarding.*/X11Forwarding no/' "$SSHD_CONFIG"
        
        echo "Changed X11Forwarding to 'no'"
        log_message "SUCCESS" "Changed X11Forwarding to no"
    fi

    # Also comment out any remaining X11Forwarding yes directives to prevent conflicts
    sed -i 's/^X11Forwarding[[:space:]]\+yes/#X11Forwarding yes/' "$SSHD_CONFIG"

    # Verify the configuration - FIXED: Use head -1 and proper conditional logic
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^X11Forwarding" "$SSHD_CONFIG" | grep -v "^#" | head -1 | awk '{print $2}')
    
    if [ -n "$FINAL_SETTING" ] && [ "$FINAL_SETTING" = "no" ]; then
        echo "X11Forwarding is set to: no"
        echo ""
        echo "Status: COMPLIANT"
        echo "SSH X11 forwarding is disabled"
        log_message "SUCCESS" "X11Forwarding is disabled"
    elif [ -z "$FINAL_SETTING" ]; then
        echo "ERROR: X11Forwarding directive not found"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "ERROR" "X11Forwarding directive missing"
    else
        echo "WARNING: X11Forwarding is set to: $FINAL_SETTING"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "WARNING" "X11Forwarding not set to 'no'"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    echo "NOTE: Disabling X11 forwarding prevents:"
    echo "  - Running graphical applications over SSH"
    echo "  - X11 session hijacking attacks"
    echo "  - Clipboard access through X11"
    echo "  - Keylogging via X11 events"
    echo ""
    echo "If your organization requires X11 forwarding for specific users,"
    echo "consider using Match directives to enable it selectively"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
