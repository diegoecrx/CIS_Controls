#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 5.2.4.7.sh
# CIS Control - 5.2.4.7 Ensure audit configuration files belong to group root (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="5.2.4.7.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "5.2.4.7 Ensure audit configuration files belong to group root (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Sets group ownership on audit configuration files."
echo ""

log_message "Starting remediation: Audit config file group"

chgrp root /etc/audit/auditd.conf
chgrp root /etc/audit/audit.rules
find /etc/audit/rules.d -type f -exec chgrp root {} +

echo "✓ Audit config files belong to group root"
ls -l /etc/audit/auditd.conf /etc/audit/rules.d/*.rules

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
