#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 5.2.3.2.sh
# CIS Control - 5.2.3.2 Ensure actions as another user are always logged (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="5.2.3.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "5.2.3.2 Ensure actions as another user are always logged (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Configures audit rules for actions as another user."
echo ""

log_message "Starting remediation: Audit user actions"

RULES_FILE="/etc/audit/rules.d/cis.rules"
backup_file "$RULES_FILE"

cat >> "$RULES_FILE" << 'EOF'
-a always,exit -F arch=b64 -C euid!=uid -F auid!=unset -S execve -k user_emulation
-a always,exit -F arch=b32 -C euid!=uid -F auid!=unset -S execve -k user_emulation
EOF

augenrules --load

echo "✓ User action audit rules configured"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
