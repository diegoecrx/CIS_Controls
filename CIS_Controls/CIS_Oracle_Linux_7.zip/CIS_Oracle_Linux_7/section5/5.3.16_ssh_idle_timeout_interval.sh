#!/bin/bash

SCRIPT_NAME="5.3.16_ssh_idle_timeout_interval.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.16 - Ensure SSH Idle Timeout Interval is configured"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH idle timeout settings..."
    echo ""

    CHANGES_MADE=0

    # Configure ClientAliveInterval
    echo "Setting ClientAliveInterval..."
    
    CURRENT_INTERVAL=$(grep -i "^ClientAliveInterval" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_INTERVAL" ]; then
        echo "ClientAliveInterval not configured - adding directive"
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.16 - SSH Idle Timeout Configuration" >> "$SSHD_CONFIG"
        echo "ClientAliveInterval 300" >> "$SSHD_CONFIG"
        echo "Added ClientAliveInterval 300"
        log_message "SUCCESS" "Added ClientAliveInterval 300"
        CHANGES_MADE=1
    elif [ "$CURRENT_INTERVAL" -le 300 ] && [ "$CURRENT_INTERVAL" -gt 0 ]; then
        echo "ClientAliveInterval is set to $CURRENT_INTERVAL (compliant)"
        log_message "INFO" "ClientAliveInterval already compliant: $CURRENT_INTERVAL"
    else
        echo "ClientAliveInterval is $CURRENT_INTERVAL - changing to 300"
        sed -i "s/^ClientAliveInterval.*/ClientAliveInterval 300/" "$SSHD_CONFIG"
        echo "Changed ClientAliveInterval to 300"
        log_message "SUCCESS" "Changed ClientAliveInterval to 300"
        CHANGES_MADE=1
    fi

    echo ""

    # Configure ClientAliveCountMax
    echo "Setting ClientAliveCountMax..."
    
    CURRENT_COUNTMAX=$(grep -i "^ClientAliveCountMax" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_COUNTMAX" ]; then
        echo "ClientAliveCountMax not configured - adding directive"
        
        # Check if we already added the comment section
        if ! grep -q "# CIS 5.3.16" "$SSHD_CONFIG"; then
            echo "" >> "$SSHD_CONFIG"
            echo "# CIS 5.3.16 - SSH Idle Timeout Configuration" >> "$SSHD_CONFIG"
        fi
        
        echo "ClientAliveCountMax 0" >> "$SSHD_CONFIG"
        echo "Added ClientAliveCountMax 0"
        log_message "SUCCESS" "Added ClientAliveCountMax 0"
        CHANGES_MADE=1
    elif [ "$CURRENT_COUNTMAX" = "0" ]; then
        echo "ClientAliveCountMax is set to 0 (compliant)"
        log_message "INFO" "ClientAliveCountMax already compliant: 0"
    else
        echo "ClientAliveCountMax is $CURRENT_COUNTMAX - changing to 0"
        sed -i "s/^ClientAliveCountMax.*/ClientAliveCountMax 0/" "$SSHD_CONFIG"
        echo "Changed ClientAliveCountMax to 0"
        log_message "SUCCESS" "Changed ClientAliveCountMax to 0"
        CHANGES_MADE=1
    fi

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_INTERVAL=$(grep -i "^ClientAliveInterval" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    FINAL_COUNTMAX=$(grep -i "^ClientAliveCountMax" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    echo "ClientAliveInterval: $FINAL_INTERVAL seconds"
    echo "ClientAliveCountMax: $FINAL_COUNTMAX"
    
    if [ -n "$FINAL_INTERVAL" ] && [ "$FINAL_INTERVAL" -le 300 ] && [ "$FINAL_INTERVAL" -gt 0 ]; then
        INTERVAL_OK=1
    else
        INTERVAL_OK=0
    fi
    
    if [ "$FINAL_COUNTMAX" = "0" ]; then
        COUNTMAX_OK=1
    else
        COUNTMAX_OK=0
    fi

    echo ""
    
    if [ $INTERVAL_OK -eq 1 ] && [ $COUNTMAX_OK -eq 1 ]; then
        TIMEOUT_SECONDS=$FINAL_INTERVAL
        echo "Idle timeout configured: ${TIMEOUT_SECONDS} seconds (${TIMEOUT_SECONDS}/60 minutes)"
        echo ""
        echo "Status: COMPLIANT"
        log_message "SUCCESS" "SSH idle timeout configured properly"
    else
        echo "Status: NON-COMPLIANT"
        echo "Configuration verification failed"
        log_message "ERROR" "SSH idle timeout configuration failed"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    if [ $CHANGES_MADE -eq 1 ]; then
        echo ""
        echo "IMPORTANT: Restart SSH service to apply changes"
        echo "Run: systemctl restart sshd"
        echo ""
        echo "WARNING: Ensure you have alternative access before restarting SSH"
    fi
    
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
