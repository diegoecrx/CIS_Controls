#!/bin/bash

SCRIPT_NAME="5.3.4_ssh_access_limited.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.4 - Ensure SSH access is limited"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "IMPORTANT: SSH Access Control Configuration"
    echo "============================================"
    echo ""
    echo "This control requires manual configuration based on your organization's requirements."
    echo ""
    echo "You must configure at least ONE of the following directives:"
    echo "  - AllowUsers: Whitelist specific users who can SSH"
    echo "  - AllowGroups: Whitelist specific groups whose members can SSH"
    echo "  - DenyUsers: Blacklist specific users who cannot SSH"
    echo "  - DenyGroups: Blacklist specific groups whose members cannot SSH"
    echo ""
    echo "RECOMMENDATION: Use AllowUsers or AllowGroups (whitelist approach)"
    echo "This is more secure than denylisting as it explicitly defines allowed access."
    echo ""

    # Check current configuration
    echo "Checking current SSH access control configuration..."
    echo ""

    ALLOW_USERS=$(grep -i "^AllowUsers" "$SSHD_CONFIG" 2>/dev/null)
    ALLOW_GROUPS=$(grep -i "^AllowGroups" "$SSHD_CONFIG" 2>/dev/null)
    DENY_USERS=$(grep -i "^DenyUsers" "$SSHD_CONFIG" 2>/dev/null)
    DENY_GROUPS=$(grep -i "^DenyGroups" "$SSHD_CONFIG" 2>/dev/null)

    if [ -n "$ALLOW_USERS" ]; then
        echo "AllowUsers configured: $ALLOW_USERS"
    fi
    if [ -n "$ALLOW_GROUPS" ]; then
        echo "AllowGroups configured: $ALLOW_GROUPS"
    fi
    if [ -n "$DENY_USERS" ]; then
        echo "DenyUsers configured: $DENY_USERS"
    fi
    if [ -n "$DENY_GROUPS" ]; then
        echo "DenyGroups configured: $DENY_GROUPS"
    fi

    echo ""

    if [ -z "$ALLOW_USERS" ] && [ -z "$ALLOW_GROUPS" ] && [ -z "$DENY_USERS" ] && [ -z "$DENY_GROUPS" ]; then
        echo "WARNING: No SSH access control directives are currently configured"
        echo "This means ALL users with valid credentials can access SSH"
        echo ""
        log_message "WARNING" "No SSH access controls configured"

        echo "Would you like to configure SSH access control now? (yes/no) [no]: "
        read -r CONFIGURE_NOW
        CONFIGURE_NOW=${CONFIGURE_NOW:-no}

        if [ "$CONFIGURE_NOW" = "yes" ] || [ "$CONFIGURE_NOW" = "y" ]; then
            echo ""
            echo "Select access control method:"
            echo "  1) AllowGroups (recommended - whitelist by group)"
            echo "  2) AllowUsers (whitelist by username)"
            echo "  3) Skip configuration (manual setup required)"
            echo ""
            read -p "Enter choice [1-3]: " CHOICE

            case $CHOICE in
                1)
                    echo ""
                    echo "Enter group name(s) to allow SSH access (space-separated):"
                    echo "Example: wheel sshusers"
                    read -r GROUPS
                    
                    if [ -n "$GROUPS" ]; then
                        echo "" >> "$SSHD_CONFIG"
                        echo "# CIS 5.3.4 - Limit SSH access by group" >> "$SSHD_CONFIG"
                        echo "AllowGroups $GROUPS" >> "$SSHD_CONFIG"
                        echo ""
                        echo "Added: AllowGroups $GROUPS"
                        log_message "SUCCESS" "Configured AllowGroups: $GROUPS"
                    fi
                    ;;
                2)
                    echo ""
                    echo "Enter username(s) to allow SSH access (space-separated):"
                    echo "Example: admin root sysadmin"
                    read -r USERS
                    
                    if [ -n "$USERS" ]; then
                        echo "" >> "$SSHD_CONFIG"
                        echo "# CIS 5.3.4 - Limit SSH access by user" >> "$SSHD_CONFIG"
                        echo "AllowUsers $USERS" >> "$SSHD_CONFIG"
                        echo ""
                        echo "Added: AllowUsers $USERS"
                        log_message "SUCCESS" "Configured AllowUsers: $USERS"
                    fi
                    ;;
                3)
                    echo ""
                    echo "Skipping automatic configuration"
                    echo "You must manually edit $SSHD_CONFIG to add access control directives"
                    log_message "INFO" "User chose to skip automatic configuration"
                    ;;
                *)
                    echo "Invalid choice. Skipping configuration."
                    ;;
            esac
        else
            echo "Skipping automatic configuration"
            echo "You must manually configure SSH access controls"
        fi
    else
        echo "SSH access control directives are configured"
        log_message "INFO" "SSH access controls already configured"
    fi

    # Final verification
    echo ""
    echo "Final Configuration:"
    echo "--------------------"

    FINAL_ALLOW_USERS=$(grep -i "^AllowUsers" "$SSHD_CONFIG" 2>/dev/null)
    FINAL_ALLOW_GROUPS=$(grep -i "^AllowGroups" "$SSHD_CONFIG" 2>/dev/null)
    FINAL_DENY_USERS=$(grep -i "^DenyUsers" "$SSHD_CONFIG" 2>/dev/null)
    FINAL_DENY_GROUPS=$(grep -i "^DenyGroups" "$SSHD_CONFIG" 2>/dev/null)

    if [ -z "$FINAL_ALLOW_USERS" ] && [ -z "$FINAL_ALLOW_GROUPS" ] && [ -z "$FINAL_DENY_USERS" ] && [ -z "$FINAL_DENY_GROUPS" ]; then
        echo "Status: NON-COMPLIANT"
        echo "No SSH access control directives configured"
        echo ""
        echo "MANUAL ACTION REQUIRED:"
        echo "Edit $SSHD_CONFIG and add one of:"
        echo "  AllowGroups <group1> <group2>"
        echo "  AllowUsers <user1> <user2>"
        echo "  DenyGroups <group1> <group2>"
        echo "  DenyUsers <user1> <user2>"
        log_message "ERROR" "SSH access controls not configured"
    else
        echo "Status: COMPLIANT"
        echo ""
        if [ -n "$FINAL_ALLOW_USERS" ]; then
            echo "$FINAL_ALLOW_USERS"
        fi
        if [ -n "$FINAL_ALLOW_GROUPS" ]; then
            echo "$FINAL_ALLOW_GROUPS"
        fi
        if [ -n "$FINAL_DENY_USERS" ]; then
            echo "$FINAL_DENY_USERS"
        fi
        if [ -n "$FINAL_DENY_GROUPS" ]; then
            echo "$FINAL_DENY_GROUPS"
        fi
        log_message "SUCCESS" "SSH access controls are configured"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Important warnings
    echo ""
    echo "CRITICAL WARNINGS:"
    echo "=================="
    echo "1. TEST the configuration before disconnecting!"
    echo "2. Ensure YOUR account is included in allowed users/groups"
    echo "3. Keep an active SSH session open while testing"
    echo "4. Have console/out-of-band access available"
    echo ""
    echo "To apply changes, restart SSH: systemctl restart sshd"
    echo ""
    
    log_message "SUCCESS" "Remediation completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
