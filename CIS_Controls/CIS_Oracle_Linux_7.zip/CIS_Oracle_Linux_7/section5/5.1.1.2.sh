#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 5.1.1.2.sh
# CIS Control - 5.1.1.2 Ensure rsyslog service is enabled (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="5.1.1.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Manual Remediation: $SCRIPT_NAME"
echo "5.1.1.2 Ensure rsyslog service is enabled (Manual)"
echo "=============================================="
echo ""
echo "Description:"
echo "Manual check: Ensure rsyslog service is enabled."
echo ""

log_message "Manual remediation: rsyslog service"

echo "Current rsyslog status:"
systemctl is-enabled rsyslog 2>/dev/null || echo "Not enabled"
systemctl is-active rsyslog 2>/dev/null || echo "Not running"
echo ""
echo "To enable rsyslog:"
echo "  systemctl enable rsyslog"
echo "  systemctl start rsyslog"
echo ""
echo "Note: Choose either rsyslog OR journald for primary logging."
echo "✓ Manual review required"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
