#!/bin/bash

SCRIPT_NAME="5.3.19_ssh_pam_enabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.19 - Ensure SSH PAM is enabled"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH to use PAM..."
    echo ""

    # Check current UsePAM setting
    CURRENT_SETTING=$(grep -i "^UsePAM" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "UsePAM is not explicitly configured (default varies by distribution)"
        echo "Adding explicit configuration..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.19 - Enable PAM for SSH" >> "$SSHD_CONFIG"
        echo "UsePAM yes" >> "$SSHD_CONFIG"
        
        echo "Added 'UsePAM yes' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added UsePAM yes directive"
        
    elif [ "$CURRENT_SETTING" = "yes" ]; then
        echo "UsePAM is already set to 'yes'"
        log_message "INFO" "UsePAM already enabled"
        
    else
        echo "UsePAM is currently set to: $CURRENT_SETTING"
        echo "Changing to 'yes'..."
        
        sed -i 's/^UsePAM.*/UsePAM yes/' "$SSHD_CONFIG"
        
        echo "Changed UsePAM to 'yes'"
        log_message "SUCCESS" "Changed UsePAM to yes"
    fi

    # Also comment out any UsePAM no directives to prevent conflicts
    sed -i 's/^UsePAM[[:space:]]\+no/#UsePAM no/' "$SSHD_CONFIG"

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^UsePAM" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ "$FINAL_SETTING" = "yes" ]; then
        echo "UsePAM is set to: yes"
        echo ""
        echo "Status: COMPLIANT"
        echo "SSH is configured to use PAM for authentication"
        log_message "SUCCESS" "UsePAM is enabled"
    else
        echo "WARNING: Could not verify UsePAM setting"
        echo "Current value: $FINAL_SETTING"
        log_message "WARNING" "Could not verify UsePAM setting"
    fi

    # Verify PAM configuration file for sshd exists
    echo ""
    echo "Checking PAM configuration..."
    
    if [ -f "/etc/pam.d/sshd" ]; then
        echo "PAM configuration file exists: /etc/pam.d/sshd"
        log_message "INFO" "PAM sshd configuration file exists"
    else
        echo "WARNING: PAM configuration file not found: /etc/pam.d/sshd"
        echo "PAM may not function correctly for SSH"
        log_message "WARNING" "PAM sshd configuration file missing"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    echo "NOTE: PAM provides authentication controls including:"
    echo "  - Password complexity requirements"
    echo "  - Account lockout mechanisms"
    echo "  - Session limits"
    echo "  - Authentication logging"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
