#!/bin/bash

SCRIPT_NAME="5.3.17_ssh_logingracetime_toe_minute_less.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.17 - Ensure SSH LoginGraceTime is set to one minute or less"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH LoginGraceTime..."
    echo ""

    # Check current LoginGraceTime setting
    CURRENT_SETTING=$(grep -i "^LoginGraceTime" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "LoginGraceTime is not explicitly configured (default: 120s)"
        echo "Adding explicit configuration..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.17 - Set LoginGraceTime to one minute or less" >> "$SSHD_CONFIG"
        echo "LoginGraceTime 60" >> "$SSHD_CONFIG"
        
        echo "Added 'LoginGraceTime 60' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added LoginGraceTime 60"
        
    else
        # Remove any time suffix (s, m, h, d) and convert to seconds
        # LoginGraceTime can be specified as seconds or with suffixes
        VALUE=$CURRENT_SETTING
        
        # Check if value has a suffix
        if [[ "$VALUE" =~ ^[0-9]+[smhd]$ ]]; then
            NUM=${VALUE%?}
            SUFFIX=${VALUE: -1}
            
            case $SUFFIX in
                s) SECONDS=$NUM ;;
                m) SECONDS=$((NUM * 60)) ;;
                h) SECONDS=$((NUM * 3600)) ;;
                d) SECONDS=$((NUM * 86400)) ;;
            esac
        else
            # No suffix, assume seconds
            SECONDS=$VALUE
        fi
        
        echo "Current LoginGraceTime: $CURRENT_SETTING ($SECONDS seconds)"
        
        if [ "$SECONDS" -le 60 ] && [ "$SECONDS" -gt 0 ]; then
            echo "LoginGraceTime is already compliant (60 seconds or less)"
            log_message "INFO" "LoginGraceTime already compliant: $CURRENT_SETTING"
        else
            echo "LoginGraceTime is too high - changing to 60 seconds..."
            sed -i 's/^LoginGraceTime.*/LoginGraceTime 60/' "$SSHD_CONFIG"
            echo "Changed LoginGraceTime to 60"
            log_message "SUCCESS" "Changed LoginGraceTime to 60"
        fi
    fi

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^LoginGraceTime" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ -n "$FINAL_SETTING" ]; then
        echo "LoginGraceTime is set to: $FINAL_SETTING"
        
        # Parse final setting for compliance check
        VALUE=$FINAL_SETTING
        if [[ "$VALUE" =~ ^[0-9]+[smhd]$ ]]; then
            NUM=${VALUE%?}
            SUFFIX=${VALUE: -1}
            case $SUFFIX in
                s) FINAL_SECONDS=$NUM ;;
                m) FINAL_SECONDS=$((NUM * 60)) ;;
                h) FINAL_SECONDS=$((NUM * 3600)) ;;
                d) FINAL_SECONDS=$((NUM * 86400)) ;;
            esac
        else
            FINAL_SECONDS=$VALUE
        fi
        
        if [ "$FINAL_SECONDS" -le 60 ] && [ "$FINAL_SECONDS" -gt 0 ]; then
            echo ""
            echo "Status: COMPLIANT"
            echo "SSH server will disconnect unauthenticated connections after $FINAL_SECONDS seconds"
            log_message "SUCCESS" "LoginGraceTime configured properly"
        else
            echo ""
            echo "Status: NON-COMPLIANT"
            echo "LoginGraceTime is greater than 60 seconds"
            log_message "ERROR" "LoginGraceTime exceeds 60 seconds"
        fi
    else
        echo "WARNING: Could not verify LoginGraceTime setting"
        log_message "WARNING" "Could not verify LoginGraceTime"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
