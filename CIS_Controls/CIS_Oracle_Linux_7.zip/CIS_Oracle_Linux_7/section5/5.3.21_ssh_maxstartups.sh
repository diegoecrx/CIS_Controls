#!/bin/bash

SCRIPT_NAME="5.3.21_ssh_maxstartups.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.21 - Ensure SSH MaxStartups is configured"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    echo "Configuring SSH MaxStartups..."
    echo ""

    # Check current MaxStartups setting
    CURRENT_SETTING=$(grep -i "^MaxStartups" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "MaxStartups is not explicitly configured (default: 10:30:100)"
        echo "Adding recommended configuration (10:30:60)..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.21 - Configure SSH MaxStartups" >> "$SSHD_CONFIG"
        echo "MaxStartups 10:30:60" >> "$SSHD_CONFIG"
        
        echo "Added 'MaxStartups 10:30:60' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added MaxStartups 10:30:60 directive"
        
    else
        echo "MaxStartups is currently set to: $CURRENT_SETTING"
        
        # Check if current setting is compliant
        # Compliant settings should have the third value (max connections) <= 60
        if [[ "$CURRENT_SETTING" =~ ^([0-9]+):([0-9]+):([0-9]+)$ ]]; then
            START=${BASH_REMATCH[1]}
            RATE=${BASH_REMATCH[2]}
            FULL=${BASH_REMATCH[3]}
            
            if [ "$FULL" -le 60 ]; then
                echo "Current setting is compliant (max connections <= 60)"
                log_message "INFO" "MaxStartups already compliant: $CURRENT_SETTING"
            else
                echo "Current setting allows too many connections (max: $FULL)"
                echo "Changing to recommended value (10:30:60)..."
                sed -i 's/^MaxStartups.*/MaxStartups 10:30:60/' "$SSHD_CONFIG"
                echo "Changed MaxStartups to 10:30:60"
                log_message "SUCCESS" "Changed MaxStartups to 10:30:60"
            fi
        else
            echo "Current setting format is non-standard"
            echo "Changing to recommended value (10:30:60)..."
            sed -i 's/^MaxStartups.*/MaxStartups 10:30:60/' "$SSHD_CONFIG"
            echo "Changed MaxStartups to 10:30:60"
            log_message "SUCCESS" "Changed MaxStartups to 10:30:60"
        fi
    fi

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^MaxStartups" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ -n "$FINAL_SETTING" ]; then
        echo "MaxStartups is set to: $FINAL_SETTING"
        
        # Parse and explain the setting
        if [[ "$FINAL_SETTING" =~ ^([0-9]+):([0-9]+):([0-9]+)$ ]]; then
            START=${BASH_REMATCH[1]}
            RATE=${BASH_REMATCH[2]}
            FULL=${BASH_REMATCH[3]}
            
            echo ""
            echo "Configuration details:"
            echo "  - Accept up to $START connections without throttling"
            echo "  - Start dropping connections with $RATE% probability"
            echo "  - Refuse all connections after $FULL concurrent attempts"
            echo ""
            
            if [ "$FULL" -le 60 ]; then
                echo "Status: COMPLIANT"
                echo "SSH connection limits are properly configured"
                log_message "SUCCESS" "MaxStartups configured properly"
            else
                echo "Status: NON-COMPLIANT"
                echo "Maximum connections ($FULL) exceeds recommended limit (60)"
                log_message "WARNING" "MaxStartups max connections too high"
            fi
        else
            echo ""
            echo "Status: NEEDS REVIEW"
            echo "MaxStartups format is non-standard"
            log_message "WARNING" "MaxStartups has non-standard format"
        fi
    else
        echo "MaxStartups is not configured"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "ERROR" "MaxStartups not configured"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
