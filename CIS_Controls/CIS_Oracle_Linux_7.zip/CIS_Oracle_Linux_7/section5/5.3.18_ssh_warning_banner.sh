#!/bin/bash

SCRIPT_NAME="5.3.18_ssh_warning_banner.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"
BANNER_FILE="/etc/issue.net"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.18 - Ensure SSH warning banner is configured"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    # Create or verify banner file exists
    if [ ! -f "$BANNER_FILE" ]; then
        echo "Banner file $BANNER_FILE does not exist - creating..."
        
        cat > "$BANNER_FILE" << 'EOF'
###############################################################################
#                            AUTHORIZED ACCESS ONLY                           #
###############################################################################

This system is for authorized use only. Unauthorized access or use is 
prohibited and may be subject to criminal and/or civil penalties.

All activities on this system are monitored and recorded. By accessing this
system, you consent to such monitoring and recording. Any unauthorized access
or use of this system is prohibited and may be subject to criminal prosecution.

If you are not an authorized user, disconnect now.

###############################################################################
EOF
        
        echo "Created default warning banner in $BANNER_FILE"
        log_message "SUCCESS" "Created default banner file"
    else
        echo "Banner file $BANNER_FILE already exists"
        
        # Display current banner content
        echo ""
        echo "Current banner content:"
        echo "----------------------"
        head -10 "$BANNER_FILE" 2>/dev/null
        if [ $(wc -l < "$BANNER_FILE") -gt 10 ]; then
            echo "... (truncated)"
        fi
        echo ""
    fi

    # Set proper permissions on banner file
    chmod 0644 "$BANNER_FILE" 2>/dev/null
    chown root:root "$BANNER_FILE" 2>/dev/null
    log_message "INFO" "Set permissions on banner file"

    echo "Configuring SSH to use warning banner..."
    echo ""

    # Check current Banner setting
    CURRENT_BANNER=$(grep -i "^Banner" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_BANNER" ]; then
        echo "Banner directive is not configured - adding..."
        
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.18 - Configure SSH warning banner" >> "$SSHD_CONFIG"
        echo "Banner $BANNER_FILE" >> "$SSHD_CONFIG"
        
        echo "Added 'Banner $BANNER_FILE' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added Banner directive"
        
    elif [ "$CURRENT_BANNER" = "$BANNER_FILE" ]; then
        echo "Banner is already configured to use $BANNER_FILE"
        log_message "INFO" "Banner already configured correctly"
        
    else
        echo "Banner is currently set to: $CURRENT_BANNER"
        echo "Changing to $BANNER_FILE..."
        
        sed -i "s|^Banner.*|Banner $BANNER_FILE|" "$SSHD_CONFIG"
        
        echo "Changed Banner to $BANNER_FILE"
        log_message "SUCCESS" "Changed Banner to $BANNER_FILE"
    fi

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_BANNER=$(grep -i "^Banner" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ -n "$FINAL_BANNER" ]; then
        echo "Banner directive: $FINAL_BANNER"
        
        if [ -f "$FINAL_BANNER" ]; then
            echo "Banner file exists: YES"
            BANNER_SIZE=$(stat -c '%s' "$FINAL_BANNER" 2>/dev/null)
            echo "Banner file size: $BANNER_SIZE bytes"
            
            if [ "$BANNER_SIZE" -gt 0 ]; then
                echo ""
                echo "Status: COMPLIANT"
                echo "SSH warning banner is configured"
                log_message "SUCCESS" "Banner configured properly"
            else
                echo ""
                echo "Status: PARTIAL COMPLIANCE"
                echo "Banner file is empty"
                log_message "WARNING" "Banner file is empty"
            fi
        else
            echo "Banner file exists: NO"
            echo ""
            echo "Status: NON-COMPLIANT"
            echo "Banner file does not exist"
            log_message "ERROR" "Banner file does not exist"
        fi
    else
        echo "Banner directive not found"
        echo ""
        echo "Status: NON-COMPLIANT"
        log_message "ERROR" "Banner directive not configured"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    echo "NOTE: You can customize the banner message by editing $BANNER_FILE"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
