#!/bin/bash

SCRIPT_NAME="5.3.12_ssh_permituserenvironment_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSHD_CONFIG="/etc/ssh/sshd_config"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.12 - Ensure SSH PermitUserEnvironment is disabled"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if sshd_config exists
    if [ ! -f "$SSHD_CONFIG" ]; then
        echo "ERROR: $SSHD_CONFIG not found"
        log_message "ERROR" "sshd_config file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$SSHD_CONFIG" "$BACKUP_DIR/sshd_config.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $SSHD_CONFIG"

    # Check current PermitUserEnvironment setting
    echo "Checking current PermitUserEnvironment setting..."
    
    CURRENT_SETTING=$(grep -i "^PermitUserEnvironment" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}')
    
    if [ -z "$CURRENT_SETTING" ]; then
        echo "PermitUserEnvironment is not explicitly configured (default: no)"
        echo "Adding explicit configuration..."
        
        # Add the directive to the configuration file
        echo "" >> "$SSHD_CONFIG"
        echo "# CIS 5.3.12 - Disable PermitUserEnvironment" >> "$SSHD_CONFIG"
        echo "PermitUserEnvironment no" >> "$SSHD_CONFIG"
        
        echo "Added 'PermitUserEnvironment no' to $SSHD_CONFIG"
        log_message "SUCCESS" "Added PermitUserEnvironment no directive"
        
    elif [ "$CURRENT_SETTING" = "no" ]; then
        echo "PermitUserEnvironment is already set to 'no'"
        log_message "INFO" "PermitUserEnvironment already disabled"
        
    else
        echo "PermitUserEnvironment is currently set to: $CURRENT_SETTING"
        echo "Changing to 'no'..."
        
        # Replace the existing directive
        sed -i 's/^PermitUserEnvironment.*/PermitUserEnvironment no/' "$SSHD_CONFIG"
        
        echo "Changed PermitUserEnvironment to 'no'"
        log_message "SUCCESS" "Changed PermitUserEnvironment to no"
    fi

    # Also comment out any other PermitUserEnvironment directives
    sed -i 's/^PermitUserEnvironment[[:space:]]\+yes/#PermitUserEnvironment yes/' "$SSHD_CONFIG"

    # Verify the configuration
    echo ""
    echo "Verification:"
    echo "-------------"
    
    FINAL_SETTING=$(grep -i "^PermitUserEnvironment" "$SSHD_CONFIG" | grep -v "^#" | awk '{print $2}')
    
    if [ "$FINAL_SETTING" = "no" ]; then
        echo "PermitUserEnvironment is set to: no"
        echo ""
        echo "Status: COMPLIANT"
        log_message "SUCCESS" "PermitUserEnvironment is disabled"
    else
        echo "WARNING: Could not verify PermitUserEnvironment setting"
        log_message "WARNING" "Could not verify PermitUserEnvironment setting"
    fi

    # Test SSH configuration for syntax errors
    echo ""
    echo "Testing SSH configuration syntax..."
    if sshd -t 2>/dev/null; then
        echo "SSH configuration syntax is valid"
        log_message "SUCCESS" "SSH configuration syntax valid"
    else
        echo "WARNING: SSH configuration syntax test failed"
        echo "Run 'sshd -t' to see detailed errors"
        log_message "WARNING" "SSH configuration syntax test failed"
    fi

    # Provide restart instructions
    echo ""
    echo "IMPORTANT: Restart SSH service to apply changes"
    echo "Run: systemctl restart sshd"
    echo ""
    echo "WARNING: Ensure you have alternative access before restarting SSH"
    echo ""
    
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
