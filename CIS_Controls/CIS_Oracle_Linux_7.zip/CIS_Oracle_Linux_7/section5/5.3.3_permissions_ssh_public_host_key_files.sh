#!/bin/bash

SCRIPT_NAME="5.3.3_permissions_ssh_public_host_key_files.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
SSH_DIR="/etc/ssh"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 5.3.3 - Ensure permissions on SSH public host key files are configured"
    echo ""

    # Check if SSH server is installed
    if ! rpm -q openssh-server >/dev/null 2>&1; then
        echo "openssh-server package is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "openssh-server not installed - control not applicable"
        return 0
    fi

    echo "openssh-server package is installed"
    echo ""

    # Check if SSH directory exists
    if [ ! -d "$SSH_DIR" ]; then
        echo "ERROR: SSH directory $SSH_DIR not found"
        log_message "ERROR" "SSH directory not found"
        return 1
    fi

    echo "Searching for SSH public host key files..."
    echo ""

    # Find all SSH public host key files
    # Public keys have .pub extension
    PUBLIC_KEYS=$(find "$SSH_DIR" -maxdepth 1 -type f -name 'ssh_host_*_key.pub' 2>/dev/null)

    if [ -z "$PUBLIC_KEYS" ]; then
        echo "No SSH public host key files found in $SSH_DIR"
        echo "This may indicate SSH host keys have not been generated"
        log_message "WARNING" "No SSH public host keys found"
        return 0
    fi

    # Count keys
    KEY_COUNT=$(echo "$PUBLIC_KEYS" | wc -l)
    echo "Found $KEY_COUNT public host key file(s)"
    echo ""

    # Create report of current permissions
    REPORT_FILE="$BACKUP_DIR/ssh_public_keys_permissions.$(date +%Y%m%d_%H%M%S).txt"
    echo "SSH Public Host Key Permissions Report" > "$REPORT_FILE"
    echo "Generated: $(date)" >> "$REPORT_FILE"
    echo "==========================================" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"

    MODIFIED_COUNT=0
    COMPLIANT_COUNT=0
    ERROR_COUNT=0

    # Process each public key file
    while IFS= read -r keyfile; do
        [ -z "$keyfile" ] && continue
        
        echo "Processing: $(basename $keyfile)"
        
        # Get current permissions, owner, and group
        CURRENT_PERMS=$(stat -c '%a' "$keyfile" 2>/dev/null)
        CURRENT_OWNER=$(stat -c '%U' "$keyfile" 2>/dev/null)
        CURRENT_GROUP=$(stat -c '%G' "$keyfile" 2>/dev/null)
        
        # Log to report
        echo "File: $keyfile" >> "$REPORT_FILE"
        echo "  Before - Perms: $CURRENT_PERMS, Owner: $CURRENT_OWNER, Group: $CURRENT_GROUP" >> "$REPORT_FILE"
        
        NEEDS_CHANGE=0
        
        # Check if ownership is correct
        if [ "$CURRENT_OWNER" != "root" ] || [ "$CURRENT_GROUP" != "root" ]; then
            if chown root:root "$keyfile" 2>/dev/null; then
                echo "  Changed ownership to root:root"
                log_message "SUCCESS" "Changed ownership: $keyfile"
                NEEDS_CHANGE=1
            else
                echo "  ERROR: Failed to change ownership"
                log_message "ERROR" "Failed to change ownership: $keyfile"
                ((ERROR_COUNT++))
                continue
            fi
        fi
        
        # Check if permissions are correct (should be 0644)
        if [ "$CURRENT_PERMS" != "644" ]; then
            if chmod 0644 "$keyfile" 2>/dev/null; then
                echo "  Changed permissions to 0644"
                log_message "SUCCESS" "Changed permissions: $keyfile"
                NEEDS_CHANGE=1
            else
                echo "  ERROR: Failed to change permissions"
                log_message "ERROR" "Failed to change permissions: $keyfile"
                ((ERROR_COUNT++))
                continue
            fi
        fi
        
        if [ $NEEDS_CHANGE -eq 1 ]; then
            ((MODIFIED_COUNT++))
        else
            echo "  Already compliant"
            ((COMPLIANT_COUNT++))
        fi
        
        # Get final state for report
        FINAL_PERMS=$(stat -c '%a' "$keyfile" 2>/dev/null)
        FINAL_OWNER=$(stat -c '%U' "$keyfile" 2>/dev/null)
        FINAL_GROUP=$(stat -c '%G' "$keyfile" 2>/dev/null)
        echo "  After  - Perms: $FINAL_PERMS, Owner: $FINAL_OWNER, Group: $FINAL_GROUP" >> "$REPORT_FILE"
        echo "" >> "$REPORT_FILE"
        
        echo ""
        
    done <<< "$PUBLIC_KEYS"

    # Summary
    echo "Summary:"
    echo "--------"
    echo "Total public key files: $KEY_COUNT"
    echo "Files modified: $MODIFIED_COUNT"
    echo "Files already compliant: $COMPLIANT_COUNT"
    if [ $ERROR_COUNT -gt 0 ]; then
        echo "Errors encountered: $ERROR_COUNT"
    fi
    echo ""
    echo "Detailed report saved to: $REPORT_FILE"
    
    # Final verification
    echo ""
    echo "Final verification:"
    echo "------------------"
    
    NON_COMPLIANT=$(find "$SSH_DIR" -maxdepth 1 -type f -name 'ssh_host_*_key.pub' ! -perm 0644 2>/dev/null | wc -l)
    
    if [ $NON_COMPLIANT -eq 0 ]; then
        echo "All SSH public host key files have correct permissions (0644)"
        echo ""
        echo "Status: COMPLIANT"
        log_message "SUCCESS" "All SSH public host keys secured"
    else
        echo "WARNING: $NON_COMPLIANT file(s) still have incorrect permissions"
        echo ""
        echo "Status: PARTIAL COMPLIANCE"
        log_message "WARNING" "$NON_COMPLIANT files with incorrect permissions"
    fi

    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
