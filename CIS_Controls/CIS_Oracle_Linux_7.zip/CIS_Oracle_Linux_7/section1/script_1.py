
import pandas as pd
import os

# Read the Excel file
df = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx', sheet_name='Recommendations')

# Create output directory for scripts
os.makedirs('cis_remediation_scripts', exist_ok=True)

print(f"Processing {len(df)} remediation scripts...")
print("=" * 80)

# Save the dataframe to CSV for easier processing
df.to_csv('remediation_data.csv', index=False)

# Check for Manual vs Automated controls
manual_count = df[df['control_name'].str.contains('Manual', case=False, na=False)].shape[0]
automated_count = df[df['control_name'].str.contains('Automated', case=False, na=False)].shape[0]

print(f"\nManual controls: {manual_count}")
print(f"Automated controls: {automated_count}")
print(f"Total: {len(df)}")

# Display first few remediations with their types
print("\nFirst 10 controls breakdown:")
for idx in range(min(10, len(df))):
    control_type = "Manual" if "Manual" in str(df.iloc[idx]['control_name']) else "Automated"
    print(f"{idx+1}. {df.iloc[idx]['script_name']} - {control_type}")
