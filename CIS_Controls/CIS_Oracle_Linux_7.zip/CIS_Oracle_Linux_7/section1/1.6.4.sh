#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.6.4.sh  
# CIS Control - 1.6.4 Ensure access to /etc/motd is configured (Automated)
###############################################################################

SCRIPT_NAME="1.6.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "1.6.4 Ensure access to /etc/motd is configured (Automated)"
echo "=============================================="
echo ""

log_message "Starting remediation: 1.6.4 Ensure access to /etc/motd is configured (Automated)"


CONFIG_FILE="/etc/motd"
touch "$CONFIG_FILE"
chmod 0644 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions on /etc/motd"
ls -l "$CONFIG_FILE"

log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
