
import pandas as pd
import os

df = pd.read_csv('remediation_data.csv')

# Continue with next batch (indices 49-59: SELinux, banners)
missing_indices = [49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

scripts_created = []

for idx in missing_indices:
    row = df.iloc[idx]
    script_num = row['script_name']
    control_name = row['control_name']
    
    script = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_num}.sh  
# CIS Control - {control_name}
###############################################################################

SCRIPT_NAME="{script_num}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

backup_file() {{
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "{control_name}"
echo "=============================================="
echo ""

log_message "Starting remediation: {control_name}"

'''
    
    # Add specific remediation logic
    if '1.5.1.4' in script_num:
        script += '''
CONFIG_FILE="/etc/selinux/config"
backup_file "$CONFIG_FILE"
sed -i 's/^SELINUX=disabled/SELINUX=enforcing/' "$CONFIG_FILE"
echo "✓ SELinux mode is not disabled"
getenforce
'''
    elif '1.5.1.5' in script_num:
        script += '''
CONFIG_FILE="/etc/selinux/config"
backup_file "$CONFIG_FILE"
sed -i 's/^SELINUX=.*/SELINUX=enforcing/' "$CONFIG_FILE"
setenforce 1
echo "✓ SELinux mode set to enforcing"
getenforce
'''
    elif '1.5.1.6' in script_num:
        script += '''
echo "Checking for unconfined services..."
UNCONFINED=$(ps -eZ | grep unconfined_service_t)
if [ -z "$UNCONFINED" ]; then
    echo "✓ No unconfined services found"
else
    echo "⚠ Found unconfined services:"
    echo "$UNCONFINED"
    echo "Manual review required"
fi
'''
    elif '1.5.1.7' in script_num:
        script += '''
if rpm -q mcstrans > /dev/null 2>&1; then
    systemctl stop mcstrans
    yum remove -y mcstrans
    echo "✓ Removed mcstrans package"
else
    echo "✓ mcstrans is not installed"
fi
'''
    elif '1.5.1.8' in script_num:
        script += '''
if rpm -q setroubleshoot > /dev/null 2>&1; then
    yum remove -y setroubleshoot
    echo "✓ Removed setroubleshoot package"
else
    echo "✓ setroubleshoot is not installed"
fi
'''
    elif '1.6.1' in script_num:  # MOTD
        script += '''
CONFIG_FILE="/etc/motd"
backup_file "$CONFIG_FILE"
cat > "$CONFIG_FILE" << 'EOF'
Authorized users only. All activity may be monitored and reported.
EOF
echo "✓ Configured /etc/motd"
cat "$CONFIG_FILE"
'''
    elif '1.6.2' in script_num:  # issue
        script += '''
CONFIG_FILE="/etc/issue"
backup_file "$CONFIG_FILE"
cat > "$CONFIG_FILE" << 'EOF'
Authorized users only. All activity may be monitored and reported.
EOF
sed -i 's/\\\\v//g; s/\\\\r//g; s/\\\\m//g; s/\\\\s//g' "$CONFIG_FILE"
echo "✓ Configured /etc/issue"
cat "$CONFIG_FILE"
'''
    elif '1.6.3' in script_num:  # issue.net
        script += '''
CONFIG_FILE="/etc/issue.net"
backup_file "$CONFIG_FILE"
cat > "$CONFIG_FILE" << 'EOF'
Authorized users only. All activity may be monitored and reported.
EOF
sed -i 's/\\\\v//g; s/\\\\r//g; s/\\\\m//g; s/\\\\s//g' "$CONFIG_FILE"
echo "✓ Configured /etc/issue.net"
cat "$CONFIG_FILE"
'''
    elif '1.6.4' in script_num:  # motd permissions
        script += '''
CONFIG_FILE="/etc/motd"
touch "$CONFIG_FILE"
chmod 0644 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions on /etc/motd"
ls -l "$CONFIG_FILE"
'''
    elif '1.6.5' in script_num:  # issue permissions
        script += '''
CONFIG_FILE="/etc/issue"
touch "$CONFIG_FILE"
chmod 0644 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions on /etc/issue"
ls -l "$CONFIG_FILE"
'''
    elif '1.6.6' in script_num:  # issue.net permissions
        script += '''
CONFIG_FILE="/etc/issue.net"
touch "$CONFIG_FILE"
chmod 0644 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions on /etc/issue.net"
ls -l "$CONFIG_FILE"
'''
    
    script += '''
log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
'''
    
    filename = f"cis_remediation_scripts/{script_num}.sh"
    with open(filename, 'w') as f:
        f.write(script)
    
    scripts_created.append(script_num)
    print(f"✓ Created: {script_num}.sh")

print(f"\nCreated {len(scripts_created)} scripts in this batch")
print("Moving to final batch (GDM scripts)...")
