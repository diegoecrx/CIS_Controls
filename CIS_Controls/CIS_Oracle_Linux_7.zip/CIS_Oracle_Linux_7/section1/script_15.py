
import pandas as pd
import os

df = pd.read_csv('remediation_data.csv')

# Final batch - GDM scripts (indices 59-69)
missing_indices = [59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69]

scripts_created = []

for idx in missing_indices:
    row = df.iloc[idx]
    script_num = row['script_name']
    control_name = row['control_name']
    
    script = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_num}.sh  
# CIS Control - {control_name}
###############################################################################

SCRIPT_NAME="{script_num}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

backup_file() {{
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "{control_name}"
echo "=============================================="
echo ""

log_message "Starting remediation: {control_name}"

'''
    
    # Add specific GDM remediation logic
    if '1.6.6' in script_num:
        script += '''
CONFIG_FILE="/etc/issue.net"
touch "$CONFIG_FILE"
chmod 0644 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions on /etc/issue.net"
ls -l "$CONFIG_FILE"
'''
    elif '1.7.1' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    systemctl disable gdm
    yum remove -y gdm
    echo "✓ Removed GDM package"
else
    echo "✓ GDM is not installed"
fi
'''
    elif '1.7.2' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/gdm.d
    cat > /etc/dconf/db/gdm.d/01-banner-message << 'EOF'
[org/gnome/login-screen]
banner-message-enable=true
banner-message-text='Authorized users only. All activity may be monitored and reported.'
EOF
    dconf update
    echo "✓ Configured GDM login banner"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.3' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/gdm.d
    cat > /etc/dconf/db/gdm.d/00-login-screen << 'EOF'
[org/gnome/login-screen]
disable-user-list=true
EOF
    dconf update
    echo "✓ Disabled GDM user list"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.4' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d
    cat > /etc/dconf/db/local.d/00-screensaver << 'EOF'
[org/gnome/desktop/session]
idle-delay=uint32 900

[org/gnome/desktop/screensaver]
lock-enabled=true
lock-delay=uint32 5
EOF
    dconf update
    echo "✓ Configured GDM screen lock"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.5' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d/locks
    cat > /etc/dconf/db/local.d/locks/00-screensaver << 'EOF'
/org/gnome/desktop/session/idle-delay
/org/gnome/desktop/screensaver/lock-enabled
/org/gnome/desktop/screensaver/lock-delay
EOF
    dconf update
    echo "✓ Locked GDM screen saver settings"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.6' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d
    cat > /etc/dconf/db/local.d/00-media-automount << 'EOF'
[org/gnome/desktop/media-handling]
automount=false
automount-open=false
EOF
    dconf update
    echo "✓ Disabled GDM automatic mounting"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.7' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d/locks
    cat > /etc/dconf/db/local.d/locks/00-media-automount << 'EOF'
/org/gnome/desktop/media-handling/automount
/org/gnome/desktop/media-handling/automount-open
EOF
    dconf update
    echo "✓ Locked GDM automount settings"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.8' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d
    cat > /etc/dconf/db/local.d/00-media-autorun << 'EOF'
[org/gnome/desktop/media-handling]
autorun-never=true
EOF
    dconf update
    echo "✓ Enabled GDM autorun-never"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.9' in script_num:
        script += '''
if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d/locks
    cat > /etc/dconf/db/local.d/locks/00-media-autorun << 'EOF'
/org/gnome/desktop/media-handling/autorun-never
EOF
    dconf update
    echo "✓ Locked GDM autorun-never setting"
else
    echo "✓ GDM not installed - skipping"
fi
'''
    elif '1.7.10' in script_num:
        script += '''
CONFIG_FILE="/etc/gdm/custom.conf"
if [ -f "$CONFIG_FILE" ]; then
    backup_file "$CONFIG_FILE"
    sed -i '/^Enable=true/d' "$CONFIG_FILE"
    sed -i '/^\\[xdmcp\\]/a Enable=false' "$CONFIG_FILE"
    echo "✓ Disabled XDMCP"
    systemctl restart gdm 2>/dev/null
else
    echo "✓ GDM config not found - likely not installed"
fi
'''
    
    script += '''
log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
'''
    
    filename = f"cis_remediation_scripts/{script_num}.sh"
    with open(filename, 'w') as f:
        f.write(script)
    
    scripts_created.append(script_num)
    print(f"✓ Created: {script_num}.sh")

print(f"\nCreated {len(scripts_created)} scripts in final batch")

# Count total scripts
total_scripts = len(os.listdir('cis_remediation_scripts'))
print(f"\n" + "=" * 80)
print(f"GENERATION COMPLETE!")
print(f"=" * 80)
print(f"Total scripts generated: {total_scripts}")
print(f"Expected: 70")

if total_scripts == 70:
    print("\n✓ ALL 70 SCRIPTS SUCCESSFULLY GENERATED!")
else:
    print(f"\n⚠ Missing {70 - total_scripts} scripts")
