#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.1.2.1.1.sh
# CIS Control - 1.1.2.1.1 Ensure /tmp is a separate partition (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.1.2.1.1.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="1.1.2.1.1 Ensure /tmp is a separate partition (Automated)"
PROFILE_SERVER="Level 1 - Server"
PROFILE_WORKSTATION="Level 1 - Workstation"
PARTITION="/tmp"
DEFAULT_VALUE="Not applicable"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}

# Validation function
validate_remediation() {
    local validation_status=0
    local l_output=""

    log_message "Validating remediation..."

    # Check if partition exists as separate mount point
    if findmnt -n "$PARTITION" > /dev/null 2>&1; then
        l_output="PASSED: $PARTITION is a separate partition"
        echo "  $l_output"
        log_message "$l_output"
        return 0
    else
        l_output="FAILED: $PARTITION is not a separate partition"
        validation_status=1
        echo "  $l_output"
        log_message "$l_output"
        return 1
    fi
}

# Main execution
main() {
    echo ""
    echo ""
    echo ""
    echo "=============================================="
    echo "Automated Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "This control ensures $PARTITION is configured as a separate partition."
    echo "Creating a separate partition helps contain the impact of disk space issues."
    echo ""
    echo "Partition: $PARTITION"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "=============================================="
    echo "MANUAL INTERVENTION REQUIRED"
    echo "=============================================="
    echo ""
    echo "This control requires manual intervention to create a separate partition."
    echo "Creating partitions requires careful planning and cannot be safely automated."
    echo ""
    echo "Recommended steps:"
    echo "1. Review current partition layout: lsblk"
    echo "2. Create a new partition for $PARTITION using fdisk/parted"
    echo "3. Format the partition: mkfs.ext4 /dev/sdXN"
    echo "4. Backup existing data from $PARTITION"
    echo "5. Update /etc/fstab with new partition entry"
    echo "6. Mount the new partition: mount $PARTITION"
    echo "7. Restore data to new partition"
    echo "8. Verify with: findmnt $PARTITION"
    echo ""

    log_message "Manual remediation required for separate partition: $PARTITION"

    # Validate current state
    validate_remediation
    local validation_result=$?

    echo ""

    if [ $validation_result -eq 0 ]; then
        echo "✓ $PARTITION is already configured as a separate partition"
        log_message "Partition already configured correctly"
        exit 0
    else
        echo "✗ $PARTITION is NOT a separate partition - manual configuration required"
        log_error "Manual partition configuration needed"
        exit 1
    fi
}

main
