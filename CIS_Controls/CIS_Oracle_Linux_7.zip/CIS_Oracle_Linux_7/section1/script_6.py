
import pandas as pd

# Read the CSV
df = pd.read_csv('remediation_data.csv')

# Generate script 1.2.1 (GPG keys - Manual)
def generate_manual_script_template(row):
    script_name = row['script_name']
    control_name = row['control_name']
    profile_app = str(row['profile_applicability'])
    remediation = str(row['remediation'])
    default_value = str(row['default_value']) if pd.notna(row['default_value']) else "Not specified"
    
    # Parse profile
    profile_server = "Level 1 - Server"
    profile_workstation = "Level 1 - Workstation"
    
    # Extract key information from control name
    config_file = "N/A"
    if '1.2.1' in script_name:
        config_file = "/etc/yum.repos.d/"
    elif '1.2.2' in script_name or '1.2.3' in script_name:
        config_file = "/etc/yum.conf"
    elif '1.2.4' in script_name:
        config_file = "/etc/yum.repos.d/"
    elif '1.2.5' in script_name:
        config_file = "System packages"
    
    script_content = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_name}.sh
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="{script_name}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="{control_name}"
PROFILE_SERVER="{profile_server}"
PROFILE_WORKSTATION="{profile_workstation}"
CONFIG_FILE="{config_file}"
DEFAULT_VALUE="{default_value}"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

log_error() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}}

# User interaction for manual remediation
user_menu() {{
    echo "=============================================="
    echo "Manual Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "{control_name}"
    echo ""
    echo "Configuration file: $CONFIG_FILE"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "This is a MANUAL control that requires administrative review and decision."
    echo ""
    echo "Please choose an option:"
    echo "1) Show remediation guidance (no execution)"
    echo "2) Show current configuration"
    echo "3) Exit"
    echo ""
    read -p "Enter your choice [1-3]: " choice
    
    case $choice in
        1)
            show_remediation_guidance
            ;;
        2)
            show_current_config
            ;;
        3)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid choice. Exiting..."
            exit 1
            ;;
    esac
}}

# Show remediation guidance
show_remediation_guidance() {{
    echo ""
    echo "=============================================="
    echo "REMEDIATION GUIDANCE"
    echo "=============================================="
    echo ""
'''
    
    # Add specific guidance based on control
    if '1.2.1' in script_name:
        script_content += '''    echo "To configure GPG keys for package verification:"
    echo ""
    echo "1. List current GPG keys:"
    echo "   rpm -q gpg-pubkey --qf '%{name}-%{version}-%{release} --> %{summary}\\n'"
    echo ""
    echo "2. Import official Oracle Linux GPG keys:"
    echo "   rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-oracle"
    echo ""
    echo "3. Verify repository configurations contain gpgkey directive:"
    echo "   grep -r gpgkey /etc/yum.repos.d/"
    echo ""
    echo "4. Ensure each enabled repository has a valid GPG key configured"
    echo ""
'''
    elif '1.2.2' in script_name:
        script_content += '''    echo "To ensure gpgcheck is globally activated:"
    echo ""
    echo "1. Edit /etc/yum.conf and set:"
    echo "   gpgcheck=1"
    echo ""
    echo "2. Verify the setting:"
    echo "   grep gpgcheck /etc/yum.conf"
    echo ""
'''
    elif '1.2.3' in script_name:
        script_content += '''    echo "To ensure repo_gpgcheck is globally activated:"
    echo ""
    echo "1. Edit /etc/yum.conf and add/set:"
    echo "   repo_gpgcheck=1"
    echo ""
    echo "2. Verify the setting:"
    echo "   grep repo_gpgcheck /etc/yum.conf"
    echo ""
    echo "Note: This may cause issues with some repositories."
    echo "Review each repository configuration carefully."
    echo ""
'''
    elif '1.2.4' in script_name:
        script_content += '''    echo "To configure package manager repositories:"
    echo ""
    echo "1. Review current repository configuration:"
    echo "   yum repolist"
    echo ""
    echo "2. Review repository files:"
    echo "   ls -l /etc/yum.repos.d/"
    echo ""
    echo "3. Ensure only approved repositories are enabled"
    echo ""
    echo "4. Disable unauthorized repositories:"
    echo "   yum-config-manager --disable <repo_name>"
    echo ""
    echo "5. Verify final configuration:"
    echo "   yum repolist enabled"
    echo ""
'''
    elif '1.2.5' in script_name:
        script_content += '''    echo "To ensure system is up to date with patches:"
    echo ""
    echo "1. Check for available updates:"
    echo "   yum check-update"
    echo ""
    echo "2. Install all updates:"
    echo "   yum update -y"
    echo ""
    echo "3. Verify system is fully updated:"
    echo "   yum list updates"
    echo ""
    echo "4. Consider installing additional security tools:"
    echo "   - aide (Advanced Intrusion Detection Environment)"
    echo "   - fail2ban"
    echo "   - rkhunter"
    echo ""
'''
    
    script_content += '''    log_message "Displayed remediation guidance"
}}

# Show current configuration
show_current_config() {{
    echo ""
    echo "=============================================="
    echo "CURRENT CONFIGURATION"
    echo "=============================================="
    echo ""
'''
    
    # Add specific current config checks
    if '1.2.1' in script_name:
        script_content += '''    echo "Current GPG keys installed:"
    rpm -q gpg-pubkey --qf '%{name}-%{version}-%{release} --> %{summary}\\n'
    echo ""
    echo "Repository GPG key configurations:"
    grep -r "^gpgkey=" /etc/yum.repos.d/ 2>/dev/null
    echo ""
'''
    elif '1.2.2' in script_name:
        script_content += '''    echo "Current gpgcheck setting in /etc/yum.conf:"
    grep -E "^gpgcheck" /etc/yum.conf 2>/dev/null || echo "Not configured"
    echo ""
    echo "Repository-specific gpgcheck settings:"
    grep -r "^gpgcheck=" /etc/yum.repos.d/ 2>/dev/null
    echo ""
'''
    elif '1.2.3' in script_name:
        script_content += '''    echo "Current repo_gpgcheck setting in /etc/yum.conf:"
    grep -E "^repo_gpgcheck" /etc/yum.conf 2>/dev/null || echo "Not configured"
    echo ""
'''
    elif '1.2.4' in script_name:
        script_content += '''    echo "Enabled repositories:"
    yum repolist enabled
    echo ""
    echo "All repositories:"
    yum repolist all
    echo ""
'''
    elif '1.2.5' in script_name:
        script_content += '''    echo "Checking for available updates..."
    yum check-update
    echo ""
    echo "Installed security packages:"
    rpm -qa | grep -E "(aide|fail2ban|rkhunter|tripwire)" || echo "No additional security packages found"
    echo ""
'''
    
    script_content += '''    log_message "Displayed current configuration"
}}

# Main execution
main() {{
    echo ""
    echo ""
    echo ""
    
    log_message "Starting manual remediation script: $CONTROL_NAME"
    
    user_menu
    
    echo ""
    echo "Script completed."
    log_message "Manual remediation script completed"
}}

main
'''
    
    return script_content

# Generate manual package management scripts (34, 36, 37, 38)
print("Generating manual package management scripts...")
for idx in [34, 36, 37, 38]:
    row = df.iloc[idx]
    script_content = generate_manual_script_template(row)
    filename = f"cis_remediation_scripts/{row['script_name']}.sh"
    with open(filename, 'w') as f:
        f.write(script_content)
    print(f"✓ Generated: {row['script_name']}.sh (Manual)")

print("\nManual scripts completed!")
