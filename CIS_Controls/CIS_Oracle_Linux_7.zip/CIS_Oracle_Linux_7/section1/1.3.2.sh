#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.3.2.sh  
# CIS Control - 1.3.2 Ensure permissions on bootloader config are configured (Automated)
###############################################################################

SCRIPT_NAME="1.3.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "1.3.2 Ensure permissions on bootloader config are configured (Automated)"
echo "=============================================="
echo ""

log_message "Starting remediation: 1.3.2 Ensure permissions on bootloader config are configured (Automated)"

# Specific remediation logic based on control

CONFIG_FILE="/boot/grub2/grub.cfg"
backup_file "$CONFIG_FILE"
chmod 0600 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions 0600 and ownership root:root on $CONFIG_FILE"
ls -l "$CONFIG_FILE"

log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
