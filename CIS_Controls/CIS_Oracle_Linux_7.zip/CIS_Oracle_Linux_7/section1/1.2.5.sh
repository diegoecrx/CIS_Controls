#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.2.5.sh
# CIS Control - 1.2.5 Ensure updates, patches, and additional security software are installed (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.2.5.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="1.2.5 Ensure updates, patches, and additional security software are installed (Manual)"
PROFILE_SERVER="Level 1 - Server"
PROFILE_WORKSTATION="Level 1 - Workstation"
CONFIG_FILE="System packages"
DEFAULT_VALUE="Not specified"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}

# User interaction for manual remediation
user_menu() {
    echo "=============================================="
    echo "Manual Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "1.2.5 Ensure updates, patches, and additional security software are installed (Manual)"
    echo ""
    echo "Configuration file: $CONFIG_FILE"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "This is a MANUAL control that requires administrative review and decision."
    echo ""
    echo "Please choose an option:"
    echo "1) Show remediation guidance (no execution)"
    echo "2) Show current configuration"
    echo "3) Exit"
    echo ""
    read -p "Enter your choice [1-3]: " choice

    case $choice in
        1)
            show_remediation_guidance
            ;;
        2)
            show_current_config
            ;;
        3)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid choice. Exiting..."
            exit 1
            ;;
    esac
}

# Show remediation guidance
show_remediation_guidance() {
    echo ""
    echo "=============================================="
    echo "REMEDIATION GUIDANCE"
    echo "=============================================="
    echo ""
    echo "To ensure system is up to date with patches:"
    echo ""
    echo "1. Check for available updates:"
    echo "   yum check-update"
    echo ""
    echo "2. Install all updates:"
    echo "   yum update -y"
    echo ""
    echo "3. Verify system is fully updated:"
    echo "   yum list updates"
    echo ""
    echo "4. Consider installing additional security tools:"
    echo "   - aide (Advanced Intrusion Detection Environment)"
    echo "   - fail2ban"
    echo "   - rkhunter"
    echo ""
    log_message "Displayed remediation guidance"
}}

# Show current configuration
show_current_config() {{
    echo ""
    echo "=============================================="
    echo "CURRENT CONFIGURATION"
    echo "=============================================="
    echo ""
    echo "Checking for available updates..."
    yum check-update
    echo ""
    echo "Installed security packages:"
    rpm -qa | grep -E "(aide|fail2ban|rkhunter|tripwire)" || echo "No additional security packages found"
    echo ""
    log_message "Displayed current configuration"
}}

# Main execution
main() {{
    echo ""
    echo ""
    echo ""

    log_message "Starting manual remediation script: $CONTROL_NAME"

    user_menu

    echo ""
    echo "Script completed."
    log_message "Manual remediation script completed"
}}

main
