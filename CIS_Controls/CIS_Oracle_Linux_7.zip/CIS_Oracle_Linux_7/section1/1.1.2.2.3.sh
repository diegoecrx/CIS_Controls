#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.1.2.2.3.sh
# CIS Control - 1.1.2.2.3 Ensure nosuid option set on /dev/shm partition (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.1.2.2.3.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="1.1.2.2.3 Ensure nosuid option set on /dev/shm partition (Automated)"
PROFILE_SERVER="Level 1 - Server"
PROFILE_WORKSTATION="Level 1 - Workstation"
CONFIG_FILE="/etc/fstab"
PARTITION="/dev/shm"
MOUNT_OPTION="nosuid"
DEFAULT_VALUE="Not applicable"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}

# Backup function
backup_file() {
    local file_to_backup="$1"
    if [ -f "$file_to_backup" ]; then
        local backup_name="$(basename "$file_to_backup")_$(date +%Y%m%d)"
        local backup_path="$BACKUP_DIR/$backup_name"

        if [ -f "$backup_path" ]; then
            log_message "Backup already exists: $backup_path"
            return 0
        fi

        cp -p "$file_to_backup" "$backup_path"
        if [ $? -eq 0 ]; then
            log_message "Backup created: $backup_path"
            return 0
        else
            log_error "Failed to create backup: $backup_path"
            return 1
        fi
    fi
    return 0
}

# Validation function
validate_remediation() {
    local validation_status=0
    local l_output=""

    log_message "Validating remediation..."

    # Check if partition exists
    if ! findmnt -n "$PARTITION" > /dev/null 2>&1; then
        l_output="WARNING: $PARTITION is not mounted as a separate partition"
        echo "  $l_output"
        log_message "$l_output"
        return 2
    fi

    # Check if mount option is set
    if findmnt -n "$PARTITION" | grep -q "$MOUNT_OPTION"; then
        l_output="PASSED: $MOUNT_OPTION option is set on $PARTITION"
    else
        l_output="FAILED: $MOUNT_OPTION option is NOT set on $PARTITION"
        validation_status=1
    fi

    echo "  $l_output"
    log_message "$l_output"

    # Check /etc/fstab
    if grep -E "^[^#].*\\s+$PARTITION\\s+" "$CONFIG_FILE" | grep -q "$MOUNT_OPTION"; then
        l_output="PASSED: $MOUNT_OPTION is configured in /etc/fstab for $PARTITION"
    else
        l_output="WARNING: $MOUNT_OPTION may not persist after reboot (check /etc/fstab)"
    fi

    echo "  $l_output"
    log_message "$l_output"

    if [ $validation_status -eq 0 ]; then
        echo ""
        echo "✓ Validation PASSED: All checks completed successfully"
        log_message "Validation PASSED"
        return 0
    else
        echo ""
        echo "✗ Validation FAILED: Some checks did not pass"
        log_error "Validation FAILED"
        return 1
    fi
}

# Main remediation function
remediate_mount_option() {
    log_message "Starting remediation for $CONTROL_NAME"

    # Check if partition exists
    if ! findmnt -n "$PARTITION" > /dev/null 2>&1; then
        echo "   ✗ ERROR: $PARTITION is not mounted as a separate partition"
        log_error "$PARTITION is not a separate partition"
        echo "   Please create a separate partition for $PARTITION first"
        return 1
    fi

    echo "   - Partition $PARTITION found"

    # Check current mount options
    local current_opts=$(findmnt -n -o OPTIONS "$PARTITION")
    echo "   - Current mount options: $current_opts"

    if echo "$current_opts" | grep -q "$MOUNT_OPTION"; then
        echo "   - Mount option $MOUNT_OPTION is already set on $PARTITION"
        log_message "Mount option $MOUNT_OPTION already configured"
        return 0
    fi

    # Backup /etc/fstab
    backup_file "$CONFIG_FILE"

    # Add mount option to /etc/fstab
    echo "   - Adding $MOUNT_OPTION to /etc/fstab for $PARTITION"

    if grep -E "^[^#].*\\s+$PARTITION\\s+" "$CONFIG_FILE" > /dev/null 2>&1; then
        # Partition entry exists, modify it
        sed -i.bak "/^[^#].*\\s\+$(echo $PARTITION | sed 's/\//\\\//g')\\s\+/s/\\(\\s\+[^\\s]\+\\s\+[^\\s]\+\\s\+\)/\\1$MOUNT_OPTION,/" "$CONFIG_FILE"
        # Clean up duplicate commas
        sed -i "s/,,/,/g" "$CONFIG_FILE"
        sed -i "s/\\s$MOUNT_OPTION,/ $MOUNT_OPTION,/g" "$CONFIG_FILE"
    else
        echo "   ✗ ERROR: No entry found for $PARTITION in /etc/fstab"
        log_error "No fstab entry for $PARTITION"
        return 1
    fi

    # Remount the partition with new options
    echo "   - Remounting $PARTITION with new options"
    mount -o remount,"$MOUNT_OPTION" "$PARTITION" 2>/dev/null

    if [ $? -eq 0 ]; then
        echo "   ✓ Successfully remounted $PARTITION with $MOUNT_OPTION option"
        log_message "Remounted $PARTITION with $MOUNT_OPTION"
    else
        echo "   ✗ Failed to remount $PARTITION - may require system reboot"
        log_error "Failed to remount $PARTITION"
    fi

    echo "   - Remediation complete"
    log_message "Remediation completed"
}

# Main execution
main() {
    echo ""
    echo ""
    echo ""
    echo "=============================================="
    echo "Automated Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "This control ensures the $MOUNT_OPTION option is set on $PARTITION partition."
    echo "The $MOUNT_OPTION option provides additional security by restricting execution/devices/setuid."
    echo ""
    echo "Configuration file: $CONFIG_FILE"
    echo "Partition: $PARTITION"
    echo "Mount option: $MOUNT_OPTION"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "Remediation Details:"
    echo ""

    remediate_mount_option
    local remediation_result=$?

    if [ $remediation_result -ne 0 ]; then
        echo ""
        echo "✗ Remediation encountered errors"
        exit 1
    fi

    echo ""
    echo "Remediation Actions Completed:"
    echo "1) Backed up /etc/fstab"
    echo "2) Added $MOUNT_OPTION option to $PARTITION in /etc/fstab"
    echo "3) Attempted to remount $PARTITION with new options"
    echo ""

    validate_remediation
    local validation_result=$?

    echo ""
    echo ""

    if [ $validation_result -eq 0 ]; then
        log_message "Script completed successfully"
        exit 0
    else
        log_error "Script completed with validation errors"
        exit 1
    fi
}

main
