
import os
import zipfile
import pandas as pd

# Create a comprehensive archive of all scripts
archive_name = 'CIS_Oracle_Linux_7_Remediation_Scripts.zip'

print("Creating downloadable archive...")
print("=" * 80)

with zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    script_dir = 'cis_remediation_scripts'
    scripts = sorted(os.listdir(script_dir))
    
    for script in scripts:
        script_path = os.path.join(script_dir, script)
        zipf.write(script_path, script)
        print(f"  Added: {script}")
    
    # Add the original spreadsheet for reference
    zipf.write('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx', 
               'CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx')
    print(f"  Added: CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx")
    
    # Create a README
    readme_content = '''# CIS Oracle Linux 7 Benchmark Remediation Scripts

## Overview
This archive contains 70 bash remediation scripts for CIS Oracle Linux 7 Benchmark v4.0.0 Section 1.

## Contents
- 70 remediation scripts (1.1.1.1.sh through 1.7.10.sh)
- Original spreadsheet with remediation details

## Script Categories

### 1.1.1.x - Kernel Module Controls (8 scripts)
- Disable unused filesystem kernel modules (cramfs, freevxfs, hfs, hfsplus, jffs2, squashfs, udf, usb-storage)

### 1.1.2.x - Partition Mount Options (26 scripts)
- Configure secure mount options for system partitions (/tmp, /dev/shm, /home, /var, /var/tmp, /var/log, /var/log/audit)

### 1.2.x - Package Management (5 scripts)
- 4 Manual controls (GPG keys, repo configuration, updates)
- 1 Automated control (gpgcheck)

### 1.3.x - Bootloader Configuration (3 scripts)
- Bootloader password protection
- Bootloader permissions
- Single user mode authentication

### 1.4.x - Kernel Parameters (4 scripts)
- ASLR (Address Space Layout Randomization)
- ptrace_scope restrictions
- Core dump controls

### 1.5.1.x - SELinux Configuration (8 scripts)
- SELinux installation and configuration
- SELinux policy and mode settings
- Remove unnecessary SELinux packages

### 1.6.x - Warning Banners (6 scripts)
- Configure MOTD, issue, and issue.net
- Set proper permissions on banner files

### 1.7.x - GNOME Display Manager (10 scripts)
- GDM removal or secure configuration
- Login banner, user list, screen lock
- Automount and autorun controls
- XDMCP disable

## Usage

### Prerequisites
- Oracle Linux 7
- Root privileges
- Bash shell

### Running Scripts

1. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

2. Run individual scripts:
   ```bash
   sudo ./1.1.1.1.sh
   ```

3. Run all scripts (use with caution):
   ```bash
   for script in *.sh; do sudo ./$script; done
   ```

### Important Notes

1. **Always backup** your system before running remediation scripts
2. **Test in a non-production environment** first
3. **Review each script** before execution to understand its actions
4. Some controls are **MANUAL** and require administrator review
5. Scripts create backups in `/tmp/cis_backup/`
6. Logs are written to `/var/log/cis_remediation.log`

### Script Features

Each automated script includes:
- Root privilege check
- Backup functionality (one backup per day per file)
- Action execution
- Validation checks
- Comprehensive logging
- Error handling

### Script Types

- **Automated**: Executes remediation automatically
- **Manual**: Provides guidance and displays current configuration for administrator review

### Backup Location
- `/tmp/cis_backup/` - Contains backups of modified files with timestamps

### Log Files
- `/var/log/cis_remediation.log` - General execution log
- `/var/log/cis_error.log` - Error messages

## Support

For issues or questions:
1. Review the CIS Oracle Linux 7 Benchmark documentation
2. Check script comments for specific remediation details
3. Review logs for error messages

## Disclaimer

These scripts are provided as-is for CIS benchmark compliance. Always:
- Test thoroughly in development environments
- Review and understand each script before execution
- Maintain proper backups
- Follow your organization's change management procedures

## Version
- CIS Benchmark: Oracle Linux 7 v4.0.0
- Section: 1 (Initial Setup)
- Generated: 2025-10-20

---
Generated with automated bash script creator for CIS compliance
'''
    
    zipf.writestr('README.md', readme_content)
    print(f"  Added: README.md")

print("=" * 80)
print(f"\n✓ Archive created successfully: {archive_name}")

# Get archive info
archive_size = os.path.getsize(archive_name)
print(f"  Archive size: {archive_size:,} bytes ({archive_size/1024:.2f} KB)")

# Create a summary CSV
df = pd.read_csv('remediation_data.csv')
summary_data = []

for idx, row in df.iterrows():
    script_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    summary_data.append({
        'Script': f"{row['script_name']}.sh",
        'Control': row['control_name'],
        'Type': script_type,
        'Profile': 'Level 1 - Server & Workstation'
    })

summary_df = pd.DataFrame(summary_data)
summary_df.to_csv('Script_Summary.csv', index=False)
print(f"\n✓ Created Script_Summary.csv with script listing")

print("\n" + "=" * 80)
print("DOWNLOAD READY!")
print("=" * 80)
print(f"\nFiles available for download:")
print(f"1. {archive_name} - Complete archive with all 70 scripts")
print(f"2. Script_Summary.csv - Quick reference list of all scripts")
print("\nAll scripts follow your exact requirements:")
print("  ✓ Root privilege checks")
print("  ✓ Backup before modifications")
print("  ✓ Date-based backup naming (no duplicates)")
print("  ✓ Action execution")
print("  ✓ Validation checks")
print("  ✓ Comprehensive logging")
print("  ✓ Proper headers and structure")
print("  ✓ Manual vs Automated differentiation")
