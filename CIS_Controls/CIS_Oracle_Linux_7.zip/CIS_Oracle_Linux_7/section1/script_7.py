
import pandas as pd

# Read the CSV
df = pd.read_csv('remediation_data.csv')

# Generate 1.2.2 (gpgcheck - Automated)
row = df.iloc[35]

script_content = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.2.2.sh
# CIS Control - 1.2.2 Ensure gpgcheck is globally activated (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.2.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="1.2.2 Ensure gpgcheck is globally activated (Automated)"
PROFILE_SERVER="Level 1 - Server"
PROFILE_WORKSTATION="Level 1 - Workstation"
CONFIG_FILE="/etc/yum.conf"
DEFAULT_VALUE="gpgcheck=1"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

log_error() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}}

# Backup function
backup_file() {{
    local file_to_backup="$1"
    if [ -f "$file_to_backup" ]; then
        local backup_name="$(basename "$file_to_backup")_$(date +%Y%m%d)"
        local backup_path="$BACKUP_DIR/$backup_name"
        
        if [ -f "$backup_path" ]; then
            log_message "Backup already exists: $backup_path"
            return 0
        fi
        
        cp -p "$file_to_backup" "$backup_path"
        if [ $? -eq 0 ]; then
            log_message "Backup created: $backup_path"
            return 0
        else
            log_error "Failed to create backup: $backup_path"
            return 1
        fi
    fi
    return 0
}}

# Validation function
validate_remediation() {{
    local validation_status=0
    local l_output=""
    
    log_message "Validating remediation..."
    
    # Check if gpgcheck is set to 1 in /etc/yum.conf
    if grep -E "^gpgcheck\\s*=\\s*1" "$CONFIG_FILE" > /dev/null 2>&1; then
        l_output="PASSED: gpgcheck is set to 1 in $CONFIG_FILE"
    else
        l_output="FAILED: gpgcheck is not properly configured in $CONFIG_FILE"
        validation_status=1
    fi
    
    echo "  $l_output"
    log_message "$l_output"
    
    if [ $validation_status -eq 0 ]; then
        echo ""
        echo "✓ Validation PASSED: All checks completed successfully"
        log_message "Validation PASSED"
        return 0
    else
        echo ""
        echo "✗ Validation FAILED: Some checks did not pass"
        log_error "Validation FAILED"
        return 1
    fi
}}

# Main remediation function
remediate_gpgcheck() {{
    log_message "Starting remediation for $CONTROL_NAME"
    
    # Backup config file
    backup_file "$CONFIG_FILE"
    
    # Check if gpgcheck exists in config
    if grep -E "^gpgcheck" "$CONFIG_FILE" > /dev/null 2>&1; then
        # Entry exists, update it
        echo "   - Updating existing gpgcheck setting"
        sed -i 's/^gpgcheck\\s*=.*/gpgcheck=1/' "$CONFIG_FILE"
    else
        # Entry doesn't exist, add it
        echo "   - Adding gpgcheck setting to $CONFIG_FILE"
        echo "gpgcheck=1" >> "$CONFIG_FILE"
    fi
    
    echo "   ✓ gpgcheck has been set to 1 in $CONFIG_FILE"
    log_message "gpgcheck configured successfully"
}}

# Main execution
main() {{
    echo ""
    echo ""
    echo ""
    echo "=============================================="
    echo "Automated Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "This control ensures GPG signature checking is enabled globally for all packages."
    echo "This helps ensure that only trusted packages from verified sources are installed."
    echo ""
    echo "Configuration file: $CONFIG_FILE"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "Remediation Details:"
    echo ""
    
    remediate_gpgcheck
    
    echo ""
    echo "Remediation Actions Completed:"
    echo "1) Backed up $CONFIG_FILE"
    echo "2) Set gpgcheck=1 in $CONFIG_FILE"
    echo ""
    
    validate_remediation
    local validation_result=$?
    
    echo ""
    echo ""
    
    if [ $validation_result -eq 0 ]; then
        log_message "Script completed successfully"
        exit 0
    else
        log_error "Script completed with validation errors"
        exit 1
    fi
}}

main
'''

filename = "cis_remediation_scripts/1.2.2.sh"
with open(filename, 'w') as f:
    f.write(script_content)

print(f"✓ Generated: 1.2.2.sh")

# Now generate bootloader, kernel parameter, and other remaining scripts
# Let me create a comprehensive generator for the remaining 30+ scripts

print("\nGenerating remaining scripts (bootloader, kernel, SELinux, banners, GDM)...")
print("This will take a moment...")
