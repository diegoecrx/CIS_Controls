
import pandas as pd

# Read the Excel file
df = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx', sheet_name='Recommendations')

# Display all rows to understand the structure
print(f"Total number of remediations: {len(df)}")
print("\nAll control names:")
print("=" * 80)
for idx, row in df.iterrows():
    print(f"{idx + 1}. {row['script_name']} - {row['control_name']}")
