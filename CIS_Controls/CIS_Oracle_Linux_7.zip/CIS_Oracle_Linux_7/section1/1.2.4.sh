#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.2.4.sh
# CIS Control - 1.2.4 Ensure package manager repositories are configured (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.2.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="1.2.4 Ensure package manager repositories are configured (Manual)"
PROFILE_SERVER="Level 1 - Server"
PROFILE_WORKSTATION="Level 1 - Workstation"
CONFIG_FILE="/etc/yum.repos.d/"
DEFAULT_VALUE="Not specified"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}

# User interaction for manual remediation
user_menu() {
    echo "=============================================="
    echo "Manual Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "1.2.4 Ensure package manager repositories are configured (Manual)"
    echo ""
    echo "Configuration file: $CONFIG_FILE"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "This is a MANUAL control that requires administrative review and decision."
    echo ""
    echo "Please choose an option:"
    echo "1) Show remediation guidance (no execution)"
    echo "2) Show current configuration"
    echo "3) Exit"
    echo ""
    read -p "Enter your choice [1-3]: " choice

    case $choice in
        1)
            show_remediation_guidance
            ;;
        2)
            show_current_config
            ;;
        3)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid choice. Exiting..."
            exit 1
            ;;
    esac
}

# Show remediation guidance
show_remediation_guidance() {
    echo ""
    echo "=============================================="
    echo "REMEDIATION GUIDANCE"
    echo "=============================================="
    echo ""
    echo "To configure package manager repositories:"
    echo ""
    echo "1. Review current repository configuration:"
    echo "   yum repolist"
    echo ""
    echo "2. Review repository files:"
    echo "   ls -l /etc/yum.repos.d/"
    echo ""
    echo "3. Ensure only approved repositories are enabled"
    echo ""
    echo "4. Disable unauthorized repositories:"
    echo "   yum-config-manager --disable <repo_name>"
    echo ""
    echo "5. Verify final configuration:"
    echo "   yum repolist enabled"
    echo ""
    log_message "Displayed remediation guidance"
}}

# Show current configuration
show_current_config() {{
    echo ""
    echo "=============================================="
    echo "CURRENT CONFIGURATION"
    echo "=============================================="
    echo ""
    echo "Enabled repositories:"
    yum repolist enabled
    echo ""
    echo "All repositories:"
    yum repolist all
    echo ""
    log_message "Displayed current configuration"
}}

# Main execution
main() {{
    echo ""
    echo ""
    echo ""

    log_message "Starting manual remediation script: $CONTROL_NAME"

    user_menu

    echo ""
    echo "Script completed."
    log_message "Manual remediation script completed"
}}

main
