
import pandas as pd
import os

# Read the CSV
df = pd.read_csv('remediation_data.csv')

# Create a comprehensive script generator
def create_remaining_scripts():
    scripts_generated = []
    
    # Scripts 1.3.1 - 1.7.10 (indices 39-69)
    for idx in range(39, 70):
        row = df.iloc[idx]
        script_name = row['script_name']
        control_name = row['control_name']
        
        script_content = generate_script_by_control(row)
        
        if script_content:
            filename = f"cis_remediation_scripts/{script_name}.sh"
            with open(filename, 'w') as f:
                f.write(script_content)
            scripts_generated.append(script_name)
            
    return scripts_generated

def generate_script_by_control(row):
    script_name = row['script_name']
    control_name = row['control_name']
    remediation = str(row['remediation'])
    
    # Determine script type and generate accordingly
    if '1.3.1' in script_name:  # Bootloader password
        return generate_bootloader_password_script(row)
    elif '1.3.2' in script_name:  # Bootloader permissions
        return generate_bootloader_permissions_script(row)
    elif '1.3.3' in script_name:  # Single user mode auth
        return generate_single_user_mode_script(row)
    elif '1.4.1' in script_name:  # ASLR
        return generate_aslr_script(row)
    elif '1.4.2' in script_name:  # ptrace_scope
        return generate_ptrace_script(row)
    elif '1.4.3' in script_name:  # core dump backtraces
        return generate_core_backtrace_script(row)
    elif '1.4.4' in script_name:  # core dump storage
        return generate_core_storage_script(row)
    elif '1.5.1.1' in script_name:  # SELinux installed
        return generate_selinux_install_script(row)
    elif '1.5.1.2' in script_name:  # SELinux bootloader
        return generate_selinux_bootloader_script(row)
    elif '1.5.1.3' in script_name:  # SELinux policy
        return generate_selinux_policy_script(row)
    elif '1.5.1.4' in script_name:  # SELinux not disabled
        return generate_selinux_not_disabled_script(row)
    elif '1.5.1.5' in script_name:  # SELinux enforcing
        return generate_selinux_enforcing_script(row)
    elif '1.5.1.6' in script_name:  # No unconfined services
        return generate_selinux_unconfined_script(row)
    elif '1.5.1.7' in script_name:  # mcstrans not installed
        return generate_mcstrans_script(row)
    elif '1.5.1.8' in script_name:  # SETroubleshoot not installed
        return generate_setroubleshoot_script(row)
    elif '1.6.1' in script_name:  # MOTD
        return generate_motd_script(row)
    elif '1.6.2' in script_name:  # issue
        return generate_issue_script(row)
    elif '1.6.3' in script_name:  # issue.net
        return generate_issue_net_script(row)
    elif '1.6.4' in script_name:  # motd permissions
        return generate_file_permissions_script(row, '/etc/motd', '0644')
    elif '1.6.5' in script_name:  # issue permissions
        return generate_file_permissions_script(row, '/etc/issue', '0644')
    elif '1.6.6' in script_name:  # issue.net permissions
        return generate_file_permissions_script(row, '/etc/issue.net', '0644')
    elif '1.7.1' in script_name:  # Remove GDM
        return generate_gdm_remove_script(row)
    elif '1.7.2' in script_name:  # GDM banner
        return generate_gdm_banner_script(row)
    elif '1.7.3' in script_name:  # GDM disable-user-list
        return generate_gdm_disable_user_list_script(row)
    elif '1.7.4' in script_name:  # GDM screen lock
        return generate_gdm_screen_lock_script(row)
    elif '1.7.5' in script_name:  # GDM screen lock override
        return generate_gdm_lock_override_script(row)
    elif '1.7.6' in script_name:  # GDM automount disabled
        return generate_gdm_automount_script(row)
    elif '1.7.7' in script_name:  # GDM automount override
        return generate_gdm_automount_override_script(row)
    elif '1.7.8' in script_name:  # GDM autorun-never
        return generate_gdm_autorun_script(row)
    elif '1.7.9' in script_name:  # GDM autorun override
        return generate_gdm_autorun_override_script(row)
    elif '1.7.10' in script_name:  # XDMCP disabled
        return generate_xdmcp_script(row)
    
    return None

# Helper function to create standard header
def create_script_header(script_name, control_name, profile_server="Level 1 - Server", 
                         profile_workstation="Level 1 - Workstation"):
    return f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_name}.sh
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="{script_name}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

log_error() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}}

# Backup function
backup_file() {{
    local file_to_backup="$1"
    if [ -f "$file_to_backup" ]; then
        local backup_name="$(basename "$file_to_backup")_$(date +%Y%m%d)"
        local backup_path="$BACKUP_DIR/$backup_name"
        
        if [ -f "$backup_path" ]; then
            log_message "Backup already exists: $backup_path"
            return 0
        fi
        
        cp -p "$file_to_backup" "$backup_path"
        if [ $? -eq 0 ]; then
            log_message "Backup created: $backup_path"
            return 0
        else
            log_error "Failed to create backup: $backup_path"
            return 1
        fi
    fi
    return 0
}}
'''

# Start generating remaining scripts - first show progress
print("Starting batch generation of remaining 31 scripts...")
print("=" * 80)

# I'll create a sample of key scripts to demonstrate the pattern
# Let me start with a few complete implementations

generated = []

# Count what we have so far
existing_files = os.listdir('cis_remediation_scripts')
print(f"Currently generated: {len(existing_files)} scripts")
print(f"Remaining to generate: {70 - len(existing_files)} scripts")
