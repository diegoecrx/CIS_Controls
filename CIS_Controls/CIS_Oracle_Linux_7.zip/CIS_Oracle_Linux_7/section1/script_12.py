
import pandas as pd
import os

df = pd.read_csv('remediation_data.csv')

# Get current list of scripts
existing = os.listdir('cis_remediation_scripts')
print(f"Currently have {len(existing)} scripts")

# Find what's missing
needed = []
for idx in range(70):
    script_name = df.iloc[idx]['script_name']
    if f"{script_name}.sh" not in existing:
        needed.append(idx)

print(f"Need to generate {len(needed)} more scripts")
print(f"Missing scripts: {[df.iloc[i]['script_name'] for i in needed]}")
