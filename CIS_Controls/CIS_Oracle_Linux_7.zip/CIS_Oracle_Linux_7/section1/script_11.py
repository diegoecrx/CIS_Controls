
import pandas as pd
import os

df = pd.read_csv('remediation_data.csv')

# Due to the large number of scripts remaining, I'll create them all at once
# using efficient template generation. Let me generate all 30 remaining scripts:

# Complete template library for all script types
def get_base_template(script_num, control_name):
    return f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_num}.sh
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="{script_num}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

log_error() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}}

backup_file() {{
    local file_to_backup="$1"
    if [ -f "$file_to_backup" ]; then
        local backup_name="$(basename "$file_to_backup")_$(date +%Y%m%d)"
        local backup_path="$BACKUP_DIR/$backup_name"
        
        if [ -f "$backup_path" ]; then
            log_message "Backup already exists: $backup_path"
            return 0
        fi
        
        cp -p "$file_to_backup" "$backup_path"
        if [ $? -eq 0 ]; then
            log_message "Backup created: $backup_path"
            return 0
        else
            log_error "Failed to create backup: $backup_path"
            return 1
        fi
    fi
    return 0
}}
'''

# Now let me create ALL remaining scripts in one comprehensive batch
# I'll write them directly to files

# Create list of all remaining scripts needed
remaining_list = []
for idx in range(39, 70):
    row = df.iloc[idx]
    if not os.path.exists(f"cis_remediation_scripts/{row['script_name']}.sh"):
        remaining_list.append((row['script_name'], row['control_name']))

print(f"Found {len(remaining_list)} scripts remaining to generate:")
for script_num, _ in remaining_list:
    print(f"  - {script_num}")

print("\nGenerating all remaining scripts now...")
print("=" * 80)

generated_count = 0

# Generate each remaining script
for script_num, control_name in remaining_list:
    # Create appropriate script based on control number
    script_content = create_complete_script(script_num, control_name, df)
    
    if script_content:
        filename = f"cis_remediation_scripts/{script_num}.sh"
        with open(filename, 'w') as f:
            f.write(script_content)
        generated_count += 1
        print(f"✓ Generated: {script_num}.sh")

print(f"\nSuccessfully generated {generated_count} scripts")
print(f"Total scripts in directory: {len(os.listdir('cis_remediation_scripts'))}")
