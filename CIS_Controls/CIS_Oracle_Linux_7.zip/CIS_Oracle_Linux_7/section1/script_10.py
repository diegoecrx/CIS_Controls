
import pandas as pd
import os

df = pd.read_csv('remediation_data.csv')

# Create a massive batch generation script for all remaining controls
# I'll use templates and parameter substitution for efficiency

scripts_to_generate = {
    '1.3.2': {
        'type': 'file_permissions',
        'file': '/boot/grub2/grub.cfg',
        'perms': '0600',
        'owner': 'root:root',
        'description': 'Ensures bootloader config has restrictive permissions'
    },
    '1.3.3': {
        'type': 'systemd_rescue',
        'description': 'Ensures single user mode requires authentication'
    },
    '1.4.1': {
        'type': 'sysctl',
        'param': 'kernel.randomize_va_space',
        'value': '2',
        'description': 'Enables Address Space Layout Randomization (ASLR)'
    },
    '1.4.2': {
        'type': 'sysctl',
        'param': 'kernel.yama.ptrace_scope',
        'value': '1',
        'description': 'Restricts ptrace scope to prevent debugging attacks'
    },
    '1.4.3': {
        'type': 'coredump_config',
        'param': 'ProcessSizeMax',
        'value': '0',
        'file': '/etc/systemd/coredump.conf',
        'description': 'Disables core dump backtraces'
    },
    '1.4.4': {
        'type': 'coredump_config',
        'param': 'Storage',
        'value': 'none',
        'file': '/etc/systemd/coredump.conf',
        'description': 'Disables core dump storage'
    },
    '1.5.1.1': {
        'type': 'package_install',
        'package': 'libselinux',
        'description': 'Ensures SELinux is installed'
    },
    '1.5.1.2': {
        'type': 'selinux_bootloader',
        'description': 'Ensures SELinux is not disabled in bootloader'
    },
    '1.5.1.3': {
        'type': 'selinux_policy',
        'description': 'Ensures SELinux policy is configured'
    },
    '1.5.1.4': {
        'type': 'selinux_mode',
        'mode': 'not_disabled',
        'description': 'Ensures SELinux mode is not disabled'
    },
    '1.5.1.5': {
        'type': 'selinux_mode',
        'mode': 'enforcing',
        'description': 'Ensures SELinux mode is enforcing'
    },
    '1.5.1.6': {
        'type': 'selinux_unconfined',
        'description': 'Checks for unconfined services'
    },
    '1.5.1.7': {
        'type': 'package_remove',
        'package': 'mcstrans',
        'description': 'Ensures MCS Translation Service is not installed'
    },
    '1.5.1.8': {
        'type': 'package_remove',
        'package': 'setroubleshoot',
        'description': 'Ensures SETroubleshoot is not installed'
    },
    '1.6.1': {
        'type': 'banner_file',
        'file': '/etc/motd',
        'description': 'Configures message of the day'
    },
    '1.6.2': {
        'type': 'banner_file',
        'file': '/etc/issue',
        'description': 'Configures local login warning banner'
    },
    '1.6.3': {
        'type': 'banner_file',
        'file': '/etc/issue.net',
        'description': 'Configures remote login warning banner'
    },
    '1.6.4': {
        'type': 'file_permissions',
        'file': '/etc/motd',
        'perms': '0644',
        'owner': 'root:root',
        'description': 'Sets permissions on /etc/motd'
    },
    '1.6.5': {
        'type': 'file_permissions',
        'file': '/etc/issue',
        'perms': '0644',
        'owner': 'root:root',
        'description': 'Sets permissions on /etc/issue'
    },
    '1.6.6': {
        'type': 'file_permissions',
        'file': '/etc/issue.net',
        'perms': '0644',
        'owner': 'root:root',
        'description': 'Sets permissions on /etc/issue.net'
    },
    '1.7.1': {
        'type': 'package_remove',
        'package': 'gdm',
        'description': 'Removes GNOME Display Manager'
    },
}

# Generate GDM scripts (1.7.2 - 1.7.10)
for i in range(2, 11):
    scripts_to_generate[f'1.7.{i}'] = {
        'type': 'gdm_config',
        'description': f'GDM configuration control 1.7.{i}'
    }

# Count scripts to generate
print(f"Preparing to generate {len(scripts_to_generate)} scripts")
print(f"Scripts already exist: {len(os.listdir('cis_remediation_scripts'))}")
print(f"\nGenerating remaining scripts in batch...")

# I'll now create a universal script template generator
def generate_universal_script(script_num, config):
    row_idx = None
    for idx, row in df.iterrows():
        if row['script_name'] == script_num:
            row_idx = idx
            break
    
    if row_idx is not None:
        row = df.iloc[row_idx]
        control_name = row['control_name']
    else:
        control_name = f"Control {script_num}"
    
    script_type = config.get('type', 'generic')
    
    if script_type == 'file_permissions':
        return generate_file_perms_script(script_num, control_name, config)
    elif script_type == 'sysctl':
        return generate_sysctl_script(script_num, control_name, config)
    elif script_type == 'package_remove':
        return generate_package_remove_script(script_num, control_name, config)
    elif script_type == 'package_install':
        return generate_package_install_script(script_num, control_name, config)
    elif script_type == 'banner_file':
        return generate_banner_script(script_num, control_name, config)
    elif script_type == 'coredump_config':
        return generate_coredump_script(script_num, control_name, config)
    elif script_type == 'selinux_mode':
        return generate_selinux_mode_script(script_num, control_name, config)
    elif script_type == 'selinux_policy':
        return generate_selinux_policy_script(script_num, control_name, config)
    elif script_type == 'selinux_bootloader':
        return generate_selinux_bootloader_script(script_num, control_name, config)
    elif script_type == 'selinux_unconfined':
        return generate_selinux_unconfined_script(script_num, control_name, config)
    elif script_type == 'systemd_rescue':
        return generate_systemd_rescue_script(script_num, control_name, config)
    elif script_type == 'gdm_config':
        return generate_gdm_config_script(script_num, control_name, config)
    
    return None

print("\nStarting script generation process...")
count = 0

# Generate first batch
for script_num in list(scripts_to_generate.keys())[:5]:
    config = scripts_to_generate[script_num]
    print(f"Processing {script_num}...")
    count += 1

print(f"\n{count} scripts queued for generation")
print("\nNow creating complete script templates...")
