#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.7.5.sh  
# CIS Control - 1.7.5 Ensure GDM screen locks cannot be overridden (Automated)
###############################################################################

SCRIPT_NAME="1.7.5.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "1.7.5 Ensure GDM screen locks cannot be overridden (Automated)"
echo "=============================================="
echo ""

log_message "Starting remediation: 1.7.5 Ensure GDM screen locks cannot be overridden (Automated)"


if rpm -q gdm > /dev/null 2>&1; then
    mkdir -p /etc/dconf/db/local.d/locks
    cat > /etc/dconf/db/local.d/locks/00-screensaver << 'EOF'
/org/gnome/desktop/session/idle-delay
/org/gnome/desktop/screensaver/lock-enabled
/org/gnome/desktop/screensaver/lock-delay
EOF
    dconf update
    echo "✓ Locked GDM screen saver settings"
else
    echo "✓ GDM not installed - skipping"
fi

log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
