#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.1.1.6.sh
# CIS Control - 1.1.1.6 Ensure squashfs kernel module is not available (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.1.1.6.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

# Control variables
CONTROL_NAME="1.1.1.6 Ensure squashfs kernel module is not available (Automated)"
PROFILE_SERVER="Level 2 - Server"
PROFILE_WORKSTATION="Level 2 - Workstation"
CONFIG_FILE="/etc/modprobe.d/squashfs.conf"
MODULE_NAME="squashfs"
MODULE_TYPE="fs"
DEFAULT_VALUE="Not applicable"

# Ensure script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Create necessary directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

# Logging function
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}

# Backup function
backup_file() {
    local file_to_backup="$1"
    if [ -f "$file_to_backup" ]; then
        local backup_name="$(basename "$file_to_backup")_$(date +%Y%m%d)"
        local backup_path="$BACKUP_DIR/$backup_name"

        # Check if backup already exists for today
        if [ -f "$backup_path" ]; then
            log_message "Backup already exists: $backup_path"
            return 0
        fi

        cp -p "$file_to_backup" "$backup_path"
        if [ $? -eq 0 ]; then
            log_message "Backup created: $backup_path"
            return 0
        else
            log_error "Failed to create backup: $backup_path"
            return 1
        fi
    fi
    return 0
}

# Validation function - Check if remediation was successful
validate_remediation() {
    local validation_status=0
    local l_output=""

    log_message "Validating remediation..."

    # Check if module is not loaded
    if lsmod | grep -q "^${MODULE_NAME}\\b"; then
        l_output="FAILED: Module $MODULE_NAME is still loaded"
        validation_status=1
    else
        l_output="PASSED: Module $MODULE_NAME is not loaded"
    fi

    echo "  $l_output"
    log_message "$l_output"

    # Check if module is blacklisted
    if modprobe --showconfig | grep -Pq "^\\h*blacklist\\h+${MODULE_NAME}\\b"; then
        l_output="PASSED: Module $MODULE_NAME is blacklisted"
    else
        l_output="FAILED: Module $MODULE_NAME is not blacklisted"
        validation_status=1
    fi

    echo "  $l_output"
    log_message "$l_output"

    # Check if module install is set to /bin/false
    if modprobe --showconfig | grep -Pq "^\\h*install\\h+${MODULE_NAME}\\h+/bin/(false|true)"; then
        l_output="PASSED: Module $MODULE_NAME install is set to /bin/false"
    else
        l_output="WARNING: Module $MODULE_NAME install directive not found (may not be needed)"
    fi

    echo "  $l_output"
    log_message "$l_output"

    if [ $validation_status -eq 0 ]; then
        echo ""
        echo "✓ Validation PASSED: All checks completed successfully"
        log_message "Validation PASSED"
        return 0
    else
        echo ""
        echo "✗ Validation FAILED: Some checks did not pass"
        log_error "Validation FAILED"
        return 1
    fi
}

# Main remediation function
remediate_module() {
    log_message "Starting remediation for $CONTROL_NAME"

    local l_mname="$MODULE_NAME"
    local l_mtype="$MODULE_TYPE"
    local l_mpath="/lib/modules/**/kernel/$l_mtype"
    local l_mpname="$(echo "$l_mname" | tr '-' '_')"
    local l_mndir="$(echo "$l_mname" | tr '-' '/')"
    local module_found=0

    # Backup existing config file if it exists
    if [ -f "$CONFIG_FILE" ]; then
        backup_file "$CONFIG_FILE"
    fi

    # Function to fix loadable module
    module_loadable_fix() {
        local l_loadable="$(modprobe -n -v "$l_mname" 2>/dev/null)"
        local line_count=$(echo "$l_loadable" | wc -l)

        if [ "$line_count" -gt "1" ]; then
            l_loadable="$(echo "$l_loadable" | grep -P "(^\\h*install|\\b$l_mname)\\b")"
        fi

        if ! echo "$l_loadable" | grep -Pq -- '^\\h*install\\s+\\S+\\s+/bin/(true|false)'; then
            echo "   - Setting module: \"$l_mname\" to be not loadable"
            log_message "Setting module $l_mname to be not loadable"
            echo "install $l_mname /bin/false" >> /etc/modprobe.d/"${l_mpname}".conf
        else
            echo "   - Module \"$l_mname\" is already set to not be loadable"
        fi
    }

    # Function to unload loaded module
    module_loaded_fix() {
        if lsmod | grep -q "^${l_mname}\\b"; then
            echo "   - Unloading module \"$l_mname\""
            log_message "Unloading module $l_mname"
            modprobe -r "$l_mname" 2>/dev/null
            if [ $? -eq 0 ]; then
                echo "   - Module \"$l_mname\" unloaded successfully"
            else
                log_error "Failed to unload module $l_mname"
            fi
        else
            echo "   - Module \"$l_mname\" is not currently loaded"
        fi
    }

    # Function to blacklist module
    module_deny_fix() {
        if ! modprobe --showconfig 2>/dev/null | grep -Pq -- "^\\h*blacklist\\h+${l_mpname}\\b"; then
            echo "   - Blacklisting \"$l_mname\""
            log_message "Blacklisting module $l_mname"
            echo "blacklist $l_mname" >> /etc/modprobe.d/"${l_mpname}".conf
        else
            echo "   - Module \"$l_mname\" is already blacklisted"
        fi
    }

    # Check if the module exists on the system
    echo "   - Checking for module \"$l_mname\" in kernel directories..."

    for l_mdir in $l_mpath; do
        if [ -d "$l_mdir/$l_mndir" ] && [ -n "$(ls -A "$l_mdir/$l_mndir" 2>/dev/null)" ]; then
            echo "   - Module: \"$l_mname\" exists in \"$l_mdir\""
            log_message "Module $l_mname found in $l_mdir"
            module_found=1

            echo "   - Checking if module is disabled..."
            module_deny_fix

            if [ "$l_mdir" = "/lib/modules/$(uname -r)/kernel/$l_mtype" ]; then
                module_loadable_fix
                module_loaded_fix
            fi
        fi
    done

    if [ $module_found -eq 0 ]; then
        echo "   - Module: \"$l_mname\" not found in any kernel directory"
        log_message "Module $l_mname not found - no remediation needed"
        # Still create the blacklist for safety
        module_deny_fix
    fi

    echo "   - Remediation of module: \"$l_mname\" complete"
    log_message "Remediation of module $l_mname complete"
}

# Main execution
main() {
    echo ""
    echo ""
    echo ""
    echo "=============================================="
    echo "Automated Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "This control ensures the squashfs kernel module is not available."
    echo "Removing support for unneeded filesystem types reduces the local attack surface."
    echo ""
    echo "Configuration file: $CONFIG_FILE"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "Remediation Details:"
    echo ""

    # Execute remediation
    remediate_module

    echo ""
    echo "Remediation Actions Completed:"
    echo "1) Created/updated blacklist entry for squashfs module"
    echo "2) Set install directive to /bin/false for squashfs module"
    echo "3) Unloaded squashfs module from kernel (if loaded)"
    echo "4) Configuration saved to $CONFIG_FILE"
    echo ""

    # Validate the remediation
    validate_remediation
    local validation_result=$?

    echo ""
    echo ""

    if [ $validation_result -eq 0 ]; then
        log_message "Script completed successfully"
        exit 0
    else
        log_error "Script completed with validation errors"
        exit 1
    fi
}

# Run main function
main
