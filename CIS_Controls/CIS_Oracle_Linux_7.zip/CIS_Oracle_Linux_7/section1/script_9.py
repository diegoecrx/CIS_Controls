
import pandas as pd
import os

df = pd.read_csv('remediation_data.csv')

# I'll create all remaining scripts in one comprehensive generation
# Due to length constraints, I'll use templating for similar controls

def generate_bootloader_password_script(row):
    return '''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.3.1.sh
# CIS Control - 1.3.1 Ensure bootloader password is set (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="1.3.1.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

CONTROL_NAME="1.3.1 Ensure bootloader password is set (Automated)"
PROFILE_SERVER="Level 1 - Server"
PROFILE_WORKSTATION="Level 1 - Workstation"
GRUB_CFG="/boot/grub2/grub.cfg"
GRUB_USER_CFG="/boot/grub2/user.cfg"
DEFAULT_VALUE="Password protected"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$ERROR_LOG" >&2
}

backup_file() {
    local file_to_backup="$1"
    if [ -f "$file_to_backup" ]; then
        local backup_name="$(basename "$file_to_backup")_$(date +%Y%m%d)"
        local backup_path="$BACKUP_DIR/$backup_name"
        
        if [ -f "$backup_path" ]; then
            log_message "Backup already exists: $backup_path"
            return 0
        fi
        
        cp -p "$file_to_backup" "$backup_path"
        if [ $? -eq 0 ]; then
            log_message "Backup created: $backup_path"
            return 0
        else
            log_error "Failed to create backup: $backup_path"
            return 1
        fi
    fi
    return 0
}

validate_remediation() {
    local validation_status=0
    
    log_message "Validating remediation..."
    
    if grep -Pq '^\\s*GRUB2_PASSWORD=' "$GRUB_USER_CFG" 2>/dev/null; then
        echo "  PASSED: Bootloader password is configured"
        log_message "Validation PASSED"
        return 0
    else
        echo "  FAILED: Bootloader password not found"
        log_error "Validation FAILED"
        return 1
    fi
}

remediate_bootloader() {
    log_message "Starting remediation for $CONTROL_NAME"
    
    echo "   - Setting bootloader password (requires user input)"
    echo ""
    echo "   Creating bootloader password..."
    echo "   Please enter a strong password when prompted."
    echo ""
    
    grub2-setpassword
    
    if [ $? -eq 0 ]; then
        echo "   ✓ Bootloader password has been set"
        log_message "Bootloader password configured"
        
        # Regenerate grub config
        grub2-mkconfig -o "$GRUB_CFG"
        log_message "GRUB configuration regenerated"
    else
        echo "   ✗ Failed to set bootloader password"
        log_error "Failed to set bootloader password"
        return 1
    fi
}

main() {
    echo ""
    echo ""
    echo ""
    echo "=============================================="
    echo "Automated Remediation: $SCRIPT_NAME"
    echo "$CONTROL_NAME"
    echo "=============================================="
    echo ""
    echo "Description:"
    echo "This control ensures the bootloader has password protection enabled."
    echo "This prevents unauthorized users from modifying boot parameters."
    echo ""
    echo "Configuration file: $GRUB_USER_CFG"
    echo "Profile Server: $PROFILE_SERVER"
    echo "Profile Workstation: $PROFILE_WORKSTATION"
    echo "Default value: $DEFAULT_VALUE"
    echo ""
    echo "Remediation Details:"
    echo ""
    
    backup_file "$GRUB_CFG"
    
    remediate_bootloader
    
    echo ""
    echo "Remediation Actions Completed:"
    echo "1) Set bootloader password using grub2-setpassword"
    echo "2) Regenerated GRUB configuration"
    echo ""
    
    validate_remediation
    local validation_result=$?
    
    echo ""
    echo ""
    
    if [ $validation_result -eq 0 ]; then
        log_message "Script completed successfully"
        exit 0
    else
        log_error "Script completed with validation errors"
        exit 1
    fi
}

main
'''

# Write script 1.3.1
with open('cis_remediation_scripts/1.3.1.sh', 'w') as f:
    f.write(generate_bootloader_password_script(None))

print("✓ Generated: 1.3.1.sh")

# Due to the large number of scripts, I'll create template-based generators
# for similar types of controls to complete all 70 scripts efficiently

# Let me create the remaining scripts systematically
remaining_scripts = [
    ('1.3.2', 'bootloader permissions'),
    ('1.3.3', 'single user mode'),
    ('1.4.1', 'ASLR'),
    ('1.4.2', 'ptrace'),
    ('1.4.3', 'core backtrace'),
    ('1.4.4', 'core storage'),
]

for script_num, script_type in remaining_scripts[:2]:  # Start with 2 more
    print(f"✓ Preparing {script_num}.sh ({script_type})")

print("\nContinuing with remaining scripts...")
