
import pandas as pd

# Read the CSV
df = pd.read_csv('remediation_data.csv')

# Get details for scripts 34-39 (Package management - mostly manual)
print("Package Management Scripts (1.2.x) - Manual Controls:")
print("=" * 80)
for idx in range(34, 39):
    row = df.iloc[idx]
    is_manual = "Manual" in row['control_name']
    print(f"{row['script_name']} - {row['control_name']}")
    print(f"  Type: {'Manual' if is_manual else 'Automated'}")
    print()
