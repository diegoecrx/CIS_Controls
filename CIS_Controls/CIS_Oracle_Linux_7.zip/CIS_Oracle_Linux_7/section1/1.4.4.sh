#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 1.4.4.sh  
# CIS Control - 1.4.4 Ensure core dump storage is disabled (Automated)
###############################################################################

SCRIPT_NAME="1.4.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "1.4.4 Ensure core dump storage is disabled (Automated)"
echo "=============================================="
echo ""

log_message "Starting remediation: 1.4.4 Ensure core dump storage is disabled (Automated)"

# Specific remediation logic based on control

CONFIG_FILE="/etc/systemd/coredump.conf"
backup_file "$CONFIG_FILE"
sed -i 's/^#Storage=.*/Storage=none/' "$CONFIG_FILE"
echo "Storage=none" >> "$CONFIG_FILE"
systemctl daemon-reload
echo "✓ Core dump storage disabled"

log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
