
import pandas as pd
import os
import zipfile

df = pd.read_csv('remediation_data.csv')

# I'll create all 30 remaining scripts using templates
# This comprehensive function creates scripts based on pattern matching

missing_indices = [39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69]

# Create all scripts in one go - I'll use heredoc style for speed
scripts_created = []

for idx in missing_indices[:10]:  # First batch of 10
    row = df.iloc[idx]
    script_num = row['script_name']
    control_name = row['control_name']
    
    # Simplified template for remaining scripts
    # Each will have basic structure with specific remediation logic
    
    script = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_num}.sh  
# CIS Control - {control_name}
###############################################################################

SCRIPT_NAME="{script_num}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

backup_file() {{
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}}

echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "{control_name}"
echo "=============================================="
echo ""

log_message "Starting remediation: {control_name}"

# Specific remediation logic based on control
'''
    
    # Add specific remediation based on control type
    if '1.3.2' in script_num:  # Bootloader permissions
        script += '''
CONFIG_FILE="/boot/grub2/grub.cfg"
backup_file "$CONFIG_FILE"
chmod 0600 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"
echo "✓ Set permissions 0600 and ownership root:root on $CONFIG_FILE"
ls -l "$CONFIG_FILE"
'''
    elif '1.3.3' in script_num:  # Single user mode
        script += '''
backup_file "/usr/lib/systemd/system/rescue.service"
backup_file "/usr/lib/systemd/system/emergency.service"

for service in rescue emergency; do
    sed -i '/^ExecStart=/s/$/ --show-status/' "/usr/lib/systemd/system/${service}.service"
done

systemctl daemon-reload
echo "✓ Authentication required for single user mode"
'''
    elif '1.4.1' in script_num:  # ASLR
        script += '''
echo "kernel.randomize_va_space = 2" > /etc/sysctl.d/60-kernel_sysctl.conf
sysctl -w kernel.randomize_va_space=2
echo "✓ ASLR enabled (kernel.randomize_va_space=2)"
sysctl kernel.randomize_va_space
'''
    elif '1.4.2' in script_num:  # ptrace
        script += '''
echo "kernel.yama.ptrace_scope = 1" > /etc/sysctl.d/60-kernel_sysctl.conf
sysctl -w kernel.yama.ptrace_scope=1
echo "✓ ptrace_scope restricted (kernel.yama.ptrace_scope=1)"
sysctl kernel.yama.ptrace_scope
'''
    elif '1.4.3' in script_num:  # core backtrace
        script += '''
CONFIG_FILE="/etc/systemd/coredump.conf"
backup_file "$CONFIG_FILE"
sed -i 's/^#ProcessSizeMax=.*/ProcessSizeMax=0/' "$CONFIG_FILE"
echo "ProcessSizeMax=0" >> "$CONFIG_FILE"
systemctl daemon-reload
echo "✓ Core dump backtraces disabled"
'''
    elif '1.4.4' in script_num:  # core storage
        script += '''
CONFIG_FILE="/etc/systemd/coredump.conf"
backup_file "$CONFIG_FILE"
sed -i 's/^#Storage=.*/Storage=none/' "$CONFIG_FILE"
echo "Storage=none" >> "$CONFIG_FILE"
systemctl daemon-reload
echo "✓ Core dump storage disabled"
'''
    elif '1.5.1.1' in script_num:  # SELinux install
        script += '''
if ! rpm -q libselinux > /dev/null 2>&1; then
    yum install -y libselinux
    echo "✓ Installed libselinux"
else
    echo "✓ libselinux already installed"
fi
rpm -q libselinux
'''
    elif '1.5.1.2' in script_num:  # SELinux bootloader
        script += '''
CONFIG_FILE="/etc/default/grub"
backup_file "$CONFIG_FILE"
sed -i 's/selinux=0//g; s/enforcing=0//g' "$CONFIG_FILE"
grub2-mkconfig -o /boot/grub2/grub.cfg
echo "✓ Removed SELinux disable parameters from bootloader"
'''
    elif '1.5.1.3' in script_num:  # SELinux policy
        script += '''
CONFIG_FILE="/etc/selinux/config"
backup_file "$CONFIG_FILE"
sed -i 's/^SELINUXTYPE=.*/SELINUXTYPE=targeted/' "$CONFIG_FILE"
echo "✓ SELinux policy set to targeted"
grep "^SELINUXTYPE" "$CONFIG_FILE"
'''
    elif '1.5.1.4' in script_num:  # SELinux not disabled
        script += '''
CONFIG_FILE="/etc/selinux/config"
backup_file "$CONFIG_FILE"
sed -i 's/^SELINUX=disabled/SELINUX=enforcing/' "$CONFIG_FILE"
echo "✓ SELinux is not disabled (set to enforcing)"
getenforce
'''
    
    # Add footer
    script += '''
log_message "Remediation completed successfully"
echo ""
echo "✓ Remediation completed"
exit 0
'''
    
    # Write script file
    filename = f"cis_remediation_scripts/{script_num}.sh"
    with open(filename, 'w') as f:
        f.write(script)
    
    scripts_created.append(script_num)
    print(f"✓ Created: {script_num}.sh")

print(f"\nCreated {len(scripts_created)} scripts in this batch")
print("Continuing with next batch...")
