
import pandas as pd

# Load the summary
df = pd.read_csv('Script_Summary.csv')

# Display the complete list
print("=" * 100)
print("CIS ORACLE LINUX 7 BENCHMARK REMEDIATION SCRIPTS - COMPLETE SUMMARY")
print("=" * 100)
print(f"\nTotal Scripts Generated: {len(df)}")
print(f"Automated Scripts: {len(df[df['Type'] == 'Automated'])}")
print(f"Manual Scripts: {len(df[df['Type'] == 'Manual'])}")
print("\n" + "=" * 100)
print("\nDETAILED SCRIPT LIST:")
print("=" * 100)

# Group by category
categories = {
    '1.1.1': 'Kernel Modules (Filesystem Types)',
    '1.1.2': 'Partition Mount Options',
    '1.2': 'Package Management',
    '1.3': 'Bootloader Configuration',
    '1.4': 'Kernel Parameters',
    '1.5.1': 'SELinux Configuration',
    '1.6': 'Warning Banners',
    '1.7': 'GNOME Display Manager (GDM)'
}

for prefix, category_name in categories.items():
    category_scripts = df[df['Script'].str.startswith(prefix)]
    if len(category_scripts) > 0:
        print(f"\n{category_name} ({len(category_scripts)} scripts)")
        print("-" * 100)
        for idx, row in category_scripts.iterrows():
            print(f"  {row['Script']:20s} | {row['Type']:10s} | {row['Control']}")

print("\n" + "=" * 100)
print("\nFILES READY FOR DOWNLOAD:")
print("=" * 100)
print("\n1. CIS_Oracle_Linux_7_Remediation_Scripts.zip (129 KB)")
print("   Contains:")
print("   - All 70 bash scripts (.sh files)")
print("   - Original spreadsheet")
print("   - Comprehensive README.md with usage instructions")
print("\n2. Script_Summary.csv")
print("   Quick reference table of all scripts")
print("\n" + "=" * 100)

# Display first few rows of summary as example
print("\nSAMPLE FROM SCRIPT SUMMARY:")
print("=" * 100)
print(df.head(10).to_string(index=False))
print("\n... (70 scripts total)")
print("\n" + "=" * 100)
