
# Show a sample of one of the generated scripts to verify quality
print("SAMPLE SCRIPT VERIFICATION")
print("=" * 100)
print("\nShowing content of script 1.4.1.sh (ASLR configuration):")
print("=" * 100)

with open('cis_remediation_scripts/1.4.1.sh', 'r') as f:
    content = f.read()
    print(content)

print("\n" + "=" * 100)
print("\nAll 70 scripts have been successfully generated and packaged!")
print("They are ready for download in: CIS_Oracle_Linux_7_Remediation_Scripts.zip")
print("=" * 100)
