#!/bin/bash

SCRIPT_NAME="3.5.1.7_firewalld_drops_unnecessary_services_ports.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.1.7 - Ensure firewalld drops unnecessary services and ports"
    echo ""
    
    # Check if firewalld is running
    if ! systemctl is-active firewalld >/dev/null 2>&1; then
        echo "firewalld is not running"
        log_message "ERROR" "firewalld not active"
        echo "Status: NOT APPLICABLE"
        return 1
    fi
    
    echo "Current firewall configuration:"
    echo ""
    
    # Show current services
    echo "Allowed services:"
    firewall-cmd --list-services
    echo ""
    
    # Show current ports
    echo "Allowed ports:"
    firewall-cmd --list-ports
    echo ""
    
    # This is a manual review control - list what's open for review
    echo "Review the above services and ports."
    echo "Remove unnecessary items with:"
    echo "  firewall-cmd --permanent --remove-service=<service>"
    echo "  firewall-cmd --permanent --remove-port=<port>/tcp"
    echo "  firewall-cmd --reload"
    echo ""
    
    log_message "REVIEW" "Manual review required for firewall rules"
    echo "Status: MANUAL REVIEW REQUIRED"
    
    echo ""
    log_message "REVIEW" "Completed - Manual review required"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
