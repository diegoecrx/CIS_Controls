#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 3.4.1.2.sh
# CIS Control - 3.4.1.2 Ensure a single firewall configuration utility is in use (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="3.4.1.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "3.4.1.2 Ensure a single firewall configuration utility is in use (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures only one firewall configuration utility is in use."
echo ""

log_message "Starting remediation: Single firewall utility"

echo "Checking firewall configuration utilities..."
echo ""

FIREWALLD_STATUS=$(systemctl is-enabled firewalld 2>/dev/null || echo "not-found")
NFTABLES_STATUS=$(systemctl is-enabled nftables 2>/dev/null || echo "not-found")
IPTABLES_STATUS=$(systemctl is-enabled iptables 2>/dev/null || echo "not-found")

echo "Current status:"
echo "  firewalld: $FIREWALLD_STATUS"
echo "  nftables: $NFTABLES_STATUS"
echo "  iptables: $IPTABLES_STATUS"
echo ""

# Recommendation: Use firewalld as default
if [ "$FIREWALLD_STATUS" != "enabled" ]; then
    echo "Enabling firewalld as the primary firewall..."
    systemctl unmask firewalld 2>/dev/null
    systemctl enable firewalld
    systemctl start firewalld

    # Disable others
    systemctl stop nftables 2>/dev/null
    systemctl mask nftables 2>/dev/null
    systemctl stop iptables 2>/dev/null
    systemctl mask iptables 2>/dev/null

    echo "✓ firewalld enabled, others disabled"
else
    echo "✓ firewalld is already the active firewall"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
