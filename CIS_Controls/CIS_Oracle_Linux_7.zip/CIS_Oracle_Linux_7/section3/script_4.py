
import os

print("=" * 100)
print("SAMPLE SCRIPT VERIFICATION - 3.3.1.sh (Disable IP forwarding)")
print("=" * 100)

with open('section3_scripts/3.3.1.sh', 'r') as f:
    content = f.read()
    print(content)

print("\n" + "=" * 100)
print("✓ ALL SECTION 3 FILES READY FOR DOWNLOAD")
print("=" * 100)
print("\nFolder: section3_scripts/")
print("\nMain download:")
print("  📦 CIS_Oracle_Linux_7_Section3_Remediation_Scripts.zip (68 KB)")
print("\nIndividual files available:")
print("  - 46 bash scripts (3.1.1.sh through 3.4.4.3.6.sh)")
print("  - Section3_Script_Summary.csv")
print("  - Original spreadsheet")
print("\n⚠️  IMPORTANT: Firewall scripts can lock you out - have console access!")
