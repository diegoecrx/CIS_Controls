#!/bin/bash

SCRIPT_NAME="3.4.2_sctp_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.4.2 - Disable SCTP"
    echo ""
    
    # Create modprobe config to disable SCTP
    cat > /etc/modprobe.d/sctp.conf <<EOF
# Disable SCTP protocol
install sctp /bin/true
EOF
    
    # Unload module if currently loaded
    if lsmod | grep -q "^sctp"; then
        rmmod sctp 2>/dev/null
        echo "SCTP module unloaded"
    else
        echo "SCTP module not currently loaded"
    fi
    
    log_message "SUCCESS" "SCTP protocol disabled"
    echo "SCTP protocol disabled"
    echo "Status: COMPLIANT"
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
