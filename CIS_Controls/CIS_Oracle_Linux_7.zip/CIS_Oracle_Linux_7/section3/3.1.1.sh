#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 3.1.1.sh
# CIS Control - 3.1.1 Ensure IPv6 status is identified (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="3.1.1.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Manual Remediation: $SCRIPT_NAME"
echo "3.1.1 Ensure IPv6 status is identified (Manual)"
echo "=============================================="
echo ""
echo "Description:"
echo "Identifies IPv6 status on the system (Manual review required)."
echo ""

log_message "Manual remediation: Identify IPv6 status"

echo "Current IPv6 configuration status:"
echo ""
echo "1. Check if IPv6 is enabled:"
sysctl net.ipv6.conf.all.disable_ipv6
echo ""
echo "2. Check IPv6 addresses:"
ip -6 addr show
echo ""
echo "3. Check IPv6 routing:"
ip -6 route show
echo ""
echo "4. Determine if IPv6 is needed for your environment"
echo ""
echo "To disable IPv6 if not needed:"
echo "  - Add to /etc/sysctl.d/60-disable_ipv6.conf:"
echo "    net.ipv6.conf.all.disable_ipv6 = 1"
echo "    net.ipv6.conf.default.disable_ipv6 = 1"
echo "  - Run: sysctl -w net.ipv6.conf.all.disable_ipv6=1"
echo ""
echo "✓ Manual review displayed - administrator decision required"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
