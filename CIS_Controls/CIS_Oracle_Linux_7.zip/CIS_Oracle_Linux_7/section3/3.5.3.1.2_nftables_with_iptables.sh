#!/bin/bash

SCRIPT_NAME="3.5.3.1.2_nftables_with_iptables.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.3.1.2 - Ensure nftables is not installed with iptables"
    echo ""
    
    # Check if iptables-services is installed
    if rpm -q iptables-services >/dev/null 2>&1; then
        log_message "INFO" "iptables-services is installed"
        
        # Check if nftables is installed
        if rpm -q nftables >/dev/null 2>&1; then
            log_message "WARNING" "nftables is installed alongside iptables"
            
            # Stop nftables if running
            if systemctl is-active nftables >/dev/null 2>&1; then
                systemctl stop nftables >/dev/null 2>&1
                echo "nftables service stopped"
            fi
            
            # Remove nftables package
            yum remove -y nftables >/dev/null 2>&1
            echo "nftables package removed"
            log_message "SUCCESS" "nftables removed"
        else
            echo "nftables not installed"
            log_message "INFO" "nftables not present"
        fi
        
        # Ensure iptables services are enabled
        if ! systemctl is-enabled iptables >/dev/null 2>&1; then
            systemctl enable iptables >/dev/null 2>&1
            log_message "SUCCESS" "Enabled iptables"
        fi
        
        if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
            systemctl enable ip6tables >/dev/null 2>&1
            log_message "SUCCESS" "Enabled ip6tables"
        fi
        
        echo "iptables-services configured"
        echo "Status: COMPLIANT"
    else
        echo "iptables-services is not installed"
        log_message "WARNING" "iptables-services not installed - this control requires iptables"
        echo "Status: NOT APPLICABLE"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
