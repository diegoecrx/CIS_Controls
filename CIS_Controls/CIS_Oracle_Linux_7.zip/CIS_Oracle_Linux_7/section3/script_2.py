
import pandas as pd
import zipfile
import os

df = pd.read_csv('section3_remediation_data.csv')

# Create summary CSV for Section 3
summary_data = []
for idx, row in df.iterrows():
    script_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    summary_data.append({
        'Script': f"{row['script_name']}.sh",
        'Control': row['control_name'],
        'Type': script_type,
        'Profile': 'Level 1 - Server & Workstation'
    })

summary_df = pd.DataFrame(summary_data)
summary_df.to_csv('section3_scripts/Section3_Script_Summary.csv', index=False)

# Create README for Section 3
readme_content = '''# CIS Oracle Linux 7 Benchmark Remediation Scripts - Section 3

## Overview
This archive contains 46 bash remediation scripts for CIS Oracle Linux 7 Benchmark v4.0.0 Section 3 (Network Configuration).

## Contents
- 46 remediation scripts (3.1.1.sh through 3.4.4.3.6.sh)
- Original spreadsheet with remediation details
- Script summary CSV

## Script Categories

### 3.1.x - Network Configuration (3 scripts)
- IPv6 status identification (Manual)
- Wireless interface disabling
- Bluetooth service disabling

### 3.2.x - Uncommon Network Protocols (4 scripts)
Kernel modules to disable:
- dccp (Datagram Congestion Control Protocol)
- tipc (Transparent Inter-Process Communication)
- rds (Reliable Datagram Sockets)
- sctp (Stream Control Transmission Protocol)

### 3.3.x - Network Parameters (11 scripts)
Host-only kernel parameter settings:
- IP forwarding disabled
- Packet redirect sending disabled
- ICMP responses and redirects configured
- Reverse path filtering enabled
- Source routed packets rejected
- Suspicious packets logged
- TCP SYN cookies enabled
- IPv6 router advertisements disabled

### 3.4.x - Firewall Configuration (28 scripts)

#### 3.4.1.x - General Firewall (2 scripts)
- iptables installation
- Single firewall utility configuration

#### 3.4.2.x - firewalld Configuration (4 scripts)
- firewalld installation and enablement
- Service and port management (Manual)
- Zone assignment (Manual)

#### 3.4.3.x - nftables Configuration (9 scripts)
- nftables installation and setup
- Table and chain creation
- Loopback traffic configuration
- Default deny policy
- Rule persistence

#### 3.4.4.x - iptables Configuration (13 scripts)
- iptables package installation
- IPv4 (iptables) configuration
- IPv6 (ip6tables) configuration
- Loopback, outbound, and open port rules
- Default deny policies
- Service enablement

## Usage

### Prerequisites
- Oracle Linux 7
- Root privileges
- Bash shell
- **Important**: Firewall configuration can lock you out - have console access

### Running Scripts

1. Extract the archive:
   ```bash
   unzip CIS_Oracle_Linux_7_Section3_Remediation_Scripts.zip
   cd section3_scripts
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Run individual scripts:
   ```bash
   sudo ./3.1.2.sh
   ```

4. Run by category:
   ```bash
   # Network protocols
   for script in 3.2.*.sh; do sudo ./$script; done
   
   # Network parameters
   for script in 3.3.*.sh; do sudo ./$script; done
   ```

### CRITICAL WARNINGS

⚠️ **FIREWALL SCRIPTS (3.4.x)**
- Can lock you out of remote systems
- Always have console/physical access before running
- Test in non-production environments first
- Review firewall rules carefully before applying

⚠️ **NETWORK PARAMETER CHANGES (3.3.x)**
- May affect network connectivity
- Can impact routing behavior
- Test thoroughly before production use

⚠️ **PROTOCOL DISABLING (3.2.x)**
- Ensure protocols are not needed by applications
- Some applications require SCTP or other protocols
- Review application requirements first

### Important Notes

1. **Backup your system** before running remediation scripts
2. **Have console access** before running firewall scripts
3. **Test in non-production** environments first
4. **Review Manual controls** - they require administrator decisions
5. Scripts create backups in `/tmp/cis_backup/`
6. Logs are written to `/var/log/cis_remediation.log`

### Script Features

Each script includes:
- Root privilege check
- Backup functionality (one backup per day per file)
- Action execution
- Network/firewall configuration
- Comprehensive logging
- Error handling

### Script Types

- **Automated (39 scripts)**: Executes remediation automatically
- **Manual (7 scripts)**: Requires administrator review and decisions

### Backup Location
- `/tmp/cis_backup/` - Contains backups of modified files with timestamps

### Log Files
- `/var/log/cis_remediation.log` - General execution log
- `/var/log/cis_error.log` - Error messages

## Firewall Configuration Options

Section 3 supports three firewall solutions. Choose ONE:

### Option 1: firewalld (Recommended for most users)
```bash
sudo ./3.4.1.2.sh  # Select firewalld
sudo ./3.4.2.1.sh  # Install firewalld
sudo ./3.4.2.2.sh  # Enable firewalld
# Review and run 3.4.2.3.sh and 3.4.2.4.sh for configuration
```

### Option 2: nftables (For advanced users)
```bash
sudo ./3.4.1.2.sh  # Select nftables
sudo ./3.4.3.1.sh  # Install nftables
# Run 3.4.3.2.sh through 3.4.3.9.sh for configuration
```

### Option 3: iptables (Legacy systems)
```bash
sudo ./3.4.1.2.sh  # Select iptables
sudo ./3.4.4.1.1.sh  # Install iptables
# Run 3.4.4.2.x for IPv4 configuration
# Run 3.4.4.3.x for IPv6 configuration
```

**Do not run scripts for multiple firewall solutions simultaneously!**

## Network Parameter Validation

After running network parameter scripts (3.3.x), verify:
```bash
# Check all network parameters
sysctl -a | grep -E "(ip_forward|send_redirects|accept_redirects|icmp)"

# View applied sysctl configuration
cat /etc/sysctl.d/60-netconfig.conf

# Reload sysctl
sysctl --system
```

## Kernel Module Validation

After disabling kernel modules (3.2.x), verify:
```bash
# Check if modules are loaded
lsmod | grep -E "(dccp|tipc|rds|sctp)"

# Check module configuration
ls -l /etc/modprobe.d/

# Verify blacklist
cat /etc/modprobe.d/*.conf
```

## Support

For issues or questions:
1. Review the CIS Oracle Linux 7 Benchmark documentation
2. Check script comments for specific remediation details
3. Review logs for error messages
4. Ensure you have console access for firewall changes

## Disclaimer

These scripts are provided as-is for CIS benchmark compliance. Always:
- Test thoroughly in development environments
- Have console/physical access for firewall changes
- Review and understand each script before execution
- Maintain proper backups
- Follow your organization's change management procedures
- Verify network connectivity after changes

## Version
- CIS Benchmark: Oracle Linux 7 v4.0.0
- Section: 3 (Network Configuration)
- Generated: 2025-10-20

---
Generated with automated bash script creator for CIS compliance
'''

# Create the archive
archive_name = 'section3_scripts/CIS_Oracle_Linux_7_Section3_Remediation_Scripts.zip'

print("=" * 100)
print("Creating Section 3 downloadable archive...")
print("=" * 100)

with zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    script_dir = 'section3_scripts'
    scripts = sorted([f for f in os.listdir(script_dir) if f.endswith('.sh')])
    
    for script in scripts:
        script_path = os.path.join(script_dir, script)
        zipf.write(script_path, f'section3_scripts/{script}')
        print(f"  Added: {script}")
    
    # Add the original spreadsheet
    zipf.write('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section3.xlsx', 
               'section3_scripts/CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section3.xlsx')
    print(f"  Added: CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section3.xlsx")
    
    # Add README
    zipf.writestr('section3_scripts/README.md', readme_content)
    print(f"  Added: README.md")
    
    # Add summary CSV
    zipf.write('section3_scripts/Section3_Script_Summary.csv', 
               'section3_scripts/Section3_Script_Summary.csv')
    print(f"  Added: Section3_Script_Summary.csv")

print("=" * 100)

# Get archive info
archive_size = os.path.getsize(archive_name)
print(f"\n✓ Archive created successfully!")
print(f"  File: {archive_name}")
print(f"  Size: {archive_size:,} bytes ({archive_size/1024:.2f} KB)")

print("\n" + "=" * 100)
print("SECTION 3 GENERATION COMPLETE!")
print("=" * 100)
print(f"\nGenerated Files:")
print(f"1. section3_scripts/ folder - Contains all 46 individual scripts")
print(f"2. CIS_Oracle_Linux_7_Section3_Remediation_Scripts.zip - Complete archive")
print(f"3. Section3_Script_Summary.csv - Quick reference list")
