
import pandas as pd
import os

# Read the new Section 3 spreadsheet
df_section3 = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section3.xlsx', sheet_name='Recommendations')

# Display overview
print("=" * 100)
print("CIS ORACLE LINUX 7 BENCHMARK - SECTION 3 ANALYSIS")
print("=" * 100)
print(f"\nTotal number of remediations in Section 3: {len(df_section3)}")
print("\nAll controls:")
print("=" * 100)

for idx in range(len(df_section3)):
    row = df_section3.iloc[idx]
    control_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    print(f"{idx + 1}. {row['script_name']:15s} | {control_type:10s} | {row['control_name']}")

# Count manual vs automated
manual_count = df_section3[df_section3['control_name'].str.contains('Manual', case=False, na=False)].shape[0]
automated_count = df_section3[df_section3['control_name'].str.contains('Automated', case=False, na=False)].shape[0]

print("\n" + "=" * 100)
print(f"Manual controls: {manual_count}")
print(f"Automated controls: {automated_count}")
print(f"Total: {len(df_section3)}")

# Save for processing
df_section3.to_csv('section3_remediation_data.csv', index=False)
print("\n✓ Section 3 data loaded and ready for script generation")
