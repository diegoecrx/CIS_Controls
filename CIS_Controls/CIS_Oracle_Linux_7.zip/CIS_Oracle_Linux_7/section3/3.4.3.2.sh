#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 3.4.3.2.sh
# CIS Control - 3.4.3.2 Ensure iptables are flushed with nftables (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="3.4.3.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Manual Remediation: $SCRIPT_NAME"
echo "3.4.3.2 Ensure iptables are flushed with nftables (Manual)"
echo "=============================================="
echo ""
echo "Description:"
echo "Manual action: Flush iptables before using nftables."
echo ""

log_message "Manual remediation: Flush iptables for nftables"

echo "Current iptables rules:"
iptables -L -v -n
echo ""
echo "Manual actions required if switching to nftables:"
echo "1. Backup current iptables rules:"
echo "   iptables-save > /root/iptables.backup"
echo "2. Flush iptables:"
echo "   iptables -F"
echo "   iptables -X"
echo "3. Stop iptables service:"
echo "   systemctl stop iptables"
echo "   systemctl mask iptables"
echo "4. Enable nftables:"
echo "   systemctl enable nftables"
echo "   systemctl start nftables"
echo ""
echo "✓ Manual instructions displayed"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
