#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 3.3.4.sh
# CIS Control - 3.3.4 Ensure broadcast icmp requests are ignored (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="3.3.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "3.3.4 Ensure broadcast icmp requests are ignored (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Enables ignoring broadcast ICMP requests."
echo ""

log_message "Starting remediation: Ignore broadcast ICMP"

SYSCTL_FILE="/etc/sysctl.d/60-netconfig.conf"
backup_file "$SYSCTL_FILE"

echo "net.ipv4.icmp_echo_ignore_broadcasts = 1" >> "$SYSCTL_FILE"
sysctl -w net.ipv4.icmp_echo_ignore_broadcasts=1
sysctl -w net.ipv4.route.flush=1

echo "✓ Broadcast ICMP requests ignored"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
