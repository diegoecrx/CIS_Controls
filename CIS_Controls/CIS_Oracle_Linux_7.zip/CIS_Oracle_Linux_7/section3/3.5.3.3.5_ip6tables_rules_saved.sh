#!/bin/bash

SCRIPT_NAME="3.5.3.3.5_ip6tables_rules_saved.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 3.5.3.3.5 - Ensure ip6tables rules are saved"
    echo ""

    # Check if iptables-services is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "iptables-services is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "iptables-services not installed - control not applicable"
        return 0
    fi

    # ip6tables configuration file
    IP6TABLES_RULES="/etc/sysconfig/ip6tables"

    # Check if the rules file exists
    if [ ! -f "$IP6TABLES_RULES" ]; then
        echo "File $IP6TABLES_RULES does not exist - creating default rules..."
        
        # Save current ip6tables rules
        if ip6tables-save > "$IP6TABLES_RULES" 2>/dev/null; then
            echo "ip6tables rules saved to $IP6TABLES_RULES"
            log_message "SUCCESS" "ip6tables rules saved to $IP6TABLES_RULES"
        else
            echo "Failed to save ip6tables rules"
            log_message "ERROR" "Failed to save ip6tables rules"
            return 1
        fi
    else
        echo "File $IP6TABLES_RULES already exists"
        
        # Check if the file contains rules
        if [ -s "$IP6TABLES_RULES" ]; then
            echo "File contains existing rules"
            log_message "INFO" "ip6tables rules file exists and contains rules"
        else
            echo "File exists but is empty - saving current rules..."
            if ip6tables-save > "$IP6TABLES_RULES" 2>/dev/null; then
                echo "ip6tables rules saved to $IP6TABLES_RULES"
                log_message "SUCCESS" "ip6tables rules saved to $IP6TABLES_RULES"
            else
                echo "Failed to save ip6tables rules"
                log_message "ERROR" "Failed to save ip6tables rules"
                return 1
            fi
        fi
    fi

    # Check if ip6tables service is enabled to persist rules on boot
    if systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo "ip6tables service is enabled - rules will be persisted"
        log_message "INFO" "ip6tables service is enabled"
    else
        echo "WARNING: ip6tables service is not enabled"
        echo "Consider enabling the service to persist rules after reboot"
        log_message "WARNING" "ip6tables service is not enabled"
    fi

    echo ""
    echo "Status: COMPLIANT"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
