#!/bin/bash

SCRIPT_NAME="3.5.3.1.1_iptables_packages.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.3.1.1 - Ensure iptables packages are installed"
    echo ""
    
    # Check if iptables is installed, install if not
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "iptables package not installed - installing..."
        log_message "INFO" "Installing iptables package"
        
        if yum install -y iptables >/dev/null 2>&1; then
            echo "iptables installed successfully"
            log_message "SUCCESS" "iptables package installed"
        else
            echo "Failed to install iptables"
            log_message "ERROR" "Failed to install iptables"
            echo "Status: FAILED"
            return 1
        fi
    else
        echo "iptables package already installed"
        log_message "INFO" "iptables already installed"
    fi
    
    # Check if iptables-services is installed, install if not
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "iptables-services package not installed - installing..."
        log_message "INFO" "Installing iptables-services package"
        
        if yum install -y iptables-services >/dev/null 2>&1; then
            echo "iptables-services installed successfully"
            log_message "SUCCESS" "iptables-services package installed"
        else
            echo "Failed to install iptables-services"
            log_message "ERROR" "Failed to install iptables-services"
            echo "Status: FAILED"
            return 1
        fi
    else
        echo "iptables-services package already installed"
        log_message "INFO" "iptables-services already installed"
    fi
    
    echo "Status: COMPLIANT"
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
