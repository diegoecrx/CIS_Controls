#!/bin/bash

SCRIPT_NAME="3.4.1_dccp_disabled.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.4.1 - Disable DCCP"
    echo ""
    
    # Create modprobe config to disable DCCP
    cat > /etc/modprobe.d/dccp.conf <<EOF
# Disable DCCP protocol
install dccp /bin/true
EOF
    
    # Unload module if currently loaded
    if lsmod | grep -q "^dccp"; then
        rmmod dccp 2>/dev/null
        echo "DCCP module unloaded"
    else
        echo "DCCP module not currently loaded"
    fi
    
    log_message "SUCCESS" "DCCP protocol disabled"
    echo "DCCP protocol disabled"
    echo "Status: COMPLIANT"
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
