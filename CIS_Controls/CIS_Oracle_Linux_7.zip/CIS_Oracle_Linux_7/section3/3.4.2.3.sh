#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 3.4.2.3.sh
# CIS Control - 3.4.2.3 Ensure firewalld drops unnecessary services and ports (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="3.4.2.3.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Manual Remediation: $SCRIPT_NAME"
echo "3.4.2.3 Ensure firewalld drops unnecessary services and ports (Manual)"
echo "=============================================="
echo ""
echo "Description:"
echo "Manual review: Ensure unnecessary services and ports are dropped."
echo ""

log_message "Manual remediation: Review firewalld services"

echo "Current firewalld configuration:"
echo ""
echo "Active zones:"
firewall-cmd --get-active-zones
echo ""
echo "Default zone:"
firewall-cmd --get-default-zone
echo ""
echo "Services enabled in default zone:"
firewall-cmd --list-services
echo ""
echo "Ports enabled in default zone:"
firewall-cmd --list-ports
echo ""
echo "Manual actions required:"
echo "1. Review enabled services and remove unnecessary ones:"
echo "   firewall-cmd --remove-service=<service> --permanent"
echo "2. Review open ports and close unnecessary ones:"
echo "   firewall-cmd --remove-port=<port>/tcp --permanent"
echo "3. Reload firewall: firewall-cmd --reload"
echo ""
echo "✓ Manual review information displayed"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
