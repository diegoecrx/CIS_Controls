#!/bin/bash

SCRIPT_NAME="3.5.2.2_firewalld_either_masked_with_nftables.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 3.5.2.2 - Ensure firewalld is either not installed or masked with nftables"
    echo ""
    
    # Check if nftables is installed and active
    if rpm -q nftables >/dev/null 2>&1; then
        log_message "INFO" "nftables is installed"
        
        # Check if firewalld is installed
        if rpm -q firewalld >/dev/null 2>&1; then
            log_message "WARNING" "firewalld is installed alongside nftables"
            
            # Stop firewalld if running
            if systemctl is-active firewalld >/dev/null 2>&1; then
                systemctl stop firewalld >/dev/null 2>&1
                echo "firewalld service stopped"
            fi
            
            # Mask firewalld service to prevent conflicts
            if systemctl is-masked firewalld >/dev/null 2>&1; then
                echo "firewalld already masked"
            else
                systemctl mask firewalld >/dev/null 2>&1
                echo "firewalld service masked"
                log_message "SUCCESS" "firewalld masked to prevent conflicts with nftables"
            fi
        else
            echo "firewalld not installed"
            log_message "INFO" "firewalld not present"
        fi
        
        # Ensure nftables is enabled and running
        if ! systemctl is-enabled nftables >/dev/null 2>&1; then
            systemctl enable nftables >/dev/null 2>&1
            log_message "SUCCESS" "Enabled nftables"
        fi
        
        if ! systemctl is-active nftables >/dev/null 2>&1; then
            systemctl start nftables >/dev/null 2>&1
            log_message "SUCCESS" "Started nftables"
        fi
        
        echo "nftables is active and enabled"
        echo "Status: COMPLIANT"
    else
        echo "nftables is not installed"
        log_message "WARNING" "nftables not installed - this control requires nftables"
        echo "Status: NOT APPLICABLE"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
