
import pandas as pd
import os

# Read the new Section 6 spreadsheet
df_section6 = pd.read_excel('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section6.xlsx', sheet_name='Recommendations')

# Display overview
print("=" * 100)
print("CIS ORACLE LINUX 7 BENCHMARK - SECTION 6 ANALYSIS")
print("=" * 100)
print(f"\nTotal number of remediations in Section 6: {len(df_section6)}")
print("\nAll controls:")
print("=" * 100)

for idx in range(len(df_section6)):
    row = df_section6.iloc[idx]
    control_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    print(f"{idx + 1}. {row['script_name']:20s} | {control_type:10s} | {row['control_name']}")

# Count manual vs automated
manual_count = df_section6[df_section6['control_name'].str.contains('Manual', case=False, na=False)].shape[0]
automated_count = df_section6[df_section6['control_name'].str.contains('Automated', case=False, na=False)].shape[0]

print("\n" + "=" * 100)
print(f"Manual controls: {manual_count}")
print(f"Automated controls: {automated_count}")
print(f"Total: {len(df_section6)}")

# Save for processing
df_section6.to_csv('section6_remediation_data.csv', index=False)
print("\n✓ Section 6 data loaded and ready for script generation")
