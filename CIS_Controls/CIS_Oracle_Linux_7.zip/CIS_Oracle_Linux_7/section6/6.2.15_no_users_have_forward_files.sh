#!/bin/bash

SCRIPT_NAME="6.2.15_no_users_have_forward_files.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_forward_files_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.15 - Ensure no users have .forward files"
    echo ""

    log_message "INFO" "Starting .forward files audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.15 .forward Files Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies users with .forward files in their home directories.

EOF

    echo "Checking for .forward files..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    FORWARD_FILES_FOUND=0
    USERS_CHECKED=0

    # Read /etc/passwd and check for .forward files
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Skip system users with UID < 1000 (except root)
        if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
            continue
        fi
        
        # Skip if home directory doesn't exist
        if [ ! -d "$homedir" ]; then
            continue
        fi
        
        ((USERS_CHECKED++))
        
        # Check for .forward file
        FORWARD_FILE="$homedir/.forward"
        
        if [ -f "$FORWARD_FILE" ]; then
            echo "[FOUND] User: $username - .forward exists: $FORWARD_FILE" | tee -a "$AUDIT_REPORT"
            
            # Show content preview (first 3 lines) for context
            echo "  Content preview:" | tee -a "$AUDIT_REPORT"
            head -3 "$FORWARD_FILE" 2>/dev/null | while read -r line; do
                echo "    $line" | tee -a "$AUDIT_REPORT"
            done
            echo "" | tee -a "$AUDIT_REPORT"
            
            ((FORWARD_FILES_FOUND++))
        fi
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Users checked: $USERS_CHECKED
.forward files found: $FORWARD_FILES_FOUND

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Users checked: $USERS_CHECKED"
    echo ".forward files found: $FORWARD_FILES_FOUND"
    echo ""

    if [ $FORWARD_FILES_FOUND -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "No .forward files found"
        log_message "SUCCESS" "No .forward files present"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT"
        echo "$FORWARD_FILES_FOUND .forward file(s) found"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $FORWARD_FILES_FOUND .forward files"
    fi

    # Ask if user wants to remove .forward files
    echo ""
    echo "IMPORTANT: Removing .forward files will stop mail forwarding!"
    echo "This may disrupt mail routing for users who intentionally use this feature."
    echo ""
    echo "Options:"
    echo "  1) Backup and remove all .forward files"
    echo "  2) Review each .forward file individually (recommended)"
    echo "  3) Exit without making changes"
    echo ""
    read -p "Enter choice [1-3] (default: 3): " CHOICE
    CHOICE=${CHOICE:-3}

    if [ "$CHOICE" = "1" ]; then
        echo ""
        echo "Backing up and removing .forward files..."
        echo ""
        
        REMOVED=0
        FAILED=0
        
        # Re-scan and remove .forward files
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            FORWARD_FILE="$homedir/.forward"
            
            if [ -f "$FORWARD_FILE" ]; then
                echo "Processing: $FORWARD_FILE"
                
                # Backup the file
                BACKUP_FILE="$BACKUP_DIR/forward_${username}_$(date +%Y%m%d_%H%M%S).backup"
                if cp "$FORWARD_FILE" "$BACKUP_FILE" 2>/dev/null; then
                    echo "  Backed up to: $BACKUP_FILE"
                    
                    # Remove the file
                    if rm "$FORWARD_FILE" 2>/dev/null; then
                        echo "  Removed: $FORWARD_FILE"
                        log_message "SUCCESS" "Removed .forward for $username"
                        ((REMOVED++))
                    else
                        echo "  ERROR: Failed to remove"
                        log_message "ERROR" "Failed to remove .forward for $username"
                        ((FAILED++))
                    fi
                else
                    echo "  ERROR: Failed to backup"
                    log_message "ERROR" "Failed to backup .forward for $username"
                    ((FAILED++))
                fi
            fi
        done < /etc/passwd
        
        echo ""
        echo "Removal Summary:"
        echo "  Removed: $REMOVED"
        echo "  Failed: $FAILED"
        echo "  Backups location: $BACKUP_DIR"
        log_message "SUCCESS" "Removed $REMOVED .forward files, $FAILED failures"
        
    elif [ "$CHOICE" = "2" ]; then
        echo ""
        echo "Reviewing .forward files individually..."
        echo ""
        
        REMOVED=0
        KEPT=0
        
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            FORWARD_FILE="$homedir/.forward"
            
            if [ -f "$FORWARD_FILE" ]; then
                echo "================================"
                echo "User: $username"
                echo "File: $FORWARD_FILE"
                echo "Content:"
                cat "$FORWARD_FILE" 2>/dev/null
                echo ""
                
                read -p "Remove this .forward file? [y/N]: " REMOVE
                
                if [ "$REMOVE" = "y" ] || [ "$REMOVE" = "Y" ]; then
                    BACKUP_FILE="$BACKUP_DIR/forward_${username}_$(date +%Y%m%d_%H%M%S).backup"
                    cp "$FORWARD_FILE" "$BACKUP_FILE" 2>/dev/null
                    
                    if rm "$FORWARD_FILE" 2>/dev/null; then
                        echo "Removed (backed up to: $BACKUP_FILE)"
                        log_message "SUCCESS" "Removed .forward for $username"
                        ((REMOVED++))
                    else
                        echo "ERROR: Failed to remove"
                        ((FAILED++))
                    fi
                else
                    echo "Kept"
                    ((KEPT++))
                fi
                echo ""
            fi
        done < /etc/passwd
        
        echo "Review Summary:"
        echo "  Removed: $REMOVED"
        echo "  Kept: $KEPT"
        log_message "SUCCESS" "Reviewed and removed $REMOVED .forward files"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "To manually remove a .forward file:"
        echo "  rm /home/username/.forward"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. .forward files are used by mail systems to redirect email"
    echo "2. They can be exploited to:"
    echo "   - Expose sensitive information via mail forwarding"
    echo "   - Facilitate spam and phishing attacks"
    echo "   - Bypass email security controls"
    echo "3. Modern mail forwarding should be configured in the mail system, not user files"
    echo "4. If mail forwarding is needed, use aliases in /etc/aliases instead"
    echo "5. Backups are saved in: $BACKUP_DIR"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
