#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.8.sh
# CIS Control - 6.2.8 Ensure root path integrity (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.8.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.8 Ensure root path integrity (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Validates root PATH integrity."
echo ""

log_message "Starting remediation: Root PATH integrity"

ISSUE_FOUND=0

# Check for empty directory in PATH
if echo "$PATH" | grep -q "::"; then
    echo "⚠ Empty directory in PATH (::)"
    ISSUE_FOUND=1
fi

if echo "$PATH" | grep -q "^:"; then
    echo "⚠ PATH starts with empty directory"
    ISSUE_FOUND=1
fi

if echo "$PATH" | grep -q ":$"; then
    echo "⚠ PATH ends with empty directory"
    ISSUE_FOUND=1
fi

# Check for . in PATH
if echo "$PATH" | grep -q "\."; then
    echo "⚠ Current directory (.) in PATH"
    ISSUE_FOUND=1
fi

# Check PATH directory permissions
IFS=: read -ra PATHS <<< "$PATH"
for dir in "${PATHS[@]}"; do
    if [ -d "$dir" ]; then
        # Check if world writable
        if [ "$(stat -c %a "$dir" | cut -c3)" -ge 2 ]; then
            echo "⚠ PATH directory $dir is world-writable"
            ISSUE_FOUND=1
        fi

        # Check if not owned by root
        if [ "$(stat -c %U "$dir")" != "root" ]; then
            echo "⚠ PATH directory $dir is not owned by root"
            ISSUE_FOUND=1
        fi
    fi
done

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ Root PATH integrity validated"
else
    echo ""
    echo "Fix PATH issues in /root/.bash_profile and /root/.bashrc"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
