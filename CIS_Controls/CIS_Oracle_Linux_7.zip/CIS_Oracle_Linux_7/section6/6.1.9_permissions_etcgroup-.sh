#!/bin/bash

SCRIPT_NAME="6.1.9_permissions_etcgroup-.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
GROUP_BACKUP="/etc/group-"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.1.9 - Ensure permissions on /etc/group- are configured"
    echo ""

    # Check if group- backup file exists
    if [ ! -f "$GROUP_BACKUP" ]; then
        echo "WARNING: $GROUP_BACKUP not found"
        echo "This is the backup file created by shadow utilities"
        echo ""
        echo "Status: NOT APPLICABLE"
        echo "The backup file does not exist on this system"
        log_message "INFO" "group- backup file not found - control not applicable"
        return 0
    fi

    echo "$GROUP_BACKUP exists"
    echo ""

    # Get current permissions, owner, and group
    CURRENT_PERMS=$(stat -c '%a' "$GROUP_BACKUP" 2>/dev/null)
    CURRENT_OWNER=$(stat -c '%U' "$GROUP_BACKUP" 2>/dev/null)
    CURRENT_GROUP=$(stat -c '%G' "$GROUP_BACKUP" 2>/dev/null)

    echo "Current status:"
    echo "  Permissions: $CURRENT_PERMS"
    echo "  Owner: $CURRENT_OWNER"
    echo "  Group: $CURRENT_GROUP"
    echo ""

    CHANGES_MADE=0

    # Check and fix ownership
    if [ "$CURRENT_OWNER" != "root" ] || [ "$CURRENT_GROUP" != "root" ]; then
        echo "Fixing ownership to root:root..."
        
        if chown root:root "$GROUP_BACKUP" 2>/dev/null; then
            echo "Changed ownership to root:root"
            log_message "SUCCESS" "Changed ownership of group- to root:root"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to change ownership"
            log_message "ERROR" "Failed to change ownership of group-"
            return 1
        fi
    else
        echo "Ownership is correct (root:root)"
    fi

    echo ""

    # Check and fix permissions
    # Convert to decimal for comparison
    CURRENT_PERMS_DEC=$((8#$CURRENT_PERMS))
    TARGET_PERMS_DEC=$((8#644))
    
    # CIS requires 644 or more restrictive (e.g., 640, 600)
    # Check if current permissions are more permissive than 644
    if [ $CURRENT_PERMS_DEC -gt $TARGET_PERMS_DEC ]; then
        echo "Permissions are too permissive ($CURRENT_PERMS)"
        echo "Fixing permissions to 644..."
        
        if chmod 644 "$GROUP_BACKUP" 2>/dev/null; then
            echo "Changed permissions to 644"
            log_message "SUCCESS" "Changed permissions of group- to 644"
            CHANGES_MADE=1
        else
            echo "ERROR: Failed to change permissions"
            log_message "ERROR" "Failed to change permissions of group-"
            return 1
        fi
    else
        echo "Permissions are compliant ($CURRENT_PERMS)"
    fi

    # Verify final state
    echo ""
    echo "Verification:"
    echo "-------------"

    FINAL_PERMS=$(stat -c '%a' "$GROUP_BACKUP" 2>/dev/null)
    FINAL_OWNER=$(stat -c '%U' "$GROUP_BACKUP" 2>/dev/null)
    FINAL_GROUP=$(stat -c '%G' "$GROUP_BACKUP" 2>/dev/null)

    echo "Final status:"
    echo "  Permissions: $FINAL_PERMS"
    echo "  Owner: $FINAL_OWNER"
    echo "  Group: $FINAL_GROUP"
    echo ""

    # Check compliance
    FINAL_PERMS_DEC=$((8#$FINAL_PERMS))
    
    if [ "$FINAL_OWNER" = "root" ] && [ "$FINAL_GROUP" = "root" ] && [ $FINAL_PERMS_DEC -le $TARGET_PERMS_DEC ]; then
        echo "Status: COMPLIANT"
        echo "/etc/group- is properly secured"
        echo ""
        echo "Permission breakdown (644):"
        echo "  - Owner (root): read, write"
        echo "  - Group (root): read"
        echo "  - Others: read"
        log_message "SUCCESS" "group- properly secured"
    else
        echo "Status: NON-COMPLIANT"
        echo "WARNING: /etc/group- is not properly secured"
        log_message "ERROR" "group- not properly secured"
        return 1
    fi

    echo ""
    
    if [ $CHANGES_MADE -eq 1 ]; then
        echo "Changes have been applied successfully"
        log_message "SUCCESS" "Remediation completed with changes"
    else
        echo "No changes were necessary"
        log_message "SUCCESS" "System already compliant"
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. /etc/group- is a backup of /etc/group"
    echo "2. Created automatically by shadow utilities (usermod, groupmod, etc.)"
    echo "3. Contains same group membership information as group"
    echo "4. Must be secured with same permissions as /etc/group"
    echo "5. Permissions 644 allow read access while preventing unauthorized modification"
    echo ""

    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
