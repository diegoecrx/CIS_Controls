#!/bin/bash

SCRIPT_NAME="6.2.17_no_users_have_rhosts_files.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_rhosts_files_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.17 - Ensure no users have .rhosts files"
    echo ""
    echo "WARNING: .rhosts files enable INSECURE passwordless remote access!"
    echo ""

    log_message "INFO" "Starting .rhosts files audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.17 .rhosts Files Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies users with .rhosts files that bypass authentication.

EOF

    echo "Checking for .rhosts files..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    RHOSTS_FILES_FOUND=0
    USERS_CHECKED=0

    # Read /etc/passwd and check for .rhosts files
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Skip system users with UID < 1000 (except root)
        if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
            continue
        fi
        
        # Skip if home directory doesn't exist
        if [ ! -d "$homedir" ]; then
            continue
        fi
        
        ((USERS_CHECKED++))
        
        # Check for .rhosts file
        RHOSTS_FILE="$homedir/.rhosts"
        
        if [ -f "$RHOSTS_FILE" ]; then
            # Get file permissions
            PERMS=$(stat -c '%a' "$RHOSTS_FILE" 2>/dev/null)
            
            echo "[FOUND] User: $username - .rhosts exists: $RHOSTS_FILE (permissions: $PERMS)" | tee -a "$AUDIT_REPORT"
            
            # Show number of trusted hosts
            HOSTS=$(wc -l < "$RHOSTS_FILE" 2>/dev/null || echo 0)
            echo "  Trusted hosts configured: $HOSTS" | tee -a "$AUDIT_REPORT"
            
            # Show trusted hosts (without + which allows all)
            echo "  Host entries:" | tee -a "$AUDIT_REPORT"
            while read -r line; do
                # Skip empty lines and comments
                [ -z "$line" ] && continue
                [[ "$line" =~ ^# ]] && continue
                
                # Warn about wildcard entries
                if [[ "$line" =~ ^\+ ]]; then
                    echo "    CRITICAL: + (allows ALL hosts)" | tee -a "$AUDIT_REPORT"
                else
                    echo "    $line" | tee -a "$AUDIT_REPORT"
                fi
            done < "$RHOSTS_FILE"
            
            echo "" | tee -a "$AUDIT_REPORT"
            
            ((RHOSTS_FILES_FOUND++))
        fi
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Users checked: $USERS_CHECKED
.rhosts files found: $RHOSTS_FILES_FOUND

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Users checked: $USERS_CHECKED"
    echo ".rhosts files found: $RHOSTS_FILES_FOUND"
    echo ""

    if [ $RHOSTS_FILES_FOUND -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "No .rhosts files found"
        log_message "SUCCESS" "No .rhosts files present"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT"
        echo "$RHOSTS_FILES_FOUND .rhosts file(s) found - SEVERE SECURITY RISK!"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $RHOSTS_FILES_FOUND .rhosts files - severe security risk"
    fi

    # Ask if user wants to remove .rhosts files
    echo ""
    echo "CRITICAL SECURITY WARNING:"
    echo "=========================="
    echo ".rhosts files allow passwordless remote access based on hostname trust"
    echo "This is EXTREMELY INSECURE and should be removed immediately!"
    echo ""
    echo "Security risks:"
    echo "  - Bypasses password authentication"
    echo "  - Relies on easily spoofed IP/hostname trust"
    echo "  - No encryption or integrity checking"
    echo "  - Violates modern security standards"
    echo ""
    echo "Removing .rhosts files will break passwordless rsh/rlogin access."
    echo "Users should migrate to SSH with key-based authentication."
    echo ""
    echo "Options:"
    echo "  1) Backup and remove all .rhosts files (STRONGLY RECOMMENDED)"
    echo "  2) Review each .rhosts file individually"
    echo "  3) Exit without making changes"
    echo ""
    read -p "Enter choice [1-3] (default: 1): " CHOICE
    CHOICE=${CHOICE:-1}

    if [ "$CHOICE" = "1" ]; then
        echo ""
        echo "Backing up and removing .rhosts files..."
        echo ""
        
        REMOVED=0
        FAILED=0
        
        # Re-scan and remove .rhosts files
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            RHOSTS_FILE="$homedir/.rhosts"
            
            if [ -f "$RHOSTS_FILE" ]; then
                echo "Processing: $RHOSTS_FILE"
                
                # Backup the file
                BACKUP_FILE="$BACKUP_DIR/rhosts_${username}_$(date +%Y%m%d_%H%M%S).backup"
                if cp "$RHOSTS_FILE" "$BACKUP_FILE" 2>/dev/null; then
                    echo "  Backed up to: $BACKUP_FILE"
                    
                    # Remove the file
                    if rm "$RHOSTS_FILE" 2>/dev/null; then
                        echo "  Removed: $RHOSTS_FILE"
                        log_message "SUCCESS" "Removed .rhosts for $username"
                        ((REMOVED++))
                    else
                        echo "  ERROR: Failed to remove"
                        log_message "ERROR" "Failed to remove .rhosts for $username"
                        ((FAILED++))
                    fi
                else
                    echo "  ERROR: Failed to backup"
                    log_message "ERROR" "Failed to backup .rhosts for $username"
                    ((FAILED++))
                fi
            fi
        done < /etc/passwd
        
        echo ""
        echo "Removal Summary:"
        echo "  Removed: $REMOVED"
        echo "  Failed: $FAILED"
        echo "  Backups location: $BACKUP_DIR"
        log_message "SUCCESS" "Removed $REMOVED .rhosts files, $FAILED failures"
        
    elif [ "$CHOICE" = "2" ]; then
        echo ""
        echo "Reviewing .rhosts files individually..."
        echo ""
        
        REMOVED=0
        KEPT=0
        
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            RHOSTS_FILE="$homedir/.rhosts"
            
            if [ -f "$RHOSTS_FILE" ]; then
                echo "================================"
                echo "User: $username"
                echo "File: $RHOSTS_FILE"
                echo "Permissions: $(stat -c '%a' "$RHOSTS_FILE")"
                echo ""
                echo "Trusted hosts:"
                cat "$RHOSTS_FILE" 2>/dev/null | grep -v "^$" | grep -v "^#"
                echo ""
                
                read -p "Remove this .rhosts file? [Y/n]: " REMOVE
                REMOVE=${REMOVE:-y}
                
                if [ "$REMOVE" = "y" ] || [ "$REMOVE" = "Y" ]; then
                    BACKUP_FILE="$BACKUP_DIR/rhosts_${username}_$(date +%Y%m%d_%H%M%S).backup"
                    cp "$RHOSTS_FILE" "$BACKUP_FILE" 2>/dev/null
                    
                    if rm "$RHOSTS_FILE" 2>/dev/null; then
                        echo "Removed (backed up to: $BACKUP_FILE)"
                        log_message "SUCCESS" "Removed .rhosts for $username"
                        ((REMOVED++))
                    else
                        echo "ERROR: Failed to remove"
                        ((FAILED++))
                    fi
                else
                    echo "Kept (NOT RECOMMENDED)"
                    ((KEPT++))
                fi
                echo ""
            fi
        done < /etc/passwd
        
        echo "Review Summary:"
        echo "  Removed: $REMOVED"
        echo "  Kept: $KEPT"
        log_message "SUCCESS" "Reviewed and removed $REMOVED .rhosts files"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "WARNING: .rhosts files remain - SEVERE SECURITY RISK!"
        echo ""
        echo "To manually remove a .rhosts file:"
        echo "  rm /home/username/.rhosts"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. .rhosts files are legacy authentication for rsh/rlogin/rcp"
    echo "2. They allow passwordless remote access based on hostname trust"
    echo "3. Security risks include:"
    echo "   - No password required for remote access"
    echo "   - Easily spoofed IP addresses and hostnames"
    echo "   - No encryption of communication"
    echo "   - Bypasses modern authentication controls"
    echo "4. Secure alternatives:"
    echo "   - SSH with key-based authentication"
    echo "   - Configure SSH authorized_keys instead"
    echo "   - Use proper certificate-based authentication"
    echo "5. The 'r' commands (rsh, rlogin, rcp) should be disabled entirely"
    echo "6. Backups saved in: $BACKUP_DIR"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
