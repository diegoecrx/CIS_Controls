#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.1.11.sh
# CIS Control - 6.1.11 Ensure world writable files and directories are secured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.1.11.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.1.11 Ensure world writable files and directories are secured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Secures world-writable files and directories."
echo ""

log_message "Starting remediation: Secure world-writable files"

echo "Searching for world-writable files and directories..."
echo ""

# Find world-writable files (excluding /proc, /sys, /dev)
WRITABLE_FILES=$(find / -xdev -type f -perm -0002 2>/dev/null)

if [ -n "$WRITABLE_FILES" ]; then
    echo "Found world-writable files:"
    echo "$WRITABLE_FILES"
    echo ""
    echo "Removing world-write permission..."
    find / -xdev -type f -perm -0002 -exec chmod o-w {} \; 2>/dev/null
    echo "✓ World-write removed from files"
else
    echo "✓ No world-writable files found"
fi

# Find world-writable directories without sticky bit
echo ""
WRITABLE_DIRS=$(find / -xdev -type d -perm -0002 ! -perm -1000 2>/dev/null)

if [ -n "$WRITABLE_DIRS" ]; then
    echo "Found world-writable directories without sticky bit:"
    echo "$WRITABLE_DIRS"
    echo ""
    echo "Adding sticky bit..."
    find / -xdev -type d -perm -0002 ! -perm -1000 -exec chmod +t {} \; 2>/dev/null
    echo "✓ Sticky bit added to world-writable directories"
else
    echo "✓ No insecure world-writable directories found"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
