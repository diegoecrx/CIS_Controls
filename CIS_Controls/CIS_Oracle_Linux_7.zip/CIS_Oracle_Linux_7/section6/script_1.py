
import pandas as pd
import os

# Create section6_scripts directory
os.makedirs('section6_scripts', exist_ok=True)

df = pd.read_csv('section6_remediation_data.csv')

print("=" * 100)
print("GENERATING SECTION 6 SCRIPTS - SYSTEM MAINTENANCE")
print("=" * 100)
print(f"\nTotal scripts to generate: {len(df)}")
print(f"Automated: {len(df[df['control_name'].str.contains('Automated', na=False)])}")
print(f"Manual: {len(df[df['control_name'].str.contains('Manual', na=False)])}")

print("\n" + "=" * 100)
print("Script Categories:")
print("=" * 100)
print("6.1.x - System File Permissions")
print("6.2.x - Local User and Group Settings")

print("\n" + "=" * 100)
print("Starting script generation...")
print("=" * 100)

scripts_created = []

# Generate all Section 6 scripts
for idx in range(len(df)):
    row = df.iloc[idx]
    script_num = row['script_name']
    control_name = row['control_name']
    is_manual = "Manual" in control_name
    
    script = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_num}.sh
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="{script_num}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

backup_file() {{
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}}

echo ""
echo ""
echo ""
echo "=============================================="
'''

    if is_manual:
        script += f'''echo "Manual Remediation: $SCRIPT_NAME"
'''
    else:
        script += f'''echo "Automated Remediation: $SCRIPT_NAME"
'''
    
    script += f'''echo "{control_name}"
echo "=============================================="
echo ""
echo "Description:"
'''

    # Add specific remediation logic based on control
    # System File Permissions (6.1.x)
    if script_num.startswith('6.1'):
        if '6.1.1' == script_num:
            script += '''echo "Sets permissions on /etc/passwd."
echo ""

log_message "Starting remediation: /etc/passwd permissions"

chmod 0644 /etc/passwd
chown root:root /etc/passwd

echo "✓ Permissions set on /etc/passwd"
ls -l /etc/passwd
'''
        elif '6.1.2' == script_num:
            script += '''echo "Sets permissions on /etc/passwd- (backup file)."
echo ""

log_message "Starting remediation: /etc/passwd- permissions"

if [ -f /etc/passwd- ]; then
    chmod 0644 /etc/passwd-
    chown root:root /etc/passwd-
    echo "✓ Permissions set on /etc/passwd-"
    ls -l /etc/passwd-
else
    echo "✓ /etc/passwd- does not exist"
fi
'''
        elif '6.1.3' == script_num:
            script += '''echo "Sets permissions on /etc/group."
echo ""

log_message "Starting remediation: /etc/group permissions"

chmod 0644 /etc/group
chown root:root /etc/group

echo "✓ Permissions set on /etc/group"
ls -l /etc/group
'''
        elif '6.1.4' == script_num:
            script += '''echo "Sets permissions on /etc/group- (backup file)."
echo ""

log_message "Starting remediation: /etc/group- permissions"

if [ -f /etc/group- ]; then
    chmod 0644 /etc/group-
    chown root:root /etc/group-
    echo "✓ Permissions set on /etc/group-"
    ls -l /etc/group-
else
    echo "✓ /etc/group- does not exist"
fi
'''
        elif '6.1.5' == script_num:
            script += '''echo "Sets permissions on /etc/shadow."
echo ""

log_message "Starting remediation: /etc/shadow permissions"

chmod 0000 /etc/shadow
chown root:root /etc/shadow

echo "✓ Permissions set on /etc/shadow (0000)"
ls -l /etc/shadow
'''
        elif '6.1.6' == script_num:
            script += '''echo "Sets permissions on /etc/shadow- (backup file)."
echo ""

log_message "Starting remediation: /etc/shadow- permissions"

if [ -f /etc/shadow- ]; then
    chmod 0000 /etc/shadow-
    chown root:root /etc/shadow-
    echo "✓ Permissions set on /etc/shadow- (0000)"
    ls -l /etc/shadow-
else
    echo "✓ /etc/shadow- does not exist"
fi
'''
        elif '6.1.7' == script_num:
            script += '''echo "Sets permissions on /etc/gshadow."
echo ""

log_message "Starting remediation: /etc/gshadow permissions"

chmod 0000 /etc/gshadow
chown root:root /etc/gshadow

echo "✓ Permissions set on /etc/gshadow (0000)"
ls -l /etc/gshadow
'''
        elif '6.1.8' == script_num:
            script += '''echo "Sets permissions on /etc/gshadow- (backup file)."
echo ""

log_message "Starting remediation: /etc/gshadow- permissions"

if [ -f /etc/gshadow- ]; then
    chmod 0000 /etc/gshadow-
    chown root:root /etc/gshadow-
    echo "✓ Permissions set on /etc/gshadow- (0000)"
    ls -l /etc/gshadow-
else
    echo "✓ /etc/gshadow- does not exist"
fi
'''
        elif '6.1.9' == script_num:
            script += '''echo "Sets permissions on /etc/shells."
echo ""

log_message "Starting remediation: /etc/shells permissions"

chmod 0644 /etc/shells
chown root:root /etc/shells

echo "✓ Permissions set on /etc/shells"
ls -l /etc/shells
'''
        elif '6.1.10' == script_num:
            script += '''echo "Sets permissions on /etc/security/opasswd."
echo ""

log_message "Starting remediation: /etc/security/opasswd permissions"

if [ -f /etc/security/opasswd ]; then
    chmod 0600 /etc/security/opasswd
    chown root:root /etc/security/opasswd
    echo "✓ Permissions set on /etc/security/opasswd"
    ls -l /etc/security/opasswd
else
    touch /etc/security/opasswd
    chmod 0600 /etc/security/opasswd
    chown root:root /etc/security/opasswd
    echo "✓ Created and set permissions on /etc/security/opasswd"
    ls -l /etc/security/opasswd
fi
'''
        elif '6.1.11' == script_num:
            script += '''echo "Secures world-writable files and directories."
echo ""

log_message "Starting remediation: Secure world-writable files"

echo "Searching for world-writable files and directories..."
echo ""

# Find world-writable files (excluding /proc, /sys, /dev)
WRITABLE_FILES=$(find / -xdev -type f -perm -0002 2>/dev/null)

if [ -n "$WRITABLE_FILES" ]; then
    echo "Found world-writable files:"
    echo "$WRITABLE_FILES"
    echo ""
    echo "Removing world-write permission..."
    find / -xdev -type f -perm -0002 -exec chmod o-w {} \\; 2>/dev/null
    echo "✓ World-write removed from files"
else
    echo "✓ No world-writable files found"
fi

# Find world-writable directories without sticky bit
echo ""
WRITABLE_DIRS=$(find / -xdev -type d -perm -0002 ! -perm -1000 2>/dev/null)

if [ -n "$WRITABLE_DIRS" ]; then
    echo "Found world-writable directories without sticky bit:"
    echo "$WRITABLE_DIRS"
    echo ""
    echo "Adding sticky bit..."
    find / -xdev -type d -perm -0002 ! -perm -1000 -exec chmod +t {} \\; 2>/dev/null
    echo "✓ Sticky bit added to world-writable directories"
else
    echo "✓ No insecure world-writable directories found"
fi
'''
        elif '6.1.12' == script_num:
            script += '''echo "Checks for unowned or ungrouped files."
echo ""

log_message "Starting remediation: Find unowned files"

echo "Searching for unowned files..."
UNOWNED=$(find / -xdev -nouser 2>/dev/null)

if [ -n "$UNOWNED" ]; then
    echo "Found unowned files:"
    echo "$UNOWNED"
    echo ""
    echo "⚠ Manual review required - these files should be:"
    echo "  1. Assigned to appropriate user, or"
    echo "  2. Deleted if not needed"
else
    echo "✓ No unowned files found"
fi

echo ""
echo "Searching for ungrouped files..."
UNGROUPED=$(find / -xdev -nogroup 2>/dev/null)

if [ -n "$UNGROUPED" ]; then
    echo "Found ungrouped files:"
    echo "$UNGROUPED"
    echo ""
    echo "⚠ Manual review required - these files should be:"
    echo "  1. Assigned to appropriate group, or"
    echo "  2. Deleted if not needed"
else
    echo "✓ No ungrouped files found"
fi
'''
        elif '6.1.13' == script_num:
            script += '''echo "Manual review: SUID and SGID files."
echo ""

log_message "Manual remediation: Review SUID/SGID files"

echo "Finding SUID files (permission 4000)..."
echo ""
find / -xdev -type f -perm -4000 -ls 2>/dev/null

echo ""
echo "Finding SGID files (permission 2000)..."
echo ""
find / -xdev -type f -perm -2000 -ls 2>/dev/null

echo ""
echo "Manual review required:"
echo "1. Verify each SUID/SGID file is necessary"
echo "2. Remove SUID/SGID bit from unnecessary files:"
echo "   chmod u-s <file>  # Remove SUID"
echo "   chmod g-s <file>  # Remove SGID"
echo ""
echo "✓ SUID/SGID file list displayed for review"
'''
        elif '6.1.14' == script_num:
            script += '''echo "Manual audit: System file permissions."
echo ""

log_message "Manual remediation: Audit file permissions"

echo "Auditing important system file permissions..."
echo ""

for file in /etc/passwd /etc/shadow /etc/group /etc/gshadow \\
            /etc/passwd- /etc/shadow- /etc/group- /etc/gshadow- \\
            /etc/ssh/sshd_config /etc/sudoers /boot/grub2/grub.cfg; do
    if [ -f "$file" ]; then
        ls -l "$file"
    fi
done

echo ""
echo "Review the permissions above and compare with CIS Benchmark requirements"
echo "✓ System file permissions audit complete"
'''
    
    # Local User and Group Settings (6.2.x)
    elif script_num.startswith('6.2'):
        if '6.2.1' == script_num:
            script += '''echo "Ensures accounts use shadowed passwords."
echo ""

log_message "Starting remediation: Shadowed passwords"

ISSUE_FOUND=0

while IFS=: read -r username password uid gid comment home shell; do
    if [ "$password" != "x" ]; then
        echo "⚠ User $username does not use shadowed password"
        ISSUE_FOUND=1
    fi
done < /etc/passwd

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ All accounts use shadowed passwords"
else
    echo ""
    echo "To fix, run: pwconv"
    echo "This will move passwords to /etc/shadow"
fi
'''
        elif '6.2.2' == script_num:
            script += '''echo "Checks for empty password fields."
echo ""

log_message "Starting remediation: Empty passwords"

EMPTY_PASS=$(awk -F: '($2 == "") {print $1}' /etc/shadow)

if [ -n "$EMPTY_PASS" ]; then
    echo "⚠ Found accounts with empty passwords:"
    echo "$EMPTY_PASS"
    echo ""
    echo "Lock these accounts with:"
    echo "  passwd -l <username>"
    echo ""
    echo "Or set passwords:"
    echo "  passwd <username>"
else
    echo "✓ No accounts with empty passwords found"
fi
'''
        elif '6.2.3' == script_num:
            script += '''echo "Validates all groups in /etc/passwd exist in /etc/group."
echo ""

log_message "Starting remediation: Validate groups"

ISSUE_FOUND=0

while IFS=: read -r username password uid gid comment home shell; do
    if ! grep -q "^[^:]*:[^:]*:$gid:" /etc/group; then
        echo "⚠ User $username (UID: $uid) has GID $gid which does not exist in /etc/group"
        ISSUE_FOUND=1
    fi
done < /etc/passwd

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ All groups in /etc/passwd exist in /etc/group"
else
    echo ""
    echo "Create missing groups or assign users to existing groups"
fi
'''
        elif '6.2.4' == script_num:
            script += '''echo "Checks for duplicate UIDs."
echo ""

log_message "Starting remediation: Check duplicate UIDs"

DUPLICATES=$(awk -F: '{print $3}' /etc/passwd | sort | uniq -d)

if [ -n "$DUPLICATES" ]; then
    echo "⚠ Found duplicate UIDs:"
    for uid in $DUPLICATES; do
        echo "  UID $uid:"
        awk -F: -v uid="$uid" '$3 == uid {print "    " $1}' /etc/passwd
    done
    echo ""
    echo "Assign unique UIDs to each user with usermod -u"
else
    echo "✓ No duplicate UIDs found"
fi
'''
        elif '6.2.5' == script_num:
            script += '''echo "Checks for duplicate GIDs."
echo ""

log_message "Starting remediation: Check duplicate GIDs"

DUPLICATES=$(awk -F: '{print $3}' /etc/group | sort | uniq -d)

if [ -n "$DUPLICATES" ]; then
    echo "⚠ Found duplicate GIDs:"
    for gid in $DUPLICATES; do
        echo "  GID $gid:"
        awk -F: -v gid="$gid" '$3 == gid {print "    " $1}' /etc/group
    done
    echo ""
    echo "Assign unique GIDs to each group with groupmod -g"
else
    echo "✓ No duplicate GIDs found"
fi
'''
        elif '6.2.6' == script_num:
            script += '''echo "Checks for duplicate user names."
echo ""

log_message "Starting remediation: Check duplicate usernames"

DUPLICATES=$(awk -F: '{print $1}' /etc/passwd | sort | uniq -d)

if [ -n "$DUPLICATES" ]; then
    echo "⚠ Found duplicate user names:"
    echo "$DUPLICATES"
    echo ""
    echo "Remove or rename duplicate user accounts"
else
    echo "✓ No duplicate user names found"
fi
'''
        elif '6.2.7' == script_num:
            script += '''echo "Checks for duplicate group names."
echo ""

log_message "Starting remediation: Check duplicate group names"

DUPLICATES=$(awk -F: '{print $1}' /etc/group | sort | uniq -d)

if [ -n "$DUPLICATES" ]; then
    echo "⚠ Found duplicate group names:"
    echo "$DUPLICATES"
    echo ""
    echo "Remove or rename duplicate groups"
else
    echo "✓ No duplicate group names found"
fi
'''
        elif '6.2.8' == script_num:
            script += '''echo "Validates root PATH integrity."
echo ""

log_message "Starting remediation: Root PATH integrity"

ISSUE_FOUND=0

# Check for empty directory in PATH
if echo "$PATH" | grep -q "::"; then
    echo "⚠ Empty directory in PATH (::)"
    ISSUE_FOUND=1
fi

if echo "$PATH" | grep -q "^:"; then
    echo "⚠ PATH starts with empty directory"
    ISSUE_FOUND=1
fi

if echo "$PATH" | grep -q ":$"; then
    echo "⚠ PATH ends with empty directory"
    ISSUE_FOUND=1
fi

# Check for . in PATH
if echo "$PATH" | grep -q "\\."; then
    echo "⚠ Current directory (.) in PATH"
    ISSUE_FOUND=1
fi

# Check PATH directory permissions
IFS=: read -ra PATHS <<< "$PATH"
for dir in "${PATHS[@]}"; do
    if [ -d "$dir" ]; then
        # Check if world writable
        if [ "$(stat -c %a "$dir" | cut -c3)" -ge 2 ]; then
            echo "⚠ PATH directory $dir is world-writable"
            ISSUE_FOUND=1
        fi
        
        # Check if not owned by root
        if [ "$(stat -c %U "$dir")" != "root" ]; then
            echo "⚠ PATH directory $dir is not owned by root"
            ISSUE_FOUND=1
        fi
    fi
done

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ Root PATH integrity validated"
else
    echo ""
    echo "Fix PATH issues in /root/.bash_profile and /root/.bashrc"
fi
'''
        elif '6.2.9' == script_num:
            script += '''echo "Ensures root is the only UID 0 account."
echo ""

log_message "Starting remediation: Check UID 0 accounts"

UID0_ACCOUNTS=$(awk -F: '($3 == 0 && $1 != "root") {print $1}' /etc/passwd)

if [ -n "$UID0_ACCOUNTS" ]; then
    echo "⚠ Found UID 0 accounts other than root:"
    echo "$UID0_ACCOUNTS"
    echo ""
    echo "Remove these accounts or change their UID:"
    echo "  userdel <username>"
    echo "  or"
    echo "  usermod -u <new-uid> <username>"
else
    echo "✓ Root is the only UID 0 account"
fi
'''
        elif '6.2.10' == script_num:
            script += '''echo "Validates local interactive user home directories."
echo ""

log_message "Starting remediation: Check user home directories"

ISSUE_FOUND=0

# Check users with UID >= 1000 (interactive users)
while IFS=: read -r username password uid gid comment home shell; do
    if [ "$uid" -ge 1000 ] && [ "$username" != "nfsnobody" ]; then
        # Check if home directory exists
        if [ ! -d "$home" ]; then
            echo "⚠ User $username home directory $home does not exist"
            ISSUE_FOUND=1
        else
            # Check ownership
            owner=$(stat -c %U "$home")
            if [ "$owner" != "$username" ]; then
                echo "⚠ User $username home directory $home is owned by $owner"
                echo "  Fixing ownership..."
                chown "$username" "$home"
            fi
            
            # Check permissions (should not be group or world writable)
            perms=$(stat -c %a "$home")
            if [ "$((perms & 022))" -ne 0 ]; then
                echo "⚠ User $username home directory $home has insecure permissions ($perms)"
                echo "  Fixing permissions..."
                chmod go-w "$home"
            fi
        fi
    fi
done < /etc/passwd

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ All user home directories are properly configured"
else
    echo ""
    echo "Create missing home directories with: mkhomedir_helper <username>"
fi
'''
        elif '6.2.11' == script_num:
            script += '''echo "Configures local interactive user dot files access."
echo ""

log_message "Starting remediation: Check user dot files"

# Check users with UID >= 1000 (interactive users)
while IFS=: read -r username password uid gid comment home shell; do
    if [ "$uid" -ge 1000 ] && [ "$username" != "nfsnobody" ] && [ -d "$home" ]; then
        # Check dot files in home directory
        for file in "$home"/.*; do
            if [ -f "$file" ]; then
                filename=$(basename "$file")
                
                # Skip . and ..
                if [ "$filename" = "." ] || [ "$filename" = ".." ]; then
                    continue
                fi
                
                # Check ownership
                owner=$(stat -c %U "$file")
                if [ "$owner" != "$username" ]; then
                    echo "⚠ $username dot file $file is owned by $owner"
                    echo "  Fixing ownership..."
                    chown "$username" "$file"
                fi
                
                # Check if group or world writable
                perms=$(stat -c %a "$file")
                if [ "$((perms & 022))" -ne 0 ]; then
                    echo "⚠ $username dot file $file has insecure permissions ($perms)"
                    echo "  Fixing permissions..."
                    chmod go-w "$file"
                fi
            fi
        done
        
        # Check .netrc specifically (should be 0600)
        if [ -f "$home/.netrc" ]; then
            perms=$(stat -c %a "$home/.netrc")
            if [ "$perms" != "600" ]; then
                echo "⚠ $username .netrc has insecure permissions ($perms)"
                echo "  Setting permissions to 0600..."
                chmod 0600 "$home/.netrc"
            fi
        fi
    fi
done < /etc/passwd

echo "✓ User dot files checked and secured"
'''
    
    # Add footer
    script += '''
log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
'''
    
    filename = f"section6_scripts/{script_num}.sh"
    with open(filename, 'w') as f:
        f.write(script)
    
    scripts_created.append(script_num)
    print(f"✓ Created: {script_num}.sh")

print(f"\n" + "=" * 100)
print(f"Successfully generated all {len(scripts_created)} Section 6 scripts!")
print("=" * 100)
