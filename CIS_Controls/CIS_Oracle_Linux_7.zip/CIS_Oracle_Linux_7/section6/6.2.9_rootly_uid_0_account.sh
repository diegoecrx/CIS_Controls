#!/bin/bash

SCRIPT_NAME="6.2.9_rootly_uid_0_account.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_uid0_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.9 - Ensure root is the only UID 0 account"
    echo ""
    echo "WARNING: Multiple UID 0 accounts bypass access controls and auditing!"
    echo ""

    log_message "INFO" "Starting UID 0 audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.9 UID 0 Accounts Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies all accounts with UID 0 (superuser privileges).

EOF

    echo "Checking for UID 0 accounts..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    UID0_ACCOUNTS=0
    NON_ROOT_UID0=""

    # Read /etc/passwd and check for UID 0 accounts
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Check for UID 0
        if [ "$uid" = "0" ]; then
            if [ "$username" = "root" ]; then
                echo "[OK] root account has UID 0 (expected)" | tee -a "$AUDIT_REPORT"
            else
                echo "[CRITICAL] $username has UID 0 (unauthorized superuser account)" | tee -a "$AUDIT_REPORT"
                echo "  Home directory: $homedir" | tee -a "$AUDIT_REPORT"
                echo "  Shell: $shell" | tee -a "$AUDIT_REPORT"
                echo "  Comment: $comment" | tee -a "$AUDIT_REPORT"
                echo "" | tee -a "$AUDIT_REPORT"
                NON_ROOT_UID0="$NON_ROOT_UID0 $username"
                ((UID0_ACCOUNTS++))
            fi
        fi
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Non-root UID 0 accounts found: $UID0_ACCOUNTS

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Non-root UID 0 accounts: $UID0_ACCOUNTS"
    echo ""

    if [ $UID0_ACCOUNTS -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "Only root has UID 0"
        log_message "SUCCESS" "Only root has UID 0"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT - CRITICAL SECURITY ISSUE"
        echo "$UID0_ACCOUNTS unauthorized UID 0 account(s) found"
        echo ""
        echo "Accounts with UID 0:$NON_ROOT_UID0"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "ERROR" "Found $UID0_ACCOUNTS unauthorized UID 0 accounts"
    fi

    # Ask if user wants to remediate
    echo ""
    echo "CRITICAL SECURITY WARNING:"
    echo "=========================="
    echo "Accounts with UID 0 have FULL SUPERUSER PRIVILEGES:"
    echo "  - Complete root access to the system"
    echo "  - Bypass all access controls and auditing"
    echo "  - Can modify any file or process"
    echo "  - Actions may be logged under different usernames"
    echo ""
    echo "These accounts must be addressed immediately!"
    echo ""
    echo "Remediation Options:"
    echo "  1) Lock the accounts (disable login while preserving data)"
    echo "  2) Delete the accounts (PERMANENT - removes user data)"
    echo "  3) Change UID to a unique value (convert to regular user)"
    echo "  4) Exit without changes (NOT RECOMMENDED)"
    echo ""
    read -p "Enter choice [1-4] (default: 1): " CHOICE
    CHOICE=${CHOICE:-1}

    if [ "$CHOICE" = "1" ]; then
        echo ""
        echo "Locking UID 0 accounts (disabling login)..."
        echo ""
        
        LOCKED=0
        FAILED=0
        
        for username in $NON_ROOT_UID0; do
            [ -z "$username" ] && continue
            
            echo "Locking account: $username"
            
            # Lock the account (prevents login)
            if passwd -l "$username" 2>/dev/null; then
                echo "  Password locked"
                
                # Also disable shell
                if usermod -s /sbin/nologin "$username" 2>/dev/null; then
                    echo "  Shell changed to /sbin/nologin"
                    echo "  Account successfully locked"
                    log_message "SUCCESS" "Locked UID 0 account: $username"
                    ((LOCKED++))
                else
                    echo "  WARNING: Password locked but shell change failed"
                    log_message "WARNING" "Partially locked UID 0 account: $username"
                    ((LOCKED++))
                fi
            else
                echo "  ERROR: Failed to lock account"
                log_message "ERROR" "Failed to lock UID 0 account: $username"
                ((FAILED++))
            fi
            echo ""
        done
        
        echo "Remediation Summary:"
        echo "  Locked: $LOCKED"
        echo "  Failed: $FAILED"
        echo ""
        echo "IMPORTANT: Locked accounts still exist but cannot log in."
        echo "To completely remove, use option 2."
        log_message "SUCCESS" "Locked $LOCKED UID 0 accounts"
        
    elif [ "$CHOICE" = "2" ]; then
        echo ""
        echo "DANGER: This will PERMANENTLY DELETE the accounts!"
        echo ""
        read -p "Are you absolutely sure? Type 'DELETE' to confirm: " CONFIRM
        
        if [ "$CONFIRM" = "DELETE" ]; then
            echo ""
            echo "Deleting UID 0 accounts..."
            echo ""
            
            DELETED=0
            FAILED=0
            
            for username in $NON_ROOT_UID0; do
                [ -z "$username" ] && continue
                
                echo "Deleting account: $username"
                
                # Backup passwd and shadow entries
                BACKUP_FILE="$BACKUP_DIR/uid0_${username}_$(date +%Y%m%d_%H%M%S).backup"
                grep "^${username}:" /etc/passwd > "$BACKUP_FILE"
                grep "^${username}:" /etc/shadow >> "$BACKUP_FILE" 2>/dev/null
                echo "  Backed up to: $BACKUP_FILE"
                
                # Delete the user (with home directory)
                if userdel -r "$username" 2>/dev/null; then
                    echo "  Account and home directory deleted"
                    log_message "SUCCESS" "Deleted UID 0 account: $username"
                    ((DELETED++))
                else
                    # Try without removing home directory
                    if userdel "$username" 2>/dev/null; then
                        echo "  Account deleted (home directory preserved)"
                        log_message "SUCCESS" "Deleted UID 0 account: $username (home preserved)"
                        ((DELETED++))
                    else
                        echo "  ERROR: Failed to delete account"
                        log_message "ERROR" "Failed to delete UID 0 account: $username"
                        ((FAILED++))
                    fi
                fi
                echo ""
            done
            
            echo "Remediation Summary:"
            echo "  Deleted: $DELETED"
            echo "  Failed: $FAILED"
            log_message "SUCCESS" "Deleted $DELETED UID 0 accounts"
        else
            echo ""
            echo "Deletion cancelled."
        fi
        
    elif [ "$CHOICE" = "3" ]; then
        echo ""
        echo "Changing UID to unique values..."
        echo ""
        
        CHANGED=0
        FAILED=0
        
        for username in $NON_ROOT_UID0; do
            [ -z "$username" ] && continue
            
            echo "Processing account: $username"
            
            # Find next available UID (starting from 1000 for regular users)
            NEW_UID=1000
            while getent passwd $NEW_UID > /dev/null 2>&1; do
                ((NEW_UID++))
            done
            
            echo "  New UID will be: $NEW_UID"
            read -p "  Change UID for $username to $NEW_UID? [y/N]: " CONFIRM
            
            if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
                # Change UID (also updates file ownership in home directory)
                if usermod -u "$NEW_UID" "$username" 2>/dev/null; then
                    echo "  UID changed to $NEW_UID"
                    log_message "SUCCESS" "Changed UID for $username from 0 to $NEW_UID"
                    ((CHANGED++))
                    
                    # Find and update files owned by old UID outside home directory
                    echo "  Searching for files owned by UID 0 outside home directory..."
                    HOME_DIR=$(getent passwd "$username" | cut -d: -f6)
                    find / -path "$HOME_DIR" -prune -o -uid 0 -user "$username" -exec chown "$NEW_UID" {} \; 2>/dev/null &
                    echo "  Background process started to update file ownership"
                else
                    echo "  ERROR: Failed to change UID"
                    log_message "ERROR" "Failed to change UID for $username"
                    ((FAILED++))
                fi
            else
                echo "  Skipped"
            fi
            echo ""
        done
        
        echo "Remediation Summary:"
        echo "  Changed: $CHANGED"
        echo "  Failed: $FAILED"
        log_message "SUCCESS" "Changed UID for $CHANGED accounts"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "WARNING: UID 0 accounts remain - CRITICAL SECURITY RISK!"
        echo ""
        echo "To manually lock an account:"
        echo "  passwd -l username"
        echo "  usermod -s /sbin/nologin username"
        echo ""
        echo "To manually delete an account:"
        echo "  userdel -r username"
        echo ""
        echo "To manually change UID:"
        echo "  usermod -u newuid username"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. Only the root account should have UID 0"
    echo "2. Multiple UID 0 accounts bypass security controls and auditing"
    echo "3. Actions by non-root UID 0 accounts may be logged as 'root'"
    echo "4. This makes accountability and forensics impossible"
    echo "5. Legitimate admin access should use sudo, not UID 0 accounts"
    echo "6. Backups are saved in: $BACKUP_DIR"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
