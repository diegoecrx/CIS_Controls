#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.6.sh
# CIS Control - 6.2.6 Ensure no duplicate user names exist (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.6.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.6 Ensure no duplicate user names exist (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Checks for duplicate user names."
echo ""

log_message "Starting remediation: Check duplicate usernames"

DUPLICATES=$(awk -F: '{print $1}' /etc/passwd | sort | uniq -d)

if [ -n "$DUPLICATES" ]; then
    echo "⚠ Found duplicate user names:"
    echo "$DUPLICATES"
    echo ""
    echo "Remove or rename duplicate user accounts"
else
    echo "✓ No duplicate user names found"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
