#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.3.sh
# CIS Control - 6.2.3 Ensure all groups in /etc/passwd exist in /etc/group (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.3.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.3 Ensure all groups in /etc/passwd exist in /etc/group (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Validates all groups in /etc/passwd exist in /etc/group."
echo ""

log_message "Starting remediation: Validate groups"

ISSUE_FOUND=0

while IFS=: read -r username password uid gid comment home shell; do
    if ! grep -q "^[^:]*:[^:]*:$gid:" /etc/group; then
        echo "⚠ User $username (UID: $uid) has GID $gid which does not exist in /etc/group"
        ISSUE_FOUND=1
    fi
done < /etc/passwd

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ All groups in /etc/passwd exist in /etc/group"
else
    echo ""
    echo "Create missing groups or assign users to existing groups"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
