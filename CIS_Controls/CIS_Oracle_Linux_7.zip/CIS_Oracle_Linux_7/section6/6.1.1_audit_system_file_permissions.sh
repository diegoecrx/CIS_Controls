#!/bin/bash

SCRIPT_NAME="6.1.1_audit_system_file_permissions.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_file_permissions_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.1.1 - Audit system file permissions"
    echo ""
    echo "NOTE: This is an AUDIT control, not a remediation control"
    echo "This script will identify files with incorrect permissions"
    echo "but will NOT automatically fix them."
    echo ""

    log_message "INFO" "Starting file permissions audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.1.1 File Permissions Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies files where current permissions differ from
package database expectations. Review findings carefully before making
any changes, as some differences may be intentional.

EOF

    echo "Running package verification..."
    echo "This may take several minutes depending on the number of installed packages..."
    echo ""

    echo "Checking for permission and ownership discrepancies..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    # Create temporary file to store rpm output
    TEMP_RPM_OUTPUT=$(mktemp)
    
    # Run rpm verification
    rpm -Va 2>/dev/null > "$TEMP_RPM_OUTPUT"

    # Process the output
    while IFS= read -r line; do
        # Skip empty lines
        [ -z "$line" ] && continue
        
        # Extract the verification flags (first 9 characters) and filename (from position 13)
        FLAGS="${line:0:9}"
        FILE="${line:13}"
        
        # Check if Mode (permissions) differs - position 2
        if [ "${FLAGS:2:1}" = "M" ]; then
            echo "[PERMISSION] $FILE" >> "$AUDIT_REPORT"
        fi
        
        # Check if User ownership differs - position 4
        if [ "${FLAGS:4:1}" = "U" ]; then
            echo "[OWNERSHIP-USER] $FILE" >> "$AUDIT_REPORT"
        fi
        
        # Check if Group ownership differs - position 5
        if [ "${FLAGS:5:1}" = "G" ]; then
            echo "[OWNERSHIP-GROUP] $FILE" >> "$AUDIT_REPORT"
        fi
    done < "$TEMP_RPM_OUTPUT"

    # Clean up temp file
    rm -f "$TEMP_RPM_OUTPUT"

    # Count findings
    PERMISSION_COUNT=0
    OWNERSHIP_USER_COUNT=0
    OWNERSHIP_GROUP_COUNT=0
    
    if grep -q "^\[PERMISSION\]" "$AUDIT_REPORT" 2>/dev/null; then
        PERMISSION_COUNT=$(grep -c "^\[PERMISSION\]" "$AUDIT_REPORT")
    fi
    
    if grep -q "^\[OWNERSHIP-USER\]" "$AUDIT_REPORT" 2>/dev/null; then
        OWNERSHIP_USER_COUNT=$(grep -c "^\[OWNERSHIP-USER\]" "$AUDIT_REPORT")
    fi
    
    if grep -q "^\[OWNERSHIP-GROUP\]" "$AUDIT_REPORT" 2>/dev/null; then
        OWNERSHIP_GROUP_COUNT=$(grep -c "^\[OWNERSHIP-GROUP\]" "$AUDIT_REPORT")
    fi
    
    TOTAL_COUNT=$((PERMISSION_COUNT + OWNERSHIP_USER_COUNT + OWNERSHIP_GROUP_COUNT))

    # Display findings to console
    if [ $TOTAL_COUNT -gt 0 ]; then
        echo "Sample findings (first 20):"
        grep "^\[" "$AUDIT_REPORT" | head -20
        if [ $TOTAL_COUNT -gt 20 ]; then
            echo "... ($(($TOTAL_COUNT - 20)) more findings in report)"
        fi
        echo ""
    fi

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Permission issues found: $PERMISSION_COUNT
User ownership issues found: $OWNERSHIP_USER_COUNT
Group ownership issues found: $OWNERSHIP_GROUP_COUNT
Total issues found: $TOTAL_COUNT

EOF

    # Display summary
    echo "Audit Summary:"
    echo "=============="
    echo "Permission issues found: $PERMISSION_COUNT"
    echo "User ownership issues found: $OWNERSHIP_USER_COUNT"
    echo "Group ownership issues found: $OWNERSHIP_GROUP_COUNT"
    echo "Total issues found: $TOTAL_COUNT"
    echo ""

    if [ $TOTAL_COUNT -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "No file permission or ownership discrepancies found"
        log_message "SUCCESS" "Audit complete - no issues found"
    else
        echo "Status: REVIEW REQUIRED"
        echo "File permission or ownership discrepancies were found"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Audit found $TOTAL_COUNT issues - review required"
    fi

    # Provide guidance
    echo ""
    echo "Next Steps:"
    echo "==========="
    echo "1. Review the detailed audit report: $AUDIT_REPORT"
    echo "2. For each finding, determine if it requires remediation"
    echo "3. To restore original permissions for a package:"
    echo "   rpm --setperms <package-name>"
    echo "   rpm --setugids <package-name>"
    echo "4. To identify which package owns a file:"
    echo "   rpm -qf /path/to/file"
    echo ""
    echo "IMPORTANT: This is an AUDIT control - review findings before taking action!"
    echo ""

    # Additional checks for critical files with NUMERIC comparison
    echo "Critical System File Checks:"
    echo "============================" | tee -a "$AUDIT_REPORT"

    # Define critical files with expected permissions
    declare -A CRITICAL_FILES
    CRITICAL_FILES["/etc/passwd"]="644"
    CRITICAL_FILES["/etc/shadow"]="0"
    CRITICAL_FILES["/etc/group"]="644"
    CRITICAL_FILES["/etc/gshadow"]="0"
    CRITICAL_FILES["/etc/ssh/sshd_config"]="600"

    CRITICAL_ISSUES=0
    
    for FILE in "${!CRITICAL_FILES[@]}"; do
        EXPECTED_PERMS="${CRITICAL_FILES[$FILE]}"
        
        if [ -f "$FILE" ]; then
            ACTUAL_PERMS=$(stat -c '%a' "$FILE" 2>/dev/null)
            
            # Convert both to decimal for proper comparison (handle leading zeros)
            ACTUAL_DEC=$((8#$ACTUAL_PERMS))
            EXPECTED_DEC=$((8#$EXPECTED_PERMS))
            
            if [ $ACTUAL_DEC -ne $EXPECTED_DEC ]; then
                echo "[CRITICAL] $FILE: $ACTUAL_PERMS (expected $EXPECTED_PERMS)" | tee -a "$AUDIT_REPORT"
                log_message "WARNING" "Critical file $FILE has unexpected permissions"
                ((CRITICAL_ISSUES++))
            else
                echo "[OK] $FILE: $ACTUAL_PERMS" | tee -a "$AUDIT_REPORT"
            fi
        fi
    done

    echo ""
    
    if [ $CRITICAL_ISSUES -gt 0 ]; then
        echo "WARNING: $CRITICAL_ISSUES critical file(s) have unexpected permissions"
        echo "Review and remediate immediately!"
    else
        echo "All critical system files have correct permissions"
    fi

    echo ""
    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
