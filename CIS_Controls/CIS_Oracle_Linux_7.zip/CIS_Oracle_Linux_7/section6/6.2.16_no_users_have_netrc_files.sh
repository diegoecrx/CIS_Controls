#!/bin/bash

SCRIPT_NAME="6.2.16_no_users_have_netrc_files.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_REPORT="/var/log/cis_netrc_files_audit_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 6.2.16 - Ensure no users have .netrc files"
    echo ""
    echo "WARNING: .netrc files store credentials in PLAINTEXT!"
    echo ""

    log_message "INFO" "Starting .netrc files audit"

    # Create audit report header
    cat > "$AUDIT_REPORT" << EOF
CIS 6.2.16 .netrc Files Audit Report
Generated: $(date)
System: $(hostname)
========================================

This report identifies users with .netrc files containing plaintext credentials.

EOF

    echo "Checking for .netrc files..." | tee -a "$AUDIT_REPORT"
    echo "" | tee -a "$AUDIT_REPORT"

    NETRC_FILES_FOUND=0
    USERS_CHECKED=0

    # Read /etc/passwd and check for .netrc files
    while IFS=: read -r username password uid gid comment homedir shell; do
        # Skip empty lines
        [ -z "$username" ] && continue
        
        # Skip system users with UID < 1000 (except root)
        if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
            continue
        fi
        
        # Skip if home directory doesn't exist
        if [ ! -d "$homedir" ]; then
            continue
        fi
        
        ((USERS_CHECKED++))
        
        # Check for .netrc file
        NETRC_FILE="$homedir/.netrc"
        
        if [ -f "$NETRC_FILE" ]; then
            # Get file permissions
            PERMS=$(stat -c '%a' "$NETRC_FILE" 2>/dev/null)
            
            echo "[FOUND] User: $username - .netrc exists: $NETRC_FILE (permissions: $PERMS)" | tee -a "$AUDIT_REPORT"
            
            # Check if permissions are too permissive
            PERMS_DEC=$((8#$PERMS))
            GROUP_PERMS=$(((PERMS_DEC / 8) % 8))
            OTHER_PERMS=$((PERMS_DEC % 8))
            
            if [ $GROUP_PERMS -gt 0 ] || [ $OTHER_PERMS -gt 0 ]; then
                echo "  WARNING: Permissions too permissive! Group/others can read credentials." | tee -a "$AUDIT_REPORT"
            fi
            
            # Show number of credential entries (count "machine" directives)
            ENTRIES=$(grep -c "^machine" "$NETRC_FILE" 2>/dev/null || echo 0)
            echo "  Credential entries: $ENTRIES" | tee -a "$AUDIT_REPORT"
            
            # Show machines (without passwords)
            echo "  Machines configured:" | tee -a "$AUDIT_REPORT"
            grep "^machine" "$NETRC_FILE" 2>/dev/null | awk '{print "    - " $2}' | tee -a "$AUDIT_REPORT"
            echo "" | tee -a "$AUDIT_REPORT"
            
            ((NETRC_FILES_FOUND++))
        fi
        
    done < /etc/passwd

    # Append summary to report
    cat >> "$AUDIT_REPORT" << EOF

========================================
AUDIT SUMMARY
========================================
Users checked: $USERS_CHECKED
.netrc files found: $NETRC_FILES_FOUND

EOF

    # Display summary
    echo ""
    echo "Audit Summary:"
    echo "=============="
    echo "Users checked: $USERS_CHECKED"
    echo ".netrc files found: $NETRC_FILES_FOUND"
    echo ""

    if [ $NETRC_FILES_FOUND -eq 0 ]; then
        echo "Status: COMPLIANT"
        echo "No .netrc files found"
        log_message "SUCCESS" "No .netrc files present"
        echo ""
        log_message "SUCCESS" "Audit completed successfully"
        return 0
    else
        echo "Status: NON-COMPLIANT"
        echo "$NETRC_FILES_FOUND .netrc file(s) found containing plaintext credentials"
        echo ""
        echo "Detailed audit report saved to: $AUDIT_REPORT"
        log_message "WARNING" "Found $NETRC_FILES_FOUND .netrc files with plaintext credentials"
    fi

    # Ask if user wants to remove .netrc files
    echo ""
    echo "CRITICAL SECURITY WARNING:"
    echo "=========================="
    echo ".netrc files store FTP/HTTP credentials in PLAINTEXT"
    echo "This is a SERIOUS security vulnerability!"
    echo ""
    echo "Removing .netrc files will break automated FTP/HTTP authentication."
    echo "Users should migrate to more secure authentication methods."
    echo ""
    echo "Options:"
    echo "  1) Backup and remove all .netrc files (recommended)"
    echo "  2) Review each .netrc file individually"
    echo "  3) Exit without making changes"
    echo ""
    read -p "Enter choice [1-3] (default: 3): " CHOICE
    CHOICE=${CHOICE:-3}

    if [ "$CHOICE" = "1" ]; then
        echo ""
        echo "Backing up and removing .netrc files..."
        echo ""
        
        REMOVED=0
        FAILED=0
        
        # Re-scan and remove .netrc files
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            NETRC_FILE="$homedir/.netrc"
            
            if [ -f "$NETRC_FILE" ]; then
                echo "Processing: $NETRC_FILE"
                
                # Backup the file
                BACKUP_FILE="$BACKUP_DIR/netrc_${username}_$(date +%Y%m%d_%H%M%S).backup"
                if cp "$NETRC_FILE" "$BACKUP_FILE" 2>/dev/null; then
                    echo "  Backed up to: $BACKUP_FILE"
                    
                    # Secure the backup with restrictive permissions
                    chmod 600 "$BACKUP_FILE" 2>/dev/null
                    
                    # Remove the file
                    if rm "$NETRC_FILE" 2>/dev/null; then
                        echo "  Removed: $NETRC_FILE"
                        log_message "SUCCESS" "Removed .netrc for $username"
                        ((REMOVED++))
                    else
                        echo "  ERROR: Failed to remove"
                        log_message "ERROR" "Failed to remove .netrc for $username"
                        ((FAILED++))
                    fi
                else
                    echo "  ERROR: Failed to backup"
                    log_message "ERROR" "Failed to backup .netrc for $username"
                    ((FAILED++))
                fi
            fi
        done < /etc/passwd
        
        echo ""
        echo "Removal Summary:"
        echo "  Removed: $REMOVED"
        echo "  Failed: $FAILED"
        echo "  Backups location: $BACKUP_DIR"
        echo "  Backup permissions: 600 (secured)"
        log_message "SUCCESS" "Removed $REMOVED .netrc files, $FAILED failures"
        
    elif [ "$CHOICE" = "2" ]; then
        echo ""
        echo "Reviewing .netrc files individually..."
        echo ""
        
        REMOVED=0
        KEPT=0
        
        while IFS=: read -r username password uid gid comment homedir shell; do
            [ -z "$username" ] && continue
            
            if [ "$uid" -lt 1000 ] && [ "$uid" -ne 0 ]; then
                continue
            fi
            
            if [ ! -d "$homedir" ]; then
                continue
            fi
            
            NETRC_FILE="$homedir/.netrc"
            
            if [ -f "$NETRC_FILE" ]; then
                echo "================================"
                echo "User: $username"
                echo "File: $NETRC_FILE"
                echo "Permissions: $(stat -c '%a' "$NETRC_FILE")"
                echo ""
                echo "Configured machines:"
                grep "^machine" "$NETRC_FILE" 2>/dev/null | awk '{print "  - " $2}'
                echo ""
                
                read -p "Remove this .netrc file? [y/N]: " REMOVE
                
                if [ "$REMOVE" = "y" ] || [ "$REMOVE" = "Y" ]; then
                    BACKUP_FILE="$BACKUP_DIR/netrc_${username}_$(date +%Y%m%d_%H%M%S).backup"
                    cp "$NETRC_FILE" "$BACKUP_FILE" 2>/dev/null
                    chmod 600 "$BACKUP_FILE" 2>/dev/null
                    
                    if rm "$NETRC_FILE" 2>/dev/null; then
                        echo "Removed (backed up to: $BACKUP_FILE)"
                        log_message "SUCCESS" "Removed .netrc for $username"
                        ((REMOVED++))
                    else
                        echo "ERROR: Failed to remove"
                        ((FAILED++))
                    fi
                else
                    echo "Kept"
                    ((KEPT++))
                fi
                echo ""
            fi
        done < /etc/passwd
        
        echo "Review Summary:"
        echo "  Removed: $REMOVED"
        echo "  Kept: $KEPT"
        log_message "SUCCESS" "Reviewed and removed $REMOVED .netrc files"
        
    else
        echo ""
        echo "No changes made."
        echo ""
        echo "To manually remove a .netrc file:"
        echo "  rm /home/username/.netrc"
        echo ""
    fi

    echo ""
    echo "IMPORTANT NOTES:"
    echo "================"
    echo "1. .netrc files store FTP/HTTP credentials in PLAINTEXT"
    echo "2. Security risks include:"
    echo "   - Credential exposure if file permissions are weak"
    echo "   - Plaintext password storage (no encryption)"
    echo "   - Potential for credential theft"
    echo "   - Violation of security policies requiring encrypted credentials"
    echo "3. Secure alternatives:"
    echo "   - SSH keys for automated file transfers"
    echo "   - Credential managers or vaults"
    echo "   - Application-specific authentication tokens"
    echo "4. Backups are secured with 600 permissions in: $BACKUP_DIR"
    echo ""

    log_message "SUCCESS" "Audit completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
