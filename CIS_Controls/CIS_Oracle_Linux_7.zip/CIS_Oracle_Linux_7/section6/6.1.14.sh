#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.1.14.sh
# CIS Control - 6.1.14 Audit system file permissions (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.1.14.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Manual Remediation: $SCRIPT_NAME"
echo "6.1.14 Audit system file permissions (Manual)"
echo "=============================================="
echo ""
echo "Description:"
echo "Manual audit: System file permissions."
echo ""

log_message "Manual remediation: Audit file permissions"

echo "Auditing important system file permissions..."
echo ""

for file in /etc/passwd /etc/shadow /etc/group /etc/gshadow \
            /etc/passwd- /etc/shadow- /etc/group- /etc/gshadow- \
            /etc/ssh/sshd_config /etc/sudoers /boot/grub2/grub.cfg; do
    if [ -f "$file" ]; then
        ls -l "$file"
    fi
done

echo ""
echo "Review the permissions above and compare with CIS Benchmark requirements"
echo "✓ System file permissions audit complete"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
