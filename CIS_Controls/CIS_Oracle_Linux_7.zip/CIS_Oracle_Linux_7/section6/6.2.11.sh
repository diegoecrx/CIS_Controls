#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.11.sh
# CIS Control - 6.2.11 Ensure local interactive user dot files access is configured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.11.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.11 Ensure local interactive user dot files access is configured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Configures local interactive user dot files access."
echo ""

log_message "Starting remediation: Check user dot files"

# Check users with UID >= 1000 (interactive users)
while IFS=: read -r username password uid gid comment home shell; do
    if [ "$uid" -ge 1000 ] && [ "$username" != "nfsnobody" ] && [ -d "$home" ]; then
        # Check dot files in home directory
        for file in "$home"/.*; do
            if [ -f "$file" ]; then
                filename=$(basename "$file")

                # Skip . and ..
                if [ "$filename" = "." ] || [ "$filename" = ".." ]; then
                    continue
                fi

                # Check ownership
                owner=$(stat -c %U "$file")
                if [ "$owner" != "$username" ]; then
                    echo "⚠ $username dot file $file is owned by $owner"
                    echo "  Fixing ownership..."
                    chown "$username" "$file"
                fi

                # Check if group or world writable
                perms=$(stat -c %a "$file")
                if [ "$((perms & 022))" -ne 0 ]; then
                    echo "⚠ $username dot file $file has insecure permissions ($perms)"
                    echo "  Fixing permissions..."
                    chmod go-w "$file"
                fi
            fi
        done

        # Check .netrc specifically (should be 0600)
        if [ -f "$home/.netrc" ]; then
            perms=$(stat -c %a "$home/.netrc")
            if [ "$perms" != "600" ]; then
                echo "⚠ $username .netrc has insecure permissions ($perms)"
                echo "  Setting permissions to 0600..."
                chmod 0600 "$home/.netrc"
            fi
        fi
    fi
done < /etc/passwd

echo "✓ User dot files checked and secured"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
