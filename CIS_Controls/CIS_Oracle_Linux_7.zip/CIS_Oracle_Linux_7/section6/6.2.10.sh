#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.10.sh
# CIS Control - 6.2.10 Ensure local interactive user home directories are configured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.10.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.10 Ensure local interactive user home directories are configured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Validates local interactive user home directories."
echo ""

log_message "Starting remediation: Check user home directories"

ISSUE_FOUND=0

# Check users with UID >= 1000 (interactive users)
while IFS=: read -r username password uid gid comment home shell; do
    if [ "$uid" -ge 1000 ] && [ "$username" != "nfsnobody" ]; then
        # Check if home directory exists
        if [ ! -d "$home" ]; then
            echo "⚠ User $username home directory $home does not exist"
            ISSUE_FOUND=1
        else
            # Check ownership
            owner=$(stat -c %U "$home")
            if [ "$owner" != "$username" ]; then
                echo "⚠ User $username home directory $home is owned by $owner"
                echo "  Fixing ownership..."
                chown "$username" "$home"
            fi

            # Check permissions (should not be group or world writable)
            perms=$(stat -c %a "$home")
            if [ "$((perms & 022))" -ne 0 ]; then
                echo "⚠ User $username home directory $home has insecure permissions ($perms)"
                echo "  Fixing permissions..."
                chmod go-w "$home"
            fi
        fi
    fi
done < /etc/passwd

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ All user home directories are properly configured"
else
    echo ""
    echo "Create missing home directories with: mkhomedir_helper <username>"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
