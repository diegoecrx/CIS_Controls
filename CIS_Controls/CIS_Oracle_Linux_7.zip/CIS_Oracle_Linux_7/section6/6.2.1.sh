#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.1.sh
# CIS Control - 6.2.1 Ensure accounts in /etc/passwd use shadowed passwords (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.1.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.1 Ensure accounts in /etc/passwd use shadowed passwords (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures accounts use shadowed passwords."
echo ""

log_message "Starting remediation: Shadowed passwords"

ISSUE_FOUND=0

while IFS=: read -r username password uid gid comment home shell; do
    if [ "$password" != "x" ]; then
        echo "⚠ User $username does not use shadowed password"
        ISSUE_FOUND=1
    fi
done < /etc/passwd

if [ $ISSUE_FOUND -eq 0 ]; then
    echo "✓ All accounts use shadowed passwords"
else
    echo ""
    echo "To fix, run: pwconv"
    echo "This will move passwords to /etc/shadow"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
