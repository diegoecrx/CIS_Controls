
import pandas as pd
import zipfile
import os

df = pd.read_csv('section6_remediation_data.csv')

# Create summary CSV for Section 6
summary_data = []
for idx, row in df.iterrows():
    script_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    summary_data.append({
        'Script': f"{row['script_name']}.sh",
        'Control': row['control_name'],
        'Type': script_type,
        'Profile': 'Level 1 - Server & Workstation'
    })

summary_df = pd.DataFrame(summary_data)
summary_df.to_csv('section6_scripts/Section6_Script_Summary.csv', index=False)

# Create comprehensive README
readme_content = '''# CIS Oracle Linux 7 Benchmark Remediation Scripts - Section 6

## Overview
This archive contains 25 bash remediation scripts for CIS Oracle Linux 7 Benchmark v4.0.0 Section 6 (System Maintenance).

## Contents
- 25 remediation scripts (6.1.1.sh through 6.2.11.sh)
- Original spreadsheet with remediation details
- Script summary CSV

## Script Categories

### 6.1.x - System File Permissions (14 scripts)
Critical system file permission controls:
- /etc/passwd, /etc/passwd- (0644)
- /etc/group, /etc/group- (0644)
- /etc/shadow, /etc/shadow- (0000)
- /etc/gshadow, /etc/gshadow- (0000)
- /etc/shells (0644)
- /etc/security/opasswd (0600)
- World-writable file security
- Unowned/ungrouped file detection
- SUID/SGID file review (Manual)
- System file permission audit (Manual)

### 6.2.x - Local User and Group Settings (11 scripts)
User account integrity controls:
- Shadowed password verification
- Empty password detection
- Group validation
- Duplicate UID/GID detection
- Duplicate username/group name detection
- Root PATH integrity
- UID 0 account validation
- Home directory configuration
- Dot file permissions

## Usage

### Prerequisites
- Oracle Linux 7
- Root privileges
- Bash shell

### Running Scripts

1. Extract the archive:
   ```bash
   unzip CIS_Oracle_Linux_7_Section6_Remediation_Scripts.zip
   cd section6_scripts
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Run individual scripts:
   ```bash
   sudo ./6.1.1.sh
   ```

4. Run by category:
   ```bash
   # System file permissions
   for script in 6.1.*.sh; do sudo ./$script; done
   
   # User and group settings
   for script in 6.2.*.sh; do sudo ./$script; done
   ```

### Important Notes

1. **Backup your system** before running remediation scripts
2. **Test in non-production** environments first
3. Some scripts perform **filesystem scans** which take time
4. Scripts create backups in `/tmp/cis_backup/`
5. Logs are written to `/var/log/cis_remediation.log`

### Script Features

Each script includes:
- Root privilege check
- Backup functionality (one backup per day per file)
- Action execution
- Validation checks
- Comprehensive logging
- Error handling

### Script Types

- **Automated (23 scripts)**: Executes remediation automatically
- **Manual (2 scripts)**: 
  - 6.1.13 - SUID/SGID file review
  - 6.1.14 - System file permission audit

### Backup Location
- `/tmp/cis_backup/` - Contains backups of modified files with timestamps

### Log Files
- `/var/log/cis_remediation.log` - General execution log
- `/var/log/cis_error.log` - Error messages

## Critical File Permissions

Section 6 enforces strict permissions on security-critical files:

### Password and Group Files
```
/etc/passwd       0644 root:root
/etc/passwd-      0644 root:root
/etc/group        0644 root:root
/etc/group-       0644 root:root
/etc/shadow       0000 root:root  # No permissions!
/etc/shadow-      0000 root:root
/etc/gshadow      0000 root:root
/etc/gshadow-     0000 root:root
/etc/shells       0644 root:root
/etc/security/opasswd  0600 root:root
```

**Note**: Shadow files (0000) are extremely restrictive - only root can access.

## World-Writable Files (6.1.11)

This script:
1. Finds all world-writable files
2. Removes world-write permission
3. Adds sticky bit to world-writable directories

**Time**: May take several minutes on large filesystems.

```bash
# Manual check
find / -xdev -type f -perm -0002 2>/dev/null
```

## Unowned Files (6.1.12)

Detects files without valid user or group ownership:
- Often left behind from removed packages
- Security risk (can be claimed by any user)

**Action Required**: 
- Assign to appropriate user/group
- Delete if not needed

## SUID/SGID Files (6.1.13 - Manual)

Lists all SUID and SGID binaries:
- **SUID**: Runs with owner's privileges
- **SGID**: Runs with group's privileges

**Review carefully**:
- Verify each is necessary
- Remove SUID/SGID from unnecessary files
- Common legitimate SUID: passwd, sudo, su, mount

```bash
# Find SUID files
find / -xdev -type f -perm -4000 2>/dev/null

# Remove SUID if not needed
chmod u-s /path/to/file
```

## User Account Validation

### Duplicate Detection (6.2.4-6.2.7)
Scripts detect:
- Duplicate UIDs
- Duplicate GIDs
- Duplicate usernames
- Duplicate group names

**Fix duplicates** by reassigning unique values:
```bash
usermod -u <new-uid> <username>
groupmod -g <new-gid> <groupname>
```

### Root PATH Integrity (6.2.8)
Validates root's PATH:
- No empty directories
- No current directory (.)
- All directories owned by root
- No world-writable directories

**Critical for security**: Prevents privilege escalation attacks.

### Home Directory Security (6.2.10)
Ensures:
- Home directories exist for all users
- Proper ownership (user owns their home)
- Secure permissions (not group/world writable)

Auto-fixes:
- Ownership issues
- Permission issues

**Manual action**: Create missing directories with `mkhomedir_helper`

### Dot File Security (6.2.11)
Secures user configuration files (.bashrc, .profile, etc.):
- Proper ownership
- Not group/world writable
- Special handling for .netrc (0600)

Auto-fixes permission and ownership issues.

## Performance Considerations

### Filesystem Scans
Scripts that scan entire filesystem:
- **6.1.11**: World-writable files
- **6.1.12**: Unowned files
- **6.1.13**: SUID/SGID files (Manual)

**Time**: 5-30 minutes depending on:
- Filesystem size
- Number of files
- Disk I/O speed

**Recommendation**: Run during maintenance windows.

### User Validation Scripts
Scripts that check all users/groups:
- **6.2.10**: Home directory validation
- **6.2.11**: Dot file validation

**Time**: Usually < 1 minute

## Common Issues and Solutions

### Shadow File Permissions
Some systems expect /etc/shadow to be 0640 (readable by shadow group).
CIS requires 0000 for maximum security.

**If applications break**:
```bash
# Temporarily restore read access
chmod 0640 /etc/shadow
# Fix applications to use proper APIs
# Return to 0000 when fixed
```

### Unowned Files
Often from:
- Removed packages
- Deleted users
- Manual file extraction

**Solution**:
```bash
# Assign to user
chown username:groupname /path/to/file

# Or delete
rm /path/to/file
```

### SUID Files
Too many SUID binaries = security risk
Too few = functionality issues

**Balance**: Keep only necessary SUID binaries.

## Troubleshooting

### Scripts Take Too Long
Filesystem scan scripts (6.1.11-6.1.13) can be slow:
```bash
# Run in background
nohup ./6.1.11.sh > /tmp/6.1.11.log 2>&1 &

# Check progress
tail -f /tmp/6.1.11.log
```

### Permission Denied Errors
Ensure running as root:
```bash
sudo su -
./script.sh
```

### Files Re-appear as Insecure
Check for:
- Automated tools resetting permissions
- Application installers
- Configuration management systems

**Solution**: Adjust automation or run scripts after deployments.

## Support

For issues or questions:
1. Review the CIS Oracle Linux 7 Benchmark documentation
2. Check script comments for specific remediation details
3. Review logs for error messages
4. Test filesystem scan scripts in non-production first

## Disclaimer

These scripts are provided as-is for CIS benchmark compliance. Always:
- Test thoroughly in development environments
- Backup system before running
- Review and understand each script before execution
- Maintain proper backups
- Follow your organization's change management procedures
- Allow sufficient time for filesystem scan scripts

**Shadow file permissions (0000) are extremely restrictive and may affect some applications.**

## Version
- CIS Benchmark: Oracle Linux 7 v4.0.0
- Section: 6 (System Maintenance)
- Generated: 2025-10-20

---
Generated with automated bash script creator for CIS compliance
'''

# Create the archive
archive_name = 'section6_scripts/CIS_Oracle_Linux_7_Section6_Remediation_Scripts.zip'

print("=" * 100)
print("Creating Section 6 downloadable archive...")
print("=" * 100)

with zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    script_dir = 'section6_scripts'
    scripts = sorted([f for f in os.listdir(script_dir) if f.endswith('.sh')])
    
    for script in scripts:
        script_path = os.path.join(script_dir, script)
        zipf.write(script_path, f'section6_scripts/{script}')
        print(f"  Added: {script}")
    
    # Add the original spreadsheet
    zipf.write('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section6.xlsx', 
               'section6_scripts/CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section6.xlsx')
    print(f"  Added: CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section6.xlsx")
    
    # Add README
    zipf.writestr('section6_scripts/README.md', readme_content)
    print(f"  Added: README.md")
    
    # Add summary CSV
    zipf.write('section6_scripts/Section6_Script_Summary.csv', 
               'section6_scripts/Section6_Script_Summary.csv')
    print(f"  Added: Section6_Script_Summary.csv")

print("=" * 100)

# Get archive info
archive_size = os.path.getsize(archive_name)
print(f"\n✓ Archive created successfully!")
print(f"  File: {archive_name}")
print(f"  Size: {archive_size:,} bytes ({archive_size/1024:.2f} KB)")

print("\n" + "=" * 100)
print("SECTION 6 GENERATION COMPLETE!")
print("=" * 100)
print(f"\nGenerated Files:")
print(f"1. section6_scripts/ folder - Contains all 25 individual scripts")
print(f"2. CIS_Oracle_Linux_7_Section6_Remediation_Scripts.zip - Complete archive")
print(f"3. Section6_Script_Summary.csv - Quick reference list")

print("\n" + "=" * 100)
print("COMPLETE CIS ORACLE LINUX 7 BENCHMARK - ALL SECTIONS GENERATED!")
print("=" * 100)
print(f"\nSummary of All Sections:")
print(f"  Section 1: 70 scripts  (Initial Setup)")
print(f"  Section 2: 30 scripts  (Services)")
print(f"  Section 3: 46 scripts  (Network Configuration)")
print(f"  Section 4: 71 scripts  (Access, Authentication and Authorization)")
print(f"  Section 5: 59 scripts  (Logging and Auditing)")
print(f"  Section 6: 25 scripts  (System Maintenance)")
print(f"  ────────────────────")
print(f"  TOTAL:     301 scripts")
print("\n" + "=" * 100)
