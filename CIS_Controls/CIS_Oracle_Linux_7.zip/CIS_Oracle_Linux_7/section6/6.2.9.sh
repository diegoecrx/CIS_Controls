#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.9.sh
# CIS Control - 6.2.9 Ensure root is the only UID 0 account (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.9.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.9 Ensure root is the only UID 0 account (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures root is the only UID 0 account."
echo ""

log_message "Starting remediation: Check UID 0 accounts"

UID0_ACCOUNTS=$(awk -F: '($3 == 0 && $1 != "root") {print $1}' /etc/passwd)

if [ -n "$UID0_ACCOUNTS" ]; then
    echo "⚠ Found UID 0 accounts other than root:"
    echo "$UID0_ACCOUNTS"
    echo ""
    echo "Remove these accounts or change their UID:"
    echo "  userdel <username>"
    echo "  or"
    echo "  usermod -u <new-uid> <username>"
else
    echo "✓ Root is the only UID 0 account"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
