#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 6.2.2.sh
# CIS Control - 6.2.2 Ensure /etc/shadow password fields are not empty (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="6.2.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "6.2.2 Ensure /etc/shadow password fields are not empty (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Checks for empty password fields."
echo ""

log_message "Starting remediation: Empty passwords"

EMPTY_PASS=$(awk -F: '($2 == "") {print $1}' /etc/shadow)

if [ -n "$EMPTY_PASS" ]; then
    echo "⚠ Found accounts with empty passwords:"
    echo "$EMPTY_PASS"
    echo ""
    echo "Lock these accounts with:"
    echo "  passwd -l <username>"
    echo ""
    echo "Or set passwords:"
    echo "  passwd <username>"
else
    echo "✓ No accounts with empty passwords found"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
