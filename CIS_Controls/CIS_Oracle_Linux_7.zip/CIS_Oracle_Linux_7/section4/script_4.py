
import pandas as pd
import zipfile
import os

df = pd.read_csv('section4_remediation_data.csv')

# Create summary CSV for Section 4
summary_data = []
for idx, row in df.iterrows():
    script_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    summary_data.append({
        'Script': f"{row['script_name']}.sh",
        'Control': row['control_name'],
        'Type': script_type,
        'Profile': 'Level 1 - Server & Workstation'
    })

summary_df = pd.DataFrame(summary_data)
summary_df.to_csv('section4_scripts/Section4_Script_Summary.csv', index=False)

# Create README for Section 4
readme_content = '''# CIS Oracle Linux 7 Benchmark Remediation Scripts - Section 4

## Overview
This archive contains 71 bash remediation scripts for CIS Oracle Linux 7 Benchmark v4.0.0 Section 4 (Access, Authentication and Authorization).

## Contents
- 71 remediation scripts (4.1.1.1.sh through 4.5.3.3.sh)
- Original spreadsheet with remediation details
- Script summary CSV

## Script Categories

### 4.1.x - Configure Job Schedulers (9 scripts)
#### 4.1.1.x - Configure cron (8 scripts)
- cron daemon enablement
- Permissions on cron files and directories
- crontab access restriction

#### 4.1.2.x - Configure at (1 script)
- at command access restriction

### 4.2.x - Configure SSH Server (22 scripts)
- SSH configuration file permissions
- SSH host key permissions (private and public)
- SSH access controls (AllowUsers, DenyUsers, etc.)
- SSH protocol settings:
  - Banner configuration
  - Cipher configuration
  - ClientAlive settings
  - DisableForwarding
  - Authentication methods (GSSAPI, Hostbased)
  - Key exchange algorithms
  - Login and session settings
  - MAC algorithms
  - Password and root login controls
  - PAM integration

### 4.3.x - Configure Privilege Escalation (7 scripts)
- sudo installation
- sudo configuration:
  - use_pty requirement
  - log file configuration
  - Password requirement for escalation
  - Re-authentication settings
  - Timeout configuration
- su command restriction

### 4.4.x - Configure PAM (25 scripts)
#### 4.4.1.x - PAM Software (2 scripts)
- PAM package updates
- libpwquality installation

#### 4.4.2.x - Configure PAM Modules (23 scripts)

**pam_faillock (4 scripts):**
- Account lockout configuration
- Failed attempt limits
- Unlock time settings
- Root account inclusion

**pam_pwquality (7 scripts):**
- Password quality requirements
- Minimum length and complexity
- Character repetition limits
- Sequential character limits
- Dictionary checking

**pam_pwhistory (4 scripts):**
- Password history enforcement
- Remember previous passwords
- Root account inclusion
- use_authtok configuration

**pam_unix (4 scripts):**
- Remove nullok option
- Remove remember option
- Strong hashing algorithm (SHA512)
- use_authtok configuration

### 4.5.x - User Accounts and Environment (8 scripts)
#### 4.5.1.x - Configure Password Settings (5 scripts)
- Strong password hashing algorithm
- Password expiration (365 days)
- Password warning days (7 days)
- Inactive password lock (30 days)
- Password change date verification

#### 4.5.2.x - Configure root Account (4 scripts)
- Root account GID verification
- Root umask configuration
- System account security
- Root password verification

#### 4.5.3.x - Configure User Environment (3 scripts)
- nologin shell configuration
- Default shell timeout (TMOUT)
- Default user umask

## Usage

### Prerequisites
- Oracle Linux 7
- Root privileges
- Bash shell
- **CRITICAL**: SSH changes can lock you out - have console access

### Running Scripts

1. Extract the archive:
   ```bash
   unzip CIS_Oracle_Linux_7_Section4_Remediation_Scripts.zip
   cd section4_scripts
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Run individual scripts:
   ```bash
   sudo ./4.1.1.1.sh
   ```

4. Run by category:
   ```bash
   # cron configuration
   for script in 4.1.1.*.sh; do sudo ./$script; done
   
   # SSH configuration (BE CAREFUL!)
   for script in 4.2.*.sh; do sudo ./$script; done
   
   # sudo configuration
   for script in 4.3.*.sh; do sudo ./$script; done
   
   # PAM configuration
   for script in 4.4.*.sh; do sudo ./$script; done
   
   # User accounts
   for script in 4.5.*.sh; do sudo ./$script; done
   ```

### ⚠️ CRITICAL WARNINGS

**SSH CONFIGURATION (4.2.x scripts)**
- Can lock you out of remote systems
- ALWAYS have console/physical access before running
- Test each SSH change individually
- Keep an existing SSH session open while testing
- Verify you can open new connections before closing existing ones

**PAM CONFIGURATION (4.4.x scripts)**
- Can prevent user login if misconfigured
- Test thoroughly in non-production first
- Have console access for recovery
- Understand your organization's password policy before applying

**PRIVILEGE ESCALATION (4.3.x scripts)**
- Changes to sudo can prevent administrative access
- Ensure at least one user can use sudo before restricting
- Test sudo access after changes
- Have root password available for recovery

### Important Notes

1. **Backup your system** before running remediation scripts
2. **Have console access** before running SSH/PAM scripts
3. **Test in non-production** environments first
4. **Review Manual controls** - they require administrator decisions
5. Scripts create backups in `/tmp/cis_backup/`
6. Logs are written to `/var/log/cis_remediation.log`

### Script Features

Each script includes:
- Root privilege check
- Backup functionality (one backup per day per file)
- Action execution
- Configuration changes
- Service reloads when needed
- Comprehensive logging
- Error handling

### Script Types

- **Automated (70 scripts)**: Executes remediation automatically
- **Manual (1 script)**: 4.4.2.2.4 - Password complexity configuration

### Backup Location
- `/tmp/cis_backup/` - Contains backups of modified files with timestamps

### Log Files
- `/var/log/cis_remediation.log` - General execution log
- `/var/log/cis_error.log` - Error messages

## Testing Recommendations

### Before Running SSH Scripts
```bash
# Keep an existing session open
# In another terminal, test new connections after each change
ssh user@hostname

# If locked out, use console to fix:
cp /tmp/cis_backup/sshd_config_YYYYMMDD /etc/ssh/sshd_config
systemctl restart sshd
```

### Before Running PAM Scripts
```bash
# Verify current login works
su - testuser

# After PAM changes, verify:
su - testuser  # Should still work
sudo -l        # Should still work

# If locked out, use console/root to fix:
cp /tmp/cis_backup/system-auth_YYYYMMDD /etc/pam.d/system-auth
```

### Before Running sudo Scripts
```bash
# Verify current sudo access
sudo -l

# After changes, test immediately:
sudo -l

# If locked out, use root account:
su -
cp /tmp/cis_backup/sudoers_YYYYMMDD /etc/sudoers.d/cis_sudoers
```

## Password Policy Considerations

Section 4.4.x implements strong password policies:
- Minimum 14 characters
- Account lockout after 5 failed attempts
- 900 second (15 minute) lockout duration
- Password history (5 previous passwords)
- SHA512 hashing
- No empty passwords allowed

**Customize these settings to match your organization's requirements before running scripts.**

## Support

For issues or questions:
1. Review the CIS Oracle Linux 7 Benchmark documentation
2. Check script comments for specific remediation details
3. Review logs for error messages
4. Have console/physical access for recovery
5. Keep backups of all configuration files

## Disclaimer

These scripts are provided as-is for CIS benchmark compliance. Always:
- Test thoroughly in development environments
- Have console/physical access for SSH/PAM changes
- Review and understand each script before execution
- Maintain proper backups
- Follow your organization's change management procedures
- Verify access after each change

**SSH and PAM misconfigurations can completely lock you out of the system.**

## Version
- CIS Benchmark: Oracle Linux 7 v4.0.0
- Section: 4 (Access, Authentication and Authorization)
- Generated: 2025-10-20

---
Generated with automated bash script creator for CIS compliance
'''

# Create the archive
archive_name = 'section4_scripts/CIS_Oracle_Linux_7_Section4_Remediation_Scripts.zip'

print("=" * 100)
print("Creating Section 4 downloadable archive...")
print("=" * 100)

with zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    script_dir = 'section4_scripts'
    scripts = sorted([f for f in os.listdir(script_dir) if f.endswith('.sh')])
    
    for script in scripts:
        script_path = os.path.join(script_dir, script)
        zipf.write(script_path, f'section4_scripts/{script}')
        print(f"  Added: {script}")
    
    # Add the original spreadsheet
    zipf.write('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section4.xlsx', 
               'section4_scripts/CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section4.xlsx')
    print(f"  Added: CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section4.xlsx")
    
    # Add README
    zipf.writestr('section4_scripts/README.md', readme_content)
    print(f"  Added: README.md")
    
    # Add summary CSV
    zipf.write('section4_scripts/Section4_Script_Summary.csv', 
               'section4_scripts/Section4_Script_Summary.csv')
    print(f"  Added: Section4_Script_Summary.csv")

print("=" * 100)

# Get archive info
archive_size = os.path.getsize(archive_name)
print(f"\n✓ Archive created successfully!")
print(f"  File: {archive_name}")
print(f"  Size: {archive_size:,} bytes ({archive_size/1024:.2f} KB)")

print("\n" + "=" * 100)
print("SECTION 4 GENERATION COMPLETE!")
print("=" * 100)
print(f"\nGenerated Files:")
print(f"1. section4_scripts/ folder - Contains all 71 individual scripts")
print(f"2. CIS_Oracle_Linux_7_Section4_Remediation_Scripts.zip - Complete archive")
print(f"3. Section4_Script_Summary.csv - Quick reference list")
