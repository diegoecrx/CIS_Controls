#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.5.2.4.sh
# CIS Control - 4.5.2.4 Ensure root password is set (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.5.2.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "4.5.2.4 Ensure root password is set (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures root password is set."
echo ""

log_message "Starting remediation: Verify root password"

if passwd -S root | grep -q "LK\|NP"; then
    echo "⚠ WARNING: Root password is not set or locked"
    echo "  Run: passwd root"
    echo "  to set root password"
else
    echo "✓ Root password is set"
fi

passwd -S root

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
