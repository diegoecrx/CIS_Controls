#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.5.3.2.sh
# CIS Control - 4.5.3.2 Ensure default user shell timeout is configured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.5.3.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "4.5.3.2 Ensure default user shell timeout is configured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Configures default user shell timeout."
echo ""

log_message "Starting remediation: Configure shell timeout"

for file in /etc/bashrc /etc/profile; do
    backup_file "$file"

    if ! grep -q "^TMOUT=" "$file"; then
        echo "TMOUT=900" >> "$file"
        echo "readonly TMOUT" >> "$file"
        echo "export TMOUT" >> "$file"
    fi
done

echo "✓ Shell timeout configured (900 seconds)"
grep "TMOUT" /etc/bashrc /etc/profile

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
