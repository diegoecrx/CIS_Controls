#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.2.4.sh
# CIS Control - 4.2.4 Ensure sshd access is configured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.2.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "4.2.4 Ensure sshd access is configured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Configures SSH access restrictions."
echo ""

log_message "Starting remediation: sshd access configuration"

FILE="/etc/ssh/sshd_config"
backup_file "$FILE"

# Remove existing AllowUsers, AllowGroups, DenyUsers, DenyGroups entries
sed -i '/^AllowUsers/d; /^AllowGroups/d; /^DenyUsers/d; /^DenyGroups/d' "$FILE"

# Add recommended configuration (customize as needed)
echo "# SSH Access Configuration" >> "$FILE"
echo "#AllowUsers <userlist>" >> "$FILE"
echo "#AllowGroups <grouplist>" >> "$FILE"
echo "#DenyUsers <userlist>" >> "$FILE"
echo "#DenyGroups <grouplist>" >> "$FILE"

echo "✓ SSH access configuration template added (customize as needed)"
echo "  Edit $FILE to configure AllowUsers/AllowGroups/DenyUsers/DenyGroups"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
