#!/bin/bash

SCRIPT_NAME="4.2.1.6_remote_rsyslog_messagesly_accepted_designated_log_hosts.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
RSYSLOG_CONF="/etc/rsyslog.conf"
RSYSLOG_D="/etc/rsyslog.d"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 4.2.1.6 - Ensure remote rsyslog messages are only accepted on designated log hosts"
    echo ""

    # Check if rsyslog is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo "rsyslog is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "rsyslog not installed - control not applicable"
        return 0
    fi

    # Ask if this is a designated log host
    echo "IMPORTANT: This control requires manual decision"
    echo ""
    echo "Is this system a designated log host (should it receive logs from other systems)?"
    echo ""
    echo "If YES: Remote log reception modules will be enabled"
    echo "If NO: Remote log reception modules will be disabled (recommended for most systems)"
    echo ""
    echo "Most systems should answer NO unless specifically configured as centralized log servers"
    echo ""
    read -p "Is this a designated log host? (yes/no) [no]: " IS_LOG_HOST
    IS_LOG_HOST=${IS_LOG_HOST:-no}

    # Convert to lowercase
    IS_LOG_HOST=$(echo "$IS_LOG_HOST" | tr '[:upper:]' '[:lower:]')

    echo ""

    # Backup rsyslog.conf
    if [ -f "$RSYSLOG_CONF" ]; then
        cp "$RSYSLOG_CONF" "$BACKUP_DIR/rsyslog.conf.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up $RSYSLOG_CONF"
    else
        echo "ERROR: $RSYSLOG_CONF not found"
        log_message "ERROR" "rsyslog configuration file not found"
        return 1
    fi

    if [ "$IS_LOG_HOST" = "yes" ] || [ "$IS_LOG_HOST" = "y" ]; then
        echo "Configuring system as DESIGNATED LOG HOST..."
        echo ""
        log_message "INFO" "Configuring system as designated log host"

        # Enable TCP reception module (more reliable)
        if ! grep -q '^module(load="imtcp")' "$RSYSLOG_CONF"; then
            echo 'module(load="imtcp")' >> "$RSYSLOG_CONF"
            echo "Enabled TCP input module"
        else
            echo "TCP input module already enabled"
        fi

        # Enable TCP listener on port 514
        if ! grep -q '^input(type="imtcp" port="514")' "$RSYSLOG_CONF"; then
            echo 'input(type="imtcp" port="514")' >> "$RSYSLOG_CONF"
            echo "Enabled TCP listener on port 514"
        else
            echo "TCP listener already enabled"
        fi

        # Optionally enable UDP reception (legacy support)
        if ! grep -q '^module(load="imudp")' "$RSYSLOG_CONF"; then
            echo 'module(load="imudp")' >> "$RSYSLOG_CONF"
            echo "Enabled UDP input module"
        else
            echo "UDP input module already enabled"
        fi

        if ! grep -q '^input(type="imudp" port="514")' "$RSYSLOG_CONF"; then
            echo 'input(type="imudp" port="514")' >> "$RSYSLOG_CONF"
            echo "Enabled UDP listener on port 514"
        else
            echo "UDP listener already enabled"
        fi

        echo ""
        echo "FIREWALL CONFIGURATION REQUIRED:"
        echo "Run the following commands to allow incoming syslog traffic:"
        echo "  firewall-cmd --permanent --add-port=514/tcp"
        echo "  firewall-cmd --permanent --add-port=514/udp"
        echo "  firewall-cmd --reload"
        echo ""

    else
        echo "Configuring system to NOT accept remote logs (standard configuration)..."
        echo ""
        log_message "INFO" "Disabling remote log reception"

        # Comment out or remove TCP module loading
        sed -i 's/^module(load="imtcp")/#module(load="imtcp")/' "$RSYSLOG_CONF"
        sed -i 's/^input(type="imtcp"/#input(type="imtcp")/' "$RSYSLOG_CONF"
        
        # Comment out or remove UDP module loading
        sed -i 's/^module(load="imudp")/#module(load="imudp")/' "$RSYSLOG_CONF"
        sed -i 's/^input(type="imudp"/#input(type="imudp")/' "$RSYSLOG_CONF"

        # Also check for old-style configuration
        sed -i 's/^\$ModLoad imtcp/#$ModLoad imtcp/' "$RSYSLOG_CONF"
        sed -i 's/^\$InputTCPServerRun/#$InputTCPServerRun/' "$RSYSLOG_CONF"
        sed -i 's/^\$ModLoad imudp/#$ModLoad imudp/' "$RSYSLOG_CONF"
        sed -i 's/^\$UDPServerRun/#$UDPServerRun/' "$RSYSLOG_CONF"

        echo "Disabled remote log reception modules"
        echo "This system will NOT accept logs from remote systems"
    fi

    # Check configuration files in rsyslog.d directory
    if [ -d "$RSYSLOG_D" ]; then
        echo ""
        echo "Checking rsyslog.d configuration files..."
        
        CONF_FILES=$(find "$RSYSLOG_D" -name "*.conf" 2>/dev/null)
        
        if [ -n "$CONF_FILES" ]; then
            for conf_file in $CONF_FILES; do
                cp "$conf_file" "$BACKUP_DIR/$(basename $conf_file).$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
                
                if [ "$IS_LOG_HOST" != "yes" ] && [ "$IS_LOG_HOST" != "y" ]; then
                    # Disable remote log reception in all config files
                    sed -i 's/^module(load="imtcp")/#module(load="imtcp")/' "$conf_file"
                    sed -i 's/^input(type="imtcp"/#input(type="imtcp")/' "$conf_file"
                    sed -i 's/^module(load="imudp")/#module(load="imudp")/' "$conf_file"
                    sed -i 's/^input(type="imudp"/#input(type="imudp")/' "$conf_file"
                fi
            done
            echo "Processed configuration files in rsyslog.d"
        fi
    fi

    # Restart rsyslog service
    echo ""
    echo "Restarting rsyslog service..."
    if systemctl restart rsyslog >/dev/null 2>&1; then
        echo "rsyslog service restarted successfully"
        log_message "SUCCESS" "rsyslog service restarted"
    else
        echo "WARNING: Failed to restart rsyslog service"
        echo "Run 'systemctl restart rsyslog' manually to apply changes"
        log_message "WARNING" "Manual rsyslog restart required"
    fi

    echo ""
    echo "Status: COMPLIANT"
    if [ "$IS_LOG_HOST" = "yes" ] || [ "$IS_LOG_HOST" = "y" ]; then
        echo "System configured as designated log host - accepting remote logs"
    else
        echo "System configured to reject remote logs - only local logs accepted"
    fi
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
