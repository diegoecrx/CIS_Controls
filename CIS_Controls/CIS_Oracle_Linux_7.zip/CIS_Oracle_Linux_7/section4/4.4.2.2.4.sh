#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.4.2.2.4.sh
# CIS Control - 4.4.2.2.4 Ensure password complexity is configured (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.4.2.2.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Manual Remediation: $SCRIPT_NAME"
echo "4.4.2.2.4 Ensure password complexity is configured (Manual)"
echo "=============================================="
echo ""
echo "Description:"
echo "Manual configuration: Password complexity."
echo ""

log_message "Manual remediation: Password complexity"

PWQUALITY_CONF="/etc/security/pwquality.conf"

echo "Current password complexity settings:"
grep -E "^(dcredit|ucredit|ocredit|lcredit)" "$PWQUALITY_CONF" 2>/dev/null || echo "  Not configured"
echo ""
echo "Recommended configuration (add to $PWQUALITY_CONF):"
echo "  dcredit = -1  # At least 1 digit"
echo "  ucredit = -1  # At least 1 uppercase"
echo "  ocredit = -1  # At least 1 special character"
echo "  lcredit = -1  # At least 1 lowercase"
echo ""
echo "Edit $PWQUALITY_CONF to configure password complexity requirements"
echo "✓ Manual review required"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
