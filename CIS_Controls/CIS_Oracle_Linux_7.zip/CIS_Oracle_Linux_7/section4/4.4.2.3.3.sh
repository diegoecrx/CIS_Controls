#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.4.2.3.3.sh
# CIS Control - 4.4.2.3.3 Ensure password history is enforced for the root user (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.4.2.3.3.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "4.4.2.3.3 Ensure password history is enforced for the root user (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures password history is enforced for root."
echo ""

log_message "Starting remediation: Enforce password history for root"

for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
    backup_file "$file"

    sed -i '/pam_pwhistory.so/s/$/ enforce_for_root/' "$file"
done

echo "✓ Password history enforced for root"
grep "pam_pwhistory.so" /etc/pam.d/system-auth

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
