#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.2.6.sh
# CIS Control - 4.2.6 Ensure sshd Ciphers are configured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.2.6.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "4.2.6 Ensure sshd Ciphers are configured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Configures SSH Ciphers setting."
echo ""

log_message "Starting remediation: SSH Ciphers"

FILE="/etc/ssh/sshd_config"
backup_file "$FILE"

sed -i '/^Ciphers/d' "$FILE"
echo "Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr" >> "$FILE"

systemctl reload sshd

echo "✓ SSH Ciphers configured"
grep "^Ciphers" "$FILE"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
