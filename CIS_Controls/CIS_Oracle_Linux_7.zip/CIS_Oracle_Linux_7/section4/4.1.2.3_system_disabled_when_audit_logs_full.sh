#!/bin/bash

SCRIPT_NAME="4.1.2.3_system_disabled_when_audit_logs_full.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDITD_CONF="/etc/audit/auditd.conf"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 4.1.2.3 - Ensure system is disabled when audit logs are full"
    echo ""

    # Check if auditd is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "auditd is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "auditd not installed - control not applicable"
        return 0
    fi

    # Check if auditd.conf exists
    if [ ! -f "$AUDITD_CONF" ]; then
        echo "ERROR: Configuration file $AUDITD_CONF not found"
        log_message "ERROR" "auditd configuration file not found"
        return 1
    fi

    # Backup the configuration file
    cp "$AUDITD_CONF" "$BACKUP_DIR/auditd.conf.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
    log_message "INFO" "Backed up $AUDITD_CONF"

    echo "Configuring audit daemon to halt system when logs are full..."
    echo ""

    # Configure space_left_action
    CURRENT_SPACE_LEFT=$(grep "^space_left_action" "$AUDITD_CONF" 2>/dev/null | awk '{print $NF}')
    if [ "$CURRENT_SPACE_LEFT" != "email" ]; then
        sed -i '/^space_left_action/d' "$AUDITD_CONF"
        echo "space_left_action = email" >> "$AUDITD_CONF"
        echo "? Set space_left_action = email"
        log_message "SUCCESS" "Configured space_left_action = email"
    else
        echo "? space_left_action already set to email"
    fi

    # Configure admin_space_left_action
    CURRENT_ADMIN_SPACE=$(grep "^admin_space_left_action" "$AUDITD_CONF" 2>/dev/null | awk '{print $NF}')
    if [ "$CURRENT_ADMIN_SPACE" != "halt" ]; then
        sed -i '/^admin_space_left_action/d' "$AUDITD_CONF"
        echo "admin_space_left_action = halt" >> "$AUDITD_CONF"
        echo "? Set admin_space_left_action = halt"
        log_message "SUCCESS" "Configured admin_space_left_action = halt"
    else
        echo "? admin_space_left_action already set to halt"
    fi

    # Configure disk_full_action
    CURRENT_DISK_FULL=$(grep "^disk_full_action" "$AUDITD_CONF" 2>/dev/null | awk '{print $NF}')
    if [ "$CURRENT_DISK_FULL" != "halt" ]; then
        sed -i '/^disk_full_action/d' "$AUDITD_CONF"
        echo "disk_full_action = halt" >> "$AUDITD_CONF"
        echo "? Set disk_full_action = halt"
        log_message "SUCCESS" "Configured disk_full_action = halt"
    else
        echo "? disk_full_action already set to halt"
    fi

    # Configure disk_error_action
    CURRENT_DISK_ERROR=$(grep "^disk_error_action" "$AUDITD_CONF" 2>/dev/null | awk '{print $NF}')
    if [ "$CURRENT_DISK_ERROR" != "halt" ]; then
        sed -i '/^disk_error_action/d' "$AUDITD_CONF"
        echo "disk_error_action = halt" >> "$AUDITD_CONF"
        echo "? Set disk_error_action = halt"
        log_message "SUCCESS" "Configured disk_error_action = halt"
    else
        echo "? disk_error_action already set to halt"
    fi

    echo ""
    echo "Current audit daemon configuration:"
    echo "-----------------------------------"
    grep -E "^(space_left_action|admin_space_left_action|disk_full_action|disk_error_action)" "$AUDITD_CONF"
    echo ""

    # Restart auditd to apply changes
    echo "Restarting auditd service to apply changes..."
    if service auditd restart >/dev/null 2>&1; then
        echo "? auditd service restarted successfully"
        log_message "SUCCESS" "auditd service restarted"
    else
        echo "WARNING: Failed to restart auditd service"
        echo "Run 'service auditd restart' manually to apply changes"
        log_message "WARNING" "Manual auditd restart required"
    fi

    echo ""
    echo "Status: COMPLIANT"
    echo "System will halt when audit logs are full or encounter errors"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
