#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 4.4.2.2.1.sh
# CIS Control - 4.4.2.2.1 Ensure pam_pwquality module is enabled (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="4.4.2.2.1.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "4.4.2.2.1 Ensure pam_pwquality module is enabled (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures pam_pwquality module is enabled."
echo ""

log_message "Starting remediation: Enable pam_pwquality"

for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
    backup_file "$file"

    if ! grep -q "pam_pwquality.so" "$file"; then
        sed -i '/^password.*requisite.*pam_pwquality.so/d' "$file"
        sed -i '/^password.*required.*pam_unix.so/i password requisite pam_pwquality.so try_first_pass local_users_only retry=3' "$file"
    fi
done

echo "✓ pam_pwquality module enabled"

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
