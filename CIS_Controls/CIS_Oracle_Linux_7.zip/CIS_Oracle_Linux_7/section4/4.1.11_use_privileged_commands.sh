#!/bin/bash

SCRIPT_NAME="4.1.11_use_privileged_commands.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
AUDIT_RULES="/etc/audit/rules.d/privileged.rules"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"

    echo ""
    echo "CIS 4.1.11 - Ensure use of privileged commands is collected"
    echo ""

    # Check if auditd is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "auditd is not installed"
        echo "Status: NOT APPLICABLE"
        echo ""
        log_message "INFO" "auditd not installed - control not applicable"
        return 0
    fi

    # Create rules directory if it doesn't exist
    mkdir -p /etc/audit/rules.d 2>/dev/null

    # Backup existing privileged rules file if it exists
    if [ -f "$AUDIT_RULES" ]; then
        cp "$AUDIT_RULES" "$BACKUP_DIR/privileged.rules.$(date +%Y%m%d_%H%M%S).backup" 2>/dev/null
        log_message "INFO" "Backed up existing privileged rules file"
    fi

    echo "Finding all privileged commands (SUID/SGID binaries)..."
    echo "This may take a few minutes..."
    echo ""

    # Find all files with SUID or SGID bits set
    # Search common system directories for performance
    PRIVILEGED_COMMANDS=$(find /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin /bin /sbin \
        -type f \( -perm -4000 -o -perm -2000 \) 2>/dev/null)

    if [ -z "$PRIVILEGED_COMMANDS" ]; then
        echo "No privileged commands found"
        log_message "WARNING" "No privileged commands found on system"
        return 0
    fi

    # Count total privileged commands
    TOTAL_COMMANDS=$(echo "$PRIVILEGED_COMMANDS" | wc -l)
    echo "Found $TOTAL_COMMANDS privileged commands"
    echo ""

    # Create audit rules file header
    cat > "$AUDIT_RULES" << 'EOF'
## Audit rules for privileged commands (CIS 4.1.11)
## Generated automatically - DO NOT EDIT MANUALLY
## These rules monitor execution of SUID/SGID programs

EOF

    # Add audit rule for each privileged command
    RULES_ADDED=0
    echo "Generating audit rules..."
    
    while IFS= read -r cmd; do
        if [ -n "$cmd" ] && [ -f "$cmd" ]; then
            echo "-a always,exit -F path=$cmd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged" >> "$AUDIT_RULES"
            ((RULES_ADDED++))
        fi
    done <<< "$PRIVILEGED_COMMANDS"

    echo "Added $RULES_ADDED audit rules to $AUDIT_RULES"
    log_message "SUCCESS" "Generated $RULES_ADDED audit rules for privileged commands"

    # Load the new audit rules
    echo ""
    echo "Loading audit rules..."
    
    if augenrules --load >/dev/null 2>&1; then
        echo "Audit rules loaded successfully"
        log_message "SUCCESS" "Audit rules loaded successfully"
    else
        echo "WARNING: Failed to load audit rules automatically"
        echo "Run 'augenrules --load' or 'service auditd restart' to apply changes"
        log_message "WARNING" "Manual audit rules reload required"
    fi

    # Verify auditd service is enabled and running
    if systemctl is-enabled auditd >/dev/null 2>&1; then
        echo "auditd service is enabled"
    else
        echo "WARNING: auditd service is not enabled - enabling now..."
        systemctl enable auditd >/dev/null 2>&1
        log_message "INFO" "Enabled auditd service"
    fi

    if systemctl is-active auditd >/dev/null 2>&1; then
        echo "auditd service is running"
    else
        echo "WARNING: auditd service is not running - starting now..."
        systemctl start auditd >/dev/null 2>&1
        log_message "INFO" "Started auditd service"
    fi

    echo ""
    echo "Status: COMPLIANT"
    echo "Privileged commands are now being audited"
    echo ""
    log_message "SUCCESS" "Remediation completed successfully"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
