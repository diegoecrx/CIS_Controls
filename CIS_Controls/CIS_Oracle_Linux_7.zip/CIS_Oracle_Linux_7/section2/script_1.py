
import pandas as pd
import os

# Read section 2 data
df = pd.read_csv('section2_remediation_data.csv')

# Create section2 directory
os.makedirs('section2_scripts', exist_ok=True)

print("=" * 100)
print("GENERATING SECTION 2 SCRIPTS")
print("=" * 100)
print(f"\nTotal scripts to generate: {len(df)}")
print("\nAll controls in Section 2:")
print("-" * 100)

for idx, row in df.iterrows():
    control_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    print(f"{idx + 1}. {row['script_name']} - {row['control_name']} ({control_type})")

print("\n" + "=" * 100)
print("Starting script generation...")
print("=" * 100)
