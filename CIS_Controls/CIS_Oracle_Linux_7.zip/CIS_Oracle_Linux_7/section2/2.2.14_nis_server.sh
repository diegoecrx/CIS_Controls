#!/bin/bash

SCRIPT_NAME="2.2.14_nis_server.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.14 - Remove NIS Server"
    echo ""
    
    if ! rpm -q ypserv &>/dev/null; then
        echo "NIS server not installed"
        echo "Status: COMPLIANT"
        log_message "INFO" "ypserv not present"
    else
        echo "NIS server (ypserv) is installed"
        
        systemctl stop ypserv 2>/dev/null
        systemctl disable ypserv 2>/dev/null
        
        yum remove -y ypserv &>/dev/null
        log_message "SUCCESS" "Removed ypserv"
        
        echo "NIS server removed"
        echo "Status: COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
