#!/bin/bash

SCRIPT_NAME="2.2.5_dhcp_server.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"

mkdir -p "$BACKUP_DIR" 2>/dev/null

log_message() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] [$1] [$SCRIPT_NAME] ${@:2}" | tee -a "$LOG_FILE"
}

main_remediation() {
    log_message "INFO" "Starting remediation"
    
    echo ""
    echo "CIS 2.2.5 - Remove DHCP Server"
    echo ""
    
    if ! rpm -q dhcp &>/dev/null; then
        echo "DHCP server not installed"
        echo "Status: COMPLIANT"
        log_message "INFO" "DHCP not present"
    else
        echo "DHCP server is installed"
        
        systemctl stop dhcpd 2>/dev/null
        systemctl stop dhcpd6 2>/dev/null
        systemctl disable dhcpd 2>/dev/null
        systemctl disable dhcpd6 2>/dev/null
        
        yum remove -y dhcp &>/dev/null
        log_message "SUCCESS" "Removed DHCP server"
        
        echo "DHCP server removed"
        echo "Status: COMPLIANT"
    fi
    
    echo ""
    log_message "SUCCESS" "Completed"
}

[ "$EUID" -ne 0 ] && { echo "Must run as root"; exit 1; }
main_remediation
