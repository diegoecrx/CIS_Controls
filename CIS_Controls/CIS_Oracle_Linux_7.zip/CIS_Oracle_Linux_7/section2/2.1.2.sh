#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 2.1.2.sh
# CIS Control - 2.1.2 Ensure chrony is configured (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="2.1.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "2.1.2 Ensure chrony is configured (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures chrony is properly configured for time synchronization."
echo ""

log_message "Starting remediation: chrony configuration"

CONFIG_FILE="/etc/chrony.conf"
backup_file "$CONFIG_FILE"

if ! rpm -q chrony > /dev/null 2>&1; then
    yum install -y chrony
fi

# Ensure chrony has proper server configuration
if ! grep -q "^server" "$CONFIG_FILE" && ! grep -q "^pool" "$CONFIG_FILE"; then
    echo "pool 2.pool.ntp.org iburst" >> "$CONFIG_FILE"
    echo "✓ Added NTP pool servers to chrony configuration"
fi

# Enable and start chrony
systemctl enable chronyd
systemctl restart chronyd

echo "✓ chrony is configured and running"
systemctl status chronyd --no-pager

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
