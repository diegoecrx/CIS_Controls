
import os

# Verify directory structure
print("=" * 100)
print("DIRECTORY STRUCTURE VERIFICATION")
print("=" * 100)

print("\nSection 1 (from previous task):")
print("-" * 100)
section1_files = os.listdir('cis_remediation_scripts')
print(f"  Location: cis_remediation_scripts/")
print(f"  Files: {len(section1_files)} scripts")
print(f"  Scripts: 1.1.1.1.sh through 1.7.10.sh")

print("\nSection 2 (newly created):")
print("-" * 100)
section2_files = os.listdir('section2_scripts')
print(f"  Location: section2_scripts/")
print(f"  Files: {len(section2_files)} files total")
print(f"  Scripts: {len([f for f in section2_files if f.endswith('.sh')])} bash scripts")
print(f"  Scripts: 2.1.1.sh through 2.3.5.sh")

print("\nFiles in section2_scripts/ folder:")
for f in sorted(section2_files):
    file_path = os.path.join('section2_scripts', f)
    file_size = os.path.getsize(file_path)
    print(f"  - {f:60s} ({file_size:>8,} bytes)")

print("\n" + "=" * 100)
print("SAMPLE SCRIPT VERIFICATION - 2.2.6.sh (Samba removal)")
print("=" * 100)

with open('section2_scripts/2.2.6.sh', 'r') as f:
    print(f.read())

print("\n" + "=" * 100)
print("READY FOR DOWNLOAD")
print("=" * 100)
print("\nAll Section 2 files are in: section2_scripts/")
print("\nDownloadable package:")
print("  CIS_Oracle_Linux_7_Section2_Remediation_Scripts.zip (51 KB)")
print("\nContains:")
print("  - 30 bash scripts (.sh files)")
print("  - Original Section 2 spreadsheet")
print("  - README.md with instructions")
print("  - Section2_Script_Summary.csv")
