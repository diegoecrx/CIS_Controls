
import pandas as pd
import zipfile
import os

df = pd.read_csv('section2_remediation_data.csv')

# Create summary CSV for Section 2
summary_data = []
for idx, row in df.iterrows():
    script_type = "Manual" if "Manual" in str(row['control_name']) else "Automated"
    summary_data.append({
        'Script': f"{row['script_name']}.sh",
        'Control': row['control_name'],
        'Type': script_type,
        'Profile': 'Level 1 - Server & Workstation'
    })

summary_df = pd.DataFrame(summary_data)
summary_df.to_csv('section2_scripts/Section2_Script_Summary.csv', index=False)

# Create README for Section 2
readme_content = '''# CIS Oracle Linux 7 Benchmark Remediation Scripts - Section 2

## Overview
This archive contains 30 bash remediation scripts for CIS Oracle Linux 7 Benchmark v4.0.0 Section 2 (Services).

## Contents
- 30 remediation scripts (2.1.1.sh through 2.3.5.sh)
- Original spreadsheet with remediation details
- Script summary CSV

## Script Categories

### 2.1.x - Time Synchronization (3 scripts)
- Time synchronization enablement
- chrony configuration and security

### 2.2.x - Service Configuration (22 scripts)
Services to disable/remove:
- autofs (automounter)
- avahi-daemon (network service discovery)
- dhcp server
- dns server (bind)
- dnsmasq
- samba (file server)
- ftp server (vsftpd)
- dovecot/cyrus-imapd (mail access servers)
- nfs server
- nis server
- print server (cups)
- rpcbind
- rsync daemon
- snmp
- telnet server
- tftp server
- squid (web proxy)
- httpd/nginx (web servers)
- xinetd
- X Window server
- Mail Transfer Agent (MTA) configuration for local-only mode
- Manual review of listening services

### 2.3.x - Service Clients (5 scripts)
Client packages to remove:
- ftp client
- ldap client
- nis client (ypbind)
- telnet client
- tftp client

## Usage

### Prerequisites
- Oracle Linux 7
- Root privileges
- Bash shell

### Running Scripts

1. Extract the archive:
   ```bash
   unzip CIS_Oracle_Linux_7_Section2_Remediation_Scripts.zip
   cd section2_scripts
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Run individual scripts:
   ```bash
   sudo ./2.1.1.sh
   ```

4. Run all scripts (use with caution):
   ```bash
   for script in *.sh; do sudo ./$script; done
   ```

### Important Notes

1. **Backup your system** before running remediation scripts
2. **Test in non-production** environments first
3. **Review each script** to understand its impact on your services
4. Many scripts **remove packages and disable services** - ensure these services are not needed
5. Scripts create backups in `/tmp/cis_backup/`
6. Logs are written to `/var/log/cis_remediation.log`

### Script Features

Each script includes:
- Root privilege check
- Backup functionality (one backup per day per file)
- Action execution
- Service disabling/removal
- Package removal where appropriate
- Comprehensive logging
- Error handling

### Script Types

- **Automated (29 scripts)**: Executes remediation automatically
- **Manual (1 script)**: 2.2.22 - Requires administrator review of listening services

### Backup Location
- `/tmp/cis_backup/` - Contains backups of modified files with timestamps

### Log Files
- `/var/log/cis_remediation.log` - General execution log
- `/var/log/cis_error.log` - Error messages

## Important Service Considerations

### Time Synchronization (2.1.x)
- Installs and configures chrony if not present
- Ensures time sync is running for system security

### Service Removal (2.2.x)
These scripts remove services that may be critical for your environment:
- **DNS/DHCP servers**: Remove only if not providing these services
- **File servers (Samba/NFS)**: Remove only if not sharing files
- **Web servers**: Remove only if not hosting web applications
- **Mail servers**: Configure for local-only unless providing mail services

**Always verify that removed services are not required before running scripts.**

### Client Removal (2.3.x)
- Removes client utilities that may be needed for administration
- Review requirements before removing

## Validation

After running scripts, verify:
```bash
# Check removed packages
rpm -qa | grep -E "(vsftpd|bind|samba|httpd|nginx)"

# Check disabled services
systemctl list-unit-files | grep enabled

# Check listening ports
ss -plntu
```

## Support

For issues or questions:
1. Review the CIS Oracle Linux 7 Benchmark documentation
2. Check script comments for specific remediation details
3. Review logs for error messages

## Disclaimer

These scripts are provided as-is for CIS benchmark compliance. Always:
- Test thoroughly in development environments
- Review and understand each script before execution
- Maintain proper backups
- Follow your organization's change management procedures
- Verify services are not needed before removal

## Version
- CIS Benchmark: Oracle Linux 7 v4.0.0
- Section: 2 (Services)
- Generated: 2025-10-20

---
Generated with automated bash script creator for CIS compliance
'''

# Create the archive
archive_name = 'section2_scripts/CIS_Oracle_Linux_7_Section2_Remediation_Scripts.zip'

print("=" * 100)
print("Creating Section 2 downloadable archive...")
print("=" * 100)

with zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    script_dir = 'section2_scripts'
    scripts = sorted([f for f in os.listdir(script_dir) if f.endswith('.sh')])
    
    for script in scripts:
        script_path = os.path.join(script_dir, script)
        zipf.write(script_path, f'section2_scripts/{script}')
        print(f"  Added: {script}")
    
    # Add the original spreadsheet
    zipf.write('CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section2.xlsx', 
               'section2_scripts/CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section2.xlsx')
    print(f"  Added: CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section2.xlsx")
    
    # Add README
    zipf.writestr('section2_scripts/README.md', readme_content)
    print(f"  Added: README.md")
    
    # Add summary CSV
    zipf.write('section2_scripts/Section2_Script_Summary.csv', 
               'section2_scripts/Section2_Script_Summary.csv')
    print(f"  Added: Section2_Script_Summary.csv")

print("=" * 100)

# Get archive info
archive_size = os.path.getsize(archive_name)
print(f"\n✓ Archive created successfully!")
print(f"  File: {archive_name}")
print(f"  Size: {archive_size:,} bytes ({archive_size/1024:.2f} KB)")

print("\n" + "=" * 100)
print("SECTION 2 GENERATION COMPLETE!")
print("=" * 100)
print(f"\nGenerated Files:")
print(f"1. section2_scripts/ folder - Contains all 30 individual scripts")
print(f"2. CIS_Oracle_Linux_7_Section2_Remediation_Scripts.zip - Complete archive")
print(f"3. Section2_Script_Summary.csv - Quick reference list")

# Display summary
print("\n" + "=" * 100)
print("SECTION 2 SCRIPT SUMMARY")
print("=" * 100)
print(summary_df.to_string(index=False))

print("\n" + "=" * 100)
print("FILES READY FOR DOWNLOAD FROM section2_scripts/ FOLDER")
print("=" * 100)
