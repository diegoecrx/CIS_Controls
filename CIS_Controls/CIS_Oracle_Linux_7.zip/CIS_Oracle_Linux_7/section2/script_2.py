
import pandas as pd
import os

df = pd.read_csv('section2_remediation_data.csv')

# Generate all Section 2 scripts
# Section 2 focuses on:
# - Time synchronization (2.1.x)
# - Service disabling (2.2.x)
# - Client package removal (2.3.x)

scripts_created = []

for idx in range(len(df)):
    row = df.iloc[idx]
    script_num = row['script_name']
    control_name = row['control_name']
    
    script = f'''#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# {script_num}.sh
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="{script_num}.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {{
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}}

backup_file() {{
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}}

echo ""
echo ""
echo ""
echo "=============================================="
'''

    # Determine if manual or automated
    if "Manual" in control_name:
        script += f'''echo "Manual Remediation: $SCRIPT_NAME"
'''
    else:
        script += f'''echo "Automated Remediation: $SCRIPT_NAME"
'''
    
    script += f'''echo "{control_name}"
echo "=============================================="
echo ""
echo "Description:"
'''

    # Add specific remediation logic based on control
    if '2.1.1' in script_num:  # Time synchronization
        script += '''echo "Ensures time synchronization is enabled on the system."
echo ""

log_message "Starting remediation: Time synchronization"

if rpm -q chrony > /dev/null 2>&1; then
    echo "✓ chrony is already installed"
elif rpm -q ntp > /dev/null 2>&1; then
    echo "✓ ntp is already installed"
else
    echo "Installing chrony for time synchronization..."
    yum install -y chrony
    systemctl enable chronyd
    systemctl start chronyd
    echo "✓ chrony installed and enabled"
fi

# Verify time sync is active
if systemctl is-active chronyd > /dev/null 2>&1 || systemctl is-active ntpd > /dev/null 2>&1; then
    echo "✓ Time synchronization service is active"
else
    echo "⚠ Warning: Time synchronization service is not active"
fi
'''
    elif '2.1.2' in script_num:  # chrony configured
        script += '''echo "Ensures chrony is properly configured for time synchronization."
echo ""

log_message "Starting remediation: chrony configuration"

CONFIG_FILE="/etc/chrony.conf"
backup_file "$CONFIG_FILE"

if ! rpm -q chrony > /dev/null 2>&1; then
    yum install -y chrony
fi

# Ensure chrony has proper server configuration
if ! grep -q "^server" "$CONFIG_FILE" && ! grep -q "^pool" "$CONFIG_FILE"; then
    echo "pool 2.pool.ntp.org iburst" >> "$CONFIG_FILE"
    echo "✓ Added NTP pool servers to chrony configuration"
fi

# Enable and start chrony
systemctl enable chronyd
systemctl restart chronyd

echo "✓ chrony is configured and running"
systemctl status chronyd --no-pager
'''
    elif '2.1.3' in script_num:  # chrony not root
        script += '''echo "Ensures chrony daemon does not run as root user."
echo ""

log_message "Starting remediation: chrony user configuration"

CONFIG_FILE="/etc/sysconfig/chronyd"
backup_file "$CONFIG_FILE"

if ! grep -q "^OPTIONS.*-u chrony" "$CONFIG_FILE" 2>/dev/null; then
    echo 'OPTIONS="-u chrony"' >> "$CONFIG_FILE"
    systemctl restart chronyd
    echo "✓ chrony configured to run as chrony user"
else
    echo "✓ chrony already configured to run as non-root user"
fi

ps aux | grep chronyd | grep -v grep
'''
    elif '2.2.1' in script_num:  # autofs
        script += '''echo "Disables autofs (automounter) services."
echo ""

log_message "Starting remediation: Remove autofs"

if systemctl is-enabled autofs 2>/dev/null | grep -q enabled; then
    systemctl stop autofs
    systemctl mask autofs
    echo "✓ autofs service stopped and masked"
fi

if rpm -q autofs > /dev/null 2>&1; then
    yum remove -y autofs
    echo "✓ autofs package removed"
else
    echo "✓ autofs is not installed"
fi
'''
    elif '2.2.2' in script_num:  # avahi
        script += '''echo "Disables Avahi daemon services (network service discovery)."
echo ""

log_message "Starting remediation: Remove avahi"

for service in avahi-daemon avahi-daemon.socket; do
    if systemctl is-enabled $service 2>/dev/null | grep -q enabled; then
        systemctl stop $service
        systemctl mask $service
        echo "✓ $service stopped and masked"
    fi
done

if rpm -q avahi > /dev/null 2>&1; then
    yum remove -y avahi avahi-autoipd
    echo "✓ avahi packages removed"
else
    echo "✓ avahi is not installed"
fi
'''
    elif '2.2.3' in script_num:  # dhcp server
        script += '''echo "Disables DHCP server services."
echo ""

log_message "Starting remediation: Remove DHCP server"

for service in dhcpd dhcpd6; do
    if systemctl is-enabled $service 2>/dev/null | grep -q enabled; then
        systemctl stop $service
        systemctl mask $service
        echo "✓ $service stopped and masked"
    fi
done

if rpm -q dhcp-server > /dev/null 2>&1; then
    yum remove -y dhcp-server
    echo "✓ dhcp-server package removed"
else
    echo "✓ dhcp-server is not installed"
fi
'''
    elif '2.2.4' in script_num:  # dns server
        script += '''echo "Disables DNS server services."
echo ""

log_message "Starting remediation: Remove DNS server"

if systemctl is-enabled named 2>/dev/null | grep -q enabled; then
    systemctl stop named
    systemctl mask named
    echo "✓ named service stopped and masked"
fi

if rpm -q bind > /dev/null 2>&1; then
    yum remove -y bind
    echo "✓ bind package removed"
else
    echo "✓ bind is not installed"
fi
'''
    elif '2.2.5' in script_num:  # dnsmasq
        script += '''echo "Disables dnsmasq services."
echo ""

log_message "Starting remediation: Remove dnsmasq"

if systemctl is-enabled dnsmasq 2>/dev/null | grep -q enabled; then
    systemctl stop dnsmasq
    systemctl mask dnsmasq
    echo "✓ dnsmasq service stopped and masked"
fi

if rpm -q dnsmasq > /dev/null 2>&1; then
    yum remove -y dnsmasq
    echo "✓ dnsmasq package removed"
else
    echo "✓ dnsmasq is not installed"
fi
'''
    elif '2.2.6' in script_num:  # samba
        script += '''echo "Disables Samba file server services."
echo ""

log_message "Starting remediation: Remove Samba"

for service in smb nmb; do
    if systemctl is-enabled $service 2>/dev/null | grep -q enabled; then
        systemctl stop $service
        systemctl mask $service
        echo "✓ $service stopped and masked"
    fi
done

if rpm -q samba > /dev/null 2>&1; then
    yum remove -y samba
    echo "✓ samba package removed"
else
    echo "✓ samba is not installed"
fi
'''
    elif '2.2.7' in script_num:  # ftp server
        script += '''echo "Disables FTP server services."
echo ""

log_message "Starting remediation: Remove FTP server"

if systemctl is-enabled vsftpd 2>/dev/null | grep -q enabled; then
    systemctl stop vsftpd
    systemctl mask vsftpd
    echo "✓ vsftpd service stopped and masked"
fi

if rpm -q vsftpd > /dev/null 2>&1; then
    yum remove -y vsftpd
    echo "✓ vsftpd package removed"
else
    echo "✓ vsftpd is not installed"
fi
'''
    elif '2.2.8' in script_num:  # mail server (dovecot/cyrus)
        script += '''echo "Disables message access server services (IMAP/POP3)."
echo ""

log_message "Starting remediation: Remove mail access servers"

if systemctl is-enabled dovecot 2>/dev/null | grep -q enabled; then
    systemctl stop dovecot
    systemctl mask dovecot
    echo "✓ dovecot service stopped and masked"
fi

for pkg in dovecot cyrus-imapd; do
    if rpm -q $pkg > /dev/null 2>&1; then
        yum remove -y $pkg
        echo "✓ $pkg package removed"
    fi
done

if ! rpm -q dovecot > /dev/null 2>&1 && ! rpm -q cyrus-imapd > /dev/null 2>&1; then
    echo "✓ Message access servers are not installed"
fi
'''
    elif '2.2.9' in script_num:  # nfs
        script += '''echo "Disables NFS server services."
echo ""

log_message "Starting remediation: Remove NFS server"

for service in nfs-server nfs; do
    if systemctl is-enabled $service 2>/dev/null | grep -q enabled; then
        systemctl stop $service
        systemctl mask $service
        echo "✓ $service stopped and masked"
    fi
done

if rpm -q nfs-utils > /dev/null 2>&1; then
    yum remove -y nfs-utils
    echo "✓ nfs-utils package removed"
else
    echo "✓ nfs-utils is not installed"
fi
'''
    elif '2.2.10' in script_num:  # nis server
        script += '''echo "Disables NIS server services."
echo ""

log_message "Starting remediation: Remove NIS server"

if systemctl is-enabled ypserv 2>/dev/null | grep -q enabled; then
    systemctl stop ypserv
    systemctl mask ypserv
    echo "✓ ypserv service stopped and masked"
fi

if rpm -q ypserv > /dev/null 2>&1; then
    yum remove -y ypserv
    echo "✓ ypserv package removed"
else
    echo "✓ ypserv is not installed"
fi
'''
    elif '2.2.11' in script_num:  # print server
        script += '''echo "Disables print server services (CUPS)."
echo ""

log_message "Starting remediation: Remove print server"

if systemctl is-enabled cups 2>/dev/null | grep -q enabled; then
    systemctl stop cups
    systemctl mask cups
    echo "✓ cups service stopped and masked"
fi

if rpm -q cups > /dev/null 2>&1; then
    yum remove -y cups
    echo "✓ cups package removed"
else
    echo "✓ cups is not installed"
fi
'''
    elif '2.2.12' in script_num:  # rpcbind
        script += '''echo "Disables rpcbind services."
echo ""

log_message "Starting remediation: Remove rpcbind"

for service in rpcbind rpcbind.socket; do
    if systemctl is-enabled $service 2>/dev/null | grep -q enabled; then
        systemctl stop $service
        systemctl mask $service
        echo "✓ $service stopped and masked"
    fi
done

if rpm -q rpcbind > /dev/null 2>&1; then
    yum remove -y rpcbind
    echo "✓ rpcbind package removed"
else
    echo "✓ rpcbind is not installed"
fi
'''
    elif '2.2.13' in script_num:  # rsync
        script += '''echo "Disables rsync services."
echo ""

log_message "Starting remediation: Remove rsync service"

if systemctl is-enabled rsyncd 2>/dev/null | grep -q enabled; then
    systemctl stop rsyncd
    systemctl mask rsyncd
    echo "✓ rsyncd service stopped and masked"
fi

if rpm -q rsync-daemon > /dev/null 2>&1; then
    yum remove -y rsync-daemon
    echo "✓ rsync-daemon package removed"
else
    echo "✓ rsync daemon is not configured"
fi
'''
    elif '2.2.14' in script_num:  # snmp
        script += '''echo "Disables SNMP services."
echo ""

log_message "Starting remediation: Remove SNMP"

if systemctl is-enabled snmpd 2>/dev/null | grep -q enabled; then
    systemctl stop snmpd
    systemctl mask snmpd
    echo "✓ snmpd service stopped and masked"
fi

if rpm -q net-snmp > /dev/null 2>&1; then
    yum remove -y net-snmp
    echo "✓ net-snmp package removed"
else
    echo "✓ net-snmp is not installed"
fi
'''
    elif '2.2.15' in script_num:  # telnet server
        script += '''echo "Disables telnet server services."
echo ""

log_message "Starting remediation: Remove telnet server"

if systemctl is-enabled telnet.socket 2>/dev/null | grep -q enabled; then
    systemctl stop telnet.socket
    systemctl mask telnet.socket
    echo "✓ telnet.socket stopped and masked"
fi

if rpm -q telnet-server > /dev/null 2>&1; then
    yum remove -y telnet-server
    echo "✓ telnet-server package removed"
else
    echo "✓ telnet-server is not installed"
fi
'''
    elif '2.2.16' in script_num:  # tftp server
        script += '''echo "Disables TFTP server services."
echo ""

log_message "Starting remediation: Remove TFTP server"

if systemctl is-enabled tftp.socket 2>/dev/null | grep -q enabled; then
    systemctl stop tftp.socket
    systemctl mask tftp.socket
    echo "✓ tftp.socket stopped and masked"
fi

if rpm -q tftp-server > /dev/null 2>&1; then
    yum remove -y tftp-server
    echo "✓ tftp-server package removed"
else
    echo "✓ tftp-server is not installed"
fi
'''
    elif '2.2.17' in script_num:  # web proxy (squid)
        script += '''echo "Disables web proxy server services."
echo ""

log_message "Starting remediation: Remove web proxy"

if systemctl is-enabled squid 2>/dev/null | grep -q enabled; then
    systemctl stop squid
    systemctl mask squid
    echo "✓ squid service stopped and masked"
fi

if rpm -q squid > /dev/null 2>&1; then
    yum remove -y squid
    echo "✓ squid package removed"
else
    echo "✓ squid is not installed"
fi
'''
    elif '2.2.18' in script_num:  # web server
        script += '''echo "Disables web server services (Apache/nginx)."
echo ""

log_message "Starting remediation: Remove web server"

for service in httpd nginx; do
    if systemctl is-enabled $service 2>/dev/null | grep -q enabled; then
        systemctl stop $service
        systemctl mask $service
        echo "✓ $service stopped and masked"
    fi
done

for pkg in httpd nginx; do
    if rpm -q $pkg > /dev/null 2>&1; then
        yum remove -y $pkg
        echo "✓ $pkg package removed"
    fi
done

if ! rpm -q httpd > /dev/null 2>&1 && ! rpm -q nginx > /dev/null 2>&1; then
    echo "✓ Web servers are not installed"
fi
'''
    elif '2.2.19' in script_num:  # xinetd
        script += '''echo "Disables xinetd services."
echo ""

log_message "Starting remediation: Remove xinetd"

if systemctl is-enabled xinetd 2>/dev/null | grep -q enabled; then
    systemctl stop xinetd
    systemctl mask xinetd
    echo "✓ xinetd service stopped and masked"
fi

if rpm -q xinetd > /dev/null 2>&1; then
    yum remove -y xinetd
    echo "✓ xinetd package removed"
else
    echo "✓ xinetd is not installed"
fi
'''
    elif '2.2.20' in script_num:  # X Window
        script += '''echo "Disables X Window server services."
echo ""

log_message "Starting remediation: Remove X Window server"

if rpm -qa | grep -q "xorg-x11-server"; then
    yum remove -y xorg-x11-server-common xorg-x11-server-Xorg
    echo "✓ X Window server packages removed"
else
    echo "✓ X Window server is not installed"
fi
'''
    elif '2.2.21' in script_num:  # MTA local only
        script += '''echo "Configures mail transfer agent for local-only mode."
echo ""

log_message "Starting remediation: Configure MTA local-only"

CONFIG_FILE="/etc/postfix/main.cf"

if rpm -q postfix > /dev/null 2>&1; then
    backup_file "$CONFIG_FILE"
    
    if ! grep -q "^inet_interfaces = loopback-only" "$CONFIG_FILE" 2>/dev/null; then
        sed -i 's/^inet_interfaces.*/inet_interfaces = loopback-only/' "$CONFIG_FILE"
        echo "inet_interfaces = loopback-only" >> "$CONFIG_FILE"
        systemctl restart postfix
        echo "✓ Postfix configured for local-only mode"
    else
        echo "✓ Postfix already configured for local-only mode"
    fi
else
    echo "✓ Postfix is not installed"
fi
'''
    elif '2.2.22' in script_num:  # Manual - approved services
        script += '''echo "Manual check: Ensure only approved services are listening."
echo ""
echo "This is a MANUAL control requiring administrator review."
echo ""
echo "Run the following command to see listening services:"
echo "  ss -plntu"
echo ""
echo "Review each service and ensure only approved services are running."
echo ""

log_message "Manual remediation: Check listening services"

echo "Current listening services:"
ss -plntu 2>/dev/null || netstat -plntu 2>/dev/null

echo ""
echo "✓ Manual review required - listing displayed above"
'''
    elif '2.3.1' in script_num:  # ftp client
        script += '''echo "Removes FTP client package."
echo ""

log_message "Starting remediation: Remove FTP client"

if rpm -q ftp > /dev/null 2>&1; then
    yum remove -y ftp
    echo "✓ ftp client package removed"
else
    echo "✓ ftp client is not installed"
fi
'''
    elif '2.3.2' in script_num:  # ldap client
        script += '''echo "Removes LDAP client package."
echo ""

log_message "Starting remediation: Remove LDAP client"

if rpm -q openldap-clients > /dev/null 2>&1; then
    yum remove -y openldap-clients
    echo "✓ openldap-clients package removed"
else
    echo "✓ openldap-clients is not installed"
fi
'''
    elif '2.3.3' in script_num:  # nis client
        script += '''echo "Removes NIS client package."
echo ""

log_message "Starting remediation: Remove NIS client"

if rpm -q ypbind > /dev/null 2>&1; then
    yum remove -y ypbind
    echo "✓ ypbind package removed"
else
    echo "✓ ypbind is not installed"
fi
'''
    elif '2.3.4' in script_num:  # telnet client
        script += '''echo "Removes telnet client package."
echo ""

log_message "Starting remediation: Remove telnet client"

if rpm -q telnet > /dev/null 2>&1; then
    yum remove -y telnet
    echo "✓ telnet client package removed"
else
    echo "✓ telnet client is not installed"
fi
'''
    elif '2.3.5' in script_num:  # tftp client
        script += '''echo "Removes TFTP client package."
echo ""

log_message "Starting remediation: Remove TFTP client"

if rpm -q tftp > /dev/null 2>&1; then
    yum remove -y tftp
    echo "✓ tftp client package removed"
else
    echo "✓ tftp client is not installed"
fi
'''
    
    # Add footer
    script += '''
log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
'''
    
    # Write script file
    filename = f"section2_scripts/{script_num}.sh"
    with open(filename, 'w') as f:
        f.write(script)
    
    scripts_created.append(script_num)
    print(f"✓ Created: {script_num}.sh")

print(f"\n" + "=" * 100)
print(f"Successfully generated {len(scripts_created)} Section 2 scripts!")
print("=" * 100)
