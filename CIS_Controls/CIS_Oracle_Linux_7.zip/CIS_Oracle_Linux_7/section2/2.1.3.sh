#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 2.1.3.sh
# CIS Control - 2.1.3 Ensure chrony is not run as the root user (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="2.1.3.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "2.1.3 Ensure chrony is not run as the root user (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Ensures chrony daemon does not run as root user."
echo ""

log_message "Starting remediation: chrony user configuration"

CONFIG_FILE="/etc/sysconfig/chronyd"
backup_file "$CONFIG_FILE"

if ! grep -q "^OPTIONS.*-u chrony" "$CONFIG_FILE" 2>/dev/null; then
    echo 'OPTIONS="-u chrony"' >> "$CONFIG_FILE"
    systemctl restart chronyd
    echo "✓ chrony configured to run as chrony user"
else
    echo "✓ chrony already configured to run as non-root user"
fi

ps aux | grep chronyd | grep -v grep

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
