#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 2.3.4.sh
# CIS Control - 2.3.4 Ensure telnet client is not installed (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="2.3.4.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error.log"

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$ERROR_LOG")"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$BACKUP_DIR/$(basename "$file")_$(date +%Y%m%d)" 2>/dev/null
    fi
}

echo ""
echo ""
echo ""
echo "=============================================="
echo "Automated Remediation: $SCRIPT_NAME"
echo "2.3.4 Ensure telnet client is not installed (Automated)"
echo "=============================================="
echo ""
echo "Description:"
echo "Removes telnet client package."
echo ""

log_message "Starting remediation: Remove telnet client"

if rpm -q telnet > /dev/null 2>&1; then
    yum remove -y telnet
    echo "✓ telnet client package removed"
else
    echo "✓ telnet client is not installed"
fi

log_message "Remediation completed successfully"
echo ""
echo ""
echo "✓ Remediation completed"
exit 0
