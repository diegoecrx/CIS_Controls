#!/bin/bash

# ID: 5.4.3
# Nome Completo: 5.4.3 Ensure password hashing algorithm is SHA-512 (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# '^\h*password\h+(sufficient|requisite|required)\h+pam_unix\.so\h+([^#\n\r]+)?
# sha512(\h+.*)?$' /etc/pam.d/system-auth /etc/pam.d/password-auth
# /etc/pam.d/system-auth:password sufficient pam_unix.so sha512 shadow
# nullok try_first_pass use_authtok
# /etc/pam.d/password-auth:password sufficient pam_unix.so sha512 shadow
# nullok try_first_pass use_authtok

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -P
output_1=$( grep -P 2>&1 )
status_1=$?
echo "Audit command 1: grep -P"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    awk -F: '( $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"' && $1 !~
fi
