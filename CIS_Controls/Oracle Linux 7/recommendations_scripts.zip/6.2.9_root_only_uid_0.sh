#!/bin/bash

# ID: 6.2.9
# Nome Completo: 6.2.9 Ensure root is the only UID 0 account (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# root

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: awk -F: '($3 == 0) { print $1 }' /etc/passwd
output_1=$( awk -F: '($3 == 0) { print $1 }' /etc/passwd 2>&1 )
status_1=$?
echo "Audit command 1: awk -F: '($3 == 0) { print $1 }' /etc/passwd"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Remove any users other than root with UID 0 or assign them a new UID if appropriate.
fi
