#!/bin/bash

# ID: 1.1.6
# Nome Completo: 1.1.6 Ensure /dev/shm is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# tmpfs on /dev/shm type tmpfs (rw,nosuid,nodev,noexec,relatime,seclabel)
# tmpfs /dev/shm tmpfs defaults,noexec,nodev,nosuid 0 0

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: findmnt -n /dev/shm
output_1=$( findmnt -n /dev/shm 2>&1 )
status_1=$?
echo "Audit command 1: findmnt -n /dev/shm"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '\s/dev/shm\s' /etc/fstab
output_2=$( grep -E '\s/dev/shm\s' /etc/fstab 2>&1 )
status_2=$?
echo "Audit command 2: grep -E '\s/dev/shm\s' /etc/fstab"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    mount -o remount,noexec,nodev,nosuid /dev/shm
fi
