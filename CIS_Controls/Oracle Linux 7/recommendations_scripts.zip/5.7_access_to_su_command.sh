#!/bin/bash

# ID: 5.7
# Nome Completo: 5.7 Ensure access to the su command is restricted (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# '^\h*auth\h+(?:required|requisite)\h+pam_wheel\.so\h+(?:[^#\n\r]+\h+)?((?!\2)
# (use_uid\b|group=\H+\b))\h+(?:[^#\n\r]+\h+)?((?!\1)(use_uid\b|group=\H+\b))(\
# h+.*)?$' /etc/pam.d/su
# auth required pam_wheel.so use_uid group=<group_name>
# no users:
# There should be no users listed after the Group ID field.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -Pi
output_1=$( grep -Pi 2>&1 )
status_1=$?
echo "Audit command 1: grep -Pi"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep <group_name> /etc/group
output_2=$( grep <group_name> /etc/group 2>&1 )
status_2=$?
echo "Audit command 2: grep <group_name> /etc/group"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    groupadd sugroup
fi
