#!/bin/bash

# ID: 1.1.20
# Nome Completo: 1.1.20 Ensure nodev option set on removable media partitions (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# partitions.
# for rmpo in $(lsblk -o RM,MOUNTPOINT | awk -F " " '/1/ {print $2}'); do
# findmnt -n "$rmpo" | grep -Ev "\bnodev\b"
# done
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/usr/bin/bash
output_1=$( !/usr/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/usr/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/fstab file and add nodev to the fourth field (mounting options) of all
    # removable media partitions. Look for entries that have mount points that contain words
    # such as floppy or cdrom. See the fstab(5) manual page for more information.
fi
