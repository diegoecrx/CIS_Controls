#!/bin/bash

# ID: 2.2.17
# Nome Completo: 2.2.17 Ensure nfs-utils is not installed or the nfs-server service is masked (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# package nfs-utils is not installed
# OR
# If the nfs-package is required as a dependency, run the following command to verify that
# the nfs-server service is masked:
# masked

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q nfs-utils
output_1=$( rpm -q nfs-utils 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q nfs-utils"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled nfs-server
output_2=$( systemctl is-enabled nfs-server 2>&1 )
status_2=$?
echo "Audit command 2: systemctl is-enabled nfs-server"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove nfs-utils
    systemctl --now mask nfs-server
fi
