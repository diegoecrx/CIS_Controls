#!/bin/bash

# ID: 3.5.1.3
# Nome Completo: 3.5.1.3 Ensure nftables either not installed or masked with firewalld (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# package nftables is not installed
# OR
# \((running|exited)\) "
# No output should be returned
# masked

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q nftables
output_1=$( rpm -q nftables 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q nftables"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl status nftables | grep "Active: " | grep -E " active
output_2=$( systemctl status nftables | grep "Active: " | grep -E " active 2>&1 )
status_2=$?
echo "Audit command 2: systemctl status nftables | grep "Active: " | grep -E " active"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled nftables
output_3=$( systemctl is-enabled nftables 2>&1 )
status_3=$?
echo "Audit command 3: systemctl is-enabled nftables"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove nftables
fi
