#!/bin/bash

# ID: 4.1.11
# Nome Completo: 4.1.11 Ensure use of privileged commands is collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# programs can be executed from on your system:
# '{print "-a always,exit -F path=" $1 " -F perm=x -F auid>='"$(awk
# '/^\s*UID_MIN/{print $2}' /etc/login.defs)"' -F auid!=4294967295 -k
# privileged" }'
# auditctl -l.
# Note: The .rules file output will be auid!=-1 not auid!=4294967295

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: find <partition> -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk
output_1=$( find <partition> -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk 2>&1 )
status_1=$?
echo "Audit command 1: find <partition> -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    find <partition> -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk
    find / -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk '{print "-a
fi
