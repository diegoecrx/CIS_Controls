#!/bin/bash

# ID: 3.5.2.11
# Nome Completo: 3.5.2.11 Ensure nftables rules are permanent (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# configured to be applied to a nftables ruleset on boot:
# $2 }' /etc/sysconfig/nftables.conf)
# Output should be similar to:
# type filter hook input priority 0; policy drop;
# iif "lo" accept
# ip saddr 127.0.0.0/8 counter packets 0 bytes 0 drop
# ip6 saddr ::1 counter packets 0 bytes 0 drop
# ip protocol tcp ct state established accept
# ip protocol udp ct state established accept
# ip protocol icmp ct state established accept
# tcp dport ssh accept
# icmpv6 type { destination-unreachable, packet-too-big, time-
# exceeded, parameter-problem, mld-listener-query, mld-listener-report, mld-
# listener-done, nd-router-solicit, nd-router-advert, nd-neighbor-solicit, nd-
# neighbor-advert, ind-neighbor-solicit, ind-neighbor-advert, mld2-listener-
# report } accept
# Note: Review the input base chain to ensure that it follows local site policy
# $2 }' /etc/sysconfig/nftables.conf)
# Output should be similar to:
# network packets)
# chain forward {
# type filter hook forward priority 0; policy drop;
# }
# Note: Review the forward base chain to ensure that it follows local site policy.
# $2 }' /etc/sysconfig/nftables.conf)
# Output should be similar to:
# packets)
# chain output {
# type filter hook output priority 0; policy drop;
# ip protocol tcp ct state established,related,new accept
# ip protocol tcp ct state established,related,new accept
# ip protocol udp ct state established,related,new accept
# ip protocol icmp ct state established,related,new accept
# }
# Note: Review the output base chain to ensure that it follows local site policy.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: awk '/hook input/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print
output_1=$( awk '/hook input/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print 2>&1 )
status_1=$?
echo "Audit command 1: awk '/hook input/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Ensure loopback traffic is configured
output_2=$( Ensure loopback traffic is configured 2>&1 )
status_2=$?
echo "Audit command 2: Ensure loopback traffic is configured"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Ensure established connections are configured
output_3=$( Ensure established connections are configured 2>&1 )
status_3=$?
echo "Audit command 3: Ensure established connections are configured"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Accept port 22(SSH) traffic from anywhere
output_4=$( Accept port 22(SSH) traffic from anywhere 2>&1 )
status_4=$?
echo "Audit command 4: Accept port 22(SSH) traffic from anywhere"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Accept ICMP and IGMP from anywhere
output_5=$( Accept ICMP and IGMP from anywhere 2>&1 )
status_5=$?
echo "Audit command 5: Accept ICMP and IGMP from anywhere"
echo "Output:" "$$output_5"
echo "Status: $status_5"
if [ $status_5 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: awk '/hook forward/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print
output_6=$( awk '/hook forward/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print 2>&1 )
status_6=$?
echo "Audit command 6: awk '/hook forward/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print"
echo "Output:" "$$output_6"
echo "Status: $status_6"
if [ $status_6 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Base chain for hook forward named forward (Filters forwarded
output_7=$( Base chain for hook forward named forward (Filters forwarded 2>&1 )
status_7=$?
echo "Audit command 7: Base chain for hook forward named forward (Filters forwarded"
echo "Output:" "$$output_7"
echo "Status: $status_7"
if [ $status_7 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: awk '/hook output/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print
output_8=$( awk '/hook output/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print 2>&1 )
status_8=$?
echo "Audit command 8: awk '/hook output/,/}/' $(awk '$1 ~ /^\s*include/ { gsub("\"","",$2);print"
echo "Output:" "$$output_8"
echo "Status: $status_8"
if [ $status_8 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Base chain for hook output named output (Filters outbound network
output_9=$( Base chain for hook output named output (Filters outbound network 2>&1 )
status_9=$?
echo "Audit command 9: Base chain for hook output named output (Filters outbound network"
echo "Output:" "$$output_9"
echo "Status: $status_9"
if [ $status_9 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: Ensure outbound and established connections are configured
output_10=$( Ensure outbound and established connections are configured 2>&1 )
status_10=$?
echo "Audit command 10: Ensure outbound and established connections are configured"
echo "Output:" "$$output_10"
echo "Status: $status_10"
if [ $status_10 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/sysconfig/nftables.conf file and un-comment or add a line with include
    # <Absolute path to nftables rules file> for each nftables file you want included in the
    # nftables ruleset on boot:
    # Example:
    # include "/etc/nftables/nftables.rules"
fi
