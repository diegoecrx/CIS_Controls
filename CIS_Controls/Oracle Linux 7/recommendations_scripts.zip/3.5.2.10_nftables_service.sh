#!/bin/bash

# ID: 3.5.2.10
# Nome Completo: 3.5.2.10 Ensure nftables service is enabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# enabled

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: systemctl is-enabled nftables
output_1=$( systemctl is-enabled nftables 2>&1 )
status_1=$?
echo "Audit command 1: systemctl is-enabled nftables"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    systemctl enable nftables
fi
