#!/bin/bash

# ID: 1.8.1
# Nome Completo: 1.8.1 Ensure GNOME Display Manager is removed (Manual)
# Profile Applicability: Level 2 - Server
PROFILE_APPLICABILITY="Level 2 - Server"

# Expected output for audit:
# package gdm is not installed

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q gdm
output_1=$( rpm -q gdm 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q gdm"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove gdm
fi
