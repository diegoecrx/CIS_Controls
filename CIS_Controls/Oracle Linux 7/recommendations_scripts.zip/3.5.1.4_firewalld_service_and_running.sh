#!/bin/bash

# ID: 3.5.1.4
# Nome Completo: 3.5.1.4 Ensure firewalld service enabled and running (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# enabled

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: systemctl is-enabled firewalld
output_1=$( systemctl is-enabled firewalld 2>&1 )
status_1=$?
echo "Audit command 1: systemctl is-enabled firewalld"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: firewall-cmd --state
output_2=$( firewall-cmd --state 2>&1 )
status_2=$?
echo "Audit command 2: firewall-cmd --state"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    systemctl unmask firewalld
    systemctl --now enable firewalld
fi
