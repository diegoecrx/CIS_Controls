#!/bin/bash

# ID: 3.2.1
# Nome Completo: 3.2.1 Ensure IP forwarding is disabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# net.ipv4.ip_forward = 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# No value should be returned
# IFIPv6 is enabled:
# net.ipv6.conf.all.forwarding = 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# No value should be returned
# OR
# [ -n "$passing" ] && passing=""
# [ -z "$(grep "^\s*linux" /boot/grub2/grub.cfg | grep -v ipv6.disable=1)" ] &&
# passing="true"
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$"
# /etc/sysctl.conf \
# /etc/sysctl.d/*.conf && grep -Eq
# "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" \
# /etc/sysctl.conf /etc/sysctl.d/*.conf && sysctl
# net.ipv6.conf.all.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" && \
# sysctl net.ipv6.conf.default.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" &&
# passing="true"
# if [ "$passing" = true ] ; then
# echo "IPv6 is disabled on the system"
# else
# echo "IPv6 is enabled on the system"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sysctl net.ipv4.ip_forward
output_1=$( sysctl net.ipv4.ip_forward 2>&1 )
status_1=$?
echo "Audit command 1: sysctl net.ipv4.ip_forward"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E -s "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf
output_2=$( grep -E -s "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep -E -s "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: sysctl net.ipv6.conf.all.forwarding
output_3=$( sysctl net.ipv6.conf.all.forwarding 2>&1 )
status_3=$?
echo "Audit command 3: sysctl net.ipv6.conf.all.forwarding"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E -s "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf
output_4=$( grep -E -s "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf 2>&1 )
status_4=$?
echo "Audit command 4: grep -E -s "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: !/bin/bash
output_5=$( !/bin/bash 2>&1 )
status_5=$?
echo "Audit command 5: !/bin/bash"
echo "Output:" "$$output_5"
echo "Status: $status_5"
if [ $status_5 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    grep -Els "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf
    grep -Els "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf
fi
