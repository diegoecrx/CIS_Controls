#!/bin/bash

# ID: 3.5.2.4
# Nome Completo: 3.5.2.4 Ensure iptables are flushed with nftables (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# For iptables:
# No rules should be returned
# For ip6tables:
# No rules should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: iptables -L
output_1=$( iptables -L 2>&1 )
status_1=$?
echo "Audit command 1: iptables -L"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: ip6tables -L
output_2=$( ip6tables -L 2>&1 )
status_2=$?
echo "Audit command 2: ip6tables -L"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    iptables -F
    ip6tables -F
fi
