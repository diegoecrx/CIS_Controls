#!/bin/bash

# ID: 4.1.2.4
# Nome Completo: 4.1.2.4 Ensure audit_backlog_limit is sufficient (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# appropriate size for your organization
# efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
# gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
# if [ -f "$efidir"/grub.cfg ]; then
# grep "^\s*linux" "$efidir"/grub.cfg | grep -Evq
# "audit_backlog_limit=\S+\b" && echo -e "\n\nFAILED" || echo -e "\n\nPASSED:\n
# \"$(grep "audit_backlog_limit=" "$gbdir"/grub.cfg)\""
# elif [ -f "$gbdir"/grub.cfg ]; then
# grep "^\s*linux" "$gbdir"/grub.cfg | grep -Evq "audit_backlog_limit=\S+\b"
# && echo -e "\n\nFAILED" || echo -e "\n\nPASSED:\n \"$(grep
# "audit_backlog_limit=" "$gbdir"/grub.cfg)\""
# else
# echo "FAILED"
# fi
# Ensure the the returned value complies with local site policy. It's recommended that this value
# be 8192 or larger.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: IF check passes return PASSED
output_2=$( IF check passes return PASSED 2>&1 )
status_2=$?
echo "Audit command 2: IF check passes return PASSED"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    grub2-mkconfig -o /boot/grub2/grub.cfg
fi
