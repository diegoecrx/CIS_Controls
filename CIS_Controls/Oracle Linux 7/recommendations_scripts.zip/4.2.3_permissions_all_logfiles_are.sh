#!/bin/bash

# ID: 4.2.3
# Nome Completo: 4.2.3 Ensure permissions on all logfiles are configured (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# group does not have write or execute permissions on any files:
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: find /var/log -type f -perm /g+wx,o+rwx -exec ls -l {} \;
output_1=$( find /var/log -type f -perm /g+wx,o+rwx -exec ls -l {} \; 2>&1 )
status_1=$?
echo "Audit command 1: find /var/log -type f -perm /g+wx,o+rwx -exec ls -l {} \;"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    find /var/log -type f -exec chmod g-wx,o-rwx "{}" +
fi
