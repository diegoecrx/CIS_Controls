#!/bin/bash

# ID: 5.4.1
# Nome Completo: 5.4.1 Ensure password creation requirements are configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# characters.
# minlen = 14
# minclass = 4
# OR
# dcredit = -1
# ucredit = -1
# lcredit = -1
# ocredit = -1
# /etc/pam.d/system-auth include try_first_pass and retry=3 on the password
# requisite pam_pwquality.so line.
# '^\s*password\s+(?:requisite|required)\s+pam_pwquality\.so\s+(?:\S+\s+)*(?!\2
# )(retry=[1-3]|try_first_pass)\s+(?:\S+\s+)*(?!\1)(retry=[1-
# 3]|try_first_pass)\s*(?:\s+\S+\s*)*(?:\s+#.*)?$' /etc/pam.d/password-auth
# password requisite pam_pwquality.so try_first_pass retry=3
# '^\s*password\s+(?:requisite|required)\s+pam_pwquality\.so\s+(?:\S+\s+)*(?!\2
# )(retry=[1-3]|try_first_pass)\s+(?:\S+\s+)*(?!\1)(retry=[1-
# 3]|try_first_pass)\s*(?:\s+\S+\s*)*(?:\s+#.*)?$' /etc/pam.d/system-auth
# password requisite pam_pwquality.so try_first_pass retry=3

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep '^\s*minlen\s*' /etc/security/pwquality.conf
output_1=$( grep '^\s*minlen\s*' /etc/security/pwquality.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep '^\s*minlen\s*' /etc/security/pwquality.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep '^\s*minclass\s*' /etc/security/pwquality.conf
output_2=$( grep '^\s*minclass\s*' /etc/security/pwquality.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep '^\s*minclass\s*' /etc/security/pwquality.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '^\s*[duol]credit\s*' /etc/security/pwquality.conf
output_3=$( grep -E '^\s*[duol]credit\s*' /etc/security/pwquality.conf 2>&1 )
status_3=$?
echo "Audit command 3: grep -E '^\s*[duol]credit\s*' /etc/security/pwquality.conf"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -P
output_4=$( grep -P 2>&1 )
status_4=$?
echo "Audit command 4: grep -P"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -P
output_5=$( grep -P 2>&1 )
status_5=$?
echo "Audit command 5: grep -P"
echo "Output:" "$$output_5"
echo "Status: $status_5"
if [ $status_5 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the file /etc/security/pwquality.conf and add or modify the following line for
    # password length to conform to site policy
    # minlen = 14
    # Edit the file /etc/security/pwquality.conf and add or modify the following line for
    # password complexity to conform to site policy
    # minclass = 4
    # OR
    # dcredit = -1
    # ucredit = -1
    # ocredit = -1
    # lcredit = -1
    # Edit the /etc/pam.d/password-auth and /etc/pam.d/system-auth files to include the
    # appropriate options for pam_pwquality.so and to conform to site policy:
    # password requisite pam_pwquality.so try_first_pass retry=3
fi
