#!/bin/bash

# ID: 6.2.14
# Nome Completo: 6.2.14 Ensure users' dot files are not group or world writable (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ &&
# $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {
# print $1 " " $6 }' /etc/passwd | while read -r user dir; do
# if [ -d "$dir" ]; then
# for file in "$dir"/.*; do
# if [ ! -h "$file" ] && [ -f "$file" ]; then
# fileperm=$(stat -L -c "%A" "$file")
# if [ "$(echo "$fileperm" | cut -c6)" != "-" ] || [ "$(echo
# "$fileperm" | cut -c9)" != "-" ]; then
# echo "User: \"$user\" file: \"$file\" has permissions:
# \"$fileperm\""
# fi
# fi
# done
# fi
# done

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    !/bin/bash
fi
