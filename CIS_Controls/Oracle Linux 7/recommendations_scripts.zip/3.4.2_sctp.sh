#!/bin/bash

# ID: 3.4.2
# Nome Completo: 3.4.2 Ensure SCTP is disabled (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# install /bin/true

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: modprobe -n -v sctp
output_1=$( modprobe -n -v sctp 2>&1 )
status_1=$?
echo "Audit command 1: modprobe -n -v sctp"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: lsmod | grep sctp
output_2=$( lsmod | grep sctp 2>&1 )
status_2=$?
echo "Audit command 2: lsmod | grep sctp"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit or create a file in the /etc/modprobe.d/ directory ending in .conf
    # Example: vim /etc/modprobe.d/sctp.conf
    # Add the following line:
    # install sctp /bin/true
fi
