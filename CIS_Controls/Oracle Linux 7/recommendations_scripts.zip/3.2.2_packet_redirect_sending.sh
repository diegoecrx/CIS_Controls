#!/bin/bash

# ID: 3.2.2
# Nome Completo: 3.2.2 Ensure packet redirect sending is disabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# net.ipv4.conf.all.send_redirects = 0
# net.ipv4.conf.default.send_redirects = 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv4.conf.all.send_redirects = 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv4.conf.default.send_redirects= 0

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sysctl net.ipv4.conf.all.send_redirects
output_1=$( sysctl net.ipv4.conf.all.send_redirects 2>&1 )
status_1=$?
echo "Audit command 1: sysctl net.ipv4.conf.all.send_redirects"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: sysctl net.ipv4.conf.default.send_redirects
output_2=$( sysctl net.ipv4.conf.default.send_redirects 2>&1 )
status_2=$?
echo "Audit command 2: sysctl net.ipv4.conf.default.send_redirects"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv4\.conf\.all\.send_redirects" /etc/sysctl.conf
output_3=$( grep "net\.ipv4\.conf\.all\.send_redirects" /etc/sysctl.conf 2>&1 )
status_3=$?
echo "Audit command 3: grep "net\.ipv4\.conf\.all\.send_redirects" /etc/sysctl.conf"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv4\.conf\.default\.send_redirects" /etc/sysctl.conf
output_4=$( grep "net\.ipv4\.conf\.default\.send_redirects" /etc/sysctl.conf 2>&1 )
status_4=$?
echo "Audit command 4: grep "net\.ipv4\.conf\.default\.send_redirects" /etc/sysctl.conf"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    sysctl -w net.ipv4.conf.all.send_redirects=0
    sysctl -w net.ipv4.conf.default.send_redirects=0
    sysctl -w net.ipv4.route.flush=1
fi
