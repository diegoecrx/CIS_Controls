#!/bin/bash

# ID: 2.2.15
# Nome Completo: 2.2.15 Ensure telnet-server is not installed (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# rpm -q telnet-server
# package telnet-server is not installed

# No audit commands found. Manual verification may be required.
# Applying remediation commands
yum remove telnet-server
