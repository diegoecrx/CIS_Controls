#!/bin/bash

# ID: 3.5.2.8
# Nome Completo: 3.5.2.8 Ensure nftables outbound and established connections are configured (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# match site policy: site policy:
# (tcp|udp|icmp) ct state'
# Output should be similar to:
# ip protocol tcp ct state established accept
# ip protocol udp ct state established accept
# ip protocol icmp ct state established accept
# connections match site policy
# (tcp|udp|icmp) ct state'
# Output should be similar to:
# ip protocol tcp ct state established,related,new accept
# ip protocol udp ct state established,related,new accept
# ip protocol icmp ct state established,related,new accept

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: nft list ruleset | awk '/hook input/,/}/' | grep -E 'ip protocol
output_1=$( nft list ruleset | awk '/hook input/,/}/' | grep -E 'ip protocol 2>&1 )
status_1=$?
echo "Audit command 1: nft list ruleset | awk '/hook input/,/}/' | grep -E 'ip protocol"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: nft list ruleset | awk '/hook output/,/}/' | grep -E 'ip protocol
output_2=$( nft list ruleset | awk '/hook output/,/}/' | grep -E 'ip protocol 2>&1 )
status_2=$?
echo "Audit command 2: nft list ruleset | awk '/hook output/,/}/' | grep -E 'ip protocol"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    nft add rule inet filter input ip protocol tcp ct state established accept
    nft add rule inet filter input ip protocol udp ct state established accept
    nft add rule inet filter input ip protocol icmp ct state established accept
    nft add rule inet filter output ip protocol tcp ct state
    nft add rule inet filter output ip protocol udp ct state
    nft add rule inet filter output ip protocol icmp ct state
fi
