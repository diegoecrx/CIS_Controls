#!/bin/bash

# ID: 1.1.24
# Nome Completo: 1.1.24 Disable USB Storage (Automated)
# Profile Applicability: Level 1 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 2 - Workstation"

# Expected output for audit:
# install /bin/true

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: modprobe -n -v usb-storage
output_1=$( modprobe -n -v usb-storage 2>&1 )
status_1=$?
echo "Audit command 1: modprobe -n -v usb-storage"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: lsmod | grep usb-storage
output_2=$( lsmod | grep usb-storage 2>&1 )
status_2=$?
echo "Audit command 2: lsmod | grep usb-storage"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit or create a file in the /etc/modprobe.d/ directory ending in .conf
    # Example: vim /etc/modprobe.d/usb_storage.conf
    # Add the following line:
    # install usb-storage /bin/true
    # Run the following command to unload the usb-storage module:
    # rmmod usb-storage
    # 
    # 
    # 
    # 
    # Additional Information:
    # 
    # An alternative solution to disabling the usb-storage module may be found in
    # USBGuard.
    # 
    # Use of USBGuard and construction of USB device policies should be done in
    # alignment with site policy.
fi
