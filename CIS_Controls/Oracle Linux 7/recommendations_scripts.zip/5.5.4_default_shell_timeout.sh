#!/bin/bash

# ID: 5.5.4
# Nome Completo: 5.5.4 Ensure default user shell timeout is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# than 900 seconds, to be readonly, to be exported, and is not being changed to a longer
# timeout.
# output1="" output2=""
# [ -f /etc/bashrc ] && BRC="/etc/bashrc"
# for f in "$BRC" /etc/profile /etc/profile.d/*.sh ; do
# grep -Pq '^\s*([^#]+\s+)?TMOUT=(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\b'
# "$f" && grep -Pq '^\s*([^#]+;\s*)?readonly\s+TMOUT(\s+|\s*;|\s*$|=(900|[1-
# 8][0-9][0-9]|[1-9][0-9]|[1-9]))\b' "$f" && grep -Pq
# '^\s*([^#]+;\s*)?export\s+TMOUT(\s+|\s*;|\s*$|=(900|[1-8][0-9][0-9]|[1-9][0-
# 9]|[1-9]))\b' "$f" && output1="$f"
# done
# grep -Pq '^\s*([^#]+\s+)?TMOUT=(9[0-9][1-9]|9[1-9][0-9]|0+|[1-9]\d{3,})\b'
# /etc/profile /etc/profile.d/*.sh "$BRC" && output2=$(grep -Ps
# '^\s*([^#]+\s+)?TMOUT=(9[0-9][1-9]|9[1-9][0-9]|0+|[1-9]\d{3,})\b'
# /etc/profile /etc/profile.d/*.sh $BRC)
# if [ -n "$output1" ] && [ -z "$output2" ]; then
# echo -e "\nPASSED\n\nTMOUT is configured in: \"$output1\"\n"
# else
# [ -z "$output1" ] && echo -e "\nFAILED\n\nTMOUT is not configured\n"
# [ -n "$output2" ] && echo -e "\nFAILED\n\nTMOUT is incorrectly configured
# in: \"$output2\"\n"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Review /etc/bashrc, /etc/profile, and all files ending in *.sh in the /etc/profile.d/
    # directory and remove or edit all TMOUT=_n_ entries to follow local site policy. TMOUT should
    # not exceed 900 or be equal to 0.
    # Configure TMOUT in one of the following files:
    # 
    # A file in the /etc/profile.d/ directory ending in .sh
    # 
    # /etc/profile
    # 
    # /etc/bashrc
    # TMOUT configuration examples:
    # 
    # As multiple lines:
    # TMOUT=900
    # readonly TMOUT
    # export TMOUT
    # 
    # As a single line:
    # readonly TMOUT=900 ; export TMOUT
    # 
    # 
    # 
    # 
    # Additional Information:
    # 
    # The audit and remediation in this recommendation apply to bash and shell. If other
    # shells are supported on the system, it is recommended that their configuration files
    # are also checked. Other methods of setting a timeout exist for other shells not
    # covered here.
    # 
    # Ensure that the timeout conforms to your local policy.
fi
