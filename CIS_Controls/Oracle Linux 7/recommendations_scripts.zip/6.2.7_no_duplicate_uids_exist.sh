#!/bin/bash

# ID: 6.2.7
# Nome Completo: 6.2.7 Ensure no duplicate UIDs exist (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# cut -f3 -d":" /etc/passwd | sort -n | uniq -c | while read -r x; do
# [ -z "$x" ] && break
# set - "$x"
# if [ "$1" -gt 1 ]; then
# users=$(awk -F: '($3 == n) { print $1 }' n="$2" /etc/passwd | xargs)
# echo "Duplicate UID ($2): $users"
# fi
# done

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Based on the results of the audit script, establish unique UIDs and review all files owned by
    # the shared UIDs to determine which UID they are supposed to belong to.
fi
