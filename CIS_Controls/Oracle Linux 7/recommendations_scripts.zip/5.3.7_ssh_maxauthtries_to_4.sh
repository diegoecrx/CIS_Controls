#!/bin/bash

# ID: 5.3.7
# Nome Completo: 5.3.7 Ensure SSH MaxAuthTries is set to 4 or less (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /etc/hosts | awk '{print $1}')" | grep maxauthtries
# maxauthtries 4
# Nothing is returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)
output_1=$( sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) 2>&1 )
status_1=$?
echo "Audit command 1: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -Ei '^\s*maxauthtries\s+([5-9]|[1-9][0-9]+)' /etc/ssh/sshd_config
output_2=$( grep -Ei '^\s*maxauthtries\s+([5-9]|[1-9][0-9]+)' /etc/ssh/sshd_config 2>&1 )
status_2=$?
echo "Audit command 2: grep -Ei '^\s*maxauthtries\s+([5-9]|[1-9][0-9]+)' /etc/ssh/sshd_config"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/ssh/sshd_config file to set the parameter as follows:
    # MaxAuthTries 4
fi
