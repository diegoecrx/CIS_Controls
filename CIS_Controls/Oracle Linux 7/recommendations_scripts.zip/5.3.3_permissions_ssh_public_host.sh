#!/bin/bash

# ID: 5.3.3
# Nome Completo: 5.3.3 Ensure permissions on SSH public host key files are configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# to group or other for all returned files:
# Example Output:
# File: ‘/etc/ssh/ssh_host_rsa_key.pub’
# Size: 382 Blocks: 8 IO Block: 4096 regular file
# Device: ca01h/51713d Inode: 8631758 Links: 1
# Access: (0644/-rw-r--r--) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2018-10-22 18:24:56.861750616 +0000
# Modify: 2018-10-22 18:24:56.861750616 +0000
# Change: 2018-10-22 18:24:56.881750616 +0000
# Birth: -
# File: ‘/etc/ssh/ssh_host_ecdsa_key.pub’
# Size: 162 Blocks: 8 IO Block: 4096 regular file
# Device: ca01h/51713d Inode: 8631761 Links: 1
# Access: (0644/-rw-r--r--) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2018-10-22 18:24:56.897750616 +0000
# Modify: 2018-10-22 18:24:56.897750616 +0000
# Change: 2018-10-22 18:24:56.917750616 +0000
# Birth: -
# File: ‘/etc/ssh/ssh_host_ed25519_key.pub’
# Size: 82 Blocks: 8 IO Block: 4096 regular file
# Device: ca01h/51713d Inode: 8631763 Links: 1
# Access: (0644/-rw-r--r--) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2018-10-22 18:24:56.945750616 +0000
# Modify: 2018-10-22 18:24:56.945750616 +0000
# Change: 2018-10-22 18:24:56.961750616 +0000
# Birth: -

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec stat {} \;
output_1=$( find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec stat {} \; 2>&1 )
status_1=$?
echo "Audit command 1: find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec stat {} \;"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chmod u-x,go-
    find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chown
fi
