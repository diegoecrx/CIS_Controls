#!/bin/bash

# ID: 3.5.3.3.4
# Nome Completo: 3.5.3.3.4 Ensure ip6tables default deny firewall policy (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# FORWARD chains is DROP or REJECT:
# Chain INPUT (policy DROP)
# Chain FORWARD (policy DROP)
# Chain OUTPUT (policy DROP)
# OR
# [ -n "$passing" ] && passing=""
# [ -z "$(grep "^\s*linux" /boot/grub2/grub.cfg | grep -v ipv6.disable=1)" ] &&
# passing="true"
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$"
# /etc/sysctl.conf \
# /etc/sysctl.d/*.conf && grep -Eq
# "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" \
# /etc/sysctl.conf /etc/sysctl.d/*.conf && sysctl
# net.ipv6.conf.all.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" && \
# sysctl net.ipv6.conf.default.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" &&
# passing="true"
# if [ "$passing" = true ] ; then
# echo "IPv6 is disabled on the system"
# else
# echo "IPv6 is enabled on the system"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: ip6tables -L
output_1=$( ip6tables -L 2>&1 )
status_1=$?
echo "Audit command 1: ip6tables -L"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: !/bin/bash
output_2=$( !/bin/bash 2>&1 )
status_2=$?
echo "Audit command 2: !/bin/bash"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    ip6tables -P INPUT DROP
    ip6tables -P OUTPUT DROP
    ip6tables -P FORWARD DROP
fi
