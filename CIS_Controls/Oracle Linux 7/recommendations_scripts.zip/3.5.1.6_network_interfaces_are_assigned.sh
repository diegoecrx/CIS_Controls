#!/bin/bash

# ID: 3.5.1.6
# Nome Completo: 3.5.1.6 Ensure network interfaces are assigned to appropriate zone (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# netint; do [ "$netint" != "lo" ] && firewall-cmd --get-active-zones | grep -
# B1 $netint; done
# Example output:
# eth0

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: find /sys/class/net/* -maxdepth 1 | awk -F"/" '{print $NF}' | while read -r
output_1=$( find /sys/class/net/* -maxdepth 1 | awk -F"/" '{print $NF}' | while read -r 2>&1 )
status_1=$?
echo "Audit command 1: find /sys/class/net/* -maxdepth 1 | awk -F"/" '{print $NF}' | while read -r"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    firewall-cmd --zone=<Zone NAME> --change-interface=<INTERFACE NAME>
    firewall-cmd --zone=customezone --change-interface=eth0
fi
