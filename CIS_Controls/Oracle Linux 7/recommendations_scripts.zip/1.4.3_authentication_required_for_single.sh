#!/bin/bash

# ID: 1.4.3
# Nome Completo: 1.4.3 Ensure authentication required for single user mode (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# as shown:
# ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block
# default"
# ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block
# default"

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep /sbin/sulogin /usr/lib/systemd/system/rescue.service
output_1=$( grep /sbin/sulogin /usr/lib/systemd/system/rescue.service 2>&1 )
status_1=$?
echo "Audit command 1: grep /sbin/sulogin /usr/lib/systemd/system/rescue.service"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep /sbin/sulogin /usr/lib/systemd/system/emergency.service
output_2=$( grep /sbin/sulogin /usr/lib/systemd/system/emergency.service 2>&1 )
status_2=$?
echo "Audit command 2: grep /sbin/sulogin /usr/lib/systemd/system/emergency.service"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit /usr/lib/systemd/system/rescue.service and
    # /usr/lib/systemd/system/emergency.service and set ExecStart to use /sbin/sulogin or
    # /usr/sbin/sulogin:
    # ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block
    # default"
fi
