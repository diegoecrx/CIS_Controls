#!/bin/bash

# ID: 5.5.5
# Nome Completo: 5.5.5 Ensure default user umask is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# A default user umask is set to enforce a newly created directories' permissions to be
# 750 (drwxr-x---), and a newly created file's permissions be 640 (rw-r-----), or
# more restrictive
# No less restrictive System Wide umask is set
# directories's permissions to be 750 (drwxr-x---), and a newly created file's permissions be
# 640 (rw-r-----), or more restrictive:
# passing=""
# grep -Eiq '^\s*UMASK\s+(0[0-7][2-7]7|[0-7][2-7]7)\b' /etc/login.defs && grep
# -Eqi '^\s*USERGROUPS_ENAB\s*"?no"?\b' /etc/login.defs && grep -Eq
# '^\s*session\s+(optional|requisite|required)\s+pam_umask\.so\b'
# /etc/pam.d/common-session && passing=true
# grep -REiq '^\s*UMASK\s+\s*(0[0-7][2-7]7|[0-7][2-
# 7]7|u=(r?|w?|x?)(r?|w?|x?)(r?|w?|x?),g=(r?x?|x?r?),o=)\b' /etc/profile*
# /etc/bashrc* && passing=true
# [ "$passing" = true ] && echo "Default user umask is set"
# 6]\b|[0-7][01][0-7]\b|[0-7][0-7][0-
# 6]\b|(u=[rwx]{0,3},)?(g=[rwx]{0,3},)?o=[rwx]+\b|(u=[rwx]{1,3},)?g=[^rx]{1,3}(
# ,o=[rwx]{0,3})?\b)' /etc/login.defs /etc/profile* /etc/bashrc*
# No file should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -RPi '(^|^[^#]*)\s*umask\s+([0-7][0-7][01][0-7]\b|[0-7][0-7][0-7][0-
output_2=$( grep -RPi '(^|^[^#]*)\s*umask\s+([0-7][0-7][01][0-7]\b|[0-7][0-7][0-7][0- 2>&1 )
status_2=$?
echo "Audit command 2: grep -RPi '(^|^[^#]*)\s*umask\s+([0-7][0-7][01][0-7]\b|[0-7][0-7][0-7][0-"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    vi /etc/profile.d/set_umask.sh
    grep -RPi '(^|^[^#]*)\s*umask\s+([0-7][0-7][01][0-7]\b|[0-7][0-7][0-7][0-
fi
