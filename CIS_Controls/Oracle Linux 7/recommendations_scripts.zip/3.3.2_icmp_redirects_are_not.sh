#!/bin/bash

# ID: 3.3.2
# Nome Completo: 3.3.2 Ensure ICMP redirects are not accepted (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# net.ipv4.conf.all.accept_redirects = 0
# net.ipv4.conf.default.accept_redirects = 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv4.conf.all.accept_redirects= 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv4.conf.default.accept_redirects= 0
# IF IPv6 is not disabled:
# net.ipv6.conf.all.accept_redirects = 0
# net.ipv6.conf.default.accept_redirects = 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv6.conf.all.accept_redirects= 0
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv6.conf.default.accept_redirects= 0
# OR verify IPv6 is disabled:
# [ -n "$passing" ] && passing=""
# [ -z "$(grep "^\s*linux" /boot/grub2/grub.cfg | grep -v ipv6.disable=1)" ] &&
# passing="true"
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$"
# /etc/sysctl.conf \
# /etc/sysctl.d/*.conf && grep -Eq
# "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" \
# /etc/sysctl.conf /etc/sysctl.d/*.conf && sysctl
# net.ipv6.conf.all.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" && \
# sysctl net.ipv6.conf.default.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" &&
# passing="true"
# if [ "$passing" = true ] ; then
# echo "IPv6 is disabled on the system"
# else
# echo "IPv6 is enabled on the system"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sysctl net.ipv4.conf.all.accept_redirects
output_1=$( sysctl net.ipv4.conf.all.accept_redirects 2>&1 )
status_1=$?
echo "Audit command 1: sysctl net.ipv4.conf.all.accept_redirects"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: sysctl net.ipv4.conf.default.accept_redirects
output_2=$( sysctl net.ipv4.conf.default.accept_redirects 2>&1 )
status_2=$?
echo "Audit command 2: sysctl net.ipv4.conf.default.accept_redirects"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv4\.conf\.all\.accept_redirects" /etc/sysctl.conf
output_3=$( grep "net\.ipv4\.conf\.all\.accept_redirects" /etc/sysctl.conf 2>&1 )
status_3=$?
echo "Audit command 3: grep "net\.ipv4\.conf\.all\.accept_redirects" /etc/sysctl.conf"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv4\.conf\.default\.accept_redirects" /etc/sysctl.conf
output_4=$( grep "net\.ipv4\.conf\.default\.accept_redirects" /etc/sysctl.conf 2>&1 )
status_4=$?
echo "Audit command 4: grep "net\.ipv4\.conf\.default\.accept_redirects" /etc/sysctl.conf"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: sysctl net.ipv6.conf.all.accept_redirects
output_5=$( sysctl net.ipv6.conf.all.accept_redirects 2>&1 )
status_5=$?
echo "Audit command 5: sysctl net.ipv6.conf.all.accept_redirects"
echo "Output:" "$$output_5"
echo "Status: $status_5"
if [ $status_5 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: sysctl net.ipv6.conf.default.accept_redirects
output_6=$( sysctl net.ipv6.conf.default.accept_redirects 2>&1 )
status_6=$?
echo "Audit command 6: sysctl net.ipv6.conf.default.accept_redirects"
echo "Output:" "$$output_6"
echo "Status: $status_6"
if [ $status_6 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv6\.conf\.all\.accept_redirects" /etc/sysctl.conf
output_7=$( grep "net\.ipv6\.conf\.all\.accept_redirects" /etc/sysctl.conf 2>&1 )
status_7=$?
echo "Audit command 7: grep "net\.ipv6\.conf\.all\.accept_redirects" /etc/sysctl.conf"
echo "Output:" "$$output_7"
echo "Status: $status_7"
if [ $status_7 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv6\.conf\.default\.accept_redirects" /etc/sysctl.conf
output_8=$( grep "net\.ipv6\.conf\.default\.accept_redirects" /etc/sysctl.conf 2>&1 )
status_8=$?
echo "Audit command 8: grep "net\.ipv6\.conf\.default\.accept_redirects" /etc/sysctl.conf"
echo "Output:" "$$output_8"
echo "Status: $status_8"
if [ $status_8 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: !/bin/bash
output_9=$( !/bin/bash 2>&1 )
status_9=$?
echo "Audit command 9: !/bin/bash"
echo "Output:" "$$output_9"
echo "Status: $status_9"
if [ $status_9 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    sysctl -w net.ipv4.conf.all.accept_redirects=0
    sysctl -w net.ipv4.conf.default.accept_redirects=0
    sysctl -w net.ipv4.route.flush=1
    sysctl -w net.ipv6.conf.all.accept_redirects=0
    sysctl -w net.ipv6.conf.default.accept_redirects=0
    sysctl -w net.ipv6.route.flush=1
fi
