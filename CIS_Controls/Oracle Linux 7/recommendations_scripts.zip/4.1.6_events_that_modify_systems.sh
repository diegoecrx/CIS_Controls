#!/bin/bash

# ID: 4.1.6
# Nome Completo: 4.1.6 Ensure events that modify the system's Mandatory Access Controls are collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# -w /etc/selinux/ -p wa -k MAC-policy
# -w /usr/share/selinux/ -p wa -k MAC-policy

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep MAC-policy /etc/audit/rules.d/*.rules
output_1=$( grep MAC-policy /etc/audit/rules.d/*.rules 2>&1 )
status_1=$?
echo "Audit command 1: grep MAC-policy /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep MAC-policy
output_2=$( auditctl -l | grep MAC-policy 2>&1 )
status_2=$?
echo "Audit command 2: auditctl -l | grep MAC-policy"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit or create a file in the /etc/audit/rules.d/ directory ending in .rules
    # Example: vi /etc/audit/rules.d/50-MAC_policy.rules
    # Add the following lines:
    # -w /etc/selinux/ -p wa -k MAC-policy
    # -w /usr/share/selinux/ -p wa -k MAC-policy
fi
