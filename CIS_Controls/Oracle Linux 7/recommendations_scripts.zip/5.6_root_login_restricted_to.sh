#!/bin/bash

# ID: 5.6
# Nome Completo: 5.6 Ensure root login is restricted to system console (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: cat /etc/securetty
output_1=$( cat /etc/securetty 2>&1 )
status_1=$?
echo "Audit command 1: cat /etc/securetty"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Remove entries for any consoles that are not in a physically secure location.
fi
