#!/bin/bash

# ID: 4.1.12
# Nome Completo: 4.1.12 Ensure successful file system mounts are collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# On a 32 bit system run the following commands:
# -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k
# mounts
# -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=-1 -k mounts
# On a 64 bit system run the following commands:
# -a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k
# mounts
# -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k
# mounts
# -a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=-1 -k mounts
# -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=-1 -k mounts

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep mounts /etc/audit/rules.d/*.rules
output_1=$( grep mounts /etc/audit/rules.d/*.rules 2>&1 )
status_1=$?
echo "Audit command 1: grep mounts /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep mounts
output_2=$( auditctl -l | grep mounts 2>&1 )
status_2=$?
echo "Audit command 2: auditctl -l | grep mounts"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep mounts /etc/audit/rules.d/*.rules
output_3=$( grep mounts /etc/audit/rules.d/*.rules 2>&1 )
status_3=$?
echo "Audit command 3: grep mounts /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep mounts
output_4=$( auditctl -l | grep mounts 2>&1 )
status_4=$?
echo "Audit command 4: auditctl -l | grep mounts"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # For 32 bit systems edit or create a file in the /etc/audit/rules.d/ directory ending in
    # .rules
    # Example: vi /etc/audit/rules.d/50-mounts.rules
    # Add the following lines:
    # -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k
    # mounts
    # For 64 bit systems Edit or create a file in the /etc/audit/rules.d/ directory ending in
    # .rules
    # Example: vi /etc/audit/rules.d/50-mounts.rules
    # Add the following lines:
    # -a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k
    # mounts
    # -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k
    # mounts
    # Additional Information:
    # This tracks successful and unsuccessful mount commands.
    # File system mounts do not have to come from external media and this action still does not
    # verify write (e.g. CD ROMS).
fi
