#!/bin/bash

# ID: 3.5.2.6
# Nome Completo: 3.5.2.6 Ensure nftables base chains exist (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# OUTPUT.
# type filter hook input priority 0;
# type filter hook forward priority 0;
# type filter hook output priority 0;

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: nft list ruleset | grep 'hook input'
output_1=$( nft list ruleset | grep 'hook input' 2>&1 )
status_1=$?
echo "Audit command 1: nft list ruleset | grep 'hook input'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: nft list ruleset | grep 'hook forward'
output_2=$( nft list ruleset | grep 'hook forward' 2>&1 )
status_2=$?
echo "Audit command 2: nft list ruleset | grep 'hook forward'"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: nft list ruleset | grep 'hook output'
output_3=$( nft list ruleset | grep 'hook output' 2>&1 )
status_3=$?
echo "Audit command 3: nft list ruleset | grep 'hook output'"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    nft create chain inet <table name> <base chain name> { type filter hook
    nft create chain inet filter input { type filter hook input priority 0 \; }
    nft create chain inet filter forward { type filter hook forward priority 0
    nft create chain inet filter output { type filter hook output priority 0 \;
fi
