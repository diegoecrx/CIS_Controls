#!/bin/bash

# ID: 5.5.1.3
# Nome Completo: 5.5.1.3 Ensure password expiration warning days is 7 or more (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# 7 days):
# PASS_WARN_AGE 7
# expires set to 7 or more:
# users' PASS_WARN_AGE conforms to site policy (No less than 7 days):

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep ^\s*PASS_WARN_AGE /etc/login.defs
output_1=$( grep ^\s*PASS_WARN_AGE /etc/login.defs 2>&1 )
status_1=$?
echo "Audit command 1: grep ^\s*PASS_WARN_AGE /etc/login.defs"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1,6
output_2=$( grep -E ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1,6 2>&1 )
status_2=$?
echo "Audit command 2: grep -E ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1,6"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    chage --warndays 7 <user>
fi
