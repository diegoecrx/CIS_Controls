#!/bin/bash

# ID: 2.2.18
# Nome Completo: 2.2.18 Ensure rpcbind is not installed or the rpcbind services are masked (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# package rpcbind is not installed
# OR
# If the rpcbind package is required as a dependency, run the following commands to verify
# that the rpcbind and rpcbind.socket services are masked:
# masked
# masked

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q rpcbind
output_1=$( rpm -q rpcbind 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q rpcbind"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled rpcbind
output_2=$( systemctl is-enabled rpcbind 2>&1 )
status_2=$?
echo "Audit command 2: systemctl is-enabled rpcbind"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled rpcbind.socket
output_3=$( systemctl is-enabled rpcbind.socket 2>&1 )
status_3=$?
echo "Audit command 3: systemctl is-enabled rpcbind.socket"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove rpcbind
    systemctl --now mask rpcbind
    systemctl --now mask rpcbind.socket
fi
