#!/bin/bash

# ID: 2.2.9
# Nome Completo: 2.2.9 Ensure HTTP server is not installed (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# package httpd is not installed

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q httpd
output_1=$( rpm -q httpd 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q httpd"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove httpd
fi
