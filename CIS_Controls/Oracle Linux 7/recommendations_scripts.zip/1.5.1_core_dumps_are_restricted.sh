#!/bin/bash

# ID: 1.5.1
# Nome Completo: 1.5.1 Ensure core dumps are restricted (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /etc/security/limits.d/*
# * hard core 0
# fs.suid_dumpable = 0
# fs.suid_dumpable = 0
# If enabled or disabled is returned systemd-coredump is installed

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -E "^\s*\*\s+hard\s+core" /etc/security/limits.conf
output_1=$( grep -E "^\s*\*\s+hard\s+core" /etc/security/limits.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep -E "^\s*\*\s+hard\s+core" /etc/security/limits.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: sysctl fs.suid_dumpable
output_2=$( sysctl fs.suid_dumpable 2>&1 )
status_2=$?
echo "Audit command 2: sysctl fs.suid_dumpable"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "fs\.suid_dumpable" /etc/sysctl.conf /etc/sysctl.d/*
output_3=$( grep "fs\.suid_dumpable" /etc/sysctl.conf /etc/sysctl.d/* 2>&1 )
status_3=$?
echo "Audit command 3: grep "fs\.suid_dumpable" /etc/sysctl.conf /etc/sysctl.d/*"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled coredump.service
output_4=$( systemctl is-enabled coredump.service 2>&1 )
status_4=$?
echo "Audit command 4: systemctl is-enabled coredump.service"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    sysctl -w fs.suid_dumpable=0
fi
