#!/bin/bash

# ID: 5.3.15
# Nome Completo: 5.3.15 Ensure only strong Key Exchange algorithms are used (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /etc/hosts | awk '{print $1}')" | grep -Ei
# '^\s*kexalgorithms\s+([^#]+,)?(diffie-hellman-group1-sha1|diffie-hellman-
# group14-sha1|diffie-hellman-group-exchange-sha1)\b'
# Nothing should be returned
# hellman-group14-sha1|diffie-hellman-group-exchange-sha1)\b'
# /etc/ssh/sshd_config
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)
output_1=$( sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) 2>&1 )
status_1=$?
echo "Audit command 1: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -Ei '^\s*kexalgorithms\s+([^#]+,)?(diffie-hellman-group1-sha1|diffie-
output_2=$( grep -Ei '^\s*kexalgorithms\s+([^#]+,)?(diffie-hellman-group1-sha1|diffie- 2>&1 )
status_2=$?
echo "Audit command 2: grep -Ei '^\s*kexalgorithms\s+([^#]+,)?(diffie-hellman-group1-sha1|diffie-"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/ssh/sshd_config file add/modify the KexAlgorithms line to contain a comma
    # separated list of the site approved key exchange algorithms
    # Example:
    # KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-
    # nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group-exchange-
    # sha256
fi
