#!/bin/bash

# ID: 4.1.9
# Nome Completo: 4.1.9 Ensure discretionary access control permission modification events are collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# On a 32 bit system run the following commands:
# -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F
# auid!=4294967295 -k perm_mod
# -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F
# auid>=1000 -F auid!=4294967295 -k perm_mod
# -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S
# removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295
# -k perm_mod
# -a always,exit -F arch=b32 -S chmod,fchmod,fchmodat -F auid>=1000 -F auid!=-1
# -F key=perm_mod
# -a always,exit -F arch=b32 -S lchown,fchown,chown,fchownat -F auid>=1000 -F
# auid!=-1 -F key=perm_mod
# -a always,exit -F arch=b32 -S
# setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr -F
# auid>=1000 -F auid!=-1 -F key=perm_mod
# On a 64 bit system run the following commands:
# -a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F
# auid!=4294967295 -k perm_mod
# -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F
# auid!=4294967295 -k perm_mod
# -a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F
# auid>=1000 -F auid!=4294967295 -k perm_mod
# -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F
# auid>=1000 -F auid!=4294967295 -k perm_mod
# -a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S
# removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295
# -k perm_mod
# -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S
# removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295
# -k perm_mod
# -a always,exit -F arch=b64 -S chmod,fchmod,fchmodat -F auid>=1000 -F auid!=-1
# -F key=perm_mod
# -a always,exit -F arch=b32 -S chmod,fchmod,fchmodat -F auid>=1000 -F auid!=-1
# -F key=perm_mod
# -a always,exit -F arch=b64 -S chown,fchown,lchown,fchownat -F auid>=1000 -F
# auid!=-1 -F key=perm_mod
# -a always,exit -F arch=b32 -S lchown,fchown,chown,fchownat -F auid>=1000 -F
# auid!=-1 -F key=perm_mod
# -a always,exit -F arch=b64 -S
# setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr -F
# auid>=1000 -F auid!=-1 -F key=perm_mod
# -a always,exit -F arch=b32 -S
# setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr -F
# auid>=1000 -F auid!=-1 -F key=perm_mod

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep perm_mod /etc/audit/rules.d/*.rules
output_1=$( grep perm_mod /etc/audit/rules.d/*.rules 2>&1 )
status_1=$?
echo "Audit command 1: grep perm_mod /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep perm_mod
output_2=$( auditctl -l | grep perm_mod 2>&1 )
status_2=$?
echo "Audit command 2: auditctl -l | grep perm_mod"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep perm_mod /etc/audit/rules.d/*.rules
output_3=$( grep perm_mod /etc/audit/rules.d/*.rules 2>&1 )
status_3=$?
echo "Audit command 3: grep perm_mod /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep auditctl -l | grep perm_mod
output_4=$( auditctl -l | grep auditctl -l | grep perm_mod 2>&1 )
status_4=$?
echo "Audit command 4: auditctl -l | grep auditctl -l | grep perm_mod"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # For 32 bit systems edit or create a file in the /etc/audit/rules.d/ directory ending in
    # .rules
    # Example: vi /etc/audit/rules.d/50-perm_mod.rules
    # Add the following lines:
    # -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F
    # auid!=4294967295 -k perm_mod
    # -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F
    # auid>=1000 -F auid!=4294967295 -k perm_mod
    # -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S
    # removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295
    # -k perm_mod
    # For 64 bit systems Edit or create a file in the /etc/audit/rules.d/ directory ending in
    # .rules
    # Example: vi /etc/audit/rules.d/50-perm_mod.rules
    # Add the following lines:
    # -a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F
    # auid!=4294967295 -k perm_mod
    # -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F
    # auid!=4294967295 -k perm_mod
    # -a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F
    # auid>=1000 -F auid!=4294967295 -k perm_mod
    # -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F
    # auid>=1000 -F auid!=4294967295 -k perm_mod
    # -a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S
    # removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295
    # -k perm_mod
    # -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S
    # removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295
    # -k perm_mod
fi
