#!/bin/bash

# ID: 5.5.1.5
# Nome Completo: 5.5.1.5 Ensure all users last password change date is in the past (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# '^Last password change' | cut -d: -f2) > $(date) ]] && echo "$usr :$(chage --
# list $usr | grep '^Last password change' | cut -d: -f2)"; done

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: for usr in $(cut -d: -f1 /etc/shadow); do [[ $(chage --list $usr | grep
output_1=$( for usr in $(cut -d: -f1 /etc/shadow); do [[ $(chage --list $usr | grep 2>&1 )
status_1=$?
echo "Audit command 1: for usr in $(cut -d: -f1 /etc/shadow); do [[ $(chage --list $usr | grep"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Investigate any users with a password change date in the future and correct them. Locking
    # the account, expiring the password, or resetting the password manually may be
    # appropriate.
fi
