#!/bin/bash

# ID: 1.3.2
# Nome Completo: 1.3.2 Ensure filesystem integrity is regularly checked (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# -(check|update)|\$AIDEARGS)\b' /etc/cron.* /etc/crontab /var/spool/cron/
# Ensure a cron job in compliance with site policy is returned.
# OR run the following commands to verify that aidcheck.service and aidcheck.timer are
# enabled and aidcheck.timer is running

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -Ers '^([^#]+\s+)?(\/usr\/s?bin\/|^\s*)aide(\.wrapper)?\s(--?\S+\s)*(-
output_1=$( grep -Ers '^([^#]+\s+)?(\/usr\/s?bin\/|^\s*)aide(\.wrapper)?\s(--?\S+\s)*(- 2>&1 )
status_1=$?
echo "Audit command 1: grep -Ers '^([^#]+\s+)?(\/usr\/s?bin\/|^\s*)aide(\.wrapper)?\s(--?\S+\s)*(-"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled aidecheck.service
output_2=$( systemctl is-enabled aidecheck.service 2>&1 )
status_2=$?
echo "Audit command 2: systemctl is-enabled aidecheck.service"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled aidecheck.timer
output_3=$( systemctl is-enabled aidecheck.timer 2>&1 )
status_3=$?
echo "Audit command 3: systemctl is-enabled aidecheck.timer"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl status aidecheck.timer
output_4=$( systemctl status aidecheck.timer 2>&1 )
status_4=$?
echo "Audit command 4: systemctl status aidecheck.timer"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    crontab -u root -e
    chown root:root /etc/systemd/system/aidecheck.*
    chmod 0644 /etc/systemd/system/aidecheck.*
    systemctl daemon-reload
    systemctl enable aidecheck.service
    systemctl --now enable aidecheck.timer
fi
