#!/bin/bash

# ID: 1.5.2
# Nome Completo: 1.5.2 Ensure XD/NX support is enabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# protection.
# kernel: NX (Execute Disable) protection: active
# OR
# on systems without journalctl:
# ' /proc/cpuinfo) || -n $(grep '\sNX\s.*\sprotection:\s' /var/log/dmesg | grep
# -v active) ]] && echo "NX Protection is not active"
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: journalctl | grep 'protection: active'
output_1=$( journalctl | grep 'protection: active' 2>&1 )
status_1=$?
echo "Audit command 1: journalctl | grep 'protection: active'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: [[ -n $(grep noexec[0-9]*=off /proc/cmdline) || -z $(grep -E -i ' (pae|nx)
output_2=$( [[ -n $(grep noexec[0-9]*=off /proc/cmdline) || -z $(grep -E -i ' (pae|nx) 2>&1 )
status_2=$?
echo "Audit command 2: [[ -n $(grep noexec[0-9]*=off /proc/cmdline) || -z $(grep -E -i ' (pae|nx)"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # On 32 bit systems install a kernel with PAE support, no installation is required on 64 bit
    # systems:
    # If necessary configure your bootloader to load the new kernel and reboot the system.
    # You may need to enable NX or XD support in your bios.
fi
