#!/bin/bash

# ID: 3.3.5
# Nome Completo: 3.3.5 Ensure broadcast ICMP requests are ignored (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# net.ipv4.icmp_echo_ignore_broadcasts = 1
# /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf
# net.ipv4.icmp_echo_ignore_broadcasts = 1

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sysctl net.ipv4.icmp_echo_ignore_broadcasts
output_1=$( sysctl net.ipv4.icmp_echo_ignore_broadcasts 2>&1 )
status_1=$?
echo "Audit command 1: sysctl net.ipv4.icmp_echo_ignore_broadcasts"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "net\.ipv4\.icmp_echo_ignore_broadcasts" /etc/sysctl.conf
output_2=$( grep "net\.ipv4\.icmp_echo_ignore_broadcasts" /etc/sysctl.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep "net\.ipv4\.icmp_echo_ignore_broadcasts" /etc/sysctl.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    sysctl -w net.ipv4.icmp_echo_ignore_broadcasts=1
    sysctl -w net.ipv4.route.flush=1
fi
