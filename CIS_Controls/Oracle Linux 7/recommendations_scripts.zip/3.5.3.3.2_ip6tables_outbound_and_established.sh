#!/bin/bash

# ID: 3.5.3.3.2
# Nome Completo: 3.5.3.3.2 Ensure ip6tables outbound and established connections are configured (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# connections match site policy:
# OR verify IPv6 is disabled:
# [ -n "$passing" ] && passing=""
# [ -z "$(grep "^\s*linux" /boot/grub2/grub.cfg | grep -v ipv6.disable=1)" ] &&
# passing="true"
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$"
# /etc/sysctl.conf \
# /etc/sysctl.d/*.conf && grep -Eq
# "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" \
# /etc/sysctl.conf /etc/sysctl.d/*.conf && sysctl
# net.ipv6.conf.all.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" && \
# sysctl net.ipv6.conf.default.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" &&
# passing="true"
# if [ "$passing" = true ] ; then
# echo "IPv6 is disabled on the system"
# else
# echo "IPv6 is enabled on the system"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: ip6tables -L -v -n
output_1=$( ip6tables -L -v -n 2>&1 )
status_1=$?
echo "Audit command 1: ip6tables -L -v -n"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: !/bin/bash
output_2=$( !/bin/bash 2>&1 )
status_2=$?
echo "Audit command 2: !/bin/bash"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT
fi
