#!/bin/bash

# ID: 1.1.1.3
# Nome Completo: 1.1.1.3 Ensure mounting of udf filesystems is disabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# install /bin/true

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: modprobe -n -v udf | grep -E '(udf|install)'
output_1=$( modprobe -n -v udf | grep -E '(udf|install)' 2>&1 )
status_1=$?
echo "Audit command 1: modprobe -n -v udf | grep -E '(udf|install)'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: lsmod | grep udf
output_2=$( lsmod | grep udf 2>&1 )
status_2=$?
echo "Audit command 2: lsmod | grep udf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    rmmod udf
fi
