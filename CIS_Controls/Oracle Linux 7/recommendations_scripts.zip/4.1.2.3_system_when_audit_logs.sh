#!/bin/bash

# ID: 4.1.2.3
# Nome Completo: 4.1.2.3 Ensure system is disabled when audit logs are full (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# space_left_action = email
# action_mail_acct = root
# admin_space_left_action = halt

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep space_left_action /etc/audit/auditd.conf
output_1=$( grep space_left_action /etc/audit/auditd.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep space_left_action /etc/audit/auditd.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep action_mail_acct /etc/audit/auditd.conf
output_2=$( grep action_mail_acct /etc/audit/auditd.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep action_mail_acct /etc/audit/auditd.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep admin_space_left_action /etc/audit/auditd.conf
output_3=$( grep admin_space_left_action /etc/audit/auditd.conf 2>&1 )
status_3=$?
echo "Audit command 3: grep admin_space_left_action /etc/audit/auditd.conf"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Set the following parameters in /etc/audit/auditd.conf:
    # space_left_action = email
    # action_mail_acct = root
    # admin_space_left_action = halt
fi
