#!/bin/bash

# ID: 4.1.2.1
# Nome Completo: 4.1.2.1 Ensure audit log storage size is configured (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# max_log_file = <MB>

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep max_log_file /etc/audit/auditd.conf
output_1=$( grep max_log_file /etc/audit/auditd.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep max_log_file /etc/audit/auditd.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Set the following parameter in /etc/audit/auditd.conf in accordance with site policy:
    # max_log_file = <MB>
fi
