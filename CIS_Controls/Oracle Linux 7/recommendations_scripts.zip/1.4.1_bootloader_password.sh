#!/bin/bash

# ID: 1.4.1
# Nome Completo: 1.4.1 Ensure bootloader password is set (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# tst1="" tst2="" output=""
# efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
# gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
# if [ -f "$efidir"/grub.cfg ]; then
# grubdir="$efidir" && grubfile="$efidir/grub.cfg"
# elif [ -f "$gbdir"/grub.cfg ]; then
# grubdir="$gbdir" && grubfile="$gbdir/grub.cfg"
# fi
# userfile="$grubdir/user.cfg"
# [ -f "$userfile" ] && grep -Pq '^\h*GRUB2_PASSWORD\h*=\h*.+$' "$userfile" &&
# output="\n PASSED: bootloader password set in \"$userfile\"\n\n"
# if [ -z "$output" ] && [ -f "$grubfile" ]; then
# grep -Piq '^\h*set\h+superusers\h*=\h*"?[^"\n\r]+"?(\h+.*)?$' "$grubfile"
# && tst1=pass
# grep -Piq '^\h*password\h+\H+\h+.+$' "$grubfile" && tst2=pass
# [ "$tst1" = pass ] && [ "$tst2" = pass ] && output="\n\n*** PASSED:
# bootloader password set in \"$grubfile\" ***\n\n"
# fi
# [ -n "$output" ] && echo -e "$output" || echo -e "\n\n *** FAILED: bootloader
# password is not set ***\n\n"

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    grub2-setpassword
    grub2-mkpasswd-pbkdf2
    grub2-mkconfig -o /boot/grub2/grub.cfg
fi
