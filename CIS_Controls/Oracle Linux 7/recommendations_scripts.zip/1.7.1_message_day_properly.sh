#!/bin/bash

# ID: 1.7.1
# Nome Completo: 1.7.1 Ensure message of the day is configured properly (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# f2 | sed -e 's/"//g'))" /etc/motd

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: cat /etc/motd
output_1=$( cat /etc/motd 2>&1 )
status_1=$?
echo "Audit command 1: cat /etc/motd"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E -i "(\\\v|\\\r|\\\m|\\\s|$(grep '^ID=' /etc/os-release | cut -d= -
output_2=$( grep -E -i "(\\\v|\\\r|\\\m|\\\s|$(grep '^ID=' /etc/os-release | cut -d= - 2>&1 )
status_2=$?
echo "Audit command 2: grep -E -i "(\\\v|\\\r|\\\m|\\\s|$(grep '^ID=' /etc/os-release | cut -d= -"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    rm /etc/motd
fi
