#!/bin/bash

# ID: 1.8.2
# Nome Completo: 1.8.2 Ensure GDM login banner is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# user-db:user
# system-db:gdm
# file-db:/usr/share/gdm/greeter-dconf-defaults
# typically /etc/dconf/db/gdm.d/01-banner-message)
# [org/gnome/login-screen]
# banner-message-enable=true
# banner-message-text='<banner message>'

# No audit commands found. Manual verification may be required.
# Applying remediation commands
dconf update
