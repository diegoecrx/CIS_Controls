#!/bin/bash

# ID: 4.1.17
# Nome Completo: 4.1.17 Ensure the audit configuration is immutable (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# -e 2

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep "^\s*[^#]" /etc/audit/rules.d/*.rules | tail -1
output_1=$( grep "^\s*[^#]" /etc/audit/rules.d/*.rules | tail -1 2>&1 )
status_1=$?
echo "Audit command 1: grep "^\s*[^#]" /etc/audit/rules.d/*.rules | tail -1"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit or create the file /etc/audit/rules.d/99-finalize.rules and add the following line
    # at the end of the file:
    # -e 2
fi
