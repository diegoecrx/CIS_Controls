#!/bin/bash

# ID: 4.2.2.3
# Nome Completo: 4.2.2.3 Ensure journald is configured to write logfiles to persistent disk (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Review /etc/systemd/journald.conf and verify that logs are persisted to disk:
# Storage=persistent

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -E ^\s*Storage /etc/systemd/journald.conf
output_1=$( grep -E ^\s*Storage /etc/systemd/journald.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep -E ^\s*Storage /etc/systemd/journald.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/systemd/journald.conf file and add the following line:
    # Storage=persistent
fi
