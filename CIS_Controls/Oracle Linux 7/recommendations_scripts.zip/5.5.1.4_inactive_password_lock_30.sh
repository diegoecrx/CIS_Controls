#!/bin/bash

# ID: 5.5.1.4
# Nome Completo: 5.5.1.4 Ensure inactive password lock is 30 days or less (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# days):
# INACTIVE=30
# password expires:
# INACTIVE conforms to site policy (no more than 30 days):

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: useradd -D | grep INACTIVE
output_1=$( useradd -D | grep INACTIVE 2>&1 )
status_1=$?
echo "Audit command 1: useradd -D | grep INACTIVE"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1,7
output_2=$( grep -E ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1,7 2>&1 )
status_2=$?
echo "Audit command 2: grep -E ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1,7"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    useradd -D -f 30
    chage --inactive 30 <user>
fi
