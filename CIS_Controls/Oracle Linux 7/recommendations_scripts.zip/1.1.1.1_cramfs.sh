#!/bin/bash

# ID: 1.1.1.1
# Nome Completo: 1.1.1.1 Ensure mounting of cramfs filesystems is disabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# install /bin/true

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: modprobe -n -v cramfs | grep -E '(cramfs|install)'
output_1=$( modprobe -n -v cramfs | grep -E '(cramfs|install)' 2>&1 )
status_1=$?
echo "Audit command 1: modprobe -n -v cramfs | grep -E '(cramfs|install)'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: lsmod | grep cramfs
output_2=$( lsmod | grep cramfs 2>&1 )
status_2=$?
echo "Audit command 2: lsmod | grep cramfs"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    rmmod cramfs
fi
