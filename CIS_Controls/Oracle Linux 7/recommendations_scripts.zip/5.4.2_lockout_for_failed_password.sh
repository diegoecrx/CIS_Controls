#!/bin/bash

# ID: 5.4.2
# Nome Completo: 5.4.2 Ensure lockout for failed password attempts is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# This should not exceed deny=5.
# If pam_failock.so is used:
# /etc/pam.d/password-auth
# /etc/pam.d/system-auth:auth required pam_faillock.so preauth
# silent audit deny=5 unlock_time=900
# /etc/pam.d/system-auth:auth sufficient pam_unix.so nullok
# try_first_pass
# /etc/pam.d/system-auth:auth [default=die] pam_faillock.so authfail
# audit deny=5 unlock_time=900
# /etc/pam.d/password-auth:auth required pam_faillock.so preauth
# silent audit deny=5 unlock_time=900
# /etc/pam.d/password-auth:auth sufficient pam_unix.so nullok
# try_first_pass
# /etc/pam.d/password-auth:auth [default=die] pam_faillock.so authfail
# audit deny=5 unlock_time=900
# auth /etc/pam.d/password-auth
# /etc/pam.d/system-auth:account required pam_faillock.so
# /etc/pam.d/password-auth:account required pam_faillock.so
# OR
# If pam_tally2.so is used:
# /etc/pam.d/password-auth
# /etc/pam.d/system-auth:auth required pam_tally2.so deny=5
# onerr=fail unlock_time=900
# /etc/pam.d/system-auth:auth sufficient pam_unix.so nullok
# try_first_pass
# /etc/pam.d/password-auth:auth required pam_tally2.so deny=5
# onerr=fail unlock_time=900
# /etc/pam.d/password-auth:auth sufficient pam_unix.so nullok
# try_first_pass
# /etc/pam.d/password-auth
# /etc/pam.d/system-auth:account required pam_tally2.so
# /etc/pam.d/password-auth:account required pam_tally2.so

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -E '^\s*auth\s+\S+\s+pam_(faillock|unix)\.so' /etc/pam.d/system-auth
output_1=$( grep -E '^\s*auth\s+\S+\s+pam_(faillock|unix)\.so' /etc/pam.d/system-auth 2>&1 )
status_1=$?
echo "Audit command 1: grep -E '^\s*auth\s+\S+\s+pam_(faillock|unix)\.so' /etc/pam.d/system-auth"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '^\s*account\s+required\s+pam_faillock.so\s*' /etc/pam.d/system-
output_2=$( grep -E '^\s*account\s+required\s+pam_faillock.so\s*' /etc/pam.d/system- 2>&1 )
status_2=$?
echo "Audit command 2: grep -E '^\s*account\s+required\s+pam_faillock.so\s*' /etc/pam.d/system-"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '^\s*auth\s+\S+\s+pam_(tally2|unix)\.so' /etc/pam.d/system-auth
output_3=$( grep -E '^\s*auth\s+\S+\s+pam_(tally2|unix)\.so' /etc/pam.d/system-auth 2>&1 )
status_3=$?
echo "Audit command 3: grep -E '^\s*auth\s+\S+\s+pam_(tally2|unix)\.so' /etc/pam.d/system-auth"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '^\s*account\s+required\s+pam_tally2.so\s*' /etc/pam.d/system-auth
output_4=$( grep -E '^\s*account\s+required\s+pam_tally2.so\s*' /etc/pam.d/system-auth 2>&1 )
status_4=$?
echo "Audit command 4: grep -E '^\s*account\s+required\s+pam_tally2.so\s*' /etc/pam.d/system-auth"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the files /etc/pam.d/system-auth and /etc/pam.d/password-auth and add the
    # following lines:
    # Modify the deny= and unlock_time= parameters to conform to local site policy, Not to be
    # greater than deny=5
    # To use pam_faillock.so module, add the following lines to the auth section:
    # auth required pam_faillock.so preauth silent audit deny=5
    # unlock_time=900
    # auth [default=die] pam_faillock.so authfail audit deny=5
    # unlock_time=900
    # The auth sections should look similar to the following example:
    # Note: The ordering on the lines in the auth section is important. The preauth line needs to
    # below the line auth required pam_env.so and above all password validation lines. The
    # authfail line needs to be after all password validation lines such as pam_sss.so. Incorrect
    # order can cause you to be locked out of the system
    # Example:
    # auth required pam_env.so
    # auth required pam_faillock.so preauth silent audit deny=5
    # unlock_time=900 # <- Under "auth required pam_env.so"
    # auth sufficient pam_unix.so nullok try_first_pass
    # auth [default=die] pam_faillock.so authfail audit deny=5
    # unlock_time=900 # <- Last auth line before "auth requisite
    # pam_succeed_if.so"
    # auth requisite pam_succeed_if.so uid >= 1000 quiet_success
    # auth required pam_deny.so
    # Add the following line to the account section:
    # 
    # 
    # account required pam_faillock.so
    # Example:
    # account required pam_faillock.so
    # account required pam_unix.so
    # account sufficient pam_localuser.so
    # account sufficient pam_pam_succeed_if.so uid < 1000 quiet
    # account required pam_permit.so
    # OR
    # To use the pam_tally2.so module, add the following line to the auth section:
    # auth required pam_tally2.so deny=5 onerr=fail unlock_time=900
    # The auth sections should look similar to the following example:
    # Note: The ordering on the lines in the auth section is important. the additional line needs to
    # below the line auth required pam_env.so and above all password validation lines.
    # Example:
    # auth required pam_env.so
    # auth required pam_tally2.so deny=5 onerr=fail unlock_time=900 #
    # <- Under "auth required pam_env.so"
    # auth sufficient pam_unix.so nullok try_first_pass
    # auth requisite pam_succeed_if.so uid >= 1000 quiet_success
    # auth required pam_deny.so
    # Add the following line to the account section:
    # account required pam_tally2.so
    # Example:
    # account required pam_tally2.so
    # account required pam_unix.so
    # account sufficient pam_localuser.so
    # account sufficient pam_pam_succeed_if.so uid < 1000 quiet
    # account required pam_permit.so
fi
