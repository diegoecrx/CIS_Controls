#!/bin/bash

# ID: 5.3.2
# Nome Completo: 5.3.2 Ensure permissions on SSH private host key files are configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# 0600 or more restrictive:
# Example Output:
# File: '/etc/ssh/ssh_host_rsa_key'
# Size: 1675 Blocks: 8 IO Block: 4096 regular file
# Device: 801h/2049d Inode: 794321 Links: 1
# Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2021-03-01 06:25:08.633246149 -0800
# Modify: 2021-01-29 06:42:16.001324236 -0800
# Change: 2021-01-29 06:42:16.001324236 -0800
# Birth: -
# File: '/etc/ssh/ssh_host_ecdsa_key'
# Size: 227 Blocks: 8 IO Block: 4096 regular file
# Device: 801h/2049d Inode: 794325 Links: 1
# Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2021-03-01 06:25:08.633246149 -0800
# Modify: 2021-01-29 06:42:16.173327263 -0800
# Change: 2021-01-29 06:42:16.173327263 -0800
# Birth: -
# File: '/etc/ssh/ssh_host_ed25519_key'
# Size: 399 Blocks: 8 IO Block: 4096 regular file
# Device: 801h/2049d Inode: 794327 Links: 1
# Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2021-03-01 06:25:08.633246149 -0800
# Modify: 2021-01-29 06:42:16.185327474 -0800
# Change: 2021-01-29 06:42:16.185327474 -0800
# Birth: -
# File: '/etc/ssh/ssh_host_dsa_key'
# Size: 672 Blocks: 8 IO Block: 4096 regular file
# Device: 801h/2049d Inode: 794323 Links: 1
# Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)
# Access: 2021-03-01 06:25:08.645246255 -0800
# Modify: 2021-01-29 06:42:16.161327052 -0800
# Change: 2021-01-29 06:42:16.161327052 -0800
# Birth: -

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec stat {} \;
output_1=$( find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec stat {} \; 2>&1 )
status_1=$?
echo "Audit command 1: find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec stat {} \;"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec chown root:root {}
    find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec chmod u-x,go-rwx
fi
