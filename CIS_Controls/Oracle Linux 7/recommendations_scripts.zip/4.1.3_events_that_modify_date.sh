#!/bin/bash

# ID: 4.1.3
# Nome Completo: 4.1.3 Ensure events that modify date and time information are collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# On a 32 bit system run the following commands:
# -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-
# change
# -a always,exit -F arch=b32 -S clock_settime -k time-change
# -w /etc/localtime -p wa -k time-change
# On a 64 bit system run the following commands:
# -a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change
# -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-
# change
# -a always,exit -F arch=b64 -S clock_settime -k time-change
# -a always,exit -F arch=b32 -S clock_settime -k time-change
# -w /etc/localtime -p wa -k time-change

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep time-change /etc/audit/rules.d/*.rules
output_1=$( grep time-change /etc/audit/rules.d/*.rules 2>&1 )
status_1=$?
echo "Audit command 1: grep time-change /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep time-change
output_2=$( auditctl -l | grep time-change 2>&1 )
status_2=$?
echo "Audit command 2: auditctl -l | grep time-change"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep time-change /etc/audit/rules.d/*.rules
output_3=$( grep time-change /etc/audit/rules.d/*.rules 2>&1 )
status_3=$?
echo "Audit command 3: grep time-change /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep time-change
output_4=$( auditctl -l | grep time-change 2>&1 )
status_4=$?
echo "Audit command 4: auditctl -l | grep time-change"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # For 32 bit systems Edit or create a file in the /etc/audit/rules.d/ directory ending in
    # .rules
    # Example: vi /etc/audit/rules.d/50-time_change.rules
    # Add the following lines:
    # -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-
    # change
    # -a always,exit -F arch=b32 -S clock_settime -k time-change
    # -w /etc/localtime -p wa -k time-change
    # For 64 bit systems Edit or create a file in the /etc/audit/rules.d/ directory ending in
    # .rules
    # Example: vi /etc/audit/rules.d/50-time_change.rules
    # Add the following lines:
    # -a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change
    # -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-
    # change
    # -a always,exit -F arch=b64 -S clock_settime -k time-change
    # -a always,exit -F arch=b32 -S clock_settime -k time-change
    # -w /etc/localtime -p wa -k time-change
fi
