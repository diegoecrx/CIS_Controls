#!/bin/bash

# ID: 4.2.1.6
# Nome Completo: 4.2.1.6 Ensure remote rsyslog messages are only accepted on designated log hosts. (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# designated log hosts and commented or removed on all others:
# $ModLoad imtcp
# $InputTCPServerRun 514

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep '$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf
output_1=$( grep '$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep '$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep '$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf
output_2=$( grep '$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep '$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    $ModLoad imtcp
    $InputTCPServerRun 514
    systemctl restart rsyslog
fi
