#!/bin/bash

# ID: 3.5.3.1.1
# Nome Completo: 3.5.3.1.1 Ensure iptables packages are installed (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# rpm -q iptables iptables-services
# iptables-<version>
# iptables-services-<version>

# No audit commands found. Manual verification may be required.
# Applying remediation commands
yum install iptables iptables-services
