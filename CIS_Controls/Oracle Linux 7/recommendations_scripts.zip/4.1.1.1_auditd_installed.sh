#!/bin/bash

# ID: 4.1.1.1
# Nome Completo: 4.1.1.1 Ensure auditd is installed (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# audit-<version>
# audit-libs-<version>

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q audit audit-libs
output_1=$( rpm -q audit audit-libs 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q audit audit-libs"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum install audit audit-libs
fi
