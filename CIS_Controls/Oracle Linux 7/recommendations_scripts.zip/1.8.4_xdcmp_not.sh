#!/bin/bash

# ID: 1.8.4
# Nome Completo: 1.8.4 Ensure XDCMP is not enabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -Eis '^\s*Enable\s*=\s*true' /etc/gdm/custom.conf
output_1=$( grep -Eis '^\s*Enable\s*=\s*true' /etc/gdm/custom.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep -Eis '^\s*Enable\s*=\s*true' /etc/gdm/custom.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the file /etc/gdm/custom.conf and remove the line
    # Enable=true
fi
