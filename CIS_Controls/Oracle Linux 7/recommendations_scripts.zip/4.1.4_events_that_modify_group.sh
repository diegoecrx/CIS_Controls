#!/bin/bash

# ID: 4.1.4
# Nome Completo: 4.1.4 Ensure events that modify user/group information are collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# -w /etc/group -p wa -k identity
# -w /etc/passwd -p wa -k identity
# -w /etc/gshadow -p wa -k identity
# -w /etc/shadow -p wa -k identity
# -w /etc/security/opasswd -p wa -k identity
# -w /etc/group -p wa -k identity
# -w /etc/passwd -p wa -k identity
# -w /etc/gshadow -p wa -k identity
# -w /etc/shadow -p wa -k identity
# -w /etc/security/opasswd -p wa -k identity

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep identity /etc/audit/rules.d/*.rules
output_1=$( grep identity /etc/audit/rules.d/*.rules 2>&1 )
status_1=$?
echo "Audit command 1: grep identity /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep identity
output_2=$( auditctl -l | grep identity 2>&1 )
status_2=$?
echo "Audit command 2: auditctl -l | grep identity"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit or create a file in the /etc/audit/rules.d/ directory ending in .rules
    # Example: vi /etc/audit/rules.d/50-identity.rules
    # Add the following lines:
    # -w /etc/group -p wa -k identity
    # -w /etc/passwd -p wa -k identity
    # -w /etc/gshadow -p wa -k identity
    # -w /etc/shadow -p wa -k identity
    # -w /etc/security/opasswd -p wa -k identity
fi
