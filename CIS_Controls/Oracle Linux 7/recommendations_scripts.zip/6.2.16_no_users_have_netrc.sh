#!/bin/bash

# ID: 6.2.16
# Nome Completo: 6.2.16 Ensure no users have .netrc files (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# FAILED: for any .netrc file with permissions less restrictive than 600
# WARNING: for any .netrc files that exist in interactive users' home directories.
# awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ &&
# $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {
# print $1 " " $6 }' /etc/passwd | while read -r user dir; do
# if [ -d "$dir" ]; then
# file="$dir/.netrc"
# if [ ! -h "$file" ] && [ -f "$file" ]; then
# if stat -L -c "%A" "$file" | cut -c4-10 | grep -Eq '[^-]+'; then
# echo "FAILED: User: \"$user\" file: \"$file\" exists with
# permissions: \"$(stat -L -c "%a" "$file")\", remove file or excessive
# permissions"
# else
# echo "WARNING: User: \"$user\" file: \"$file\" exists with
# permissions: \"$(stat -L -c "%a" "$file")\", remove file unless required"
# fi
# fi
# fi
# done
# Any lines beginning with FAILED: - File should be removed unless deemed
# necessary, in accordance with local site policy, and permissions are updated to be
# 600 or more restrictive
# Any lines beginning with WARNING: - File should be removed unless deemed
# necessary, and in accordance with local site policy

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    !/bin/bash
fi
