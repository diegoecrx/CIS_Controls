#!/bin/bash

# ID: 3.5.3.1.3
# Nome Completo: 3.5.3.1.3 Ensure firewalld is either not installed or masked with iptables (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# package firewalld is not installed
# OR
# No output should be returned
# masked

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q firewalld
output_1=$( rpm -q firewalld 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q firewalld"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl status firewalld | grep "Active: " | grep -v "active (running) "
output_2=$( systemctl status firewalld | grep "Active: " | grep -v "active (running) " 2>&1 )
status_2=$?
echo "Audit command 2: systemctl status firewalld | grep "Active: " | grep -v "active (running) ""
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl is-enabled firewalld
output_3=$( systemctl is-enabled firewalld 2>&1 )
status_3=$?
echo "Audit command 3: systemctl is-enabled firewalld"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove firewalld
    systemctl --now mask firewalld
fi
