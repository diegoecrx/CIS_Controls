#!/bin/bash

# ID: 1.6.1.5
# Nome Completo: 1.6.1.5 Ensure the SELinux mode is enforcing (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# Enforcing
# SELINUX=enforcing

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: getenforce
output_1=$( getenforce 2>&1 )
status_1=$?
echo "Audit command 1: getenforce"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -i SELINUX=enforcing /etc/selinux/config
output_2=$( grep -i SELINUX=enforcing /etc/selinux/config 2>&1 )
status_2=$?
echo "Audit command 2: grep -i SELINUX=enforcing /etc/selinux/config"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    setenforce 1
fi
