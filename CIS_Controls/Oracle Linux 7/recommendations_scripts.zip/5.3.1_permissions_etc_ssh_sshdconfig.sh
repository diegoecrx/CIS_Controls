#!/bin/bash

# ID: 5.3.1
# Nome Completo: 5.3.1 Ensure permissions on /etc/ssh/sshd_config are configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# grant permissions to group or other:
# Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: stat /etc/ssh/sshd_config
output_1=$( stat /etc/ssh/sshd_config 2>&1 )
status_1=$?
echo "Audit command 1: stat /etc/ssh/sshd_config"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    chown root:root /etc/ssh/sshd_config
    chmod og-rwx /etc/ssh/sshd_config
fi
