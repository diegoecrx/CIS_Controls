#!/bin/bash

# ID: 6.2.10
# Nome Completo: 6.2.10 Ensure root PATH Integrity (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# RPCV="$(sudo -Hiu root env | grep '^PATH' | cut -d= -f2)"
# echo "$RPCV" | grep -q "::" && echo "root's path contains a empty directory
# (::)"
# echo "$RPCV" | grep -q ":$" && echo "root's path contains a trailing (:)"
# for x in $(echo "$RPCV" | tr ":" " "); do
# if [ -d "$x" ]; then
# ls -ldH "$x" | awk '$9 == "." {print "PATH contains current working
# directory (.)"}
# $3 != "root" {print $9, "is not owned by root"}
# substr($1,6,1) != "-" {print $9, "is group writable"}
# substr($1,9,1) != "-" {print $9, "is world writable"}'
# else
# echo "$x is not a directory"
# fi
# done

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Correct or justify any items discovered in the Audit step.
fi
