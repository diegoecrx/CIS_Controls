#!/bin/bash

# ID: 4.1.1.2
# Nome Completo: 4.1.1.2 Ensure auditd service is enabled and running (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# enabled
# Active: active (running) since <time and date>

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: systemctl is-enabled auditd
output_1=$( systemctl is-enabled auditd 2>&1 )
status_1=$?
echo "Audit command 1: systemctl is-enabled auditd"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl status auditd | grep 'Active: active (running) '
output_2=$( systemctl status auditd | grep 'Active: active (running) ' 2>&1 )
status_2=$?
echo "Audit command 2: systemctl status auditd | grep 'Active: active (running) '"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    systemctl --now enable auditd
fi
