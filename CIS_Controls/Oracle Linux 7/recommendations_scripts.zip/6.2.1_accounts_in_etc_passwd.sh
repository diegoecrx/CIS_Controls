#!/bin/bash

# ID: 6.2.1
# Nome Completo: 6.2.1 Ensure accounts in /etc/passwd use shadowed passwords (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /etc/passwd

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: awk -F: '($2 != "x" ) { print $1 " is not set to shadowed passwords "}'
output_1=$( awk -F: '($2 != "x" ) { print $1 " is not set to shadowed passwords "}' 2>&1 )
status_1=$?
echo "Audit command 1: awk -F: '($2 != "x" ) { print $1 " is not set to shadowed passwords "}'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    sed -e 's/^\([a-zA-Z0-9_]*\):[^:]*:/\1:x:/' -i /etc/passwd
fi
