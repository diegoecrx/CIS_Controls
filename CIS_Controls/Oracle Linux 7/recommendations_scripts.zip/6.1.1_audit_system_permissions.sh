#!/bin/bash

# ID: 6.1.1
# Nome Completo: 6.1.1 Audit system file permissions (Manual)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# time consuming and may be best scheduled via the cron utility. It is recommended that the
# output of this command be redirected to a file that can be reviewed later. This command
# will ignore configuration files due to the extreme likelihood that they will change.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -Va --nomtime --nosize --nomd5 --nolinkto > <filename> | grep -vw c
output_1=$( rpm -Va --nomtime --nosize --nomd5 --nolinkto > <filename> | grep -vw c 2>&1 )
status_1=$?
echo "Audit command 1: rpm -Va --nomtime --nosize --nomd5 --nolinkto > <filename> | grep -vw c"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Investigate the results to ensure any discrepancies found are understood and support
    # proper secure operation of the system.
fi
