#!/bin/bash

# ID: 1.4.2
# Nome Completo: 1.4.2 Ensure permissions on bootloader config are configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# and if it exists, user.cfg:
# tst1="" tst2="" tst3="" tst4="" test1="" test2="" efidir="" gbdir=""
# grubdir="" grubfile="" userfile=""
# efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
# gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
# for file in "$efidir"/grub.cfg "$efidir"/grub.conf; do
# [ -f "$file" ] && grubdir="$efidir" && grubfile=$file
# done
# if [ -z "$grubdir" ]; then
# for file in "$gbdir"/grub.cfg "$gbdir"/grub.conf; do
# [ -f "$file" ] && grubdir="$gbdir" && grubfile=$file
# done
# fi
# userfile="$grubdir/user.cfg"
# stat -c "%a" "$grubfile" | grep -Pq '^\h*[0-7]00$' && tst1=pass
# output="Permissions on \"$grubfile\" are \"$(stat -c "%a" "$grubfile")\""
# stat -c "%u:%g" "$grubfile" | grep -Pq '^\h*0:0$' && tst2=pass
# output2="\"$grubfile\" is owned by \"$(stat -c "%U" "$grubfile")\" and
# belongs to group \"$(stat -c "%G" "$grubfile")\""
# [ "$tst1" = pass ] && [ "$tst2" = pass ] && test1=pass
# if [ -f "$userfile" ]; then
# stat -c "%a" "$userfile" | grep -Pq '^\h*[0-7]00$' && tst3=pass
# output3="Permissions on \"$userfile\" are \"$(stat -c "%a" "$userfile")\""
# stat -c "%u:%g" "$userfile" | grep -Pq '^\h*0:0$' && tst4=pass
# output4="\"$userfile\" is owned by \"$(stat -c "%U" "$userfile")\" and
# belongs to group \"$(stat -c "%G" "$userfile")\""
# [ "$tst3" = pass ] && [ "$tst4" = pass ] && test2=pass
# else
# test2=pass
# fi
# [ "$test1" = pass ] && [ "$test2" = pass ] && passing=true
# if [ "$passing" = true ] ; then
# echo "PASSED:"
# echo "$output"
# echo "$output2"
# [ -n "$output3" ] && echo "$output3"
# [ -n "$output4" ] && echo "$output4"
# else
# echo "FAILED:"
# echo "$output"
# echo "$output2"
# [ -n "$output3" ] && echo "$output3"
# [ -n "$output4" ] && echo "$output4"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: !/bin/bash
output_1=$( !/bin/bash 2>&1 )
status_1=$?
echo "Audit command 1: !/bin/bash"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: If passing is true we pass
output_2=$( If passing is true we pass 2>&1 )
status_2=$?
echo "Audit command 2: If passing is true we pass"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: print the reason why we are failing
output_3=$( print the reason why we are failing 2>&1 )
status_3=$?
echo "Audit command 3: print the reason why we are failing"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    chown root:root /boot/grub2/grub.cfg
    test -f /boot/grub2/user.cfg && chown root:root /boot/grub2/user.cfg
    chmod og-rwx /boot/grub2/grub.cfg
    test -f /boot/grub2/user.cfg && chmod og-rwx /boot/grub2/user.cfg
fi
