#!/bin/bash

# ID: 3.5.3.2.6
# Nome Completo: 3.5.3.2.6 Ensure iptables is enabled and running (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# enabled
# Active: active (exited) since <day date and time>

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: systemctl is-enabled iptables
output_1=$( systemctl is-enabled iptables 2>&1 )
status_1=$?
echo "Audit command 1: systemctl is-enabled iptables"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl status iptables | grep -E " Active: active \((running|exited)\) "
output_2=$( systemctl status iptables | grep -E " Active: active \((running|exited)\) " 2>&1 )
status_2=$?
echo "Audit command 2: systemctl status iptables | grep -E " Active: active \((running|exited)\) ""
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    systemctl --now enable iptables
fi
