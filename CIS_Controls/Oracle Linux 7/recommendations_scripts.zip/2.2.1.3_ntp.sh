#!/bin/bash

# ID: 2.2.1.3
# Nome Completo: 2.2.1.3 Ensure ntp is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# IF NTP is installed on the system:
# enabled
# restrict -4 default kod nomodify notrap nopeer noquery
# restrict -6 default kod nomodify notrap nopeer noquery
# The -4 in the first line is optional and options after default can appear in any order.
# Additional restriction lines may exist.
# server <remote-server>
# Multiple servers may be configured
# ExecStart as listed:
# OPTIONS="-u ntp:ntp"
# OR
# ExecStart=/usr/sbin/ntpd -u ntp:ntp $OPTIONS
# Additional options may be present.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: systemctl is-enabled ntpd
output_1=$( systemctl is-enabled ntpd 2>&1 )
status_1=$?
echo "Audit command 1: systemctl is-enabled ntpd"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "^restrict" /etc/ntp.conf
output_2=$( grep "^restrict" /etc/ntp.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep "^restrict" /etc/ntp.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E "^(server|pool)" /etc/ntp.conf
output_3=$( grep -E "^(server|pool)" /etc/ntp.conf 2>&1 )
status_3=$?
echo "Audit command 3: grep -E "^(server|pool)" /etc/ntp.conf"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "^OPTIONS" /etc/sysconfig/ntpd
output_4=$( grep "^OPTIONS" /etc/sysconfig/ntpd 2>&1 )
status_4=$?
echo "Audit command 4: grep "^OPTIONS" /etc/sysconfig/ntpd"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep "^ExecStart" /usr/lib/systemd/system/ntpd.service
output_5=$( grep "^ExecStart" /usr/lib/systemd/system/ntpd.service 2>&1 )
status_5=$?
echo "Audit command 5: grep "^ExecStart" /usr/lib/systemd/system/ntpd.service"
echo "Output:" "$$output_5"
echo "Status: $status_5"
if [ $status_5 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Add or edit restrict lines in /etc/ntp.conf to match the following:
    # restrict -4 default kod nomodify notrap nopeer noquery
    # restrict -6 default kod nomodify notrap nopeer noquery
    # Add or edit server or pool lines to /etc/ntp.conf as appropriate:
    # server <remote-server>
    # Add or edit the OPTIONS in /etc/sysconfig/ntpd to include '-u ntp:ntp':
    # OPTIONS="-u ntp:ntp"
    # Reload the systemd daemon:
    # systemctl daemon-reload
    # Enable and start the ntp service:
    # systemctl --now enable ntpd
fi
