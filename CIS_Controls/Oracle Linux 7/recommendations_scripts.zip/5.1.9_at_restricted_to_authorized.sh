#!/bin/bash

# ID: 5.1.9
# Nome Completo: 5.1.9 Ensure at is restricted to authorized users (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# If at is installed:
# stat: cannot stat `/etc/at.deny': No such file or directory
# grant permissions to group or other for /etc/at.allow:
# Access: (0600/-rw-------) Uid: ( 0/ root) Gid: ( 0/ root)

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: stat /etc/at.deny
output_1=$( stat /etc/at.deny 2>&1 )
status_1=$?
echo "Audit command 1: stat /etc/at.deny"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: stat /etc/at.allow
output_2=$( stat /etc/at.allow 2>&1 )
status_2=$?
echo "Audit command 2: stat /etc/at.allow"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    rm /etc/at.deny
    touch /etc/at.allow
    chown root:root /etc/at.allow
    chmod u-x,og-rwx /etc/at.allow
    yum remove at
fi
