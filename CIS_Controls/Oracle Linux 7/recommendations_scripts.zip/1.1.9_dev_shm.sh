#!/bin/bash

# ID: 1.1.9
# Nome Completo: 1.1.9 Ensure nosuid option set on /dev/shm partition (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: findmnt -n /dev/shm | grep -Ev '\bnosuid\b'
output_1=$( findmnt -n /dev/shm | grep -Ev '\bnosuid\b' 2>&1 )
status_1=$?
echo "Audit command 1: findmnt -n /dev/shm | grep -Ev '\bnosuid\b'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    mount -o remount,noexec,nodev,nosuid /dev/shm
fi
