#!/bin/bash

# ID: 1.1.2
# Nome Completo: 1.1.2 Ensure /tmp is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /tmp tmpfs tmpfs rw,nosuid,nodev,noexec
# If /etc/fstab is used: run the following command and verify that tmpfs has been mounted
# to tmpfs, or a system partition has been created for /tmp
# tmpfs /tmp tmpfs defaults,noexec,nosuid,nodev 0 0
# OR If systemd tmp.mount file is used: run the following command and verify that tmp.mount
# is enabled:
# UnitFileState=enabled

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: findmnt -n /tmp
output_1=$( findmnt -n /tmp 2>&1 )
status_1=$?
echo "Audit command 1: findmnt -n /tmp"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '\s/tmp\s' /etc/fstab | grep -E -v '^\s*#'
output_2=$( grep -E '\s/tmp\s' /etc/fstab | grep -E -v '^\s*#' 2>&1 )
status_2=$?
echo "Audit command 2: grep -E '\s/tmp\s' /etc/fstab | grep -E -v '^\s*#'"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: systemctl show "tmp.mount" | grep -i unitfilestate
output_3=$( systemctl show "tmp.mount" | grep -i unitfilestate 2>&1 )
status_3=$?
echo "Audit command 3: systemctl show "tmp.mount" | grep -i unitfilestate"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    mount -o remount,noexec,nodev,nosuid /tmp
    [ ! -f /etc/systemd/system/tmp.mount ] && cp -v
    systemctl daemon-reload
    systemctl --now unmask tmp.mount
fi
