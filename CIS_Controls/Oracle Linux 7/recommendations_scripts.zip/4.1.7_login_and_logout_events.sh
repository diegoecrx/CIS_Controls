#!/bin/bash

# ID: 4.1.7
# Nome Completo: 4.1.7 Ensure login and logout events are collected (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# -w /var/log/lastlog -p wa -k logins
# -w /var/run/faillock/ -p wa -k logins

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep logins /etc/audit/rules.d/*.rules
output_1=$( grep logins /etc/audit/rules.d/*.rules 2>&1 )
status_1=$?
echo "Audit command 1: grep logins /etc/audit/rules.d/*.rules"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: auditctl -l | grep logins
output_2=$( auditctl -l | grep logins 2>&1 )
status_2=$?
echo "Audit command 2: auditctl -l | grep logins"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit or create a file in the /etc/audit/rules.d/ directory ending in .rules
    # Example: vi /etc/audit/rules.d/50-logins.rules
    # Add the following lines:
    # -w /var/log/lastlog -p wa -k logins
    # -w /var/run/faillock/ -p wa -k logins
fi
