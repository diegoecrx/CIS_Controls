#!/bin/bash

# ID: 5.3.4
# Nome Completo: 5.3.4 Ensure SSH access is limited (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /etc/hosts | awk '{print $1}')" | grep -Pi
# '^\h*(allow|deny)(users|groups)\h+\H+(\h+.*)?$'
# /etc/ssh/sshd_config
# allowusers <userlist>
# allowgroups <grouplist>
# denyusers <userlist>
# denygroups <grouplist>

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)
output_1=$( sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) 2>&1 )
status_1=$?
echo "Audit command 1: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -Pi '^\h*(allow|deny)(users|groups)\h+\H+(\h+.*)?$'
output_2=$( grep -Pi '^\h*(allow|deny)(users|groups)\h+\H+(\h+.*)?$' 2>&1 )
status_2=$?
echo "Audit command 2: grep -Pi '^\h*(allow|deny)(users|groups)\h+\H+(\h+.*)?$'"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/ssh/sshd_config file to set one or more of the parameter as follows:
    # AllowUsers <userlist>
    # OR
    # AllowGroups <grouplist>
    # OR
    # DenyUsers <userlist>
    # OR
    # DenyGroups <grouplist>
fi
