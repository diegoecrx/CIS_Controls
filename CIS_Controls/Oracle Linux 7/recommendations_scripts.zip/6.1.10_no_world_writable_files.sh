#!/bin/bash

# ID: 6.1.10
# Nome Completo: 6.1.10 Ensure no world writable files exist (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# -type f -perm -0002
# The command above only searches local filesystems, there may still be compromised items
# on network mounted partitions. Additionally the --local option to df is not universal to all
# versions, it can be omitted to search all filesystems on a system including network mounted
# filesystems or the following command can be run manually for each partition:

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev
output_1=$( df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev 2>&1 )
status_1=$?
echo "Audit command 1: df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: find <partition> -xdev -type f -perm -0002
output_2=$( find <partition> -xdev -type f -perm -0002 2>&1 )
status_2=$?
echo "Audit command 2: find <partition> -xdev -type f -perm -0002"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Removing write access for the "other" category ( chmod o-w <filename> ) is advisable, but
    # always consult relevant vendor documentation to avoid breaking any application
    # dependencies on a given file.
fi
