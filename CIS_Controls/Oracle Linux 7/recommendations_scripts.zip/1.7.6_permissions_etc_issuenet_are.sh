#!/bin/bash

# ID: 1.7.6
# Nome Completo: 1.7.6 Ensure permissions on /etc/issue.net are configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Access: (0644/-rw-r--r--) Uid: ( 0/ root) Gid: ( 0/ root)

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: stat /etc/issue.net
output_1=$( stat /etc/issue.net 2>&1 )
status_1=$?
echo "Audit command 1: stat /etc/issue.net"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    chown root:root /etc/issue.net
    chmod u-x,go-wx /etc/issue.net
fi
