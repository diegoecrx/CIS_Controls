#!/bin/bash

# ID: 3.5.3.2.3
# Nome Completo: 3.5.3.2.3 Ensure iptables rules exist for all open ports (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Netid State Recv-Q Send-Q Local Address:Port Peer
# Address:Port
# udp UNCONN 0 0 *:68
# *:*
# udp UNCONN 0 0 *:123
# *:*
# tcp LISTEN 0 128 *:22
# *:*
# Chain INPUT (policy DROP 0 packets, 0 bytes)
# pkts bytes target prot opt in out source
# destination
# 0 0 ACCEPT all -- lo * 0.0.0.0/0 0.0.0.0/0
# 0 0 DROP all -- * * 127.0.0.0/8 0.0.0.0/0
# 0 0 ACCEPT tcp -- * * 0.0.0.0/0 0.0.0.0/0
# tcp dpt:22 state NEW
# Note: The last line identified by the "tcp dpt:22 state NEW" identifies it as a firewall rule for
# new connections on tcp port 22.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: ss -4tuln
output_1=$( ss -4tuln 2>&1 )
status_1=$?
echo "Audit command 1: ss -4tuln"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: iptables -L INPUT -v -n
output_2=$( iptables -L INPUT -v -n 2>&1 )
status_2=$?
echo "Audit command 2: iptables -L INPUT -v -n"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    iptables -A INPUT -p <protocol> --dport <port> -m state --state NEW -j
fi
