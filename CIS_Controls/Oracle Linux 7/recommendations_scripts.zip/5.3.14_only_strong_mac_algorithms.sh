#!/bin/bash

# ID: 5.3.14
# Nome Completo: 5.3.14 Ensure only strong MAC algorithms are used (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# /etc/hosts | awk '{print $1}')" | grep -Ei '^\s*macs\s+([^#]+,)?(hmac-
# md5|hmac-md5-96|hmac-ripemd160|hmac-sha1|hmac-sha1-96|umac-
# 64@openssh\.com|hmac-md5-etm@openssh\.com|hmac-md5-96-etm@openssh\.com|hmac-
# ripemd160-etm@openssh\.com|hmac-sha1-etm@openssh\.com|hmac-sha1-96-
# etm@openssh\.com|umac-64-etm@openssh\.com|umac-128-etm@openssh\.com)\b'
# Nothing should be returned
# sha1|hmac-sha1-96|umac-64@openssh\.com|hmac-md5-etm@openssh\.com|hmac-md5-96-
# etm@openssh\.com|hmac-ripemd160-etm@openssh\.com|hmac-sha1-
# etm@openssh\.com|hmac-sha1-96-etm@openssh\.com|umac-64-etm@openssh\.com|umac-
# 128-etm@openssh\.com)\b' /etc/ssh/sshd_config
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)
output_1=$( sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) 2>&1 )
status_1=$?
echo "Audit command 1: sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname)"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -Ei '^\s*macs\s+([^#]+,)?(hmac-md5|hmac-md5-96|hmac-ripemd160|hmac-
output_2=$( grep -Ei '^\s*macs\s+([^#]+,)?(hmac-md5|hmac-md5-96|hmac-ripemd160|hmac- 2>&1 )
status_2=$?
echo "Audit command 2: grep -Ei '^\s*macs\s+([^#]+,)?(hmac-md5|hmac-md5-96|hmac-ripemd160|hmac-"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit the /etc/ssh/sshd_config file and add/modify the MACs line to contain a comma
    # separated list of the site approved MACs
    # Example:
    # MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-
    # 512,hmac-sha2-256
fi
