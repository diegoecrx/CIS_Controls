#!/bin/bash

# ID: 2.2.1.2
# Nome Completo: 2.2.1.2 Ensure chrony is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# IF chrony is installed on the system:
# server <remote-server>
# Multiple servers may be configured.
# OPTIONS="-u chrony"
# Additional options may be present.

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -E "^(server|pool)" /etc/chrony.conf
output_1=$( grep -E "^(server|pool)" /etc/chrony.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep -E "^(server|pool)" /etc/chrony.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep ^OPTIONS /etc/sysconfig/chronyd
output_2=$( grep ^OPTIONS /etc/sysconfig/chronyd 2>&1 )
status_2=$?
echo "Audit command 2: grep ^OPTIONS /etc/sysconfig/chronyd"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Add or edit server or pool lines to /etc/chrony.conf as appropriate:
    # server <remote-server>
    # Add or edit the OPTIONS in /etc/sysconfig/chronyd to include '-u chrony':
    # OPTIONS="-u chrony"
fi
