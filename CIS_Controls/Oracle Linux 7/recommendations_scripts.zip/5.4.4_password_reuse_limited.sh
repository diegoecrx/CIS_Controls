#!/bin/bash

# ID: 5.4.4
# Nome Completo: 5.4.4 Ensure password reuse is limited (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# If pam_pwhistory.so is used:
# '^\s*password\s+(requisite|required)\s+pam_pwhistory\.so\s+([^#]+\s+)*remembe
# r=([5-9]|[1-9][0-9]+)\b' /etc/pam.d/system-auth /etc/pam.d/password-auth
# /etc/pam.d/system-auth:password required pam_pwhistory.so remember=5
# /etc/pam.d/password-auth:password required pam_pwhistory.so
# remember=5
# OR If pam_unix.so is used:
# '^\s*password\s+(sufficient|requisite|required)\s+pam_unix\.so\s+([^#]+\s+)*r
# emember=([5-9]|[1-9][0-9]+)\b' /etc/pam.d/system-auth /etc/pam.d/password-
# auth
# /etc/pam.d/system-auth:password sufficient pam_unix.so remember=5
# /etc/pam.d/password-auth:password sufficient pam_unix.so remember=5

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -P
output_1=$( grep -P 2>&1 )
status_1=$?
echo "Audit command 1: grep -P"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -P
output_2=$( grep -P 2>&1 )
status_2=$?
echo "Audit command 2: grep -P"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit both the /etc/pam.d/password-auth and /etc/pam.d/system-auth files to include the
    # remember option and conform to site policy as shown:
    # Note: Add or modify the line containing the pam_pwhistory.so after the first occurrence of
    # password requisite:
    # password required pam_pwhistory.so remember=5
    # Example: (Second line is modified)
    # password requisite pam_pwquality.so try_first_pass local_users_only
    # authtok_type=
    # password required pam_pwhistory.so use_authtok remember=5 retry=3
    # password sufficient pam_unix.so sha512 shadow nullok try_first_pass
    # use_authtok
    # password required pam_deny.so
    # Additional Information:
    # 
    # This setting only applies to local accounts.
    # 
    # This option is configured with the remember=n module option in
    # /etc/pam.d/system-auth and /etc/pam.d/password-auth
    # 
    # This option can be set with either one of the two following modules:
    # o
    # pam_pwhistory.so - This is the newer recommended method included in the
    # remediation section.
    # o
    # pam_unix.so - This is the older method, and is included in the audit to
    # account for legacy configurations.
fi
