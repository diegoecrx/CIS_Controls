#!/bin/bash

# ID: 3.5.2.7
# Nome Completo: 3.5.2.7 Ensure nftables loopback traffic is configured (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# iif "lo" accept
# ip saddr 127.0.0.0/8 counter packets 0 bytes 0 drop
# IF IPv6 is enabled, run the following command to verify that the IPv6 loopback interface is
# configured:
# ip6 saddr ::1 counter packets 0 bytes 0 drop
# OR
# [ -n "$passing" ] && passing=""
# [ -z "$(grep "^\s*linux" /boot/grub2/grub.cfg | grep -v ipv6.disabled=1)" ]
# && passing="true"
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$"
# /etc/sysctl.conf \
# /etc/sysctl.d/*.conf && grep -Eq
# "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" \
# /etc/sysctl.conf /etc/sysctl.d/*.conf && sysctl
# net.ipv6.conf.all.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" && \
# sysctl net.ipv6.conf.default.disable_ipv6 | \
# grep -Eq "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b(\s+#.*)?$" &&
# passing="true"
# if [ "$passing" = true ] ; then
# echo "IPv6 is disabled on the system"
# else
# echo "IPv6 is enabled on the system"
# fi

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: nft list ruleset | awk '/hook input/,/}/' | grep 'iif "lo" accept'
output_1=$( nft list ruleset | awk '/hook input/,/}/' | grep 'iif "lo" accept' 2>&1 )
status_1=$?
echo "Audit command 1: nft list ruleset | awk '/hook input/,/}/' | grep 'iif "lo" accept'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: nft list ruleset | awk '/hook input/,/}/' | grep 'ip saddr'
output_2=$( nft list ruleset | awk '/hook input/,/}/' | grep 'ip saddr' 2>&1 )
status_2=$?
echo "Audit command 2: nft list ruleset | awk '/hook input/,/}/' | grep 'ip saddr'"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: nft list ruleset | awk '/hook input/,/}/' | grep 'ip6 saddr'
output_3=$( nft list ruleset | awk '/hook input/,/}/' | grep 'ip6 saddr' 2>&1 )
status_3=$?
echo "Audit command 3: nft list ruleset | awk '/hook input/,/}/' | grep 'ip6 saddr'"
echo "Output:" "$$output_3"
echo "Status: $status_3"
if [ $status_3 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: !/bin/bash
output_4=$( !/bin/bash 2>&1 )
status_4=$?
echo "Audit command 4: !/bin/bash"
echo "Output:" "$$output_4"
echo "Status: $status_4"
if [ $status_4 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    nft add rule inet filter input iif lo accept
    nft create rule inet filter input ip saddr 127.0.0.0/8 counter drop
    nft add rule inet filter input ip6 saddr ::1 counter drop
fi
