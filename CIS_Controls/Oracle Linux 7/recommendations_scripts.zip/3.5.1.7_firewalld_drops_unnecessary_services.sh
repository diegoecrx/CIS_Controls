#!/bin/bash

# ID: 3.5.1.7
# Nome Completo: 3.5.1.7 Ensure firewalld drops unnecessary services and ports (Manual)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# follow site policy.
# firewall-cmd --list-all --zone=$ZN; done

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: firewall-cmd --get-active-zones | awk '!/:/ {print $1}' | while read ZN; do
output_1=$( firewall-cmd --get-active-zones | awk '!/:/ {print $1}' | while read ZN; do 2>&1 )
status_1=$?
echo "Audit command 1: firewall-cmd --get-active-zones | awk '!/:/ {print $1}' | while read ZN; do"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    firewall-cmd --remove-service=<service>
    firewall-cmd --remove-service=cockpit
    firewall-cmd --remove-port=<port-number>/<port-type>
    firewall-cmd --remove-port=25/tcp
    firewall-cmd --runtime-to-permanent
fi
