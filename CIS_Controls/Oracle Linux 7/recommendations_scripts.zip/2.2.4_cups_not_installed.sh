#!/bin/bash

# ID: 2.2.4
# Nome Completo: 2.2.4 Ensure CUPS is not installed (Automated)
# Profile Applicability: Level 1 - Server
PROFILE_APPLICABILITY="Level 1 - Server"

# Expected output for audit:
# package cups is not installed

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: rpm -q cups
output_1=$( rpm -q cups 2>&1 )
status_1=$?
echo "Audit command 1: rpm -q cups"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    yum remove cups
fi
