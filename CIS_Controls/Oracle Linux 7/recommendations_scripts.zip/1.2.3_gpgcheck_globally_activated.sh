#!/bin/bash

# ID: 1.2.3
# Nome Completo: 1.2.3 Ensure gpgcheck is globally activated (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# gpgcheck=1
# /etc/yum.repos.d/*.repo
# Nothing should be returned

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep ^\s*gpgcheck /etc/yum.conf
output_1=$( grep ^\s*gpgcheck /etc/yum.conf 2>&1 )
status_1=$?
echo "Audit command 1: grep ^\s*gpgcheck /etc/yum.conf"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -P '^\h*gpgcheck=[^1\n\r]+\b(\h+.*)?$' /etc/yum.conf
output_2=$( grep -P '^\h*gpgcheck=[^1\n\r]+\b(\h+.*)?$' /etc/yum.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep -P '^\h*gpgcheck=[^1\n\r]+\b(\h+.*)?$' /etc/yum.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Edit /etc/yum.conf and set 'gpgcheck=1' in the [main] section.
    # Edit any failing files in /etc/yum.repos.d/*.repo and set all instances of gpgcheck to 1.
fi
