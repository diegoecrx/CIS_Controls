#!/bin/bash

# ID: 1.6.1.6
# Nome Completo: 1.6.1.6 Ensure no unconfined services exist (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: ps -eZ | grep unconfined_service_t
output_1=$( ps -eZ | grep unconfined_service_t 2>&1 )
status_1=$?
echo "Audit command 1: ps -eZ | grep unconfined_service_t"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # Investigate any unconfined processes found during the audit action. They may need to have
    # an existing security context assigned to them or a policy built for them.
fi
