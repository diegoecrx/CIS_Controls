#!/bin/bash

# ID: 3.5.2.5
# Nome Completo: 3.5.2.5 Ensure an nftables table exists (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Return should include a list of nftables:
# Example:
# table inet filter

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: nft list tables
output_1=$( nft list tables 2>&1 )
status_1=$?
echo "Audit command 1: nft list tables"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    nft create table inet <table name>
    nft create table inet filter
fi
