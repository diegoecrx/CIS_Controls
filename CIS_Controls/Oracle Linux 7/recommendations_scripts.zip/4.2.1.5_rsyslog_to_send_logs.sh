#!/bin/bash

# ID: 4.2.1.5
# Nome Completo: 4.2.1.5 Ensure rsyslog is configured to send logs to a remote log host (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# Review the /etc/rsyslog.conf and /etc/rsyslog.d/*.conf files and verify that logs are
# sent to a central host.
# /etc/rsyslog.conf /etc/rsyslog.d/*.conf
# Output should include target=<FQDN or IP of remote loghost>
# OR
# Output should include either the FQDN or the IP of the remote loghost

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: grep -E '^\s*([^#]+\s+)?action\(([^#]+\s+)?\btarget=\"?[^#"]+\"?\b'
output_1=$( grep -E '^\s*([^#]+\s+)?action\(([^#]+\s+)?\btarget=\"?[^#"]+\"?\b' 2>&1 )
status_1=$?
echo "Audit command 1: grep -E '^\s*([^#]+\s+)?action\(([^#]+\s+)?\btarget=\"?[^#"]+\"?\b'"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

# Audit command: grep -E '^[^#]\s*\S+\.\*\s+@' /etc/rsyslog.conf /etc/rsyslog.d/*.conf
output_2=$( grep -E '^[^#]\s*\S+\.\*\s+@' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 2>&1 )
status_2=$?
echo "Audit command 2: grep -E '^[^#]\s*\S+\.\*\s+@' /etc/rsyslog.conf /etc/rsyslog.d/*.conf"
echo "Output:" "$$output_2"
echo "Status: $status_2"
if [ $status_2 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    systemctl restart rsyslog
fi
