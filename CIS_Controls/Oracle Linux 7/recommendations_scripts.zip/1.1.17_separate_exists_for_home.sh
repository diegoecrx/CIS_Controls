#!/bin/bash

# ID: 1.1.17
# Nome Completo: 1.1.17 Ensure separate partition exists for /home (Automated)
# Profile Applicability: Level 2 - Server | Level 2 - Workstation
PROFILE_APPLICABILITY="Level 2 - Server | Level 2 - Workstation"

# Expected output for audit:
# TARGET SOURCE FSTYPE OPTIONS
# /home <device> <fstype> rw,relatime,attr2,inode64,noquota

# Execute audit commands and evaluate status
AUDIT_PASS=true

# Audit command: findmnt /home
output_1=$( findmnt /home 2>&1 )
status_1=$?
echo "Audit command 1: findmnt /home"
echo "Output:" "$$output_1"
echo "Status: $status_1"
if [ $status_1 -ne 0 ]; then
    AUDIT_PASS=false
fi

if [ "$AUDIT_PASS" = true ]; then
    echo "Audit passed. No remediation required."
else
    echo "Audit failed. Applying remediation..."
    # No remediation commands found in the provided guidance.
    # For new installations, during installation create a custom partition setup and specify a
    # separate partition for /home .
    # For systems that were previously installed, create a new partition and configure
    # /etc/fstab as appropriate.
fi
