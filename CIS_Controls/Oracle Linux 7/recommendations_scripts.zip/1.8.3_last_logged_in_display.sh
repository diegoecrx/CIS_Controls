#!/bin/bash

# ID: 1.8.3
# Nome Completo: 1.8.3 Ensure last logged in user display is disabled (Automated)
# Profile Applicability: Level 1 - Server | Level 1 - Workstation
PROFILE_APPLICABILITY="Level 1 - Server | Level 1 - Workstation"

# Expected output for audit:
# user-db:user
# system-db:gdm
# file-db:/usr/share/gdm/greeter-dconf-defaults
# typically /etc/dconf/db/gdm.d/00-login-screen)
# [org/gnome/login-screen]
# disable-user-list=true

# No audit commands found. Manual verification may be required.
# Applying remediation commands
Do not show the user list
dconf update
