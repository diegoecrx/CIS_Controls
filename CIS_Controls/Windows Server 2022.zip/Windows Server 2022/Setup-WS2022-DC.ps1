<# 
WS2022 NAT (VMware VMnet8) — Promote to first DC for lab.local and seed directory
Host: WS2022-DC  |  IP: 192.168.30.10/24  |  GW: 192.168.30.2  |  DNS: self
Creates OU "IT Department", Group "IT" (Global/Security), and user 'msuser' with password '@Real2014CIS321!' in that OU.
Installs IIS and sets DNS forwarders. Idempotent; safe to re-run after reboots.
#>

[CmdletBinding()]
param(
  [string]$DomainName       = 'lab.local',
  [string]$DomainNetBIOS    = 'LAB',
  [string]$TargetHostname   = 'WS2022-DC',
  [string]$InterfaceAlias   = 'Ethernet0',
  [string]$IPv4             = '192.168.30.10',
  [int]   $PrefixLength     = 24,
  [string]$DefaultGateway   = '192.168.30.2',
  [string[]]$DnsForwarders  = @('1.1.1.1','8.8.8.8'),

  # Directory seed (UPDATED)
  [string]$OuITName         = 'IT Department',
  [string]$SeedUserSam      = 'msuser',
  [string]$SeedUserPwdPlain = '@Real2014CIS321!'
)

function Info($m){ Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function Warn($m){ Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Err ($m){ Write-Host "[ERROR] $m" -ForegroundColor Red }

$null = New-Item -ItemType Directory -Path C:\Logs -ErrorAction SilentlyContinue
$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
Start-Transcript -Path "C:\Logs\dc_setup_$ts.log" -Force | Out-Null

# Admin check
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run as Administrator." }

function Ensure-IPv4 {
  param([string]$Nic,[string]$IP,[int]$Pref,[string]$Gw,[string[]]$Dns)
  Set-NetIPInterface -InterfaceAlias $Nic -Dhcp Disabled -ErrorAction SilentlyContinue | Out-Null
  $cur = Get-NetIPAddress -InterfaceAlias $Nic -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.PrefixOrigin -ne 'WellKnown'}
  $have = $false
  foreach($c in ($cur | Where-Object { $_.IPAddress -notlike '169.254.*' })) {
    if ($c.IPAddress -eq $IP -and $c.PrefixLength -eq $Pref) { $have = $true } else {
      $c | Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue
    }
  }
  if (-not $have) {
    New-NetIPAddress -InterfaceAlias $Nic -IPAddress $IP -PrefixLength $Pref -DefaultGateway $Gw | Out-Null
    Info "$Nic -> $IP/$Pref gw $Gw"
  } else {
    Info "$Nic already $IP/$Pref"
    $gwCur = (Get-NetIPConfiguration -InterfaceAlias $Nic).IPv4DefaultGateway.NextHop
    if ($Gw -and $gwCur -ne $Gw) {
      Remove-NetRoute -InterfaceAlias $Nic -DestinationPrefix '0.0.0.0/0' -Confirm:$false -ErrorAction SilentlyContinue
      New-NetRoute    -InterfaceAlias $Nic -DestinationPrefix '0.0.0.0/0' -NextHop $Gw | Out-Null
      Info "Updated default route via $Gw"
    }
  }
  if ($Dns) {
    $curDns = (Get-DnsClientServerAddress -InterfaceAlias $Nic -AddressFamily IPv4).ServerAddresses
    if (($curDns -join ',') -ne ($Dns -join ',')) {
      Set-DnsClientServerAddress -InterfaceAlias $Nic -ServerAddresses $Dns
      Info "DNS on $Nic -> $($Dns -join ', ')"
    }
  }
}

# 1) Hostname
$current = (Get-ComputerInfo).CsName
if ($current -ne $TargetHostname) {
  Info ("Renaming {0} -> {1} (rebooting...)" -f $current,$TargetHostname)
  Rename-Computer -NewName $TargetHostname -Force
  Restart-Computer -Force
  Stop-Transcript | Out-Null
  exit
} else { Info "Hostname OK: $TargetHostname" }

# 2) NIC / IPv4 / GW / DNS (self)
Ensure-IPv4 -Nic $InterfaceAlias -IP $IPv4 -Pref $PrefixLength -Gw $DefaultGateway -Dns @($IPv4)

# 3) AD DS binaries
if (-not (Get-WindowsFeature AD-Domain-Services).Installed) {
  Info "Installing AD-Domain-Services..."
  Install-WindowsFeature AD-Domain-Services -IncludeManagementTools | Out-Null
}
Import-Module ADDSDeployment

# 4) Promote if needed (reboots)
$domainExists = $false
try { $null = Get-ADDomain -Identity $DomainName -ErrorAction Stop; $domainExists = $true } catch {}
if (-not $domainExists) {
  $dsrm = Read-Host "Enter DSRM (Safe Mode) password" -AsSecureString
  Info "Creating forest $DomainName (NetBIOS $DomainNetBIOS)..."
  Install-ADDSForest `
    -DomainName $DomainName `
    -DomainNetbiosName $DomainNetBIOS `
    -InstallDns:$true `
    -CreateDnsDelegation:$false `
    -DatabasePath 'C:\Windows\NTDS' `
    -LogPath 'C:\Windows\NTDS' `
    -SysvolPath 'C:\Windows\SYSVOL' `
    -SafeModeAdministratorPassword $dsrm `
    -NoRebootOnCompletion:$false `
    -Force:$true
  Stop-Transcript | Out-Null
  exit
} else { Info "Forest $DomainName already present." }

# 5) DNS forwarders + reverse zone
Import-Module DnsServer -ErrorAction Stop
try {
  $curFwd = (Get-DnsServerForwarder -ErrorAction SilentlyContinue).IPAddress
  if (-not $curFwd -or (($curFwd | Sort-Object) -join ',') -ne (($DnsForwarders | Sort-Object) -join ',')) {
    Set-DnsServerForwarder -IPAddress $DnsForwarders -PassThru | Out-Null
    Info "DNS forwarders -> $($DnsForwarders -join ', ')"
  } else { Info "DNS forwarders already set." }
  Set-DnsServerRecursion -Enable $true
} catch { Warn "Forwarders step: $($_.Exception.Message)" }

if (-not (Get-DnsServerZone -Name '30.168.192.in-addr.arpa' -ErrorAction SilentlyContinue)) {
  Add-DnsServerPrimaryZone -NetworkId '192.168.30.0/24' -DynamicUpdate Secure -ReplicationScope Forest | Out-Null
  Info "Created reverse zone 30.168.192.in-addr.arpa"
}

# 6) Create OU (IT Department) and Group (IT)
Import-Module ActiveDirectory
$baseDN = (Get-ADDomain $DomainName).DistinguishedName
$ouITDN = "OU=$OuITName,$baseDN"
if (-not (Get-ADOrganizationalUnit -LDAPFilter "(ou=$OuITName)" -SearchBase $baseDN -ErrorAction SilentlyContinue)) {
  New-ADOrganizationalUnit -Name $OuITName -Path $baseDN | Out-Null
  Info ("Created OU '{0}'" -f $OuITName)
}
# Group "IT" in IT Department
$itGroupDN = "CN=IT,$ouITDN"
if (-not (Get-ADGroup -LDAPFilter "(cn=IT)" -SearchBase $ouITDN -ErrorAction SilentlyContinue)) {
  New-ADGroup -Name 'IT' -GroupScope Global -GroupCategory Security -Path $ouITDN -SamAccountName 'IT' | Out-Null
  Info "Created Group 'IT' in OU=IT Department"
}

# 7) Ensure user 'msuser' in OU=IT Department with given password, and add to IT group
$seedPwd = ConvertTo-SecureString $SeedUserPwdPlain -AsPlainText -Force
$user = Get-ADUser -Filter "SamAccountName -eq '$SeedUserSam'" -ErrorAction SilentlyContinue
if (-not $user) {
  try {
    New-ADUser -Name $SeedUserSam -SamAccountName $SeedUserSam -UserPrincipalName "$SeedUserSam@$DomainName" `
               -GivenName 'MS' -Surname 'User' -DisplayName 'MS User' `
               -Path $ouITDN -AccountPassword $seedPwd -Enabled $true `
               -ChangePasswordAtLogon:$false -PasswordNeverExpires:$false | Out-Null
    Info ("Created user {0} in OU '{1}'" -f $SeedUserSam,$OuITName)
  } catch {
    if ($_.Exception.Message -match 'length, complexity, or history') {
      Err ("Password '@Real2014CIS321!' was **not accepted** by domain policy: {0}" -f $_.Exception.Message)
      throw
    } else { throw }
  }
} else {
  # Move to IT OU if needed, then set password (no history workaround here by request—notify instead)
  if ($user.DistinguishedName -notlike "*$($OuITName),$baseDN") {
    Move-ADObject -Identity $user.DistinguishedName -TargetPath $ouITDN
    Info ("Moved user {0} to OU '{1}'" -f $SeedUserSam,$OuITName)
  }
  try {
    Set-ADAccountPassword -Identity $SeedUserSam -Reset -NewPassword $seedPwd
  } catch {
    if ($_.Exception.Message -match 'length, complexity, or history') {
      Err ("Password '@Real2014CIS321!' was **not accepted** by domain policy: {0}" -f $_.Exception.Message)
      throw
    } else { throw }
  }
  Enable-ADAccount -Identity $SeedUserSam
  Unlock-ADAccount -Identity $SeedUserSam -ErrorAction SilentlyContinue
  Set-ADUser -Identity $SeedUserSam -ChangePasswordAtLogon:$false -PasswordNeverExpires:$false -AccountExpirationDate $null -Clear logonHours
  Info ("Ensured user {0} enabled" -f $SeedUserSam)
}

# Add user to IT group (idempotent)
Add-ADGroupMember -Identity 'IT' -Members $SeedUserSam -ErrorAction SilentlyContinue
Info ("Added {0} to IT group" -f $SeedUserSam)

# 8) IIS as test service
if (-not (Get-WindowsFeature Web-Server).Installed) { Install-WindowsFeature Web-Server -IncludeManagementTools | Out-Null }
Start-Service W3SVC -ErrorAction SilentlyContinue
Set-Service  W3SVC -StartupType Automatic
"<!doctype html><h1>WS2022-DC (IIS)</h1><p>Domain: $DomainName</p>" | Out-File "C:\inetpub\wwwroot\index.html" -Encoding UTF8 -Force

Get-Service DNS, Netlogon, W3SVC | Format-Table Name,Status
Info "DC setup complete."
Stop-Transcript | Out-Null
