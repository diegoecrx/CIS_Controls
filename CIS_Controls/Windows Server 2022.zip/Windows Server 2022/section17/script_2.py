
import pandas as pd
import os
import re
import zipfile

# Read the Excel file for section 17
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section17.xlsx', sheet_name='Recommendations')

# Create output directory
output_dir = "section17_scripts"
os.makedirs(output_dir, exist_ok=True)

print("Generating Section 17 PowerShell Scripts")
print("="*80)
print(f"Total scripts to generate: {len(df)}\n")

# Mapping of audit categories to their auditpol subcategory names
audit_mapping = {
    "Credential Validation": "Credential Validation",
    "Kerberos Authentication Service": "Kerberos Authentication Service",
    "Kerberos Service Ticket Operations": "Kerberos Service Ticket Operations",
    "Application Group Management": "Application Group Management",
    "Computer Account Management": "Computer Account Management",
    "Distribution Group Management": "Distribution Group Management",
    "Other Account Management Events": "Other Account Management Events",
    "Security Group Management": "Security Group Management",
    "User Account Management": "User Account Management",
    "PNP Activity": "Plug and Play Events",
    "Process Creation": "Process Creation",
    "Directory Service Access": "Directory Service Access",
    "Directory Service Changes": "Directory Service Changes",
    "Account Lockout": "Account Lockout",
    "Group Membership": "Group Membership",
    "Logoff": "Logoff",
    "Logon": "Logon",
    "Other Logon/Logoff Events": "Other Logon/Logoff Events",
    "Special Logon": "Special Logon",
    "Detailed File Share": "Detailed File Share",
    "File Share": "File Share",
    "Other Object Access Events": "Other Object Access Events",
    "Removable Storage": "Removable Storage",
    "Audit Policy Change": "Audit Policy Change",
    "Authentication Policy Change": "Authentication Policy Change",
    "Authorization Policy Change": "Authorization Policy Change",
    "MPSSVC Rule-Level Policy Change": "MPSSVC Rule-Level Policy Change",
    "Other Policy Change Events": "Other Policy Change Events",
    "Sensitive Privilege Use": "Sensitive Privilege Use",
    "IPsec Driver": "IPsec Driver",
    "Other System Events": "Other System Events",
    "Security State Change": "Security State Change",
    "Security System Extension": "Security System Extension",
    "System Integrity": "System Integrity"
}

def extract_audit_category(control_name):
    """Extract audit category from control name"""
    for key in audit_mapping.keys():
        if key in control_name:
            return key, audit_mapping[key]
    return "Unknown", "Unknown"

def extract_audit_setting(control_name):
    """Extract the audit setting (Success, Failure, or both)"""
    if "Success and Failure" in control_name:
        return "Success and Failure"
    elif "include 'Success'" in control_name:
        return "Success"
    elif "include 'Failure'" in control_name:
        return "Failure"
    return "Success and Failure"

# Generate all scripts
generated_count = 0

for idx in range(len(df)):
    script_id = str(df.loc[idx, 'script_name']).strip()
    control_name = str(df.loc[idx, 'control_name']).strip()
    profile = str(df.loc[idx, 'profile_applicability']).strip()
    remediation = str(df.loc[idx, 'remediation']).strip()
    default_value = str(df.loc[idx, 'default_value']).strip()
    
    is_dc_only = "(DC only)" in control_name or "(DC Only)" in control_name
    is_ms_only = "(MS only)" in control_name or "(MS Only)" in control_name
    
    audit_name, auditpol_name = extract_audit_category(control_name)
    audit_setting = extract_audit_setting(control_name)
    
    filename = f"{script_id}.ps1"
    filepath = os.path.join(output_dir, filename)
    
    # Generate PowerShell script for Audit Policy configuration
    script_content = f'''###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# {script_id}.ps1
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control {script_id}

.DESCRIPTION
    This script configures Advanced Audit Policy for '{audit_name}'
    per CIS {script_id} control for Windows Server 2022.
    
    Profile Applicability: 
    {profile}
    
    Default value: {default_value}

.NOTES
    Requires: Run as Administrator
    Uses: auditpol.exe command-line utility
    
    Remediation Path: Computer Configuration\\Policies\\Windows Settings\\Security Settings\\
                      Advanced Audit Policy Configuration\\Audit Policies
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "{script_id}.ps1"
$CONTROL_NAME = "{control_name}"
$AUDIT_CATEGORY = "{audit_name}"
$AUDITPOL_SUBCATEGORY = "{auditpol_name}"
$RECOMMENDED_SETTING = "{audit_setting}"
$DEFAULT_VALUE = "{default_value}"
$IS_DC_ONLY = ${{"True" if is_dc_only else "False"}}
$IS_MS_ONLY = ${{"True" if is_ms_only else "False"}}

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Configure Advanced Audit Policy: $AUDIT_CATEGORY"
Write-Host ""
Write-Host "Profile Applicability: {profile}"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host "Recommended setting: $RECOMMENDED_SETTING"
Write-Host ""

# Determine if this is a Domain Controller or Member Server
$isDomainController = $false
$computerInfo = Get-WmiObject -Class Win32_ComputerSystem

if ($computerInfo.DomainRole -eq 4 -or $computerInfo.DomainRole -eq 5) {{
    $isDomainController = $true
}}

Write-Host "Remediation Details:"
Write-Host ""

# Check if this script should run on this system type
$shouldRun = $true
if ($IS_DC_ONLY -eq "True" -and -not $isDomainController) {{
    Write-Host "[INFO] This control is for Domain Controllers only."
    Write-Host "[INFO] Current system is a Member Server. Skipping remediation."
    $shouldRun = $false
}}

if ($IS_MS_ONLY -eq "True" -and $isDomainController) {{
    Write-Host "[INFO] This control is for Member Servers only."
    Write-Host "[INFO] Current system is a Domain Controller. Skipping remediation."
    $shouldRun = $false
}}

if ($shouldRun) {{
    try {{
        # Get current audit policy setting
        Write-Host "[INFO] Checking current audit policy for: $AUDITPOL_SUBCATEGORY"
        $currentSetting = auditpol /get /subcategory:"$AUDITPOL_SUBCATEGORY" 2>&1
        
        if ($LASTEXITCODE -eq 0) {{
            Write-Host ""
            Write-Host "[CURRENT] Audit Policy Status:"
            Write-Host $currentSetting
            Write-Host ""
        }}
        
        # Apply the recommended audit policy setting
        Write-Host "[ACTION] Configuring audit policy..."
        Write-Host "  - Subcategory: $AUDITPOL_SUBCATEGORY"
        Write-Host "  - Setting: $RECOMMENDED_SETTING"
        Write-Host ""
        
        # Construct auditpol command based on setting
        $auditpolCommand = ""
        if ($RECOMMENDED_SETTING -eq "Success and Failure") {{
            $auditpolCommand = "auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:enable /failure:enable"
        }}
        elseif ($RECOMMENDED_SETTING -eq "Success") {{
            $auditpolCommand = "auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:enable /failure:disable"
        }}
        elseif ($RECOMMENDED_SETTING -eq "Failure") {{
            $auditpolCommand = "auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:disable /failure:enable"
        }}
        
        # Execute the command
        $result = Invoke-Expression $auditpolCommand 2>&1
        
        if ($LASTEXITCODE -eq 0) {{
            Write-Host "[SUCCESS] Audit policy configured successfully"
            
            # Verify the configuration
            Write-Host ""
            Write-Host "[VERIFICATION] Updated Audit Policy Status:"
            $verifyResult = auditpol /get /subcategory:"$AUDITPOL_SUBCATEGORY"
            Write-Host $verifyResult
            Write-Host ""
        }} else {{
            Write-Host "[ERROR] Failed to apply audit policy. Exit code: $LASTEXITCODE"
            Write-Host $result
        }}
        
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "Remediation Summary:"
        Write-Host "- Control: {script_id}"
        Write-Host "- Status: COMPLETED"
        Write-Host "- Audit Category: $AUDIT_CATEGORY"
        Write-Host "- Audit Setting: $RECOMMENDED_SETTING"
        Write-Host "=============================================="
        
    }} catch {{
        Write-Host ""
        Write-Host "[ERROR] Failed to apply remediation automatically."
        Write-Host "Error details: $_"
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "MANUAL REMEDIATION REQUIRED"
        Write-Host "=============================================="
        Write-Host ""
        Write-Host "Please configure manually via Group Policy Editor:"
        Write-Host ""
        Write-Host "Path: Computer Configuration > Policies > Windows Settings > Security Settings"
        Write-Host "      > Advanced Audit Policy Configuration > Audit Policies"
        Write-Host ""
        Write-Host "Steps:"
        Write-Host "1. Open Group Policy Editor (gpedit.msc)"
        Write-Host "2. Navigate to the path above"
        Write-Host "3. Find the appropriate audit category"
        Write-Host "4. Double-click '$AUDIT_CATEGORY'"
        Write-Host "5. Check 'Configure the following audit events'"
        Write-Host "6. Select: $RECOMMENDED_SETTING"
        Write-Host "7. Click OK and apply the policy"
        Write-Host "8. Run 'gpupdate /force' to apply changes"
        Write-Host ""
        Write-Host "Alternative using auditpol.exe:"
        Write-Host "  auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:enable /failure:enable"
        Write-Host ""
        Write-Host "=============================================="
    }}
}} else {{
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation skipped based on system type."
    Write-Host "=============================================="
}}

Write-Host ""
Write-Host ""
Write-Host ""
'''
    
    # Write to file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    generated_count += 1
    if generated_count <= 5 or generated_count % 10 == 0:
        print(f"✓ Generated: {filename}")

print(f"\n✓ Successfully generated {generated_count} PowerShell scripts")
print(f"✓ Location: {output_dir}/")

# Create a ZIP file for easy download
zip_filename = "CIS_Section17_Scripts.zip"
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(output_dir):
        for file in files:
            file_path = os.path.join(root, file)
            zipf.write(file_path, os.path.basename(file_path))

print(f"\n✓ Created ZIP archive: {zip_filename}")
print(f"✓ Total size: {os.path.getsize(zip_filename) / 1024:.2f} KB")
print("\nAll Section 17 scripts are ready for deployment!")
