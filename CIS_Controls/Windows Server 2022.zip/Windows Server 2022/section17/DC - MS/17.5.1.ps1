# 17.5.1.ps1
(& {
  $subcategory = "Account Lockout"
  $after = "Failure"
  $dcOnly = $false

  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $isDC = $role -in 4,5

  # Check if this is a DC-only control
  if ($dcOnly -and -not $isDC) {
    Write-Output "Control: 17.5.1 (L1) Ensure 'Audit Account Lockout' is set to include 'Failure' (Automated)"
    Write-Output "Note: This control applies to Domain Controllers only"
    return
  }

  try {
    # Get current audit policy setting
    $currentSetting = auditpol /get /subcategory:"$subcategory" 2>$null
    $current = "Not Configured"

    if ($currentSetting -match "Success and Failure") {
      $current = "Success and Failure"
    }
    elseif ($currentSetting -match "Success") {
      $current = "Success"
    }
    elseif ($currentSetting -match "Failure") {
      $current = "Failure"
    }
    elseif ($currentSetting -match "No Auditing") {
      $current = "No Auditing"
    }

    # Apply remediation using auditpol
    auditpol /set /subcategory:"$subcategory" /success:disable /failure:enable | Out-Null

    Write-Output "Control: 17.5.1 (L1) Ensure 'Audit Account Lockout' is set to include 'Failure' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Advanced Audit Policy Configuration\Audit Policies"
    Write-Output "Name: $subcategory"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 17.5.1 (L1) Ensure 'Audit Account Lockout' is set to include 'Failure' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
