###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 17.7.4.ps1
# CIS Control - 17.7.4 (L1) Ensure 'Audit MPSSVC Rule-Level Policy Change' is set to 'Success and Failure' (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 17.7.4

.DESCRIPTION
    This script configures Advanced Audit Policy for 'MPSSVC Rule-Level Policy Change'
    per CIS 17.7.4 control for Windows Server 2022.

    Profile Applicability: 
    • Level 1 - Domain Controller
• Level 1 - Member Server

    Default value: No Auditing.

.NOTES
    Requires: Run as Administrator
    Uses: auditpol.exe command-line utility

    Remediation Path: Computer Configuration\Policies\Windows Settings\Security Settings\
                      Advanced Audit Policy Configuration\Audit Policies
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "17.7.4.ps1"
$CONTROL_NAME = "17.7.4 (L1) Ensure 'Audit MPSSVC Rule-Level Policy Change' is set to 'Success and Failure' (Automated)"
$AUDIT_CATEGORY = "MPSSVC Rule-Level Policy Change"
$AUDITPOL_SUBCATEGORY = "MPSSVC Rule-Level Policy Change"
$RECOMMENDED_SETTING = "Success and Failure"
$DEFAULT_VALUE = "No Auditing."
$IS_DC_ONLY = ${"True" if is_dc_only else "False"}
$IS_MS_ONLY = ${"True" if is_ms_only else "False"}

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Configure Advanced Audit Policy: $AUDIT_CATEGORY"
Write-Host ""
Write-Host "Profile Applicability: • Level 1 - Domain Controller
• Level 1 - Member Server"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host "Recommended setting: $RECOMMENDED_SETTING"
Write-Host ""

# Determine if this is a Domain Controller or Member Server
$isDomainController = $false
$computerInfo = Get-WmiObject -Class Win32_ComputerSystem

if ($computerInfo.DomainRole -eq 4 -or $computerInfo.DomainRole -eq 5) {
    $isDomainController = $true
}

Write-Host "Remediation Details:"
Write-Host ""

# Check if this script should run on this system type
$shouldRun = $true
if ($IS_DC_ONLY -eq "True" -and -not $isDomainController) {
    Write-Host "[INFO] This control is for Domain Controllers only."
    Write-Host "[INFO] Current system is a Member Server. Skipping remediation."
    $shouldRun = $false
}

if ($IS_MS_ONLY -eq "True" -and $isDomainController) {
    Write-Host "[INFO] This control is for Member Servers only."
    Write-Host "[INFO] Current system is a Domain Controller. Skipping remediation."
    $shouldRun = $false
}

if ($shouldRun) {
    try {
        # Get current audit policy setting
        Write-Host "[INFO] Checking current audit policy for: $AUDITPOL_SUBCATEGORY"
        $currentSetting = auditpol /get /subcategory:"$AUDITPOL_SUBCATEGORY" 2>&1

        if ($LASTEXITCODE -eq 0) {
            Write-Host ""
            Write-Host "[CURRENT] Audit Policy Status:"
            Write-Host $currentSetting
            Write-Host ""
        }

        # Apply the recommended audit policy setting
        Write-Host "[ACTION] Configuring audit policy..."
        Write-Host "  - Subcategory: $AUDITPOL_SUBCATEGORY"
        Write-Host "  - Setting: $RECOMMENDED_SETTING"
        Write-Host ""

        # Construct auditpol command based on setting
        $auditpolCommand = ""
        if ($RECOMMENDED_SETTING -eq "Success and Failure") {
            $auditpolCommand = "auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:enable /failure:enable"
        }
        elseif ($RECOMMENDED_SETTING -eq "Success") {
            $auditpolCommand = "auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:enable /failure:disable"
        }
        elseif ($RECOMMENDED_SETTING -eq "Failure") {
            $auditpolCommand = "auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:disable /failure:enable"
        }

        # Execute the command
        $result = Invoke-Expression $auditpolCommand 2>&1

        if ($LASTEXITCODE -eq 0) {
            Write-Host "[SUCCESS] Audit policy configured successfully"

            # Verify the configuration
            Write-Host ""
            Write-Host "[VERIFICATION] Updated Audit Policy Status:"
            $verifyResult = auditpol /get /subcategory:"$AUDITPOL_SUBCATEGORY"
            Write-Host $verifyResult
            Write-Host ""
        } else {
            Write-Host "[ERROR] Failed to apply audit policy. Exit code: $LASTEXITCODE"
            Write-Host $result
        }

        Write-Host ""
        Write-Host "=============================================="
        Write-Host "Remediation Summary:"
        Write-Host "- Control: 17.7.4"
        Write-Host "- Status: COMPLETED"
        Write-Host "- Audit Category: $AUDIT_CATEGORY"
        Write-Host "- Audit Setting: $RECOMMENDED_SETTING"
        Write-Host "=============================================="

    } catch {
        Write-Host ""
        Write-Host "[ERROR] Failed to apply remediation automatically."
        Write-Host "Error details: $_"
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "MANUAL REMEDIATION REQUIRED"
        Write-Host "=============================================="
        Write-Host ""
        Write-Host "Please configure manually via Group Policy Editor:"
        Write-Host ""
        Write-Host "Path: Computer Configuration > Policies > Windows Settings > Security Settings"
        Write-Host "      > Advanced Audit Policy Configuration > Audit Policies"
        Write-Host ""
        Write-Host "Steps:"
        Write-Host "1. Open Group Policy Editor (gpedit.msc)"
        Write-Host "2. Navigate to the path above"
        Write-Host "3. Find the appropriate audit category"
        Write-Host "4. Double-click '$AUDIT_CATEGORY'"
        Write-Host "5. Check 'Configure the following audit events'"
        Write-Host "6. Select: $RECOMMENDED_SETTING"
        Write-Host "7. Click OK and apply the policy"
        Write-Host "8. Run 'gpupdate /force' to apply changes"
        Write-Host ""
        Write-Host "Alternative using auditpol.exe:"
        Write-Host "  auditpol /set /subcategory:`"$AUDITPOL_SUBCATEGORY`" /success:enable /failure:enable"
        Write-Host ""
        Write-Host "=============================================="
    }
} else {
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation skipped based on system type."
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
