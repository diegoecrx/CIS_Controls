###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark - Section 19 Scripts
# README for User Administrative Templates Configuration Scripts
###############################################################################

OVERVIEW
========
This package contains 12 PowerShell remediation scripts for CIS Microsoft Windows Server 2022 Benchmark Section 19.
These scripts configure User Configuration Administrative Templates (user-level policy settings).

Section 19 focuses on USER-LEVEL settings that affect the user experience, privacy, and security
for all users on the system.

IMPORTANT NOTE
==============
Section 19 settings are USER CONFIGURATION policies, not COMPUTER CONFIGURATION.

Key Differences:
- Computer policies (Section 18): Apply to the machine regardless of user
- User policies (Section 19): Apply to users logging into the machine

For enterprise environments, these settings should be deployed via Group Policy User Configuration
to ensure consistent application across all users and computers.

SCRIPTS INCLUDED
================

19.5.1.1 - Notifications (1 script)
------------------------------------
Turn off toast notifications on the lock screen

19.6.6.1.1 - Help Experience (1 script)
----------------------------------------
Turn off Help Experience Improvement Program (L2)

19.7.5.x - Attachments (2 scripts)
-----------------------------------
19.7.5.1 - Do not preserve zone information in file attachments
19.7.5.2 - Notify antivirus programs when opening attachments

19.7.8.x - Windows Spotlight (5 scripts)
-----------------------------------------
19.7.8.1 - Configure Windows spotlight on lock screen
19.7.8.2 - Do not suggest third-party content
19.7.8.3 - Do not use diagnostic data for tailored experiences (L2)
19.7.8.4 - Turn off all Windows spotlight features (L2)
19.7.8.5 - Turn off Spotlight collection on Desktop

19.7.26.1 - File Sharing (1 script)
------------------------------------
Prevent users from sharing files within their profile

19.7.44.1 - Windows Installer (1 script)
-----------------------------------------
Always install with elevated privileges (should be DISABLED)

19.7.46.2.1 - Windows Media Player (1 script)
----------------------------------------------
Prevent Codec Download (L2)

PROFILE APPLICABILITY
=====================
Most scripts apply to:
• Level 1 - Domain Controller
• Level 1 - Member Server

Some scripts are Level 2 (high security environments):
• 19.6.6.1.1 - Help Experience Improvement (L2)
• 19.7.8.3 - Diagnostic data (L2)
• 19.7.8.4 - Windows spotlight (L2)
• 19.7.46.2.1 - Codec download (L2)

USAGE
=====
All scripts must be run as Administrator.

Run individual script:
  PS> .\19.5.1.1.ps1

Run all notification scripts:
  PS> Get-ChildItem -Filter 19.5.*.ps1 | ForEach-Object { & $_.FullName }

Run all Windows Spotlight scripts:
  PS> Get-ChildItem -Filter 19.7.8.*.ps1 | ForEach-Object { & $_.FullName }

Run ALL user policy scripts:
  PS> Get-ChildItem -Filter 19.*.ps1 | Sort-Object Name | ForEach-Object { & $_.FullName }

WHAT THE SCRIPTS DO
===================
1. Attempt to configure user-level registry settings
2. Apply settings that affect all users on the system
3. Provide guidance for Group Policy deployment
4. Verify configuration where possible
5. Provide detailed status reporting

FEATURES
========
✓ User-level policy configuration
✓ Registry-based settings
✓ Guidance for Group Policy deployment
✓ Error handling with manual instructions
✓ Enterprise deployment recommendations

USER vs COMPUTER POLICIES
==========================

Computer Configuration (Section 18):
  - Applies to the machine
  - Affects all users
  - Takes precedence over user settings
  - Stored in: HKLM:\SOFTWARE\Policies\...

User Configuration (Section 19):
  - Applies to individual users
  - User-specific settings
  - Can be overridden by computer policies
  - Stored in: HKCU:\SOFTWARE\Policies\... (per user)

DEPLOYMENT CONSIDERATIONS
=========================

Local Script Execution:
  ✓ Quick remediation
  ✓ Immediate effect for logged-in user
  ✗ Must run for each user
  ✗ Not persistent for new users
  ✗ Difficult to manage at scale

Group Policy Deployment (RECOMMENDED):
  ✓ Centralized management
  ✓ Applies to all users automatically
  ✓ New users get settings automatically
  ✓ Easy to modify and rollback
  ✓ Reporting and monitoring
  ✓ Incremental deployment

For Enterprise: Use Group Policy
  User Configuration > Administrative Templates

CRITICAL SETTINGS
=================

Privacy & Security:
  19.7.5.1 - File attachment zone info (security marking)
  19.7.5.2 - Antivirus notification (malware protection)
  19.7.26.1 - Prevent file sharing from profile (data leakage)
  19.7.44.1 - Disable elevated installer (privilege escalation)

User Experience:
  19.5.1.1 - Lock screen notifications (information disclosure)
  19.7.8.x - Windows Spotlight (privacy, ads, data collection)

Data Collection:
  19.6.6.1.1 - Help Experience Improvement (telemetry)
  19.7.8.3 - Diagnostic data for experiences (privacy)

IMPACT ASSESSMENT
=================

User Experience Impact:
  ⚠️ Lock screen becomes less interactive
  ⚠️ Windows Spotlight features disabled (lock screen images, tips)
  ⚠️ Some convenience features disabled
  ⚠️ File sharing from profile prevented

Security Benefits:
  ✓ Reduced information disclosure on lock screen
  ✓ Better malware protection (antivirus notifications)
  ✓ Prevented privilege escalation via installers
  ✓ Reduced attack surface (file sharing)
  ✓ Enhanced privacy (less telemetry)

Recommended Pre-Deployment:
  1. Review settings with users/stakeholders
  2. Communicate changes
  3. Test in pilot group
  4. Monitor user feedback
  5. Adjust as needed

VERIFICATION
============

Check user registry settings:
  PS> Get-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\..." -Name "ValueName"

For all users (requires admin):
  PS> Get-ChildItem "C:\Users" | ForEach-Object {
      $userPath = Join-Path $_.FullName "NTUSER.DAT"
      if (Test-Path $userPath) {
          Write-Host "User: $($_.Name)"
          # Check user registry
      }
  }

Verify via Group Policy:
  PS> gpresult /user <username> /h userreport.html

Check currently logged-in user:
  PS> gpresult /r /scope:user

MANUAL CONFIGURATION
====================

Via Local Group Policy Editor:
  1. Open gpedit.msc
  2. Navigate to: User Configuration > Administrative Templates
  3. Find appropriate category:
     - Start Menu and Taskbar
     - Windows Components > Attachment Manager
     - Windows Components > Cloud Content
     - Windows Components > File Explorer
     - Windows Components > Windows Installer
     - Windows Components > Windows Media Player
  4. Configure each setting
  5. Log off and log back in (or gpupdate /force)

Via Domain Group Policy:
  1. Open Group Policy Management (gpmc.msc)
  2. Create or edit GPO
  3. Navigate to: User Configuration > Administrative Templates
  4. Configure settings
  5. Link GPO to appropriate OUs
  6. Wait for policy refresh or run: gpupdate /force

SETTINGS BREAKDOWN
==================

Lock Screen & Notifications:
  19.5.1.1 - Prevents notifications on lock screen
    Security: Prevents information disclosure to unauthorized viewers

File Attachments:
  19.7.5.1 - Keeps zone information (Internet, Intranet, etc.)
    Security: Maintains security warnings for downloaded files
  
  19.7.5.2 - Notifies antivirus when opening attachments
    Security: Enables real-time scanning of attachments

Windows Spotlight:
  19.7.8.1 - Disables spotlight on lock screen
  19.7.8.2 - Blocks third-party content suggestions
  19.7.8.3 - Prevents tailored experiences based on diagnostics
  19.7.8.4 - Turns off all spotlight features
  19.7.8.5 - Disables desktop spotlight collection
    Privacy: Reduces data collection and external content

File Sharing:
  19.7.26.1 - Prevents sharing files from user profile
    Security: Reduces data leakage risk

Windows Installer:
  19.7.44.1 - DISABLES always elevated installs
    Security: Critical! Prevents privilege escalation

Media Player:
  19.7.46.2.1 - Prevents codec download
    Security: Reduces malware risk from codec downloads

TROUBLESHOOTING
===============

Settings not applying:

1. Check user logged in:
   PS> whoami

2. Verify Group Policy application:
   PS> gpresult /r /scope:user

3. Force policy refresh:
   PS> gpupdate /force /target:user

4. Check for conflicts:
   PS> gpresult /h report.html
   # Review "Winning GPO" for each setting

5. Verify registry permissions:
   PS> $acl = Get-Acl "HKCU:\SOFTWARE\Policies"
   PS> $acl.Access

6. Log off and log back in:
   # Some user settings require logoff/logon

BACKUP AND RESTORE
==================

Backup user registry:
  # Current user
  reg export HKCU C:\backup\hkcu_before.reg

  # All users (admin required)
  reg export HKU C:\backup\hku_before.reg

Restore from backup:
  reg import C:\backup\hkcu_before.reg

Export specific user policy keys:
  reg export "HKCU\SOFTWARE\Policies" C:\backup\user_policies.reg

ROLLBACK
========

To undo changes:

Method 1 - Restore Registry:
  reg import C:\backup\hkcu_before.reg

Method 2 - Remove Registry Values:
  Remove-ItemProperty -Path "HKCU:\SOFTWARE\Policies\..." -Name "ValueName"

Method 3 - Group Policy Reset:
  1. Open gpedit.msc (User Configuration)
  2. Set policies to "Not Configured"
  3. gpupdate /force
  4. Log off and log back in

Method 4 - Delete User Policy Keys:
  PS> Remove-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\..." -Recurse

BEST PRACTICES
==============

1. Deploy via Group Policy:
   - Don't run scripts on each user
   - Use GPO for centralized management
   - Link to user OUs appropriately

2. Test with pilot users:
   - Select diverse user group
   - Gather feedback
   - Adjust settings as needed

3. Communicate changes:
   - Inform users of changes
   - Explain security benefits
   - Provide training if needed

4. Monitor and maintain:
   - Review settings quarterly
   - Update for new Windows features
   - Remove deprecated settings

5. Documentation:
   - Document GPO structure
   - Maintain setting inventory
   - Track changes over time

ENTERPRISE GPO STRUCTURE
========================

Recommended GPO organization:

CIS_User_L1_Baseline
  - Link to: All User OUs
  - Contains: All Level 1 user settings
  
CIS_User_L2_HighSecurity
  - Link to: High security user OUs
  - Contains: Level 2 user settings
  
CIS_User_Exceptions
  - Link to: Specific users/groups needing exceptions
  - Contains: Overrides for specific requirements

Link Order (highest to lowest precedence):
  1. CIS_User_Exceptions
  2. CIS_User_L2_HighSecurity
  3. CIS_User_L1_Baseline

COMPLIANCE
==========
These user settings help meet requirements for:
  - Privacy regulations (GDPR, CCPA)
  - Security standards (NIST, ISO 27001)
  - Industry compliance (PCI DSS, HIPAA)

USER IMPACT
===========

Minimal Impact Settings:
  ✓ 19.7.5.1 - File attachment zones (invisible to user)
  ✓ 19.7.5.2 - Antivirus notifications (security benefit)

Moderate Impact Settings:
  ⚠️ 19.5.1.1 - Lock screen notifications (less convenient)
  ⚠️ 19.7.8.x - Windows Spotlight (less visual interest)
  ⚠️ 19.7.26.1 - File sharing (may need alternative methods)

High Impact Settings:
  ⚠️⚠️ 19.7.44.1 - Elevated installs (GOOD - security critical)
  ⚠️⚠️ 19.7.46.2.1 - Codec download (may affect media playback)

TESTING CHECKLIST
=================
Before deployment, test:
  ☐ User logon/logoff
  ☐ Lock screen behavior
  ☐ File attachment handling
  ☐ Windows Spotlight features
  ☐ File sharing functionality
  ☐ Software installation
  ☐ Media file playback
  ☐ User notifications
  ☐ Help system functionality

SUPPORT
=======
For issues or questions, refer to:
  - CIS Microsoft Windows Server 2022 Benchmark v4.0.0
  - Microsoft Group Policy documentation
  - User Configuration Administrative Templates reference

ADDITIONAL RESOURCES
====================
- Group Policy Central: https://admx.help/
- User Configuration GPO reference
- Windows User Experience guidelines

IMPORTANT NOTES
===============
✓ Section 19 contains only 12 controls (small but important)
✓ Focus on user privacy and security
✓ Deploy via Group Policy for best results
✓ Test with pilot users before wide deployment
✓ Some settings may require user communication
✓ Level 2 settings are optional (high security environments)

Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
