
import pandas as pd

# Read the Excel file for section 19
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section19.xlsx', sheet_name='Recommendations')

# Display the dataframe overview
print("Total rows:", len(df))
print("\nColumns:", df.columns.tolist())
print("\n")
print("All controls:")
print(df[['script_name', 'control_name']].to_string(index=False))
