###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 19.6.6.1.1.ps1
# CIS Control - 19.6.6.1.1 (L2) Ensure 'Turn off Help Experience Improvement Program' is set to 'Enabled' (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 19.6.6.1.1

.DESCRIPTION
    This script configures User Administrative Template settings via registry
    per CIS 19.6.6.1.1 control for Windows Server 2022.

    Profile Applicability: 
    • Level 2 - Domain Controller
• Level 2 - Member Server

    Default value: Disabled. (Users can turn on the Help Experience Improvement program feature from
the Help and Support settings page.)

.NOTES
    Requires: Run as Administrator
    Uses: Direct Registry modification for User Administrative Templates

    NOTE: This is a USER-level setting that applies to all users on the system.
          Settings are typically stored in HKCU (per-user) or configured via
          Group Policy User Configuration to apply consistently.
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "19.6.6.1.1.ps1"
$CONTROL_NAME = "19.6.6.1.1 (L2) Ensure 'Turn off Help Experience Improvement Program' is set to 'Enabled' (Automated)"
$REG_PATH = "See remediation details"
$VALUE_NAME = "See remediation details"
$VALUE_TYPE = "REG_DWORD"
$RECOMMENDED_VALUE = "See remediation details"
$DEFAULT_VALUE = "Disabled. (Users can turn on the Help Experience Improvement program feature from
the Help and Support settings page.)"

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Configure User Administrative Template (Registry-based Policy)"
Write-Host ""
Write-Host "Profile Applicability: • Level 2 - Domain Controller
• Level 2 - Member Server"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host ""
Write-Host "NOTE: This control affects USER settings."
Write-Host "For complete coverage, this should be deployed via Group Policy"
Write-Host "User Configuration to affect all users consistently."
Write-Host ""

Write-Host "Remediation Details:"
Write-Host ""

try {
    Write-Host "[INFO] Registry Path: $REG_PATH"
    Write-Host "[INFO] Value Name: $VALUE_NAME"
    Write-Host "[INFO] Recommended Value: $RECOMMENDED_VALUE"
    Write-Host ""

    # Note: For user-level settings, we need to apply to all user profiles
    # This script applies to default user profile and current users

    # Apply to Default User Profile (affects new users)
    $defaultUserPath = "HKU:\.DEFAULT\Software\Policies\Microsoft\"

    # Load Default User Hive
    Write-Host "[INFO] Configuring Default User Profile (for new users)..."

    # For HKLM-based user policies (applies to all users)
    if ($REG_PATH -like "HKLM:*") {
        # Ensure registry path exists
        if (-not (Test-Path -Path $REG_PATH)) {
            Write-Host "[ACTION] Creating registry path: $REG_PATH"
            New-Item -Path $REG_PATH -Force | Out-Null
        }

        # Get current value if it exists
        try {
            $currentValue = Get-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -ErrorAction SilentlyContinue
            if ($currentValue) {
                Write-Host "[CURRENT] Current value: $($currentValue.$VALUE_NAME)"
            } else {
                Write-Host "[CURRENT] Value does not exist (will be created)"
            }
        } catch {
            Write-Host "[CURRENT] Value does not exist (will be created)"
        }

        # Set the registry value
        Write-Host ""
        Write-Host "[ACTION] Applying CIS recommended configuration..."

        if ($VALUE_TYPE -eq "REG_DWORD") {
            Set-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -Value ([int]$RECOMMENDED_VALUE) -Type DWord -Force
        }
        elseif ($VALUE_TYPE -eq "REG_SZ") {
            Set-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -Value $RECOMMENDED_VALUE -Type String -Force
        }
        else {
            Set-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -Value $RECOMMENDED_VALUE -Force
        }

        # Verify the configuration
        $verifyValue = Get-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -ErrorAction Stop
        Write-Host "[VERIFICATION] Updated value: $($verifyValue.$VALUE_NAME)"
        Write-Host ""

        Write-Host "[SUCCESS] Configuration applied successfully"
    } else {
        Write-Host "[INFO] This setting requires Group Policy User Configuration for full deployment"
        Write-Host "[INFO] Manual configuration via gpedit.msc recommended"
    }

    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation Summary:"
    Write-Host "- Control: 19.6.6.1.1"
    Write-Host "- Status: COMPLETED"
    Write-Host "- Type: User Administrative Template"
    Write-Host "- Setting: $VALUE_NAME = $RECOMMENDED_VALUE"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "IMPORTANT: For enterprise deployment, configure via Group Policy:"
    Write-Host "  User Configuration > Administrative Templates"
    Write-Host ""

} catch {
    Write-Host ""
    Write-Host "[ERROR] Failed to apply remediation automatically."
    Write-Host "Error details: $_"
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "MANUAL REMEDIATION REQUIRED"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Please configure manually via Group Policy Editor:"
    Write-Host ""
    Write-Host "1. Open Group Policy Editor (gpedit.msc)"
    Write-Host "2. Navigate to: User Configuration > Administrative Templates"
    Write-Host "3. Locate the policy for control 19.6.6.1.1"
    Write-Host "4. Configure according to CIS Benchmark recommendations"
    Write-Host "5. Run 'gpupdate /force' to apply changes"
    Write-Host ""
    Write-Host "For Domain environments:"
    Write-Host "1. Open Group Policy Management (gpmc.msc)"
    Write-Host "2. Create or edit a GPO"
    Write-Host "3. Navigate to: User Configuration > Administrative Templates"
    Write-Host "4. Configure the setting"
    Write-Host "5. Link GPO to appropriate OUs"
    Write-Host ""
    Write-Host "Alternative using Registry (affects current user only):"
    Write-Host "  Path: $REG_PATH"
    Write-Host "  Value Name: $VALUE_NAME"
    Write-Host "  Value: $RECOMMENDED_VALUE"
    Write-Host ""
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
