###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark - Section 5 Scripts
# README for Print Spooler Service Remediation
###############################################################################

OVERVIEW
========
This package contains 2 PowerShell remediation scripts for CIS Microsoft Windows Server 2022 Benchmark Section 5.
Both scripts disable the Print Spooler service to mitigate security risks.

SCRIPTS INCLUDED
================

5.1.ps1 - Domain Controller Configuration (Level 1)
  - Control: 5.1 (L1) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (DC only)
  - Applies to: Domain Controllers only
  - Automatically detects if running on a DC

5.2.ps1 - Member Server Configuration (Level 2)
  - Control: 5.2 (L2) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (MS only)
  - Applies to: Member Servers only
  - Automatically detects if running on a Member Server

SECURITY CONTEXT
=================
The Print Spooler service has been identified as a security risk, particularly on Domain Controllers.
Several critical vulnerabilities (including PrintNightmare) have targeted this service.

CIS Recommendation:
  - Disable Print Spooler on Domain Controllers (L1 - all environments)
  - Disable Print Spooler on Member Servers (L2 - high security environments)

USAGE
=====
All scripts must be run as Administrator.

Run on Domain Controller:
  PS> .\5.1.ps1

Run on Member Server:
  PS> .\5.2.ps1

The scripts automatically detect the system type and will skip execution if not applicable.

WHAT THE SCRIPTS DO
===================
1. Detect system type (Domain Controller or Member Server)
2. Verify the control applies to the current system
3. Check current Print Spooler service status
4. Stop the Print Spooler service if running
5. Set the Print Spooler service startup type to 'Disabled'
6. Verify the configuration change
7. Provide detailed status reporting

FEATURES
========
✓ #Requires -RunAsAdministrator directive
✓ Automatic system type detection
✓ Graceful skipping if control doesn't apply
✓ Safe service stopping before disabling
✓ Comprehensive error handling
✓ Manual remediation guidance on failure
✓ Clear success/failure reporting
✓ Alternative remediation methods included

IMPACT ASSESSMENT
=================
Before running these scripts, ensure:

⚠️ CRITICAL: The target server does NOT act as a print server
⚠️ No applications depend on local printing capabilities
⚠️ Users do not print directly from this server

If the server is used for printing:
  - Consider deploying a dedicated print server
  - Migrate print queues before running remediation
  - Communicate changes to end users

ROLLBACK
========
If you need to re-enable the Print Spooler service:

PowerShell:
  Set-Service -Name Spooler -StartupType Automatic
  Start-Service -Name Spooler

Command Prompt (as Administrator):
  sc config Spooler start= auto
  net start Spooler

Group Policy:
  Computer Configuration > Policies > Windows Settings > Security Settings > System Services > Print Spooler
  Set to: Automatic (or leave undefined)

VERIFICATION
============
To verify the Print Spooler is disabled:

PowerShell:
  Get-Service -Name Spooler | Select-Object Name, Status, StartType

Expected output:
  Name    Status  StartType
  ----    ------  ---------
  Spooler Stopped Disabled

Command Prompt:
  sc query Spooler

ALTERNATIVE METHODS
===================
If PowerShell scripts cannot be used:

Method 1 - Group Policy:
  1. Open gpedit.msc
  2. Navigate to: Computer Configuration > Policies > Windows Settings > Security Settings > System Services
  3. Double-click "Print Spooler"
  4. Check "Define this policy setting"
  5. Select "Disabled"
  6. Run: gpupdate /force

Method 2 - Command Line:
  sc config Spooler start= disabled
  net stop Spooler

Method 3 - Services MMC:
  1. Run: services.msc
  2. Find "Print Spooler"
  3. Right-click > Properties
  4. Set Startup type to "Disabled"
  5. Click Stop
  6. Click OK

TESTING
=======
Test in a non-production environment first.
Verify no critical applications break after disabling the service.

SUPPORT
=======
For issues or questions, refer to:
  - CIS Microsoft Windows Server 2022 Benchmark v4.0.0
  - Microsoft Security Advisory for Print Spooler vulnerabilities

ADDITIONAL RESOURCES
====================
- Microsoft PrintNightmare guidance: https://msrc.microsoft.com/update-guide/vulnerability/CVE-2021-34527
- CIS Benchmarks: https://www.cisecurity.org/cis-benchmarks

Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
