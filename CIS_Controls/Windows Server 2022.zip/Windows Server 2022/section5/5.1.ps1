###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 5.1.ps1
# CIS Control - 5.1 (L1) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (DC only) (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 5.1

.DESCRIPTION
    This script ensures that 'Print Spooler (Spooler)' service is set to 'Disabled' 
    per CIS 5.1 control for Windows Server 2022.

    Profile Applicability: 
    • Level 1 - Domain Controller

    Default value: Automatic

.NOTES
    Requires: Run as Administrator
    Uses: PowerShell Service Management cmdlets

    Remediation Path: Computer Configuration\Policies\Windows Settings\Security Settings\System Services\Print Spooler
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "5.1.ps1"
$CONTROL_NAME = "5.1 (L1) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (DC only) (Automated)"
$SERVICE_NAME = "Spooler"
$SERVICE_DISPLAY_NAME = "Print Spooler"
$RECOMMENDED_STATUS = "Disabled"
$DEFAULT_VALUE = "Automatic"

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Print Spooler (Spooler)' service is set to 'Disabled' (Automated)"
Write-Host ""
Write-Host "Profile: • Level 1 - Domain Controller"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host "Recommended value: $RECOMMENDED_STATUS"
Write-Host ""

# Determine if this is a Domain Controller or Member Server
$isDomainController = $false
$computerInfo = Get-WmiObject -Class Win32_ComputerSystem

if ($computerInfo.DomainRole -eq 4 -or $computerInfo.DomainRole -eq 5) {
    $isDomainController = $true
}

Write-Host "Remediation Details:"
Write-Host ""

# Check if this script should run on this system type
$shouldRun = $true
if ("True" -eq "True" -and -not $isDomainController) {
    Write-Host "[INFO] This control is for Domain Controllers only."
    Write-Host "[INFO] Current system is a Member Server. Skipping remediation."
    $shouldRun = $false
}

if ("False" -eq "True" -and $isDomainController) {
    Write-Host "[INFO] This control is for Member Servers only."
    Write-Host "[INFO] Current system is a Domain Controller. Skipping remediation."
    $shouldRun = $false
}

if ($shouldRun) {
    try {
        # Check if service exists
        $service = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue

        if ($service) {
            Write-Host "[INFO] Current status of $SERVICE_DISPLAY_NAME service:"
            Write-Host "  - Status: $($service.Status)"
            Write-Host "  - StartType: $($service.StartType)"
            Write-Host ""

            # Stop the service if it's running
            if ($service.Status -eq 'Running') {
                Write-Host "[ACTION] Stopping $SERVICE_DISPLAY_NAME service..."
                Stop-Service -Name $SERVICE_NAME -Force -ErrorAction Stop
                Write-Host "[SUCCESS] Service stopped successfully"
            }

            # Disable the service
            Write-Host "[ACTION] Setting $SERVICE_DISPLAY_NAME service to Disabled..."
            Set-Service -Name $SERVICE_NAME -StartupType Disabled -ErrorAction Stop

            # Verify the change
            $serviceAfter = Get-Service -Name $SERVICE_NAME
            Write-Host ""
            Write-Host "[VERIFICATION] Updated service configuration:"
            Write-Host "  - Status: $($serviceAfter.Status)"
            Write-Host "  - StartType: $($serviceAfter.StartType)"
            Write-Host ""

            if ($serviceAfter.StartType -eq 'Disabled') {
                Write-Host "[SUCCESS] $SERVICE_DISPLAY_NAME service has been disabled successfully"
            } else {
                Write-Host "[WARNING] Service may not be fully disabled. Manual verification recommended."
            }

        } else {
            Write-Host "[INFO] $SERVICE_DISPLAY_NAME service not found on this system."
            Write-Host "[INFO] This may be expected if the Print Server role is not installed."
        }

        Write-Host ""
        Write-Host "=============================================="
        Write-Host "Remediation Summary:"
        Write-Host "- Control: 5.1"
        Write-Host "- Status: COMPLETED"
        Write-Host "- Service: $SERVICE_DISPLAY_NAME"
        Write-Host "- Configuration: Disabled"
        Write-Host "=============================================="

    } catch {
        Write-Host ""
        Write-Host "[ERROR] Failed to apply remediation automatically."
        Write-Host "Error details: $_"
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "MANUAL REMEDIATION REQUIRED"
        Write-Host "=============================================="
        Write-Host ""
        Write-Host "Please configure manually via Group Policy Editor (gpedit.msc):"
        Write-Host ""
        Write-Host "Path: Computer Configuration > Policies > Windows Settings > Security Settings > System Services > Print Spooler"
        Write-Host "Value to set: Disabled"
        Write-Host ""
        Write-Host "Steps:"
        Write-Host "1. Open Local Group Policy Editor (gpedit.msc)"
        Write-Host "2. Navigate to: Computer Configuration > Policies > Windows Settings > Security Settings > System Services"
        Write-Host "3. Double-click 'Print Spooler'"
        Write-Host "4. Check 'Define this policy setting'"
        Write-Host "5. Select 'Disabled'"
        Write-Host "6. Click OK and close the editor"
        Write-Host "7. Run 'gpupdate /force' to apply changes"
        Write-Host ""
        Write-Host "Alternative using PowerShell:"
        Write-Host "  Set-Service -Name Spooler -StartupType Disabled"
        Write-Host "  Stop-Service -Name Spooler -Force"
        Write-Host ""
        Write-Host "Alternative using Command Prompt (as Administrator):"
        Write-Host "  sc config Spooler start= disabled"
        Write-Host "  net stop Spooler"
        Write-Host ""
        Write-Host "=============================================="
    }
} else {
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation skipped based on system type."
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
