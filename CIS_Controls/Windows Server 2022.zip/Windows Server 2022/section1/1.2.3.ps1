###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 1.2.3.ps1
# CIS Control - 1.2.3 (L1) Ensure 'Allow Administrator account lockout' is set to 'Enabled' (MS only) (Manual)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Manual remediation for CIS Control 1.2.3

.DESCRIPTION
    This script provides guidance for manual configuration of 'Allow Administrator account lockout' to 'Enabled'
    per CIS 1.2.3 control for Windows Server 2022.
    
    Profile Applicability: 
    - Level 1 - Member Server
    
    Default value: Disabled. (The built-in Administrator account is not subject to the account lockout policy.)
    
    NOTE: This is a MANUAL remediation. User interaction is required.

.NOTES
    Requires: Run as Administrator
    
    Remediation Path: Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policies\Allow Administrator account lockout
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "1.2.3.ps1"
$CONTROL_NAME = "1.2.3 (L1) Ensure 'Allow Administrator account lockout' is set to 'Enabled' (MS only) (Manual)"
$CONFIG_FILE = "Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policies\Allow Administrator account lockout"
$PROFILE_MS = "Level 1 - Member Server"
$DEFAULT_VALUE = "Disabled. (The built-in Administrator account is not subject to the account lockout policy.)"
$RECOMMENDED_VALUE = "Enabled"

# User interaction for manual remediation
function Show-ManualRemediationMenu {
    Write-Host ""
    Write-Host ""
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Manual Remediation: $SCRIPT_NAME"
    Write-Host "$CONTROL_NAME"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Description:"
    Write-Host "Ensure 'Allow Administrator account lockout' is set to 'Enabled' (MS only) (Manual)"
    Write-Host ""
    Write-Host "Configuration file: $CONFIG_FILE"
    Write-Host "Profile Member Server: $PROFILE_MS"
    Write-Host "Default value: $DEFAULT_VALUE"
    Write-Host ""
    Write-Host "Please choose an option:"
    Write-Host "1) Execute/Force the remediation (will create backup)"
    Write-Host "2) Show remediation commands only (no execution)"
    Write-Host "3) Exit"
    Write-Host ""
    
    $choice = Read-Host "Enter your choice [1-3]"
    
    return $choice
}

$userChoice = Show-ManualRemediationMenu

switch ($userChoice) {
    "1" {
        Write-Host ""
        Write-Host "Attempting automated remediation..."
        Write-Host ""
        
        try {
            # Member Server - Use secedit.exe
            Write-Host "Applying remediation via Local Security Policy (secedit.exe)..."
            Write-Host ""
            
            # Export current security policy
            $backupFile = "$env:TEMP\secedit_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').cfg"
            
            secedit /export /cfg $backupFile /quiet
            Write-Host "[BACKUP] Current security policy exported to: $backupFile"
            
            # Create temporary security template
            $tempFile = [System.IO.Path]::GetTempFileName()
            $secTemplate = @"
[Unicode]
Unicode=yes
[System Access]
AllowAdministratorLockout = 1
[Version]
signature="`$CHICAGO`$"
Revision=1
"@
            
            $secTemplate | Out-File -FilePath $tempFile -Encoding unicode -Force
            
            # Apply the security template
            secedit /configure /db secedit.sdb /cfg $tempFile /quiet
            
            # Refresh Group Policy
            gpupdate /force | Out-Null
            
            Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
            
            Write-Host "[SUCCESS] 'Allow Administrator account lockout' set to 'Enabled' via Local Security Policy"
            Write-Host "[INFO] Group Policy has been refreshed"
            Write-Host ""
            
            Write-Host "=============================================="
            Write-Host "Remediation Summary:"
            Write-Host "- Control: 1.2.3"
            Write-Host "- Status: COMPLETED"
            Write-Host "- Allow Administrator Account Lockout: Enabled"
            Write-Host "=============================================="
            
        } catch {
            Write-Host ""
            Write-Host "[ERROR] Failed to apply remediation automatically."
            Write-Host "Error details: $_"
            Write-Host ""
            Write-Host "Please proceed with manual configuration using the Group Policy Editor."
            Write-Host ""
        }
    }
    
    "2" {
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "Remediation Commands (No Execution):"
        Write-Host "=============================================="
        Write-Host ""
        Write-Host "To manually configure this setting:"
        Write-Host ""
        Write-Host "Path: $CONFIG_FILE"
        Write-Host "Value to set: $RECOMMENDED_VALUE"
        Write-Host ""
        Write-Host "Steps:"
        Write-Host "1. Open Local Group Policy Editor (gpedit.msc)"
        Write-Host "2. Navigate to: Computer Configuration > Windows Settings > Security Settings > Account Policies > Account Lockout Policy"
        Write-Host "3. Double-click 'Allow Administrator account lockout'"
        Write-Host "4. Set to 'Enabled'"
        Write-Host "5. Click OK and close the editor"
        Write-Host "6. Run 'gpupdate /force' to apply changes"
        Write-Host ""
        Write-Host "Alternative using secedit:"
        Write-Host "  secedit /export /cfg C:\temp\current_policy.cfg"
        Write-Host "  Edit the file and set: AllowAdministratorLockout = 1"
        Write-Host "  secedit /configure /db secedit.sdb /cfg C:\temp\current_policy.cfg"
        Write-Host "  gpupdate /force"
        Write-Host ""
        Write-Host "=============================================="
    }
    
    "3" {
        Write-Host ""
        Write-Host "Exiting without making changes."
        Write-Host ""
    }
    
    default {
        Write-Host ""
        Write-Host "Invalid choice. Exiting."
        Write-Host ""
    }
}

Write-Host ""
Write-Host ""
Write-Host ""
