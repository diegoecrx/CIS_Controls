###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 1.2.4.ps1
# CIS Control - 1.2.4 (L1) Ensure 'Reset account lockout counter after' is set to '15 or more minute(s)' (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 1.2.4

.DESCRIPTION
    This script ensures that 'Reset account lockout counter after' is set to '15 or more minute(s)' 
    per CIS 1.2.4 control for Windows Server 2022.
    
    Profile Applicability: 
    - Level 1 - Domain Controller
    - Level 1 - Member Server
    
    Default value: None, because this policy setting only has meaning when an Account lockout threshold is specified. 
                   When an Account lockout threshold is configured, Windows automatically suggests a value of 30 minutes.

.NOTES
    Requires: Run as Administrator
    Uses: PowerShell ActiveDirectory module for Domain Controllers
          secedit.exe for Member Servers/Stand-alone systems
    
    Remediation Path: Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Reset account lockout counter after
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "1.2.4.ps1"
$CONTROL_NAME = "1.2.4 (L1) Ensure 'Reset account lockout counter after' is set to '15 or more minute(s)' (Automated)"
$CONFIG_FILE = "Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Reset account lockout counter after"
$PROFILE_DC = "Level 1 - Domain Controller"
$PROFILE_MS = "Level 1 - Member Server"
$DEFAULT_VALUE = "None, because this policy setting only has meaning when an Account lockout threshold is specified. When an Account lockout threshold is configured, Windows automatically suggests a value of 30 minutes."
$RECOMMENDED_VALUE = 15

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Reset account lockout counter after' is set to '15 or more minute(s)' (Automated)"
Write-Host ""
Write-Host "Configuration file: $CONFIG_FILE"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host ""

# Determine if this is a Domain Controller or Member Server
$isDomainController = $false
$computerInfo = Get-WmiObject -Class Win32_ComputerSystem

if ($computerInfo.DomainRole -eq 4 -or $computerInfo.DomainRole -eq 5) {
    $isDomainController = $true
}

Write-Host "Remediation Details:"
Write-Host ""

try {
    if ($isDomainController) {
        # Domain Controller - Use Active Directory module
        Write-Host "Detected: Domain Controller"
        Write-Host "Applying remediation via Active Directory Default Domain Password Policy..."
        Write-Host ""
        
        Import-Module ActiveDirectory -ErrorAction Stop
        
        $domain = (Get-ADDomain).DistinguishedName
        Set-ADDefaultDomainPasswordPolicy -Identity $domain -LockoutObservationWindow (New-TimeSpan -Minutes $RECOMMENDED_VALUE) -ErrorAction Stop
        
        Write-Host "[SUCCESS] Reset account lockout counter set to $RECOMMENDED_VALUE minute(s) for domain: $domain"
        Write-Host ""
        
    } else {
        # Member Server or Stand-alone - Use secedit.exe
        Write-Host "Detected: Member Server or Stand-alone"
        Write-Host "Applying remediation via Local Security Policy (secedit.exe)..."
        Write-Host ""
        
        # Export current security policy
        $backupFile = "$env:TEMP\secedit_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').cfg"
        
        secedit /export /cfg $backupFile /quiet
        Write-Host "[BACKUP] Current security policy exported to: $backupFile"
        
        # Create temporary security template
        $tempFile = [System.IO.Path]::GetTempFileName()
        $secTemplate = @"
[Unicode]
Unicode=yes
[System Access]
ResetLockoutCount = $RECOMMENDED_VALUE
[Version]
signature="`$CHICAGO`$"
Revision=1
"@
        
        $secTemplate | Out-File -FilePath $tempFile -Encoding unicode -Force
        
        # Apply the security template
        secedit /configure /db secedit.sdb /cfg $tempFile /quiet
        
        # Refresh Group Policy
        gpupdate /force | Out-Null
        
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        
        Write-Host "[SUCCESS] Reset account lockout counter set to $RECOMMENDED_VALUE minute(s) via Local Security Policy"
        Write-Host "[INFO] Group Policy has been refreshed"
        Write-Host ""
    }
    
    Write-Host "=============================================="
    Write-Host "Remediation Summary:"
    Write-Host "- Control: 1.2.4"
    Write-Host "- Status: COMPLETED"
    Write-Host "- Reset Account Lockout Counter After: Set to $RECOMMENDED_VALUE minute(s)"
    Write-Host "=============================================="
    
} catch {
    Write-Host ""
    Write-Host "[ERROR] Failed to apply remediation automatically."
    Write-Host "Error details: $_"
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "MANUAL REMEDIATION REQUIRED"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Please configure manually via Group Policy Editor (gpedit.msc):"
    Write-Host ""
    Write-Host "Path: $CONFIG_FILE"
    Write-Host "Value to set: $RECOMMENDED_VALUE or more minute(s)"
    Write-Host ""
    Write-Host "Steps:"
    Write-Host "1. Open Local Group Policy Editor (gpedit.msc)"
    Write-Host "2. Navigate to: Computer Configuration > Windows Settings > Security Settings > Account Policies > Account Lockout Policy"
    Write-Host "3. Double-click 'Reset account lockout counter after'"
    Write-Host "4. Set to '$RECOMMENDED_VALUE minutes' or more"
    Write-Host "5. Click OK and close the editor"
    Write-Host "6. Run 'gpupdate /force' to apply changes"
    Write-Host ""
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
