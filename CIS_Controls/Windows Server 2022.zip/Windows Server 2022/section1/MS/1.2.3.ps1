# 1.2.3.ps1
(& {
  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $after = 1  # 1 = Enabled
  
  if ($role -notin 4, 5) {
    $tempPath = $env:TEMP
    $beforeInf = Join-Path $tempPath 'before_policy.inf'
    $afterInf = Join-Path $tempPath 'adminlockout.inf'
    
    secedit /export /cfg $beforeInf /areas SECURITYPOLICY /quiet | Out-Null
    $beforeLine = Select-String -Path $beforeInf -Pattern '^AllowAdministratorLockout\s*=\s*(\d+)' | Select-Object -First 1
    $current = if ($beforeLine) { [int]$beforeLine.Matches[0].Groups[1].Value } else { 0 }
    
    Set-Content -Path $afterInf -Encoding ascii -Value @(
      '[Unicode]',
      'Unicode=yes',
      '[System Access]',
      "AllowAdministratorLockout = $after",
      '[Version]',
      'signature="$CHICAGO$"',
      'Revision=1'
    )
    
    secedit /configure /db "$tempPath\secedit.sdb" /cfg $afterInf /areas SECURITYPOLICY /quiet | Out-Null
    
    Write-Output "Control: 1.2.3 (L1) Ensure 'Allow Administrator account lockout' is set to 'Enabled' (MS only) (Manual)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policies\Allow Administrator account lockout"
    Write-Output "Name: AllowAdministratorLockout"
    Write-Output "Current: $current"
    Write-Output "After: $after"
    
    Remove-Item $beforeInf, $afterInf -Force -ErrorAction SilentlyContinue
  } else {
    Write-Output "Control: 1.2.3 (L1) Ensure 'Allow Administrator account lockout' is set to 'Enabled' (MS only) (Manual)"
    Write-Output "Note: This setting applies to Member Servers only, not Domain Controllers"
  }
})
