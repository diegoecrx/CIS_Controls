###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 1.1.6.ps1
# CIS Control - 1.1.6 (L1) Ensure 'Relax minimum password length limits' is set to 'Enabled' (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 1.1.6

.DESCRIPTION
    This script ensures that 'Relax minimum password length limits' is set to 'Enabled' 
    per CIS 1.1.6 control for Windows Server 2022.
    
    Profile Applicability: 
    - Level 1 - Member Server
    
    Default value: Disabled. (The Minimum password length may be configured to a maximum of 14 characters.)
    
    NOTE: This setting is only available within the built-in OS security template of Windows 10 Release 2004 
    and Server 2022 (or newer).

.NOTES
    Requires: Run as Administrator
    Uses: secedit.exe for Member Servers/Stand-alone systems
    
    Remediation Path: Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Password Policy\Relax minimum password length limits
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "1.1.6.ps1"
$CONTROL_NAME = "1.1.6 (L1) Ensure 'Relax minimum password length limits' is set to 'Enabled' (Automated)"
$CONFIG_FILE = "Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Password Policy\Relax minimum password length limits"
$PROFILE_MS = "Level 1 - Member Server"
$DEFAULT_VALUE = "Disabled. (The Minimum password length may be configured to a maximum of 14 characters.)"
$RECOMMENDED_VALUE = 1  # 1 = Enabled

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Relax minimum password length limits' is set to 'Enabled' (Automated)"
Write-Host ""
Write-Host "Configuration file: $CONFIG_FILE"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host ""
Write-Host "NOTE: This setting is only available in Windows 10 Release 2004 and Server 2022 (or newer)."
Write-Host ""

# Check Windows version
$osInfo = Get-WmiObject -Class Win32_OperatingSystem
$osVersion = [System.Environment]::OSVersion.Version

Write-Host "Remediation Details:"
Write-Host ""

try {
    # Member Server or Stand-alone - Use secedit.exe
    Write-Host "Detected OS: $($osInfo.Caption) - Build $($osInfo.BuildNumber)"
    Write-Host "Applying remediation via Local Security Policy (secedit.exe)..."
    Write-Host ""
    
    # Export current security policy
    $backupFile = "$env:TEMP\secedit_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').cfg"
    
    secedit /export /cfg $backupFile /quiet
    Write-Host "[BACKUP] Current security policy exported to: $backupFile"
    
    # Create temporary security template
    $tempFile = [System.IO.Path]::GetTempFileName()
    $secTemplate = @"
[Unicode]
Unicode=yes
[System Access]
RelaxMinimumPasswordLengthLimits = $RECOMMENDED_VALUE
[Version]
signature="`$CHICAGO`$"
Revision=1
"@
    
    $secTemplate | Out-File -FilePath $tempFile -Encoding unicode -Force
    
    # Apply the security template
    secedit /configure /db secedit.sdb /cfg $tempFile /quiet
    
    # Refresh Group Policy
    gpupdate /force | Out-Null
    
    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    
    Write-Host "[SUCCESS] 'Relax minimum password length limits' set to 'Enabled' via Local Security Policy"
    Write-Host "[INFO] Group Policy has been refreshed"
    Write-Host "[INFO] This allows passwords longer than 14 characters"
    Write-Host ""
    
    Write-Host "=============================================="
    Write-Host "Remediation Summary:"
    Write-Host "- Control: 1.1.6"
    Write-Host "- Status: COMPLETED"
    Write-Host "- Relax Minimum Password Length Limits: Enabled"
    Write-Host "=============================================="
    
} catch {
    Write-Host ""
    Write-Host "[ERROR] Failed to apply remediation automatically."
    Write-Host "Error details: $_"
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "MANUAL REMEDIATION REQUIRED"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Please configure manually via Group Policy Editor (gpedit.msc):"
    Write-Host ""
    Write-Host "Path: $CONFIG_FILE"
    Write-Host "Value to set: Enabled"
    Write-Host ""
    Write-Host "Steps:"
    Write-Host "1. Open Local Group Policy Editor (gpedit.msc) on Windows Server 2022 or newer"
    Write-Host "2. Navigate to: Computer Configuration > Windows Settings > Security Settings > Account Policies > Password Policy"
    Write-Host "3. Double-click 'Relax minimum password length limits'"
    Write-Host "4. Set to 'Enabled'"
    Write-Host "5. Click OK and close the editor"
    Write-Host "6. Run 'gpupdate /force' to apply changes"
    Write-Host ""
    Write-Host "IMPORTANT: This setting is only available in Windows 10 Release 2004 and Server 2022 (or newer)."
    Write-Host "If you cannot find this setting, ensure you are using the correct OS version."
    Write-Host ""
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
