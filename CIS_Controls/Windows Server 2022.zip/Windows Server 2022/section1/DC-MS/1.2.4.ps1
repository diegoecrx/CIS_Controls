# 1.2.4.ps1
(& {
  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $after = 15
  
  if ($role -in 4, 5) {
    Import-Module ActiveDirectory -ErrorAction Stop
    $currentPolicy = Get-ADDefaultDomainPasswordPolicy
    $current = $currentPolicy.LockoutObservationWindow.Minutes
    Set-ADDefaultDomainPasswordPolicy -Identity $currentPolicy.DistinguishedName -LockoutObservationWindow (New-TimeSpan -Minutes $after)
    
    Write-Output "Control: 1.2.4 (L1) Ensure 'Reset account lockout counter after' is set to '15 or more minute(s)' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Reset account lockout counter after"
    Write-Output "Name: ResetLockoutCount"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  } else {
    $tempPath = $env:TEMP
    $beforeInf = Join-Path $tempPath 'before_policy.inf'
    $afterInf = Join-Path $tempPath 'resetlockout.inf'
    
    secedit /export /cfg $beforeInf /areas SECURITYPOLICY /quiet | Out-Null
    $beforeLine = Select-String -Path $beforeInf -Pattern '^ResetLockoutCount\s*=\s*(\d+)' | Select-Object -First 1
    $current = if ($beforeLine) { [int]$beforeLine.Matches[0].Groups[1].Value } else { 0 }
    
    Set-Content -Path $afterInf -Encoding ascii -Value @(
      '[Unicode]',
      'Unicode=yes',
      '[System Access]',
      "ResetLockoutCount = $after",
      '[Version]',
      'signature="$CHICAGO$"',
      'Revision=1'
    )
    
    secedit /configure /db "$tempPath\secedit.sdb" /cfg $afterInf /areas SECURITYPOLICY /quiet | Out-Null
    
    Write-Output "Control: 1.2.4 (L1) Ensure 'Reset account lockout counter after' is set to '15 or more minute(s)' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Reset account lockout counter after"
    Write-Output "Name: ResetLockoutCount"
    Write-Output "Current: $current"
    Write-Output "After: $after"
    
    Remove-Item $beforeInf, $afterInf -Force -ErrorAction SilentlyContinue
  }
})
