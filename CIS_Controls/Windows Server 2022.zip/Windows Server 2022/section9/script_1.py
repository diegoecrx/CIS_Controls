
import pandas as pd

# Read the Excel file for section 9
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section9.xlsx', sheet_name='Recommendations')

# Display all control names
print("Section 9 - All Controls\n")
print("="*80)
print(f"Total scripts to generate: {len(df)}\n")

for idx in range(len(df)):
    print(f"{df.loc[idx, 'script_name']:8} - {df.loc[idx, 'control_name']}")

# Show sample details for first control
print("\n" + "="*80)
print("Sample Details for First Control:\n")
idx = 0
print(f"Script Name: {df.loc[idx, 'script_name']}")
print(f"Control Name: {df.loc[idx, 'control_name']}")
print(f"Profile: {df.loc[idx, 'profile_applicability']}")
print(f"Remediation: {df.loc[idx, 'remediation'][:300]}...")
print(f"Default Value: {df.loc[idx, 'default_value']}")
