###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark - Section 9 Scripts
# README for Windows Firewall Configuration Scripts
###############################################################################

OVERVIEW
========
This package contains 23 PowerShell remediation scripts for CIS Microsoft Windows Server 2022 Benchmark Section 9.
All scripts configure Windows Defender Firewall with Advanced Security settings across three profiles:
- Domain Profile (9.1.x) - 7 scripts
- Private Profile (9.2.x) - 7 scripts  
- Public Profile (9.3.x) - 9 scripts

SCRIPTS BREAKDOWN
=================

DOMAIN PROFILE SCRIPTS (9.1.x)
-------------------------------
9.1.1 - Enable Domain Firewall state
9.1.2 - Block inbound connections (Domain)
9.1.3 - Disable notifications (Domain)
9.1.4 - Configure log file path (domainfw.log)
9.1.5 - Set log size limit to 16,384 KB
9.1.6 - Enable logging of dropped packets
9.1.7 - Enable logging of successful connections

PRIVATE PROFILE SCRIPTS (9.2.x)
--------------------------------
9.2.1 - Enable Private Firewall state
9.2.2 - Block inbound connections (Private)
9.2.3 - Disable notifications (Private)
9.2.4 - Configure log file path (privatefw.log)
9.2.5 - Set log size limit to 16,384 KB
9.2.6 - Enable logging of dropped packets
9.2.7 - Enable logging of successful connections

PUBLIC PROFILE SCRIPTS (9.3.x)
-------------------------------
9.3.1 - Enable Public Firewall state
9.3.2 - Block inbound connections (Public)
9.3.3 - Disable notifications (Public)
9.3.4 - Disable local firewall rules (Public)
9.3.5 - Disable local connection security rules (Public)
9.3.6 - Configure log file path (publicfw.log)
9.3.7 - Set log size limit to 16,384 KB
9.3.8 - Enable logging of dropped packets
9.3.9 - Enable logging of successful connections

PROFILE APPLICABILITY
=====================
All scripts apply to:
• Level 1 - Domain Controller
• Level 1 - Member Server

These are foundational security controls required for all environments.

USAGE
=====
All scripts must be run as Administrator.

Run individual script:
  PS> .\9.1.1.ps1

Run all Domain profile scripts:
  PS> Get-ChildItem -Filter 9.1.*.ps1 | ForEach-Object { & $_.FullName }

Run all Private profile scripts:
  PS> Get-ChildItem -Filter 9.2.*.ps1 | ForEach-Object { & $_.FullName }

Run all Public profile scripts:
  PS> Get-ChildItem -Filter 9.3.*.ps1 | ForEach-Object { & $_.FullName }

Run ALL firewall scripts:
  PS> Get-ChildItem -Filter 9.*.ps1 | ForEach-Object { & $_.FullName }

WHAT THE SCRIPTS DO
===================
1. Import NetSecurity PowerShell module
2. Get current Windows Firewall profile configuration
3. Apply CIS-recommended security settings
4. Verify configuration changes
5. Create log directories if needed (for logging scripts)
6. Provide detailed status reporting

FEATURES
========
✓ Uses native PowerShell NetSecurity module
✓ Comprehensive current state reporting
✓ Automatic log directory creation
✓ Configuration verification after changes
✓ Comprehensive error handling
✓ Manual remediation guidance on failure
✓ Clear success/failure reporting
✓ Profile-specific configuration

KEY CONFIGURATIONS
==================

Firewall State: ENABLED
  - All three profiles (Domain, Private, Public) enabled
  - Critical for network security

Default Inbound Action: BLOCK
  - Block all unsolicited inbound traffic
  - Reduces attack surface
  - Requires explicit rules for allowed traffic

Notifications: DISABLED
  - Prevents notification pop-ups
  - Reduces user confusion and support calls

Logging Configuration:
  - Log File Location: %SystemRoot%\System32\logfiles\firewall\
    • domainfw.log (Domain profile)
    • privatefw.log (Private profile)
    • publicfw.log (Public profile)
  - Log File Size: 16,384 KB (16 MB) minimum
  - Log Dropped Packets: Enabled
  - Log Successful Connections: Enabled

Public Profile Additional Hardening:
  - Disable local firewall rules
  - Disable local connection security rules
  - Prevents unauthorized local rule creation

IMPACT ASSESSMENT
=================

⚠️ IMPORTANT: Review existing firewall rules before running scripts

Potential Impact:
  - Existing network connections may be blocked
  - Applications requiring inbound connections must have firewall rules
  - VPN, Remote Desktop, and management tools require proper exceptions
  - Domain-joined systems may need specific rules for domain services

Recommended Pre-Deployment Steps:
  1. Document all required network ports/services
  2. Create necessary firewall exceptions BEFORE running scripts
  3. Test in non-production environment
  4. Have console/physical access during deployment
  5. Prepare rollback plan

VERIFICATION
============

Check firewall status for all profiles:
  PS> Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction

Check firewall logging configuration:
  PS> Get-NetFirewallProfile | Select-Object Name, LogFileName, LogMaxSizeKilobytes, LogBlocked, LogAllowed

View firewall logs:
  PS> Get-Content "$env:SystemRoot\System32\logfiles\firewall\domainfw.log" -Tail 50
  PS> Get-Content "$env:SystemRoot\System32\logfiles\firewall\privatefw.log" -Tail 50
  PS> Get-Content "$env:SystemRoot\System32\logfiles\firewall\publicfw.log" -Tail 50

Check which profile is currently active:
  PS> Get-NetConnectionProfile

FIREWALL PROFILES EXPLAINED
============================

Domain Profile:
  - Active when connected to a network with accessible domain controller
  - Applies to domain-joined computers on corporate networks
  - Typically the most permissive of the three profiles

Private Profile:
  - Active when connected to a private network (home/work)
  - User-designated private networks
  - Moderate security level

Public Profile:
  - Active when connected to public networks (airports, cafes)
  - Most restrictive profile
  - Highest security settings
  - Additional hardening controls (9.3.4, 9.3.5)

TROUBLESHOOTING
===============

If connectivity issues occur after deployment:

1. Check which profile is active:
   PS> Get-NetConnectionProfile

2. Temporarily allow a connection:
   PS> New-NetFirewallRule -DisplayName "TempAllow" -Direction Inbound -Protocol TCP -LocalPort 3389 -Action Allow

3. View blocked connections in logs:
   PS> Select-String -Path "$env:SystemRoot\System32\logfiles\firewall\domainfw.log" -Pattern "DROP"

4. Check existing rules:
   PS> Get-NetFirewallRule | Where-Object {$_.Enabled -eq 'True'} | Select-Object DisplayName, Direction, Action

ROLLBACK
========

To restore default firewall settings:

Reset all profiles to defaults:
  PS> Set-NetFirewallProfile -All -DefaultInboundAction NotConfigured -DefaultOutboundAction NotConfigured

Disable firewall (NOT RECOMMENDED for production):
  PS> Set-NetFirewallProfile -All -Enabled False

Restore via Group Policy:
  1. Open gpedit.msc
  2. Navigate to: Computer Configuration > Policies > Windows Settings > Security Settings > 
     Windows Defender Firewall with Advanced Security
  3. Right-click > "Restore Default Policy"

ALTERNATIVE METHODS
===================

If PowerShell scripts cannot be used:

Method 1 - Group Policy:
  1. Open gpedit.msc
  2. Navigate to: Computer Configuration > Policies > Windows Settings > Security Settings
  3. Open: Windows Defender Firewall with Advanced Security
  4. Right-click "Windows Defender Firewall with Advanced Security" > Properties
  5. Configure each profile tab (Domain, Private, Public)

Method 2 - Windows Defender Firewall with Advanced Security MMC:
  1. Run: wf.msc
  2. Click "Windows Defender Firewall Properties"
  3. Configure each profile tab

Method 3 - netsh commands:
  netsh advfirewall set allprofiles state on
  netsh advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound
  netsh advfirewall set allprofiles logging filename %SystemRoot%\System32\logfiles\firewall\pfirewall.log
  netsh advfirewall set allprofiles logging maxfilesize 16384

BEST PRACTICES
==============

1. Deploy scripts in this order:
   - Domain profile first (9.1.x)
   - Private profile second (9.2.x)
   - Public profile last (9.3.x)

2. Create firewall exceptions BEFORE running scripts:
   - Document required inbound ports
   - Create necessary rules via Group Policy
   - Test connectivity

3. Monitor firewall logs after deployment:
   - Review dropped packet logs daily for first week
   - Identify legitimate traffic being blocked
   - Create appropriate exceptions

4. Use Group Policy for firewall rule management:
   - Centralized rule deployment
   - Consistent across all servers
   - Version control and auditing

TESTING
=======
Always test in non-production environment first.
Verify all critical services remain functional after deployment.

SUPPORT
=======
For issues or questions, refer to:
  - CIS Microsoft Windows Server 2022 Benchmark v4.0.0
  - Microsoft Windows Defender Firewall documentation
  - Windows Firewall with Advanced Security Deployment Guide

ADDITIONAL RESOURCES
====================
- Windows Firewall Best Practices: https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-firewall/
- CIS Benchmarks: https://www.cisecurity.org/cis-benchmarks

Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
