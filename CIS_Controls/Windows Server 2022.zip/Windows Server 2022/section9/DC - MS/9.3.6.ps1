# 9.3.6.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"
  $regValue = "LogFilePath"
  $after = "%SystemRoot%\System32\logfiles\firewall\publicfw.log"
  
  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }
    
    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }
    
    $expandedPath = [System.Environment]::ExpandEnvironmentVariables($after)
    $logDir = Split-Path -Parent $expandedPath
    if (-not (Test-Path $logDir)) {
      New-Item -Path $logDir -ItemType Directory -Force | Out-Null
    }
    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type String -Force
    
    Write-Output "Control: 9.3.6 (L1) Ensure 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Windows Defender Firewall with Advanced Security\Windows Defender Firewall with Advanced Security\Windows Defender Firewall Properties\Public Profile\Logging Customize\Name"
    Write-Output "Name: LogFilePath"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 9.3.6 (L1) Ensure 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
