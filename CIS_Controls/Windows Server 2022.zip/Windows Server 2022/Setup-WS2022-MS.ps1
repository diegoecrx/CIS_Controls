<# 
WS2022 NAT (VMware VMnet8) — Join lab.local and prep IIS
Host: WS2022-MS  |  IP: 192.168.30.20/24  |  GW: 192.168.30.2  |  DNS: 192.168.30.10 (DC)
Adds LAB\msuser to local "Remote Desktop Users" for easy login. Idempotent.
#>

[CmdletBinding()]
param(
  [string]$DomainName     = 'lab.local',
  [string]$TargetHostname = 'WS2022-MS',
  [string]$InterfaceAlias = 'Ethernet0',
  [string]$IPv4           = '192.168.30.20',
  [int]   $PrefixLength   = 24,
  [string]$DefaultGateway = '192.168.30.2',
  [string]$DcFqdn         = 'ws2022-dc.lab.local',
  [string]$DcIP           = '192.168.30.10',
  [string]$EnableRdpUser  = 'LAB\msuser'
)

function Info($m){ Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function Warn($m){ Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Err ($m){ Write-Host "[ERROR] $m" -ForegroundColor Red }

$null = New-Item -ItemType Directory -Path C:\Logs -ErrorAction SilentlyContinue
$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
Start-Transcript -Path "C:\Logs\ms_setup_$ts.log" -Force | Out-Null

# Admin check
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run as Administrator." }

function Ensure-IPv4 {
  param([string]$Nic,[string]$IP,[int]$Pref,[string]$Gw,[string[]]$Dns)
  Set-NetIPInterface -InterfaceAlias $Nic -Dhcp Disabled -ErrorAction SilentlyContinue | Out-Null
  $cur = Get-NetIPAddress -InterfaceAlias $Nic -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.PrefixOrigin -ne 'WellKnown'}
  $have = $false
  foreach($c in ($cur | Where-Object { $_.IPAddress -notlike '169.254.*' })) {
    if ($c.IPAddress -eq $IP -and $c.PrefixLength -eq $Pref) { $have = $true } else {
      $c | Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue
    }
  }
  if (-not $have) {
    New-NetIPAddress -InterfaceAlias $Nic -IPAddress $IP -PrefixLength $Pref -DefaultGateway $Gw | Out-Null
    Info "$Nic -> $IP/$Pref gw $Gw"
  } else {
    Info "$Nic already $IP/$Pref"
    $gwCur = (Get-NetIPConfiguration -InterfaceAlias $Nic).IPv4DefaultGateway.NextHop
    if ($Gw -and $gwCur -ne $Gw) {
      Remove-NetRoute -InterfaceAlias $Nic -DestinationPrefix '0.0.0.0/0' -Confirm:$false -ErrorAction SilentlyContinue
      New-NetRoute    -InterfaceAlias $Nic -DestinationPrefix '0.0.0.0/0' -NextHop $Gw | Out-Null
      Info "Updated default route via $Gw"
    }
  }
  if ($Dns) {
    $curDns = (Get-DnsClientServerAddress -InterfaceAlias $Nic -AddressFamily IPv4).ServerAddresses
    if (($curDns -join ',') -ne ($Dns -join ',')) {
      Set-DnsClientServerAddress -InterfaceAlias $Nic -ServerAddresses $Dns
      Info "DNS on $Nic -> $($Dns -join ', ')"
    }
  }
}

# 1) Hostname
$current = (Get-ComputerInfo).CsName
if ($current -ne $TargetHostname) {
  Info ("Renaming {0} -> {1} (rebooting...)" -f $current,$TargetHostname)
  Rename-Computer -NewName $TargetHostname -Force
  Restart-Computer -Force
  Stop-Transcript | Out-Null
  exit
} else { Info "Hostname OK: $TargetHostname" }

# 2) NIC / IPv4 / GW / DNS -> DC
Ensure-IPv4 -Nic $InterfaceAlias -IP $IPv4 -Pref $PrefixLength -Gw $DefaultGateway -Dns @($DcIP)

# 3) Time sync to DC
w32tm /config /manualpeerlist:$DcFqdn /syncfromflags:manual /update | Out-Null
w32tm /resync /nowait | Out-Null

# 4) Join domain if needed
$cs = Get-WmiObject Win32_ComputerSystem
if (-not $cs.PartOfDomain -or $cs.Domain -ne $DomainName) {
  try {
    $cred = Get-Credential -UserName 'LAB\Administrator' -Message "Join $DomainName"
    Add-Computer -DomainName $DomainName -Server $DcFqdn -Credential $cred -Force -Verbose -ErrorAction Stop
    Info "Join initiated. Rebooting..."
    Restart-Computer -Force
    Stop-Transcript | Out-Null
    exit
  } catch {
    $msg = $_.Exception.Message
    Err ("Add-Computer failed: {0}" -f $msg)
    if ($msg -match 'SID.*improperly cloned|SID of the domain.*identical') {
      Warn "This VM needs generalization: sysprep /oobe /generalize /shutdown  (then re-run)."
    }
    throw
  }
} else { Info "Already joined to $DomainName." }

# 5) Optional RSAT tools
if (-not (Get-WindowsFeature RSAT-AD-Tools).Installed) { Add-WindowsFeature RSAT-AD-Tools | Out-Null }

# 6) Add msuser to local RDP group (handy)
try {
  Add-LocalGroupMember -Group "Remote Desktop Users" -Member "LAB\msuser" -ErrorAction SilentlyContinue
  Info "Added LAB\msuser to 'Remote Desktop Users'."
} catch { Warn "RDP group step: $($_.Exception.Message)" }

# 7) IIS as test service
if (-not (Get-WindowsFeature Web-Server).Installed) { Install-WindowsFeature Web-Server -IncludeManagementTools | Out-Null }
Start-Service W3SVC -ErrorAction SilentlyContinue
Set-Service  W3SVC -StartupType Automatic
"<!doctype html><h1>WS2022-MS (IIS)</h1><p>Joined to: $DomainName</p>" | Out-File "C:\inetpub\wwwroot\index.html" -Encoding UTF8 -Force

# 8) Quick sanity
try { $sc = Test-ComputerSecureChannel; Info ("Secure channel: {0}" -f $sc) } catch { Warn "Secure channel check error." }
(Invoke-WebRequest http://localhost -UseBasicParsing).StatusCode | Out-Null

Info "Member setup complete."
Stop-Transcript | Out-Null
