###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 18.10.43.5.2.ps1
# CIS Control - 18.10.43.5.2 (L2) Ensure 'Join Microsoft MAPS' is set to 'Disabled' (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 18.10.43.5.2

.DESCRIPTION
    This script configures Group Policy Administrative Template settings via registry
    per CIS 18.10.43.5.2 control for Windows Server 2022.

    Profile Applicability: 
    • Level 2 - Domain Controller
• Level 2 - Member Server

    Default value: Disabled. (Microsoft MAPS / Microsoft Defender Antivirus Cloud Protection Service will
not be joined.)

.NOTES
    Requires: Run as Administrator
    Uses: Direct Registry modification for Administrative Templates

    Remediation: See control documentation for full details
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "18.10.43.5.2.ps1"
$CONTROL_NAME = "18.10.43.5.2 (L2) Ensure 'Join Microsoft MAPS' is set to 'Disabled' (Automated)"
$REG_PATH = "See remediation details"
$VALUE_NAME = "See remediation details"
$VALUE_TYPE = "REG_DWORD"
$RECOMMENDED_VALUE = "See remediation details"
$DEFAULT_VALUE = "Disabled. (Microsoft MAPS / Microsoft Defender Antivirus Cloud Protection Service will
not be joined.)"
$IS_DC_ONLY = ${"True" if is_dc_only else "False"}
$IS_MS_ONLY = ${"True" if is_ms_only else "False"}

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Configure Administrative Template (Registry-based Policy)"
Write-Host ""
Write-Host "Profile Applicability: • Level 2 - Domain Controller
• Level 2 - Member Server"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host ""

# Determine if this is a Domain Controller or Member Server
$isDomainController = $false
$computerInfo = Get-WmiObject -Class Win32_ComputerSystem

if ($computerInfo.DomainRole -eq 4 -or $computerInfo.DomainRole -eq 5) {
    $isDomainController = $true
}

Write-Host "Remediation Details:"
Write-Host ""

# Check if this script should run on this system type
$shouldRun = $true
if ($IS_DC_ONLY -eq "True" -and -not $isDomainController) {
    Write-Host "[INFO] This control is for Domain Controllers only."
    Write-Host "[INFO] Current system is a Member Server. Skipping remediation."
    $shouldRun = $false
}

if ($IS_MS_ONLY -eq "True" -and $isDomainController) {
    Write-Host "[INFO] This control is for Member Servers only."
    Write-Host "[INFO] Current system is a Domain Controller. Skipping remediation."
    $shouldRun = $false
}

if ($shouldRun) {
    try {
        Write-Host "[INFO] Registry Path: $REG_PATH"
        Write-Host "[INFO] Value Name: $VALUE_NAME"
        Write-Host "[INFO] Recommended Value: $RECOMMENDED_VALUE"
        Write-Host ""

        # Ensure registry path exists
        if (-not (Test-Path -Path $REG_PATH)) {
            Write-Host "[ACTION] Creating registry path: $REG_PATH"
            New-Item -Path $REG_PATH -Force | Out-Null
        }

        # Get current value if it exists
        try {
            $currentValue = Get-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -ErrorAction SilentlyContinue
            if ($currentValue) {
                Write-Host "[CURRENT] Current value: $($currentValue.$VALUE_NAME)"
            } else {
                Write-Host "[CURRENT] Value does not exist (will be created)"
            }
        } catch {
            Write-Host "[CURRENT] Value does not exist (will be created)"
        }

        # Set the registry value
        Write-Host ""
        Write-Host "[ACTION] Applying CIS recommended configuration..."

        if ($VALUE_TYPE -eq "REG_DWORD") {
            Set-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -Value ([int]$RECOMMENDED_VALUE) -Type DWord -Force
        }
        elseif ($VALUE_TYPE -eq "REG_SZ") {
            Set-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -Value $RECOMMENDED_VALUE -Type String -Force
        }
        else {
            Set-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -Value $RECOMMENDED_VALUE -Force
        }

        # Verify the configuration
        $verifyValue = Get-ItemProperty -Path $REG_PATH -Name $VALUE_NAME -ErrorAction Stop
        Write-Host "[VERIFICATION] Updated value: $($verifyValue.$VALUE_NAME)"
        Write-Host ""

        Write-Host "[SUCCESS] Configuration applied successfully"
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "Remediation Summary:"
        Write-Host "- Control: 18.10.43.5.2"
        Write-Host "- Status: COMPLETED"
        Write-Host "- Registry: $REG_PATH"
        Write-Host "- Value: $VALUE_NAME = $RECOMMENDED_VALUE"
        Write-Host "=============================================="

    } catch {
        Write-Host ""
        Write-Host "[ERROR] Failed to apply remediation automatically."
        Write-Host "Error details: $_"
        Write-Host ""
        Write-Host "=============================================="
        Write-Host "MANUAL REMEDIATION REQUIRED"
        Write-Host "=============================================="
        Write-Host ""
        Write-Host "Please configure manually via Group Policy Editor:"
        Write-Host ""
        Write-Host "1. Open Group Policy Editor (gpedit.msc)"
        Write-Host "2. Navigate to: Computer Configuration > Administrative Templates"
        Write-Host "3. Locate the policy for control 18.10.43.5.2"
        Write-Host "4. Configure according to CIS Benchmark recommendations"
        Write-Host "5. Run 'gpupdate /force' to apply changes"
        Write-Host ""
        Write-Host "Alternative using Registry:"
        Write-Host "  Path: $REG_PATH"
        Write-Host "  Value Name: $VALUE_NAME"
        Write-Host "  Value: $RECOMMENDED_VALUE"
        Write-Host ""
        Write-Host "=============================================="
    }
} else {
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation skipped based on system type."
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
