
import pandas as pd

# Read the Excel file for section 18
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section18.xlsx', sheet_name='Recommendations')

# Display the dataframe overview
print("Total rows:", len(df))
print("\nColumns:", df.columns.tolist())
print("\n")
print("First 20 controls:")
print(df[['script_name', 'control_name']].head(20).to_string(index=False))
print(f"\n... (showing first 20 of {len(df)} rows)")
