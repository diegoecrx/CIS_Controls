# 2.2.38.ps1 - 2.2.38 (L1) Ensure 'Manage auditing and security log' is set to 'Administrators' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.38
