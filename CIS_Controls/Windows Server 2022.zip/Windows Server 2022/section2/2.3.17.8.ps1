# 2.3.17.8.ps1 - 2.3.17.8 (L1) Ensure 'User Account Control: Virtualize file and registry write failures to per-user locations' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.17.8
