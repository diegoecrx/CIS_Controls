# 2.2.26.ps1 - 2.2.26 (L1) Ensure 'Deny log on through Remote Desktop Services' to include 'Guests' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.26
