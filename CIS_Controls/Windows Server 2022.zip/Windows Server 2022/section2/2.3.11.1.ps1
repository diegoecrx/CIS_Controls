# 2.3.11.1.ps1 - 2.3.11.1 (L1) Ensure 'Network security: Allow Local System to use computer identity for NTLM' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.11.1
