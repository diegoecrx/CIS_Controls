# 2.3.17.7.ps1 - 2.3.17.7 (L1) Ensure 'User Account Control: Switch to the secure desktop when prompting for elevation' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.17.7
