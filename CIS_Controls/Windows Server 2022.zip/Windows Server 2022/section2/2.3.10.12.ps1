# 2.3.10.12.ps1 - 2.3.10.12 (L1) Ensure 'Network access: Shares that can be accessed anonymously' is set to 'None' (Automated)
# Generated placeholder for CIS control 2.3.10.12
