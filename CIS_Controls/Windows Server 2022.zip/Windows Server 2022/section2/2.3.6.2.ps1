# 2.3.6.2.ps1 - 2.3.6.2 (L1) Ensure 'Domain member: Digitally encrypt secure channel data (when possible)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.6.2
