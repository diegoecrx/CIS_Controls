# 2.3.11.4.ps1 - 2.3.11.4 (L1) Ensure 'Network security: Configure encryption types allowed for Kerberos' is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types' (Automated)
# Generated placeholder for CIS control 2.3.11.4
