# 2.2.34.ps1 - 2.2.34 (L1) Ensure 'Increase scheduling priority' is set to 'Administrators, Window Manager\Window Manager Group' (Automated)
# Generated placeholder for CIS control 2.2.34
