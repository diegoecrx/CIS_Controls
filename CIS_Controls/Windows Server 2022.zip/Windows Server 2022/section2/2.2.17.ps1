# 2.2.17.ps1 - 2.2.17 (L1) Ensure 'Create permanent shared objects' is set to 'No One' (Automated)
# Generated placeholder for CIS control 2.2.17
