# 2.3.9.1.ps1 - 2.3.9.1 (L1) Ensure 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)' (Automated)
# Generated placeholder for CIS control 2.3.9.1
