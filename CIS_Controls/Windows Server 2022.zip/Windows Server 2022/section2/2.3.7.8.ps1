# 2.3.7.8.ps1 - 2.3.7.8 (L1) Ensure 'Interactive logon: Require Domain Controller Authentication to unlock workstation' is set to 'Enabled' (MS only) (Automated)
# Generated placeholder for CIS control 2.3.7.8
