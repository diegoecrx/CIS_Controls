# 2.3.7.1.ps1 - 2.3.7.1 (L1) Ensure 'Interactive logon: Do not require CTRL+ALT+DEL' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.7.1
