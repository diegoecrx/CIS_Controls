# 2.2.7.ps1 - 2.2.7 (L1) Ensure 'Allow log on locally' is set to 'Administrators, ENTERPRISE DOMAIN CONTROLLERS' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.7
