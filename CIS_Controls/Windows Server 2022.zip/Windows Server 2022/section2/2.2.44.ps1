# 2.2.44.ps1 - 2.2.44 (L1) Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\WdiServiceHost' (Automated)
# Generated placeholder for CIS control 2.2.44
