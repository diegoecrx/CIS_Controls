# 2.2.21.ps1 - 2.2.21 (L1) Ensure 'Deny access to this computer from the network' to include 'Guests' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.21
