# 2.2.41.ps1 - 2.2.41 (L1) Ensure 'Modify firmware environment values' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.41
