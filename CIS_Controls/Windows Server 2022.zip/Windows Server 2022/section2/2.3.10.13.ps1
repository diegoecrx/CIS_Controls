# 2.3.10.13.ps1 - 2.3.10.13 (L1) Ensure 'Network access: Sharing and security model for local accounts' is set to 'Classic - local users authenticate as themselves' (Automated)
# Generated placeholder for CIS control 2.3.10.13
