# 2.2.2.ps1 - 2.2.2 (L1) Ensure 'Access this computer from the network' is set to 'Administrators, Authenticated Users, ENTERPRISE DOMAIN CONTROLLERS' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.2
