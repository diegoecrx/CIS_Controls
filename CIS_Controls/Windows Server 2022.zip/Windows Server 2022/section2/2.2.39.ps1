# 2.2.39.ps1 - 2.2.39 (L1) Ensure 'Manage auditing and security log' is set to 'Administrators' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.39
