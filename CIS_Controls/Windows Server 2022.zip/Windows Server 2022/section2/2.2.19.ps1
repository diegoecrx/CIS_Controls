# 2.2.19.ps1 - 2.2.19 (L1) Ensure 'Create symbolic links' is set to 'Administrators, NT VIRTUAL MACHINE\Virtual Machines' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.19
