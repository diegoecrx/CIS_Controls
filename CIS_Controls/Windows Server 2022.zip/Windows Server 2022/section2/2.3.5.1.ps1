# 2.3.5.1.ps1 - 2.3.5.1 (L1) Ensure 'Domain controller: Allow server operators to schedule tasks' is set to 'Disabled' (DC only) (Automated)
# Generated placeholder for CIS control 2.3.5.1
