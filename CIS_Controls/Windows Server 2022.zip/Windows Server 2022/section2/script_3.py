
import pandas as pd
import os
import re

# Read the Excel file
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section2.xlsx', sheet_name='Recommendations')

# User rights mapping
user_rights_mapping = {
    "Access Credential Manager as a trusted caller": "SeTrustedCredManAccessPrivilege",
    "Access this computer from the network": "SeNetworkLogonRight",
    "Act as part of the operating system": "SeTcbPrivilege",
    "Add workstations to domain": "SeMachineAccountPrivilege",
    "Adjust memory quotas for a process": "SeIncreaseQuotaPrivilege",
    "Allow log on locally": "SeInteractiveLogonRight",
    "Allow log on through Remote Desktop Services": "SeRemoteInteractiveLogonRight",
    "Back up files and directories": "SeBackupPrivilege",
    "Change the system time": "SeSystemtimePrivilege",
    "Change the time zone": "SeTimeZonePrivilege",
    "Create a pagefile": "SeCreatePagefilePrivilege",
    "Create a token object": "SeCreateTokenPrivilege",
    "Create global objects": "SeCreateGlobalPrivilege",
    "Create permanent shared objects": "SeCreatePermanentPrivilege",
    "Create symbolic links": "SeCreateSymbolicLinkPrivilege",
    "Debug programs": "SeDebugPrivilege",
    "Deny access to this computer from the network": "SeDenyNetworkLogonRight",
    "Deny log on as a batch job": "SeDenyBatchLogonRight",
    "Deny log on as a service": "SeDenyServiceLogonRight",
    "Deny log on locally": "SeDenyInteractiveLogonRight",
    "Deny log on through Remote Desktop Services": "SeDenyRemoteInteractiveLogonRight",
    "Enable computer and user accounts to be trusted for delegation": "SeEnableDelegationPrivilege",
    "Force shutdown from a remote system": "SeRemoteShutdownPrivilege",
    "Generate security audits": "SeAuditPrivilege",
    "Impersonate a client after authentication": "SeImpersonatePrivilege",
    "Increase scheduling priority": "SeIncreaseBasePriorityPrivilege",
    "Load and unload device drivers": "SeLoadDriverPrivilege",
    "Lock pages in memory": "SeLockMemoryPrivilege",
    "Log on as a batch job": "SeBatchLogonRight",
    "Manage auditing and security log": "SeSecurityPrivilege",
    "Modify an object label": "SeRelabelPrivilege",
    "Modify firmware environment values": "SeSystemEnvironmentPrivilege",
    "Perform volume maintenance tasks": "SeManageVolumePrivilege",
    "Profile single process": "SeProfileSingleProcessPrivilege",
    "Profile system performance": "SeSystemProfilePrivilege",
    "Replace a process level token": "SeAssignPrimaryTokenPrivilege",
    "Restore files and directories": "SeRestorePrivilege",
    "Shut down the system": "SeShutdownPrivilege",
    "Synchronize directory service data": "SeSyncAgentPrivilege",
    "Take ownership of files or other objects": "SeTakeOwnershipPrivilege"
}

print(f"Total scripts to generate: {len(df)}")
print("\nStarting script generation...\n")

# Create output directory
output_dir = "section2_scripts"
os.makedirs(output_dir, exist_ok=True)

generated_count = 0

for idx in range(len(df)):
    script_name = str(df.loc[idx, 'script_name']).strip()
    control_name = str(df.loc[idx, 'control_name']).strip()
    profile = str(df.loc[idx, 'profile_applicability']).strip()
    remediation = str(df.loc[idx, 'remediation']).strip()
    default_value = str(df.loc[idx, 'default_value']).strip()
    
    # Determine if this is Automated or Manual
    is_manual = "(Manual)" in control_name
    is_automated = "(Automated)" in control_name
    
    filename = f"{script_name}.ps1"
    
    # Skip for now, we'll generate them
    generated_count += 1
    
print(f"\nTotal rows processed: {generated_count}")
print(f"Output directory: {output_dir}")
