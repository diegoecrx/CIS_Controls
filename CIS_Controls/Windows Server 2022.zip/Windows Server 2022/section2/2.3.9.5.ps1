# 2.3.9.5.ps1 - 2.3.9.5 (L1) Ensure 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher (MS only) (Automated)
# Generated placeholder for CIS control 2.3.9.5
