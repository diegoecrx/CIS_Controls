# 2.2.16.ps1 - 2.2.16 (L1) Ensure 'Create global objects' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE' (Automated)
# Generated placeholder for CIS control 2.2.16
