# 2.2.8.ps1 - 2.2.8 (L1) Ensure 'Allow log on locally' is set to 'Administrators' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.8
