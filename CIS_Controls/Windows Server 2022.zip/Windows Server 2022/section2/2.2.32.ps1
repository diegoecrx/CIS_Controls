# 2.2.32.ps1 - 2.2.32 (L1) Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.32
