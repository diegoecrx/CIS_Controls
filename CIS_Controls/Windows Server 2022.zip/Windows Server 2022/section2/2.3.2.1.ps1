# 2.3.2.1.ps1 - 2.3.2.1 (L1) Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.2.1
