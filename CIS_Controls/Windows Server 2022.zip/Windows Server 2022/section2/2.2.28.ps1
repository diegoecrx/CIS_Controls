# 2.2.28.ps1 - 2.2.28 (L1) Ensure 'Enable computer and user accounts to be trusted for delegation' is set to 'Administrators' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.28
