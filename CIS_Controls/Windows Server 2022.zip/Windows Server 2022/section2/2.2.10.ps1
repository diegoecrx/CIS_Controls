# 2.2.10.ps1 - 2.2.10 (L1) Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators, Remote Desktop Users' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.10
