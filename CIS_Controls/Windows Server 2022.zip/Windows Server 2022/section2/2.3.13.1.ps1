# 2.3.13.1.ps1 - 2.3.13.1 (L1) Ensure 'Shutdown: Allow system to be shut down without having to log on' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.13.1
