# 2.3.11.10.ps1 - 2.3.11.10 (L1) Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients' is set to 'Require NTLMv2 session security, Require 128-bit encryption' (Automated)
# Generated placeholder for CIS control 2.3.11.10
