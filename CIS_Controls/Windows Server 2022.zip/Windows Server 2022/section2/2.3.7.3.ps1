# 2.3.7.3.ps1 - 2.3.7.3 (L1) Ensure 'Interactive logon: Machine inactivity limit' is set to '900 or fewer second(s), but not 0' (Automated)
# Generated placeholder for CIS control 2.3.7.3
