
import pandas as pd
import os
import re

# Read the Excel file
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section2.xlsx', sheet_name='Recommendations')

output_dir = "section2_scripts"

# This function generates complete PowerShell script for User Rights Assignments
def generate_user_rights_script_template(script_id, control_name, profile, remediation, default_value, 
                                         right_name, secedit_name, recommended_value, sids, 
                                         is_dc_only, is_ms_only, config_path):
    
    script_type = "Manual" if "(Manual)" in control_name else "Automated"
    
    script = f'''###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# {script_id}.ps1
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    {script_type} remediation for CIS Control {script_id}

.DESCRIPTION
    This script ensures that '{right_name}' is set to '{recommended_value}' 
    per CIS {script_id} control for Windows Server 2022.
    
    Profile Applicability: 
    {profile}
    
    Default value: {default_value}

.NOTES
    Requires: Run as Administrator
    Uses: secedit.exe for User Rights Assignment
    
    Remediation Path: {config_path}
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "{script_id}.ps1"
$CONTROL_NAME = "{control_name}"
$CONFIG_FILE = "{config_path}"
$DEFAULT_VALUE = "{default_value}"
$RECOMMENDED_VALUE = "{recommended_value}"
$SECEDIT_SETTING = "{secedit_name}"
$SECEDIT_VALUE = "{sids}"

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure '{right_name}' is set to '{recommended_value}'"
Write-Host ""
Write-Host "Configuration file: $CONFIG_FILE"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host ""

Write-Host "Remediation Details:"
Write-Host ""

try {{
    # Export current security policy
    $backupFile = "$env:TEMP\\secedit_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').cfg"
    
    secedit /export /cfg $backupFile /quiet
    Write-Host "[BACKUP] Current security policy exported to: $backupFile"
    
    # Create temporary security template
    $tempFile = [System.IO.Path]::GetTempFileName()
    $secTemplate = @"
[Unicode]
Unicode=yes
[Privilege Rights]
$SECEDIT_SETTING = $SECEDIT_VALUE
[Version]
signature="`$CHICAGO`$"
Revision=1
"@
    
    $secTemplate | Out-File -FilePath $tempFile -Encoding unicode -Force
    
    # Apply the security template
    secedit /configure /db secedit.sdb /cfg $tempFile /quiet
    
    # Refresh Group Policy
    gpupdate /force | Out-Null
    
    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    
    Write-Host "[SUCCESS] '{right_name}' set to '{recommended_value}' via Local Security Policy"
    Write-Host "[INFO] Group Policy has been refreshed"
    Write-Host ""
    
    Write-Host "=============================================="
    Write-Host "Remediation Summary:"
    Write-Host "- Control: {script_id}"
    Write-Host "- Status: COMPLETED"
    Write-Host "- User Right: {right_name}"
    Write-Host "- Configured Value: {recommended_value}"
    Write-Host "=============================================="
    
}} catch {{
    Write-Host ""
    Write-Host "[ERROR] Failed to apply remediation automatically."
    Write-Host "Error details: $_"
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "MANUAL REMEDIATION REQUIRED"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Please configure manually via Group Policy Editor (gpedit.msc):"
    Write-Host ""
    Write-Host "Path: $CONFIG_FILE"
    Write-Host "Value to set: {recommended_value}"
    Write-Host ""
    Write-Host "Steps:"
    Write-Host "1. Open Local Group Policy Editor (gpedit.msc)"
    Write-Host "2. Navigate to the policy path above"
    Write-Host "3. Configure the setting to: {recommended_value}"
    Write-Host "4. Click OK and close the editor"
    Write-Host "5. Run 'gpupdate /force' to apply changes"
    Write-Host ""
    Write-Host "=============================================="
}}

Write-Host ""
Write-Host ""
Write-Host ""
'''
    return script

print("Generating complete PowerShell scripts...")
print("This will take a moment...\n")

# Count by type
total = len(df)
print(f"Total scripts to generate: {total}")
print("Processing...")
