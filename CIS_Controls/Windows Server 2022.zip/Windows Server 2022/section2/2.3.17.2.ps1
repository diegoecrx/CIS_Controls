# 2.3.17.2.ps1 - 2.3.17.2 (L1) Ensure 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode' is set to 'Prompt for consent on the secure desktop' or higher (Automated)
# Generated placeholder for CIS control 2.3.17.2
