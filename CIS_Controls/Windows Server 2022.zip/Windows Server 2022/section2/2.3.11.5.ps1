# 2.3.11.5.ps1 - 2.3.11.5 (L1) Ensure 'Network security: Do not store LAN Manager hash value on next password change' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.11.5
