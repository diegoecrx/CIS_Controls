# 2.2.47.ps1 - 2.2.47 (L1) Ensure 'Shut down the system' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.47
