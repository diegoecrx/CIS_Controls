# 2.3.8.2.ps1 - 2.3.8.2 (L1) Ensure 'Microsoft network client: Digitally sign communications (if server agrees)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.8.2
