# 2.2.37.ps1 - 2.2.37 (L2) Ensure 'Log on as a batch job' is set to 'Administrators' (DC Only) (Automated)
# Generated placeholder for CIS control 2.2.37
