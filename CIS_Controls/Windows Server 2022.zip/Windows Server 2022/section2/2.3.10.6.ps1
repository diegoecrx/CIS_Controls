# 2.3.10.6.ps1 - 2.3.10.6 (L1) Ensure 'Network access: Named Pipes that can be accessed anonymously' is configured (DC only) (Automated)
# Generated placeholder for CIS control 2.3.10.6
