
import pandas as pd
import re

# Read the Excel file for section 2
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section2.xlsx', sheet_name='Recommendations')

# Create a dictionary to map user rights to their corresponding secedit names
user_rights_mapping = {
    "Access Credential Manager as a trusted caller": "SeTrustedCredManAccessPrivilege",
    "Access this computer from the network": "SeNetworkLogonRight",
    "Act as part of the operating system": "SeTcbPrivilege",
    "Add workstations to domain": "SeMachineAccountPrivilege",
    "Adjust memory quotas for a process": "SeIncreaseQuotaPrivilege",
    "Allow log on locally": "SeInteractiveLogonRight",
    "Allow log on through Remote Desktop Services": "SeRemoteInteractiveLogonRight",
    "Back up files and directories": "SeBackupPrivilege",
    "Change the system time": "SeSystemtimePrivilege",
    "Change the time zone": "SeTimeZonePrivilege",
    "Create a pagefile": "SeCreatePagefilePrivilege",
    "Create a token object": "SeCreateTokenPrivilege",
    "Create global objects": "SeCreateGlobalPrivilege",
    "Create permanent shared objects": "SeCreatePermanentPrivilege",
    "Create symbolic links": "SeCreateSymbolicLinkPrivilege",
    "Debug programs": "SeDebugPrivilege",
    "Deny access to this computer from the network": "SeDenyNetworkLogonRight",
    "Deny log on as a batch job": "SeDenyBatchLogonRight",
    "Deny log on as a service": "SeDenyServiceLogonRight",
    "Deny log on locally": "SeDenyInteractiveLogonRight",
    "Deny log on through Remote Desktop Services": "SeDenyRemoteInteractiveLogonRight",
    "Enable computer and user accounts to be trusted for delegation": "SeEnableDelegationPrivilege",
    "Force shutdown from a remote system": "SeRemoteShutdownPrivilege",
    "Generate security audits": "SeAuditPrivilege",
    "Impersonate a client after authentication": "SeImpersonatePrivilege",
    "Increase scheduling priority": "SeIncreaseBasePriorityPrivilege",
    "Load and unload device drivers": "SeLoadDriverPrivilege",
    "Lock pages in memory": "SeLockMemoryPrivilege",
    "Log on as a batch job": "SeBatchLogonRight",
    "Manage auditing and security log": "SeSecurityPrivilege",
    "Modify an object label": "SeRelabelPrivilege",
    "Modify firmware environment values": "SeSystemEnvironmentPrivilege",
    "Perform volume maintenance tasks": "SeManageVolumePrivilege",
    "Profile single process": "SeProfileSingleProcessPrivilege",
    "Profile system performance": "SeSystemProfilePrivilege",
    "Replace a process level token": "SeAssignPrimaryTokenPrivilege",
    "Restore files and directories": "SeRestorePrivilege",
    "Shut down the system": "SeShutdownPrivilege",
    "Synchronize directory service data": "SeSyncAgentPrivilege",
    "Take ownership of files or other objects": "SeTakeOwnershipPrivilege"
}

# Helper function to extract user right from control name
def extract_user_right(control_name):
    for right_name in user_rights_mapping.keys():
        if right_name in control_name:
            return right_name, user_rights_mapping[right_name]
    return None, None

# Test first 5
print("Testing user rights extraction for first 5 rows:\n")
for idx in range(min(5, len(df))):
    control = df.loc[idx, 'control_name']
    right_name, secedit_name = extract_user_right(control)
    print(f"{idx+1}. {df.loc[idx, 'script_name']}: {right_name} -> {secedit_name}")
