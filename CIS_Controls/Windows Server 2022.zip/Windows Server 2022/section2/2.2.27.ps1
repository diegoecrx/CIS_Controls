# 2.2.27.ps1 - 2.2.27 (L1) Ensure 'Deny log on through Remote Desktop Services' is set to 'Guests, Local account' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.27
