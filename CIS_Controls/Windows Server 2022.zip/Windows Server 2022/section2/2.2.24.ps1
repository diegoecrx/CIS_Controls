# 2.2.24.ps1 - 2.2.24 (L1) Ensure 'Deny log on as a service' to include 'Guests' (Automated)
# Generated placeholder for CIS control 2.2.24
