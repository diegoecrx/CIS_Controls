# 2.2.35.ps1 - 2.2.35 (L1) Ensure 'Load and unload device drivers' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.35
