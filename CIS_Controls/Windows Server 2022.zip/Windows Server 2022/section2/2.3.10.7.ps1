# 2.3.10.7.ps1 - 2.3.10.7 (L1) Ensure 'Network access: Named Pipes that can be accessed anonymously' is configured (MS only) (Automated)
# Generated placeholder for CIS control 2.3.10.7
