# 2.2.22.ps1 - 2.2.22 (L1) Ensure 'Deny access to this computer from the network' to include 'Guests, Local account and member of Administrators group' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.22
