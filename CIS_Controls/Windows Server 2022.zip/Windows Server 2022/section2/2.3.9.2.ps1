# 2.3.9.2.ps1 - 2.3.9.2 (L1) Ensure 'Microsoft network server: Digitally sign communications (always)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.9.2
