# 2.2.49.ps1 - 2.2.49 (L1) Ensure 'Take ownership of files or other objects' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.49
