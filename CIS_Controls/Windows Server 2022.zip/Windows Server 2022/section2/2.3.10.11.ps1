# 2.3.10.11.ps1 - 2.3.10.11 (L1) Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow' (MS only) (Automated)
# Generated placeholder for CIS control 2.3.10.11
