# 2.3.9.4.ps1 - 2.3.9.4 (L1) Ensure 'Microsoft network server: Disconnect clients when logon hours expire' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.9.4
