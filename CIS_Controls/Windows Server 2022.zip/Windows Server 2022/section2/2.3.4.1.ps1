# 2.3.4.1.ps1 - 2.3.4.1 (L1) Ensure 'Devices: Prevent users from installing printer drivers' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.4.1
