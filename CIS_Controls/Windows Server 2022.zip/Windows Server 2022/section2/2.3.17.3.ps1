# 2.3.17.3.ps1 - 2.3.17.3 (L1) Ensure 'User Account Control: Behavior of the elevation prompt for standard users' is set to 'Automatically deny elevation requests' (Automated)
# Generated placeholder for CIS control 2.3.17.3
