# 2.3.7.2.ps1 - 2.3.7.2 (L1) Ensure 'Interactive logon: Don't display last signed-in' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.7.2
