# 2.3.10.1.ps1 - 2.3.10.1 (L1) Ensure 'Network access: Allow anonymous SID/Name translation' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.10.1
