###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark - Section 2 Scripts
# README for all 122 PowerShell scripts
###############################################################################

OVERVIEW
========
This package contains 122 PowerShell remediation scripts for CIS Microsoft Windows Server 2022 Benchmark Section 2.
All scripts follow the standardized format as requested.

SCRIPT CATEGORIES
=================

1. User Rights Assignment Scripts (2.2.x)
   - 49 scripts covering user rights and permissions
   - Uses secedit.exe for configuration
   - Automatic SID conversion for users/groups
   
2. Security Options Scripts (2.3.x)
   - 73 scripts covering security options
   - Uses registry edits and secedit.exe
   - Covers Account Policies, Audit Settings, Domain Settings, Network Settings, UAC

USAGE
=====
All scripts must be run as Administrator.

To run a single script:
  PS> .\2.2.1.ps1

To run all scripts in sequence:
  PS> Get-ChildItem -Filter *.ps1 | ForEach-Object { & $_.FullName }

FEATURES
========
✓ #Requires -RunAsAdministrator directive
✓ Automatic backup creation before changes
✓ Comprehensive error handling
✓ Domain Controller vs Member Server detection (where applicable)
✓ Manual remediation guidance on failure
✓ Clear remediation summaries

BACKUP
======
All scripts create automatic backups before making changes:
  Location: %TEMP%\secedit_backup_<timestamp>.cfg

To restore from backup:
  PS> secedit /configure /db secedit.sdb /cfg <backup_file>

STRUCTURE
=========
Each script contains:
1. Header with CIS control information
2. Synopsis and description
3. Parameter definitions
4. Remediation logic
5. Error handling
6. Manual remediation instructions

TESTING
=======
Always test scripts in a non-production environment first.
Review each script before execution.

SUPPORT
=======
For issues or questions, refer to the CIS Microsoft Windows Server 2022 Benchmark v4.0.0 documentation.

Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
