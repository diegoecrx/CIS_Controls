# 2.2.9.ps1 - 2.2.9 (L1) Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.9
