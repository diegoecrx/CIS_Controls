# 2.2.20.ps1 - 2.2.20 (L1) Ensure 'Debug programs' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.20
