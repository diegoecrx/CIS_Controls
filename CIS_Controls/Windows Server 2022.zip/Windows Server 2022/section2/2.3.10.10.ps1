# 2.3.10.10.ps1 - 2.3.10.10 (L1) Ensure 'Network access: Restrict anonymous access to Named Pipes and Shares' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.10.10
