# 2.3.11.3.ps1 - 2.3.11.3 (L1) Ensure 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.11.3
