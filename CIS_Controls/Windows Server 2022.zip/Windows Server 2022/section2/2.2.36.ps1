# 2.2.36.ps1 - 2.2.36 (L1) Ensure 'Lock pages in memory' is set to 'No One' (Automated)
# Generated placeholder for CIS control 2.2.36
