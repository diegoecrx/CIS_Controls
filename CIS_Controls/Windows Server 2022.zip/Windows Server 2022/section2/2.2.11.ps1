# 2.2.11.ps1 - 2.2.11 (L1) Ensure 'Back up files and directories' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.11
