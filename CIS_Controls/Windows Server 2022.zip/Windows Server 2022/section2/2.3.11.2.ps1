# 2.3.11.2.ps1 - 2.3.11.2 (L1) Ensure 'Network security: Allow LocalSystem NULL session fallback' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.11.2
