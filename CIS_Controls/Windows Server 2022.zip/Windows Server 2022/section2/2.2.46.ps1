# 2.2.46.ps1 - 2.2.46 (L1) Ensure 'Restore files and directories' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.46
