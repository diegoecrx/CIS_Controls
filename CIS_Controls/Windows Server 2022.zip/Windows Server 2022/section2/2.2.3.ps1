# 2.2.3.ps1 - 2.2.3 (L1) Ensure 'Access this computer from the network' is set to 'Administrators, Authenticated Users' (MS only) (Automated)
# Generated placeholder for CIS control 2.2.3
