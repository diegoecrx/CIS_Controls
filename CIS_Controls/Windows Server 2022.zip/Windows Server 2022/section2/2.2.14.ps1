# 2.2.14.ps1 - 2.2.14 (L1) Ensure 'Create a pagefile' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.14
