# 2.3.5.3.ps1 - 2.3.5.3 (L1) Ensure 'Domain controller: LDAP server channel binding token requirements' is set to 'Always' (DC Only) (Automated)
# Generated placeholder for CIS control 2.3.5.3
