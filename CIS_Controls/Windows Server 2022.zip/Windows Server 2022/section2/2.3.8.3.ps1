# 2.3.8.3.ps1 - 2.3.8.3 (L1) Ensure 'Microsoft network client: Send unencrypted password to third-party SMB servers' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.8.3
