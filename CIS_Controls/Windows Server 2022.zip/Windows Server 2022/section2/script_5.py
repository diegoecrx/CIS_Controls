
import pandas as pd
import os
import re

# Read the Excel file
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section2.xlsx', sheet_name='Recommendations')

# Create output directory
output_dir = "section2_scripts"
os.makedirs(output_dir, exist_ok=True)

# User rights mapping for secedit
user_rights_mapping = {
    "Access Credential Manager as a trusted caller": "SeTrustedCredManAccessPrivilege",
    "Access this computer from the network": "SeNetworkLogonRight",
    "Act as part of the operating system": "SeTcbPrivilege",
    "Add workstations to domain": "SeMachineAccountPrivilege",
    "Adjust memory quotas for a process": "SeIncreaseQuotaPrivilege",
    "Allow log on locally": "SeInteractiveLogonRight",
    "Allow log on through Remote Desktop Services": "SeRemoteInteractiveLogonRight",
    "Back up files and directories": "SeBackupPrivilege",
    "Change the system time": "SeSystemtimePrivilege",
    "Change the time zone": "SeTimeZonePrivilege",
    "Create a pagefile": "SeCreatePagefilePrivilege",
    "Create a token object": "SeCreateTokenPrivilege",
    "Create global objects": "SeCreateGlobalPrivilege",
    "Create permanent shared objects": "SeCreatePermanentPrivilege",
    "Create symbolic links": "SeCreateSymbolicLinkPrivilege",
    "Debug programs": "SeDebugPrivilege",
    "Deny access to this computer from the network": "SeDenyNetworkLogonRight",
    "Deny log on as a batch job": "SeDenyBatchLogonRight",
    "Deny log on as a service": "SeDenyServiceLogonRight",
    "Deny log on locally": "SeDenyInteractiveLogonRight",
    "Deny log on through Remote Desktop Services": "SeDenyRemoteInteractiveLogonRight",
    "Enable computer and user accounts to be trusted for delegation": "SeEnableDelegationPrivilege",
    "Force shutdown from a remote system": "SeRemoteShutdownPrivilege",
    "Generate security audits": "SeAuditPrivilege",
    "Impersonate a client after authentication": "SeImpersonatePrivilege",
    "Increase scheduling priority": "SeIncreaseBasePriorityPrivilege",
    "Load and unload device drivers": "SeLoadDriverPrivilege",
    "Lock pages in memory": "SeLockMemoryPrivilege",
    "Log on as a batch job": "SeBatchLogonRight",
    "Manage auditing and security log": "SeSecurityPrivilege",
    "Modify an object label": "SeRelabelPrivilege",
    "Modify firmware environment values": "SeSystemEnvironmentPrivilege",
    "Perform volume maintenance tasks": "SeManageVolumePrivilege",
    "Profile single process": "SeProfileSingleProcessPrivilege",
    "Profile system performance": "SeSystemProfilePrivilege",
    "Replace a process level token": "SeAssignPrimaryTokenPrivilege",
    "Restore files and directories": "SeRestorePrivilege",
    "Shut down the system": "SeShutdownPrivilege",
    "Synchronize directory service data": "SeSyncAgentPrivilege",
    "Take ownership of files or other objects": "SeTakeOwnershipPrivilege"
}

# Registry path mappings for Security Options
registry_mapping = {
    "Accounts: Guest account status": {
        "path": "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",
        "key": "AutoAdminLogon",
        "type": "DWord"
    },
    "Accounts: Limit local account use of blank passwords": {
        "path": "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa",
        "key": "LimitBlankPasswordUse",
        "type": "DWord"
    }
}

def extract_user_right(control_name):
    for right_name in user_rights_mapping.keys():
        if right_name in control_name:
            return right_name, user_rights_mapping[right_name]
    return None, None

def extract_recommended_value(control_name, remediation):
    """Extract the recommended value from control name or remediation"""
    match = re.search(r"is set to ['\"]([^'\"]+)['\"]", control_name)
    if match:
        return match.group(1)
    
    match = re.search(r"set to ['\"]([^'\"]+)['\"]", control_name)
    if match:
        return match.group(1)
    
    match = re.search(r"to include ['\"]([^'\"]+)['\"]", control_name)
    if match:
        return match.group(1)
    
    match = re.search(r"set the following UI path to ([^:\n\.]+)", remediation)
    if match:
        value = match.group(1).strip()
        return value
    
    return "See remediation details"

def convert_users_to_sids(users_string):
    """Convert common user/group names to SID format for secedit"""
    sid_mapping = {
        "No One": "",
        "No one": "",
        "None": "",
        "Administrators": "*S-1-5-32-544",
        "Authenticated Users": "*S-1-5-11",
        "ENTERPRISE DOMAIN CONTROLLERS": "*S-1-5-9",
        "LOCAL SERVICE": "*S-1-5-19",
        "NETWORK SERVICE": "*S-1-5-20",
        "SERVICE": "*S-1-5-6",
        "Guests": "*S-1-5-32-546",
        "Remote Desktop Users": "*S-1-5-32-555",
        "Window Manager\\Window Manager Group": "*S-1-5-90-0",
        "NT SERVICE\\WdiServiceHost": "*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420",
        "NT VIRTUAL MACHINE\\Virtual Machines": "*S-1-5-83-0",
        "IIS_IUSRS": "*S-1-5-32-568",
        "Everyone": "*S-1-1-0",
        "Pre-Windows 2000 Compatible Access": "*S-1-5-32-554",
        "Backup Operators": "*S-1-5-32-551",
        "Users": "*S-1-5-32-545",
        "Local account and member of Administrators group": "*S-1-5-113",
        "Local account": "*S-1-5-113"
    }
    
    if not users_string or users_string in ["No One", "No one", "None"]:
        return ""
    
    users = [u.strip() for u in users_string.split(',')]
    sids = []
    for user in users:
        if user in sid_mapping:
            sid = sid_mapping[user]
            if sid:  # Only add non-empty SIDs
                sids.append(sid)
    
    return ",".join(sids)

# Generate first 10 scripts to file
for idx in range(min(10, len(df))):
    script_id = str(df.loc[idx, 'script_name']).strip()
    control_name = str(df.loc[idx, 'control_name']).strip()
    profile = str(df.loc[idx, 'profile_applicability']).strip()
    remediation = str(df.loc[idx, 'remediation']).strip()
    default_value = str(df.loc[idx, 'default_value']).strip()
    
    is_manual = "(Manual)" in control_name
    is_automated = "(Automated)" in control_name
    right_name, secedit_name = extract_user_right(control_name)
    recommended_value = extract_recommended_value(control_name, remediation)
    
    # Determine if DC only, MS only, or both
    is_dc_only = "(DC only)" in control_name or "(DC Only)" in control_name
    is_ms_only = "(MS only)" in control_name or "(MS Only)" in control_name
    
    # Extract config path from remediation
    path_match = re.search(r"Computer Configuration\\\\([^\n]+)", remediation)
    config_path = path_match.group(0).replace("\\\\", "\\") if path_match else "See remediation details"
    
    filename = f"{script_id}.ps1"
    filepath = os.path.join(output_dir, filename)
    
    # Generate PowerShell script content based on type
    if right_name and secedit_name:
        # This is a User Rights Assignment
        sids = convert_users_to_sids(recommended_value)
        script_content = generate_user_rights_script(
            script_id, control_name, profile, remediation, default_value,
            is_manual, right_name, secedit_name, recommended_value, sids,
            is_dc_only, is_ms_only, config_path
        )
    else:
        # This is a Security Option or Registry setting
        script_content = generate_security_option_script(
            script_id, control_name, profile, remediation, default_value,
            is_manual, recommended_value, is_dc_only, is_ms_only, config_path
        )
    
    # Write to file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(script_content)

print(f"Generated first 10 scripts in: {output_dir}/")
print("\nSample files created:")
for i in range(min(10, len(df))):
    print(f"  - {df.loc[i, 'script_name']}.ps1")
