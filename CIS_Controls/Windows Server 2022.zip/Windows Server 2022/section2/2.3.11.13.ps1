# 2.3.11.13.ps1 - 2.3.11.13 (L1) Ensure 'Network security: Restrict NTLM: Audit NTLM authentication in this domain' is set to 'Enable all' (DC only) (Automated)
# Generated placeholder for CIS control 2.3.11.13
