# 2.3.9.3.ps1 - 2.3.9.3 (L1) Ensure 'Microsoft network server: Digitally sign communications (if client agrees)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.9.3
