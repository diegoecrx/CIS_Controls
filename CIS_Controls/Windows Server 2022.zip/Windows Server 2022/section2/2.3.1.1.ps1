# 2.3.1.1.ps1 - 2.3.1.1 (L1) Ensure 'Accounts: Guest account status' is set to 'Disabled' (MS only) (Automated)
# Generated placeholder for CIS control 2.3.1.1
