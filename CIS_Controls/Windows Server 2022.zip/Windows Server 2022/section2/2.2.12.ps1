# 2.2.12.ps1 - 2.2.12 (L1) Ensure 'Change the system time' is set to 'Administrators, LOCAL SERVICE' (Automated)
# Generated placeholder for CIS control 2.2.12
