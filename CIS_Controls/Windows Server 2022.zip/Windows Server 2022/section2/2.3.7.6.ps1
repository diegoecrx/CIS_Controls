# 2.3.7.6.ps1 - 2.3.7.6 (L2) Ensure 'Interactive logon: Number of previous logons to cache (in case domain controller is not available)' is set to '4 or fewer logon(s)' (MS only) (Automated)
# Generated placeholder for CIS control 2.3.7.6
