# 2.2.30.ps1 - 2.2.30 (L1) Ensure 'Force shutdown from a remote system' is set to 'Administrators' (Automated)
# Generated placeholder for CIS control 2.2.30
