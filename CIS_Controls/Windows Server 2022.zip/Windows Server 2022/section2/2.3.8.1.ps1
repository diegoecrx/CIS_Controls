# 2.3.8.1.ps1 - 2.3.8.1 (L1) Ensure 'Microsoft network client: Digitally sign communications (always)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.8.1
