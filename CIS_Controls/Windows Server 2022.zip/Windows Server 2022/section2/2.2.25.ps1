# 2.2.25.ps1 - 2.2.25 (L1) Ensure 'Deny log on locally' to include 'Guests' (Automated)
# Generated placeholder for CIS control 2.2.25
