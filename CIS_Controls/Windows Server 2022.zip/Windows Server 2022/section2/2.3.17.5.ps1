# 2.3.17.5.ps1 - 2.3.17.5 (L1) Ensure 'User Account Control: Only elevate UIAccess applications that are installed in secure locations' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.17.5
