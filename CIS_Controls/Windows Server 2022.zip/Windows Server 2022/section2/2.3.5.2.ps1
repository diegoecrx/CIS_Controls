# 2.3.5.2.ps1 - 2.3.5.2 (L1) Ensure 'Domain controller: Allow vulnerable Netlogon secure channel connections' is set to 'Not Configured' (DC Only) (Automated)
# Generated placeholder for CIS control 2.3.5.2
