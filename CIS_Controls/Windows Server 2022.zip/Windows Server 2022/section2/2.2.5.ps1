# 2.2.5.ps1 - 2.2.5 (L1) Ensure 'Add workstations to domain' is set to 'Administrators' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.5
