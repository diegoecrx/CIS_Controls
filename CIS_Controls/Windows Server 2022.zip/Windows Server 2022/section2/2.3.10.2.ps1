# 2.3.10.2.ps1 - 2.3.10.2 (L1) Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts' is set to 'Enabled' (MS only) (Automated)
# Generated placeholder for CIS control 2.3.10.2
