# 2.3.1.4.ps1
(& {
  Write-Output "Control: 2.3.1.4 (L1) Configure 'Accounts: Rename guest account' (Automated)"
  Write-Output "Note: Rename Guest account - manual configuration required"
  Write-Output "This setting requires manual configuration via Group Policy or Local Security Policy"
})
