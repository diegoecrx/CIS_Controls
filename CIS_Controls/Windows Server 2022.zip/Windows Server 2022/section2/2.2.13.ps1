# 2.2.13.ps1 - 2.2.13 (L1) Ensure 'Change the time zone' is set to 'Administrators, LOCAL SERVICE' (Automated)
# Generated placeholder for CIS control 2.2.13
