# 2.3.2.2.ps1 - 2.3.2.2 (L1) Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.2.2
