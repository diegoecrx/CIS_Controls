# 2.3.1.2.ps1 - 2.3.1.2 (L1) Ensure 'Accounts: Limit local account use of blank passwords to console logon only' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.1.2
