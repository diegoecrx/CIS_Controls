# 2.3.11.7.ps1 - 2.3.11.7 (L1) Ensure 'Network security: LAN Manager authentication level' is set to 'Send NTLMv2 response only. Refuse LM & NTLM' (Automated)
# Generated placeholder for CIS control 2.3.11.7
