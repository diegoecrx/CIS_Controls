# 2.2.6.ps1 - 2.2.6 (L1) Ensure 'Adjust memory quotas for a process' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE' (Automated)
# Generated placeholder for CIS control 2.2.6
