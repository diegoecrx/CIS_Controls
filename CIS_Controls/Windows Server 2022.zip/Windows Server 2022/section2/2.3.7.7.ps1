# 2.3.7.7.ps1 - 2.3.7.7 (L1) Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days' (Automated)
# Generated placeholder for CIS control 2.3.7.7
