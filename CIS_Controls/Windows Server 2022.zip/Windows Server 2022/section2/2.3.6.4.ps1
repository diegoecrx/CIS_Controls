# 2.3.6.4.ps1 - 2.3.6.4 (L1) Ensure 'Domain member: Disable machine account password changes' is set to 'Disabled' (Automated)
# Generated placeholder for CIS control 2.3.6.4
