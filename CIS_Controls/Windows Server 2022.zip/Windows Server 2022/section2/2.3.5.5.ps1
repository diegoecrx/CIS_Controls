# 2.3.5.5.ps1 - 2.3.5.5 (L1) Ensure 'Domain controller: Refuse machine account password changes' is set to 'Disabled' (DC only) (Automated)
# Generated placeholder for CIS control 2.3.5.5
