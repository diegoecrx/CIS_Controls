# 2.2.18.ps1 - 2.2.18 (L1) Ensure 'Create symbolic links' is set to 'Administrators' (DC only) (Automated)
# Generated placeholder for CIS control 2.2.18
