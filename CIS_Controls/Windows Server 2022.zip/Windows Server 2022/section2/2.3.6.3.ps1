# 2.3.6.3.ps1 - 2.3.6.3 (L1) Ensure 'Domain member: Digitally sign secure channel data (when possible)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.6.3
