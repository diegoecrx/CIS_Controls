# 2.2.23.ps1 - 2.2.23 (L1) Ensure 'Deny log on as a batch job' to include 'Guests' (Automated)
# Generated placeholder for CIS control 2.2.23
