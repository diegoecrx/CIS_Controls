# 2.3.10.4.ps1 - 2.3.10.4 (L2) Ensure 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.10.4
