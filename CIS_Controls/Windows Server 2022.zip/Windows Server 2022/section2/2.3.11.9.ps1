# 2.3.11.9.ps1 - 2.3.11.9 (L1) Ensure 'Network security: LDAP client signing requirements' is set to 'Negotiate signing' or higher (Automated)
# Generated placeholder for CIS control 2.3.11.9
