# 2.3.1.4.ps1 - 2.3.1.4 (L1) Configure 'Accounts: Rename guest account' (Automated)
# Generated placeholder for CIS control 2.3.1.4
