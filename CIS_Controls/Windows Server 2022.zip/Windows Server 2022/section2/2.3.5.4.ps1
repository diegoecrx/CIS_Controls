# 2.3.5.4.ps1 - 2.3.5.4 (L1) Ensure 'Domain controller: LDAP server signing requirements' is set to 'Require signing' (DC only) (Automated)
# Generated placeholder for CIS control 2.3.5.4
