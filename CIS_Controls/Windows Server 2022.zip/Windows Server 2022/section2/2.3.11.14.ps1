# 2.3.11.14.ps1 - 2.3.11.14 (L1) Ensure 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher (Automated)
# Generated placeholder for CIS control 2.3.11.14
