# 2.3.15.2.ps1 - 2.3.15.2 (L1) Ensure 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)' is set to 'Enabled' (Automated)
# Generated placeholder for CIS control 2.3.15.2
