# 2.3.9.4)..ps1 - 2.3.9.4). The recommended state for this setting is: Enabled.
# Generated placeholder for CIS control 2.3.9.4).
