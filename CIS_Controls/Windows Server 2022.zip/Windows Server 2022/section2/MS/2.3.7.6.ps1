# 2.3.7.6.ps1
(& {
  Write-Output "Control: 2.3.7.6 (L2) Ensure 'Interactive logon: Number of previous logons to cache (in case domain controller is not available)' is set to '4 or fewer logon(s)' (MS only) (Automated)"
  Write-Output "Note: Configure legal notice message text"
  Write-Output "This setting requires manual configuration via Group Policy or Local Security Policy"
})
