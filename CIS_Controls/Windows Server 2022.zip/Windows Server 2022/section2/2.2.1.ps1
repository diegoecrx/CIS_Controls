# 2.2.1.ps1 - 2.2.1 (L1) Ensure 'Access Credential Manager as a trusted caller' is set to 'No One' (Automated)
# Generated placeholder for CIS control 2.2.1
