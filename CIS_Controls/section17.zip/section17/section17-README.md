###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark - Section 17 Scripts
# README for Advanced Audit Policy Configuration Scripts
###############################################################################

OVERVIEW
========
This package contains 34 PowerShell remediation scripts for CIS Microsoft Windows Server 2022 Benchmark Section 17.
All scripts configure Advanced Audit Policy settings to ensure comprehensive security event logging.

AUDIT CATEGORIES
================

17.1.x - Account Logon (3 scripts)
------------------------------------
17.1.1 - Audit Credential Validation
17.1.2 - Audit Kerberos Authentication Service (DC only)
17.1.3 - Audit Kerberos Service Ticket Operations (DC only)

17.2.x - Account Management (6 scripts)
----------------------------------------
17.2.1 - Audit Application Group Management
17.2.2 - Audit Computer Account Management (DC only)
17.2.3 - Audit Distribution Group Management (DC only)
17.2.4 - Audit Other Account Management Events (DC only)
17.2.5 - Audit Security Group Management
17.2.6 - Audit User Account Management

17.3.x - Detailed Tracking (2 scripts)
---------------------------------------
17.3.1 - Audit PNP Activity
17.3.2 - Audit Process Creation

17.4.x - DS Access (2 scripts)
------------------------------
17.4.1 - Audit Directory Service Access (DC only)
17.4.2 - Audit Directory Service Changes (DC only)

17.5.x - Logon/Logoff (6 scripts)
----------------------------------
17.5.1 - Audit Account Lockout
17.5.2 - Audit Group Membership
17.5.3 - Audit Logoff
17.5.4 - Audit Logon
17.5.5 - Audit Other Logon/Logoff Events
17.5.6 - Audit Special Logon

17.6.x - Object Access (4 scripts)
-----------------------------------
17.6.1 - Audit Detailed File Share
17.6.2 - Audit File Share
17.6.3 - Audit Other Object Access Events
17.6.4 - Audit Removable Storage

17.7.x - Policy Change (5 scripts)
-----------------------------------
17.7.1 - Audit Audit Policy Change
17.7.2 - Audit Authentication Policy Change
17.7.3 - Audit Authorization Policy Change
17.7.4 - Audit MPSSVC Rule-Level Policy Change
17.7.5 - Audit Other Policy Change Events

17.8.x - Privilege Use (1 script)
----------------------------------
17.8.1 - Audit Sensitive Privilege Use

17.9.x - System (5 scripts)
----------------------------
17.9.1 - Audit IPsec Driver
17.9.2 - Audit Other System Events
17.9.3 - Audit Security State Change
17.9.4 - Audit Security System Extension
17.9.5 - Audit System Integrity

PROFILE APPLICABILITY
=====================
Most scripts apply to:
• Level 1 - Domain Controller
• Level 1 - Member Server

Some scripts are DC-only or MS-only (clearly marked in control name)

USAGE
=====
All scripts must be run as Administrator.

Run individual script:
  PS> .\17.1.1.ps1

Run all Account Logon audit scripts:
  PS> Get-ChildItem -Filter 17.1.*.ps1 | ForEach-Object { & $_.FullName }

Run all Account Management audit scripts:
  PS> Get-ChildItem -Filter 17.2.*.ps1 | ForEach-Object { & $_.FullName }

Run ALL audit policy scripts:
  PS> Get-ChildItem -Filter 17.*.ps1 | Sort-Object Name | ForEach-Object { & $_.FullName }

WHAT THE SCRIPTS DO
===================
1. Detect system type (Domain Controller or Member Server)
2. Skip execution if control doesn't apply to system type
3. Query current audit policy setting using auditpol.exe
4. Apply CIS-recommended audit configuration
5. Verify configuration after changes
6. Provide detailed status reporting

FEATURES
========
✓ Uses native auditpol.exe utility
✓ Automatic DC/MS detection and filtering
✓ Current audit policy reporting
✓ Configuration verification
✓ Comprehensive error handling
✓ Manual remediation guidance
✓ All Level 1 controls

AUDIT SETTINGS EXPLAINED
=========================

Success:
  - Logs successful events
  - Example: Successful logon, successful account creation

Failure:
  - Logs failed events
  - Example: Failed logon attempts, failed privilege use

Success and Failure:
  - Logs both successful and failed events
  - Provides complete audit trail
  - Recommended for most security-sensitive operations

WHY AUDIT POLICIES MATTER
==========================

Security Benefits:
  ✓ Detect unauthorized access attempts
  ✓ Track privileged account usage
  ✓ Identify policy violations
  ✓ Support forensic investigations
  ✓ Meet compliance requirements
  ✓ Enable security incident response

Without proper auditing:
  ✗ Security breaches may go undetected
  ✗ Insider threats are invisible
  ✗ Compliance violations occur
  ✗ Forensic analysis is impossible
  ✗ No accountability trail

IMPACT ASSESSMENT
=================

Performance Impact:
  - Minimal CPU/memory overhead
  - Moderate disk I/O for logging
  - Security Event Log will grow faster

Storage Requirements:
  - Increase Security Event Log size
  - Recommended: 1 GB or larger
  - Consider log forwarding/archival

Recommended Pre-Deployment:
  1. Increase Security Event Log size
  2. Configure log retention policy
  3. Set up centralized log collection (SIEM)
  4. Test in non-production first
  5. Monitor log growth for first week

VERIFICATION
============

Check all audit policy settings:
  PS> auditpol /get /category:*

Check specific audit policy:
  PS> auditpol /get /subcategory:"Credential Validation"

Export current audit policy:
  PS> auditpol /backup /file:C:\audit_policy_backup.csv

View Security Event Log:
  PS> Get-EventLog -LogName Security -Newest 50

Check Security Event Log size:
  PS> Get-EventLog -LogName Security | Select-Object MaximumKilobytes, MinimumRetentionDays

SECURITY EVENT LOG CONFIGURATION
=================================

Increase Security Event Log size:
  PS> Limit-EventLog -LogName Security -MaximumSize 1GB

Configure log retention:
  PS> Limit-EventLog -LogName Security -OverflowAction OverwriteAsNeeded

Via Registry:
  Path: HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Security
  MaxSize (DWORD): 1073741824 (1 GB in bytes)

Via Group Policy:
  Computer Configuration > Policies > Administrative Templates > 
  Windows Components > Event Log Service > Security >
  "Specify the maximum log file size (KB)"

KEY EVENT IDS TO MONITOR
=========================

Account Logon:
  4768 - Kerberos authentication ticket (TGT) requested
  4769 - Kerberos service ticket requested
  4771 - Kerberos pre-authentication failed

Account Management:
  4720 - User account created
  4722 - User account enabled
  4724 - Password reset attempt
  4725 - User account disabled
  4726 - User account deleted
  4728 - Member added to security-enabled global group
  4732 - Member added to security-enabled local group

Logon/Logoff:
  4624 - Successful account logon
  4625 - Failed account logon
  4634 - Account logged off
  4647 - User initiated logoff
  4648 - Logon using explicit credentials

Object Access:
  5140 - Network share accessed
  5145 - Network share object checked for access

Policy Change:
  4719 - System audit policy changed
  4739 - Domain policy changed

Privilege Use:
  4672 - Special privileges assigned to new logon
  4673 - Privileged service called

System:
  4697 - Service installed on system
  4946 - Windows Firewall rule added

CENTRALIZED LOGGING
====================

For enterprise environments, configure:

Windows Event Forwarding (WEF):
  1. Configure event subscriptions
  2. Point clients to collector server
  3. Consolidate logs centrally

SIEM Integration:
  - Splunk
  - Microsoft Sentinel
  - Elastic Security
  - IBM QRadar
  - ArcSight

Benefits:
  ✓ Centralized log analysis
  ✓ Real-time alerting
  ✓ Long-term retention
  ✓ Correlation across systems
  ✓ Compliance reporting

TROUBLESHOOTING
===============

If audit policy doesn't apply:

1. Check Group Policy application:
   PS> gpresult /h gpresult.html

2. Verify audit policy precedence:
   Advanced Audit Policy > Basic Audit Policy

3. Ensure "Force audit policy subcategory" is enabled:
   Computer Configuration > Policies > Windows Settings > 
   Security Settings > Local Policies > Security Options >
   "Audit: Force audit policy subcategory settings..."

4. Check auditpol directly:
   auditpol /get /category:"Account Logon"

5. Clear and reapply:
   auditpol /clear /y
   gpupdate /force

BACKUP AND RESTORE
==================

Backup current audit policy:
  auditpol /backup /file:C:\audit_backup.csv

Restore audit policy from backup:
  auditpol /restore /file:C:\audit_backup.csv

Reset to default:
  auditpol /clear /y

ROLLBACK
========

To disable all audit policies (NOT RECOMMENDED):
  auditpol /clear /y

To restore previous state:
  auditpol /restore /file:<backup_file>

Via Group Policy:
  1. Open gpedit.msc
  2. Navigate to Advanced Audit Policy Configuration
  3. Set policies to "Not Configured"
  4. Run: gpupdate /force

ALTERNATIVE METHODS
===================

If PowerShell scripts cannot be used:

Method 1 - Group Policy:
  1. Open gpedit.msc
  2. Navigate to: Computer Configuration > Policies > Windows Settings > 
     Security Settings > Advanced Audit Policy Configuration > Audit Policies
  3. Configure each audit subcategory
  4. Run: gpupdate /force

Method 2 - auditpol.exe directly:
  auditpol /set /subcategory:"Credential Validation" /success:enable /failure:enable
  auditpol /set /subcategory:"Account Lockout" /success:disable /failure:enable

Method 3 - Import from CSV:
  Create audit policy CSV file
  auditpol /restore /file:audit_policy.csv

BEST PRACTICES
==============

1. Deploy scripts in order:
   - Start with Account Logon (17.1.x)
   - Then Account Management (17.2.x)
   - Continue through remaining categories

2. Configure log infrastructure FIRST:
   - Increase Security Event Log size (1 GB minimum)
   - Set up log forwarding
   - Configure retention policy

3. Monitor after deployment:
   - Check Security Event Log daily
   - Verify log growth is manageable
   - Confirm events are being generated

4. Regular maintenance:
   - Archive old logs monthly
   - Review audit policy quarterly
   - Update SIEM correlation rules

5. Documentation:
   - Document baseline audit policy
   - Track all changes
   - Maintain runbooks for common events

TESTING
=======
Always test in non-production environment first.
Verify log collection and alerting work correctly.

COMPLIANCE
==========
These audit policies help meet requirements for:
  - PCI DSS (Payment Card Industry Data Security Standard)
  - HIPAA (Health Insurance Portability and Accountability Act)
  - SOX (Sarbanes-Oxley Act)
  - GDPR (General Data Protection Regulation)
  - NIST 800-53 (Security and Privacy Controls)
  - ISO 27001 (Information Security Management)

SUPPORT
=======
For issues or questions, refer to:
  - CIS Microsoft Windows Server 2022 Benchmark v4.0.0
  - Microsoft Windows Security Auditing documentation
  - auditpol.exe command reference

ADDITIONAL RESOURCES
====================
- Windows Security Auditing: https://docs.microsoft.com/en-us/windows/security/threat-protection/auditing/
- auditpol command: https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/auditpol
- Security Event IDs: https://www.ultimatewindowssecurity.com/securitylog/encyclopedia/

Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
