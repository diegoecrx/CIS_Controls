
import pandas as pd
import os
import re
import zipfile

# Read the Excel file for section 9
df = pd.read_excel('CIS_Microsoft_Windows_Server_2022_Benchmark_v4.0.0_section9.xlsx', sheet_name='Recommendations')

# Create output directory
output_dir = "section9_scripts"
os.makedirs(output_dir, exist_ok=True)

print("Generating Section 9 PowerShell Scripts")
print("="*80)
print(f"Total scripts to generate: {len(df)}\n")

# Mapping of firewall profiles
profile_mapping = {
    "Domain": "Domain",
    "Private": "Private",
    "Public": "Public"
}

def extract_firewall_profile(control_name):
    """Extract firewall profile from control name"""
    if "Domain:" in control_name:
        return "Domain"
    elif "Private:" in control_name:
        return "Private"
    elif "Public:" in control_name:
        return "Public"
    return None

def extract_firewall_setting(control_name):
    """Extract the specific firewall setting being configured"""
    if "Firewall state" in control_name:
        return "FirewallState", "Enabled"
    elif "Inbound connections" in control_name:
        return "InboundConnections", "Block"
    elif "Display a notification" in control_name:
        return "Notification", "False"
    elif "Apply local firewall rules" in control_name:
        return "AllowLocalFirewallRules", "False"
    elif "Apply local connection security rules" in control_name:
        return "AllowLocalIPsecRules", "False"
    elif "Logging: Name" in control_name:
        if "domainfw.log" in control_name:
            return "LogFileName", "%SystemRoot%\\System32\\logfiles\\firewall\\domainfw.log"
        elif "privatefw.log" in control_name:
            return "LogFileName", "%SystemRoot%\\System32\\logfiles\\firewall\\privatefw.log"
        elif "publicfw.log" in control_name:
            return "LogFileName", "%SystemRoot%\\System32\\logfiles\\firewall\\publicfw.log"
    elif "Size limit (KB)" in control_name:
        return "LogMaxSizeKilobytes", "16384"
    elif "Log dropped packets" in control_name:
        return "LogDroppedPackets", "True"
    elif "Log successful connections" in control_name:
        return "LogAllowedPackets", "True"
    
    return "Unknown", "Unknown"

# Generate all scripts
generated_count = 0

for idx in range(len(df)):
    script_id = str(df.loc[idx, 'script_name']).strip()
    control_name = str(df.loc[idx, 'control_name']).strip()
    profile = str(df.loc[idx, 'profile_applicability']).strip()
    remediation = str(df.loc[idx, 'remediation']).strip()
    default_value = str(df.loc[idx, 'default_value']).strip()
    
    fw_profile = extract_firewall_profile(control_name)
    setting_name, setting_value = extract_firewall_setting(control_name)
    
    filename = f"{script_id}.ps1"
    filepath = os.path.join(output_dir, filename)
    
    # Generate PowerShell script for Windows Firewall configuration
    script_content = f'''###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# {script_id}.ps1
# CIS Control - {control_name}
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control {script_id}

.DESCRIPTION
    This script configures Windows Firewall {fw_profile} profile settings
    per CIS {script_id} control for Windows Server 2022.
    
    Profile Applicability: 
    {profile}
    
    Default value: {default_value}

.NOTES
    Requires: Run as Administrator
    Uses: PowerShell NetSecurity module and Registry
    
    Remediation Path: Computer Configuration\\Policies\\Windows Settings\\Security Settings\\
                      Windows Defender Firewall with Advanced Security\\Windows Defender Firewall Properties
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "{script_id}.ps1"
$CONTROL_NAME = "{control_name}"
$FIREWALL_PROFILE = "{fw_profile}"
$SETTING_NAME = "{setting_name}"
$RECOMMENDED_VALUE = "{setting_value}"
$DEFAULT_VALUE = "{default_value}"

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Configure Windows Firewall {fw_profile} Profile"
Write-Host ""
Write-Host "Profile Applicability: {profile}"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host "Recommended value: $RECOMMENDED_VALUE"
Write-Host ""

Write-Host "Remediation Details:"
Write-Host ""

try {{
    # Import NetSecurity module
    Import-Module NetSecurity -ErrorAction Stop
    
    # Get current firewall profile settings
    $currentProfile = Get-NetFirewallProfile -Name $FIREWALL_PROFILE -ErrorAction Stop
    
    Write-Host "[INFO] Current $FIREWALL_PROFILE Profile Configuration:"
    Write-Host "  - Enabled: $($currentProfile.Enabled)"
    Write-Host "  - DefaultInboundAction: $($currentProfile.DefaultInboundAction)"
    Write-Host "  - DefaultOutboundAction: $($currentProfile.DefaultOutboundAction)"
    Write-Host ""
    
    # Apply configuration based on setting type
    $configApplied = $false
    
    if ($SETTING_NAME -eq "FirewallState") {{
        Write-Host "[ACTION] Enabling Windows Firewall for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -Enabled True -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "InboundConnections") {{
        Write-Host "[ACTION] Setting default inbound action to Block for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -DefaultInboundAction Block -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "Notification") {{
        Write-Host "[ACTION] Disabling notifications for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -NotifyOnListen False -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "AllowLocalFirewallRules") {{
        Write-Host "[ACTION] Disabling local firewall rules for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -AllowLocalFirewallRules False -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "AllowLocalIPsecRules") {{
        Write-Host "[ACTION] Disabling local IPsec rules for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -AllowLocalIPsecRules False -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "LogFileName") {{
        Write-Host "[ACTION] Setting log file path for $FIREWALL_PROFILE profile..."
        $logPath = [Environment]::ExpandEnvironmentVariables("$RECOMMENDED_VALUE")
        
        # Ensure log directory exists
        $logDir = Split-Path -Path $logPath -Parent
        if (-not (Test-Path -Path $logDir)) {{
            New-Item -Path $logDir -ItemType Directory -Force | Out-Null
            Write-Host "[INFO] Created log directory: $logDir"
        }}
        
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogFileName $logPath -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "LogMaxSizeKilobytes") {{
        Write-Host "[ACTION] Setting log file size limit to $RECOMMENDED_VALUE KB for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogMaxSizeKilobytes $RECOMMENDED_VALUE -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "LogDroppedPackets") {{
        Write-Host "[ACTION] Enabling logging of dropped packets for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogBlocked True -ErrorAction Stop
        $configApplied = $true
    }}
    elseif ($SETTING_NAME -eq "LogAllowedPackets") {{
        Write-Host "[ACTION] Enabling logging of successful connections for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogAllowed True -ErrorAction Stop
        $configApplied = $true
    }}
    
    if ($configApplied) {{
        # Verify the configuration
        $updatedProfile = Get-NetFirewallProfile -Name $FIREWALL_PROFILE
        Write-Host ""
        Write-Host "[VERIFICATION] Updated $FIREWALL_PROFILE Profile Configuration:"
        Write-Host "  - Enabled: $($updatedProfile.Enabled)"
        Write-Host "  - DefaultInboundAction: $($updatedProfile.DefaultInboundAction)"
        Write-Host "  - NotifyOnListen: $($updatedProfile.NotifyOnListen)"
        Write-Host ""
        
        Write-Host "[SUCCESS] Windows Firewall $FIREWALL_PROFILE profile configured successfully"
    }}
    
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation Summary:"
    Write-Host "- Control: {script_id}"
    Write-Host "- Status: COMPLETED"
    Write-Host "- Firewall Profile: $FIREWALL_PROFILE"
    Write-Host "- Setting: $SETTING_NAME"
    Write-Host "- Value: $RECOMMENDED_VALUE"
    Write-Host "=============================================="
    
}} catch {{
    Write-Host ""
    Write-Host "[ERROR] Failed to apply remediation automatically."
    Write-Host "Error details: $_"
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "MANUAL REMEDIATION REQUIRED"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Please configure manually via Group Policy Editor:"
    Write-Host ""
    Write-Host "Path: Computer Configuration > Policies > Windows Settings > Security Settings"
    Write-Host "      > Windows Defender Firewall with Advanced Security"
    Write-Host "      > Windows Defender Firewall Properties"
    Write-Host ""
    Write-Host "Steps:"
    Write-Host "1. Open Group Policy Editor (gpedit.msc)"
    Write-Host "2. Navigate to the path above"
    Write-Host "3. Select the '$FIREWALL_PROFILE Profile' tab"
    Write-Host "4. Configure the setting as specified in the control"
    Write-Host "5. Click OK and apply the policy"
    Write-Host "6. Run 'gpupdate /force' to apply changes"
    Write-Host ""
    Write-Host "Alternative using PowerShell:"
    Write-Host "  Set-NetFirewallProfile -Name $FIREWALL_PROFILE -<SettingParameter> <Value>"
    Write-Host ""
    Write-Host "=============================================="
}}

Write-Host ""
Write-Host ""
Write-Host ""
'''
    
    # Write to file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    generated_count += 1
    print(f"✓ Generated: {filename}")

print(f"\n✓ Successfully generated {generated_count} PowerShell scripts")
print(f"✓ Location: {output_dir}/")

# Create a ZIP file for easy download
zip_filename = "CIS_Section9_Scripts.zip"
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(output_dir):
        for file in files:
            file_path = os.path.join(root, file)
            zipf.write(file_path, os.path.basename(file_path))

print(f"\n✓ Created ZIP archive: {zip_filename}")
print(f"✓ Total size: {os.path.getsize(zip_filename) / 1024:.2f} KB")
print("\nAll Section 9 scripts are ready for deployment!")
