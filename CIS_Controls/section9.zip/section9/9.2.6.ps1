###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 9.2.6.ps1
# CIS Control - 9.2.6 (L1) Ensure 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes' (Automated)
# 
# This script implements proper CIS controls with comprehensive error handling
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 9.2.6

.DESCRIPTION
    This script configures Windows Firewall Private profile settings
    per CIS 9.2.6 control for Windows Server 2022.

    Profile Applicability: 
    • Level 1 - Domain Controller
• Level 1 - Member Server

    Default value: No (default). (Information about dropped packets will not be recorded in the firewall log
file.)

.NOTES
    Requires: Run as Administrator
    Uses: PowerShell NetSecurity module and Registry

    Remediation Path: Computer Configuration\Policies\Windows Settings\Security Settings\
                      Windows Defender Firewall with Advanced Security\Windows Defender Firewall Properties
#>

#Requires -RunAsAdministrator

# Script parameters
$SCRIPT_NAME = "9.2.6.ps1"
$CONTROL_NAME = "9.2.6 (L1) Ensure 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes' (Automated)"
$FIREWALL_PROFILE = "Private"
$SETTING_NAME = "LogDroppedPackets"
$RECOMMENDED_VALUE = "True"
$DEFAULT_VALUE = "No (default). (Information about dropped packets will not be recorded in the firewall log
file.)"

Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Configure Windows Firewall Private Profile"
Write-Host ""
Write-Host "Profile Applicability: • Level 1 - Domain Controller
• Level 1 - Member Server"
Write-Host "Default value: $DEFAULT_VALUE"
Write-Host "Recommended value: $RECOMMENDED_VALUE"
Write-Host ""

Write-Host "Remediation Details:"
Write-Host ""

try {
    # Import NetSecurity module
    Import-Module NetSecurity -ErrorAction Stop

    # Get current firewall profile settings
    $currentProfile = Get-NetFirewallProfile -Name $FIREWALL_PROFILE -ErrorAction Stop

    Write-Host "[INFO] Current $FIREWALL_PROFILE Profile Configuration:"
    Write-Host "  - Enabled: $($currentProfile.Enabled)"
    Write-Host "  - DefaultInboundAction: $($currentProfile.DefaultInboundAction)"
    Write-Host "  - DefaultOutboundAction: $($currentProfile.DefaultOutboundAction)"
    Write-Host ""

    # Apply configuration based on setting type
    $configApplied = $false

    if ($SETTING_NAME -eq "FirewallState") {
        Write-Host "[ACTION] Enabling Windows Firewall for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -Enabled True -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "InboundConnections") {
        Write-Host "[ACTION] Setting default inbound action to Block for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -DefaultInboundAction Block -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "Notification") {
        Write-Host "[ACTION] Disabling notifications for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -NotifyOnListen False -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "AllowLocalFirewallRules") {
        Write-Host "[ACTION] Disabling local firewall rules for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -AllowLocalFirewallRules False -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "AllowLocalIPsecRules") {
        Write-Host "[ACTION] Disabling local IPsec rules for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -AllowLocalIPsecRules False -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "LogFileName") {
        Write-Host "[ACTION] Setting log file path for $FIREWALL_PROFILE profile..."
        $logPath = [Environment]::ExpandEnvironmentVariables("$RECOMMENDED_VALUE")

        # Ensure log directory exists
        $logDir = Split-Path -Path $logPath -Parent
        if (-not (Test-Path -Path $logDir)) {
            New-Item -Path $logDir -ItemType Directory -Force | Out-Null
            Write-Host "[INFO] Created log directory: $logDir"
        }

        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogFileName $logPath -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "LogMaxSizeKilobytes") {
        Write-Host "[ACTION] Setting log file size limit to $RECOMMENDED_VALUE KB for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogMaxSizeKilobytes $RECOMMENDED_VALUE -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "LogDroppedPackets") {
        Write-Host "[ACTION] Enabling logging of dropped packets for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogBlocked True -ErrorAction Stop
        $configApplied = $true
    }
    elseif ($SETTING_NAME -eq "LogAllowedPackets") {
        Write-Host "[ACTION] Enabling logging of successful connections for $FIREWALL_PROFILE profile..."
        Set-NetFirewallProfile -Name $FIREWALL_PROFILE -LogAllowed True -ErrorAction Stop
        $configApplied = $true
    }

    if ($configApplied) {
        # Verify the configuration
        $updatedProfile = Get-NetFirewallProfile -Name $FIREWALL_PROFILE
        Write-Host ""
        Write-Host "[VERIFICATION] Updated $FIREWALL_PROFILE Profile Configuration:"
        Write-Host "  - Enabled: $($updatedProfile.Enabled)"
        Write-Host "  - DefaultInboundAction: $($updatedProfile.DefaultInboundAction)"
        Write-Host "  - NotifyOnListen: $($updatedProfile.NotifyOnListen)"
        Write-Host ""

        Write-Host "[SUCCESS] Windows Firewall $FIREWALL_PROFILE profile configured successfully"
    }

    Write-Host ""
    Write-Host "=============================================="
    Write-Host "Remediation Summary:"
    Write-Host "- Control: 9.2.6"
    Write-Host "- Status: COMPLETED"
    Write-Host "- Firewall Profile: $FIREWALL_PROFILE"
    Write-Host "- Setting: $SETTING_NAME"
    Write-Host "- Value: $RECOMMENDED_VALUE"
    Write-Host "=============================================="

} catch {
    Write-Host ""
    Write-Host "[ERROR] Failed to apply remediation automatically."
    Write-Host "Error details: $_"
    Write-Host ""
    Write-Host "=============================================="
    Write-Host "MANUAL REMEDIATION REQUIRED"
    Write-Host "=============================================="
    Write-Host ""
    Write-Host "Please configure manually via Group Policy Editor:"
    Write-Host ""
    Write-Host "Path: Computer Configuration > Policies > Windows Settings > Security Settings"
    Write-Host "      > Windows Defender Firewall with Advanced Security"
    Write-Host "      > Windows Defender Firewall Properties"
    Write-Host ""
    Write-Host "Steps:"
    Write-Host "1. Open Group Policy Editor (gpedit.msc)"
    Write-Host "2. Navigate to the path above"
    Write-Host "3. Select the '$FIREWALL_PROFILE Profile' tab"
    Write-Host "4. Configure the setting as specified in the control"
    Write-Host "5. Click OK and apply the policy"
    Write-Host "6. Run 'gpupdate /force' to apply changes"
    Write-Host ""
    Write-Host "Alternative using PowerShell:"
    Write-Host "  Set-NetFirewallProfile -Name $FIREWALL_PROFILE -<SettingParameter> <Value>"
    Write-Host ""
    Write-Host "=============================================="
}

Write-Host ""
Write-Host ""
Write-Host ""
