# 17.1.3.ps1
(& {
  $subcategory = "Kerberos Service Ticket Operations"
  $after = "Success and Failure"
  $dcOnly = $true

  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $isDC = $role -in 4,5

  # Check if this is a DC-only control
  if ($dcOnly -and -not $isDC) {
    Write-Output "Control: 17.1.3 (L1) Ensure 'Audit Kerberos Service Ticket Operations' is set to 'Success and Failure' (DC Only) (Automated)"
    Write-Output "Note: This control applies to Domain Controllers only"
    return
  }

  try {
    # Get current audit policy setting
    $currentSetting = auditpol /get /subcategory:"$subcategory" 2>$null
    $current = "Not Configured"

    if ($currentSetting -match "Success and Failure") {
      $current = "Success and Failure"
    }
    elseif ($currentSetting -match "Success") {
      $current = "Success"
    }
    elseif ($currentSetting -match "Failure") {
      $current = "Failure"
    }
    elseif ($currentSetting -match "No Auditing") {
      $current = "No Auditing"
    }

    # Apply remediation using auditpol
    auditpol /set /subcategory:"$subcategory" /success:enable /failure:enable | Out-Null

    Write-Output "Control: 17.1.3 (L1) Ensure 'Audit Kerberos Service Ticket Operations' is set to 'Success and Failure' (DC Only) (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Advanced Audit Policy Configuration\Audit Policies"
    Write-Output "Name: $subcategory"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 17.1.3 (L1) Ensure 'Audit Kerberos Service Ticket Operations' is set to 'Success and Failure' (DC Only) (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
