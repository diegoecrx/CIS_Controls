# 18.9.39.3.ps1
(& {
  $regKey = "HKLM:\SYSTEM\CurrentControlSet\Control\SAM"
  $regValue = "ChangePasswordRPCPolicy"
  $after = 2
  $valueType = "DWord"
  $dcOnly = $false
  $msOnly = $true

  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $isDC = $role -in 4,5

  if ($dcOnly -and -not $isDC) {
    Write-Output "Control: 18.9.39.3 (L1) Ensure 'Configure SAM change password RPC methods policy' is set to 'Enabled: Block all change password RPC methods' (MS only) (Automated)"
    Write-Output "Note: This control applies to Domain Controllers only"
    return
  }

  if ($msOnly -and $isDC) {
    Write-Output "Control: 18.9.39.3 (L1) Ensure 'Configure SAM change password RPC methods policy' is set to 'Enabled: Block all change password RPC methods' (MS only) (Automated)"
    Write-Output "Note: This control applies to Member Servers only"
    return
  }

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.9.39.3 (L1) Ensure 'Configure SAM change password RPC methods policy' is set to 'Enabled: Block all change password RPC methods' (MS only) (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies"
    Write-Output "Name: ChangePasswordRPCPolicy"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.9.39.3 (L1) Ensure 'Configure SAM change password RPC methods policy' is set to 'Enabled: Block all change password RPC methods' (MS only) (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
