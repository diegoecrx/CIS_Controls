# 18.10.89.2.1.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows"
  $regValue = "AllowBasicauthentication"
  $after = 0
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.10.89.2.1 (L1) Ensure 'Allow Basic authentication' is set to 'Disabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: AllowBasicauthentication"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.10.89.2.1 (L1) Ensure 'Allow Basic authentication' is set to 'Disabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
