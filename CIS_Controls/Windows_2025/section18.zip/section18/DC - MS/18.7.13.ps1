# 18.7.13.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint"
  $regValue = "UpdatePromptSettings"
  $after = 0
  $valueType = "DWord"
  $dcOnly = $false
  $msOnly = $false

  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $isDC = $role -in 4,5

  if ($dcOnly -and -not $isDC) {
    Write-Output "Control: 18.7.13 (L1) Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt' (Automated)"
    Write-Output "Note: This control applies to Domain Controllers only"
    return
  }

  if ($msOnly -and $isDC) {
    Write-Output "Control: 18.7.13 (L1) Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt' (Automated)"
    Write-Output "Note: This control applies to Member Servers only"
    return
  }

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.7.13 (L1) Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies"
    Write-Output "Name: UpdatePromptSettings"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.7.13 (L1) Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
