# 18.9.28.6.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows"
  $regValue = "Turnoffpicturepasswordsignin"
  $after = 1
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.9.28.6 (L1) Ensure 'Turn off picture password sign-in' is set to 'Enabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: Turnoffpicturepasswordsignin"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.9.28.6 (L1) Ensure 'Turn off picture password sign-in' is set to 'Enabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
