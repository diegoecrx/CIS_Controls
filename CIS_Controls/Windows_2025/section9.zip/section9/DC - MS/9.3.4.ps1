# 9.3.4.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"
  $regValue = "AllowLocalPolicyMerge"
  $after = 0
  
  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }
    
    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }
    
    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force
    
    Write-Output "Control: 9.3.4 (L1) Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Windows Defender Firewall with Advanced Security\Windows Defender Firewall with Advanced Security\Windows Defender Firewall Properties\Public Profile\Settings Customize\Apply local firewall rules"
    Write-Output "Name: AllowLocalPolicyMerge"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 9.3.4 (L1) Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
