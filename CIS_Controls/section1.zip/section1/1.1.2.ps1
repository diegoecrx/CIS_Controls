###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 1.1.2.ps1
# CIS Control - 1.1.2 (L1) Ensure 'Maximum password age' is set to
# '365 or fewer days, but not 0' (Automated)
#
# This script remediates and verifies Maximum password age on
# Domain Controllers (via Default Domain Password Policy) and on
# Member/Standalone servers (via Local Security Policy using secedit).
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 1.1.2 (Maximum password age)

.DESCRIPTION
    Ensures 'Maximum password age' is set to '365 or fewer days, but not 0'
    per CIS 1.1.2 for Windows Server 2022.

    Profile Applicability:
      - Level 1 - Domain Controller
      - Level 1 - Member Server

    Default value (Microsoft): 42 days.
    Recommended (CIS): 365 or fewer days, but not 0.

.NOTES
    Run as Administrator.
    DCs: Uses ActiveDirectory module (ADWS) with fallback to 'net accounts' (read) if needed.
    Members: Uses secedit template (Unicode).
#>

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Script Metadata / Constants ----------------------
$SCRIPT_NAME        = "1.1.2.ps1"
$CONTROL_NAME       = "1.1.2 (L1) Ensure 'Maximum password age' is set to '365 or fewer days, but not 0' (Automated)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Password Policy\Maximum password age'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "42 days."
$RECOMMENDED_VALUE  = 365    # CIS cap
$MIN_ALLOWED        = 1
$MAX_ALLOWED        = 365

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole
        return ($role -ge 4)    # 4/5 = DC roles
    } catch { return $false }
}

function Ensure-ADWS {
    try {
        $svc = Get-Service -Name ADWS -ErrorAction Stop
        if ($svc.Status -ne 'Running') {
            Start-Service -Name ADWS -ErrorAction Stop
            $svc.WaitForStatus('Running','00:00:20')
        }
    } catch { } # best-effort
}

function To-Display([Nullable[int]]$v){
    if ($null -eq $v) { return 'Unknown' }
    return $v.ToString()
}

# ---- Read current effective value: Member/Standalone (locale independent)
function Get-MaxPasswordAgeMember {
    $tmpName = "secexport_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $tmpPath = Join-Path $env:TEMP $tmpName
    try {
        secedit /export /cfg $tmpPath /quiet | Out-Null
        # System Access key for max age is MaximumPasswordAge (days)
        $line = Get-Content $tmpPath | Where-Object { $_ -match '^\s*MaximumPasswordAge\s*=\s*(.+)$' } | Select-Object -First 1
        if (-not $line) { return $null }
        $raw = ($line -replace '^\s*MaximumPasswordAge\s*=\s*','').Trim()
        if ($raw -match '^\d+$') { return [int]$raw }
        return $null
    } finally {
        Remove-Item $tmpPath -Force -ErrorAction SilentlyContinue
    }
}

# ---- Read current value: Domain (prefer AD cmdlets, fallback net accounts parse)
function Get-MaxPasswordAgeDomain {
    try {
        Import-Module ActiveDirectory -ErrorAction Stop
        $ts = (Get-ADDefaultDomainPasswordPolicy).MaxPasswordAge
        if ($null -eq $ts) { return $null }
        return [int][Math]::Abs([int]$ts.Days)   # ensure positive day count
    } catch {
        # Fallback (English output expected): "Maximum password age (days): 42"
        $out = (net accounts) 2>$null
        $line = $out | Where-Object { $_ -match 'Maximum password age' } | Select-Object -First 1
        if ($line -and $line -match ':\s*(\d+)\b') { return [int]$Matches[1] }
        return $null
    }
}

# ---- Set value: Domain
function Set-MaxPasswordAgeDomain([int]$value){
    Ensure-ADWS
    Import-Module ActiveDirectory -ErrorAction Stop
    $domain = (Get-ADDomain).DistinguishedName
    $ts = New-TimeSpan -Days $value
    Set-ADDefaultDomainPasswordPolicy -Identity $domain -MaxPasswordAge $ts -ErrorAction Stop
    return $true
}

# ---- Set value: Member/Standalone (local security policy)
function Set-MaxPasswordAgeMember([int]$value){
    $cfgName = "secpol_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $dbName  = "secedit_{0:yyyyMMdd_HHmmss}.sdb" -f (Get-Date)
    $bkpName = "secedit_backup_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)

    $tempCfg = Join-Path $env:TEMP $cfgName
    $dbPath  = Join-Path $env:TEMP $dbName
    $backup  = Join-Path $env:TEMP $bkpName

    # Backup local policy
    secedit /export /cfg $backup /quiet | Out-Null
    Write-Host "[BACKUP] Current security policy exported to: $backup"

$template = @"
[Unicode]
Unicode=yes
[System Access]
MaximumPasswordAge = $value
[Version]
signature="$`CHICAGO$`"
Revision=1
"@
    $template | Out-File -FilePath $tempCfg -Encoding Unicode -Force

    # Apply template
    secedit /configure /db $dbPath /cfg $tempCfg /quiet | Out-Null
    return $true
}

function Test-Target([int]$v,[int]$min,[int]$max){
    if ($v -lt $min -or $v -gt $max) {
        throw "Target must be between $min and $max days. Current: $v"
    }
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Maximum password age' is set to '365 or fewer days, but not 0' (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController
$machine = Get-CimInstance Win32_ComputerSystem
$partOfDomain = [bool]$machine.PartOfDomain

# Determine target and validate
$target = [Math]::Min([Math]::Max($RECOMMENDED_VALUE, $MIN_ALLOWED), $MAX_ALLOWED)
Test-Target -v $target -min $MIN_ALLOWED -max $MAX_ALLOWED

# Read current value (pre)
$pre = if ($isDC) { Get-MaxPasswordAgeDomain } else { Get-MaxPasswordAgeMember }
Write-Host ("Current threshold: {0}" -f (To-Display $pre))
Write-Host ""

# Match requested layout banner for remediation channel
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Default Domain Password Policy (ActiveDirectory cmdlets)"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
}
Write-Host ""

# Apply if needed (1..365 days, not 0)
$changed = $false
if ($null -eq $pre -or $pre -eq 0 -or $pre -gt $target) {
    if ($isDC) {
        Set-MaxPasswordAgeDomain -value $target | Out-Null
    } else {
        Set-MaxPasswordAgeMember  -value $target | Out-Null
    }
    $changed = $true
}

# ---- Force policy refresh (as requested) ----
try {
    if ($isDC) {
        gpupdate /force | Out-Null
        secedit /refreshpolicy machine_policy /enforce | Out-Null
    } else {
        gpupdate /target:computer /force | Out-Null
        secedit /refreshpolicy machine_policy /enforce | Out-Null
    }
} catch { }

# Verify after remediation (post)
$post = if ($isDC) { Get-MaxPasswordAgeDomain } else { Get-MaxPasswordAgeMember }
$compliant = ($post -ge $MIN_ALLOWED -and $post -le $MAX_ALLOWED)

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current threshold: {0}" -f (To-Display $post))
$preDisp  = To-Display $pre
$postDisp = To-Display $post
Write-Host ("Maximum Password Age       : target={0}  pre={1}  post={2}" -f $target, $preDisp, $postDisp)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
