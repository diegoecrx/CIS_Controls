###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 1.2.1.ps1
# CIS Control - 1.2.1 (L1) Ensure 'Account lockout duration' is set to
# '15 or more minute(s)' (Automated)
#
# This script remediates and verifies Account lockout duration on
# Domain Controllers (via Default Domain Password Policy) and on
# Member/Standalone servers (via Local Security Policy using secedit).
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 1.2.1 (Account lockout duration)

.DESCRIPTION
    Ensures 'Account lockout duration' is set to '15 or more minute(s)'
    per CIS 1.2.1 for Windows Server 2022.

    Profile Applicability:
      - Level 1 - Domain Controller
      - Level 1 - Member Server

    Default value (Microsoft):
      - Not applicable when 'Account lockout threshold' is 0 (no lockout).
      - If defined by policy, common default is 30 minutes.

.NOTES
    Run as Administrator.
    DCs: Uses ActiveDirectory module (ADWS).
    Members: Uses secedit template (Unicode).
#>

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Script Metadata / Constants ----------------------
$SCRIPT_NAME        = "1.2.1.ps1"
$CONTROL_NAME       = "1.2.1 (L1) Ensure 'Account lockout duration' is set to '15 or more minute(s)' (Automated)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Account lockout duration'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Not applicable when threshold is 0 (no lockout)."
$RECOMMENDED_VALUE  = 15    # CIS requires 15 or more minutes
$MIN_ALLOWED        = 15
$MAX_ALLOWED        = 99999 # Windows supports large values; cap generously

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole
        return ($role -ge 4)    # 4/5 = DC roles
    } catch { return $false }
}

function Ensure-ADWS {
    try {
        $svc = Get-Service -Name ADWS -ErrorAction Stop
        if ($svc.Status -ne 'Running') {
            Start-Service -Name ADWS -ErrorAction Stop
            $svc.WaitForStatus('Running','00:00:20')
        }
    } catch { } # best-effort
}

function To-Display([Nullable[int]]$v){
    if ($null -eq $v) { return 'Unknown' }
    return ("{0} minute(s)" -f $v)
}

# ---- Read current effective value: Member/Standalone (locale independent)
# System Access key: LockoutDuration (minutes)
function Get-LockoutDurationMember {
    $tmpName = "secexport_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $tmpPath = Join-Path $env:TEMP $tmpName
    try {
        secedit /export /cfg $tmpPath /quiet | Out-Null
        $line = Get-Content $tmpPath | Where-Object { $_ -match '^\s*LockoutDuration\s*=\s*(.+)$' } | Select-Object -First 1
        if (-not $line) { return $null }
        $raw = ($line -replace '^\s*LockoutDuration\s*=\s*','').Trim()
        if ($raw -match '^\d+$') { return [int]$raw }
        return $null
    } finally {
        Remove-Item $tmpPath -Force -ErrorAction SilentlyContinue
    }
}

# ---- Read current value: Domain (prefer AD cmdlets)
# AD returns a (negative) TimeSpan for durations; convert to positive minutes
function Get-LockoutDurationDomain {
    try {
        Import-Module ActiveDirectory -ErrorAction Stop
        $ts = (Get-ADDefaultDomainPasswordPolicy).LockoutDuration
        if ($null -eq $ts) { return $null }
        return [int][Math]::Abs([int][Math]::Round($ts.TotalMinutes))
    } catch {
        return $null
    }
}

# ---- Set value: Domain
function Set-LockoutDurationDomain([int]$value){
    Ensure-ADWS
    Import-Module ActiveDirectory -ErrorAction Stop
    $domain = (Get-ADDomain).DistinguishedName
    $ts = New-TimeSpan -Minutes $value
    Set-ADDefaultDomainPasswordPolicy -Identity $domain -LockoutDuration $ts -ErrorAction Stop
    return $true
}

# ---- Set value: Member/Standalone (local security policy)
function Set-LockoutDurationMember([int]$value){
    $cfgName = "secpol_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $dbName  = "secedit_{0:yyyyMMdd_HHmmss}.sdb" -f (Get-Date)
    $bkpName = "secedit_backup_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)

    $tempCfg = Join-Path $env:TEMP $cfgName
    $dbPath  = Join-Path $env:TEMP $dbName
    $backup  = Join-Path $env:TEMP $bkpName

    # Backup local policy
    secedit /export /cfg $backup /quiet | Out-Null
    Write-Host "[BACKUP] Current security policy exported to: $backup"

$template = @"
[Unicode]
Unicode=yes
[System Access]
LockoutDuration = $value
[Version]
signature="$`CHICAGO$`"
Revision=1
"@
    $template | Out-File -FilePath $tempCfg -Encoding Unicode -Force

    # Apply template
    secedit /configure /db $dbPath /cfg $tempCfg /quiet | Out-Null
    return $true
}

function Test-Target([int]$v,[int]$min,[int]$max){
    if ($v -lt $min -or $v -gt $max) {
        throw "Target must be between $min and $max minutes. Current: $v"
    }
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Account lockout duration' is set to '15 or more minute(s)' (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController
$machine = Get-CimInstance Win32_ComputerSystem | Select-Object -First 1
$partOfDomain = [bool]$machine.PartOfDomain

# Determine target and validate
$target = [Math]::Min([Math]::Max($RECOMMENDED_VALUE, $MIN_ALLOWED), $MAX_ALLOWED)
Test-Target -v $target -min $MIN_ALLOWED -max $MAX_ALLOWED

# Read current value (pre)
$pre = if ($isDC) { Get-LockoutDurationDomain } else { Get-LockoutDurationMember }
Write-Host ("Current threshold: {0}" -f (To-Display $pre))
Write-Host ""

# Match requested layout banner
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Default Domain Password Policy (ActiveDirectory cmdlets)"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
}
Write-Host ""

# Apply if needed (must be >= 15 minutes)
$changed = $false
if ($null -eq $pre -or $pre -lt $target) {
    if ($isDC) {
        Set-LockoutDurationDomain -value $target | Out-Null
    } else {
        Set-LockoutDurationMember  -value $target | Out-Null
    }
    $changed = $true
}

# ---- Force policy refresh (as requested) ----
try {
    if ($isDC) {
        gpupdate /force | Out-Null
        secedit /refreshpolicy machine_policy /enforce | Out-Null
    } else {
        gpupdate /target:computer /force | Out-Null
        secedit /refreshpolicy machine_policy /enforce | Out-Null
    }
} catch { }

# Verify after remediation (post)
$post = if ($isDC) { Get-LockoutDurationDomain } else { Get-LockoutDurationMember }
$compliant = ($post -ge $MIN_ALLOWED -and $post -le $MAX_ALLOWED)

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current threshold: {0}" -f (To-Display $post))
$preDisp  = To-Display $pre
$postDisp = To-Display $post
Write-Host ("Account Lockout Duration   : target={0}  pre={1}  post={2}" -f (To-Display $target), $preDisp, $postDisp)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
