#!/bin/bash
# ID: 2.2.1.2_chrony.sh 2.2.1.2 Ensure chrony is configured (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.1.2_chrony.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/chrony.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter OPTIONS to "-u chrony" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^OPTIONS\s*=" "$CONF_FILE"; then
    sed -i "s|^OPTIONS\s*=.*|OPTIONS = "-u chrony"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "OPTIONS = "-u chrony"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0