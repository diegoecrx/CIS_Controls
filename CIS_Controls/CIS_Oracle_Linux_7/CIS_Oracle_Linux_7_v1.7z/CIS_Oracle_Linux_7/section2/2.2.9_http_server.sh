#!/bin/bash
# ID: 2.2.9_http_server_not_installed.sh 2.2.19 Ensure rsync is not installed or the rsyncd service is masked (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.9_http_server_not_installed.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: yum remove rsync"
yum remove rsync || result="pending"

echo "Executing: systemctl --now mask rsyncd"
systemctl --now mask rsyncd || result="pending"


log_event "$result"
exit 0