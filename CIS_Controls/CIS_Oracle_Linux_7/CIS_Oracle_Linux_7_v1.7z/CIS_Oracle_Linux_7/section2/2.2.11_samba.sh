#!/bin/bash
# ID: 2.2.11_samba_not_installed.sh 2.2.3 Ensure Avahi Server is not installed (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.11_samba_not_installed.sh
profile_app_server=1
profile_app_workstation=2

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: systemctl stop avahi-daemon.socket avahi-daemon.service"
systemctl stop avahi-daemon.socket avahi-daemon.service || result="pending"

echo "Executing: yum remove avahi-autoipd avahi"
yum remove avahi-autoipd avahi || result="pending"


log_event "$result"
exit 0