#!/bin/bash
# ID: 2.2.10_imap_and_pop3_server.sh 2.2.2 Ensure X11 Server components are not installed (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.10_imap_and_pop3_server.sh
profile_app_server=1
profile_app_workstation=N/A

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: yum remove xorg-x11-server*"
yum remove xorg-x11-server* || result="pending"


log_event "$result"
exit 0