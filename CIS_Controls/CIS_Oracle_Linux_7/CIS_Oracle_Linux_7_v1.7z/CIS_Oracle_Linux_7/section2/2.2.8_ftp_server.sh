#!/bin/bash
# ID: 2.2.8_ftp_server_not_installed.sh 2.2.18 Ensure rpcbind is not installed or the rpcbind services are masked (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.8_ftp_server_not_installed.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: yum remove rpcbind"
yum remove rpcbind || result="pending"

echo "Executing: systemctl --now mask rpcbind"
systemctl --now mask rpcbind || result="pending"

echo "Executing: systemctl --now mask rpcbind.socket"
systemctl --now mask rpcbind.socket || result="pending"


log_event "$result"
exit 0