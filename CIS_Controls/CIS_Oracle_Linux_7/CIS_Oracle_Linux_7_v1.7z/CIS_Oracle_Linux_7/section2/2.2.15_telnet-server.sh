#!/bin/bash
# ID: 2.2.15_telnetserver_not_installed.sh 2.2.7 Ensure DNS Server is not installed (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.15_telnetserver_not_installed.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: yum remove bind"
yum remove bind || result="pending"


log_event "$result"
exit 0