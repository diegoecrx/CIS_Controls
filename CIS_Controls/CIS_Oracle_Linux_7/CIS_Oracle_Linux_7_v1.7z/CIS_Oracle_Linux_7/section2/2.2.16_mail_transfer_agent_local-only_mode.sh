#!/bin/bash
# ID: 2.2.16_mail_transfer_agent_for.sh 2.2.8 Ensure FTP Server is not installed (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.16_mail_transfer_agent_for.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: yum remove vsftpd"
yum remove vsftpd || result="pending"


log_event "$result"
exit 0