#!/bin/bash
# ID: 2.2.1.3_ntp.sh 2.2.1.3 Ensure ntp is configured (Automated)

section=2_services
sub_section=2.2_special_purpose_services
script_name=2.2.1.3_ntp.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ntp.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter OPTIONS to "-u ntp:ntp" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^OPTIONS\s*=" "$CONF_FILE"; then
    sed -i "s|^OPTIONS\s*=.*|OPTIONS = "-u ntp:ntp"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "OPTIONS = "-u ntp:ntp"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: systemctl daemon-reload"
systemctl daemon-reload || result="pending"

echo "Executing: systemctl --now enable ntpd"
systemctl --now enable ntpd || result="pending"


log_event "$result"
exit 0