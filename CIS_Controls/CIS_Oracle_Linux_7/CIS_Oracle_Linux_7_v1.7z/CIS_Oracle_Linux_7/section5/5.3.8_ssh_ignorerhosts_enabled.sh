#!/bin/bash
# ID: 5.3.8_ssh_ignorerhosts.sh 5.3.21 Ensure SSH MaxStartups is configured (Automated)

section=5_access_authentication_authorization
sub_section=5.3_configure_ssh_server
script_name=5.3.8_ssh_ignorerhosts.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ssh/sshd_config"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

# Set MaxStartups parameter for SSH
MAX_STARTUPS="10:30:60"
echo "Setting MaxStartups to $MAX_STARTUPS in $CONF_FILE"
if grep -qi '^MaxStartups' "$CONF_FILE"; then
  sed -i "s/^MaxStartups.*/MaxStartups $MAX_STARTUPS/" "$CONF_FILE" || result="pending"
else
  echo "MaxStartups $MAX_STARTUPS" >> "$CONF_FILE" || result="pending"
fi

# Reload or restart sshd to apply changes
if systemctl is-active --quiet sshd || systemctl is-active --quiet ssh; then
  systemctl reload sshd || systemctl restart sshd || systemctl restart ssh || true
fi

log_event "$result"
exit 0