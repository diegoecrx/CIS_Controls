#!/bin/bash
# ID: 5.1.9_at_restricted_to_authorized.sh 5.1.9 Ensure at is restricted to authorized users (Automated)

section=5_access_authentication_authorization
sub_section=5.1_configure_time-based_job_schedulers
script_name=5.1.9_at_restricted_to_authorized.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/at.deny:"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: rm /etc/at.deny"
rm /etc/at.deny || result="pending"

echo "Executing: chown root:root /etc/at.allow"
chown root:root /etc/at.allow || result="pending"

echo "Executing: chmod u-x,og-rwx /etc/at.allow"
chmod u-x,og-rwx /etc/at.allow || result="pending"

echo "Executing: yum remove at"
yum remove at || result="pending"


log_event "$result"
exit 0