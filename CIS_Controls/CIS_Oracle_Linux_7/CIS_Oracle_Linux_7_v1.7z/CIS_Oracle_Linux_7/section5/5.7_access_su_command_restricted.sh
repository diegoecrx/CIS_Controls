#!/bin/bash
# ID: 5.7_access_to_su_command.sh 5.7 Ensure access to the su command is restricted (Automated)

section=5_access_authentication_authorization
sub_section=5.7_ensure_access_to_the_su_command_is_restricted
script_name=5.7_access_to_su_command.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/pam.d/su"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if groupadd sugroup; then
  echo "Executed: groupadd sugroup"
else
  echo "Failed: groupadd sugroup"
  result="pending"
fi

log_event "$result"
exit 0
