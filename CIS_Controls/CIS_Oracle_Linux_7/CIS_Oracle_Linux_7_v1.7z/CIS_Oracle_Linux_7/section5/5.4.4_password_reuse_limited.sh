#!/bin/bash
# ID: 5.4.4_password_reuse_limited.sh 5.4.4 Ensure password reuse is limited (Automated)

section=5_access_authentication_authorization
sub_section=5.4_configure_pam
script_name=5.4.4_password_reuse_limited.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/pam.d/password-auth"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter authtok_type to  in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^authtok_type\s*=" "$CONF_FILE"; then
    sed -i "s|^authtok_type\s*=.*|authtok_type = |" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "authtok_type = " >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0