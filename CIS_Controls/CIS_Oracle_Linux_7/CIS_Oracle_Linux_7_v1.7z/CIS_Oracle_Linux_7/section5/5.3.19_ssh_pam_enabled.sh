#!/bin/bash
# ID: 5.3.19_ssh_pam.sh 5.3.10 Ensure SSH root login is disabled (Automated)

section=5_access_authentication_authorization
sub_section=5.3_configure_ssh_server
script_name=5.3.19_ssh_pam.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ssh/sshd_config"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}
set_sshd_param() {
  local param="$1"
  local value="$2"
  local file="/etc/ssh/sshd_config"
  # Replace existing parameter or append if missing
  if grep -qi "^\s*${param}\s*" "$file"; then
    sed -ri "s/^\s*${param}\s*.*/${param} ${value}/I" "$file"
  else
    echo "${param} ${value}" >> "$file"
  fi
}

# Implement remediation commands
result="success"
set_sshd_param "PermitRootLogin" "no"
systemctl reload sshd || systemctl restart sshd

log_event "$result"
exit 0
