#!/bin/bash
# ID: 5.4.1_password_creation_requirements_are.sh 5.4.1 Ensure password creation requirements are configured (Automated)

section=5_access_authentication_authorization
sub_section=5.4_configure_pam
script_name=5.4.1_password_creation_requirements_are.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/security/pwquality.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter minlen to 14 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^minlen\s*=" "$CONF_FILE"; then
    sed -i "s|^minlen\s*=.*|minlen = 14|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "minlen = 14" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter minclass to 4 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^minclass\s*=" "$CONF_FILE"; then
    sed -i "s|^minclass\s*=.*|minclass = 4|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "minclass = 4" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter dcredit to -1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^dcredit\s*=" "$CONF_FILE"; then
    sed -i "s|^dcredit\s*=.*|dcredit = -1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "dcredit = -1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter ucredit to -1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^ucredit\s*=" "$CONF_FILE"; then
    sed -i "s|^ucredit\s*=.*|ucredit = -1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "ucredit = -1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter ocredit to -1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^ocredit\s*=" "$CONF_FILE"; then
    sed -i "s|^ocredit\s*=.*|ocredit = -1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "ocredit = -1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter lcredit to -1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^lcredit\s*=" "$CONF_FILE"; then
    sed -i "s|^lcredit\s*=.*|lcredit = -1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "lcredit = -1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0