#!/bin/bash
# ID: 5.5.4_default_shell_timeout.sh 5.5.4 Ensure default user shell timeout is configured (Automated)

section=5_access_authentication_authorization
sub_section=5.5_user_accounts_and_environment
script_name=5.5.4_default_shell_timeout.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/bashrc,"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter TMOUT to 900 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^TMOUT\s*=" "$CONF_FILE"; then
    sed -i "s|^TMOUT\s*=.*|TMOUT = 900|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "TMOUT = 900" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0