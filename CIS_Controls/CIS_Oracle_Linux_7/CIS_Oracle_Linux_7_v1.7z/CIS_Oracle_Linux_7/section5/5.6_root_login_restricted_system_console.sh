#!/bin/bash
# ID: 5.6_root_login_restricted_to.sh 5.6 Ensure root login is restricted to system console (Manual)

section=5_access_authentication_authorization
sub_section=5.6_ensure_root_login_is_restricted_to_system_console
script_name=5.6_root_login_restricted_to.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
echo "Manual remediation required: see CIS benchmark documentation."
result="pending"

log_event "$result"
exit 0
