#!/bin/bash
# ID: 5.5.2_system_accounts_are_secured.sh 5.5.2 Ensure system accounts are secured (Automated)

section=5_access_authentication_authorization
sub_section=5.5_user_accounts_and_environment
script_name=5.5.2_system_accounts_are_secured.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/login.defs)"'"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if usermod -s $(which nologin) <user>; then
  echo "Executed: usermod -s $(which nologin) <user>"
else
  echo "Failed: usermod -s $(which nologin) <user>"
  result="pending"
fi
if usermod -L <user>; then
  echo "Executed: usermod -L <user>"
else
  echo "Failed: usermod -L <user>"
  result="pending"
fi

log_event "$result"
exit 0
