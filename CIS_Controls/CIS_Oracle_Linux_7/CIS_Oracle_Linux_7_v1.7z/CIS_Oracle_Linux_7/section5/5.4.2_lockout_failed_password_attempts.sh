#!/bin/bash
# ID: 5.4.2_lockout_for_failed_password.sh 5.4.2 Ensure lockout for failed password attempts is configured (Automated)

section=5_access_authentication_authorization
sub_section=5.4_configure_pam
script_name=5.4.2_lockout_for_failed_password.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/pam.d/system-auth"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter unlock_time to 900 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^unlock_time\s*=" "$CONF_FILE"; then
    sed -i "s|^unlock_time\s*=.*|unlock_time = 900|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "unlock_time = 900" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter unlock_time to 900 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^unlock_time\s*=" "$CONF_FILE"; then
    sed -i "s|^unlock_time\s*=.*|unlock_time = 900|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "unlock_time = 900" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter unlock_time to 900 # <- Under "auth required pam_env.so" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^unlock_time\s*=" "$CONF_FILE"; then
    sed -i "s|^unlock_time\s*=.*|unlock_time = 900 # <- Under "auth required pam_env.so"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "unlock_time = 900 # <- Under "auth required pam_env.so"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter unlock_time to 900 # <- Last auth line before "auth requisite in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^unlock_time\s*=" "$CONF_FILE"; then
    sed -i "s|^unlock_time\s*=.*|unlock_time = 900 # <- Last auth line before "auth requisite|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "unlock_time = 900 # <- Last auth line before "auth requisite" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0