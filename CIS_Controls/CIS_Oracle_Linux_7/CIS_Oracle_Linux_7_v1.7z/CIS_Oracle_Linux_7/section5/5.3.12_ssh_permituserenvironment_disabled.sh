#!/bin/bash
# ID: 5.3.12_ssh_permituserenvironment.sh 5.3.3 Ensure permissions on SSH public host key files are configured (Automated)

section=5_access_authentication_authorization
sub_section=5.3_configure_ssh_server
script_name=5.3.12_ssh_permituserenvironment.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ssh"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chmod u-x,go-; then
  echo "Executed: find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chmod u-x,go-"
else
  echo "Failed: find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chmod u-x,go-"
  result="pending"
fi
if find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chown; then
  echo "Executed: find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chown"
else
  echo "Failed: find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chown"
  result="pending"
fi

log_event "$result"
exit 0
