#!/bin/bash
# ID: 5.3.10_ssh_root_login.sh 5.3.1 Ensure permissions on /etc/ssh/sshd_config are configured (Automated)

section=5_access_authentication_authorization
sub_section=5.2_configure_sudo
script_name=5.3.10_ssh_root_login.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ssh/sshd_config:"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: chown root:root /etc/ssh/sshd_config"
chown root:root /etc/ssh/sshd_config || result="pending"

echo "Executing: chmod og-rwx /etc/ssh/sshd_config"
chmod og-rwx /etc/ssh/sshd_config || result="pending"


log_event "$result"
exit 0