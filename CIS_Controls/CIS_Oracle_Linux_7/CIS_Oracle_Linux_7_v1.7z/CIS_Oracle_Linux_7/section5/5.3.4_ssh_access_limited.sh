#!/bin/bash
# ID: 5.3.4_ssh_access_limited.sh 5.3.17 Ensure SSH LoginGraceTime is set to one minute or less (Automated)

section=5_access_authentication_authorization
sub_section=5.3_configure_ssh_server
script_name=5.3.4_ssh_access_limited.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ssh/sshd_config"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}
set_sshd_param() {
  local param="$1"
  local value="$2"
  local file="/etc/ssh/sshd_config"
  # Replace existing parameter or append if missing
  if grep -qi "^\s*${param}\s*" "$file"; then
    sed -ri "s/^\s*${param}\s*.*/${param} ${value}/I" "$file"
  else
    echo "${param} ${value}" >> "$file"
  fi
}

# Implement remediation commands
result="success"
set_sshd_param "LoginGraceTime" "60"
systemctl reload sshd || systemctl restart sshd

log_event "$result"
exit 0
