#!/bin/bash
# ID: 5.2.3_sudo_log_exists.sh 5.2.3 Ensure sudo log file exists (Automated)

section=5_access_authentication_authorization
sub_section=5.2_configure_sudo
script_name=5.2.3_sudo_log_exists.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/sudoers"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
echo "Manual remediation required: see CIS benchmark documentation."
result="pending"

log_event "$result"
exit 0
