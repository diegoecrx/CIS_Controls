#!/bin/bash
# ID: 5.4.3_password_hashing_algorithm_sha512.sh 5.4.3 Ensure password hashing algorithm is SHA-512 (Automated)

section=5_access_authentication_authorization
sub_section=5.4_configure_pam
script_name=5.4.3_password_hashing_algorithm_sha512.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/pam.d/password-auth"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if awk -F: '( $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"' && $1 !~; then
  echo "Executed: awk -F: '( $3<'\"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)\"' && $1 !~"
else
  echo "Failed: awk -F: '( $3<'\"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)\"' && $1 !~"
  result="pending"
fi

log_event "$result"
exit 0
