#!/bin/bash
# ID: 5.3.21_ssh_maxstartups.sh 5.3.13 Ensure only strong Ciphers are used (Automated)

section=5_access_authentication_authorization
sub_section=5.3_configure_ssh_server
script_name=5.3.21_ssh_maxstartups.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/ssh/sshd_config"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

# Configure strong SSH ciphers
STRONG_CIPHERS="chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr"
echo "Updating Ciphers directive in $CONF_FILE"
if grep -qi '^Ciphers' "$CONF_FILE"; then
  sed -i "s/^Ciphers.*/Ciphers $STRONG_CIPHERS/" "$CONF_FILE" || result="pending"
else
  echo "Ciphers $STRONG_CIPHERS" >> "$CONF_FILE" || result="pending"
fi

# Reload or restart sshd to apply changes
if systemctl is-active --quiet sshd || systemctl is-active --quiet ssh; then
  systemctl reload sshd || systemctl restart sshd || systemctl restart ssh || true
fi

log_event "$result"
exit 0