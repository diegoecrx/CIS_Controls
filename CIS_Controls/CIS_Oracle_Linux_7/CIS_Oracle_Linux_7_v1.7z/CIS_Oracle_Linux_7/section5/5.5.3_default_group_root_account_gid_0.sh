#!/bin/bash
# ID: 5.5.3_default_group_for_root.sh 5.5.3 Ensure default group for the root account is GID 0 (Automated)

section=5_access_authentication_authorization
sub_section=5.5_user_accounts_and_environment
script_name=5.5.3_default_group_for_root.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if usermod -g 0 root; then
  echo "Executed: usermod -g 0 root"
else
  echo "Failed: usermod -g 0 root"
  result="pending"
fi

log_event "$result"
exit 0
