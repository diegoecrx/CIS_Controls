#!/bin/bash
# ID: 6.2.10_root_path_integrity.sh 6.2.1 Ensure accounts in /etc/passwd use shadowed passwords (Automated)

section=6_system_maintenance
sub_section=6.2_user_and_group_settings
script_name=6.2.10_root_path_integrity.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/passwd"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if sed -e 's/^\([a-zA-Z0-9_]*\):[^:]*:/\1:x:/' -i /etc/passwd; then
  echo "Executed: sed -e 's/^\([a-zA-Z0-9_]*\):[^:]*:/\1:x:/' -i /etc/passwd"
else
  echo "Failed: sed -e 's/^\([a-zA-Z0-9_]*\):[^:]*:/\1:x:/' -i /etc/passwd"
  result="pending"
fi

log_event "$result"
exit 0
