#!/bin/bash
# ID: 6.2.11_all_users_home_directories.sh 6.2.2 Ensure /etc/shadow password fields are not empty (Automated)

section=6_system_maintenance
sub_section=6.2_user_and_group_settings
script_name=6.2.11_all_users_home_directories.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/shadow"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: passwd -l <username>"
passwd -l <username> || result="pending"


log_event "$result"
exit 0