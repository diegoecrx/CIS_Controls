#!/bin/bash
# ID: 6.1.14_audit_sgid_executables.sh 6.1.5 Ensure permissions on /etc/shadow- are configured (Automated)

section=6_system_maintenance
sub_section=6.1_system_file_permissions
script_name=6.1.14_audit_sgid_executables.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/shadow-"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: chown root:root /etc/shadow-"
chown root:root /etc/shadow- || result="pending"

echo "Executing: chmod 0000 /etc/shadow-"
chmod 0000 /etc/shadow- || result="pending"


log_event "$result"
exit 0