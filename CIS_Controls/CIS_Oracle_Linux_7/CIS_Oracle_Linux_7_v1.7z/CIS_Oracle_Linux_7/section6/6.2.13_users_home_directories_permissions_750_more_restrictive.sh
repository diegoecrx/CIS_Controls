#!/bin/bash
# ID: 6.2.13_users_home_directories_permissions.sh 6.2.4 Ensure shadow group is empty (Automated)

section=6_system_maintenance
sub_section=6.2_user_and_group_settings
script_name=6.2.13_users_home_directories_permissions.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/group"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if sed -ri 's/(^shadow:[^:]*:[^:]*:)([^:]+$)/\1/' /etc/group; then
  echo "Executed: sed -ri 's/(^shadow:[^:]*:[^:]*:)([^:]+$)/\1/' /etc/group"
else
  echo "Failed: sed -ri 's/(^shadow:[^:]*:[^:]*:)([^:]+$)/\1/' /etc/group"
  result="pending"
fi
if usermod -g <primary group> <user>; then
  echo "Executed: usermod -g <primary group> <user>"
else
  echo "Failed: usermod -g <primary group> <user>"
  result="pending"
fi

log_event "$result"
exit 0
