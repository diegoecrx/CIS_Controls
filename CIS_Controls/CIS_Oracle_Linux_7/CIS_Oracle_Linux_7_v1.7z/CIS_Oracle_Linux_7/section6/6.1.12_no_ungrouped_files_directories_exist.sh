#!/bin/bash
# ID: 6.1.12_no_ungrouped_files_or.sh 6.1.3 Ensure permissions on /etc/passwd- are configured (Automated)

section=6_system_maintenance
sub_section=6.1_system_file_permissions
script_name=6.1.12_no_ungrouped_files_or.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/passwd-"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: chown root:root /etc/passwd-"
chown root:root /etc/passwd- || result="pending"

echo "Executing: chmod u-x,go-wx /etc/passwd-"
chmod u-x,go-wx /etc/passwd- || result="pending"


log_event "$result"
exit 0