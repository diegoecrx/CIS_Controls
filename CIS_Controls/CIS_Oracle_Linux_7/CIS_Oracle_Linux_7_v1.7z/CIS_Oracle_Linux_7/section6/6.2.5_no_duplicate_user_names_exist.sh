#!/bin/bash
# ID: 6.2.5_no_duplicate_names_exist.sh 6.2.13 Ensure users' home directories permissions are 750 or more restrictive (Automated)

section=6_system_maintenance
sub_section=6.2_user_and_group_settings
script_name=6.2.5_no_duplicate_names_exist.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/passwd"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter dirperm to $(stat -L -c "%A" "$dir") in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^dirperm\s*=" "$CONF_FILE"; then
    sed -i "s|^dirperm\s*=.*|dirperm = $(stat -L -c "%A" "$dir")|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "dirperm = $(stat -L -c "%A" "$dir")" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: chmod g-w,o-rwx \"$dir\""
chmod g-w,o-rwx "$dir" || result="pending"


log_event "$result"
exit 0