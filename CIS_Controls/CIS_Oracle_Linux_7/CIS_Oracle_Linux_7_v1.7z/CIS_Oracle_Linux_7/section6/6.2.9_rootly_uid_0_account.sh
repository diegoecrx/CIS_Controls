#!/bin/bash
# ID: 6.2.9_root_only_uid_0.sh 6.2.17 Ensure no users have .rhosts files (Automated)

section=6_system_maintenance
sub_section=6.2_user_and_group_settings
script_name=6.2.9_root_only_uid_0.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/passwd"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter file to "$dir/.rhosts" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^file\s*=" "$CONF_FILE"; then
    sed -i "s|^file\s*=.*|file = "$dir/.rhosts"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "file = "$dir/.rhosts"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0