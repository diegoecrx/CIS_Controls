#!/bin/bash
# ID: 6.1.7_permissions_etc_gshadow_are.sh 6.1.12 Ensure no ungrouped files or directories exist (Automated)

section=6_system_maintenance
sub_section=6.1_system_file_permissions
script_name=6.1.7_permissions_etc_gshadow_are.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"
# Scan for files with no group or no user
echo "Scanning for files with no group..."
if find / -xdev -nogroup -print -quit | grep -q .; then
  # List files without a valid group and mark as pending
  find / -xdev -nogroup -exec ls -l {} \+
  result="pending"
else
  echo "No files without group ownership found."
fi

echo "Scanning for files with no user..."
if find / -xdev -nouser -print -quit | grep -q .; then
  # List files without a valid user and mark as pending
  find / -xdev -nouser -exec ls -l {} \+
  result="pending"
else
  echo "No files without user ownership found."
fi

log_event "$result"
exit 0