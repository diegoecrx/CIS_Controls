#!/bin/bash
# ID: 4.1.4_events_that_modify_group.sh 4.1.12 Ensure successful file system mounts are collected (Automated)

section=4_logging_and_auditing
sub_section=4.1_configure_system_accounting
script_name=4.1.4_events_that_modify_group.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/audit/rules.d/"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: mounts"
mounts || result="pending"

echo "Executing: mounts"
mounts || result="pending"

echo "Executing: mounts"
mounts || result="pending"


log_event "$result"
exit 0