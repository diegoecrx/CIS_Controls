#!/bin/bash
# ID: 4.1.11_privileged_commands_collected.sh 4.1.2.2 Ensure audit logs are not automatically deleted (Automated)

section=4_logging_and_auditing
sub_section=4.1_configure_system_accounting
script_name=4.1.11_privileged_commands_collected.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/audit/auditd.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter max_log_file_action to keep_logs in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^max_log_file_action\s*=" "$CONF_FILE"; then
    sed -i "s|^max_log_file_action\s*=.*|max_log_file_action = keep_logs|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "max_log_file_action = keep_logs" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0