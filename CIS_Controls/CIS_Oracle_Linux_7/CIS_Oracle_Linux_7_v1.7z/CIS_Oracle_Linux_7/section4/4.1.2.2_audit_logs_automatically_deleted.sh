#!/bin/bash
# ID: 4.1.2.2_audit_logs_are_not.sh 4.1.8 Ensure session initiation information is collected (Automated)

section=4_logging_and_auditing
sub_section=4.1_configure_system_accounting
script_name=4.1.2.2_audit_logs_are_not.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/audit/rules.d/"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
echo "Manual remediation required: see CIS benchmark documentation."
result="pending"

log_event "$result"
exit 0
