#!/bin/bash
# ID: 4.2.3_permissions_all_logfiles_are.sh 4.2.3 Ensure permissions on all logfiles are configured (Manual)

section=4_logging_and_auditing
sub_section=4.2_configure_logging
script_name=4.2.3_permissions_all_logfiles_are.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if find /var/log -type f -exec chmod g-wx,o-rwx "{}" +; then
  echo "Executed: find /var/log -type f -exec chmod g-wx,o-rwx \"{}\" +"
else
  echo "Failed: find /var/log -type f -exec chmod g-wx,o-rwx \"{}\" +"
  result="pending"
fi

log_event "$result"
exit 0
