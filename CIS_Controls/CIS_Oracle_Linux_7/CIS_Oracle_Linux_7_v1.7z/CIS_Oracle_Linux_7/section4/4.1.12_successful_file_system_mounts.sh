#!/bin/bash
# ID: 4.1.12_successful_system_mounts_are.sh 4.1.2.3 Ensure system is disabled when audit logs are full (Automated)

section=4_logging_and_auditing
sub_section=4.1_configure_system_accounting
script_name=4.1.12_successful_system_mounts_are.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/audit/auditd.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter space_left_action to email in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^space_left_action\s*=" "$CONF_FILE"; then
    sed -i "s|^space_left_action\s*=.*|space_left_action = email|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "space_left_action = email" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter action_mail_acct to root in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^action_mail_acct\s*=" "$CONF_FILE"; then
    sed -i "s|^action_mail_acct\s*=.*|action_mail_acct = root|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "action_mail_acct = root" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter admin_space_left_action to halt in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^admin_space_left_action\s*=" "$CONF_FILE"; then
    sed -i "s|^admin_space_left_action\s*=.*|admin_space_left_action = halt|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "admin_space_left_action = halt" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0