#!/bin/bash
# ID: 4.1.1.3_auditing_for_processes_that.sh 4.1.1.3 Ensure auditing for processes that start prior to auditd is enabled (Automated)

section=4_logging_and_auditing
sub_section=4.1_configure_system_accounting
script_name=4.1.1.3_auditing_for_processes_that.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/default/grub"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter GRUB_CMDLINE_LINUX to "audit=1" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^GRUB_CMDLINE_LINUX\s*=" "$CONF_FILE"; then
    sed -i "s|^GRUB_CMDLINE_LINUX\s*=.*|GRUB_CMDLINE_LINUX = "audit=1"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "GRUB_CMDLINE_LINUX = "audit=1"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0