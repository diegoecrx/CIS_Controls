#!/bin/bash
# ID: 4.2.1.6_remote_rsyslog_messages_are.sh 4.2.1.6 Ensure remote rsyslog messages are only accepted on designated log hosts. (Manual)

section=4_logging_and_auditing
sub_section=4.2_configure_logging
script_name=4.2.1.6_remote_rsyslog_messages_are.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/rsyslog.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: systemctl restart rsyslog"
systemctl restart rsyslog || result="pending"


log_event "$result"
exit 0