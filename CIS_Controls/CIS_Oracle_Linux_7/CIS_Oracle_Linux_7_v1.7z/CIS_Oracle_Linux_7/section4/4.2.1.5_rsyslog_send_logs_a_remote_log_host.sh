#!/bin/bash
# ID: 4.2.1.5_rsyslog_to_send_logs.sh 4.2.1.5 Ensure rsyslog is configured to send logs to a remote log host (Automated)

section=4_logging_and_auditing
sub_section=4.2_configure_logging
script_name=4.2.1.5_rsyslog_to_send_logs.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/rsyslog.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter action.resumeRetryCount to "<number of re-tries>" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^action.resumeRetryCount\s*=" "$CONF_FILE"; then
    sed -i "s|^action.resumeRetryCount\s*=.*|action.resumeRetryCount = "<number of re-tries>"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "action.resumeRetryCount = "<number of re-tries>"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter queue.type to "LinkedList" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^queue.type\s*=" "$CONF_FILE"; then
    sed -i "s|^queue.type\s*=.*|queue.type = "LinkedList"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "queue.type = "LinkedList"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter queue.size to <number of messages to queue>") in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^queue.size\s*=" "$CONF_FILE"; then
    sed -i "s|^queue.size\s*=.*|queue.size = <number of messages to queue>")|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "queue.size = <number of messages to queue>")" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter action.resumeRetryCount to "100" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^action.resumeRetryCount\s*=" "$CONF_FILE"; then
    sed -i "s|^action.resumeRetryCount\s*=.*|action.resumeRetryCount = "100"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "action.resumeRetryCount = "100"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter queue.type to "LinkedList" queue.size="1000") in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^queue.type\s*=" "$CONF_FILE"; then
    sed -i "s|^queue.type\s*=.*|queue.type = "LinkedList" queue.size="1000")|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "queue.type = "LinkedList" queue.size="1000")" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: systemctl restart rsyslog"
systemctl restart rsyslog || result="pending"


log_event "$result"
exit 0