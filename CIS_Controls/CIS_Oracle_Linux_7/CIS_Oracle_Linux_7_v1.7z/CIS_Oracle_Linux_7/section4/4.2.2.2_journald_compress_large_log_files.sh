#!/bin/bash
# ID: 4.2.2.2_journald_to_compress_large.sh 4.2.2.2 Ensure journald is configured to compress large log files (Automated)

section=4_logging_and_auditing
sub_section=4.2_configure_logging
script_name=4.2.2.2_journald_to_compress_large.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/systemd/journald.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter Compress to yes in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^Compress\s*=" "$CONF_FILE"; then
    sed -i "s|^Compress\s*=.*|Compress = yes|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "Compress = yes" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi


log_event "$result"
exit 0