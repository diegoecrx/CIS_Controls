#!/usr/bin/env bash
# cis_main.sh - Run CIS OL7 control scripts listed in controls.txt and ensure logging to cis_event.log
# Supports controls.txt lines as either:
#   - Control ID only (e.g., 1.1.14), matching <control>_*.sh across section1..section6
#   - Explicit script filename (e.g., 1.1.1.1_mounting_cramfs_filesystems_disabled.sh), searched by basename across section1..section6
# Guarantees a log entry if the script didn't write one, without creating new log files.

set -o errexit
set -o nounset
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR_DEFAULT="$SCRIPT_DIR"
CONTROLS_FILE_DEFAULT="$BASE_DIR_DEFAULT/controls.txt"

BASE_DIR="${BASE_DIR_DEFAULT}"
CONTROLS_FILE="${CONTROLS_FILE_DEFAULT}"

usage() {
  cat <<EOF
Usage: $0 [-c CONTROLS_FILE] [-b BASE_DIR] [-h]
  -c  Path to controls.txt (default: $CONTROLS_FILE_DEFAULT)
  -b  Base directory with section1..section6 (default: $BASE_DIR_DEFAULT)
  -h  Show help
Env:
  SECTIONS_OVERRIDE="section1 section2 ..."  # override the default sections
EOF
}

while getopts ":c:b:h" opt; do
  case "$opt" in
    c) CONTROLS_FILE="$OPTARG" ;;
    b) BASE_DIR="$OPTARG" ;;
    h) usage; exit 0 ;;
    \?) echo "Invalid option: -$OPTARG" >&2; usage; exit 1 ;;
    :)  echo "Option -$OPTARG requires an argument." >&2; usage; exit 1 ;;
  esac
done

if [[ -n "${SECTIONS_OVERRIDE:-}" ]]; then
  read -r -a SECTIONS <<<"$SECTIONS_OVERRIDE"
else
  SECTIONS=(section1 section2 section3 section4 section5 section6)
fi

[[ -d "$BASE_DIR" ]] || { echo "ERROR: Base directory not found: $BASE_DIR" >&2; exit 1; }
[[ -f "$CONTROLS_FILE" ]] || { echo "ERROR: controls.txt not found: $CONTROLS_FILE" >&2; exit 1; }

for s in "${SECTIONS[@]}"; do
  [[ -d "$BASE_DIR/$s" ]] || echo "WARN: Section directory not found: $BASE_DIR/$s" >&2
done

shopt -s nullglob

trim_spaces() { awk '{$1=$1;print}'; }
is_comment_or_empty() { [[ -z "$1" || "$1" =~ ^[[:space:]]*# ]]; }

normalize_file_endings() {
  local f="$1"
  grep -q $'\r' "$f" && sed -i 's/\r$//' "$f"
}

# Parse VAR=value (quoted or not) from a script, without executing it
parse_var() {
  local script="$1" var="$2"
  awk -v vname="^"var"[[:space:]]*=" '
    $0 ~ vname {
      line=$0
      sub(/^[^=]*=[[:space:]]*/, "", line)
      gsub(/^"/, "", line); gsub(/"$/, "", line)
      gsub(/^'\''/, "", line); gsub(/'\''$/, "", line)
      print line
      exit
    }
  ' "$script"
}

resolve_log_path() {
  local script="$1" sdir log_name
  sdir="$(dirname "$script")"
  log_name="$(parse_var "$script" "LOG_FILE")"
  [[ -z "$log_name" ]] && log_name="cis_event.log"
  [[ "$log_name" = /* ]] && { printf "%s\n" "$log_name"; return; }
  printf "%s/%s\n" "$sdir" "$log_name"
}

compose_log_line() {
  local script="$1" result="$2"
  local conf sub scriptname ts
  conf="$(parse_var "$script" "CONF_FILE")"
  sub="$(parse_var "$script" "sub_section")"
  scriptname="$(parse_var "$script" "script_name")"
  ts="$(date +"%d/%m/%Y %H:%M")"
  [[ -z "$conf" ]] && conf=""
  [[ -z "$sub" ]] && sub="UNKNOWN_SUBSECTION"
  [[ -z "$scriptname" ]] && scriptname="$(basename "$script")"
  printf "%s %s %s %s %s\n" "$ts" "$conf" "$sub" "$scriptname" "$result"
}

log_has_entry_for_script() {
  local log="$1" script="$2" scriptname
  scriptname="$(parse_var "$script" "script_name")"
  [[ -z "$scriptname" ]] && scriptname="$(basename "$script")"
  [[ -f "$log" ]] || return 1
  tail -n 100 "$log" | grep -q -- "$scriptname"
}

# Find matching scripts for a controls.txt item (control ID or explicit basename)
find_targets_for_item() {
  local item="$1"
  local matches=()

  if [[ "$item" == *.sh ]]; then
    # Item is a script basename; search across sections
    local base; base="$(basename "$item")"
    for s in "${SECTIONS[@]}"; do
      local p="$BASE_DIR/$s/$base"
      [[ -f "$p" ]] && matches+=("$p")
    done
  else
    # Item is a control ID; match <control>_*.sh across sections
    for s in "${SECTIONS[@]}"; do
      for f in "$BASE_DIR/$s/${item}"_*.sh; do
        [[ -e "$f" ]] && matches+=("$f")
      done
    done
  fi

  printf "%s\n" "${matches[@]}"
}

echo "== CIS main runner =="
echo "Base dir     : $BASE_DIR"
echo "Controls file: $CONTROLS_FILE"
echo "Sections     : ${SECTIONS[*]}"
echo
grep -q $'\r' "$CONTROLS_FILE" && echo "WARN: controls.txt has CRLF; stripping on read." >&2

declare -A RESULT
declare -A CONTROL_MATCHES

while IFS= read -r raw || [[ -n "${raw-}" ]]; do
  item="$(echo "${raw%$'\r'}" | trim_spaces)"
  is_comment_or_empty "$item" && continue

  mapfile -t found_scripts < <(find_targets_for_item "$item")

  if [[ ${#found_scripts[@]} -eq 0 ]]; then
    CONTROL_MATCHES["$item"]="NONE"
    echo "MISS: No script found for '$item'"
    continue
  fi

  CONTROL_MATCHES["$item"]="$(printf "%s," "${found_scripts[@]}" | sed 's/,$//')"
  echo "RUN : $item -> ${#found_scripts[@]} script(s)"

  for script in "${found_scripts[@]}"; do
    [[ -s "$script" ]] || { RESULT["$script"]="SKIP(empty)"; echo "SKIP: $(basename "$script") (empty)"; continue; }

    normalize_file_endings "$script"
    chmod +x "$script" 2>/dev/null || true

    script_dir="$(dirname "$script")"
    if ( cd "$script_dir" && bash "$script" ); then
      RESULT["$script"]="OK"
      echo " OK : $(basename "$script")"
      # Fallback logging if script didn't log
      log_path="$(resolve_log_path "$script")"
      if [[ -f "$log_path" ]] && ! log_has_entry_for_script "$log_path" "$script"; then
        compose_log_line "$script" "success" >> "$log_path"
      elif [[ ! -f "$log_path" ]]; then
        echo "WARN: Log not found for $(basename "$script"): expected $(basename "$log_path") in $script_dir (skip fallback)" >&2
      fi
    else
      code=$?
      RESULT["$script"]="FAIL($code)"
      echo "FAIL: $(basename "$script") (exit $code)"
      log_path="$(resolve_log_path "$script")"
      if [[ -f "$log_path" ]] && ! log_has_entry_for_script "$log_path" "$script"; then
        compose_log_line "$script" "fail" >> "$log_path"
      fi
    fi
  done
done < "$CONTROLS_FILE"

echo
echo "== Summary =="
printf "%-6s | %-60s | %-8s\n" "Type" "Item" "Result"
printf -- "%-6s-+-%-60s-+-%-8s\n" "------" "------------------------------------------------------------" "--------"

for key in "${!CONTROL_MATCHES[@]}"; do
  val="${CONTROL_MATCHES[$key]}"
  if [[ "$val" == "NONE" ]]; then
    printf "%-6s | %-60s | %-8s\n" "CTRL" "$key" "NONE"
  else
    IFS=',' read -r -a arr <<<"$val"
    for sp in "${arr[@]}"; do
      printf "%-6s | %-60s | %-8s\n" "CTRL" "$key -> $(basename "$sp")" "${RESULT[$sp]:-N/A}"
    done
  fi
done

# Orphans (should be none)
for sp in "${!RESULT[@]}"; do
  seen=0
  for key in "${!CONTROL_MATCHES[@]}"; do
    [[ "${CONTROL_MATCHES[$key]}" == *"$sp"* ]] && { seen=1; break; }
  done
  (( seen == 0 )) && printf "%-6s | %-60s | %-8s\n" "ORPH" "$(basename "$sp")" "${RESULT[$sp]}"
done

exit 0
