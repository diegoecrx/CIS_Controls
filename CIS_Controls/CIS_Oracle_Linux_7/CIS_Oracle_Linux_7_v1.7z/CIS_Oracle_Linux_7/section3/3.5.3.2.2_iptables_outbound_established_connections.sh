#!/bin/bash
# ID: 3.5.3.2.2_iptables_outbound_and_established.sh 3.5.3.2.2 Ensure iptables outbound and established connections are configured (Manual)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.2.2_iptables_outbound_and_established.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT; then
  echo "Executed: iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
else
  echo "Failed: iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
  result="pending"
fi
if iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT; then
  echo "Executed: iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
else
  echo "Failed: iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
  result="pending"
fi
if iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT; then
  echo "Executed: iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
else
  echo "Failed: iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
  result="pending"
fi
if iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT; then
  echo "Executed: iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
else
  echo "Failed: iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
  result="pending"
fi
if iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT; then
  echo "Executed: iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
else
  echo "Failed: iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
  result="pending"
fi
if iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT; then
  echo "Executed: iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
else
  echo "Failed: iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
  result="pending"
fi

log_event "$result"
exit 0
