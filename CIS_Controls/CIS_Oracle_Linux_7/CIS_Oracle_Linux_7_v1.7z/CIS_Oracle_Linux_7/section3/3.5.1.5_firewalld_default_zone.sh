#!/bin/bash
# ID: 3.5.1.5_firewalld_default_zone.sh 3.5.1.5 Ensure firewalld default zone is set (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.1.5_firewalld_default_zone.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: firewall-cmd --set-default-zone=<NAME_OF_ZONE>"
firewall-cmd --set-default-zone=<NAME_OF_ZONE> || result="pending"

echo "Executing: firewall-cmd --set-default-zone=public"
firewall-cmd --set-default-zone=public || result="pending"


log_event "$result"
exit 0