#!/bin/bash
# ID: 3.5.2.5_an_nftables_table_exists.sh 3.5.2.7 Ensure nftables loopback traffic is configured (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.2.5_an_nftables_table_exists.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if nft add rule inet filter input iif lo accept; then
  echo "Executed: nft add rule inet filter input iif lo accept"
else
  echo "Failed: nft add rule inet filter input iif lo accept"
  result="pending"
fi
if nft create rule inet filter input ip saddr 127.0.0.0/8 counter drop; then
  echo "Executed: nft create rule inet filter input ip saddr 127.0.0.0/8 counter drop"
else
  echo "Failed: nft create rule inet filter input ip saddr 127.0.0.0/8 counter drop"
  result="pending"
fi
if nft add rule inet filter input ip6 saddr ::1 counter drop; then
  echo "Executed: nft add rule inet filter input ip6 saddr ::1 counter drop"
else
  echo "Failed: nft add rule inet filter input ip6 saddr ::1 counter drop"
  result="pending"
fi

log_event "$result"
exit 0
