#!/bin/bash
# ID: 3.2.1_ip_forwarding.sh 3.2.1 Ensure IP forwarding is disabled (Automated)

section=3_network_configuration
sub_section=3.2_network_parameters
script_name=3.2.1_ip_forwarding.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/sysctl.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter net.ipv4.route.flush to 1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv4.route.flush\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv4.route.flush\s*=.*|net.ipv4.route.flush = 1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv4.route.flush = 1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter net.ipv6.route.flush to 1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv6.route.flush\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv6.route.flush\s*=.*|net.ipv6.route.flush = 1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv6.route.flush = 1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: grep -Els \"^\s*net\.ipv4\.ip_forward\s*=\s*1\" /etc/sysctl.conf"
grep -Els "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf || result="pending"

echo "Executing: grep -Els \"^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1\" /etc/sysctl.conf"
grep -Els "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf || result="pending"


log_event "$result"
exit 0