#!/bin/bash
# ID: 3.5.2.4_iptables_are_flushed_nftables.sh 3.5.2.6 Ensure nftables base chains exist (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.2.4_iptables_are_flushed_nftables.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if nft create chain inet <table name> <base chain name> { type filter hook; then
  echo "Executed: nft create chain inet <table name> <base chain name> { type filter hook"
else
  echo "Failed: nft create chain inet <table name> <base chain name> { type filter hook"
  result="pending"
fi
if nft create chain inet filter input { type filter hook input priority 0 \; }; then
  echo "Executed: nft create chain inet filter input { type filter hook input priority 0 \; }"
else
  echo "Failed: nft create chain inet filter input { type filter hook input priority 0 \; }"
  result="pending"
fi
if nft create chain inet filter forward { type filter hook forward priority 0; then
  echo "Executed: nft create chain inet filter forward { type filter hook forward priority 0"
else
  echo "Failed: nft create chain inet filter forward { type filter hook forward priority 0"
  result="pending"
fi
if nft create chain inet filter output { type filter hook output priority 0 \;; then
  echo "Executed: nft create chain inet filter output { type filter hook output priority 0 \;"
else
  echo "Failed: nft create chain inet filter output { type filter hook output priority 0 \;"
  result="pending"
fi

log_event "$result"
exit 0
