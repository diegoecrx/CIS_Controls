#!/bin/bash
# ID: 3.5.3.3.2_ip6tables_outbound_and_established.sh 3.5.3.3.2 Ensure ip6tables outbound and established connections are configured (Manual)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.3.2_ip6tables_outbound_and_established.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT; then
  echo "Executed: ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
else
  echo "Failed: ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
  result="pending"
fi
if ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT; then
  echo "Executed: ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
else
  echo "Failed: ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
  result="pending"
fi
if ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT; then
  echo "Executed: ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
else
  echo "Failed: ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
  result="pending"
fi
if ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT; then
  echo "Executed: ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
else
  echo "Failed: ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
  result="pending"
fi
if ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT; then
  echo "Executed: ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
else
  echo "Failed: ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
  result="pending"
fi
if ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT; then
  echo "Executed: ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
else
  echo "Failed: ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
  result="pending"
fi

log_event "$result"
exit 0
