#!/bin/bash
# ID: 3.5.1.3_nftables_either_not_installed.sh 3.5.1.3 Ensure nftables either not installed or masked with firewalld (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.1.3_nftables_either_not_installed.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: yum remove nftables"
yum remove nftables || result="pending"

echo "Executing: systemctl --now mask nftables"
systemctl --now mask nftables || result="pending"


log_event "$result"
exit 0