#!/bin/bash
# ID: 3.3.1_source_routed_packets_are.sh 3.3.1 Ensure source routed packets are not accepted (Automated)

section=3_network_configuration
sub_section=3.3_network_parameters
script_name=3.3.1_source_routed_packets_are.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/sysctl.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter net.ipv4.conf.all.accept_source_route to 0 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv4.conf.all.accept_source_route\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv4.conf.all.accept_source_route\s*=.*|net.ipv4.conf.all.accept_source_route = 0|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv4.conf.all.accept_source_route = 0" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter net.ipv4.conf.default.accept_source_route to 0 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv4.conf.default.accept_source_route\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv4.conf.default.accept_source_route\s*=.*|net.ipv4.conf.default.accept_source_route = 0|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv4.conf.default.accept_source_route = 0" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter net.ipv6.conf.all.accept_source_route to 0 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv6.conf.all.accept_source_route\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv6.conf.all.accept_source_route\s*=.*|net.ipv6.conf.all.accept_source_route = 0|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv6.conf.all.accept_source_route = 0" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter net.ipv6.conf.default.accept_source_route to 0 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv6.conf.default.accept_source_route\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv6.conf.default.accept_source_route\s*=.*|net.ipv6.conf.default.accept_source_route = 0|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv6.conf.default.accept_source_route = 0" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: sysctl -w net.ipv4.conf.all.accept_source_route=0"
sysctl -w net.ipv4.conf.all.accept_source_route=0 || result="pending"

echo "Executing: sysctl -w net.ipv4.conf.default.accept_source_route=0"
sysctl -w net.ipv4.conf.default.accept_source_route=0 || result="pending"

echo "Executing: sysctl -w net.ipv4.route.flush=1"
sysctl -w net.ipv4.route.flush=1 || result="pending"

echo "Executing: sysctl -w net.ipv6.conf.all.accept_source_route=0"
sysctl -w net.ipv6.conf.all.accept_source_route=0 || result="pending"

echo "Executing: sysctl -w net.ipv6.conf.default.accept_source_route=0"
sysctl -w net.ipv6.conf.default.accept_source_route=0 || result="pending"

echo "Executing: sysctl -w net.ipv6.route.flush=1"
sysctl -w net.ipv6.route.flush=1 || result="pending"


log_event "$result"
exit 0