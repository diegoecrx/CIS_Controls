#!/bin/bash
# ID: 3.5.2.6_nftables_base_chains_exist.sh 3.5.2.8 Ensure nftables outbound and established connections are configured (Manual)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.2.6_nftables_base_chains_exist.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if nft add rule inet filter input ip protocol tcp ct state established accept; then
  echo "Executed: nft add rule inet filter input ip protocol tcp ct state established accept"
else
  echo "Failed: nft add rule inet filter input ip protocol tcp ct state established accept"
  result="pending"
fi
if nft add rule inet filter input ip protocol udp ct state established accept; then
  echo "Executed: nft add rule inet filter input ip protocol udp ct state established accept"
else
  echo "Failed: nft add rule inet filter input ip protocol udp ct state established accept"
  result="pending"
fi
if nft add rule inet filter input ip protocol icmp ct state established accept; then
  echo "Executed: nft add rule inet filter input ip protocol icmp ct state established accept"
else
  echo "Failed: nft add rule inet filter input ip protocol icmp ct state established accept"
  result="pending"
fi
if nft add rule inet filter output ip protocol tcp ct state; then
  echo "Executed: nft add rule inet filter output ip protocol tcp ct state"
else
  echo "Failed: nft add rule inet filter output ip protocol tcp ct state"
  result="pending"
fi
if nft add rule inet filter output ip protocol udp ct state; then
  echo "Executed: nft add rule inet filter output ip protocol udp ct state"
else
  echo "Failed: nft add rule inet filter output ip protocol udp ct state"
  result="pending"
fi
if nft add rule inet filter output ip protocol icmp ct state; then
  echo "Executed: nft add rule inet filter output ip protocol icmp ct state"
else
  echo "Failed: nft add rule inet filter output ip protocol icmp ct state"
  result="pending"
fi

log_event "$result"
exit 0
