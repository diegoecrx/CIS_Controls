#!/bin/bash
# ID: 3.5.1.2_iptablesservices_not_installed_firewalld.sh 3.5.1.2 Ensure iptables-services not installed with firewalld (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.1.2_iptablesservices_not_installed_firewalld.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: systemctl stop iptables"
systemctl stop iptables || result="pending"

echo "Executing: systemctl stop ip6tables"
systemctl stop ip6tables || result="pending"

echo "Executing: yum remove iptables-services"
yum remove iptables-services || result="pending"


log_event "$result"
exit 0