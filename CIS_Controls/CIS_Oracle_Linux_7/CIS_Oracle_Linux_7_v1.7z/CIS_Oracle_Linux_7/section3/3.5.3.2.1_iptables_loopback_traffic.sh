#!/bin/bash
# ID: 3.5.3.2.1_iptables_loopback_traffic.sh 3.5.3.2.1 Ensure iptables loopback traffic is configured (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.2.1_iptables_loopback_traffic.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if iptables -A INPUT -i lo -j ACCEPT; then
  echo "Executed: iptables -A INPUT -i lo -j ACCEPT"
else
  echo "Failed: iptables -A INPUT -i lo -j ACCEPT"
  result="pending"
fi
if iptables -A OUTPUT -o lo -j ACCEPT; then
  echo "Executed: iptables -A OUTPUT -o lo -j ACCEPT"
else
  echo "Failed: iptables -A OUTPUT -o lo -j ACCEPT"
  result="pending"
fi
if iptables -A INPUT -s 127.0.0.0/8 -j DROP; then
  echo "Executed: iptables -A INPUT -s 127.0.0.0/8 -j DROP"
else
  echo "Failed: iptables -A INPUT -s 127.0.0.0/8 -j DROP"
  result="pending"
fi

log_event "$result"
exit 0
