#!/bin/bash
# ID: 3.5.2.7_nftables_loopback_traffic.sh 3.5.2.9 Ensure nftables default deny firewall policy (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.2.7_nftables_loopback_traffic.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if nft chain <table family> <table name> <chain name> { policy drop \; }; then
  echo "Executed: nft chain <table family> <table name> <chain name> { policy drop \; }"
else
  echo "Failed: nft chain <table family> <table name> <chain name> { policy drop \; }"
  result="pending"
fi
if nft chain inet filter input { policy drop \; }; then
  echo "Executed: nft chain inet filter input { policy drop \; }"
else
  echo "Failed: nft chain inet filter input { policy drop \; }"
  result="pending"
fi
if nft chain inet filter forward { policy drop \; }; then
  echo "Executed: nft chain inet filter forward { policy drop \; }"
else
  echo "Failed: nft chain inet filter forward { policy drop \; }"
  result="pending"
fi
if nft chain inet filter output { policy drop \; }; then
  echo "Executed: nft chain inet filter output { policy drop \; }"
else
  echo "Failed: nft chain inet filter output { policy drop \; }"
  result="pending"
fi

log_event "$result"
exit 0
