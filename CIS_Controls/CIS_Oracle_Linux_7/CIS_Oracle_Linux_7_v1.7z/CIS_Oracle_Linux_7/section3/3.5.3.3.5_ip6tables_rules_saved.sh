#!/bin/bash
# ID: 3.5.3.3.5_ip6tables_rules_are_saved.sh 3.5.3.3.5 Ensure ip6tables rules are saved (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.3.5_ip6tables_rules_are_saved.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/sysconfig/ip6tables"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if ip6tables -L; then
  echo "Executed: ip6tables -L"
else
  echo "Failed: ip6tables -L"
  result="pending"
fi
if service ip6tables save; then
  echo "Executed: service ip6tables save"
else
  echo "Failed: service ip6tables save"
  result="pending"
fi

log_event "$result"
exit 0
