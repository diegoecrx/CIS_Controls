#!/bin/bash
# ID: 3.1.2_wireless_interfaces_are.sh 3.1.2 Ensure wireless interfaces are disabled (Automated)

section=3_network_configuration
sub_section=3.1_disable_unused_network_protocols_and_devices
script_name=3.1.2_wireless_interfaces_are.sh
profile_app_server=1
profile_app_workstation=2

CONF_FILE="/etc/modprobe.d/disable_wireless.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter mname to $(for driverdir in $(find /sys/class/net/*/ -type d -name in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^mname\s*=" "$CONF_FILE"; then
    sed -i "s|^mname\s*=.*|mname = $(for driverdir in $(find /sys/class/net/*/ -type d -name|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "mname = $(for driverdir in $(find /sys/class/net/*/ -type d -name" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: echo \"install $dm /bin/true\" >>"
echo "install $dm /bin/true" >> || result="pending"


log_event "$result"
exit 0