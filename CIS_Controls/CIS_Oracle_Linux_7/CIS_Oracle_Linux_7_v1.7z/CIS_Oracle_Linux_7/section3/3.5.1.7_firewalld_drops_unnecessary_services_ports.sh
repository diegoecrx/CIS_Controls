#!/bin/bash
# ID: 3.5.1.7_firewalld_drops_unnecessary_services.sh 3.5.1.7 Ensure firewalld drops unnecessary services and ports (Manual)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.1.7_firewalld_drops_unnecessary_services.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: firewall-cmd --remove-service=<service>"
firewall-cmd --remove-service=<service> || result="pending"

echo "Executing: firewall-cmd --remove-service=cockpit"
firewall-cmd --remove-service=cockpit || result="pending"

echo "Executing: firewall-cmd --remove-port=<port-number>/<port-type>"
firewall-cmd --remove-port=<port-number>/<port-type> || result="pending"

echo "Executing: firewall-cmd --remove-port=25/tcp"
firewall-cmd --remove-port=25/tcp || result="pending"

echo "Executing: firewall-cmd --runtime-to-permanent"
firewall-cmd --runtime-to-permanent || result="pending"


log_event "$result"
exit 0