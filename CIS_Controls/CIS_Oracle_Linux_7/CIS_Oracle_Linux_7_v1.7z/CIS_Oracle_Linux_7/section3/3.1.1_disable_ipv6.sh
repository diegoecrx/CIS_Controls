#!/bin/bash
# ID: 3.1.1_disable_ipv6.sh 3.1.1 Disable IPv6 (Manual)

section=3_network_configuration
sub_section=3.1_disable_unused_network_protocols_and_devices
script_name=3.1.1_disable_ipv6.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/sysctl.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Setting parameter GRUB_CMDLINE_LINUX to "ipv6.disable=1" in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^GRUB_CMDLINE_LINUX\s*=" "$CONF_FILE"; then
    sed -i "s|^GRUB_CMDLINE_LINUX\s*=.*|GRUB_CMDLINE_LINUX = "ipv6.disable=1"|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "GRUB_CMDLINE_LINUX = "ipv6.disable=1"" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter net.ipv6.conf.all.disable_ipv6 to 1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv6.conf.all.disable_ipv6\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv6.conf.all.disable_ipv6\s*=.*|net.ipv6.conf.all.disable_ipv6 = 1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv6.conf.all.disable_ipv6 = 1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Setting parameter net.ipv6.conf.default.disable_ipv6 to 1 in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if grep -q "^net.ipv6.conf.default.disable_ipv6\s*=" "$CONF_FILE"; then
    sed -i "s|^net.ipv6.conf.default.disable_ipv6\s*=.*|net.ipv6.conf.default.disable_ipv6 = 1|" "$CONF_FILE" || result="pending"
    echo "Updated existing parameter"
  else
    echo "net.ipv6.conf.default.disable_ipv6 = 1" >> "$CONF_FILE" || result="pending"
    echo "Added new parameter"
  fi
fi

echo "Executing: sysctl -w net.ipv6.conf.all.disable_ipv6=1"
sysctl -w net.ipv6.conf.all.disable_ipv6=1 || result="pending"

echo "Executing: sysctl -w net.ipv6.conf.default.disable_ipv6=1"
sysctl -w net.ipv6.conf.default.disable_ipv6=1 || result="pending"

echo "Executing: sysctl -w net.ipv6.route.flush=1"
sysctl -w net.ipv6.route.flush=1 || result="pending"


log_event "$result"
exit 0