#!/bin/bash
# ID: 3.5.3.2.5_iptables_rules_are_saved.sh 3.5.3.2.5 Ensure iptables rules are saved (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.2.5_iptables_rules_are_saved.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE="/etc/sysconfig/iptables"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if iptables -L; then
  echo "Executed: iptables -L"
else
  echo "Failed: iptables -L"
  result="pending"
fi
if service iptables save; then
  echo "Executed: service iptables save"
else
  echo "Failed: service iptables save"
  result="pending"
fi

log_event "$result"
exit 0
