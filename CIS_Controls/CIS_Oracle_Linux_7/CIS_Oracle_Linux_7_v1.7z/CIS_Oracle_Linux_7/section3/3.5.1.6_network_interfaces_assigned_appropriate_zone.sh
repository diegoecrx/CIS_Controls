#!/bin/bash
# ID: 3.5.1.6_network_interfaces_are_assigned.sh 3.5.1.6 Ensure network interfaces are assigned to appropriate zone (Manual)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.1.6_network_interfaces_are_assigned.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Executing: firewall-cmd --zone=<Zone NAME> --change-interface=<INTERFACE NAME>"
firewall-cmd --zone=<Zone NAME> --change-interface=<INTERFACE NAME> || result="pending"

echo "Executing: firewall-cmd --zone=customezone --change-interface=eth0"
firewall-cmd --zone=customezone --change-interface=eth0 || result="pending"


log_event "$result"
exit 0