#!/bin/bash
# ID: 3.4.1_dccp.sh 3.4.1 Ensure DCCP is disabled (Automated)

section=3_network_configuration
sub_section=3.4_uncommon_network_protocols
script_name=3.4.1_dccp.sh
profile_app_server=2
profile_app_workstation=2

CONF_FILE="/etc/modprobe.d/dccp.conf"
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Remediation commands
result="success"

echo "Ensuring configuration: install dccp /bin/true in $CONF_FILE"
if [ -n "$CONF_FILE" ]; then
  if [ ! -f "$CONF_FILE" ]; then
    echo "install dccp /bin/true" > "$CONF_FILE" || result="pending"
    echo "File $CONF_FILE created"
  else
    if ! grep -q "^install dccp /bin/true$" "$CONF_FILE"; then
      echo "install dccp /bin/true" >> "$CONF_FILE" || result="pending"
      echo "Appended install dccp /bin/true to $CONF_FILE"
    fi
  fi
fi

echo "Attempting to remove module dccp"
rmmod dccp || true


log_event "$result"
exit 0