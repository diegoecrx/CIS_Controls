#!/bin/bash
# ID: 3.5.3.2.4_iptables_default_deny_firewall.sh 3.5.3.2.4 Ensure iptables default deny firewall policy (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.2.4_iptables_default_deny_firewall.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if iptables -P INPUT DROP; then
  echo "Executed: iptables -P INPUT DROP"
else
  echo "Failed: iptables -P INPUT DROP"
  result="pending"
fi
if iptables -P OUTPUT DROP; then
  echo "Executed: iptables -P OUTPUT DROP"
else
  echo "Failed: iptables -P OUTPUT DROP"
  result="pending"
fi
if iptables -P FORWARD DROP; then
  echo "Executed: iptables -P FORWARD DROP"
else
  echo "Failed: iptables -P FORWARD DROP"
  result="pending"
fi

log_event "$result"
exit 0
