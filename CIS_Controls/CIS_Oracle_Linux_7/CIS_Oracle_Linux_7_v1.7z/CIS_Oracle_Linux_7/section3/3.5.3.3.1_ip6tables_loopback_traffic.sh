#!/bin/bash
# ID: 3.5.3.3.1_ip6tables_loopback_traffic.sh 3.5.3.3.1 Ensure ip6tables loopback traffic is configured (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.3.3.1_ip6tables_loopback_traffic.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if ip6tables -A INPUT -i lo -j ACCEPT; then
  echo "Executed: ip6tables -A INPUT -i lo -j ACCEPT"
else
  echo "Failed: ip6tables -A INPUT -i lo -j ACCEPT"
  result="pending"
fi
if ip6tables -A OUTPUT -o lo -j ACCEPT; then
  echo "Executed: ip6tables -A OUTPUT -o lo -j ACCEPT"
else
  echo "Failed: ip6tables -A OUTPUT -o lo -j ACCEPT"
  result="pending"
fi
if ip6tables -A INPUT -s ::1 -j DROP; then
  echo "Executed: ip6tables -A INPUT -s ::1 -j DROP"
else
  echo "Failed: ip6tables -A INPUT -s ::1 -j DROP"
  result="pending"
fi

log_event "$result"
exit 0
