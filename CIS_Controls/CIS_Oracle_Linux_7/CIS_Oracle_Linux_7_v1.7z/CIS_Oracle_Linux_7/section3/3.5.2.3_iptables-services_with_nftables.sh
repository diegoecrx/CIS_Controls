#!/bin/bash
# ID: 3.5.2.3_iptablesservices_not_installed_nftables.sh 3.5.2.5 Ensure an nftables table exists (Automated)

section=3_network_configuration
sub_section=3.5_firewall_configuration
script_name=3.5.2.3_iptablesservices_not_installed_nftables.sh
profile_app_server=1
profile_app_workstation=1

CONF_FILE=""
LOG_FILE="/home/user/CIS_Oracle_Linux_7/cis_event.log"

log_event() {
  local result="$1"
  local timestamp=$(date +"%d/%m/%Y %H:%M")
  echo "$timestamp $CONF_FILE $sub_section $script_name $result" >> "$LOG_FILE"
}

# Implement remediation commands
result="success"
if nft create table inet <table name>; then
  echo "Executed: nft create table inet <table name>"
else
  echo "Failed: nft create table inet <table name>"
  result="pending"
fi
if nft create table inet filter; then
  echo "Executed: nft create table inet filter"
else
  echo "Failed: nft create table inet filter"
  result="pending"
fi

log_event "$result"
exit 0
