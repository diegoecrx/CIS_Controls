# 2.3.7.7.ps1
(& {
  Write-Output "Control: 2.3.7.7 (L1) Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days' (Automated)"
  Write-Output "Note: Configure legal notice message title"
  Write-Output "This setting requires manual configuration via Group Policy or Local Security Policy"
})
