###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark - Section 18 Scripts
# README for Administrative Templates (Registry-Based) Configuration Scripts
###############################################################################

OVERVIEW
========
This package contains 240 PowerShell remediation scripts for CIS Microsoft Windows Server 2022 Benchmark Section 18.
All scripts configure Group Policy Administrative Templates through direct registry modifications.

Section 18 is the LARGEST section of the CIS Benchmark, covering comprehensive Windows configuration settings
across multiple categories including security, networking, system behavior, and application settings.

IMPORTANT NOTE
==============
Administrative Templates are registry-based Group Policy settings. These scripts directly modify the Windows
registry to apply the CIS-recommended configurations. While this provides immediate effect, enterprise
environments should ideally deploy these settings via Group Policy for centralized management.

SCRIPT CATEGORIES
=================

18.1.x - Control Panel Settings (4 scripts)
--------------------------------------------
Lock screen, personalization, and privacy settings

18.4.x - MSS (Microsoft Security Settings) & Core Settings (7 scripts)
----------------------------------------------------------------------
UAC restrictions, SMB v1, certificate padding, SEHOP, NetBT, WDigest

18.5.x - MSS (Microsoft Security Settings) Network (12 scripts)
---------------------------------------------------------------
IP source routing, ICMP, keep-alive, NetBIOS, router discovery, DLL search, screen saver

18.6.x - DNS Client Settings (16 scripts)
-----------------------------------------
DNS over HTTPS, multicast, LLMNR, NetBIOS

18.7.x - Event Log Settings (12 scripts)
----------------------------------------
Application, Security, Setup, and System log sizes and retention

18.8.x - Kerberos Settings (1 script)
-------------------------------------
Kerberos encryption types

18.9.x - Logon & Credential Management (71 scripts)
---------------------------------------------------
Biometrics, cached credentials, Ctrl+Alt+Del, legal notices, password reveal,
picture passwords, PIN sign-in, smart cards, Windows Hello

18.10.x - Windows Components & Applications (117+ scripts)
----------------------------------------------------------
The largest subcategory covering:
  - App runtime
  - Auto Play
  - BitLocker Drive Encryption
  - Camera
  - Cloud Content
  - Credential User Interface
  - Data Collection and Preview Builds
  - Delivery Optimization
  - Desktop App Installer
  - Device Guard
  - Device Installation
  - Early Launch Antimalware
  - Event Forwarding
  - File Explorer
  - HomeGroup
  - Internet Explorer (legacy)
  - Location and Sensors
  - Messaging
  - Microsoft accounts
  - Microsoft Defender Antivirus
  - Microsoft Defender Application Guard
  - Microsoft Defender Exploit Guard
  - Microsoft Edge (Chromium-based)
  - Network Connections
  - OneDrive
  - Remote Desktop Services
  - RSS Feeds
  - Search
  - Server Manager
  - Store
  - Telemetry
  - Windows Error Reporting
  - Windows Game Recording
  - Windows Ink Workspace
  - Windows Installer
  - Windows Logon Options
  - Windows PowerShell
  - Windows Remote Management (WinRM)
  - Windows Remote Shell (WinRS)
  - Windows Security
  - Windows Time Service
  - Windows Update

PROFILE APPLICABILITY
=====================
Scripts apply to various profiles:
• Level 1 - Domain Controller
• Level 1 - Member Server
• Level 2 - Domain Controller
• Level 2 - Member Server

Many scripts include automatic detection to skip if not applicable to system type.

USAGE
=====
All scripts must be run as Administrator.

Run individual script:
  PS> .\18.1.1.1.ps1

Run all scripts in a subcategory:
  PS> Get-ChildItem -Filter 18.5.*.ps1 | ForEach-Object { & $_.FullName }

Run ALL Administrative Template scripts (USE WITH CAUTION):
  PS> Get-ChildItem -Filter 18.*.ps1 | Sort-Object Name | ForEach-Object { & $_.FullName }

RECOMMENDED DEPLOYMENT APPROACH
===============================
Due to the large number of scripts (240), we recommend:

1. Phased deployment by category:
   - Start with MSS settings (18.4.x, 18.5.x)
   - Then DNS Client (18.6.x)
   - Event Logs (18.7.x)
   - Credential management (18.9.x)
   - Finally Windows Components (18.10.x)

2. Test in non-production first:
   - Deploy to test servers
   - Verify application functionality
   - Monitor for issues

3. Deploy by priority:
   - Level 1 controls first (mandatory)
   - Level 2 controls second (high security)

4. Use Group Policy in production:
   - Scripts are for quick remediation
   - GPO provides central management
   - Better for large environments

WHAT THE SCRIPTS DO
===================
1. Detect system type (Domain Controller or Member Server)
2. Skip execution if control doesn't apply to system type
3. Check if registry path exists (create if missing)
4. Read current registry value
5. Apply CIS-recommended configuration
6. Verify configuration after changes
7. Provide detailed status reporting

FEATURES
========
✓ Direct registry modification
✓ Automatic DC/MS detection and filtering
✓ Current value reporting
✓ Registry path creation if needed
✓ Configuration verification
✓ Comprehensive error handling
✓ Manual remediation guidance

CRITICAL CONTROLS
=================

High-Impact Security Settings:
  18.4.2 - Disable SMB v1 client
  18.4.3 - Disable SMB v1 server
  18.4.7 - Disable WDigest Authentication
  18.10.8.1 - Disable AutoPlay
  18.10.8.2 - Set AutoPlay default
  18.10.9.1.1 - BitLocker encryption
  18.10.43.x - Microsoft Defender settings
  18.10.57.x - Remote Desktop Services hardening
  18.10.87.x - Windows PowerShell script execution
  18.10.89.x - Windows Update settings

Privacy & Data Protection:
  18.1.2.2 - Disable online speech recognition
  18.1.3 - Disable online tips
  18.9.x - Credential management
  18.10.26.x - Data collection settings

Network Security:
  18.5.2 - Disable IPv6 source routing
  18.5.3 - Disable IPv4 source routing
  18.5.4 - Disable ICMP redirects
  18.6.x - DNS security settings

IMPACT ASSESSMENT
=================

Performance Impact:
  - Minimal CPU/memory overhead
  - Some settings may affect user experience
  - BitLocker may impact disk performance

Functionality Impact:
  ⚠️ SMB v1 disabling may break legacy applications
  ⚠️ AutoPlay disabling affects removable media
  ⚠️ PowerShell restrictions affect scripts
  ⚠️ Some settings disable features users may expect

Recommended Pre-Deployment:
  1. Review all 240 controls and their impact
  2. Identify settings that may affect your environment
  3. Create exceptions where necessary
  4. Document all changes
  5. Have rollback plan ready

VERIFICATION
============

Check individual registry value:
  PS> Get-ItemProperty -Path "HKLM:\Path\To\Key" -Name "ValueName"

Export registry branch for backup:
  PS> reg export "HKLM\SOFTWARE\Policies" C:\backup\policies.reg

Compare before/after registry state:
  Before deployment:
    PS> reg export HKLM C:\backup\before.reg

  After deployment:
    PS> reg export HKLM C:\backup\after.reg
    PS> fc C:\backup\before.reg C:\backup\after.reg

Verify Group Policy refresh:
  PS> gpupdate /force
  PS> gpresult /h gpresult.html

REGISTRY STRUCTURE
==================

Administrative Templates typically store settings in:
  HKLM:\SOFTWARE\Policies\Microsoft\...
  HKLM:\SOFTWARE\Microsoft\...
  HKLM:\SYSTEM\CurrentControlSet\...

Common Registry Value Types:
  REG_DWORD (32-bit number)
    - 0 = Disabled
    - 1 = Enabled

  REG_SZ (String value)
    - Text configuration

  REG_MULTI_SZ (Multi-string value)
    - Multiple text values

TROUBLESHOOTING
===============

If script fails:

1. Check Administrator privileges:
   PS> [Security.Principal.WindowsIdentity]::GetCurrent().Groups -contains 'S-1-5-32-544'

2. Verify registry permissions:
   PS> $acl = Get-Acl "HKLM:\Path"
   PS> $acl.Access

3. Check for Group Policy conflicts:
   PS> gpresult /h gpresult.html
   Review for conflicting settings

4. Verify system type:
   PS> (Get-WmiObject Win32_ComputerSystem).DomainRole
   # 4 or 5 = Domain Controller

5. Test registry access:
   PS> Test-Path "HKLM:\SOFTWARE\Policies"

BACKUP AND RESTORE
==================

Before deployment, backup registry:
  # Backup entire HKLM
  reg export HKLM C:\backup\hklm_full.reg

  # Backup Policies only
  reg export "HKLM\SOFTWARE\Policies" C:\backup\policies.reg

Restore from backup:
  reg import C:\backup\policies.reg

Create System Restore Point:
  PS> Checkpoint-Computer -Description "Before CIS Section 18" -RestorePointType MODIFY_SETTINGS

ROLLBACK
========

To undo changes:

Method 1 - Restore Registry Backup:
  reg import C:\backup\policies_before.reg

Method 2 - System Restore:
  rstrui.exe

Method 3 - Reset Specific Values:
  Remove-ItemProperty -Path "HKLM:\Path" -Name "ValueName"

Method 4 - Group Policy Reset:
  1. Open gpedit.msc
  2. Set policies to "Not Configured"
  3. gpupdate /force

ALTERNATIVE METHODS
===================

If PowerShell scripts cannot be used:

Method 1 - Group Policy Editor (gpedit.msc):
  1. Open gpedit.msc
  2. Navigate to: Computer Configuration > Administrative Templates
  3. Configure each setting according to CIS recommendations
  4. gpupdate /force

Method 2 - Registry Editor (regedit.exe):
  1. Open regedit.exe
  2. Navigate to registry path
  3. Create/modify values as specified
  4. Restart or gpupdate

Method 3 - Group Policy Objects (Domain):
  1. Open gpmc.msc
  2. Create/edit GPO
  3. Link to appropriate OUs
  4. Force policy update

Method 4 - PowerShell DSC:
  Use Desired State Configuration for continuous compliance

BEST PRACTICES
==============

1. Documentation:
   - Document all changes before deployment
   - Keep registry backups dated
   - Maintain change log

2. Testing:
   - Always test in lab environment
   - Verify application compatibility
   - Test user workflows

3. Phased Rollout:
   - Deploy to pilot group first
   - Monitor for 1-2 weeks
   - Gradually expand scope

4. Monitoring:
   - Monitor event logs for errors
   - Track help desk tickets
   - Review user feedback

5. Maintenance:
   - Review settings quarterly
   - Update for new CIS versions
   - Remove deprecated settings

6. Use Group Policy for Production:
   - Centralized management
   - Easy rollback
   - Reporting capabilities
   - Incremental deployment

COMMON SETTINGS BY CATEGORY
============================

SMB Security:
  18.4.2 - Disable SMB v1 client
  18.4.3 - Disable SMB v1 server

Credential Protection:
  18.4.7 - Disable WDigest
  18.9.x - Credential UI settings

Device Security:
  18.10.8.x - AutoPlay/AutoRun
  18.10.9.x - BitLocker encryption

Application Security:
  18.10.43.x - Microsoft Defender
  18.10.87.x - PowerShell restrictions

Remote Access:
  18.10.57.x - Remote Desktop Services
  18.10.82.x - Windows Remote Management

Updates & Telemetry:
  18.10.89.x - Windows Update
  18.10.26.x - Data Collection

COMPLIANCE
==========
These Administrative Template settings help meet requirements for:
  - PCI DSS (Payment Card Industry)
  - HIPAA (Healthcare)
  - SOX (Financial)
  - NIST 800-53 (Federal)
  - ISO 27001 (Information Security)
  - GDPR (Privacy)

TESTING CHECKLIST
=================
Before deployment, test:
  ☐ User logon/logoff
  ☐ Network file shares (SMB)
  ☐ Remote Desktop connections
  ☐ PowerShell script execution
  ☐ Windows Update functionality
  ☐ Antivirus/EDR functionality
  ☐ Line of business applications
  ☐ User productivity tools
  ☐ Backup software
  ☐ Monitoring agents

SUPPORT
=======
For issues or questions, refer to:
  - CIS Microsoft Windows Server 2022 Benchmark v4.0.0
  - Microsoft Group Policy documentation
  - Windows Registry reference

ADDITIONAL RESOURCES
====================
- Group Policy Central: https://admx.help/
- Group Policy settings reference: https://docs.microsoft.com/en-us/windows/client-management/mdm/policy-configuration-service-provider
- CIS Benchmarks: https://www.cisecurity.org/cis-benchmarks

WARNING
=======
⚠️ These scripts make direct registry modifications
⚠️ Always backup before making changes
⚠️ Test thoroughly in non-production environment
⚠️ Some settings may break applications or features
⚠️ Review each control before deploying
⚠️ Have rollback plan ready

Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
