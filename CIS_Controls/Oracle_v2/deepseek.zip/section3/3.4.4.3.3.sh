#!/usr/bin/env bash
# Script: 3.4.4.3.3.sh
# Item: 3.4.4.3.3 Ensure ip6tables firewall rules exist for all open ports (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.3.3.sh"
ITEM_NAME="3.4.4.3.3 Ensure ip6tables firewall rules exist for all open ports (Automated)"
DESCRIPTION="This remediation ensures ip6tables rules exist for all open IPv6 ports."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ip6tables rules for open IPv6 ports..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Get list of listening IPv6 ports
    listening_ports=$(ss -tuln6 | awk 'NR>1 && $1~/^tcp|^udp/ && $5~/\[.*\]:/ {gsub(/.*\]:/, "", $5); print $1 ":" $5}' | sort -u)
    
    if [ -z "$listening_ports" ]; then
        echo "PASS: No IPv6 listening ports found"
        echo "PROOF: No open IPv6 ports detected"
        return 0
    fi
    
    # Check each listening port for corresponding ip6tables rule
    unprotected_ports=""
    for port_info in $listening_ports; do
        protocol=$(echo "$port_info" | cut -d: -f1)
        port=$(echo "$port_info" | cut -d: -f2)
        
        # Skip if port is 0 or not numeric
        if ! [[ "$port" =~ ^[0-9]+$ ]] || [ "$port" = "0" ]; then
            continue
        fi
        
        # Check if ip6tables rule exists for this port
        if [ "$protocol" = "tcp" ]; then
            if ! ip6tables -L INPUT -n | grep -q "tcp dpt:$port"; then
                unprotected_ports="${unprotected_ports}tcp:$port "
            fi
        elif [ "$protocol" = "udp" ]; then
            if ! ip6tables -L INPUT -n | grep -q "udp dpt:$port"; then
                unprotected_ports="${unprotected_ports}udp:$port "
            fi
        fi
    done
    
    if [ -n "$unprotected_ports" ]; then
        echo "FAIL: Open IPv6 ports without ip6tables rules found"
        echo "PROOF: Unprotected IPv6 ports: $unprotected_ports"
        return 1
    fi
    
    echo "PASS: All open IPv6 ports have corresponding ip6tables rules"
    echo "PROOF: All listening IPv6 ports are protected by firewall rules"
    return 0
}
# Function to fix
fix_ip6tables_open_ports() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    # Get list of listening IPv6 ports
    listening_ports=$(ss -tuln6 | awk 'NR>1 && $1~/^tcp|^udp/ && $5~/\[.*\]:/ {gsub(/.*\]:/, "", $5); print $1 ":" $5}' | sort -u)
    
    if [ -z "$listening_ports" ]; then
        echo " - No listening IPv6 ports found, no rules to add"
        return
    fi
    
    echo " - Analyzing open IPv6 ports and adding missing ip6tables rules"
    
    # Add rules for unprotected ports
    for port_info in $listening_ports; do
        protocol=$(echo "$port_info" | cut -d: -f1)
        port=$(echo "$port_info" | cut -d: -f2)
        
        # Skip if port is 0 or not numeric
        if ! [[ "$port" =~ ^[0-9]+$ ]] || [ "$port" = "0" ]; then
            continue
        fi
        
        # Add rule if it doesn't exist
        if [ "$protocol" = "tcp" ]; then
            if ! ip6tables -L INPUT -n | grep -q "tcp dpt:$port"; then
                echo " - Adding ip6tables rule for TCP port $port"
                ip6tables -A INPUT -p tcp --dport "$port" -m state --state NEW -j ACCEPT
            fi
        elif [ "$protocol" = "udp" ]; then
            if ! ip6tables -L INPUT -n | grep -q "udp dpt:$port"; then
                echo " - Adding ip6tables rule for UDP port $port"
                ip6tables -A INPUT -p udp --dport "$port" -m state --state NEW -j ACCEPT
            fi
        fi
    done
    
    # Save ip6tables rules to make them persistent
    echo " - Saving ip6tables rules"
    service ip6tables save 2>/dev/null || ip6tables-save > /etc/sysconfig/ip6tables
    
    # Ensure ip6tables service is enabled
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo " - Enabling ip6tables service"
        systemctl enable ip6tables
    fi
    
    echo " - ip6tables open ports configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip6tables_open_ports
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: All open IPv6 ports have corresponding ip6tables rules"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="