#!/usr/bin/env bash
# Script: 3.4.4.2.4.sh
# Item: 3.4.4.2.4 Ensure iptables default deny firewall policy (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.2.4.sh"
ITEM_NAME="3.4.4.2.4 Ensure iptables default deny firewall policy (Automated)"
DESCRIPTION="This remediation ensures iptables default deny firewall policy is configured for INPUT, OUTPUT, and FORWARD chains."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking iptables default deny policy configuration..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check INPUT chain default policy
    input_policy=$(iptables -L INPUT | head -1 | awk '{print $4}' | tr -d '()')
    if [ "$input_policy" != "DROP" ]; then
        echo "FAIL: INPUT chain default policy is not DROP"
        echo "PROOF: INPUT chain policy is $input_policy"
        return 1
    fi
    
    # Check OUTPUT chain default policy
    output_policy=$(iptables -L OUTPUT | head -1 | awk '{print $4}' | tr -d '()')
    if [ "$output_policy" != "DROP" ]; then
        echo "FAIL: OUTPUT chain default policy is not DROP"
        echo "PROOF: OUTPUT chain policy is $output_policy"
        return 1
    fi
    
    # Check FORWARD chain default policy
    forward_policy=$(iptables -L FORWARD | head -1 | awk '{print $4}' | tr -d '()')
    if [ "$forward_policy" != "DROP" ]; then
        echo "FAIL: FORWARD chain default policy is not DROP"
        echo "PROOF: FORWARD chain policy is $forward_policy"
        return 1
    fi
    
    echo "PASS: iptables default deny policy properly configured"
    echo "PROOF: All chains (INPUT, OUTPUT, FORWARD) have DROP policy"
    return 0
}
# Function to fix
fix_iptables_default_deny() {
    echo "Applying fix..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Setting default deny policy for all chains"
    
    # Set INPUT chain default policy to DROP
    current_input=$(iptables -L INPUT | head -1 | awk '{print $4}' | tr -d '()')
    if [ "$current_input" != "DROP" ]; then
        echo " - Setting INPUT chain policy to DROP"
        iptables -P INPUT DROP
    fi
    
    # Set OUTPUT chain default policy to DROP
    current_output=$(iptables -L OUTPUT | head -1 | awk '{print $4}' | tr -d '()')
    if [ "$current_output" != "DROP" ]; then
        echo " - Setting OUTPUT chain policy to DROP"
        iptables -P OUTPUT DROP
    fi
    
    # Set FORWARD chain default policy to DROP
    current_forward=$(iptables -L FORWARD | head -1 | awk '{print $4}' | tr -d '()')
    if [ "$current_forward" != "DROP" ]; then
        echo " - Setting FORWARD chain policy to DROP"
        iptables -P FORWARD DROP
    fi
    
    # Save iptables rules to make them persistent
    echo " - Saving iptables rules"
    service iptables save 2>/dev/null || iptables-save > /etc/sysconfig/iptables
    
    # Ensure iptables service is enabled
    if ! systemctl is-enabled iptables >/dev/null 2>&1; then
        echo " - Enabling iptables service"
        systemctl enable iptables
    fi
    
    echo " - iptables default deny policy configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_default_deny
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: iptables default deny policy properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="