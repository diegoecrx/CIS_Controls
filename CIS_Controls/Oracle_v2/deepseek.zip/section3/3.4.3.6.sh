#!/usr/bin/env bash

# Script: 3.4.3.6.sh
# Item: 3.4.3.6 Ensure nftables outbound and established connections are configured (Manual)
# Description: "Configure nftables in accordance with site policy. The following commands will
# implement a policy to allow all outbound connections and all established connections:
# # nft add rule inet filter input ip protocol tcp ct state established accept
# # nft add rule inet filter input ip protocol udp ct state established accept
# # nft add rule inet filter input ip protocol icmp ct state established accept
# # nft add rule inet filter output ip protocol tcp ct state
# new,related,established accept
# # nft add rule inet filter output ip protocol udp ct state
# new,related,established accept
# # nft add rule inet filter output ip protocol icmp ct state
# new,related,established accept"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.4.3.6.sh"
ITEM_NAME="3.4.3.6 Ensure nftables outbound and established connections are configured (Manual)"
DESCRIPTION="Configure nftables to allow outbound and established connections according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current nftables outbound and established connection rules..."
    echo ""

    # Check if nftables is installed and active
    if ! command -v nft >/dev/null 2>&1; then
        echo "nftables is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    if ! systemctl is-active nftables >/dev/null 2>&1; then
        echo "nftables is NOT ACTIVE on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    # Display current nftables status
    echo "Current nftables status:"
    echo "========================"
    
    echo "nftables service status:"
    echo "------------------------"
    systemctl is-active nftables >/dev/null 2>&1 && echo "ACTIVE" || echo "INACTIVE"
    systemctl is-enabled nftables >/dev/null 2>&1 && echo "ENABLED at boot" || echo "DISABLED at boot"
    
    echo ""
    
    # Display current nftables ruleset
    echo "Current nftables ruleset:"
    echo "-------------------------"
    nft list ruleset 2>/dev/null | head -20 || echo "No nftables rules or error listing rules"
    
    echo ""
    
    # Check specifically for established and outbound rules
    echo "Current connection state rules:"
    echo "-------------------------------"
    
    echo "INPUT chain established rules:"
    nft list chain inet filter input 2>/dev/null | grep -E 'ct state|established' | head -5 || echo "No established rules in INPUT chain"
    
    echo ""
    
    echo "OUTPUT chain rules:"
    nft list chain inet filter output 2>/dev/null | grep -E 'ct state|new|related|established' | head -5 || echo "No connection state rules in OUTPUT chain"
    
    echo ""
    
    # Check base filter table structure
    echo "Filter table structure:"
    echo "-----------------------"
    nft list table inet filter 2>/dev/null | grep -E 'chain|type|hook' | head -10 || echo "No inet filter table found"
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_established_rules()
    {
        echo " - Checking for established connection rules..."
        
        established_rules_found=false
        
        # Check INPUT chain for established rules
        input_established_tcp=$(nft list chain inet filter input 2>/dev/null | grep -c 'ip protocol tcp ct state established accept' || echo "0")
        input_established_udp=$(nft list chain inet filter input 2>/dev/null | grep -c 'ip protocol udp ct state established accept' || echo "0")
        input_established_icmp=$(nft list chain inet filter input 2>/dev/null | grep -c 'ip protocol icmp ct state established accept' || echo "0")
        
        if [ "$input_established_tcp" -gt 0 ]; then
            echo " - FOUND: TCP established rule in INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: TCP established rule in INPUT chain"
        fi
        
        if [ "$input_established_udp" -gt 0 ]; then
            echo " - FOUND: UDP established rule in INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: UDP established rule in INPUT chain"
        fi
        
        if [ "$input_established_icmp" -gt 0 ]; then
            echo " - FOUND: ICMP established rule in INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: ICMP established rule in INPUT chain"
        fi
    }

    check_outbound_rules()
    {
        echo " - Checking for outbound connection rules..."
        
        outbound_rules_found=false
        
        # Check OUTPUT chain for outbound rules
        output_tcp=$(nft list chain inet filter output 2>/dev/null | grep -c 'ip protocol tcp ct state new,related,established accept' || echo "0")
        output_udp=$(nft list chain inet filter output 2>/dev/null | grep -c 'ip protocol udp ct state new,related,established accept' || echo "0")
        output_icmp=$(nft list chain inet filter output 2>/dev/null | grep -c 'ip protocol icmp ct state new,related,established accept' || echo "0")
        
        if [ "$output_tcp" -gt 0 ]; then
            echo " - FOUND: TCP outbound rule in OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: TCP outbound rule in OUTPUT chain"
        fi
        
        if [ "$output_udp" -gt 0 ]; then
            echo " - FOUND: UDP outbound rule in OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: UDP outbound rule in OUTPUT chain"
        fi
        
        if [ "$output_icmp" -gt 0 ]; then
            echo " - FOUND: ICMP outbound rule in OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: ICMP outbound rule in OUTPUT chain"
        fi
    }

    check_filter_table_structure()
    {
        echo " - Checking filter table structure..."
        
        # Check if inet filter table exists
        if nft list table inet filter >/dev/null 2>&1; then
            echo " - FOUND: inet filter table exists"
            
            # Check for INPUT chain
            if nft list chain inet filter input >/dev/null 2>&1; then
                echo " - FOUND: INPUT chain exists"
            else
                echo " - MISSING: INPUT chain - needs to be created"
            fi
            
            # Check for OUTPUT chain
            if nft list chain inet filter output >/dev/null 2>&1; then
                echo " - FOUND: OUTPUT chain exists"
            else
                echo " - MISSING: OUTPUT chain - needs to be created"
            fi
        else
            echo " - MISSING: inet filter table - needs to be created"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing nftables remediation guidance..."
        
        echo ""
        echo "NFTABLES REMEDIATION GUIDANCE:"
        echo "=============================="
        echo ""
        echo "To configure outbound and established connections:"
        echo ""
        echo "CREATE BASE TABLE AND CHAINS (if missing):"
        echo "  nft create table inet filter"
        echo "  nft create chain inet filter input { type filter hook input priority 0 \\; policy drop \\; }"
        echo "  nft create chain inet filter output { type filter hook output priority 0 \\; policy drop \\; }"
        echo ""
        echo "ALLOW ESTABLISHED CONNECTIONS (INPUT):"
        echo "  nft add rule inet filter input ip protocol tcp ct state established accept"
        echo "  nft add rule inet filter input ip protocol udp ct state established accept"
        echo "  nft add rule inet filter input ip protocol icmp ct state established accept"
        echo ""
        echo "ALLOW OUTBOUND CONNECTIONS (OUTPUT):"
        echo "  nft add rule inet filter output ip protocol tcp ct state new,related,established accept"
        echo "  nft add rule inet filter output ip protocol udp ct state new,related,established accept"
        echo "  nft add rule inet filter output ip protocol icmp ct state new,related,established accept"
        echo ""
        echo "MAKE RULES PERMANENT:"
        echo "  nft list ruleset > /etc/nftables.conf"
        echo "  systemctl restart nftables"
        echo ""
        echo "VERIFY CONFIGURATION:"
        echo "  nft list ruleset"
        echo "  nft list chain inet filter input"
        echo "  nft list chain inet filter output"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking filter table structure..."
    check_filter_table_structure
    remediation_applied=true
    
    echo ""
    echo "Checking established connection rules..."
    check_established_rules
    remediation_applied=true
    
    echo ""
    echo "Checking outbound connection rules..."
    check_outbound_rules
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No nftables configuration detected"
    fi

    echo ""
    echo "Remediation of nftables connection rules complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify nftables service status
    echo ""
    echo "1. VERIFYING NFTABLES SERVICE STATUS:"
    echo "-------------------------------------"
    if systemctl is-active nftables >/dev/null 2>&1; then
        echo "PASS: nftables is ACTIVE"
        echo "PROOF (systemctl status nftables):"
        systemctl status nftables --no-pager -l | head -3
    else
        echo "FAIL: nftables is INACTIVE"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify filter table structure
    echo ""
    echo "2. VERIFYING FILTER TABLE STRUCTURE:"
    echo "------------------------------------"
    if nft list table inet filter >/dev/null 2>&1; then
        echo "PASS: inet filter table exists"
        echo "PROOF (nft list table inet filter):"
        nft list table inet filter 2>/dev/null | grep -E 'table|chain' | head -5
    else
        echo "FAIL: inet filter table missing"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify established connection rules
    echo ""
    echo "3. VERIFYING ESTABLISHED CONNECTION RULES:"
    echo "------------------------------------------"
    established_rules_count=0
    
    if nft list chain inet filter input >/dev/null 2>&1; then
        tcp_established=$(nft list chain inet filter input 2>/dev/null | grep -c 'ip protocol tcp ct state established accept' || echo "0")
        udp_established=$(nft list chain inet filter input 2>/dev/null | grep -c 'ip protocol udp ct state established accept' || echo "0")
        icmp_established=$(nft list chain inet filter input 2>/dev/null | grep -c 'ip protocol icmp ct state established accept' || echo "0")
        
        established_rules_count=$((tcp_established + udp_established + icmp_established))
        
        if [ "$tcp_established" -gt 0 ]; then
            echo "PASS: TCP established rule found"
        else
            echo "FAIL: TCP established rule missing"
            final_status_pass=false
        fi
        
        if [ "$udp_established" -gt 0 ]; then
            echo "PASS: UDP established rule found"
        else
            echo "FAIL: UDP established rule missing"
            final_status_pass=false
        fi
        
        if [ "$icmp_established" -gt 0 ]; then
            echo "PASS: ICMP established rule found"
        else
            echo "FAIL: ICMP established rule missing"
            final_status_pass=false
        fi
        
        echo "PROOF (established rules in INPUT chain):"
        nft list chain inet filter input 2>/dev/null | grep -E 'established|accept' | head -5
    else
        echo "FAIL: INPUT chain missing"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify outbound connection rules
    echo ""
    echo "4. VERIFYING OUTBOUND CONNECTION RULES:"
    echo "---------------------------------------"
    outbound_rules_count=0
    
    if nft list chain inet filter output >/dev/null 2>&1; then
        tcp_outbound=$(nft list chain inet filter output 2>/dev/null | grep -c 'ip protocol tcp ct state new,related,established accept' || echo "0")
        udp_outbound=$(nft list chain inet filter output 2>/dev/null | grep -c 'ip protocol udp ct state new,related,established accept' || echo "0")
        icmp_outbound=$(nft list chain inet filter output 2>/dev/null | grep -c 'ip protocol icmp ct state new,related,established accept' || echo "0")
        
        outbound_rules_count=$((tcp_outbound + udp_outbound + icmp_outbound))
        
        if [ "$tcp_outbound" -gt 0 ]; then
            echo "PASS: TCP outbound rule found"
        else
            echo "FAIL: TCP outbound rule missing"
            final_status_pass=false
        fi
        
        if [ "$udp_outbound" -gt 0 ]; then
            echo "PASS: UDP outbound rule found"
        else
            echo "FAIL: UDP outbound rule missing"
            final_status_pass=false
        fi
        
        if [ "$icmp_outbound" -gt 0 ]; then
            echo "PASS: ICMP outbound rule found"
        else
            echo "FAIL: ICMP outbound rule missing"
            final_status_pass=false
        fi
        
        echo "PROOF (outbound rules in OUTPUT chain):"
        nft list chain inet filter output 2>/dev/null | grep -E 'new,related,established|accept' | head -5
    else
        echo "FAIL: OUTPUT chain missing"
        final_status_pass=false
    fi
    
    # PROOF 5: Manual verification steps reminder
    echo ""
    echo "5. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review established connection rules for completeness"
    echo "• Verify outbound rules match application requirements"
    echo "• Test network connectivity for both inbound and outbound traffic"
    echo "• Ensure rules are saved to persistent configuration"
    echo "• Document nftables ruleset for audit purposes"
    echo ""
    echo "CONNECTION STATE RULES SUMMARY:"
    echo "==============================="
    echo ""
    echo "ESTABLISHED CONNECTION RULES (INPUT):"
    echo "  nft add rule inet filter input ip protocol tcp ct state established accept"
    echo "  nft add rule inet filter input ip protocol udp ct state established accept"
    echo "  nft add rule inet filter input ip protocol icmp ct state established accept"
    echo ""
    echo "OUTBOUND CONNECTION RULES (OUTPUT):"
    echo "  nft add rule inet filter output ip protocol tcp ct state new,related,established accept"
    echo "  nft add rule inet filter output ip protocol udp ct state new,related,established accept"
    echo "  nft add rule inet filter output ip protocol icmp ct state new,related,established accept"
    echo ""
    echo "PERSISTENT CONFIGURATION:"
    echo "  nft list ruleset > /etc/nftables.conf"
    echo "  systemctl restart nftables"
    echo ""
    echo "VERIFICATION COMMANDS:"
    echo "  nft list ruleset"
    echo "  nft list chain inet filter input"
    echo "  nft list chain inet filter output"

    if [ "$final_status_pass" = true ] && [ "$established_rules_count" -ge 3 ] && [ "$outbound_rules_count" -ge 3 ]; then
        echo ""
        echo "SUCCESS: nftables connection rules verification completed"
        echo "NOTE: Manual testing required to verify network functionality"
    else
        echo ""
        echo "WARNING: Missing nftables connection rules - manual configuration required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="