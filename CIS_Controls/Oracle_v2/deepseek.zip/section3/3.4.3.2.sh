#!/usr/bin/env bash

# Script: 3.4.3.2.sh
# Item: 3.4.3.2 Ensure iptables are flushed with nftables (Manual)
# Description: "Run the following commands to flush iptables:
# For iptables:
# # iptables -F
# For ip6tables:
# # ip6tables -F"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.4.3.2.sh"
ITEM_NAME="3.4.3.2 Ensure iptables are flushed with nftables (Manual)"
DESCRIPTION="Flush iptables rules when using nftables to prevent rule conflicts"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current iptables and nftables status..."
    echo ""

    # Display current firewall status
    echo "Current firewall status:"
    echo "========================"
    
    # Check if nftables is installed and active
    echo "nftables status:"
    echo "----------------"
    if command -v nft >/dev/null 2>&1; then
        echo "nftables: INSTALLED"
        if systemctl is-active nftables >/dev/null 2>&1; then
            echo "nftables service: ACTIVE"
            nftables_active=true
        else
            echo "nftables service: INACTIVE"
            nftables_active=false
        fi
        
        if systemctl is-enabled nftables >/dev/null 2>&1; then
            echo "nftables service: ENABLED at boot"
        else
            echo "nftables service: DISABLED at boot"
        fi
        
        echo ""
        echo "Current nftables rules:"
        nft list ruleset 2>/dev/null | head -10 || echo "No nftables rules or error listing rules"
    else
        echo "nftables: NOT INSTALLED"
        nftables_active=false
    fi
    
    echo ""
    
    # Check iptables status and rules
    echo "iptables status:"
    echo "----------------"
    if command -v iptables >/dev/null 2>&1; then
        echo "iptables: INSTALLED"
        echo ""
        echo "Current iptables rules (IPv4):"
        iptables -L -n 2>/dev/null | head -15 || echo "No iptables rules or error listing rules"
        
        # Check if iptables has any non-default rules
        iptables_rules=$(iptables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l || echo "0")
        if [ "$iptables_rules" -gt 0 ]; then
            echo ""
            echo "WARNING: iptables has $iptables_rules active rules"
        fi
    else
        echo "iptables: NOT INSTALLED"
    fi
    
    echo ""
    
    # Check ip6tables status and rules
    echo "ip6tables status:"
    echo "-----------------"
    if command -v ip6tables >/dev/null 2>&1; then
        echo "ip6tables: INSTALLED"
        echo ""
        echo "Current ip6tables rules (IPv6):"
        ip6tables -L -n 2>/dev/null | head -15 || echo "No ip6tables rules or error listing rules"
        
        # Check if ip6tables has any non-default rules
        ip6tables_rules=$(ip6tables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l || echo "0")
        if [ "$ip6tables_rules" -gt 0 ]; then
            echo ""
            echo "WARNING: ip6tables has $ip6tables_rules active rules"
        fi
    else
        echo "ip6tables: NOT INSTALLED"
    fi
    
    echo ""
    
    # Check for iptables services
    echo "iptables service status:"
    echo "------------------------"
    if systemctl is-active iptables >/dev/null 2>&1; then
        echo "iptables service: ACTIVE"
        iptables_service_active=true
    else
        echo "iptables service: INACTIVE"
        iptables_service_active=false
    fi
    
    if systemctl is-active ip6tables >/dev/null 2>&1; then
        echo "ip6tables service: ACTIVE"
        ip6tables_service_active=true
    else
        echo "ip6tables service: INACTIVE"
        ip6tables_service_active=false
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_iptables_conflicts()
    {
        echo " - Checking for potential iptables/nftables conflicts..."
        
        conflict_detected=false
        
        # Check if both iptables and nftables have active rules
        if [ "$nftables_active" = true ]; then
            nft_rule_count=$(nft list ruleset 2>/dev/null | grep -c 'type filter' || echo "0")
            iptables_rule_count=$(iptables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l || echo "0")
            ip6tables_rule_count=$(ip6tables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l || echo "0")
            
            if [ "$iptables_rule_count" -gt 0 ] && [ "$nft_rule_count" -gt 0 ]; then
                echo " - CONFLICT: Both iptables ($iptables_rule_count rules) and nftables ($nft_rule_count rules) have active rules"
                conflict_detected=true
            fi
            
            if [ "$ip6tables_rule_count" -gt 0 ] && [ "$nft_rule_count" -gt 0 ]; then
                echo " - CONFLICT: Both ip6tables ($ip6tables_rule_count rules) and nftables ($nft_rule_count rules) have active rules"
                conflict_detected=true
            fi
        fi
        
        if [ "$conflict_detected" = false ]; then
            echo " - OK: No rule conflicts detected"
        fi
    }

    check_iptables_backend()
    {
        echo " - Checking iptables backend..."
        
        # Check if iptables is using nft backend
        if iptables --version 2>/dev/null | grep -q nf_tables; then
            echo " - iptables is using nftables backend (nf_tables)"
            using_nft_backend=true
        else
            echo " - iptables is using legacy backend"
            using_nft_backend=false
        fi
        
        if ip6tables --version 2>/dev/null | grep -q nf_tables; then
            echo " - ip6tables is using nftables backend (nf_tables)"
            using_nft_backend=true
        else
            echo " - ip6tables is using legacy backend"
            using_nft_backend=false
        fi
    }

    provide_flush_guidance()
    {
        echo " - Providing iptables flush guidance..."
        
        echo ""
        echo "IPTABLES FLUSH REMEDIATION GUIDANCE:"
        echo "===================================="
        echo ""
        echo "If nftables is the primary firewall and iptables rules exist:"
        echo ""
        echo "FLUSH IPTABLES RULES (IPv4):"
        echo "  iptables -F                          # Flush all rules"
        echo "  iptables -X                          # Delete all user-defined chains"
        echo "  iptables -Z                          # Zero all packet and byte counters"
        echo "  iptables -t nat -F                   # Flush NAT rules"
        echo "  iptables -t mangle -F                # Flush mangle rules"
        echo "  iptables -P INPUT ACCEPT             # Set default policy to ACCEPT"
        echo "  iptables -P FORWARD ACCEPT"
        echo "  iptables -P OUTPUT ACCEPT"
        echo ""
        echo "FLUSH IP6TABLES RULES (IPv6):"
        echo "  ip6tables -F                         # Flush all rules"
        echo "  ip6tables -X                         # Delete all user-defined chains"
        echo "  ip6tables -Z                         # Zero all packet and byte counters"
        echo "  ip6tables -t nat -F                  # Flush NAT rules"
        echo "  ip6tables -t mangle -F               # Flush mangle rules"
        echo "  ip6tables -P INPUT ACCEPT            # Set default policy to ACCEPT"
        echo "  ip6tables -P FORWARD ACCEPT"
        echo "  ip6tables -P OUTPUT ACCEPT"
        echo ""
        echo "DISABLE IPTABLES SERVICES:"
        echo "  systemctl stop iptables"
        echo "  systemctl stop ip6tables"
        echo "  systemctl disable iptables"
        echo "  systemctl disable ip6tables"
        echo "  systemctl mask iptables"
        echo "  systemctl mask ip6tables"
        echo ""
        echo "SAVE NFTABLES RULES (if nftables is primary):"
        echo "  nft list ruleset > /etc/nftables.conf"
        echo "  systemctl enable nftables"
        echo "  systemctl start nftables"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking for rule conflicts..."
    check_iptables_conflicts
    remediation_applied=true
    
    echo ""
    echo "Checking iptables backend..."
    check_iptables_backend
    remediation_applied=true

    echo ""
    provide_flush_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No iptables/nftables configuration detected"
    fi

    echo ""
    echo "Remediation of iptables flush complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify nftables status
    echo ""
    echo "1. VERIFYING NFTABLES STATUS:"
    echo "-----------------------------"
    if command -v nft >/dev/null 2>&1; then
        echo "nftables: INSTALLED"
        if systemctl is-active nftables >/dev/null 2>&1; then
            echo "nftables service: ACTIVE"
            echo "PROOF (systemctl status nftables):"
            systemctl status nftables --no-pager -l | head -3
        else
            echo "nftables service: INACTIVE"
        fi
        
        echo ""
        echo "nftables ruleset count:"
        nft_ruleset_count=$(nft list ruleset 2>/dev/null | grep -c '^\s*' || echo "0")
        echo "Total nftables rules: $nft_ruleset_count"
    else
        echo "nftables: NOT INSTALLED"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify iptables rules are flushed
    echo ""
    echo "2. VERIFYING IPTABLES RULES (IPv4):"
    echo "-----------------------------------"
    if command -v iptables >/dev/null 2>&1; then
        iptables_rule_count=$(iptables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l || echo "0")
        if [ "$iptables_rule_count" -eq 0 ]; then
            echo "PASS: iptables rules are flushed"
            echo "PROOF (iptables -L -n): No active rules"
            iptables -L -n 2>/dev/null | head -5
        else
            echo "WARNING: iptables has $iptables_rule_count active rules"
            echo "PROOF (iptables -L -n):"
            iptables -L -n 2>/dev/null | head -10
            final_status_pass=false
        fi
    else
        echo "INFO: iptables not installed"
    fi
    
    # PROOF 3: Verify ip6tables rules are flushed
    echo ""
    echo "3. VERIFYING IP6TABLES RULES (IPv6):"
    echo "------------------------------------"
    if command -v ip6tables >/dev/null 2>&1; then
        ip6tables_rule_count=$(ip6tables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l || echo "0")
        if [ "$ip6tables_rule_count" -eq 0 ]; then
            echo "PASS: ip6tables rules are flushed"
            echo "PROOF (ip6tables -L -n): No active rules"
            ip6tables -L -n 2>/dev/null | head -5
        else
            echo "WARNING: ip6tables has $ip6tables_rule_count active rules"
            echo "PROOF (ip6tables -L -n):"
            ip6tables -L -n 2>/dev/null | head -10
            final_status_pass=false
        fi
    else
        echo "INFO: ip6tables not installed"
    fi
    
    # PROOF 4: Verify iptables services status
    echo ""
    echo "4. VERIFYING IPTABLES SERVICES:"
    echo "-------------------------------"
    if systemctl is-active iptables >/dev/null 2>&1; then
        echo "WARNING: iptables service is ACTIVE"
        echo "PROOF (systemctl status iptables):"
        systemctl status iptables --no-pager -l | head -3
        final_status_pass=false
    else
        echo "PASS: iptables service is INACTIVE"
    fi
    
    if systemctl is-active ip6tables >/dev/null 2>&1; then
        echo "WARNING: ip6tables service is ACTIVE"
        echo "PROOF (systemctl status ip6tables):"
        systemctl status ip6tables --no-pager -l | head -3
        final_status_pass=false
    else
        echo "PASS: ip6tables service is INACTIVE"
    fi
    
    # PROOF 5: Manual verification steps reminder
    echo ""
    echo "5. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Confirm nftables is the intended primary firewall"
    echo "• Ensure all necessary rules are migrated to nftables"
    echo "• Verify no production services rely on iptables rules"
    echo "• Test network connectivity after flushing iptables"
    echo "• Document firewall configuration for audit purposes"
    echo ""
    echo "FLUSH COMMANDS SUMMARY:"
    echo "======================"
    echo ""
    echo "FLUSH IPTABLES:"
    echo "  iptables -F"
    echo "  iptables -X"
    echo "  iptables -t nat -F"
    echo "  iptables -t mangle -F"
    echo "  iptables -P INPUT ACCEPT"
    echo "  iptables -P FORWARD ACCEPT"
    echo "  iptables -P OUTPUT ACCEPT"
    echo ""
    echo "FLUSH IP6TABLES:"
    echo "  ip6tables -F"
    echo "  ip6tables -X"
    echo "  ip6tables -t nat -F"
    echo "  ip6tables -t mangle -F"
    echo "  ip6tables -P INPUT ACCEPT"
    echo "  ip6tables -P FORWARD ACCEPT"
    echo "  ip6tables -P OUTPUT ACCEPT"
    echo ""
    echo "DISABLE SERVICES:"
    echo "  systemctl stop iptables ip6tables"
    echo "  systemctl disable iptables ip6tables"
    echo "  systemctl mask iptables ip6tables"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: iptables flush verification completed"
        echo "NOTE: Manual review required to confirm nftables is properly configured"
    else
        echo ""
        echo "WARNING: iptables rules or services still active - manual flush required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="