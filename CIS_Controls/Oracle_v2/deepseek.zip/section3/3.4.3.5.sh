#!/usr/bin/env bash
# Script: 3.4.3.5.sh
# Item: 3.4.3.5 Ensure nftables loopback traffic is configured (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.5.sh"
ITEM_NAME="3.4.3.5 Ensure nftables loopback traffic is configured (Automated)"
DESCRIPTION="This remediation ensures nftables loopback traffic is properly configured for both IPv4 and IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables loopback traffic configuration..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    # Find inet table
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo "FAIL: No inet table found"
        echo "PROOF: No inet table exists"
        return 1
    fi
    
    # Check if input chain exists
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo "FAIL: Input chain does not exist in table $table_name"
        echo "PROOF: No input chain found"
        return 1
    fi
    
    # Get current ruleset for the input chain
    input_rules=$(nft list chain inet "$table_name" input 2>/dev/null)
    
    # Check for loopback interface accept rule
    if ! echo "$input_rules" | grep -q "iif.*lo.*accept"; then
        echo "FAIL: Loopback interface accept rule not found"
        echo "PROOF: No 'iif lo accept' rule in input chain"
        return 1
    fi
    
    # Check for IPv4 loopback source address drop rule
    if ! echo "$input_rules" | grep -q "ip saddr 127.0.0.0/8.*drop"; then
        echo "FAIL: IPv4 loopback source address drop rule not found"
        echo "PROOF: No 'ip saddr 127.0.0.0/8 drop' rule in input chain"
        return 1
    fi
    
    # Check IPv6 loopback rule if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        if ! echo "$input_rules" | grep -q "ip6 saddr ::1.*drop"; then
            echo "FAIL: IPv6 loopback source address drop rule not found"
            echo "PROOF: No 'ip6 saddr ::1 drop' rule in input chain"
            return 1
        fi
    fi
    
    echo "PASS: nftables loopback traffic properly configured"
    echo "PROOF: All required loopback rules exist in table $table_name"
    return 0
}
# Function to fix
fix_nftables_loopback() {
    echo "Applying fix..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package first"
        yum install -y nftables
    fi
    
    # Find or create an inet table
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo " - Creating inet filter table"
        nft create table inet filter
        table_name="filter"
    fi
    
    # Ensure input chain exists
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo " - Creating input base chain"
        nft create chain inet "$table_name" input '{ type filter hook input priority 0 ; }'
    fi
    
    echo " - Configuring loopback rules in table: $table_name"
    
    # Get current rules to avoid duplicates
    input_rules=$(nft list chain inet "$table_name" input 2>/dev/null)
    
    # Add loopback interface accept rule if not present
    if ! echo "$input_rules" | grep -q "iif.*lo.*accept"; then
        echo " - Adding loopback interface accept rule"
        nft add rule inet "$table_name" input iif lo accept
    fi
    
    # Add IPv4 loopback source address drop rule if not present
    if ! echo "$input_rules" | grep -q "ip saddr 127.0.0.0/8.*drop"; then
        echo " - Adding IPv4 loopback source address drop rule"
        nft add rule inet "$table_name" input ip saddr 127.0.0.0/8 counter drop
    fi
    
    # Add IPv6 loopback rule if IPv6 is enabled and rule not present
    if [ -d /proc/sys/net/ipv6 ]; then
        if ! echo "$input_rules" | grep -q "ip6 saddr ::1.*drop"; then
            echo " - Adding IPv6 loopback source address drop rule"
            nft add rule inet "$table_name" input ip6 saddr ::1 counter drop
        fi
    fi
    
    # Update configuration file to make persistent
    if [ -f /etc/nftables.conf ]; then
        # Backup existing config
        cp /etc/nftables.conf /etc/nftables.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    fi
    
    # Save current ruleset to configuration file
    echo " - Saving configuration to /etc/nftables.conf"
    cat > /etc/nftables.conf << EOF
#!/usr/sbin/nft -f

flush ruleset

$(nft list ruleset)
EOF
    
    echo " - nftables loopback configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_loopback
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables loopback traffic properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="