#!/usr/bin/env bash
# Script: 3.4.4.2.6.sh
# Item: 3.4.4.2.6 Ensure iptables service is enabled and active (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.2.6.sh"
ITEM_NAME="3.4.4.2.6 Ensure iptables service is enabled and active (Automated)"
DESCRIPTION="This remediation ensures iptables service is enabled and active."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking iptables service status..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    # Check if iptables service is masked
    if systemctl is-masked iptables.service >/dev/null 2>&1; then
        echo "FAIL: iptables service is masked"
        echo "PROOF: systemctl is-masked iptables.service shows masked"
        return 1
    fi
    
    # Check if iptables service is enabled
    if ! systemctl is-enabled iptables.service >/dev/null 2>&1; then
        echo "FAIL: iptables service is not enabled"
        echo "PROOF: systemctl is-enabled iptables.service shows disabled"
        return 1
    fi
    
    # Check if iptables service is running
    if ! systemctl is-active iptables.service >/dev/null 2>&1; then
        echo "FAIL: iptables service is not running"
        echo "PROOF: systemctl is-active iptables.service shows inactive"
        return 1
    fi
    
    echo "PASS: iptables service properly enabled and active"
    echo "PROOF: iptables.service is enabled and active"
    return 0
}
# Function to fix
fix_iptables_service() {
    echo "Applying fix..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    # Unmask iptables service if masked
    if systemctl is-masked iptables.service >/dev/null 2>&1; then
        echo " - Unmasking iptables service"
        systemctl unmask iptables.service
    fi
    
    # Enable and start iptables service
    if ! systemctl is-enabled iptables.service >/dev/null 2>&1 || ! systemctl is-active iptables.service >/dev/null 2>&1; then
        echo " - Enabling and starting iptables service"
        systemctl --now enable iptables.service
    fi
    
    echo " - iptables service configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_service
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: iptables service properly enabled and active"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="