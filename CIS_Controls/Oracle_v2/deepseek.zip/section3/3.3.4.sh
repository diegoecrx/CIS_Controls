#!/usr/bin/env bash
# Script: 3.3.4.sh
# Item: 3.3.4 Ensure broadcast icmp requests are ignored (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.4.sh"
ITEM_NAME="3.3.4 Ensure broadcast icmp requests are ignored (Automated)"
DESCRIPTION="This remediation ensures broadcast ICMP requests are ignored."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking broadcast ICMP request configuration..."
    
    # Check current running value
    icmp_echo_ignore_broadcasts=$(sysctl net.ipv4.icmp_echo_ignore_broadcasts 2>/dev/null | awk '{print $3}')
    
    if [ "$icmp_echo_ignore_broadcasts" != "1" ]; then
        echo "FAIL: net.ipv4.icmp_echo_ignore_broadcasts is not enabled"
        echo "PROOF: net.ipv4.icmp_echo_ignore_broadcasts = $icmp_echo_ignore_broadcasts"
        return 1
    fi
    
    # Check configuration files for conflicting settings
    if grep -Pq '^\s*net\.ipv4\.icmp_echo_ignore_broadcasts\s*=\s*[^1]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.icmp_echo_ignore_broadcasts disabled in configuration"
        echo "PROOF: net.ipv4.icmp_echo_ignore_broadcasts set to non-1 in config files"
        return 1
    fi
    
    echo "PASS: Broadcast ICMP requests properly ignored"
    echo "PROOF: net.ipv4.icmp_echo_ignore_broadcasts = 1"
    return 0
}
# Function to fix
fix_broadcast_icmp_requests() {
    echo "Applying fix..."
    
    # Remove any existing conflicting entries
    sed -i '/^\s*net\.ipv4\.icmp_echo_ignore_broadcasts\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.icmp_echo_ignore_broadcasts\s*=/d' {} \; 2>/dev/null || true
    
    # Add broadcast ICMP request configuration
    echo " - Configuring broadcast ICMP request handling"
    echo "net.ipv4.icmp_echo_ignore_broadcasts = 1" >> /etc/sysctl.d/60-netipv4_sysctl.conf
    
    # Set active kernel parameters
    sysctl -w net.ipv4.icmp_echo_ignore_broadcasts=1 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    echo " - Broadcast ICMP request configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_broadcast_icmp_requests
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Broadcast ICMP requests properly ignored"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="