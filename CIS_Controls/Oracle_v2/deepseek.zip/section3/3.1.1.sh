#!/usr/bin/env bash

# Script: 3.1.1.sh
# Item: 3.1.1 Ensure IPv6 status is identified (Manual)
# Description: Enable or disable IPv6 in accordance with system requirements and local site policy
# Default Value: IPv6 is enabled
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.1.1.sh"
ITEM_NAME="3.1.1 Ensure IPv6 status is identified (Manual)"
DESCRIPTION="Enable or disable IPv6 in accordance with system requirements and local site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current IPv6 status and configuration..."
    echo ""

    # Display current IPv6 status
    echo "Current IPv6 status:"
    echo "===================="
    
    # Check if IPv6 is enabled in kernel
    echo "Kernel IPv6 module status:"
    echo "--------------------------"
    if lsmod | grep -q ipv6; then
        echo "IPv6 module: LOADED"
        ipv6_loaded=true
    else
        echo "IPv6 module: NOT LOADED"
        ipv6_loaded=false
    fi
    
    echo ""
    
    # Check sysctl IPv6 settings
    echo "IPv6 sysctl parameters:"
    echo "-----------------------"
    sysctl -a 2>/dev/null | grep -E 'ipv6\.|net\.ipv6\.' | grep -v '^net.ipv6.conf.lo' | head -10
    
    echo ""
    
    # Check network interface IPv6 configuration
    echo "Network interface IPv6 addresses:"
    echo "---------------------------------"
    if command -v ip >/dev/null 2>&1; then
        ip -6 addr show 2>/dev/null | head -20 || echo "No IPv6 addresses configured"
    else
        ifconfig | grep inet6 | head -10 || echo "No IPv6 addresses found"
    fi
    
    echo ""
    
    # Check IPv6 routing
    echo "IPv6 routing table:"
    echo "-------------------"
    if command -v ip >/dev/null 2>&1; then
        ip -6 route show 2>/dev/null | head -10 || echo "No IPv6 routes configured"
    else
        route -6 2>/dev/null | head -10 || echo "No IPv6 routes found"
    fi
    
    echo ""
    
    # Check IPv6 listening services
    echo "IPv6 network listeners:"
    echo "-----------------------"
    if command -v ss >/dev/null 2>&1; then
        ss -tulpn6 2>/dev/null | head -10 || echo "No IPv6 listeners or IPv6 disabled"
    elif command -v netstat >/dev/null 2>&1; then
        netstat -tulpn6 2>/dev/null | head -10 || echo "No IPv6 listeners or IPv6 disabled"
    else
        echo "Network socket tools not available"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_ipv6_kernel_status()
    {
        echo " - Checking IPv6 kernel module status..."
        if lsmod | grep -q ipv6; then
            echo " - IPv6 kernel module is LOADED"
            return 0
        else
            echo " - IPv6 kernel module is NOT LOADED"
            return 1
        fi
    }

    check_ipv6_sysctl_disable()
    {
        echo " - Checking for IPv6 disable parameters..."
        
        # Check common IPv6 disable parameters
        disable_params=(
            "net.ipv6.conf.all.disable_ipv6"
            "net.ipv6.conf.default.disable_ipv6"
            "net.ipv6.conf.lo.disable_ipv6"
        )
        
        for param in "${disable_params[@]}"; do
            value=$(sysctl -n "$param" 2>/dev/null || echo "not set")
            if [ "$value" = "1" ]; then
                echo " - $param = 1 (IPv6 disabled)"
            else
                echo " - $param = $value"
            fi
        done
    }

    check_ipv6_grub_config()
    {
        echo " - Checking bootloader IPv6 configuration..."
        
        # Check GRUB configuration for IPv6 disable
        if [ -f /etc/default/grub ]; then
            if grep -q "ipv6.disable=1" /etc/default/grub; then
                echo " - GRUB configured to disable IPv6 at boot (ipv6.disable=1)"
            elif grep -q "ipv6.disable=0" /etc/default/grub; then
                echo " - GRUB configured to enable IPv6 at boot (ipv6.disable=0)"
            else
                echo " - No explicit IPv6 configuration in GRUB"
            fi
        fi
        
        # Check kernel command line
        if [ -f /proc/cmdline ]; then
            if grep -q "ipv6.disable=1" /proc/cmdline; then
                echo " - IPv6 disabled in current kernel command line"
            fi
        fi
    }

    provide_ipv6_remediation_guidance()
    {
        echo " - Providing IPv6 remediation guidance..."
        
        echo ""
        echo "IPV6 REMEDIATION GUIDANCE:"
        echo "=========================="
        echo ""
        echo "Based on organizational policy, choose one of the following:"
        echo ""
        echo "OPTION 1 - DISABLE IPv6 (if not required):"
        echo "  a) Temporary disable (until reboot):"
        echo "     echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6"
        echo "  b) Permanent disable via sysctl:"
        echo "     Add to /etc/sysctl.conf or /etc/sysctl.d/99-ipv6.conf:"
        echo "     net.ipv6.conf.all.disable_ipv6 = 1"
        echo "     net.ipv6.conf.default.disable_ipv6 = 1"
        echo "     net.ipv6.conf.lo.disable_ipv6 = 1"
        echo "  c) Disable at boot via GRUB:"
        echo "     Add to GRUB_CMDLINE_LINUX in /etc/default/grub:"
        echo "     ipv6.disable=1"
        echo "     Then run: update-grub (Debian/Ubuntu) or grub2-mkconfig (RHEL/CentOS)"
        echo ""
        echo "OPTION 2 - ENABLE IPv6 (if required):"
        echo "  a) Ensure IPv6 module is loaded:"
        echo "     modprobe ipv6"
        echo "  b) Remove any disable parameters:"
        echo "     Remove ipv6.disable=1 from GRUB and sysctl files"
        echo "     Set disable_ipv6 parameters to 0"
        echo ""
        echo "OPTION 3 - SECURE IPv6 (if enabled but not fully utilized):"
        echo "  a) Configure IPv6 firewall rules"
        echo "  b) Disable IPv6 on specific interfaces if needed"
        echo "  c) Implement IPv6 security best practices"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking IPv6 kernel status..."
    check_ipv6_kernel_status
    remediation_applied=true
    
    echo ""
    echo "Checking IPv6 sysctl configuration..."
    check_ipv6_sysctl_disable
    remediation_applied=true
    
    echo ""
    echo "Checking bootloader configuration..."
    check_ipv6_grub_config
    remediation_applied=true

    echo ""
    provide_ipv6_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No IPv6 configuration detected - system may not support IPv6"
    fi

    echo ""
    echo "Remediation of IPv6 configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify IPv6 kernel module status
    echo ""
    echo "1. VERIFYING IPV6 KERNEL MODULE STATUS:"
    echo "---------------------------------------"
    if lsmod | grep -q ipv6; then
        echo "PASS: IPv6 kernel module is LOADED"
        echo "PROOF (lsmod | grep ipv6):"
        lsmod | grep ipv6
    else
        echo "INFO: IPv6 kernel module is NOT LOADED"
        echo "PROOF (lsmod | grep ipv6): No output"
        # This may be intentional based on policy
    fi
    
    # PROOF 2: Verify IPv6 sysctl configuration
    echo ""
    echo "2. VERIFYING IPV6 SYSCTL CONFIGURATION:"
    echo "---------------------------------------"
    critical_params=(
        "net.ipv6.conf.all.disable_ipv6"
        "net.ipv6.conf.default.disable_ipv6"
        "net.ipv6.conf.all.accept_ra"
        "net.ipv6.conf.default.accept_ra"
        "net.ipv6.conf.all.forwarding"
    )
    
    for param in "${critical_params[@]}"; do
        value=$(sysctl -n "$param" 2>/dev/null || echo "not set")
        echo "$param = $value"
    done
    
    # PROOF 3: Verify IPv6 network interfaces
    echo ""
    echo "3. VERIFYING IPV6 NETWORK INTERFACES:"
    echo "-------------------------------------"
    if command -v ip >/dev/null 2>&1; then
        ipv6_addr_count=$(ip -6 addr show 2>/dev/null | grep -c "inet6" || true)
        if [ "$ipv6_addr_count" -gt 0 ]; then
            echo "PASS: $ipv6_addr_count IPv6 addresses configured"
            echo "PROOF (ip -6 addr show):"
            ip -6 addr show 2>/dev/null | head -10
        else
            echo "INFO: No IPv6 addresses configured"
            echo "PROOF (ip -6 addr show): No IPv6 addresses"
        fi
    else
        echo "INFO: ip command not available"
    fi
    
    # PROOF 4: Verify IPv6 routing
    echo ""
    echo "4. VERIFYING IPV6 ROUTING:"
    echo "--------------------------"
    if command -v ip >/dev/null 2>&1; then
        ipv6_route_count=$(ip -6 route show 2>/dev/null | wc -l || true)
        if [ "$ipv6_route_count" -gt 0 ]; then
            echo "PASS: $ipv6_route_count IPv6 routes configured"
            echo "PROOF (ip -6 route show):"
            ip -6 route show 2>/dev/null | head -5
        else
            echo "INFO: No IPv6 routes configured"
            echo "PROOF (ip -6 route show): No IPv6 routes"
        fi
    fi
    
    # PROOF 5: Verify IPv6 network listeners
    echo ""
    echo "5. VERIFYING IPV6 NETWORK LISTENERS:"
    echo "------------------------------------"
    if command -v ss >/dev/null 2>&1; then
        ipv6_listeners=$(ss -tulpn6 2>/dev/null | grep -c "LISTEN" || true)
        if [ "$ipv6_listeners" -gt 0 ]; then
            echo "INFO: $ipv6_listeners IPv6 network listeners"
            echo "PROOF (ss -tulpn6):"
            ss -tulpn6 2>/dev/null | head -5
        else
            echo "INFO: No IPv6 network listeners"
            echo "PROOF (ss -tulpn6): No IPv6 listeners"
        fi
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Determine if IPv6 is required for business operations"
    echo "• Review organizational security policy for IPv6 requirements"
    echo "• Check application dependencies on IPv6"
    echo "• Verify network infrastructure IPv6 support"
    echo "• Assess IPv6 security controls and firewall rules"
    echo ""
    echo "IPV6 CONFIGURATION FILES TO REVIEW:"
    echo "  /etc/sysctl.conf"
    echo "  /etc/sysctl.d/*.conf"
    echo "  /etc/default/grub"
    echo "  /boot/grub2/grub.cfg"
    echo "  /etc/modprobe.d/*.conf"
    echo "  /etc/network/interfaces (Debian/Ubuntu)"
    echo "  /etc/sysconfig/network-scripts/ (RHEL/CentOS)"
    echo ""
    echo "IPV6 STATUS COMMANDS:"
    echo "  ip -6 addr show              # Show IPv6 addresses"
    echo "  ip -6 route show            # Show IPv6 routing table"
    echo "  ss -tulpn6                  # Show IPv6 listeners"
    echo "  sysctl -a | grep ipv6       # Show IPv6 sysctl parameters"
    echo "  cat /proc/cmdline           # Check kernel boot parameters"
    echo "  lsmod | grep ipv6           # Check IPv6 module status"

    # Determine overall status
    ipv6_active=false
    if lsmod | grep -q ipv6 || ip -6 addr show 2>/dev/null | grep -q "inet6" || ss -tulpn6 2>/dev/null | grep -q "LISTEN"; then
        ipv6_active=true
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        if [ "$ipv6_active" = true ]; then
            echo "SUCCESS: IPv6 verification completed - IPv6 is ACTIVE"
            echo "NOTE: Manual review required to confirm this matches organizational policy"
        else
            echo "SUCCESS: IPv6 verification completed - IPv6 is DISABLED"
            echo "NOTE: Manual review required to confirm this matches organizational policy"
        fi
    else
        echo ""
        echo "WARNING: IPv6 configuration issues detected - manual intervention required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="