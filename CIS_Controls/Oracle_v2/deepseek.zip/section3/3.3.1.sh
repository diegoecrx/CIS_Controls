#!/usr/bin/env bash
# Script: 3.3.1.sh
# Item: 3.3.1 Ensure ip forwarding is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.1.sh"
ITEM_NAME="3.3.1 Ensure ip forwarding is disabled (Automated)"
DESCRIPTION="This remediation ensures IP forwarding is disabled for both IPv4 and IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking IP forwarding configuration..."
    
    # Check IPv4 forwarding
    ipv4_forward_current=$(sysctl net.ipv4.ip_forward 2>/dev/null | awk '{print $3}')
    if [ "$ipv4_forward_current" != "0" ]; then
        echo "FAIL: IPv4 forwarding is enabled"
        echo "PROOF: net.ipv4.ip_forward = $ipv4_forward_current"
        return 1
    fi
    
    # Check IPv4 forwarding in configuration files
    if grep -Pq '^\s*net\.ipv4\.ip_forward\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: IPv4 forwarding enabled in configuration"
        echo "PROOF: net.ipv4.ip_forward set to non-zero in config files"
        return 1
    fi
    
    # Check if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        # Check IPv6 forwarding
        ipv6_forward_current=$(sysctl net.ipv6.conf.all.forwarding 2>/dev/null | awk '{print $3}')
        if [ "$ipv6_forward_current" != "0" ]; then
            echo "FAIL: IPv6 forwarding is enabled"
            echo "PROOF: net.ipv6.conf.all.forwarding = $ipv6_forward_current"
            return 1
        fi
        
        # Check IPv6 forwarding in configuration files
        if grep -Pq '^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
            echo "FAIL: IPv6 forwarding enabled in configuration"
            echo "PROOF: net.ipv6.conf.all.forwarding set to non-zero in config files"
            return 1
        fi
    fi
    
    echo "PASS: IP forwarding properly disabled"
    echo "PROOF: Both IPv4 and IPv6 forwarding set to 0"
    return 0
}
# Function to fix
fix_ip_forwarding() {
    echo "Applying fix..."
    
    # Configure IPv4 forwarding
    echo " - Configuring IPv4 forwarding"
    
    # Remove any existing IPv4 forwarding entries that might conflict
    sed -i '/^\s*net\.ipv4\.ip_forward\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.ip_forward\s*=/d' {} \; 2>/dev/null || true
    
    # Add IPv4 forwarding configuration
    echo "net.ipv4.ip_forward = 0" >> /etc/sysctl.d/60-netipv4_sysctl.conf
    
    # Set active IPv4 kernel parameters
    sysctl -w net.ipv4.ip_forward=0 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    # Configure IPv6 forwarding if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        echo " - Configuring IPv6 forwarding"
        
        # Remove any existing IPv6 forwarding entries that might conflict
        sed -i '/^\s*net\.ipv6\.conf\.all\.forwarding\s*=/d' /etc/sysctl.conf 2>/dev/null || true
        find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv6\.conf\.all\.forwarding\s*=/d' {} \; 2>/dev/null || true
        
        # Add IPv6 forwarding configuration
        echo "net.ipv6.conf.all.forwarding = 0" >> /etc/sysctl.d/60-netipv6_sysctl.conf
        
        # Set active IPv6 kernel parameters
        sysctl -w net.ipv6.conf.all.forwarding=0 >/dev/null 2>&1
        sysctl -w net.ipv6.route.flush=1 >/dev/null 2>&1
    fi
    
    echo " - IP forwarding configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip_forwarding
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: IP forwarding properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="