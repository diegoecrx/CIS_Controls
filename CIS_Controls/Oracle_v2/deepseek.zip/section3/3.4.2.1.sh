#!/usr/bin/env bash
# Script: 3.4.2.1.sh
# Item: 3.4.2.1 Ensure firewalld is installed (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.2.1.sh"
ITEM_NAME="3.4.2.1 Ensure firewalld is installed (Automated)"
DESCRIPTION="This remediation ensures firewalld and iptables are installed on the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking firewalld installation..."
    
    # Check if firewalld package is installed
    if ! rpm -q firewalld >/dev/null 2>&1; then
        echo "FAIL: firewalld package is not installed"
        echo "PROOF: rpm -q firewalld returned no package found"
        return 1
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    echo "PASS: firewalld and iptables properly installed"
    echo "PROOF: Both firewalld and iptables packages are installed"
    return 0
}
# Function to fix
fix_firewalld_installation() {
    echo "Applying fix..."
    
    # Install firewalld package
    if ! rpm -q firewalld >/dev/null 2>&1; then
        echo " - Installing firewalld package"
        yum install -y firewalld
    else
        echo " - firewalld package already installed"
    fi
    
    # Install iptables package
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    else
        echo " - iptables package already installed"
    fi
    
    echo " - firewalld installation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_firewalld_installation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: firewalld and iptables properly installed"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="