#!/usr/bin/env bash

# Script: 3.4.4.3.2.sh
# Item: 3.4.4.3.2 Ensure ip6tables outbound and established connections are configured (Manual)
# Description: "Configure iptables in accordance with site policy. The following commands will
# implement a policy to allow all outbound connections and all established connections:
# # ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
# # ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
# # ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT
# # ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
# # ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT
# # ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.4.4.3.2.sh"
ITEM_NAME="3.4.4.3.2 Ensure ip6tables outbound and established connections are configured (Manual)"
DESCRIPTION="Configure ip6tables to allow outbound and established IPv6 connections according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current ip6tables outbound and established connection rules..."
    echo ""

    # Check if ip6tables is installed
    if ! command -v ip6tables >/dev/null 2>&1; then
        echo "ip6tables is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    # Display current ip6tables status
    echo "Current ip6tables status:"
    echo "========================="
    
    echo "ip6tables service status:"
    echo "-------------------------"
    if systemctl is-active ip6tables >/dev/null 2>&1; then
        echo "ACTIVE"
        ip6tables_active=true
    else
        echo "INACTIVE"
        ip6tables_active=false
    fi
    
    if systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo "ENABLED at boot"
    else
        echo "DISABLED at boot"
    fi
    
    echo ""
    
    # Display current ip6tables rules
    echo "Current ip6tables rules (IPv6):"
    echo "-------------------------------"
    ip6tables -L -n 2>/dev/null | head -20 || echo "No ip6tables rules or error listing rules"
    
    echo ""
    
    # Check specifically for established and outbound rules
    echo "Current IPv6 connection state rules:"
    echo "------------------------------------"
    
    echo "INPUT chain established rules (IPv6):"
    ip6tables -L INPUT -n 2>/dev/null | grep -E 'state|ESTABLISHED' | head -5 || echo "No established rules in IPv6 INPUT chain"
    
    echo ""
    
    echo "OUTPUT chain rules (IPv6):"
    ip6tables -L OUTPUT -n 2>/dev/null | grep -E 'state|NEW|ESTABLISHED' | head -5 || echo "No connection state rules in IPv6 OUTPUT chain"
    
    echo ""
    
    # Check IPv6 kernel status
    echo "IPv6 kernel status:"
    echo "-------------------"
    if lsmod | grep -q ipv6; then
        echo "IPv6 kernel module: LOADED"
        ipv6_enabled=true
    else
        echo "IPv6 kernel module: NOT LOADED"
        ipv6_enabled=false
    fi
    
    # Check for IPv6 addresses
    echo ""
    echo "IPv6 network interfaces:"
    echo "------------------------"
    if command -v ip >/dev/null 2>&1; then
        ip -6 addr show 2>/dev/null | head -10 || echo "No IPv6 addresses configured"
    else
        ifconfig | grep inet6 | head -5 || echo "No IPv6 addresses found"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_ipv6_established_rules()
    {
        echo " - Checking for IPv6 established connection rules..."
        
        established_rules_found=false
        
        # Check INPUT chain for established rules
        input_established_tcp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'tcp state ESTABLISHED' || echo "0")
        input_established_udp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'udp state ESTABLISHED' || echo "0")
        input_established_icmp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'icmp state ESTABLISHED' || echo "0")
        
        if [ "$input_established_tcp" -gt 0 ]; then
            echo " - FOUND: TCP established rule in IPv6 INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: TCP established rule in IPv6 INPUT chain"
        fi
        
        if [ "$input_established_udp" -gt 0 ]; then
            echo " - FOUND: UDP established rule in IPv6 INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: UDP established rule in IPv6 INPUT chain"
        fi
        
        if [ "$input_established_icmp" -gt 0 ]; then
            echo " - FOUND: ICMP established rule in IPv6 INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: ICMP established rule in IPv6 INPUT chain"
        fi
    }

    check_ipv6_outbound_rules()
    {
        echo " - Checking for IPv6 outbound connection rules..."
        
        outbound_rules_found=false
        
        # Check OUTPUT chain for outbound rules
        output_tcp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'tcp state NEW,ESTABLISHED' || echo "0")
        output_udp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'udp state NEW,ESTABLISHED' || echo "0")
        output_icmp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'icmp state NEW,ESTABLISHED' || echo "0")
        
        if [ "$output_tcp" -gt 0 ]; then
            echo " - FOUND: TCP outbound rule in IPv6 OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: TCP outbound rule in IPv6 OUTPUT chain"
        fi
        
        if [ "$output_udp" -gt 0 ]; then
            echo " - FOUND: UDP outbound rule in IPv6 OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: UDP outbound rule in IPv6 OUTPUT chain"
        fi
        
        if [ "$output_icmp" -gt 0 ]; then
            echo " - FOUND: ICMP outbound rule in IPv6 OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: ICMP outbound rule in IPv6 OUTPUT chain"
        fi
    }

    check_ipv6_default_policies()
    {
        echo " - Checking IPv6 default policies..."
        
        input_policy=$(ip6tables -L INPUT -n 2>/dev/null | grep 'policy' | awk '{print $4}' | tr -d ')' || echo "unknown")
        output_policy=$(ip6tables -L OUTPUT -n 2>/dev/null | grep 'policy' | awk '{print $4}' | tr -d ')' || echo "unknown")
        forward_policy=$(ip6tables -L FORWARD -n 2>/dev/null | grep 'policy' | awk '{print $4}' | tr -d ')' || echo "unknown")
        
        echo " - IPv6 INPUT chain default policy: $input_policy"
        echo " - IPv6 OUTPUT chain default policy: $output_policy"
        echo " - IPv6 FORWARD chain default policy: $forward_policy"
        
        if [ "$input_policy" = "DROP" ] || [ "$input_policy" = "REJECT" ]; then
            echo " - NOTE: Restrictive IPv6 INPUT policy - established rules are critical"
        fi
        
        if [ "$output_policy" = "DROP" ] || [ "$output_policy" = "REJECT" ]; then
            echo " - NOTE: Restrictive IPv6 OUTPUT policy - outbound rules are critical"
        fi
    }

    check_ipv6_listeners()
    {
        echo " - Checking for IPv6 network listeners..."
        
        if command -v ss >/dev/null 2>&1; then
            ipv6_listeners=$(ss -tulpn6 2>/dev/null | grep -c "LISTEN" || echo "0")
            echo " - IPv6 network listeners: $ipv6_listeners"
            
            if [ "$ipv6_listeners" -gt 0 ]; then
                echo " - WARNING: IPv6 services are listening - ensure established rules allow access"
            fi
        else
            echo " - INFO: ss command not available for detailed listener check"
        fi
    }

    provide_ipv6_remediation_guidance()
    {
        echo " - Providing ip6tables remediation guidance..."
        
        echo ""
        echo "IP6TABLES REMEDIATION GUIDANCE:"
        echo "==============================="
        echo ""
        echo "To configure IPv6 outbound and established connections:"
        echo ""
        echo "ALLOW ESTABLISHED CONNECTIONS (IPv6 INPUT):"
        echo "  ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
        echo ""
        echo "ALLOW OUTBOUND CONNECTIONS (IPv6 OUTPUT):"
        echo "  ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo ""
        echo "SET RESTRICTIVE DEFAULT POLICIES (if desired):"
        echo "  ip6tables -P INPUT DROP"
        echo "  ip6tables -P FORWARD DROP"
        echo "  ip6tables -P OUTPUT DROP"
        echo ""
        echo "SAVE IP6TABLES RULES PERMANENTLY:"
        echo "  service ip6tables save"
        echo "  -OR-"
        echo "  ip6tables-save > /etc/sysconfig/ip6tables"
        echo ""
        echo "ENABLE IP6TABLES SERVICE:"
        echo "  systemctl enable ip6tables"
        echo "  systemctl start ip6tables"
        echo ""
        echo "VERIFY CONFIGURATION:"
        echo "  ip6tables -L -n"
        echo "  ip6tables -L INPUT -n"
        echo "  ip6tables -L OUTPUT -n"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking IPv6 kernel and network status..."
    check_ipv6_listeners
    remediation_applied=true
    
    echo ""
    echo "Checking IPv6 established connection rules..."
    check_ipv6_established_rules
    remediation_applied=true
    
    echo ""
    echo "Checking IPv6 outbound connection rules..."
    check_ipv6_outbound_rules
    remediation_applied=true
    
    echo ""
    echo "Checking IPv6 default policies..."
    check_ipv6_default_policies
    remediation_applied=true

    echo ""
    provide_ipv6_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No ip6tables configuration detected"
    fi

    echo ""
    echo "Remediation of ip6tables connection rules complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify ip6tables service status
    echo ""
    echo "1. VERIFYING IP6TABLES SERVICE STATUS:"
    echo "--------------------------------------"
    if systemctl is-active ip6tables >/dev/null 2>&1; then
        echo "PASS: ip6tables service is ACTIVE"
        echo "PROOF (systemctl status ip6tables):"
        systemctl status ip6tables --no-pager -l | head -3
    else
        echo "INFO: ip6tables service is INACTIVE"
    fi
    
    # PROOF 2: Verify IPv6 kernel status
    echo ""
    echo "2. VERIFYING IPV6 KERNEL STATUS:"
    echo "--------------------------------"
    if lsmod | grep -q ipv6; then
        echo "PASS: IPv6 kernel module is LOADED"
        echo "PROOF (lsmod | grep ipv6):"
        lsmod | grep ipv6
    else
        echo "INFO: IPv6 kernel module is NOT LOADED"
        echo "NOTE: IPv6 functionality may be disabled at kernel level"
    fi
    
    # PROOF 3: Verify IPv6 established connection rules
    echo ""
    echo "3. VERIFYING IPV6 ESTABLISHED CONNECTION RULES:"
    echo "-----------------------------------------------"
    established_rules_count=0
    
    input_established_tcp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'tcp state ESTABLISHED' || echo "0")
    input_established_udp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'udp state ESTABLISHED' || echo "0")
    input_established_icmp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'icmp state ESTABLISHED' || echo "0")
    
    established_rules_count=$((input_established_tcp + input_established_udp + input_established_icmp))
    
    if [ "$input_established_tcp" -gt 0 ]; then
        echo "PASS: TCP established rule found in IPv6 INPUT"
        echo "PROOF: $(ip6tables -L INPUT -n 2>/dev/null | grep 'tcp state ESTABLISHED' | head -1)"
    else
        echo "FAIL: TCP established rule missing in IPv6 INPUT"
        final_status_pass=false
    fi
    
    if [ "$input_established_udp" -gt 0 ]; then
        echo "PASS: UDP established rule found in IPv6 INPUT"
        echo "PROOF: $(ip6tables -L INPUT -n 2>/dev/null | grep 'udp state ESTABLISHED' | head -1)"
    else
        echo "FAIL: UDP established rule missing in IPv6 INPUT"
        final_status_pass=false
    fi
    
    if [ "$input_established_icmp" -gt 0 ]; then
        echo "PASS: ICMP established rule found in IPv6 INPUT"
        echo "PROOF: $(ip6tables -L INPUT -n 2>/dev/null | grep 'icmp state ESTABLISHED' | head -1)"
    else
        echo "FAIL: ICMP established rule missing in IPv6 INPUT"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify IPv6 outbound connection rules
    echo ""
    echo "4. VERIFYING IPV6 OUTBOUND CONNECTION RULES:"
    echo "--------------------------------------------"
    outbound_rules_count=0
    
    output_tcp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'tcp state NEW,ESTABLISHED' || echo "0")
    output_udp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'udp state NEW,ESTABLISHED' || echo "0")
    output_icmp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'icmp state NEW,ESTABLISHED' || echo "0")
    
    outbound_rules_count=$((output_tcp + output_udp + output_icmp))
    
    if [ "$output_tcp" -gt 0 ]; then
        echo "PASS: TCP outbound rule found in IPv6 OUTPUT"
        echo "PROOF: $(ip6tables -L OUTPUT -n 2>/dev/null | grep 'tcp state NEW,ESTABLISHED' | head -1)"
    else
        echo "FAIL: TCP outbound rule missing in IPv6 OUTPUT"
        final_status_pass=false
    fi
    
    if [ "$output_udp" -gt 0 ]; then
        echo "PASS: UDP outbound rule found in IPv6 OUTPUT"
        echo "PROOF: $(ip6tables -L OUTPUT -n 2>/dev/null | grep 'udp state NEW,ESTABLISHED' | head -1)"
    else
        echo "FAIL: UDP outbound rule missing in IPv6 OUTPUT"
        final_status_pass=false
    fi
    
    if [ "$output_icmp" -gt 0 ]; then
        echo "PASS: ICMP outbound rule found in IPv6 OUTPUT"
        echo "PROOF: $(ip6tables -L OUTPUT -n 2>/dev/null | grep 'icmp state NEW,ESTABLISHED' | head -1)"
    else
        echo "FAIL: ICMP outbound rule missing in IPv6 OUTPUT"
        final_status_pass=false
    fi
    
    # PROOF 5: Verify IPv6 network configuration
    echo ""
    echo "5. VERIFYING IPV6 NETWORK CONFIGURATION:"
    echo "----------------------------------------"
    if command -v ip >/dev/null 2>&1; then
        ipv6_address_count=$(ip -6 addr show 2>/dev/null | grep -c "inet6" || echo "0")
        echo "IPv6 addresses configured: $ipv6_address_count"
        
        if [ "$ipv6_address_count" -gt 0 ]; then
            echo "PROOF (first 2 IPv6 addresses):"
            ip -6 addr show 2>/dev/null | grep "inet6" | head -2
        fi
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review IPv6 established connection rules for completeness"
    echo "• Verify IPv6 outbound rules match application requirements"
    echo "• Test IPv6 network connectivity for both inbound and outbound traffic"
    echo "• Ensure IPv6 rules are saved to persistent configuration"
    echo "• Document ip6tables ruleset for audit purposes"
    echo "• Consider IPv6-specific security considerations"
    echo ""
    echo "IPV6 CONNECTION STATE RULES SUMMARY:"
    echo "===================================="
    echo ""
    echo "IPV6 ESTABLISHED CONNECTION RULES (INPUT):"
    echo "  ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
    echo "  ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
    echo "  ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
    echo ""
    echo "IPV6 OUTBOUND CONNECTION RULES (OUTPUT):"
    echo "  ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
    echo "  ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
    echo "  ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
    echo ""
    echo "PERSISTENT CONFIGURATION:"
    echo "  service ip6tables save"
    echo "  -OR-"
    echo "  ip6tables-save > /etc/sysconfig/ip6tables"
    echo ""
    echo "VERIFICATION COMMANDS:"
    echo "  ip6tables -L -n"
    echo "  ip6tables -L INPUT -n"
    echo "  ip6tables -L OUTPUT -n"

    if [ "$final_status_pass" = true ] && [ "$established_rules_count" -ge 3 ] && [ "$outbound_rules_count" -ge 3 ]; then
        echo ""
        echo "SUCCESS: ip6tables connection rules verification completed"
        echo "NOTE: Manual testing required to verify IPv6 network functionality"
    else
        echo ""
        echo "WARNING: Missing ip6tables connection rules - manual configuration required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="