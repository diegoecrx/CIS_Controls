#!/usr/bin/env bash
# Script: 3.3.8.sh
# Item: 3.3.8 Ensure source routed packets are not accepted (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.8.sh"
ITEM_NAME="3.3.8 Ensure source routed packets are not accepted (Automated)"
DESCRIPTION="This remediation ensures source routed packets are not accepted for both IPv4 and IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking source routed packets configuration..."
    
    # Check IPv4 source route settings
    ipv4_all_accept_source_route=$(sysctl net.ipv4.conf.all.accept_source_route 2>/dev/null | awk '{print $3}')
    ipv4_default_accept_source_route=$(sysctl net.ipv4.conf.default.accept_source_route 2>/dev/null | awk '{print $3}')
    
    if [ "$ipv4_all_accept_source_route" != "0" ]; then
        echo "FAIL: net.ipv4.conf.all.accept_source_route is not disabled"
        echo "PROOF: net.ipv4.conf.all.accept_source_route = $ipv4_all_accept_source_route"
        return 1
    fi
    
    if [ "$ipv4_default_accept_source_route" != "0" ]; then
        echo "FAIL: net.ipv4.conf.default.accept_source_route is not disabled"
        echo "PROOF: net.ipv4.conf.default.accept_source_route = $ipv4_default_accept_source_route"
        return 1
    fi
    
    # Check IPv4 configuration files for conflicting settings
    if grep -Pq '^\s*net\.ipv4\.conf\.all\.accept_source_route\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.conf.all.accept_source_route enabled in configuration"
        echo "PROOF: net.ipv4.conf.all.accept_source_route set to non-zero in config files"
        return 1
    fi
    
    if grep -Pq '^\s*net\.ipv4\.conf\.default\.accept_source_route\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.conf.default.accept_source_route enabled in configuration"
        echo "PROOF: net.ipv4.conf.default.accept_source_route set to non-zero in config files"
        return 1
    fi
    
    # Check IPv6 if enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        ipv6_all_accept_source_route=$(sysctl net.ipv6.conf.all.accept_source_route 2>/dev/null | awk '{print $3}')
        ipv6_default_accept_source_route=$(sysctl net.ipv6.conf.default.accept_source_route 2>/dev/null | awk '{print $3}')
        
        if [ "$ipv6_all_accept_source_route" != "0" ]; then
            echo "FAIL: net.ipv6.conf.all.accept_source_route is not disabled"
            echo "PROOF: net.ipv6.conf.all.accept_source_route = $ipv6_all_accept_source_route"
            return 1
        fi
        
        if [ "$ipv6_default_accept_source_route" != "0" ]; then
            echo "FAIL: net.ipv6.conf.default.accept_source_route is not disabled"
            echo "PROOF: net.ipv6.conf.default.accept_source_route = $ipv6_default_accept_source_route"
            return 1
        fi
        
        # Check IPv6 configuration files for conflicting settings
        if grep -Pq '^\s*net\.ipv6\.conf\.all\.accept_source_route\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
            echo "FAIL: net.ipv6.conf.all.accept_source_route enabled in configuration"
            echo "PROOF: net.ipv6.conf.all.accept_source_route set to non-zero in config files"
            return 1
        fi
        
        if grep -Pq '^\s*net\.ipv6\.conf\.default\.accept_source_route\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
            echo "FAIL: net.ipv6.conf.default.accept_source_route enabled in configuration"
            echo "PROOF: net.ipv6.conf.default.accept_source_route set to non-zero in config files"
            return 1
        fi
    fi
    
    echo "PASS: Source routed packets properly disabled"
    echo "PROOF: All IPv4 and IPv6 accept_source_route set to 0"
    return 0
}
# Function to fix
fix_source_routed_packets() {
    echo "Applying fix..."
    
    # Configure IPv4 source route settings
    echo " - Configuring IPv4 source routed packets"
    
    # Remove any existing conflicting entries
    sed -i '/^\s*net\.ipv4\.conf\.all\.accept_source_route\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    sed -i '/^\s*net\.ipv4\.conf\.default\.accept_source_route\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.conf\.all\.accept_source_route\s*=/d' {} \; 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.conf\.default\.accept_source_route\s*=/d' {} \; 2>/dev/null || true
    
    # Add IPv4 source route configuration
    {
        echo "net.ipv4.conf.all.accept_source_route = 0"
        echo "net.ipv4.conf.default.accept_source_route = 0"
    } >> /etc/sysctl.d/60-netipv4_sysctl.conf
    
    # Set active IPv4 kernel parameters
    sysctl -w net.ipv4.conf.all.accept_source_route=0 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.accept_source_route=0 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    # Configure IPv6 source route settings if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        echo " - Configuring IPv6 source routed packets"
        
        # Remove any existing conflicting entries
        sed -i '/^\s*net\.ipv6\.conf\.all\.accept_source_route\s*=/d' /etc/sysctl.conf 2>/dev/null || true
        sed -i '/^\s*net\.ipv6\.conf\.default\.accept_source_route\s*=/d' /etc/sysctl.conf 2>/dev/null || true
        find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv6\.conf\.all\.accept_source_route\s*=/d' {} \; 2>/dev/null || true
        find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv6\.conf\.default\.accept_source_route\s*=/d' {} \; 2>/dev/null || true
        
        # Add IPv6 source route configuration
        {
            echo "net.ipv6.conf.all.accept_source_route = 0"
            echo "net.ipv6.conf.default.accept_source_route = 0"
        } >> /etc/sysctl.d/60-netipv6_sysctl.conf
        
        # Set active IPv6 kernel parameters
        sysctl -w net.ipv6.conf.all.accept_source_route=0 >/dev/null 2>&1
        sysctl -w net.ipv6.conf.default.accept_source_route=0 >/dev/null 2>&1
        sysctl -w net.ipv6.route.flush=1 >/dev/null 2>&1
    fi
    
    echo " - Source routed packets configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_source_routed_packets
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Source routed packets properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="