#!/usr/bin/env bash

# Script: 3.4.2.3.sh
# Item: 3.4.2.3 Ensure firewalld drops unnecessary services and ports (Manual)
# Description: "If Firewalld is in use on the system:
# Run the following command to remove an unnecessary service:
# # firewall-cmd --remove-service=<service>
# Example:
# # firewall-cmd --remove-service=cockpit
# Run the following command to remove an unnecessary port:
# # firewall-cmd --remove-port=<port-number>/<port-type>
# Example:
# # firewall-cmd --remove-port=25/tcp
# Run the following command to make new settings persistent:
# # firewall-cmd --runtime-to-permanent"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.4.2.3.sh"
ITEM_NAME="3.4.2.3 Ensure firewalld drops unnecessary services and ports (Manual)"
DESCRIPTION="Remove unnecessary services and ports from firewalld configuration according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current firewalld status and configuration..."
    echo ""

    # Display current firewalld status
    echo "Current firewalld status:"
    echo "========================="
    
    # Check if firewalld is installed and running
    if ! command -v firewall-cmd >/dev/null 2>&1; then
        echo "firewalld is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi
    
    echo "Firewalld service status:"
    echo "-------------------------"
    systemctl is-active firewalld >/dev/null 2>&1 && echo "ACTIVE" || echo "INACTIVE"
    systemctl is-enabled firewalld >/dev/null 2>&1 && echo "ENABLED at boot" || echo "DISABLED at boot"
    
    echo ""
    
    # Get current firewalld zones
    echo "Active firewalld zones:"
    echo "-----------------------"
    firewall-cmd --get-active-zones 2>/dev/null || echo "Unable to get active zones"
    
    echo ""
    
    # Get current services and ports
    echo "Currently allowed services (public zone):"
    echo "-----------------------------------------"
    firewall-cmd --list-services --zone=public 2>/dev/null | head -10 || echo "Unable to list services"
    
    echo ""
    
    echo "Currently allowed ports (public zone):"
    echo "--------------------------------------"
    firewall-cmd --list-ports --zone=public 2>/dev/null | head -10 || echo "Unable to list ports"
    
    echo ""
    
    # Get rich rules
    echo "Current rich rules (public zone):"
    echo "---------------------------------"
    firewall-cmd --list-rich-rules --zone=public 2>/dev/null | head -5 || echo "No rich rules configured"
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_unnecessary_services()
    {
        echo " - Checking for potentially unnecessary services..."
        
        # Common services that may be unnecessary in many environments
        potentially_unnecessary_services=(
            "cockpit" "dhcpv6-client" "tftp" "telnet" "samba" "samba-client"
            "mdns" "ipp-client" "ipp" "ftp" "snmp" "ldap" "ldaps"
        )
        
        current_services=$(firewall-cmd --list-services --zone=public 2>/dev/null || echo "")
        
        for service in "${potentially_unnecessary_services[@]}"; do
            if echo "$current_services" | grep -qw "$service"; then
                echo " - POTENTIALLY UNNECESSARY: Service '$service' is allowed"
            fi
        done
    }

    check_unnecessary_ports()
    {
        echo " - Checking for potentially unnecessary ports..."
        
        # Common ports that may be unnecessary in many environments
        potentially_unnecessary_ports=(
            "25/tcp"    # SMTP (if not mail server)
            "23/tcp"    # Telnet
            "69/udp"    # TFTP
            "111/tcp"   # RPC
            "111/udp"   # RPC
            "135/tcp"   # MSRPC
            "137/udp"   # NetBIOS
            "138/udp"   # NetBIOS
            "139/tcp"   # NetBIOS
            "445/tcp"   # SMB
            "512/tcp"   # Rexec
            "513/tcp"   # Rlogin
            "514/tcp"   # Rsh
        )
        
        current_ports=$(firewall-cmd --list-ports --zone=public 2>/dev/null || echo "")
        
        for port in "${potentially_unnecessary_ports[@]}"; do
            if echo "$current_ports" | grep -qw "$port"; then
                echo " - POTENTIALLY UNNECESSARY: Port '$port' is allowed"
            fi
        done
    }

    check_runtime_vs_permanent()
    {
        echo " - Checking runtime vs permanent configuration..."
        
        runtime_services=$(firewall-cmd --list-services --zone=public 2>/dev/null | sort)
        permanent_services=$(firewall-cmd --list-services --zone=public --permanent 2>/dev/null | sort)
        
        runtime_ports=$(firewall-cmd --list-ports --zone=public 2>/dev/null | sort)
        permanent_ports=$(firewall-cmd --list-ports --zone=public --permanent 2>/dev/null | sort)
        
        if [ "$runtime_services" != "$permanent_services" ]; then
            echo " - WARNING: Runtime services differ from permanent configuration"
        else
            echo " - OK: Runtime and permanent services match"
        fi
        
        if [ "$runtime_ports" != "$permanent_ports" ]; then
            echo " - WARNING: Runtime ports differ from permanent configuration"
        else
            echo " - OK: Runtime and permanent ports match"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing firewalld remediation guidance..."
        
        echo ""
        echo "FIREWALLD REMEDIATION GUIDANCE:"
        echo "==============================="
        echo ""
        echo "For each unnecessary service identified above:"
        echo ""
        echo "REMOVE UNNECESSARY SERVICE:"
        echo "  firewall-cmd --remove-service=<service_name>"
        echo "  firewall-cmd --remove-service=<service_name> --permanent"
        echo "  Example: firewall-cmd --remove-service=cockpit"
        echo ""
        echo "REMOVE UNNECESSARY PORT:"
        echo "  firewall-cmd --remove-port=<port>/<protocol>"
        echo "  firewall-cmd --remove-port=<port>/<protocol> --permanent"
        echo "  Example: firewall-cmd --remove-port=25/tcp"
        echo ""
        echo "SYNC RUNTIME TO PERMANENT (if configurations differ):"
        echo "  firewall-cmd --runtime-to-permanent"
        echo ""
        echo "VERIFY CHANGES:"
        echo "  firewall-cmd --list-services --zone=public"
        echo "  firewall-cmd --list-ports --zone=public"
        echo "  firewall-cmd --list-all --zone=public"
        echo ""
        echo "RELOAD FIREWALLD (after permanent changes):"
        echo "  firewall-cmd --reload"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking for unnecessary services..."
    check_unnecessary_services
    remediation_applied=true
    
    echo ""
    echo "Checking for unnecessary ports..."
    check_unnecessary_ports
    remediation_applied=true
    
    echo ""
    echo "Checking configuration consistency..."
    check_runtime_vs_permanent
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No firewalld configuration issues detected"
    fi

    echo ""
    echo "Remediation of firewalld configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify firewalld service status
    echo ""
    echo "1. VERIFYING FIREWALLD SERVICE STATUS:"
    echo "--------------------------------------"
    if systemctl is-active firewalld >/dev/null 2>&1; then
        echo "PASS: firewalld is ACTIVE"
        echo "PROOF (systemctl status firewalld):"
        systemctl status firewalld --no-pager -l | head -5
    else
        echo "INFO: firewalld is INACTIVE"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify current allowed services
    echo ""
    echo "2. VERIFYING ALLOWED SERVICES:"
    echo "------------------------------"
    current_services=$(firewall-cmd --list-services --zone=public 2>/dev/null || echo "none")
    if [ -n "$current_services" ] && [ "$current_services" != "none" ]; then
        echo "Current allowed services (public zone):"
        echo "$current_services"
        service_count=$(echo "$current_services" | wc -w)
        echo ""
        echo "Total services allowed: $service_count"
    else
        echo "INFO: No services allowed in public zone"
    fi
    
    # PROOF 3: Verify current allowed ports
    echo ""
    echo "3. VERIFYING ALLOWED PORTS:"
    echo "---------------------------"
    current_ports=$(firewall-cmd --list-ports --zone=public 2>/dev/null || echo "none")
    if [ -n "$current_ports" ] && [ "$current_ports" != "none" ]; then
        echo "Current allowed ports (public zone):"
        echo "$current_ports"
        port_count=$(echo "$current_ports" | wc -w)
        echo ""
        echo "Total ports allowed: $port_count"
    else
        echo "INFO: No ports allowed in public zone"
    fi
    
    # PROOF 4: Verify configuration consistency
    echo ""
    echo "4. VERIFYING CONFIGURATION CONSISTENCY:"
    echo "---------------------------------------"
    runtime_services=$(firewall-cmd --list-services --zone=public 2>/dev/null | sort)
    permanent_services=$(firewall-cmd --list-services --zone=public --permanent 2>/dev/null | sort)
    
    runtime_ports=$(firewall-cmd --list-ports --zone=public 2>/dev/null | sort)
    permanent_ports=$(firewall-cmd --list-ports --zone=public --permanent 2>/dev/null | sort)
    
    if [ "$runtime_services" = "$permanent_services" ]; then
        echo "PASS: Runtime and permanent services match"
    else
        echo "WARNING: Runtime and permanent services differ"
        echo "Runtime: $runtime_services"
        echo "Permanent: $permanent_services"
        final_status_pass=false
    fi
    
    if [ "$runtime_ports" = "$permanent_ports" ]; then
        echo "PASS: Runtime and permanent ports match"
    else
        echo "WARNING: Runtime and permanent ports differ"
        echo "Runtime: $runtime_ports"
        echo "Permanent: $permanent_ports"
        final_status_pass=false
    fi
    
    # PROOF 5: Verify complete firewalld configuration
    echo ""
    echo "5. VERIFYING COMPLETE FIREWALLD CONFIGURATION:"
    echo "----------------------------------------------"
    echo "Complete public zone configuration:"
    firewall-cmd --list-all --zone=public 2>/dev/null | head -15
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review all allowed services against business requirements"
    echo "• Verify all allowed ports have legitimate business purpose"
    echo "• Remove any services/ports not explicitly required"
    echo "• Ensure runtime and permanent configurations match"
    echo "• Document firewall rules for audit purposes"
    echo ""
    echo "FIREWALLD MANAGEMENT COMMANDS:"
    echo "=============================="
    echo ""
    echo "LIST CURRENT CONFIGURATION:"
    echo "  firewall-cmd --list-all --zone=public"
    echo "  firewall-cmd --list-services --zone=public"
    echo "  firewall-cmd --list-ports --zone=public"
    echo "  firewall-cmd --list-rich-rules --zone=public"
    echo ""
    echo "REMOVE UNNECESSARY ITEMS:"
    echo "  firewall-cmd --remove-service=<service>"
    echo "  firewall-cmd --remove-port=<port>/<protocol>"
    echo "  firewall-cmd --remove-rich-rule='<rule>'"
    echo ""
    echo "MAKE CHANGES PERMANENT:"
    echo "  firewall-cmd --runtime-to-permanent"
    echo "  -OR-"
    echo "  firewall-cmd --permanent --remove-service=<service>"
    echo "  firewall-cmd --reload"
    echo ""
    echo "COMMON UNNECESSARY SERVICES/PORTS:"
    echo "  cockpit, dhcpv6-client, tftp, telnet, smtp (25/tcp)"
    echo "  All services/ports not explicitly required for system function"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Firewalld configuration verification completed"
        echo "NOTE: Manual review required to remove unnecessary services and ports"
    else
        echo ""
        echo "WARNING: Firewalld configuration issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="