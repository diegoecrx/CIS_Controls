#!/usr/bin/env bash

# Script: 3.4.4.2.2.sh
# Item: 3.4.4.2.2 Ensure iptables outbound and established connections are configured (Manual)
# Description: "Configure iptables in accordance with site policy. The following commands will
# implement a policy to allow all outbound connections and all established connections:
# # iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
# # iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
# # iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT
# # iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
# # iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT
# # iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.4.4.2.2.sh"
ITEM_NAME="3.4.4.2.2 Ensure iptables outbound and established connections are configured (Manual)"
DESCRIPTION="Configure iptables to allow outbound and established connections according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current iptables outbound and established connection rules..."
    echo ""

    # Check if iptables is installed
    if ! command -v iptables >/dev/null 2>&1; then
        echo "iptables is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    # Display current iptables status
    echo "Current iptables status:"
    echo "========================"
    
    echo "iptables service status:"
    echo "------------------------"
    if systemctl is-active iptables >/dev/null 2>&1; then
        echo "ACTIVE"
        iptables_active=true
    else
        echo "INACTIVE"
        iptables_active=false
    fi
    
    if systemctl is-enabled iptables >/dev/null 2>&1; then
        echo "ENABLED at boot"
    else
        echo "DISABLED at boot"
    fi
    
    echo ""
    
    # Display current iptables rules
    echo "Current iptables rules (IPv4):"
    echo "------------------------------"
    iptables -L -n 2>/dev/null | head -20 || echo "No iptables rules or error listing rules"
    
    echo ""
    
    # Check specifically for established and outbound rules
    echo "Current connection state rules (IPv4):"
    echo "--------------------------------------"
    
    echo "INPUT chain established rules:"
    iptables -L INPUT -n 2>/dev/null | grep -E 'state|ESTABLISHED' | head -5 || echo "No established rules in INPUT chain"
    
    echo ""
    
    echo "OUTPUT chain rules:"
    iptables -L OUTPUT -n 2>/dev/null | grep -E 'state|NEW|ESTABLISHED' | head -5 || echo "No connection state rules in OUTPUT chain"
    
    echo ""
    
    # Check ip6tables if available
    if command -v ip6tables >/dev/null 2>&1; then
        echo "Current ip6tables rules (IPv6):"
        echo "------------------------------"
        ip6tables -L -n 2>/dev/null | head -15 || echo "No ip6tables rules or error listing rules"
        
        echo ""
        
        echo "IPv6 connection state rules:"
        echo "----------------------------"
        echo "INPUT chain established rules (IPv6):"
        ip6tables -L INPUT -n 2>/dev/null | grep -E 'state|ESTABLISHED' | head -3 || echo "No established rules in IPv6 INPUT chain"
        
        echo ""
        
        echo "OUTPUT chain rules (IPv6):"
        ip6tables -L OUTPUT -n 2>/dev/null | grep -E 'state|NEW|ESTABLISHED' | head -3 || echo "No connection state rules in IPv6 OUTPUT chain"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_established_rules()
    {
        echo " - Checking for established connection rules (IPv4)..."
        
        established_rules_found=false
        
        # Check INPUT chain for established rules
        input_established_tcp=$(iptables -L INPUT -n 2>/dev/null | grep -c 'tcp state ESTABLISHED' || echo "0")
        input_established_udp=$(iptables -L INPUT -n 2>/dev/null | grep -c 'udp state ESTABLISHED' || echo "0")
        input_established_icmp=$(iptables -L INPUT -n 2>/dev/null | grep -c 'icmp state ESTABLISHED' || echo "0")
        
        if [ "$input_established_tcp" -gt 0 ]; then
            echo " - FOUND: TCP established rule in INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: TCP established rule in INPUT chain"
        fi
        
        if [ "$input_established_udp" -gt 0 ]; then
            echo " - FOUND: UDP established rule in INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: UDP established rule in INPUT chain"
        fi
        
        if [ "$input_established_icmp" -gt 0 ]; then
            echo " - FOUND: ICMP established rule in INPUT chain"
            established_rules_found=true
        else
            echo " - MISSING: ICMP established rule in INPUT chain"
        fi
    }

    check_outbound_rules()
    {
        echo " - Checking for outbound connection rules (IPv4)..."
        
        outbound_rules_found=false
        
        # Check OUTPUT chain for outbound rules
        output_tcp=$(iptables -L OUTPUT -n 2>/dev/null | grep -c 'tcp state NEW,ESTABLISHED' || echo "0")
        output_udp=$(iptables -L OUTPUT -n 2>/dev/null | grep -c 'udp state NEW,ESTABLISHED' || echo "0")
        output_icmp=$(iptables -L OUTPUT -n 2>/dev/null | grep -c 'icmp state NEW,ESTABLISHED' || echo "0")
        
        if [ "$output_tcp" -gt 0 ]; then
            echo " - FOUND: TCP outbound rule in OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: TCP outbound rule in OUTPUT chain"
        fi
        
        if [ "$output_udp" -gt 0 ]; then
            echo " - FOUND: UDP outbound rule in OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: UDP outbound rule in OUTPUT chain"
        fi
        
        if [ "$output_icmp" -gt 0 ]; then
            echo " - FOUND: ICMP outbound rule in OUTPUT chain"
            outbound_rules_found=true
        else
            echo " - MISSING: ICMP outbound rule in OUTPUT chain"
        fi
    }

    check_ipv6_rules()
    {
        if command -v ip6tables >/dev/null 2>&1; then
            echo " - Checking IPv6 connection state rules..."
            
            ip6_established_tcp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'tcp state ESTABLISHED' || echo "0")
            ip6_established_udp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'udp state ESTABLISHED' || echo "0")
            ip6_established_icmp=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'icmp state ESTABLISHED' || echo "0")
            
            ip6_outbound_tcp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'tcp state NEW,ESTABLISHED' || echo "0")
            ip6_outbound_udp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'udp state NEW,ESTABLISHED' || echo "0")
            ip6_outbound_icmp=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'icmp state NEW,ESTABLISHED' || echo "0")
            
            if [ "$ip6_established_tcp" -eq 0 ] || [ "$ip6_established_udp" -eq 0 ] || [ "$ip6_established_icmp" -eq 0 ] ||
               [ "$ip6_outbound_tcp" -eq 0 ] || [ "$ip6_outbound_udp" -eq 0 ] || [ "$ip6_outbound_icmp" -eq 0 ]; then
                echo " - WARNING: Missing IPv6 connection state rules"
            else
                echo " - OK: IPv6 connection state rules configured"
            fi
        else
            echo " - INFO: ip6tables not available"
        fi
    }

    check_default_policies()
    {
        echo " - Checking default policies..."
        
        input_policy=$(iptables -L INPUT -n 2>/dev/null | grep 'policy' | awk '{print $4}' | tr -d ')' || echo "unknown")
        output_policy=$(iptables -L OUTPUT -n 2>/dev/null | grep 'policy' | awk '{print $4}' | tr -d ')' || echo "unknown")
        forward_policy=$(iptables -L FORWARD -n 2>/dev/null | grep 'policy' | awk '{print $4}' | tr -d ')' || echo "unknown")
        
        echo " - INPUT chain default policy: $input_policy"
        echo " - OUTPUT chain default policy: $output_policy"
        echo " - FORWARD chain default policy: $forward_policy"
        
        if [ "$input_policy" = "DROP" ] || [ "$input_policy" = "REJECT" ]; then
            echo " - NOTE: Restrictive INPUT policy - established rules are critical"
        fi
        
        if [ "$output_policy" = "DROP" ] || [ "$output_policy" = "REJECT" ]; then
            echo " - NOTE: Restrictive OUTPUT policy - outbound rules are critical"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing iptables remediation guidance..."
        
        echo ""
        echo "IPTABLES REMEDIATION GUIDANCE:"
        echo "=============================="
        echo ""
        echo "To configure outbound and established connections:"
        echo ""
        echo "ALLOW ESTABLISHED CONNECTIONS (INPUT - IPv4):"
        echo "  iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
        echo "  iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
        echo "  iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
        echo ""
        echo "ALLOW OUTBOUND CONNECTIONS (OUTPUT - IPv4):"
        echo "  iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "  iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "  iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo ""
        echo "ALLOW ESTABLISHED CONNECTIONS (INPUT - IPv6):"
        echo "  ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A INPUT -p icmpv6 -m state --state ESTABLISHED -j ACCEPT"
        echo ""
        echo "ALLOW OUTBOUND CONNECTIONS (OUTPUT - IPv6):"
        echo "  ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "  ip6tables -A OUTPUT -p icmpv6 -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo ""
        echo "SET RESTRICTIVE DEFAULT POLICIES (if desired):"
        echo "  iptables -P INPUT DROP"
        echo "  iptables -P FORWARD DROP"
        echo "  iptables -P OUTPUT DROP"
        echo ""
        echo "SAVE RULES PERMANENTLY:"
        echo "  service iptables save"
        echo "  -OR-"
        echo "  iptables-save > /etc/sysconfig/iptables"
        echo "  ip6tables-save > /etc/sysconfig/ip6tables"
        echo ""
        echo "VERIFY CONFIGURATION:"
        echo "  iptables -L -n"
        echo "  ip6tables -L -n"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking established connection rules..."
    check_established_rules
    remediation_applied=true
    
    echo ""
    echo "Checking outbound connection rules..."
    check_outbound_rules
    remediation_applied=true
    
    echo ""
    echo "Checking IPv6 rules..."
    check_ipv6_rules
    remediation_applied=true
    
    echo ""
    echo "Checking default policies..."
    check_default_policies
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No iptables configuration detected"
    fi

    echo ""
    echo "Remediation of iptables connection rules complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify iptables service status
    echo ""
    echo "1. VERIFYING IPTABLES SERVICE STATUS:"
    echo "-------------------------------------"
    if systemctl is-active iptables >/dev/null 2>&1; then
        echo "PASS: iptables service is ACTIVE"
        echo "PROOF (systemctl status iptables):"
        systemctl status iptables --no-pager -l | head -3
    else
        echo "INFO: iptables service is INACTIVE"
    fi
    
    # PROOF 2: Verify established connection rules
    echo ""
    echo "2. VERIFYING ESTABLISHED CONNECTION RULES (IPv4):"
    echo "-------------------------------------------------"
    established_rules_count=0
    
    input_established_tcp=$(iptables -L INPUT -n 2>/dev/null | grep -c 'tcp state ESTABLISHED' || echo "0")
    input_established_udp=$(iptables -L INPUT -n 2>/dev/null | grep -c 'udp state ESTABLISHED' || echo "0")
    input_established_icmp=$(iptables -L INPUT -n 2>/dev/null | grep -c 'icmp state ESTABLISHED' || echo "0")
    
    established_rules_count=$((input_established_tcp + input_established_udp + input_established_icmp))
    
    if [ "$input_established_tcp" -gt 0 ]; then
        echo "PASS: TCP established rule found"
        echo "PROOF: $(iptables -L INPUT -n 2>/dev/null | grep 'tcp state ESTABLISHED' | head -1)"
    else
        echo "FAIL: TCP established rule missing"
        final_status_pass=false
    fi
    
    if [ "$input_established_udp" -gt 0 ]; then
        echo "PASS: UDP established rule found"
        echo "PROOF: $(iptables -L INPUT -n 2>/dev/null | grep 'udp state ESTABLISHED' | head -1)"
    else
        echo "FAIL: UDP established rule missing"
        final_status_pass=false
    fi
    
    if [ "$input_established_icmp" -gt 0 ]; then
        echo "PASS: ICMP established rule found"
        echo "PROOF: $(iptables -L INPUT -n 2>/dev/null | grep 'icmp state ESTABLISHED' | head -1)"
    else
        echo "FAIL: ICMP established rule missing"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify outbound connection rules
    echo ""
    echo "3. VERIFYING OUTBOUND CONNECTION RULES (IPv4):"
    echo "----------------------------------------------"
    outbound_rules_count=0
    
    output_tcp=$(iptables -L OUTPUT -n 2>/dev/null | grep -c 'tcp state NEW,ESTABLISHED' || echo "0")
    output_udp=$(iptables -L OUTPUT -n 2>/dev/null | grep -c 'udp state NEW,ESTABLISHED' || echo "0")
    output_icmp=$(iptables -L OUTPUT -n 2>/dev/null | grep -c 'icmp state NEW,ESTABLISHED' || echo "0")
    
    outbound_rules_count=$((output_tcp + output_udp + output_icmp))
    
    if [ "$output_tcp" -gt 0 ]; then
        echo "PASS: TCP outbound rule found"
        echo "PROOF: $(iptables -L OUTPUT -n 2>/dev/null | grep 'tcp state NEW,ESTABLISHED' | head -1)"
    else
        echo "FAIL: TCP outbound rule missing"
        final_status_pass=false
    fi
    
    if [ "$output_udp" -gt 0 ]; then
        echo "PASS: UDP outbound rule found"
        echo "PROOF: $(iptables -L OUTPUT -n 2>/dev/null | grep 'udp state NEW,ESTABLISHED' | head -1)"
    else
        echo "FAIL: UDP outbound rule missing"
        final_status_pass=false
    fi
    
    if [ "$output_icmp" -gt 0 ]; then
        echo "PASS: ICMP outbound rule found"
        echo "PROOF: $(iptables -L OUTPUT -n 2>/dev/null | grep 'icmp state NEW,ESTABLISHED' | head -1)"
    else
        echo "FAIL: ICMP outbound rule missing"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify IPv6 rules if available
    echo ""
    echo "4. VERIFYING IPV6 CONNECTION RULES:"
    echo "-----------------------------------"
    if command -v ip6tables >/dev/null 2>&1; then
        ip6_established_count=$(ip6tables -L INPUT -n 2>/dev/null | grep -c 'state ESTABLISHED' || echo "0")
        ip6_outbound_count=$(ip6tables -L OUTPUT -n 2>/dev/null | grep -c 'state NEW,ESTABLISHED' || echo "0")
        
        echo "IPv6 established rules: $ip6_established_count"
        echo "IPv6 outbound rules: $ip6_outbound_count"
        
        if [ "$ip6_established_count" -ge 3 ] && [ "$ip6_outbound_count" -ge 3 ]; then
            echo "PASS: IPv6 connection state rules configured"
        else
            echo "INFO: IPv6 connection state rules incomplete or missing"
        fi
    else
        echo "INFO: ip6tables not available"
    fi
    
    # PROOF 5: Manual verification steps reminder
    echo ""
    echo "5. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review established connection rules for completeness"
    echo "• Verify outbound rules match application requirements"
    echo "• Test network connectivity for both inbound and outbound traffic"
    echo "• Ensure rules are saved to persistent configuration"
    echo "• Document iptables ruleset for audit purposes"
    echo ""
    echo "CONNECTION STATE RULES SUMMARY:"
    echo "==============================="
    echo ""
    echo "ESTABLISHED CONNECTION RULES (INPUT - IPv4):"
    echo "  iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
    echo "  iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
    echo "  iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
    echo ""
    echo "OUTBOUND CONNECTION RULES (OUTPUT - IPv4):"
    echo "  iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
    echo "  iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
    echo "  iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
    echo ""
    echo "PERSISTENT CONFIGURATION:"
    echo "  service iptables save"
    echo "  -OR-"
    echo "  iptables-save > /etc/sysconfig/iptables"
    echo ""
    echo "VERIFICATION COMMANDS:"
    echo "  iptables -L -n"
    echo "  iptables -L INPUT -n"
    echo "  iptables -L OUTPUT -n"

    if [ "$final_status_pass" = true ] && [ "$established_rules_count" -ge 3 ] && [ "$outbound_rules_count" -ge 3 ]; then
        echo ""
        echo "SUCCESS: iptables connection rules verification completed"
        echo "NOTE: Manual testing required to verify network functionality"
    else
        echo ""
        echo "WARNING: Missing iptables connection rules - manual configuration required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="