#!/usr/bin/env bash
# Script: 6.1.14.sh
# Item: 6.1.14 Audit system file permissions (Manual)
set -euo pipefail
SCRIPT_NAME="6.1.14.sh"
ITEM_NAME="6.1.14 Audit system file permissions (Manual)"
DESCRIPTION="This remediation audits system file permissions and corrects discrepancies."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Auditing system file permissions with rpm -Va..."
    
    audit_output=$(rpm -Va 2>&1 | grep '^..5......' || true)
    
    if [ -z "$audit_output" ]; then
        echo "PASS: No discrepancies found"
        echo "PROOF: rpm -Va shows clean output"
        return 0
    else
        echo "FAIL: Discrepancies found"
        echo "PROOF (rpm -Va output):"
        echo "$audit_output"
        return 1
    fi
}
# Function to fix discrepancies
fix_file_permissions() {
    echo "Correcting discrepancies..."
    
    # Get list of modified packages
    modified_files=$(rpm -Va | grep '^..5......' | awk '{print $NF}')
    
    for file in $modified_files; do
        package=$(rpm -qf "$file")
        echo " - Fixing permissions for $file in $package"
        rpm --setperms "$package" >/dev/null 2>&1
        rpm --setugids "$package" >/dev/null 2>&1
    done
    
    echo " - Corrections applied; rerun audit to verify"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_file_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: File permissions clean"
    else
        echo "FAIL: Issues remain - manual mitigation may be needed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="