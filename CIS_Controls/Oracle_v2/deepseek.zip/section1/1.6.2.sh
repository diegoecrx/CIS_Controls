#!/usr/bin/env bash
# Script: 1.6.2.sh
# Item: 1.6.2 Ensure local login warning banner is configured properly (Automated)
set -euo pipefail
SCRIPT_NAME="1.6.2.sh"
ITEM_NAME="1.6.2 Ensure local login warning banner is configured properly (Automated)"
DESCRIPTION="This remediation ensures /etc/issue is configured properly without forbidden variables or OS references."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/issue..."
    if [ ! -f /etc/issue ]; then
        echo "FAIL: /etc/issue does not exist"
        echo "PROOF: File not found"
        return 1
    fi
    content=$(cat /etc/issue)
    if echo "$content" | grep -qE '(\\m|\\r|\\s|\\v|CentOS|Red Hat|Linux)'; then
        echo "FAIL: Forbidden content found"
        echo "PROOF: $content"
        return 1
    else
        echo "PASS: No forbidden content"
        echo "PROOF: $content"
        return 0
    fi
}
# Function to fix
fix_issue() {
    echo "Applying fix..."
    echo "Authorized users only. All activity may be monitored and reported." > /etc/issue
    echo " - Overwritten /etc/issue with proper banner"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_issue
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Banner configured properly"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="