#!/usr/bin/env bash
# Script: 1.7.2.sh
# Item: 1.7.2 Ensure GDM login banner is configured (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.2.sh"
ITEM_NAME="1.7.2 Ensure GDM login banner is configured (Automated)"
DESCRIPTION="This remediation ensures GDM login banner is configured properly or GDM is removed."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking GDM configuration..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    l_gdmprofile="gdm"
    
    # Check if profile exists
    if [ ! -f "/etc/dconf/profile/$l_gdmprofile" ]; then
        echo "FAIL: GDM profile not configured"
        echo "PROOF: /etc/dconf/profile/$l_gdmprofile does not exist"
        return 1
    fi
    
    # Check if banner-message-enable is set to true
    if ! grep -Piq '^\h*banner-message-enable\h*=\h*true\b' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
        echo "FAIL: Banner message not enabled"
        echo "PROOF: banner-message-enable=true not found in /etc/dconf/db/$l_gdmprofile.d/"
        return 1
    fi
    
    # Check if banner message text is configured
    if ! grep -Piq "^\h*banner-message-text=[\'\"].*[\'\"]" /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
        echo "FAIL: Banner message text not configured"
        echo "PROOF: banner-message-text not found in /etc/dconf/db/$l_gdmprofile.d/"
        return 1
    fi
    
    echo "PASS: GDM banner configured properly"
    echo "PROOF: Profile exists and banner settings found"
    return 0
}
# Function to fix
fix_gdm_banner() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    l_gdmprofile="gdm"
    l_bmessage="'Authorized uses only. All activity may be monitored and reported'"
    
    # Create profile if it doesn't exist
    if [ ! -f "/etc/dconf/profile/$l_gdmprofile" ]; then
        echo " - Creating profile $l_gdmprofile"
        echo -e "user-db:user\nsystem-db:$l_gdmprofile\nfile-db:/usr/share/$l_gdmprofile/greeter-dconf-defaults" > /etc/dconf/profile/$l_gdmprofile
    fi
    
    # Create dconf database directory
    if [ ! -d "/etc/dconf/db/$l_gdmprofile.d/" ]; then
        echo " - Creating dconf database directory"
        mkdir -p /etc/dconf/db/$l_gdmprofile.d/
    fi
    
    # Configure banner settings
    if ! grep -Piq '^\h*banner-message-enable\h*=\h*true\b' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
        echo " - Creating gdm keyfile for machine-wide settings"
        l_kfile="/etc/dconf/db/$l_gdmprofile.d/01-banner-message"
        
        if ! grep -Piq -- '^\h*banner-message-enable\h*=\h*' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
            echo -e "\n[org/gnome/login-screen]\nbanner-message-enable=true" >> "$l_kfile"
        else
            l_kfile="$(grep -Pil -- '^\h*banner-message-enable\h*=\h*' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null | head -1)"
            if [ -n "$l_kfile" ]; then
                ! grep -Pq '^\h*\[org\/gnome\/login-screen\]' "$l_kfile" && sed -ri '/^\s*banner-message-enable/ i\[org/gnome/login-screen]' "$l_kfile"
                ! grep -Pq '^\h*banner-message-enable\h*=\h*true\b' "$l_kfile" && sed -ri 's/^\s*(banner-message-enable\s*=\s*)(\S+)(\s*.*$)/\1true \3/' "$l_kfile"
            fi
        fi
        
        # Add banner message text if not present
        if [ -n "$l_kfile" ] && ! grep -Piq "^\h*banner-message-text=[\'\"].*[\'\"]" "$l_kfile" 2>/dev/null; then
            sed -ri "/^\s*banner-message-enable/ a\banner-message-text=$l_bmessage" "$l_kfile"
        fi
    fi
    
    # Update dconf
    dconf update 2>/dev/null || true
    echo " - Updated dconf database"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm_banner
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GDM banner configured properly"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="