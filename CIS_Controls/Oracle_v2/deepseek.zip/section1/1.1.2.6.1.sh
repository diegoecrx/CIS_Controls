#!/usr/bin/env bash

# Script: 1.1.2.6.1_v6.sh
# Item: 1.1.2.6.1 Ensure separate partition exists for /var/log (Automated) - FORCE VERSION SIMPLE

set -euo pipefail

SCRIPT_NAME="1.1.2.6.1_v6.sh"
ITEM_NAME="1.1.2.6.1 Ensure separate partition exists for /var/log (Automated)"
DESCRIPTION="This remediation ensures a separate partition exists for /var/log. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to create partition using direct method
create_varlog_partition() {
    echo "Creating /var/log partition using direct method..."
    
    # Create disk image
    disk_image="/var_log_partition.img"
    echo " - Creating disk image: $disk_image"
    
    # Remove any existing image
    rm -f "$disk_image"
    
    # Create 1GB file using simplest method
    echo " - Creating 1GB file using dd..."
    if ! dd if=/dev/zero of="$disk_image" bs=1M count=1024 status=progress 2>&1; then
        echo "ERROR: Failed to create disk image"
        return 1
    fi
    
    # Verify the file was created
    if [ ! -f "$disk_image" ]; then
        echo "ERROR: Disk image file was not created"
        return 1
    fi
    
    file_size=$(stat -c%s "$disk_image" 2>/dev/null || echo "0")
    echo " - File size: $file_size bytes"
    
    if [ "$file_size" -lt 1048576 ]; then  # Less than 1MB
        echo "ERROR: File size is too small"
        return 1
    fi
    
    # Try different filesystems in order
    echo " - Attempting to create filesystem..."
    
    # Method 1: Try ext4 with minimal options
    if command -v mkfs.ext4 >/dev/null 2>&1; then
        echo " - Trying ext4 filesystem..."
        if mkfs.ext4 -q -F "$disk_image" 2>&1; then
            echo " - SUCCESS: Created ext4 filesystem"
            return 0
        fi
    fi
    
    # Method 2: Try ext3
    if command -v mkfs.ext3 >/dev/null 2>&1; then
        echo " - Trying ext3 filesystem..."
        if mkfs.ext3 -q -F "$disk_image" 2>&1; then
            echo " - SUCCESS: Created ext3 filesystem"
            return 0
        fi
    fi
    
    # Method 3: Try ext2
    if command -v mkfs.ext2 >/dev/null 2>&1; then
        echo " - Trying ext2 filesystem..."
        if mkfs.ext2 -q -F "$disk_image" 2>&1; then
            echo " - SUCCESS: Created ext2 filesystem"
            return 0
        fi
    fi
    
    # Method 4: Try XFS if available
    if command -v mkfs.xfs >/dev/null 2>&1; then
        echo " - Trying XFS filesystem..."
        if mkfs.xfs -q -f "$disk_image" 2>&1; then
            echo " - SUCCESS: Created XFS filesystem"
            return 0
        fi
    fi
    
    echo "ERROR: All filesystem creation methods failed"
    return 1
}

# Function to setup partition
setup_varlog_partition() {
    local disk_image="/var_log_partition.img"
    
    echo "Setting up /var/log partition..."
    
    # Stop logging services
    echo " - Stopping logging services..."
    systemctl stop rsyslog 2>/dev/null || true
    systemctl stop syslog-ng 2>/dev/null || true
    systemctl stop auditd 2>/dev/null || true
    sleep 2
    
    # Create temporary mount point
    temp_mount="/mnt/varlog_temp_$$"
    mkdir -p "$temp_mount"
    
    # Mount the disk image
    echo " - Mounting disk image..."
    if ! mount -o loop "$disk_image" "$temp_mount" 2>&1; then
        echo "ERROR: Failed to mount disk image"
        rmdir "$temp_mount" 2>/dev/null || true
        return 1
    fi
    
    echo " - Successfully mounted disk image"
    
    # Backup current /var/log
    echo " - Backing up current /var/log..."
    backup_dir="/var_log_backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    if [ -d "/var/log" ] && [ "$(ls -A /var/log 2>/dev/null)" ]; then
        echo " - Copying existing log files..."
        cp -r /var/log/* "$backup_dir/" 2>/dev/null || true
    fi
    
    # Set basic permissions on new partition
    chmod 755 "$temp_mount"
    chown root:root "$temp_mount"
    
    # Copy data to new partition
    if [ -d "$backup_dir" ] && [ "$(ls -A "$backup_dir" 2>/dev/null)" ]; then
        echo " - Restoring data to new partition..."
        cp -r "$backup_dir"/* "$temp_mount"/ 2>/dev/null || true
    fi
    
    # Create essential directories
    mkdir -p "$temp_mount/audit"
    chmod 750 "$temp_mount/audit"
    
    # Unmount temporary
    umount "$temp_mount"
    rmdir "$temp_mount"
    
    # Replace /var/log
    echo " - Replacing /var/log..."
    if [ -d "/var/log" ] && ! mountpoint -q /var/log; then
        mv /var/log "/var/log.old.backup.$$"
    fi
    
    mkdir -p /var/log
    
    # Mount to final location
    echo " - Mounting to /var/log..."
    if ! mount -o loop "$disk_image" /var/log 2>&1; then
        echo "ERROR: Failed to mount to /var/log"
        # Restore backup
        if [ -d "/var/log.old.backup.$$" ]; then
            rm -rf /var/log
            mv "/var/log.old.backup.$$" /var/log
        fi
        return 1
    fi
    
    # Update fstab
    echo " - Updating /etc/fstab..."
    cp /etc/fstab "/etc/fstab.backup.varlog.$(date +%Y%m%d_%H%M%S)"
    
    # Remove existing entries and add new one
    grep -v -E '\s/var/log\s' /etc/fstab > /etc/fstab.tmp
    echo "/var_log_partition.img /var/log auto loop,defaults,nosuid,nodev,noexec 0 2" >> /etc/fstab.tmp
    mv /etc/fstab.tmp /etc/fstab
    
    # Restart services
    echo " - Restarting logging services..."
    systemctl start rsyslog 2>/dev/null || true
    systemctl start syslog-ng 2>/dev/null || true
    systemctl start auditd 2>/dev/null || true
    
    sleep 2
    echo " - SUCCESS: /var/log partition setup completed"
    return 0
}

# Function to check current status
check_current_status() {
    echo "Checking current /var/log partition status..."
    echo ""

    # Display current mount status
    echo "Current /var/log mount information:"
    mount | grep -E '\s/var/log\s' || echo "No separate /var/log mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/log:"
    grep -E '\s/var/log\s' /etc/fstab || echo "No /var/log entry in /etc/fstab"
    echo ""

    # Check if /var/log is a separate partition
    echo "Checking if /var/log is a separate partition:"
    varlog_device=$(df /var/log --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$varlog_device" ] && [ -n "$var_device" ] && [ "$varlog_device" != "$var_device" ]; then
        echo "PASS: /var/log is on separate partition: $varlog_device"
        return 0
    elif [ -n "$varlog_device" ] && [ -n "$root_device" ] && [ "$varlog_device" != "$root_device" ]; then
        echo "PASS: /var/log is on separate partition: $varlog_device"
        return 0
    else
        echo "FAIL: /var/log is NOT on separate partition"
        if [ -n "$varlog_device" ]; then
            echo "PROOF: /var/log shares device with $varlog_device"
        else
            echo "PROOF: /var/log is not mounted separately"
        fi
        return 1
    fi
}

# Main remediation
{
    # Check current status first
    if check_current_status; then
        echo "PASS: /var/log is already on separate partition"
        exit 0
    fi

    echo ""
    echo "==================================================================="
    echo "FORCE MODE: CREATING SEPARATE /VAR/LOG PARTITION"
    echo "==================================================================="
    echo ""

    # Check disk space
    echo "Checking disk space..."
    if ! df / | awk 'NR==2 {if ($4 < 2097152) exit 1}'; then
        echo "ERROR: Insufficient disk space (need at least 2GB free)"
        exit 1
    fi
    echo "PASS: Sufficient disk space available"

    # Create partition
    if create_varlog_partition; then
        echo " - Partition created successfully"
    else
        echo "ERROR: Failed to create partition"
        echo "Trying alternative method with smaller size..."
        
        # Try with smaller size
        rm -f /var_log_partition.img
        if ! dd if=/dev/zero of=/var_log_partition.img bs=1M count=512 status=progress 2>&1; then
            echo "ERROR: Failed with smaller size too"
            exit 1
        fi
        
        # Try ext2 with smaller size
        if ! mkfs.ext2 -q -F /var_log_partition.img 2>&1; then
            echo "ERROR: All methods failed"
            exit 1
        fi
        echo " - Partition created with smaller size (512MB)"
    fi

    # Setup the partition
    if setup_varlog_partition; then
        echo " - Partition setup completed successfully"
    else
        echo "ERROR: Failed to setup partition"
        # Cleanup
        rm -f /var_log_partition.img
        exit 1
    fi

    # Final verification
    echo ""
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    
    if mountpoint -q /var/log; then
        echo "SUCCESS: /var/log is now on separate partition"
        echo ""
        echo "Mount details:"
        mount | grep -E '\s/var/log\s'
        echo ""
        echo "Disk usage:"
        df -h /var/log
        echo ""
        echo "fstab entry:"
        grep -E '\s/var/log\s' /etc/fstab
        echo ""
        echo "Testing logging..."
        logger -t "PartitionTest" "Test message after partition setup"
        echo " - Logging test completed"
    else
        echo "FAIL: /var/log is not mounted as separate partition"
        echo "Current status:"
        df /var/log
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="