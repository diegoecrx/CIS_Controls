#!/usr/bin/env bash
# Script: 1.5.1.6.sh
# Item: 1.5.1.6 Ensure no unconfined services exist (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.6.sh"
ITEM_NAME="1.5.1.6 Ensure no unconfined services exist (Automated)"
DESCRIPTION="This remediation checks for unconfined services and reports them for manual investigation."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check for unconfined services
check_unconfined() {
    unconfined=$(ps -eZ | egrep "initrc|u:r:unconfined_service_t:s0" || true)
    if [ -z "$unconfined" ]; then
        echo "PASS: No unconfined services found"
        echo "PROOF: ps -eZ output shows no matches"
        return 0
    else
        echo "FAIL: Unconfined services found"
        echo "PROOF (ps -eZ output):"
        echo "$unconfined"
        return 1
    fi
}
# Main remediation
{
    echo "Checking for unconfined services..."
    if check_unconfined; then
        echo "No remediation needed"
    else
        echo "Manual investigation required: Assign security contexts or build policies for listed services"
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_unconfined; then
        echo "SUCCESS: No unconfined services"
    else
        echo "FAIL: Unconfined services exist - manual fix needed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="