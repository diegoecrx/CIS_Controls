#!/usr/bin/env bash

# Script: 1.1.2.4.3_v2.sh
# Item: 1.1.2.4.3 Ensure nosuid option set on /var partition (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.4.3_v2.sh"
ITEM_NAME="1.1.2.4.3 Ensure nosuid option set on /var partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /var partition. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /var mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /var mount information:"
    mount | grep -E '\s/var\s' || echo "No separate /var mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var:"
    grep -E '\s/var\s' /etc/fstab || echo "No /var entry in /etc/fstab"
    echo ""

    # Check if /var is a separate partition
    echo "Checking if /var is a separate partition:"
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$var_device" ] && [ -n "$root_device" ] && [ "$var_device" != "$root_device" ]; then
        echo "PASS: /var is on separate partition: $var_device"
        var_is_separate=true
    else
        echo "FAIL: /var is NOT on separate partition"
        echo "PROOF: /var shares device with root filesystem"
        var_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /var partition if needed
    if [ "$var_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /VAR PARTITION WITH nosuid OPTION"
        echo "==================================================================="
        echo ""

        # Call the partition creation script first
        if [ -f "1.1.2.4.1_v2.sh" ]; then
            /usr/bin/env bash 1.1.2.4.1_v2.sh
        else
            echo " - ERROR: 1.1.2.4.1_v2.sh not found. Creating partition manually..."
            
            # Manual partition creation as fallback
            echo " - Creating backup of /var to /var_backup_$(date +%Y%m%d_%H%M%S)..."
            backup_dir="/var_backup_$(date +%Y%m%d_%H%M%S)"
            mkdir -p "/$backup_dir"
            
            # Backup critical /var data
            for dir in lib log spool mail; do
                if [ -d "/var/$dir" ]; then
                    mkdir -p "/$backup_dir/$dir"
                    cp -a "/var/$dir"/* "/$backup_dir/$dir/" 2>/dev/null || true
                fi
            done
            
            # Create loop device partition
            echo " - Creating 4GB disk image at /var_partition.img..."
            dd if=/dev/zero of=/var_partition.img bs=1M count=4096 status=progress
            mkfs.ext4 -F /var_partition.img
            
            # Mount and setup
            mkdir -p /mnt/newvar
            mount -o loop /var_partition.img /mnt/newvar
            mkdir -p /mnt/newvar/{lib,log,spool,mail,tmp,cache,run,lock}
            chmod 1777 /mnt/newvar/tmp
            
            # Restore data
            for dir in lib log spool mail; do
                if [ -d "/$backup_dir/$dir" ]; then
                    cp -a "/$backup_dir/$dir"/* "/mnt/newvar/$dir/" 2>/dev/null || true
                fi
            done
            
            # Replace /var
            mv /var /var.old
            mkdir /var
            umount /mnt/newvar
            mount -o loop /var_partition.img /var
            
            # Update fstab
            cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
            echo "/var_partition.img /var ext4 loop,defaults 0 2" >> /etc/fstab
            
            rmdir /mnt/newvar
            echo " - SUCCESS: Manual /var partition creation completed"
        fi
        var_is_separate=true
    fi

    echo "Applying nosuid remediation..."

    # Function to update fstab with nosuid option
    update_fstab_nosuid()
    {
        # Check if /var entry exists in fstab
        if grep -q -E '\s/var\s' /etc/fstab; then
            echo " - Checking /var entry in /etc/fstab for nosuid option"
            
            # Get the current /var entry
            current_entry=$(grep -E '\s/var\s' /etc/fstab)
            
            # Check if nosuid option is already present
            if echo "$current_entry" | grep -q 'nosuid'; then
                echo " - nosuid option already present in /etc/fstab"
                return 0
            else
                echo " - Adding nosuid option to /etc/fstab"
                
                # Create backup of fstab
                cp /etc/fstab /etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)
                echo " - Backup created: /etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)"
                
                # Create temporary fstab without /var entry
                grep -v -E '\s/var\s' /etc/fstab > /etc/fstab.tmp
                
                # Add nosuid option to the mount options field (4th field)
                if echo "$current_entry" | grep -q 'defaults,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nosuid,/' | sed 's/,,/,/g')
                else
                    # If no defaults, add nosuid to options
                    updated_entry=$(echo "$current_entry" | awk '{$4=$4",nosuid"; print}')
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /var entry in /etc/fstab with nosuid option"
            fi
        else
            echo " - ERROR: No /var entry found in /etc/fstab"
            return 1
        fi
    }

    # Function to remount /var with nosuid option
    remount_var_nosuid()
    {
        echo " - Checking /var mount for nosuid option"
        
        # Check if /var is mounted as separate filesystem
        if mount | grep -q -E '\s/var\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/var\s')
            
            # Check if nosuid is already set in current mount
            if echo "$mount_line" | grep -q 'nosuid'; then
                echo " - nosuid option already set on current /var mount"
            else
                echo " - Remounting /var with nosuid option"
                # Add nosuid to current options and remount
                if mount -o remount,nosuid /var; then
                    echo " - SUCCESS: /var remounted with nosuid option"
                else
                    echo " - WARNING: Could not remount /var with nosuid option"
                    return 1
                fi
            fi
        else
            echo " - ERROR: /var is not mounted as separate filesystem"
            return 1
        fi
    }

    # Function to remove existing setuid files from /var
    remove_setuid_files()
    {
        echo " - Scanning for setuid files in /var..."
        setuid_files=$(find /var -type f -perm /4000 2>/dev/null | wc -l)
        if [ "$setuid_files" -gt 0 ]; then
            echo " - WARNING: Found $setuid_files setuid files in /var"
            echo " - Removing setuid bits for security..."
            find /var -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null || true
            echo " - SUCCESS: Setuid bits removed from files in /var"
        else
            echo " - PASS: No setuid files found in /var"
        fi
    }

    # Apply remediation steps
    if update_fstab_nosuid; then
        remount_var_nosuid
        remove_setuid_files
    else
        echo " - Skipping remount due to missing /var configuration"
    fi

    echo ""
    echo "Remediation of nosuid option on /var partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /var is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "---------------------------------------------------"
    mount_output=$(mount | grep -E '\s/var\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /var is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /var is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nosuid option in current mount
    echo ""
    echo "2. VERIFYING nosuid OPTION IN CURRENT MOUNT:"
    echo "-------------------------------------------"
    mount_line=$(mount | grep -E '\s/var\s' || true)
    if echo "$mount_line" | grep -q 'nosuid'; then
        echo "PASS: nosuid option set on current /var mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nosuid option NOT set on current /var mount - attempting remount"
        if mount -o remount,nosuid /var 2>/dev/null; then
            mount_line=$(mount | grep -E '\s/var\s' || true)
            if echo "$mount_line" | grep -q 'nosuid'; then
                echo "PASS: nosuid option now set on /var mount"
                echo "PROOF (mount output):"
                echo "$mount_line"
            else
                echo "FAIL: Could not set nosuid option on /var mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /var with nosuid option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nosuid option in fstab
    echo ""
    echo "3. VERIFYING nosuid OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/var\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nosuid'; then
            echo "PASS: nosuid option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nosuid option NOT found in /etc/fstab - updating now"
            # Remove existing entry
            grep -v -E '\s/var\s' /etc/fstab > /etc/fstab.tmp
            # Add nosuid to mount options (4th field)
            if echo "$fstab_entry" | grep -q 'defaults,'; then
                updated_entry=$(echo "$fstab_entry" | sed 's/defaults,/defaults,nosuid,/' | sed 's/,,/,/g')
            else
                # If no defaults, add nosuid to beginning of options
                updated_entry=$(echo "$fstab_entry" | awk '{$4=$4",nosuid"; print}')
            fi
            echo "$updated_entry" >> /etc/fstab.tmp
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nosuid option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/var\s' /etc/fstab
        fi
    else
        echo "FAIL: No /var entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_nosuid=$(grep -E '\s/var\s' /etc/fstab | grep -o 'nosuid' | head -1 || true)
    mount_has_nosuid=$(mount | grep -E '\s/var\s' | grep -o 'nosuid' | head -1 || true)
    
    if [ -n "$fstab_has_nosuid" ] && [ -n "$mount_has_nosuid" ]; then
        echo "PASS: nosuid option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab options: $(grep -E '\s/var\s' /etc/fstab | awk '{print $4}')"
        echo "  mount options: $(mount | grep -E '\s/var\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_has_nosuid" ] && [ -z "$mount_has_nosuid" ]; then
        echo "FAIL: nosuid in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_has_nosuid" ] && [ -n "$mount_has_nosuid" ]; then
        echo "FAIL: nosuid in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nosuid option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Verify no setuid files remain in /var
    echo ""
    echo "5. VERIFYING NO SETUID FILES IN /var:"
    echo "------------------------------------"
    setuid_files=$(find /var -type f -perm /4000 2>/dev/null | wc -l)
    if [ "$setuid_files" -eq 0 ]; then
        echo "PASS: No setuid files found in /var"
        echo "PROOF: find /var -type f -perm /4000 returned 0 files"
    else
        echo "WARNING: Found $setuid_files setuid files in /var after remediation"
        echo "PROOF (first 5 setuid files):"
        find /var -type f -perm /4000 2>/dev/null | head -5
        echo " - Forcing removal of setuid bits..."
        find /var -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null
        final_status_pass=false
    fi

    # PROOF 6: Test setuid execution (should fail with nosuid)
    echo ""
    echo "6. TESTING SETUID EXECUTION BLOCKED:"
    echo "-----------------------------------"
    # Create a test setuid binary in /var/tmp
    test_binary="/var/tmp/test_suid_$$"
    cat > "${test_binary}.c" << 'EOF'
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("Setuid test executed - UID: %d, EUID: %d\n", getuid(), geteuid());
    return 0;
}
EOF
    
    # Compile and set setuid if possible
    if command -v gcc >/dev/null 2>&1; then
        if gcc -o "$test_binary" "${test_binary}.c" 2>/dev/null; then
            # Try to set setuid (may fail due to nosuid)
            if chmod u+s "$test_binary" 2>/dev/null; then
                # Try to execute
                if "$test_binary" 2>/dev/null; then
                    echo "FAIL: Setuid execution succeeded - nosuid may not be working"
                    final_status_pass=false
                else
                    echo "PASS: Setuid execution blocked - nosuid is working"
                fi
            else
                echo "PASS: Setuid bit setting blocked - nosuid is working"
            fi
            # Clean up
            rm -f "$test_binary" "${test_binary}.c"
        else
            echo "INFO: Could not compile test binary (gcc not available or failed)"
            rm -f "${test_binary}.c"
        fi
    else
        echo "INFO: gcc not available, setuid execution test skipped"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        echo "FORCE MODE SUMMARY:"
        echo "==================="
        echo "✓ Separate /var partition created (if needed)"
        echo "✓ nosuid option applied to /var partition"
        echo "✓ Configuration persisted in /etc/fstab"
        echo "✓ Setuid files removed from /var"
        echo "✓ Backups created for safety"
        echo ""
        echo "SECURITY BENEFITS FOR /var:"
        echo "• Prevents setuid program execution in system directories"
        echo "• Blocks privilege escalation attacks through /var"
        echo "• Protects log files and system data from setuid exploits"
        echo "• Enhances overall system security"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="