#!/usr/bin/env bash

# Script: 1.2.1.sh
# Item: 1.2.1 Ensure GPG keys are configured (Manual)
# Description: Update your package manager GPG keys in accordance with site policy.
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="1.2.1.sh"
ITEM_NAME="1.2.1 Ensure GPG keys are configured (Manual)"
DESCRIPTION="Update your package manager GPG keys in accordance with site policy."
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current status of GPG keys configuration..."
    echo ""

    # Display current GPG keys status
    echo "Current GPG keys status:"
    echo "========================="
    
    # Check for APT (Debian/Ubuntu)
    if command -v apt-key >/dev/null 2>&1; then
        echo "APT package manager detected"
        echo "---------------------------"
        apt-key list 2>/dev/null | head -20 || echo "No GPG keys found or error listing APT keys"
    else
        echo "APT package manager not detected"
    fi
    
    echo ""
    
    # Check for RPM (RedHat/CentOS/Fedora)
    if command -v rpm >/dev/null 2>&1; then
        echo "RPM package manager detected"
        echo "---------------------------"
        rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\t%{SUMMARY}\n' 2>/dev/null | head -10 || echo "No GPG keys found or error listing RPM keys"
    else
        echo "RPM package manager not detected"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    update_apt_keys()
    {
        echo " - Updating APT GPG keys..."
        if command -v apt-get >/dev/null 2>&1; then
            echo " - Refreshing package lists..."
            apt-get update >/dev/null 2>&1 || echo " - WARNING: Could not refresh package lists"
            
            # Check for specific repositories that might need key updates
            if [ -f /etc/apt/sources.list ] || [ -d /etc/apt/sources.list.d ]; then
                echo " - Checking for repository key updates..."
                # This would typically be done manually based on site policy
                echo " - NOTE: Manual intervention required for specific repository keys"
            fi
        fi
    }

    update_rpm_keys()
    {
        echo " - Updating RPM GPG keys..."
        if command -v rpm >/dev/null 2>&1; then
            echo " - Checking RPM database integrity..."
            rpm --checksig $(rpm -qa) >/dev/null 2>&1 || echo " - WARNING: Some packages have signature issues"
            
            # Import any missing keys from configured repositories
            if command -v yum >/dev/null 2>&1; then
                echo " - Refreshing YUM/DNF repository data..."
                yum makecache >/dev/null 2>&1 || echo " - WARNING: Could not refresh repository data"
            elif command -v dnf >/dev/null 2>&1; then
                echo " - Refreshing DNF repository data..."
                dnf makecache >/dev/null 2>&1 || echo " - WARNING: Could not refresh repository data"
            fi
        fi
    }

    # Apply remediation based on detected package manager
    remediation_applied=false
    
    if command -v apt-key >/dev/null 2>&1 || command -v apt-get >/dev/null 2>&1; then
        echo ""
        echo "APT-based system detected - applying APT-specific remediation..."
        update_apt_keys
        remediation_applied=true
    fi
    
    if command -v rpm >/dev/null 2>&1; then
        echo ""
        echo "RPM-based system detected - applying RPM-specific remediation..."
        update_rpm_keys
        remediation_applied=true
    fi

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No supported package manager detected - manual configuration required"
    fi

    echo ""
    echo "Remediation of GPG keys configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify APT keys are configured
    echo ""
    echo "1. VERIFYING APT GPG KEYS:"
    echo "--------------------------"
    if command -v apt-key >/dev/null 2>&1; then
        apt_key_count=$(apt-key list 2>/dev/null | grep -c "pub" || true)
        if [ "$apt_key_count" -gt 0 ]; then
            echo "PASS: $apt_key_count APT GPG keys configured"
            echo "PROOF (first 5 APT keys):"
            apt-key list 2>/dev/null | grep "pub" -A 1 | head -10 || true
        else
            echo "WARNING: No APT GPG keys found"
            echo "PROOF (apt-key list output):"
            apt-key list 2>/dev/null | head -5 || true
        fi
    else
        echo "INFO: APT package manager not available"
    fi
    
    # PROOF 2: Verify RPM keys are configured
    echo ""
    echo "2. VERIFYING RPM GPG KEYS:"
    echo "--------------------------"
    if command -v rpm >/dev/null 2>&1; then
        rpm_key_count=$(rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\t%{SUMMARY}\n' 2>/dev/null | wc -l || true)
        if [ "$rpm_key_count" -gt 0 ]; then
            echo "PASS: $rpm_key_count RPM GPG keys configured"
            echo "PROOF (RPM GPG keys):"
            rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\t%{SUMMARY}\n' 2>/dev/null | head -5 || true
        else
            echo "WARNING: No RPM GPG keys found"
            echo "PROOF (rpm -q gpg-pubkey output):"
            rpm -q gpg-pubkey 2>/dev/null || true
        fi
    else
        echo "INFO: RPM package manager not available"
    fi
    
    # PROOF 3: Verify package manager functionality
    echo ""
    echo "3. VERIFYING PACKAGE MANAGER FUNCTIONALITY:"
    echo "------------------------------------------"
    if command -v apt-get >/dev/null 2>&1; then
        echo "Testing APT package manager..."
        if apt-get check >/dev/null 2>&1; then
            echo "PASS: APT package manager configured correctly"
            echo "PROOF (apt-get check):"
            apt-get check 2>&1 | head -5 || true
        else
            echo "WARNING: APT package manager has issues"
            echo "PROOF (apt-get check output):"
            apt-get check 2>&1 | head -5 || true
            final_status_pass=false
        fi
    elif command -v yum >/dev/null 2>&1; then
        echo "Testing YUM package manager..."
        if yum check-update >/dev/null 2>&1; then
            echo "PASS: YUM package manager configured correctly"
            echo "PROOF (yum check-update): Success"
        else
            echo "WARNING: YUM package manager has issues"
            echo "PROOF (yum check-update output):"
            yum check-update 2>&1 | head -5 || true
            final_status_pass=false
        fi
    elif command -v dnf >/dev/null 2>&1; then
        echo "Testing DNF package manager..."
        if dnf check-update >/dev/null 2>&1; then
            echo "PASS: DNF package manager configured correctly"
            echo "PROOF (dnf check-update): Success"
        else
            echo "WARNING: DNF package manager has issues"
            echo "PROOF (dnf check-update output):"
            dnf check-update 2>&1 | head -5 || true
            final_status_pass=false
        fi
    fi
    
    # PROOF 4: Manual verification steps reminder
    echo ""
    echo "4. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Verify all repository GPG keys match organizational policy"
    echo "• Ensure no unauthorized repositories are configured"
    echo "• Confirm key fingerprints match trusted sources"
    echo "• Check key expiration dates and renewal schedules"
    echo ""
    echo "MANUAL STEPS:"
    echo "1. Review /etc/apt/sources.list and /etc/apt/sources.list.d/ (APT)"
    echo "2. Review /etc/yum.repos.d/ and /etc/dnf/dnf.conf (RPM)"
    echo "3. Verify key fingerprints with trusted sources"
    echo "4. Remove any unauthorized or expired keys"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Automated remediation steps completed"
        echo "NOTE: Manual verification required per organizational policy"
    else
        echo ""
        echo "WARNING: Some issues detected - manual intervention required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="