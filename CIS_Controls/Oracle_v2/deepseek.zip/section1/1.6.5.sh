#!/usr/bin/env bash
# Script: 1.6.5.sh
# Item: 1.6.5 Ensure access to /etc/issue is configured (Automated)
set -euo pipefail
SCRIPT_NAME="1.6.5.sh"
ITEM_NAME="1.6.5 Ensure access to /etc/issue is configured (Automated)"
DESCRIPTION="This remediation ensures access to /etc/issue is configured with correct permissions and ownership."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/issue access..."
    issue_file=$(readlink -e /etc/issue 2>/dev/null || true)
    if [ -z "$issue_file" ]; then
        echo "FAIL: /etc/issue does not exist"
        echo "PROOF: readlink -e /etc/issue returned empty"
        return 1
    fi
    owner=$(stat -c '%U:%G' "$issue_file")
    perm=$(stat -c '%a' "$issue_file")
    if [ "$owner" = "root:root" ] && [ "$perm" = "644" ]; then
        echo "PASS: Correct permissions and ownership"
        echo "PROOF: Owner $owner, Perm $perm"
        return 0
    else
        echo "FAIL: Incorrect permissions or ownership"
        echo "PROOF: Owner $owner, Perm $perm"
        return 1
    fi
}
# Function to fix
fix_issue() {
    echo "Applying fix..."
    issue_file=$(readlink -e /etc/issue 2>/dev/null || true)
    if [ -n "$issue_file" ]; then
        chown root:root "$issue_file"
        chmod u-x,go-wx "$issue_file"
        echo " - Set permissions on $issue_file"
    else
        echo " - No file to fix"
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_issue
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Access configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="