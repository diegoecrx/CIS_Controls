#!/usr/bin/env bash
# Script: 1.2.2.sh
# Item: 1.2.2 Ensure gpgcheck is globally activated (Automated)
set -euo pipefail
SCRIPT_NAME="1.2.2.sh"
ITEM_NAME="1.2.2 Ensure gpgcheck is globally activated (Automated)"
DESCRIPTION="This remediation ensures gpgcheck is globally activated in yum configuration."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to fix yum.conf
fix_yum_conf() {
    echo "Fixing /etc/yum.conf..."
    if grep -q '^gpgcheck=1' /etc/yum.conf; then
        echo " - gpgcheck already set to 1 in [main]"
    else
        sed -i 's/^gpgcheck\s*=\s*.*/gpgcheck=1/' /etc/yum.conf
        echo " - Updated gpgcheck to 1 in /etc/yum.conf"
    fi
}
# Function to fix repo files
fix_repo_files() {
    echo "Fixing repo files in /etc/yum.repos.d/..."
    failing_files=$(grep -l '^gpgcheck=0' /etc/yum.repos.d/*.repo 2>/dev/null || true)
    if [ -n "$failing_files" ]; then
        for file in $failing_files; do
            sed -i 's/^gpgcheck\s*=\s*0/gpgcheck=1/' "$file"
            echo " - Updated $file"
        done
    else
        echo " - No failing repo files"
    fi
}
# Function to check current status
check_current_status() {
    echo "Checking current status..."
    echo ""
    echo "yum.conf gpgcheck:"
    grep '^gpgcheck' /etc/yum.conf || echo "No gpgcheck in yum.conf"
    echo ""
    echo "Repo files with gpgcheck=0:"
    grep '^gpgcheck=0' /etc/yum.repos.d/*.repo 2>/dev/null || echo "None"
}
# Main remediation
{
    check_current_status
    echo ""
    echo "Applying remediation..."
    fix_yum_conf
    fix_repo_files
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    # Verify yum.conf
    echo ""
    echo "1. VERIFY YUM.CONF:"
    yum_gpg=$(grep '^gpgcheck' /etc/yum.conf || true)
    if echo "$yum_gpg" | grep -q '^gpgcheck=1'; then
        echo "PASS: gpgcheck=1 in yum.conf"
        echo "PROOF: $yum_gpg"
    else
        echo "FAIL: gpgcheck not 1 in yum.conf"
        echo "PROOF: $yum_gpg"
        final_pass=false
    fi
    # Verify repo files
    echo ""
    echo "2. VERIFY REPO FILES:"
    repo_gpg=$(grep '^gpgcheck=0' /etc/yum.repos.d/*.repo 2>/dev/null || true)
    if [ -z "$repo_gpg" ]; then
        echo "PASS: No gpgcheck=0 in repo files"
        echo "PROOF: No matches found"
    else
        echo "FAIL: gpgcheck=0 found in repo files"
        echo "PROOF: $repo_gpg"
        final_pass=false
    fi
    echo ""
    echo "==================================================================="
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: gpgcheck globally activated"
    else
        echo "WARNING: Some issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="