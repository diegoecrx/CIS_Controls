#!/usr/bin/env bash
# Script: 4.4.2.2.3.sh
# Item: 4.4.2.2.3 Ensure password length is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.2.3.sh"
ITEM_NAME="4.4.2.2.3 Ensure password length is configured (Automated)"
DESCRIPTION="This remediation ensures password length is configured with minlen >=14."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check pwquality.conf
check_pwquality_conf() {
    echo "Checking /etc/security/pwquality.conf..."
    minlen_line=$(grep '^minlen' /etc/security/pwquality.conf || true)
    if [ -n "$minlen_line" ]; then
        value=$(echo "$minlen_line" | awk -F= '{print $2}' | tr -d ' ')
        if [ "$value" -ge 14 ] 2>/dev/null; then
            echo "PASS: minlen >=14"
            echo "PROOF: $minlen_line"
            return 0
        fi
    fi
    echo "FAIL: minlen <14 or missing"
    echo "PROOF: $minlen_line"
    return 1
}
# Function to check PAM files for minlen
check_pam_files() {
    echo "Checking PAM files for minlen in pam_pwquality.so..."
    fail=false
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        pam_line=$(grep 'pam_pwquality.so' "$file" || true)
        if echo "$pam_line" | grep -q 'minlen'; then
            echo "FAIL: minlen found in $file"
            echo "PROOF: $pam_line"
            fail=true
        fi
    done
    if [ "$fail" = false ]; then
        echo "PASS: No minlen in pam_pwquality.so"
        return 0
    else
        return 1
    fi
}
# Function to fix pwquality.conf
fix_pwquality_conf() {
    echo "Fixing /etc/security/pwquality.conf..."
    sed -ri 's/^\s*minlen\s*=/# &/' /etc/security/pwquality.conf
    echo "minlen = 14" >> /etc/security/pwquality.conf
    echo " - Set minlen=14"
}
# Function to fix PAM files
fix_pam_files() {
    echo "Fixing PAM files..."
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+minlen\s*=\s*[0-9]+)(.*$)/\1\4/' "$file"
        echo " - Removed minlen from $file"
    done
}
# Main remediation
{
    pwquality_ok=true
    pam_ok=true
    if ! check_pwquality_conf; then
        pwquality_ok=false
    fi
    if ! check_pam_files; then
        pam_ok=false
    fi
    if [ "$pwquality_ok" = true ] && [ "$pam_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_pwquality_conf
        fix_pam_files
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_pwquality_conf; then
        final_pass=false
    fi
    if ! check_pam_files; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Password length configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="