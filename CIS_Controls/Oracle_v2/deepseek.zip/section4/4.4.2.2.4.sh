#!/usr/bin/env bash

# Script: 4.4.2.2.4.sh
# Item: 4.4.2.2.4 Ensure password complexity is configured (Manual)
# Description: "Edit /etc/security/pwquality.conf and add or modify the following line to set:
# minclass = 4
# --AND/OR--
# dcredit = -_N>
# ucredit = <N>
# ocredit = <N>
# lcredit = <N>
# Example:
# # printf '\n%s' ""minclass = 4"" >> /etc/security/pwquality.conf
# --AND/OR--
# # printf '%s\n' ""dcredit = -1"" ""ucredit = -1"" ""ocredit = -1"" ""lcredit = -1""
# >> /etc/security/pwquality.conf
# Run the following script to remove setting minclass, dcredit, ucredit, lcredit, and
# ocredit on the pam_pwquality.so module in the PAM files
# #!/usr/bin/env bash

# {
# for l_pam_file in system-auth password-auth; do
# sed -ri
# 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+
# minclass\s*=\s*\S+)(.*$)/\1\4/' /etc/pam.d/""$l_pam_file""
# sed -ri
# 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+
# dcredit\s*=\s*\S+)(.*$)/\1\4/' /etc/pam.d/""$l_pam_file""
# sed -ri
# 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+
# ucredit\s*=\s*\S+)(.*$)/\1\4/' /etc/pam.d/""$l_pam_file""
# sed -ri
# 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+
# lcredit\s*=\s*\S+)(.*$)/\1\4/' /etc/pam.d/""$l_pam_file""
# sed -ri
# 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+
# ocredit\s*=\s*\S+)(.*$)/\1\4/' /etc/pam.d/""$l_pam_file""
# done
# }"
# Default Value: "minclass = 0
# dcredit = 0
# ucredit = 0
# ocredit = 0
# lcredit = 0"
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="4.4.2.2.4.sh"
ITEM_NAME="4.4.2.2.4 Ensure password complexity is configured (Manual)"
DESCRIPTION="Configure password complexity requirements in pwquality.conf according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current password complexity configuration..."
    echo ""

    # Display current pwquality.conf configuration
    echo "Current pwquality.conf configuration:"
    echo "====================================="
    
    if [ -f /etc/security/pwquality.conf ]; then
        echo "File: /etc/security/pwquality.conf exists"
        echo ""
        echo "Current password complexity settings:"
        grep -E '^(minclass|dcredit|ucredit|ocredit|lcredit|minlen)' /etc/security/pwquality.conf 2>/dev/null | head -10 || echo "No complexity settings found"
    else
        echo "File: /etc/security/pwquality.conf does NOT exist"
    fi
    
    echo ""
    
    # Check PAM configuration for pwquality
    echo "PAM configuration for pwquality:"
    echo "================================"
    pam_files=("system-auth" "password-auth")
    
    for pam_file in "${pam_files[@]}"; do
        if [ -f "/etc/pam.d/$pam_file" ]; then
            echo "File: /etc/pam.d/$pam_file"
            grep -E 'pam_pwquality\.so' "/etc/pam.d/$pam_file" 2>/dev/null | head -3 || echo "No pam_pwquality configuration found"
            echo ""
        else
            echo "File: /etc/pam.d/$pam_file does not exist"
            echo ""
        fi
    done
    
    echo ""
    
    # Check for legacy pam_cracklib configuration
    echo "Legacy PAM configuration (pam_cracklib):"
    echo "========================================"
    for pam_file in "${pam_files[@]}"; do
        if [ -f "/etc/pam.d/$pam_file" ]; then
            grep -E 'pam_cracklib\.so' "/etc/pam.d/$pam_file" 2>/dev/null | head -2 || echo "No pam_cracklib configuration found"
        fi
    done
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_current_complexity_settings()
    {
        echo " - Checking current password complexity settings..."
        
        # Check minclass setting
        minclass=$(grep -E '^minclass\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
        echo " - minclass (character classes): $minclass"
        
        # Check credit settings
        dcredit=$(grep -E '^dcredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
        ucredit=$(grep -E '^ucredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
        ocredit=$(grep -E '^ocredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
        lcredit=$(grep -E '^lcredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
        
        echo " - dcredit (digits): $dcredit"
        echo " - ucredit (uppercase): $ucredit"
        echo " - ocredit (other/special): $ocredit"
        echo " - lcredit (lowercase): $lcredit"
        
        # Check minlen
        minlen=$(grep -E '^minlen\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "not set")
        echo " - minlen (minimum length): $minlen"
    }

    check_pam_inline_settings()
    {
        echo " - Checking for inline PAM settings (should be removed)..."
        
        problematic_settings_found=false
        
        for pam_file in "${pam_files[@]}"; do
            if [ -f "/etc/pam.d/$pam_file" ]; then
                if grep -E 'pam_pwquality\.so.*(minclass|dcredit|ucredit|ocredit|lcredit)\s*=' "/etc/pam.d/$pam_file" >/dev/null 2>&1; then
                    echo " - WARNING: Inline complexity settings found in /etc/pam.d/$pam_file"
                    grep -E 'pam_pwquality\.so.*(minclass|dcredit|ucredit|ocredit|lcredit)\s*=' "/etc/pam.d/$pam_file" | head -2
                    problematic_settings_found=true
                fi
            fi
        done
        
        if [ "$problematic_settings_found" = false ]; then
            echo " - OK: No inline complexity settings in PAM files"
        fi
    }

    verify_pwquality_usage()
    {
        echo " - Verifying pwquality PAM module usage..."
        
        pwquality_used=false
        
        for pam_file in "${pam_files[@]}"; do
            if [ -f "/etc/pam.d/$pam_file" ]; then
                if grep -q 'pam_pwquality\.so' "/etc/pam.d/$pam_file"; then
                    echo " - FOUND: pam_pwquality configured in /etc/pam.d/$pam_file"
                    pwquality_used=true
                fi
            fi
        done
        
        if [ "$pwquality_used" = false ]; then
            echo " - WARNING: pam_pwquality not found in PAM configuration"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing password complexity remediation guidance..."
        
        echo ""
        echo "PASSWORD COMPLEXITY REMEDIATION GUIDANCE:"
        echo "========================================="
        echo ""
        echo "OPTION 1: Configure in /etc/security/pwquality.conf"
        echo "---------------------------------------------------"
        echo "Edit /etc/security/pwquality.conf and add/modify:"
        echo ""
        echo "For character class requirement (recommended):"
        echo "  minclass = 4"
        echo ""
        echo "For specific character requirements:"
        echo "  dcredit = -1    # At least 1 digit"
        echo "  ucredit = -1    # At least 1 uppercase letter"
        echo "  lcredit = -1    # At least 1 lowercase letter"
        echo "  ocredit = -1    # At least 1 special character"
        echo ""
        echo "Minimum password length:"
        echo "  minlen = 14     # Minimum 14 characters"
        echo ""
        echo "Example commands:"
        echo "  echo 'minclass = 4' >> /etc/security/pwquality.conf"
        echo "  echo 'minlen = 14' >> /etc/security/pwquality.conf"
        echo ""
        echo "OPTION 2: Remove inline PAM settings"
        echo "------------------------------------"
        echo "Run the following to remove inline settings from PAM files:"
        echo ""
        cat << 'EOF'
for l_pam_file in system-auth password-auth; do
  if [ -f "/etc/pam.d/$l_pam_file" ]; then
    sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+minclass\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/$l_pam_file"
    sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+dcredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/$l_pam_file"
    sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+ucredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/$l_pam_file"
    sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+lcredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/$l_pam_file"
    sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+ocredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/$l_pam_file"
  fi
done
EOF
        echo ""
        echo "VERIFICATION:"
        echo "  cat /etc/security/pwquality.conf"
        echo "  grep pam_pwquality /etc/pam.d/system-auth /etc/pam.d/password-auth"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking current complexity settings..."
    check_current_complexity_settings
    remediation_applied=true
    
    echo ""
    echo "Checking for inline PAM settings..."
    check_pam_inline_settings
    remediation_applied=true
    
    echo ""
    echo "Verifying pwquality usage..."
    verify_pwquality_usage
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No password complexity configuration detected"
    fi

    echo ""
    echo "Remediation of password complexity configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify pwquality.conf exists and has settings
    echo ""
    echo "1. VERIFYING PWQUALITY.CONF:"
    echo "----------------------------"
    if [ -f /etc/security/pwquality.conf ]; then
        echo "PASS: /etc/security/pwquality.conf exists"
        echo ""
        echo "Current settings:"
        grep -E '^(minclass|dcredit|ucredit|ocredit|lcredit|minlen)' /etc/security/pwquality.conf 2>/dev/null || echo "No complexity settings configured"
    else
        echo "FAIL: /etc/security/pwquality.conf does not exist"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify minclass setting
    echo ""
    echo "2. VERIFYING MINCLASS SETTING:"
    echo "------------------------------"
    minclass=$(grep -E '^minclass\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
    if [ "$minclass" -ge 3 ]; then
        echo "PASS: minclass = $minclass (requires $minclass character classes)"
        echo "PROOF: minclass setting meets complexity requirements"
    else
        echo "WARNING: minclass = $minclass (should be at least 3-4)"
        echo "PROOF: minclass setting needs improvement"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify credit settings
    echo ""
    echo "3. VERIFYING CHARACTER CREDIT SETTINGS:"
    echo "---------------------------------------"
    dcredit=$(grep -E '^dcredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
    ucredit=$(grep -E '^ucredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
    ocredit=$(grep -E '^ocredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
    lcredit=$(grep -E '^lcredit\s*=' /etc/security/pwquality.conf 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' || echo "0")
    
    echo "dcredit (digits): $dcredit"
    echo "ucredit (uppercase): $ucredit"
    echo "ocredit (special): $ocredit"
    echo "lcredit (lowercase): $lcredit"
    
    negative_credits=0
    if [[ "$dcredit" =~ -[0-9]+ ]]; then ((negative_credits++)); fi
    if [[ "$ucredit" =~ -[0-9]+ ]]; then ((negative_credits++)); fi
    if [[ "$ocredit" =~ -[0-9]+ ]]; then ((negative_credits++)); fi
    if [[ "$lcredit" =~ -[0-9]+ ]]; then ((negative_credits++)); fi
    
    if [ "$negative_credits" -ge 3 ]; then
        echo "PASS: $negative_credits character type requirements configured"
    else
        echo "INFO: Consider configuring more character type requirements"
    fi
    
    # PROOF 4: Verify no inline PAM settings
    echo ""
    echo "4. VERIFYING NO INLINE PAM SETTINGS:"
    echo "------------------------------------"
    inline_settings_found=false
    for pam_file in "${pam_files[@]}"; do
        if [ -f "/etc/pam.d/$pam_file" ]; then
            if grep -E 'pam_pwquality\.so.*(minclass|dcredit|ucredit|ocredit|lcredit)\s*=' "/etc/pam.d/$pam_file" >/dev/null 2>&1; then
                echo "FAIL: Inline settings found in /etc/pam.d/$pam_file"
                grep -E 'pam_pwquality\.so.*(minclass|dcredit|ucredit|ocredit|lcredit)\s*=' "/etc/pam.d/$pam_file" | head -2
                inline_settings_found=true
                final_status_pass=false
            fi
        fi
    done
    
    if [ "$inline_settings_found" = false ]; then
        echo "PASS: No inline complexity settings in PAM files"
    fi
    
    # PROOF 5: Verify PAM configuration uses pwquality
    echo ""
    echo "5. VERIFYING PAM CONFIGURATION:"
    echo "-------------------------------"
    pwquality_configured=false
    for pam_file in "${pam_files[@]}"; do
        if [ -f "/etc/pam.d/$pam_file" ] && grep -q 'pam_pwquality\.so' "/etc/pam.d/$pam_file"; then
            echo "PASS: pam_pwquality configured in /etc/pam.d/$pam_file"
            pwquality_configured=true
        fi
    done
    
    if [ "$pwquality_configured" = false ]; then
        echo "FAIL: pam_pwquality not configured in PAM files"
        final_status_pass=false
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review password complexity requirements against organizational policy"
    echo "• Test password changes to verify complexity enforcement"
    echo "• Consider usability impact of complexity requirements"
    echo "• Document password policy for user awareness"
    echo "• Ensure password complexity aligns with industry best practices"
    echo ""
    echo "RECOMMENDED SETTINGS:"
    echo "====================="
    echo "  minclass = 4      # Require 4 character classes"
    echo "  minlen = 14       # Minimum 14 characters"
    echo "  -OR-"
    echo "  dcredit = -1      # Require at least 1 digit"
    echo "  ucredit = -1      # Require at least 1 uppercase"
    echo "  lcredit = -1      # Require at least 1 lowercase"
    echo "  ocredit = -1      # Require at least 1 special character"
    echo ""
    echo "CONFIGURATION FILES:"
    echo "  /etc/security/pwquality.conf"
    echo "  /etc/pam.d/system-auth"
    echo "  /etc/pam.d/password-auth"
    echo ""
    echo "TESTING COMMANDS:"
    echo "  echo 'TestPassword123!' | pwscore    # Test password strength"
    echo "  passwd testuser                     # Test password change"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Password complexity configuration verification completed"
        echo "NOTE: Manual testing required to verify password policy enforcement"
    else
        echo ""
        echo "WARNING: Password complexity configuration issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="