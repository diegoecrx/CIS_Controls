#!/usr/bin/env bash
# Script: 4.2.16.sh
# Item: 4.2.16 Ensure sshd MaxAuthTries is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.16.sh"
ITEM_NAME="4.2.16 Ensure sshd MaxAuthTries is configured (Automated)"
DESCRIPTION="This remediation ensures sshd MaxAuthTries is configured to 4 in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^MaxAuthTries' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ]; then
        value=$(echo "$conf_line" | awk '{print $2}')
        if [ "$value" -le 4 ] 2>/dev/null; then
            echo "PASS: MaxAuthTries <=4"
            echo "PROOF: $conf_line"
            return 0
        fi
    fi
    echo "FAIL: MaxAuthTries not <=4"
    echo "PROOF: $conf_line"
    return 1
}
# Function to fix
fix_maxauthtries() {
    echo "Applying fix..."
    sed -i '/^MaxAuthTries/d' /etc/ssh/sshd_config
    echo "MaxAuthTries 4" >> /etc/ssh/sshd_config
    echo " - Set MaxAuthTries 4"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_maxauthtries
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: MaxAuthTries configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="