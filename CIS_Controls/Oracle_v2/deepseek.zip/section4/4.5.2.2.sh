#!/usr/bin/env bash
# Script: 4.5.2.2.sh
# Item: 4.5.2.2 Ensure root user umask is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.2.2.sh"
ITEM_NAME="4.5.2.2 Ensure root user umask is configured (Automated)"
DESCRIPTION="This remediation ensures root user umask is 0027 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check root umask in .bash_profile
check_bash_profile() {
    echo "Checking /root/.bash_profile..."
    if [ ! -f /root/.bash_profile ]; then
        echo "FAIL: /root/.bash_profile not found"
        echo "PROOF: File does not exist"
        return 1
    fi
    umask_line=$(grep -E 'umask' /root/.bash_profile || true)
    if [ -z "$umask_line" ]; then
        echo "PASS: No umask set in /root/.bash_profile (using system default)"
        echo "PROOF: No umask line found"
        return 0
    else
        umask_val=$(echo "$umask_line" | sed 's/^.*umask[[:space:]]*\([0-9]*\).*/\1/')
        # Check if umask is 0027 or more restrictive (higher value = more restrictive)
        if [ "$umask_val" -ge 27 ] && [ "$umask_val" -le 77 ]; then
            echo "PASS: umask in /root/.bash_profile is $umask_val (0027 or more restrictive)"
            echo "PROOF: $umask_line"
            return 0
        else
            echo "FAIL: umask in /root/.bash_profile is $umask_val (should be 0027 or more restrictive)"
            echo "PROOF: $umask_line"
            return 1
        fi
    fi
}
# Function to check root umask in .bashrc
check_bashrc() {
    echo "Checking /root/.bashrc..."
    if [ ! -f /root/.bashrc ]; then
        echo "FAIL: /root/.bashrc not found"
        echo "PROOF: File does not exist"
        return 1
    fi
    umask_line=$(grep -E 'umask' /root/.bashrc || true)
    if [ -z "$umask_line" ]; then
        echo "PASS: No umask set in /root/.bashrc (using system default)"
        echo "PROOF: No umask line found"
        return 0
    else
        umask_val=$(echo "$umask_line" | sed 's/^.*umask[[:space:]]*\([0-9]*\).*/\1/')
        # Check if umask is 0027 or more restrictive
        if [ "$umask_val" -ge 27 ] && [ "$umask_val" -le 77 ]; then
            echo "PASS: umask in /root/.bashrc is $umask_val (0027 or more restrictive)"
            echo "PROOF: $umask_line"
            return 0
        else
            echo "FAIL: umask in /root/.bashrc is $umask_val (should be 0027 or more restrictive)"
            echo "PROOF: $umask_line"
            return 1
        fi
    fi
}
# Function to fix .bash_profile
fix_bash_profile() {
    echo "Fixing /root/.bash_profile..."
    if [ -f /root/.bash_profile ]; then
        sed -i '/^[[:space:]]*umask[[:space:]]/d' /root/.bash_profile
        echo " - Removed umask from /root/.bash_profile"
    fi
}
# Function to fix .bashrc
fix_bashrc() {
    echo "Fixing /root/.bashrc..."
    if [ -f /root/.bashrc ]; then
        sed -i '/^[[:space:]]*umask[[:space:]]/d' /root/.bashrc
        echo " - Removed umask from /root/.bashrc"
    fi
}
# Main remediation
{
    profile_ok=true
    bashrc_ok=true
    if ! check_bash_profile; then
        profile_ok=false
    fi
    if ! check_bashrc; then
        bashrc_ok=false
    fi
    if [ "$profile_ok" = true ] && [ "$bashrc_ok" = true ]; then
        echo "No remediation needed"
    else
        if [ "$profile_ok" = false ]; then
            fix_bash_profile
        fi
        if [ "$bashrc_ok" = false ]; then
            fix_bashrc
        fi
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_bash_profile; then
        final_pass=false
    fi
    if ! check_bashrc; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: root user umask is configured correctly"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
