#!/usr/bin/env bash
# Script: 4.2.18.sh
# Item: 4.2.18 Ensure sshd MaxStartups is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.18.sh"
ITEM_NAME="4.2.18 Ensure sshd MaxStartups is configured (Automated)"
DESCRIPTION="This remediation ensures sshd MaxStartups is configured to 10:30:60 in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^MaxStartups' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -q '10:30:60'; then
        echo "PASS: MaxStartups is 10:30:60"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: MaxStartups not 10:30:60"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_maxstartups() {
    echo "Applying fix..."
    sed -i '/^MaxStartups/d' /etc/ssh/sshd_config
    echo "MaxStartups 10:30:60" >> /etc/ssh/sshd_config
    echo " - Set MaxStartups 10:30:60"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_maxstartups
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: MaxStartups configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="