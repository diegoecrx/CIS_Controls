#!/usr/bin/env bash

# Script: 4.2.9.sh
# Item: 4.2.9 Ensure sshd GSSAPIAuthentication is disabled (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.9.sh"
ITEM_NAME="4.2.9 Ensure sshd GSSAPIAuthentication is disabled (Automated)"
DESCRIPTION="This remediation ensures SSH GSSAPIAuthentication directive is set to no in sshd_config."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH GSSAPIAuthentication configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"

if [ ! -f "$SSHD_CONFIG" ]; then
  echo "ERROR: $SSHD_CONFIG not found"
  exit 1
fi

# Check current GSSAPIAuthentication configuration
echo "Current GSSAPIAuthentication directive in $SSHD_CONFIG:"
current_gssapi=$(grep -Pi '^\s*GSSAPIAuthentication\s+' "$SSHD_CONFIG" || echo "Not configured")
echo "$current_gssapi"
echo ""

echo "Applying remediation..."
echo ""

# Backup sshd_config
cp "$SSHD_CONFIG" "${SSHD_CONFIG}.bak.$(date +%Y%m%d%H%M%S)"
echo " - Created backup of $SSHD_CONFIG"

# Remove any existing GSSAPIAuthentication directives (commented or uncommented)
sed -i '/^\s*#\?\s*GSSAPIAuthentication\s/d' "$SSHD_CONFIG"
echo " - Removed existing GSSAPIAuthentication directives"

# Find the line number of the first Match directive
match_line=$(grep -n "^Match" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "")

if [ -n "$match_line" ]; then
  # Insert GSSAPIAuthentication directive before Match
  sed -i "${match_line}i GSSAPIAuthentication no" "$SSHD_CONFIG"
  echo " - Inserted 'GSSAPIAuthentication no' before Match directive at line $match_line"
else
  # No Match directive, append to end
  echo "" >> "$SSHD_CONFIG"
  echo "GSSAPIAuthentication no" >> "$SSHD_CONFIG"
  echo " - Appended 'GSSAPIAuthentication no' to end of file"
fi

echo ""
echo " - SUCCESS: Applied GSSAPIAuthentication configuration"
echo ""

echo "Remediation of SSH GSSAPIAuthentication configuration complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

final_status_pass=true

echo ""
echo "1. VERIFYING GSSAPIAuthentication IS SET TO no:"
echo "-----------------------------------------------"

current_gssapi=$(grep -Pi '^\s*GSSAPIAuthentication\s+' "$SSHD_CONFIG" || true)

if [ -n "$current_gssapi" ]; then
  echo "PASS: GSSAPIAuthentication directive is configured"
  echo "PROOF:"
  echo "$current_gssapi"
  
  # Check if it's set to no
  if echo "$current_gssapi" | grep -iq "\sno\s*$"; then
    echo "PASS: GSSAPIAuthentication is set to no"
  else
    echo "FAIL: GSSAPIAuthentication is NOT set to no"
    echo "Current value: $current_gssapi"
    
    # Attempt to fix
    sed -i '/^\s*GSSAPIAuthentication\s/d' "$SSHD_CONFIG"
    match_line=$(grep -n "^Match" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "")
    if [ -n "$match_line" ]; then
      sed -i "${match_line}i GSSAPIAuthentication no" "$SSHD_CONFIG"
    else
      echo "" >> "$SSHD_CONFIG"
      echo "GSSAPIAuthentication no" >> "$SSHD_CONFIG"
    fi
    echo "Applied fix - set GSSAPIAuthentication to no"
  fi
else
  echo "FAIL: GSSAPIAuthentication directive is NOT configured"
  final_status_pass=false
fi

echo ""
echo "2. VERIFYING SSHD CONFIGURATION SYNTAX:"
echo "---------------------------------------"

if sshd -t 2>&1; then
  echo "PASS: SSHD configuration syntax is valid"
else
  echo "FAIL: SSHD configuration has syntax errors"
  echo "PROOF:"
  sshd -t 2>&1 || true
  final_status_pass=false
fi

echo ""
echo "3. RELOADING SSHD SERVICE:"
echo "-------------------------"

if systemctl reload-or-try-restart sshd.service 2>&1; then
  echo "PASS: SSHD service reloaded successfully"
else
  echo "FAIL: Failed to reload SSHD service"
  final_status_pass=false
fi

echo ""
echo "4. VERIFYING SSHD SERVICE STATUS:"
echo "---------------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "PASS: SSHD service is active"
  echo "PROOF:"
  systemctl status sshd.service --no-pager -l | head -10
else
  echo "FAIL: SSHD service is not active"
  final_status_pass=false
fi

echo ""
echo "5. TESTING ACTUAL CONFIGURATION IN USE:"
echo "---------------------------------------"

echo "PROOF (sshd -T output for GSSAPIAuthentication):"
sshd -T | grep -i "^gssapiauthentication" || echo "Could not retrieve GSSAPIAuthentication configuration"

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
