#!/usr/bin/env bash
# Script: 4.5.1.1.sh
# Item: 4.5.1.1 Ensure strong password hashing algorithm is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.1.1.sh"
ITEM_NAME="4.5.1.1 Ensure strong password hashing algorithm is configured (Automated)"
DESCRIPTION="This remediation ensures sha512 password hashing is configured in libuser.conf and login.defs."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check /etc/libuser.conf
check_libuser_conf() {
    echo "Checking /etc/libuser.conf..."
    if [ ! -f /etc/libuser.conf ]; then
        echo "FAIL: /etc/libuser.conf not found"
        echo "PROOF: File does not exist"
        return 1
    fi
    crypt_style=$(grep -E '^[[:space:]]*crypt_style[[:space:]]*=' /etc/libuser.conf || true)
    if [ -n "$crypt_style" ]; then
        if echo "$crypt_style" | grep -q 'sha512'; then
            echo "PASS: crypt_style = sha512"
            echo "PROOF: $crypt_style"
            return 0
        else
            echo "FAIL: crypt_style != sha512"
            echo "PROOF: $crypt_style"
            return 1
        fi
    else
        echo "FAIL: crypt_style not set"
        echo "PROOF: No crypt_style line found"
        return 1
    fi
}
# Function to check /etc/login.defs
check_login_defs() {
    echo "Checking /etc/login.defs..."
    if [ ! -f /etc/login.defs ]; then
        echo "FAIL: /etc/login.defs not found"
        echo "PROOF: File does not exist"
        return 1
    fi
    encrypt_method=$(grep -E '^[[:space:]]*ENCRYPT_METHOD[[:space:]]' /etc/login.defs || true)
    if [ -n "$encrypt_method" ]; then
        if echo "$encrypt_method" | grep -q 'SHA512'; then
            echo "PASS: ENCRYPT_METHOD SHA512"
            echo "PROOF: $encrypt_method"
            return 0
        else
            echo "FAIL: ENCRYPT_METHOD != SHA512"
            echo "PROOF: $encrypt_method"
            return 1
        fi
    else
        echo "FAIL: ENCRYPT_METHOD not set"
        echo "PROOF: No ENCRYPT_METHOD line found"
        return 1
    fi
}
# Function to fix /etc/libuser.conf
fix_libuser_conf() {
    echo "Fixing /etc/libuser.conf..."
    if [ ! -f /etc/libuser.conf ]; then
        echo " - Creating /etc/libuser.conf"
        echo "[defaults]" > /etc/libuser.conf
        echo "crypt_style = sha512" >> /etc/libuser.conf
    else
        sed -ri 's/^\s*crypt_style\s*=.*$/crypt_style = sha512/' /etc/libuser.conf
        if ! grep -q 'crypt_style' /etc/libuser.conf; then
            echo "crypt_style = sha512" >> /etc/libuser.conf
        fi
        echo " - Set crypt_style = sha512"
    fi
}
# Function to fix /etc/login.defs
fix_login_defs() {
    echo "Fixing /etc/login.defs..."
    sed -ri 's/^\s*ENCRYPT_METHOD\s+.*$/ENCRYPT_METHOD SHA512/' /etc/login.defs
    if ! grep -q '^ENCRYPT_METHOD' /etc/login.defs; then
        echo "ENCRYPT_METHOD SHA512" >> /etc/login.defs
    fi
    echo " - Set ENCRYPT_METHOD SHA512"
}
# Main remediation
{
    libuser_ok=true
    login_ok=true
    if ! check_libuser_conf; then
        libuser_ok=false
    fi
    if ! check_login_defs; then
        login_ok=false
    fi
    if [ "$libuser_ok" = true ] && [ "$login_ok" = true ]; then
        echo "No remediation needed"
    else
        if [ "$libuser_ok" = false ]; then
            fix_libuser_conf
        fi
        if [ "$login_ok" = false ]; then
            fix_login_defs
        fi
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_libuser_conf; then
        final_pass=false
    fi
    if ! check_login_defs; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Strong password hashing algorithm (sha512) configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
