#!/usr/bin/env bash
# Script: 4.5.1.2.sh
# Item: 4.5.1.2 Ensure password expiration is 365 days or less (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.1.2.sh"
ITEM_NAME="4.5.1.2 Ensure password expiration is 365 days or less (Automated)"
DESCRIPTION="This remediation ensures PASS_MAX_DAYS is 365 or less in login.defs and for all users."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check /etc/login.defs
check_login_defs() {
    echo "Checking /etc/login.defs..."
    pass_max_days=$(grep -E '^[[:space:]]*PASS_MAX_DAYS[[:space:]]' /etc/login.defs || true)
    if [ -n "$pass_max_days" ]; then
        days=$(echo "$pass_max_days" | awk '{print $2}')
        if [ "$days" -le 365 ] && [ "$days" -gt 0 ]; then
            echo "PASS: PASS_MAX_DAYS $days"
            echo "PROOF: $pass_max_days"
            return 0
        else
            echo "FAIL: PASS_MAX_DAYS $days (should be 1-365)"
            echo "PROOF: $pass_max_days"
            return 1
        fi
    else
        echo "FAIL: PASS_MAX_DAYS not set"
        echo "PROOF: No PASS_MAX_DAYS line found"
        return 1
    fi
}
# Function to check user accounts
check_users() {
    echo "Checking user accounts..."
    fail=false
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            max_days=$(chage -l "$user" 2>/dev/null | grep "Maximum number of days" | awk -F: '{print $2}' | tr -d ' ')
            if [ -n "$max_days" ] && [ "$max_days" != "-1" ]; then
                if [ "$max_days" -le 365 ] && [ "$max_days" -gt 0 ]; then
                    echo "PASS: $user has maxdays=$max_days"
                else
                    echo "FAIL: $user has maxdays=$max_days (should be 1-365)"
                    fail=true
                fi
            else
                echo "FAIL: $user has maxdays=$max_days (not set or unlimited)"
                fail=true
            fi
        fi
    done < /etc/passwd
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix /etc/login.defs
fix_login_defs() {
    echo "Fixing /etc/login.defs..."
    sed -ri 's/^\s*PASS_MAX_DAYS\s+.*$/PASS_MAX_DAYS 365/' /etc/login.defs
    if ! grep -q '^PASS_MAX_DAYS' /etc/login.defs; then
        echo "PASS_MAX_DAYS 365" >> /etc/login.defs
    fi
    echo " - Set PASS_MAX_DAYS 365"
}
# Function to fix user accounts
fix_users() {
    echo "Fixing user accounts..."
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            max_days=$(chage -l "$user" 2>/dev/null | grep "Maximum number of days" | awk -F: '{print $2}' | tr -d ' ')
            if [ -z "$max_days" ] || [ "$max_days" = "-1" ] || [ "$max_days" -gt 365 ]; then
                chage --maxdays 365 "$user"
                echo " - Set maxdays=365 for $user"
            fi
        fi
    done < /etc/passwd
}
# Main remediation
{
    login_ok=true
    users_ok=true
    if ! check_login_defs; then
        login_ok=false
    fi
    if ! check_users; then
        users_ok=false
    fi
    if [ "$login_ok" = true ] && [ "$users_ok" = true ]; then
        echo "No remediation needed"
    else
        if [ "$login_ok" = false ]; then
            fix_login_defs
        fi
        if [ "$users_ok" = false ]; then
            fix_users
        fi
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_login_defs; then
        final_pass=false
    fi
    if ! check_users; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Password expiration is 365 days or less"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
