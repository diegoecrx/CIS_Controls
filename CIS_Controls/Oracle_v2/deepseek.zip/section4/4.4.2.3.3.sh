#!/usr/bin/env bash
# Script: 4.4.2.3.3.sh
# Item: 4.4.2.3.3 Ensure password history is enforced for the root user (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.3.3.sh"
ITEM_NAME="4.4.2.3.3 Ensure password history is enforced for the root user (Automated)"
DESCRIPTION="This remediation ensures password history is enforced for the root user."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check PAM files for pam_pwhistory with enforce_for_root
check_pam_files() {
    echo "Checking PAM files for pam_pwhistory with enforce_for_root..."
    fail=false
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo "Checking $file..."
        # Check pam_pwhistory line includes enforce_for_root
        pwhistory_line=$(grep '^password.*pam_pwhistory\.so' "$file" || true)
        if [ -n "$pwhistory_line" ]; then
            if echo "$pwhistory_line" | grep -q 'enforce_for_root'; then
                echo "PASS: pam_pwhistory has enforce_for_root in $file"
                echo "PROOF: $pwhistory_line"
            else
                echo "FAIL: pam_pwhistory missing enforce_for_root in $file"
                echo "PROOF: $pwhistory_line"
                fail=true
            fi
        else
            echo "FAIL: pam_pwhistory line not found in $file"
            echo "PROOF: No pam_pwhistory.so line"
            fail=true
        fi
        # Ensure use_authtok on all password lines except first and pam_deny
        idx=0
        while IFS= read -r line; do
            if echo "$line" | grep -q '^password'; then
                idx=$((idx+1))
                if echo "$line" | grep -q 'pam_deny\.so'; then
                    continue
                fi
                if [ $idx -gt 1 ]; then
                    if echo "$line" | grep -q 'use_authtok'; then
                        echo "PASS: use_authtok present on password line #$idx"
                    else
                        echo "FAIL: Missing use_authtok on password line #$idx"
                        echo "PROOF: $line"
                        fail=true
                    fi
                fi
            fi
        done < "$file"
    done
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix PAM files
fix_pam_files() {
    echo "Fixing PAM files..."
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo " - Processing $file"
        # Ensure pam_pwhistory line exists with required options
        if grep -q '^password.*pam_pwhistory\.so' "$file"; then
            if ! grep -q '^password.*pam_pwhistory\.so.*enforce_for_root' "$file"; then
                sed -i '/^password.*pam_pwhistory\.so/ s/$/ enforce_for_root/' "$file"
                echo "   - Added enforce_for_root to pam_pwhistory line"
            else
                echo "   - pam_pwhistory already includes enforce_for_root"
            fi
        else
            sed -i '/^password.*pam_pwquality\.so/a password required pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' "$file"
            echo "   - Inserted pam_pwhistory line with enforce_for_root after pam_pwquality"
        fi
        # Add use_authtok to all password lines except first and pam_deny
        idx=0
        tmpfile=$(mktemp)
        while IFS= read -r line; do
            if echo "$line" | grep -q '^password'; then
                idx=$((idx+1))
                if echo "$line" | grep -q 'pam_deny\.so'; then
                    echo "$line" >> "$tmpfile"
                    continue
                fi
                if [ $idx -gt 1 ] && ! echo "$line" | grep -q 'use_authtok'; then
                    echo "${line} use_authtok" >> "$tmpfile"
                else
                    echo "$line" >> "$tmpfile"
                fi
            else
                echo "$line" >> "$tmpfile"
            fi
        done < "$file"
        cat "$tmpfile" > "$file"
        rm -f "$tmpfile"
        echo "   - Ensured use_authtok on subsequent password lines"
    done
}
# Main remediation
{
    pam_ok=true
    if ! check_pam_files; then
        pam_ok=false
    fi
    if [ "$pam_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_pam_files
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_pam_files; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Password history is enforced for the root user"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
