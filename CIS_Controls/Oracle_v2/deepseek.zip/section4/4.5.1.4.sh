#!/usr/bin/env bash
# Script: 4.5.1.4.sh
# Item: 4.5.1.4 Ensure inactive password lock is 30 days or less (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.1.4.sh"
ITEM_NAME="4.5.1.4 Ensure inactive password lock is 30 days or less (Automated)"
DESCRIPTION="This remediation ensures inactive password lock is set to 30 days or less."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check /etc/default/useradd
check_useradd() {
    echo "Checking /etc/default/useradd..."
    if [ ! -f /etc/default/useradd ]; then
        echo "FAIL: /etc/default/useradd not found"
        echo "PROOF: File does not exist"
        return 1
    fi
    inactive=$(grep -E '^[[:space:]]*INACTIVE[[:space:]]*=' /etc/default/useradd || true)
    if [ -n "$inactive" ]; then
        days=$(echo "$inactive" | awk -F= '{print $2}' | tr -d ' ')
        if [ "$days" -gt 0 ] && [ "$days" -le 30 ]; then
            echo "PASS: INACTIVE=$days"
            echo "PROOF: $inactive"
            return 0
        else
            echo "FAIL: INACTIVE=$days (should be 1-30)"
            echo "PROOF: $inactive"
            return 1
        fi
    else
        echo "FAIL: INACTIVE not set"
        echo "PROOF: No INACTIVE line found"
        return 1
    fi
}
# Function to check user accounts
check_users() {
    echo "Checking user accounts..."
    fail=false
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            inactive=$(chage -l "$user" 2>/dev/null | grep "Password inactive" | awk -F: '{print $2}' | tr -d ' ')
            if [ -n "$inactive" ] && [ "$inactive" != "never" ]; then
                if [ "$inactive" -le 30 ] && [ "$inactive" -gt 0 ]; then
                    echo "PASS: $user has inactive=$inactive"
                else
                    echo "FAIL: $user has inactive=$inactive (should be 1-30)"
                    fail=true
                fi
            else
                echo "FAIL: $user has inactive=$inactive (not set or never)"
                fail=true
            fi
        fi
    done < /etc/passwd
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix /etc/default/useradd
fix_useradd() {
    echo "Fixing /etc/default/useradd..."
    useradd -D -f 30
    echo " - Set INACTIVE=30"
}
# Function to fix user accounts
fix_users() {
    echo "Fixing user accounts..."
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            inactive=$(chage -l "$user" 2>/dev/null | grep "Password inactive" | awk -F: '{print $2}' | tr -d ' ')
            if [ -z "$inactive" ] || [ "$inactive" = "never" ] || [ "$inactive" -gt 30 ]; then
                chage --inactive 30 "$user"
                echo " - Set inactive=30 for $user"
            fi
        fi
    done < /etc/passwd
}
# Main remediation
{
    useradd_ok=true
    users_ok=true
    if ! check_useradd; then
        useradd_ok=false
    fi
    if ! check_users; then
        users_ok=false
    fi
    if [ "$useradd_ok" = true ] && [ "$users_ok" = true ]; then
        echo "No remediation needed"
    else
        if [ "$useradd_ok" = false ]; then
            fix_useradd
        fi
        if [ "$users_ok" = false ]; then
            fix_users
        fi
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_useradd; then
        final_pass=false
    fi
    if ! check_users; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Inactive password lock is 30 days or less"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
