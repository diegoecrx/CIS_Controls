#!/usr/bin/env bash
# Script: 4.1.1.2.sh
# Item: 4.1.1.2 Ensure permissions on /etc/crontab are configured (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures that /etc/crontab has correct ownership (root:root) and permissions (644).

set -euo pipefail

SCRIPT_NAME="4.1.1.2.sh"
ITEM_NAME="4.1.1.2 Ensure permissions on /etc/crontab are configured (Automated)"
DESCRIPTION="This remediation ensures that /etc/crontab has correct ownership (root:root) and permissions (644)."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

if [ ! -f /etc/crontab ]; then
  echo "FAIL: /etc/crontab does not exist."
  exit 1
fi

chown root:root /etc/crontab
chmod og-rwx /etc/crontab
chmod 644 /etc/crontab

# Verification
owner=$(stat -c '%U' /etc/crontab)
group=$(stat -c '%G' /etc/crontab)
perms=$(stat -c '%a' /etc/crontab)

if [ "$owner" = "root" ] && [ "$group" = "root" ] && [ "$perms" = "644" ]; then
  echo "SUCCESS: /etc/crontab permissions and ownership correctly set."
  stat /etc/crontab
else
  echo "FAIL: /etc/crontab permissions or ownership incorrect."
  stat /etc/crontab
fi

echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
