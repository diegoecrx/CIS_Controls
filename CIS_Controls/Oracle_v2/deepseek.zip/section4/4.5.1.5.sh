#!/usr/bin/env bash
# Script: 4.5.1.5.sh
# Item: 4.5.1.5 Ensure all users last password change date is in the past (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.1.5.sh"
ITEM_NAME="4.5.1.5 Ensure all users last password change date is in the past (Automated)"
DESCRIPTION="This remediation ensures all users have last password change dates in the past."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check user password change dates
check_users() {
    echo "Checking user password change dates..."
    fail=false
    today=$(date +%s)
    today_days=$((today / 86400))
    
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            last_change=$(chage -l "$user" 2>/dev/null | grep "Last password change" | awk -F: '{print $2}' | tr -d ' ')
            if [ -n "$last_change" ] && [ "$last_change" != "never" ]; then
                # Convert date to epoch seconds
                change_epoch=$(date -d "$last_change" +%s 2>/dev/null || echo "0")
                change_days=$((change_epoch / 86400))
                
                if [ $change_days -le $today_days ]; then
                    echo "PASS: $user password change date is in the past: $last_change"
                else
                    echo "FAIL: $user password change date is in the future: $last_change"
                    fail=true
                fi
            fi
        fi
    done < /etc/passwd
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to expire passwords for users with future change dates (remediation)
fix_users() {
    echo "Fixing users with future password change dates..."
    today=$(date +%s)
    today_days=$((today / 86400))
    
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            last_change=$(chage -l "$user" 2>/dev/null | grep "Last password change" | awk -F: '{print $2}' | tr -d ' ')
            if [ -n "$last_change" ] && [ "$last_change" != "never" ]; then
                change_epoch=$(date -d "$last_change" +%s 2>/dev/null || echo "0")
                change_days=$((change_epoch / 86400))
                
                if [ $change_days -gt $today_days ]; then
                    # Expire the password to force change
                    chage -d $(date +%Y-%m-%d) "$user"
                    echo " - Expired password for $user (had future change date)"
                fi
            fi
        fi
    done < /etc/passwd
}
# Main remediation
{
    users_ok=true
    if ! check_users; then
        users_ok=false
    fi
    if [ "$users_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_users
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_users; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: All users have password change dates in the past"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
