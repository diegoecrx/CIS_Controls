#!/usr/bin/env bash
# Script: 4.4.2.3.2.sh
# Item: 4.4.2.3.2 Ensure password history remember is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.3.2.sh"
ITEM_NAME="4.4.2.3.2 Ensure password history remember is configured (Automated)"
DESCRIPTION="This remediation ensures password history remember is configured in PAM files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check PAM file
check_pam_file() {
    local file="$1"
    echo "Checking $file..."
    pwhistory=$(grep -E '^password\s+required\s+pam_pwhistory.so\s+remember=24\s+enforce_for_root\s+try_first_pass\s+use_authtok' "$file" || true)
    if [ -n "$pwhistory" ]; then
        echo "PASS: pam_pwhistory with remember=24 present"
        echo "PROOF: $pwhistory"
        return 0
    else
        echo "FAIL: pam_pwhistory with remember=24 missing"
        echo "PROOF: No match found"
        return 1
    fi
}
# Function to fix PAM file
fix_pam_file() {
    local file="$1"
    echo "Fixing $file..."
    # Backup
    cp "$file" "$file.bak.$(date +%Y%m%d)"
    # Insert after pam_pwquality.so
    sed -i '/^password\s+requisite\s+pam_pwquality.so/a password required pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' "$file"
    echo " - Fixed $file"
}
# Main remediation
{
    files=("/etc/pam.d/system-auth" "/etc/pam.d/password-auth")
    need_fix=false
    for file in "${files[@]}"; do
        if ! check_pam_file "$file"; then
            need_fix=true
        fi
    done
    if [ "$need_fix" = false ]; then
        echo "No remediation needed"
    else
        for file in "${files[@]}"; do
            fix_pam_file "$file"
        done
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    all_pass=true
    for file in "${files[@]}"; do
        if ! check_pam_file "$file"; then
            all_pass=false
        fi
    done
    if [ "$all_pass" = true ]; then
        echo "SUCCESS: Password history remember configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="