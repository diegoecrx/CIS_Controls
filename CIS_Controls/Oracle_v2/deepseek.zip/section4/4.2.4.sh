#!/usr/bin/env bash

# Script: 4.2.4.sh
# Item: 4.2.4 Ensure sshd access is configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.4.sh"
ITEM_NAME="4.2.4 Ensure sshd access is configured (Automated)"
DESCRIPTION="This remediation ensures SSH access control is configured using AllowUsers, AllowGroups, DenyUsers, or DenyGroups directives."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH access control configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"

if [ ! -f "$SSHD_CONFIG" ]; then
  echo "ERROR: $SSHD_CONFIG not found"
  exit 1
fi

# Check for existing access control directives
echo "Current SSH access control directives:"
echo ""

has_allowusers=$(grep -Pi '^\s*AllowUsers\s+\S+' "$SSHD_CONFIG" || true)
has_allowgroups=$(grep -Pi '^\s*AllowGroups\s+\S+' "$SSHD_CONFIG" || true)
has_denyusers=$(grep -Pi '^\s*DenyUsers\s+\S+' "$SSHD_CONFIG" || true)
has_denygroups=$(grep -Pi '^\s*DenyGroups\s+\S+' "$SSHD_CONFIG" || true)

if [ -n "$has_allowusers" ]; then
  echo "AllowUsers directive found:"
  echo "$has_allowusers"
fi

if [ -n "$has_allowgroups" ]; then
  echo "AllowGroups directive found:"
  echo "$has_allowgroups"
fi

if [ -n "$has_denyusers" ]; then
  echo "DenyUsers directive found:"
  echo "$has_denyusers"
fi

if [ -n "$has_denygroups" ]; then
  echo "DenyGroups directive found:"
  echo "$has_denygroups"
fi

if [ -z "$has_allowusers" ] && [ -z "$has_allowgroups" ] && [ -z "$has_denyusers" ] && [ -z "$has_denygroups" ]; then
  echo "WARNING: No SSH access control directives found"
  echo ""
  echo "==================================================================="
  echo "MANUAL CONFIGURATION REQUIRED"
  echo "==================================================================="
  echo ""
  echo "This item requires site-specific configuration."
  echo "You must manually edit $SSHD_CONFIG and add one or more of:"
  echo ""
  echo "  AllowUsers <userlist>   # Whitelist specific users"
  echo "  AllowGroups <grouplist> # Whitelist specific groups"
  echo "  DenyUsers <userlist>    # Blacklist specific users"
  echo "  DenyGroups <grouplist>  # Blacklist specific groups"
  echo ""
  echo "Example configurations:"
  echo "  AllowUsers root admin sshuser"
  echo "  AllowGroups sshusers wheel"
  echo "  DenyUsers guest nobody"
  echo ""
  echo "After making changes, run:"
  echo "  systemctl reload-or-try-restart sshd.service"
  echo ""
  echo "==================================================================="
  exit 0
fi

echo ""
echo "SSH access control is configured."
echo ""

# Verify and enforce final status with PROOFS
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

final_status_pass=true

echo ""
echo "1. VERIFYING SSH ACCESS CONTROL DIRECTIVES:"
echo "------------------------------------------"

access_control_configured=false

if [ -n "$has_allowusers" ]; then
  echo "PASS: AllowUsers directive is configured"
  echo "PROOF:"
  echo "$has_allowusers"
  access_control_configured=true
fi

if [ -n "$has_allowgroups" ]; then
  echo "PASS: AllowGroups directive is configured"
  echo "PROOF:"
  echo "$has_allowgroups"
  access_control_configured=true
fi

if [ -n "$has_denyusers" ]; then
  echo "PASS: DenyUsers directive is configured"
  echo "PROOF:"
  echo "$has_denyusers"
  access_control_configured=true
fi

if [ -n "$has_denygroups" ]; then
  echo "PASS: DenyGroups directive is configured"
  echo "PROOF:"
  echo "$has_denygroups"
  access_control_configured=true
fi

if [ "$access_control_configured" = false ]; then
  echo "FAIL: No SSH access control directives configured"
  final_status_pass=false
fi

echo ""
echo "2. VERIFYING SSHD CONFIGURATION SYNTAX:"
echo "---------------------------------------"

if sshd -t 2>&1; then
  echo "PASS: SSHD configuration syntax is valid"
else
  echo "FAIL: SSHD configuration has syntax errors"
  echo "PROOF:"
  sshd -t 2>&1 || true
  final_status_pass=false
fi

echo ""
echo "3. RELOADING SSHD SERVICE:"
echo "-------------------------"

if systemctl reload-or-try-restart sshd.service 2>&1; then
  echo "PASS: SSHD service reloaded successfully"
else
  echo "FAIL: Failed to reload SSHD service"
  final_status_pass=false
fi

echo ""
echo "4. VERIFYING SSHD SERVICE STATUS:"
echo "---------------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "PASS: SSHD service is active"
  echo "PROOF:"
  systemctl status sshd.service --no-pager -l | head -10
else
  echo "FAIL: SSHD service is not active"
  final_status_pass=false
fi

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
