#!/usr/bin/env bash
# Script: 4.1.1.5.sh
# Item: 4.1.1.5 Ensure permissions on /etc/cron.weekly are configured (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures that /etc/cron.weekly is owned by root:root and only accessible by root (permissions 700).

set -euo pipefail

SCRIPT_NAME="4.1.1.5.sh"
ITEM_NAME="4.1.1.5 Ensure permissions on /etc/cron.weekly are configured (Automated)"
DESCRIPTION="This remediation ensures that /etc/cron.weekly is owned by root:root and only accessible by root (permissions 700)."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

if [ ! -d "/etc/cron.weekly" ]; then
  echo "FAIL: /etc/cron.weekly does not exist."
  exit 1
fi

chown root:root /etc/cron.weekly
chmod 700 /etc/cron.weekly

# Verification
owner=$(stat -c '%U' /etc/cron.weekly)
group=$(stat -c '%G' /etc/cron.weekly)
perms=$(stat -c '%a' /etc/cron.weekly)

echo "Directory information:"
ls -ld /etc/cron.weekly

echo
if [ "$owner" = "root" ] && [ "$group" = "root" ] && [ "$perms" = "700" ]; then
  echo "SUCCESS: /etc/cron.weekly permissions and ownership correctly set."
else
  echo "FAIL: /etc/cron.weekly permissions or ownership incorrect."
fi

echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
