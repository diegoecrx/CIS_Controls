#!/usr/bin/env bash
# Script: 4.1.1.3.sh
# Item: 4.1.1.3 Ensure permissions on /etc/cron.hourly are configured (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures that /etc/cron.hourly is owned by root:root and permissions are set to 700 (rwx------) to restrict access to root only.

set -euo pipefail

SCRIPT_NAME="4.1.1.3.sh"
ITEM_NAME="4.1.1.3 Ensure permissions on /etc/cron.hourly are configured (Automated)"
DESCRIPTION="This remediation ensures that /etc/cron.hourly is owned by root:root and permissions are set to 700 (rwx------) to restrict access to root only."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

if [ ! -d "/etc/cron.hourly" ]; then
  echo "FAIL: /etc/cron.hourly does not exist."
  exit 1
fi

echo "Setting ownership and permissions on /etc/cron.hourly to root:root and 700..."
# The remediation command is 'og-rwx', which removes read/write/execute for group and others.
# This sets permissions to 700 to ensure only root has access.
chown root:root /etc/cron.hourly
chmod 700 /etc/cron.hourly

# Verification
echo "Verifying permissions..."
owner=$(stat -c '%U' /etc/cron.hourly)
group=$(stat -c '%G' /etc/cron.hourly)
perms=$(stat -c '%a' /etc/cron.hourly)

echo
echo "Current State:"
ls -ld /etc/cron.hourly
echo

if [ "$owner" = "root" ] && [ "$group" = "root" ] && [ "$perms" = "700" ]; then
  echo "SUCCESS: /etc/cron.hourly permissions and ownership correctly set to rwx------ (700)."
else
  echo "FAIL: /etc/cron.hourly permissions or ownership incorrect."
  echo "Expected: root:root 700"
  echo "Actual: $owner:$group $perms"
fi

echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
