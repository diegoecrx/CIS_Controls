#!/usr/bin/env bash

# Script: 4.1.1.6.sh
# Item: 4.1.1.6 Ensure permissions on /etc/cron.monthly are configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.1.1.6.sh"
ITEM_NAME="4.1.1.6 Ensure permissions on /etc/cron.monthly are configured (Automated)"
DESCRIPTION="This remediation ensures /etc/cron.monthly has correct ownership and permissions configured."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current /etc/cron.monthly permissions..."
echo ""

# Display current permissions
if [ ! -d "/etc/cron.monthly" ]; then
  echo "WARNING: /etc/cron.monthly does not exist"
  echo "Creating directory..."
  mkdir -p /etc/cron.monthly
fi

echo "Current permissions:"
ls -ld /etc/cron.monthly
stat /etc/cron.monthly
echo ""

echo "Applying remediation..."

# Apply ownership and permissions
echo " - Setting ownership to root:root"
chown root:root /etc/cron.monthly

echo " - Setting permissions to 700 (og-rwx)"
chmod og-rwx /etc/cron.monthly

echo " - SUCCESS: Applied ownership and permissions"
echo ""

echo "Remediation of /etc/cron.monthly permissions complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

# Final verification and enforcement
final_status_pass=true

# PROOF 1: Verify ownership is root:root
echo ""
echo "1. VERIFYING OWNERSHIP IS root:root:"
echo "-----------------------------------"
current_owner=$(stat -c '%U' /etc/cron.monthly)
current_group=$(stat -c '%G' /etc/cron.monthly)

if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
  echo "PASS: /etc/cron.monthly is owned by root:root"
  echo "PROOF (stat output):"
  stat /etc/cron.monthly | grep -E '(Uid|Gid)'
else
  echo "FAIL: /etc/cron.monthly ownership is NOT root:root - fixing now"
  chown root:root /etc/cron.monthly
  
  # Verify after fixing
  current_owner=$(stat -c '%U' /etc/cron.monthly)
  current_group=$(stat -c '%G' /etc/cron.monthly)
  
  if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
    echo "PASS: /etc/cron.monthly ownership corrected to root:root"
    echo "PROOF (stat output):"
    stat /etc/cron.monthly | grep -E '(Uid|Gid)'
  else
    echo "FAIL: Could not set ownership to root:root"
    final_status_pass=false
  fi
fi

# PROOF 2: Verify permissions are 700
echo ""
echo "2. VERIFYING PERMISSIONS ARE 700:"
echo "--------------------------------"
current_perms=$(stat -c '%a' /etc/cron.monthly)

if [ "$current_perms" = "700" ]; then
  echo "PASS: /etc/cron.monthly has permissions 700"
  echo "PROOF (stat output):"
  stat -c 'Access: (%a/%A)' /etc/cron.monthly
else
  echo "FAIL: /etc/cron.monthly permissions are $current_perms (expected 700) - fixing now"
  chmod 700 /etc/cron.monthly
  
  # Verify after fixing
  current_perms=$(stat -c '%a' /etc/cron.monthly)
  
  if [ "$current_perms" = "700" ]; then
    echo "PASS: /etc/cron.monthly permissions corrected to 700"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/cron.monthly
  else
    echo "FAIL: Could not set permissions to 700"
    final_status_pass=false
  fi
fi

# PROOF 3: Verify complete stat output
echo ""
echo "3. VERIFYING COMPLETE FILE STATUS:"
echo "---------------------------------"
echo "PROOF (full stat output):"
stat /etc/cron.monthly

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
