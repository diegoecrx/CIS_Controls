#!/usr/bin/env bash
# Script: 4.1.1.4.sh
# Item: 4.1.1.4 Ensure permissions on /etc/cron.daily are configured (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures that /etc/cron.daily is owned by root:root and only accessible by root (permissions 700).

set -euo pipefail

SCRIPT_NAME="4.1.1.4.sh"
ITEM_NAME="4.1.1.4 Ensure permissions on /etc/cron.daily are configured (Automated)"
DESCRIPTION="This remediation ensures that /etc/cron.daily is owned by root:root and only accessible by root (permissions 700)."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

if [ ! -d "/etc/cron.daily" ]; then
  echo "FAIL: /etc/cron.daily does not exist."
  exit 1
fi

chown root:root /etc/cron.daily
chmod 700 /etc/cron.daily

# Verification
owner=$(stat -c '%U' /etc/cron.daily)
group=$(stat -c '%G' /etc/cron.daily)
perms=$(stat -c '%a' /etc/cron.daily)

echo "Directory information:"
ls -ld /etc/cron.daily

echo
if [ "$owner" = "root" ] && [ "$group" = "root" ] && [ "$perms" = "700" ]; then
  echo "SUCCESS: /etc/cron.daily permissions and ownership correctly set."
else
  echo "FAIL: /etc/cron.daily permissions or ownership incorrect."
fi

echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
