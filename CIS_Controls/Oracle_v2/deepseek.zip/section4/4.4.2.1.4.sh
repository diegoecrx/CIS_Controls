#!/usr/bin/env bash
# Script: 4.4.2.1.4.sh
# Item: 4.4.2.1.4 Ensure password failed attempts lockout includes root account (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.1.4.sh"
ITEM_NAME="4.4.2.1.4 Ensure password failed attempts lockout includes root account (Automated)"
DESCRIPTION="This remediation ensures password failed attempts lockout includes root account in PAM files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check PAM file
check_pam_file() {
    local file="$1"
    echo "Checking $file..."
    preauth=$(grep -E '^auth\s+required\s+pam_faillock.so\s+preauth\s+silent\s+audit\s+deny=5\s+unlock_time=900\s+even_deny_root' "$file" || true)
    authfail=$(grep -E '^auth\s+\[default=die\]\s+pam_faillock.so\s+authfail\s+audit\s+deny=5\s+unlock_time=900\s+even_deny_root' "$file" || true)
    if [ -n "$preauth" ] && [ -n "$authfail" ]; then
        echo "PASS: even_deny_root present"
        echo "PROOF (preauth): $preauth"
        echo "PROOF (authfail): $authfail"
        return 0
    else
        echo "FAIL: even_deny_root missing"
        echo "PROOF (preauth): $preauth"
        echo "PROOF (authfail): $authfail"
        return 1
    fi
}
# Function to fix PAM file
fix_pam_file() {
    local file="$1"
    echo "Fixing $file..."
    # Backup
    cp "$file" "$file.bak.$(date +%Y%m%d)"
    # Update preauth
    sed -i '/pam_faillock.so preauth/s/$/ even_deny_root/' "$file"
    # Update authfail
    sed -i '/pam_faillock.so authfail/s/$/ even_deny_root/' "$file"
    echo " - Fixed $file"
}
# Main remediation
{
    files=("/etc/pam.d/system-auth" "/etc/pam.d/password-auth")
    need_fix=false
    for file in "${files[@]}"; do
        if ! check_pam_file "$file"; then
            need_fix=true
        fi
    done
    if [ "$need_fix" = false ]; then
        echo "No remediation needed"
    else
        for file in "${files[@]}"; do
            fix_pam_file "$file"
        done
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    all_pass=true
    for file in "${files[@]}"; do
        if ! check_pam_file "$file"; then
            all_pass=false
        fi
    done
    if [ "$all_pass" = true ]; then
        echo "SUCCESS: Lockout includes root"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="