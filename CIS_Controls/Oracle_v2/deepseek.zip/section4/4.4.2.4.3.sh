#!/usr/bin/env bash
# Script: 4.4.2.4.3.sh
# Item: 4.4.2.4.3 Ensure pam_unix includes a strong password hashing algorithm (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.4.3.sh"
ITEM_NAME="4.4.2.4.3 Ensure pam_unix includes a strong password hashing algorithm (Automated)"
DESCRIPTION="This remediation ensures pam_unix uses sha512 and removes weak hashing algorithms."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check PAM files for sha512 and weak algorithms
check_pam_files() {
    echo "Checking PAM files for sha512 and weak algorithms on pam_unix lines..."
    fail=false
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo "Checking $file..."
        unix_password_line=$(grep '^password.*pam_unix.so' "$file" || true)
        if [ -z "$unix_password_line" ]; then
            echo "FAIL: No password pam_unix.so line found in $file"
            echo "PROOF: No password pam_unix.so line"
            fail=true
        else
            if echo "$unix_password_line" | grep -q 'sha512'; then
                echo "PASS: sha512 present on password pam_unix line in $file"
            else
                echo "FAIL: sha512 missing on password pam_unix line in $file"
                fail=true
            fi
            if echo "$unix_password_line" | grep -qE '(md5|bigcrypt|sha256|blowfish)'; then
                echo "FAIL: Weak algorithm found on password pam_unix line in $file"
                echo "PROOF: $unix_password_line"
                fail=true
            else
                echo "PASS: No weak algorithms on password pam_unix line"
                echo "PROOF: $unix_password_line"
            fi
        fi
    done
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix PAM files
fix_pam_files() {
    echo "Fixing PAM files..."
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo " - Processing $file"
        # Remove weak algorithms from password pam_unix line
        sed -ri '/^password.*pam_unix.so/ s/\s+(md5|bigcrypt|sha256|blowfish)\b//g' "$file"
        echo "   - Removed weak algorithms from password pam_unix line"
        # Add sha512 if not present on password pam_unix line
        if grep -q '^password.*pam_unix.so' "$file"; then
            if ! grep -q '^password.*pam_unix.so.*sha512' "$file"; then
                sed -ri '/^password.*pam_unix.so/ s/pam_unix.so/pam_unix.so sha512/' "$file"
                echo "   - Added sha512 to password pam_unix line"
            else
                echo "   - sha512 already present"
            fi
        fi
    done
}
# Main remediation
{
    pam_ok=true
    if ! check_pam_files; then
        pam_ok=false
    fi
    if [ "$pam_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_pam_files
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_pam_files; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: pam_unix includes sha512 and no weak algorithms"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
