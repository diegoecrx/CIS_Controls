#!/usr/bin/env bash
# Script: 4.4.2.4.1.sh
# Item: 4.4.2.4.1 Ensure pam_unix does not include nullok (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.4.1.sh"
ITEM_NAME="4.4.2.4.1 Ensure pam_unix does not include nullok (Automated)"
DESCRIPTION="This remediation ensures pam_unix lines in PAM files do not include the nullok option."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check PAM files for nullok on pam_unix lines
check_pam_files() {
    echo "Checking PAM files for nullok on pam_unix lines..."
    fail=false
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo "Checking $file..."
        unix_lines=$(grep 'pam_unix.so' "$file" || true)
        if [ -z "$unix_lines" ]; then
            echo "FAIL: No pam_unix.so lines found in $file"
            echo "PROOF: No pam_unix.so lines"
            fail=true
        else
            if echo "$unix_lines" | grep -q 'nullok'; then
                echo "FAIL: nullok found on pam_unix lines in $file"
                echo "PROOF: $unix_lines"
                fail=true
            else
                echo "PASS: No nullok on pam_unix lines in $file"
                echo "PROOF: $unix_lines"
            fi
        fi
    done
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix PAM files
fix_pam_files() {
    echo "Fixing PAM files..."
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo " - Processing $file"
        if grep -q 'pam_unix.so.*nullok' "$file"; then
            sed -ri 's/\s+nullok\b//g' "$file"
            echo "   - Removed nullok from pam_unix lines"
        else
            echo "   - No nullok to remove"
        fi
    done
}
# Main remediation
{
    pam_ok=true
    if ! check_pam_files; then
        pam_ok=false
    fi
    if [ "$pam_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_pam_files
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_pam_files; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: pam_unix does not include nullok"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
