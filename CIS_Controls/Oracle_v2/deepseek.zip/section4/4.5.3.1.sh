#!/usr/bin/env bash
# Script: 4.5.3.1.sh
# Item: 4.5.3.1 Ensure nologin is not listed in /etc/shells (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.3.1.sh"
ITEM_NAME="4.5.3.1 Ensure nologin is not listed in /etc/shells (Automated)"
DESCRIPTION="This remediation ensures nologin is not listed in /etc/shells."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check /etc/shells for nologin
check_shells() {
    echo "Checking /etc/shells..."
    if [ ! -f /etc/shells ]; then
        echo "PASS: /etc/shells does not exist"
        echo "PROOF: File not found"
        return 0
    fi
    
    nologin_lines=$(grep -i 'nologin' /etc/shells || true)
    if [ -z "$nologin_lines" ]; then
        echo "PASS: nologin is not listed in /etc/shells"
        echo "PROOF: No nologin entries found"
        return 0
    else
        echo "FAIL: nologin is listed in /etc/shells"
        echo "PROOF:"
        echo "$nologin_lines"
        return 1
    fi
}
# Function to fix /etc/shells
fix_shells() {
    echo "Fixing /etc/shells..."
    sed -i '/nologin/d' /etc/shells
    echo " - Removed all nologin entries from /etc/shells"
}
# Main remediation
{
    shells_ok=true
    if ! check_shells; then
        shells_ok=false
    fi
    if [ "$shells_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_shells
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_shells; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: nologin is not listed in /etc/shells"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
