#!/usr/bin/env bash
# Script: 4.4.1.2.sh
# Item: 4.4.1.2 Ensure libpwquality is installed (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.1.2.sh"
ITEM_NAME="4.4.1.2 Ensure libpwquality is installed (Automated)"
DESCRIPTION="This remediation ensures libpwquality is installed using yum."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking if libpwquality is installed..."
    if rpm -q libpwquality >/dev/null 2>&1; then
        echo "PASS: libpwquality is installed"
        echo "PROOF: $(rpm -q libpwquality)"
        return 0
    else
        echo "FAIL: libpwquality is not installed"
        echo "PROOF: rpm -q libpwquality returned not installed"
        return 1
    fi
}
# Function to install
install_libpwquality() {
    echo "Installing libpwquality..."
    yum install -y libpwquality >/dev/null 2>&1
    echo " - Installed libpwquality"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        install_libpwquality
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: libpwquality installed"
    else
        echo "FAIL: libpwquality not installed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="