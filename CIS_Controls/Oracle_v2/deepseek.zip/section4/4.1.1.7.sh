#!/usr/bin/env bash

# Script: 4.1.1.7.sh
# Item: 4.1.1.7 Ensure permissions on /etc/cron.d are configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.1.1.7.sh"
ITEM_NAME="4.1.1.7 Ensure permissions on /etc/cron.d are configured (Automated)"
DESCRIPTION="This remediation ensures /etc/cron.d has correct ownership and permissions configured."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current /etc/cron.d permissions..."
echo ""

# Display current permissions
if [ ! -d "/etc/cron.d" ]; then
  echo "WARNING: /etc/cron.d does not exist"
  echo "Creating directory..."
  mkdir -p /etc/cron.d
fi

echo "Current permissions:"
ls -ld /etc/cron.d
stat /etc/cron.d
echo ""

echo "Applying remediation..."

# Apply ownership and permissions
echo " - Setting ownership to root:root"
chown root:root /etc/cron.d

echo " - Setting permissions to 700 (og-rwx)"
chmod og-rwx /etc/cron.d

echo " - SUCCESS: Applied ownership and permissions"
echo ""

echo "Remediation of /etc/cron.d permissions complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

# Final verification and enforcement
final_status_pass=true

# PROOF 1: Verify ownership is root:root
echo ""
echo "1. VERIFYING OWNERSHIP IS root:root:"
echo "-----------------------------------"
current_owner=$(stat -c '%U' /etc/cron.d)
current_group=$(stat -c '%G' /etc/cron.d)

if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
  echo "PASS: /etc/cron.d is owned by root:root"
  echo "PROOF (stat output):"
  stat /etc/cron.d | grep -E '(Uid|Gid)'
else
  echo "FAIL: /etc/cron.d ownership is NOT root:root - fixing now"
  chown root:root /etc/cron.d
  
  # Verify after fixing
  current_owner=$(stat -c '%U' /etc/cron.d)
  current_group=$(stat -c '%G' /etc/cron.d)
  
  if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
    echo "PASS: /etc/cron.d ownership corrected to root:root"
    echo "PROOF (stat output):"
    stat /etc/cron.d | grep -E '(Uid|Gid)'
  else
    echo "FAIL: Could not set ownership to root:root"
    final_status_pass=false
  fi
fi

# PROOF 2: Verify permissions are 700
echo ""
echo "2. VERIFYING PERMISSIONS ARE 700:"
echo "--------------------------------"
current_perms=$(stat -c '%a' /etc/cron.d)

if [ "$current_perms" = "700" ]; then
  echo "PASS: /etc/cron.d has permissions 700"
  echo "PROOF (stat output):"
  stat -c 'Access: (%a/%A)' /etc/cron.d
else
  echo "FAIL: /etc/cron.d permissions are $current_perms (expected 700) - fixing now"
  chmod 700 /etc/cron.d
  
  # Verify after fixing
  current_perms=$(stat -c '%a' /etc/cron.d)
  
  if [ "$current_perms" = "700" ]; then
    echo "PASS: /etc/cron.d permissions corrected to 700"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/cron.d
  else
    echo "FAIL: Could not set permissions to 700"
    final_status_pass=false
  fi
fi

# PROOF 3: Verify complete stat output
echo ""
echo "3. VERIFYING COMPLETE FILE STATUS:"
echo "---------------------------------"
echo "PROOF (full stat output):"
stat /etc/cron.d

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
