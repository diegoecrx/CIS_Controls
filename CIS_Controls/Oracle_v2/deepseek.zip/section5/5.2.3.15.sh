#!/usr/bin/env bash
# Script: 5.2.3.15.sh
# Item: 5.2.3.15 Ensure successful and unsuccessful attempts to use the chcon command are recorded (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.15.sh"
ITEM_NAME="5.2.3.15 Ensure successful and unsuccessful attempts to use the chcon command are recorded (Automated)"
DESCRIPTION="This remediation ensures successful and unsuccessful attempts to use the chcon command are recorded by configuring audit rules for the chcon binary."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking chcon command audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    # Find chcon binary path
    chcon_path=$(which chcon 2>/dev/null || echo "/usr/bin/chcon")
    
    # Check if chcon exists
    if [ ! -x "$chcon_path" ]; then
        echo "PASS: chcon command not found on system"
        echo "PROOF: chcon binary not present at $chcon_path"
        return 0
    fi
    
    # Check for chcon audit rules in running configuration
    if ! auditctl -l | grep -q "\-a always,exit \-F path=$chcon_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng"; then
        echo "FAIL: chcon audit rules not found in running configuration"
        echo "PROOF: Required audit rule for $chcon_path not present in auditctl -l output"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "\-a always,exit \-F path=$chcon_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng" /etc/audit/rules.d/ >/dev/null 2>&1; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: chcon audit rules not found in configuration files"
        echo "PROOF: Required audit rule for $chcon_path not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: chcon command audit rules properly configured"
    echo "PROOF: Audit rule for chcon command found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_chcon_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    echo " - Using UID_MIN value: $UID_MIN"
    
    # Find chcon binary path
    chcon_path=$(which chcon 2>/dev/null || echo "/usr/bin/chcon")
    
    # Check if chcon exists
    if [ ! -x "$chcon_path" ]; then
        echo " - chcon command not found on system, no audit rule needed"
        return
    fi
    
    echo " - Found chcon command at: $chcon_path"
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "\-a always,exit \-F path=$chcon_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng" /etc/audit/rules.d/ >/dev/null 2>&1; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating chcon audit rules in /etc/audit/rules.d/50-perm_chng.rules"
        cat > /etc/audit/rules.d/50-perm_chng.rules << EOF
## Monitor successful and unsuccessful attempts to use the chcon command
-a always,exit -F path=${chcon_path} -F perm=x -F auid>=${UID_MIN} -F auid!=unset -k perm_chng
EOF
    else
        echo " - Chcon audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - chcon audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_chcon_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: chcon command audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="