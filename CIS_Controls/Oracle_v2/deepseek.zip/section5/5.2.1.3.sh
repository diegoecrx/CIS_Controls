#!/usr/bin/env bash
# Script: 5.2.1.3.sh
# Item: 5.2.1.3 Ensure audit_backlog_limit is sufficient (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.1.3.sh"
ITEM_NAME="5.2.1.3 Ensure audit_backlog_limit is sufficient (Automated)"
DESCRIPTION="This remediation ensures audit_backlog_limit is set to a sufficient value in kernel parameters."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit_backlog_limit kernel parameter configuration..."
    
    # Recommended minimum backlog limit
    min_backlog_limit=8192
    
    # Check current kernel command line
    current_backlog=""
    if grep -q "audit_backlog_limit=" /proc/cmdline 2>/dev/null; then
        current_backlog=$(grep -o 'audit_backlog_limit=[0-9]*' /proc/cmdline | cut -d= -f2)
        cmdline_has_backlog=true
    else
        cmdline_has_backlog=false
    fi
    
    # Check grub configuration
    grub_has_backlog=false
    grub_backlog=""
    if [ -f /etc/default/grub ]; then
        if grep -q 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub 2>/dev/null; then
            grub_backlog=$(grep 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub | grep -o 'audit_backlog_limit=[0-9]*' | cut -d= -f2)
            grub_has_backlog=true
        fi
    fi
    
    # Check if current kernel has sufficient audit_backlog_limit
    if [ "$cmdline_has_backlog" = false ]; then
        echo "FAIL: audit_backlog_limit not found in current kernel command line"
        echo "PROOF: /proc/cmdline does not contain audit_backlog_limit"
        return 1
    fi
    
    if [ -n "$current_backlog" ] && [ "$current_backlog" -lt "$min_backlog_limit" ]; then
        echo "FAIL: audit_backlog_limit is insufficient in current kernel"
        echo "PROOF: Current audit_backlog_limit=$current_backlog is less than recommended minimum $min_backlog_limit"
        return 1
    fi
    
    # Check if grub configuration has sufficient audit_backlog_limit
    if [ "$grub_has_backlog" = false ]; then
        echo "FAIL: audit_backlog_limit not configured in grub"
        echo "PROOF: /etc/default/grub GRUB_CMDLINE_LINUX does not contain audit_backlog_limit"
        return 1
    fi
    
    if [ -n "$grub_backlog" ] && [ "$grub_backlog" -lt "$min_backlog_limit" ]; then
        echo "FAIL: audit_backlog_limit is insufficient in grub configuration"
        echo "PROOF: Grub audit_backlog_limit=$grub_backlog is less than recommended minimum $min_backlog_limit"
        return 1
    fi
    
    echo "PASS: audit_backlog_limit properly configured"
    echo "PROOF: audit_backlog_limit=$current_backlog found in both current kernel and grub configuration"
    return 0
}
# Function to fix
fix_audit_backlog_limit() {
    echo "Applying fix..."
    
    # Set recommended backlog limit
    backlog_limit=8192
    
    # Update kernel parameters using grubby
    echo " - Updating kernel parameters with grubby (audit_backlog_limit=$backlog_limit)"
    grubby --update-kernel ALL --args "audit_backlog_limit=$backlog_limit"
    
    # Update /etc/default/grub
    if [ -f /etc/default/grub ]; then
        echo " - Updating /etc/default/grub"
        
        # Check if GRUB_CMDLINE_LINUX exists
        if grep -q '^GRUB_CMDLINE_LINUX=' /etc/default/grub; then
            # Check if audit_backlog_limit is already present
            if grep -q 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub; then
                # Update existing audit_backlog_limit
                sed -i "s/audit_backlog_limit=[0-9]*/audit_backlog_limit=$backlog_limit/" /etc/default/grub
            else
                # Add audit_backlog_limit to existing GRUB_CMDLINE_LINUX
                sed -i "s/\(GRUB_CMDLINE_LINUX=\"[^\"]*\)\"/\1 audit_backlog_limit=$backlog_limit\"/" /etc/default/grub
            fi
        else
            # Add GRUB_CMDLINE_LINUX with audit_backlog_limit
            echo "GRUB_CMDLINE_LINUX=\"audit_backlog_limit=$backlog_limit\"" >> /etc/default/grub
        fi
    else
        echo " - Creating /etc/default/grub with audit_backlog_limit=$backlog_limit"
        cat > /etc/default/grub << EOF
GRUB_TIMEOUT=5
GRUB_DISTRIBUTOR="\$(sed 's, release .*\$,,g' /etc/system-release)"
GRUB_DEFAULT=saved
GRUB_DISABLE_SUBMENU=true
GRUB_TERMINAL_OUTPUT="console"
GRUB_CMDLINE_LINUX="audit_backlog_limit=$backlog_limit"
GRUB_DISABLE_RECOVERY="true"
EOF
    fi
    
    # Regenerate grub configuration
    echo " - Regenerating grub configuration"
    if [ -f /boot/efi/EFI/oracle/grub.cfg ]; then
        # UEFI system
        grub2-mkconfig -o /boot/efi/EFI/oracle/grub.cfg
    elif [ -f /boot/grub2/grub.cfg ]; then
        # BIOS system
        grub2-mkconfig -o /boot/grub2/grub.cfg
    else
        echo " - Warning: Could not locate grub configuration file"
    fi
    
    echo " - audit_backlog_limit configuration completed"
    echo " - NOTE: A reboot is required for the changes to take effect"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_backlog_limit
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit_backlog_limit properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="