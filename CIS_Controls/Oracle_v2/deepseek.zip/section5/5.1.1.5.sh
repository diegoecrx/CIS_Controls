#!/usr/bin/env bash

# Script: 5.1.1.5.sh
# Item: 5.1.1.5 Ensure logging is configured (Manual)
# Description: "Edit the following lines in the /etc/rsyslog.conf and /etc/rsyslog.d/*.conf files as
# appropriate for your environment.
# Note: The below configuration is shown for example purposes only. Due care should be
# given to how the organization wish to store log data.
# *.emerg :omusrmsg:*
# auth,authpriv.* /var/log/secure
# mail.* -/var/log/mail
# mail.info -/var/log/mail.info
# mail.warning -/var/log/mail.warn
# mail.err /var/log/mail.err
# cron.* /var/log/cron
# *.=warning;*.=err -/var/log/warn
# *.crit /var/log/warn
# *.*;mail.none;news.none -/var/log/messages
# local0,local1.* -/var/log/localmessages
# local2,local3.* -/var/log/localmessages
# local4,local5.* -/var/log/localmessages
# local6,local7.* -/var/log/localmessages
# Run the following command to reload the rsyslogd configuration:
# # systemctl restart rsyslog"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="5.1.1.5.sh"
ITEM_NAME="5.1.1.5 Ensure logging is configured (Manual)"
DESCRIPTION="Ensure comprehensive logging configuration in rsyslog according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current rsyslog logging configuration..."
    echo ""

    # Display current rsyslog configuration status
    echo "Current rsyslog configuration status:"
    echo "====================================="
    
    # Check if rsyslog is installed and running
    if ! command -v rsyslogd >/dev/null 2>&1; then
        echo "rsyslog is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    if ! systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "rsyslog is NOT ACTIVE on this system"
        echo "WARNING: Logging may not be functioning"
    fi
    
    echo "rsyslog service status:"
    echo "-----------------------"
    systemctl is-active rsyslog >/dev/null 2>&1 && echo "ACTIVE" || echo "INACTIVE"
    systemctl is-enabled rsyslog >/dev/null 2>&1 && echo "ENABLED at boot" || echo "DISABLED at boot"
    
    echo ""
    
    # Display main rsyslog configuration
    echo "Main rsyslog configuration (/etc/rsyslog.conf):"
    echo "-----------------------------------------------"
    if [ -f /etc/rsyslog.conf ]; then
        echo "File exists, size: $(wc -l < /etc/rsyslog.conf) lines"
        echo ""
        echo "Current logging rules (filtered):"
        grep -E '^[^#].*\/var\/log' /etc/rsyslog.conf | head -15 || echo "No explicit log file rules found"
    else
        echo "WARNING: /etc/rsyslog.conf does not exist"
    fi
    
    echo ""
    
    # Check for additional configuration files
    echo "Additional rsyslog configuration files:"
    echo "---------------------------------------"
    if [ -d /etc/rsyslog.d ]; then
        config_files=$(find /etc/rsyslog.d -name "*.conf" -type f 2>/dev/null | wc -l)
        echo "Number of additional config files: $config_files"
        if [ "$config_files" -gt 0 ]; then
            echo ""
            echo "Additional configuration files:"
            find /etc/rsyslog.d -name "*.conf" -type f 2>/dev/null | head -5
            echo ""
            echo "Sample rules from additional files:"
            find /etc/rsyslog.d -name "*.conf" -type f -exec grep -h -E '^[^#].*\/var\/log' {} \; 2>/dev/null | head -5 || echo "No log file rules in additional configs"
        fi
    else
        echo "No additional configuration directory (/etc/rsyslog.d)"
    fi
    
    echo ""
    
    # Check if essential log facilities are configured
    echo "Essential log facility configuration:"
    echo "-------------------------------------"
    essential_facilities=("auth" "authpriv" "mail" "cron" "kern" "daemon")
    
    for facility in "${essential_facilities[@]}"; do
        if grep -r -E "^[^#]*${facility}\." /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -q '/var/log'; then
            echo "✓ $facility: CONFIGURED"
        else
            echo "✗ $facility: NOT CONFIGURED"
        fi
    done
    
    echo ""
    
    # Check log file permissions and existence
    echo "Log file status:"
    echo "----------------"
    common_log_files=("/var/log/messages" "/var/log/secure" "/var/log/maillog" "/var/log/cron" "/var/log/syslog")
    
    for log_file in "${common_log_files[@]}"; do
        if [ -f "$log_file" ]; then
            permissions=$(stat -c "%a %U:%G" "$log_file" 2>/dev/null || echo "unknown")
            size=$(du -h "$log_file" 2>/dev/null | cut -f1 || echo "unknown")
            echo "$log_file: EXISTS ($permissions, $size)"
        else
            echo "$log_file: MISSING"
        fi
    done
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_essential_facilities()
    {
        echo " - Checking essential log facility configuration..."
        
        essential_facilities=(
            "auth,authpriv.*"
            "mail.*"
            "cron.*"
            "*.emerg"
            "kern.*"
            "daemon.*"
        )
        
        missing_facilities=()
        
        for facility_rule in "${essential_facilities[@]}"; do
            if ! grep -r -E "^[^#]*${facility_rule}" /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -q '/var/log'; then
                facility_name=$(echo "$facility_rule" | cut -d'.' -f1)
                missing_facilities+=("$facility_name")
                echo " - MISSING: $facility_rule"
            fi
        done
        
        if [ ${#missing_facilities[@]} -eq 0 ]; then
            echo " - SUCCESS: All essential facilities configured"
        else
            echo " - WARNING: Missing configuration for: ${missing_facilities[*]}"
        fi
    }

    check_log_rotation()
    {
        echo " - Checking log rotation configuration..."
        
        if [ -f /etc/logrotate.d/rsyslog ] || [ -f /etc/logrotate.conf ]; then
            echo " - FOUND: Log rotation configuration exists"
            
            # Check if rsyslog logrotate config exists
            if [ -f /etc/logrotate.d/rsyslog ]; then
                echo " - FOUND: /etc/logrotate.d/rsyslog exists"
                rsyslog_rotate_count=$(grep -c 'rotate' /etc/logrotate.d/rsyslog 2>/dev/null || echo "0")
                if [ "$rsyslog_rotate_count" -gt 0 ]; then
                    echo " - SUCCESS: Log rotation configured for rsyslog"
                fi
            fi
        else
            echo " - WARNING: No log rotation configuration found"
        fi
    }

    check_configuration_syntax()
    {
        echo " - Checking rsyslog configuration syntax..."
        
        if command -v rsyslogd >/dev/null 2>&1; then
            if rsyslogd -N 1 >/dev/null 2>&1; then
                echo " - SUCCESS: rsyslog configuration syntax is valid"
            else
                echo " - ERROR: rsyslog configuration syntax validation failed"
                echo " - Run 'rsyslogd -N 1' to see specific errors"
            fi
        else
            echo " - WARNING: Cannot validate syntax - rsyslogd not found"
        fi
    }

    check_log_file_permissions()
    {
        echo " - Checking log file permissions..."
        
        problematic_files=()
        
        # Check common log files
        for log_file in /var/log/messages /var/log/secure /var/log/maillog /var/log/cron /var/log/syslog; do
            if [ -f "$log_file" ]; then
                permissions=$(stat -c "%a" "$log_file" 2>/dev/null)
                owner=$(stat -c "%U" "$log_file" 2>/dev/null)
                
                # Log files should not be world-writable
                if [ "$((permissions & 2))" -ne 0 ]; then
                    echo " - INSECURE: $log_file is world-writable (permissions: $permissions)"
                    problematic_files+=("$log_file")
                fi
                
                # Should typically be owned by root
                if [ "$owner" != "root" ]; then
                    echo " - WARNING: $log_file owned by $owner (should be root)"
                fi
            fi
        done
        
        if [ ${#problematic_files[@]} -eq 0 ]; then
            echo " - SUCCESS: Log file permissions are secure"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing logging configuration remediation guidance..."
        
        echo ""
        echo "LOGGING CONFIGURATION REMEDIATION GUIDANCE:"
        echo "==========================================="
        echo ""
        echo "Configure essential logging facilities in /etc/rsyslog.conf or /etc/rsyslog.d/*.conf:"
        echo ""
        echo "ESSENTIAL FACILITIES CONFIGURATION:"
        echo "-----------------------------------"
        echo "*.emerg :omusrmsg:*"
        echo "auth,authpriv.* /var/log/secure"
        echo "mail.* -/var/log/mail"
        echo "mail.info -/var/log/mail.info"
        echo "mail.warning -/var/log/mail.warn"
        echo "mail.err /var/log/mail.err"
        echo "cron.* /var/log/cron"
        echo "*.=warning;*.=err -/var/log/warn"
        echo "*.crit /var/log/warn"
        echo "*.*;mail.none;news.none -/var/log/messages"
        echo "local0,local1.* -/var/log/localmessages"
        echo "local2,local3.* -/var/log/localmessages"
        echo "local4,local5.* -/var/log/localmessages"
        echo "local6,local7.* -/var/log/localmessages"
        echo ""
        echo "ADDITIONAL CONFIGURATION:"
        echo "-------------------------"
        echo "kern.* /var/log/kern.log"
        echo "daemon.* /var/log/daemon.log"
        echo "user.* /var/log/user.log"
        echo ""
        echo "CONFIGURATION STEPS:"
        echo "--------------------"
        echo "1. Edit /etc/rsyslog.conf or create files in /etc/rsyslog.d/"
        echo "2. Add the appropriate facility rules for your environment"
        echo "3. Validate configuration syntax: rsyslogd -N 1"
        echo "4. Restart rsyslog: systemctl restart rsyslog"
        echo "5. Test logging: logger \"Test message from facility test\""
        echo ""
        echo "SECURE LOG FILE PERMISSIONS:"
        echo "---------------------------"
        echo "chmod 640 /var/log/secure /var/log/mail /var/log/cron /var/log/messages"
        echo "chown root:root /var/log/secure /var/log/mail /var/log/cron /var/log/messages"
        echo ""
        echo "VERIFICATION COMMANDS:"
        echo "---------------------"
        echo "rsyslogd -N 1                      # Validate configuration"
        echo "systemctl status rsyslog           # Check service status"
        echo "logger \"Test message\"             # Test logging"
        echo "tail -f /var/log/messages          # Monitor logs"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking essential log facilities..."
    check_essential_facilities
    remediation_applied=true
    
    echo ""
    echo "Checking log rotation..."
    check_log_rotation
    remediation_applied=true
    
    echo ""
    echo "Checking configuration syntax..."
    check_configuration_syntax
    remediation_applied=true
    
    echo ""
    echo "Checking log file permissions..."
    check_log_file_permissions
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No rsyslog configuration detected"
    fi

    echo ""
    echo "Remediation of logging configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify rsyslog service status
    echo ""
    echo "1. VERIFYING RSYSLOG SERVICE STATUS:"
    echo "------------------------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "PASS: rsyslog service is ACTIVE"
        echo "PROOF (systemctl is-active rsyslog): active"
        echo ""
        echo "Service details:"
        systemctl status rsyslog --no-pager -l 2>/dev/null | head -3
    else
        echo "FAIL: rsyslog service is INACTIVE"
        echo "PROOF (systemctl is-active rsyslog): inactive"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify essential facility configuration
    echo ""
    echo "2. VERIFYING ESSENTIAL FACILITY CONFIGURATION:"
    echo "----------------------------------------------"
    essential_count=0
    essential_facilities=("auth,authpriv" "mail" "cron" "*.emerg" "kern" "daemon")
    
    for facility in "${essential_facilities[@]}"; do
        if grep -r -E "^[^#]*${facility}\..*\/var\/log" /etc/rsyslog.conf /etc/rsyslog.d/ >/dev/null 2>&1; then
            echo "✓ $facility: CONFIGURED"
            ((essential_count++))
            echo "PROOF: $(grep -r -E "^[^#]*${facility}\..*\/var\/log" /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | head -1)"
        else
            echo "✗ $facility: NOT CONFIGURED"
            final_status_pass=false
        fi
    done
    
    echo ""
    echo "Essential facilities configured: $essential_count/${#essential_facilities[@]}"
    
    # PROOF 3: Verify configuration syntax
    echo ""
    echo "3. VERIFYING CONFIGURATION SYNTAX:"
    echo "----------------------------------"
    if command -v rsyslogd >/dev/null 2>&1; then
        if rsyslogd -N 1 >/dev/null 2>&1; then
            echo "PASS: rsyslog configuration syntax is valid"
            echo "PROOF (rsyslogd -N 1): exit code 0"
        else
            echo "FAIL: rsyslog configuration syntax validation failed"
            echo "PROOF (rsyslogd -N 1): non-zero exit code"
            final_status_pass=false
        fi
    else
        echo "INFO: Cannot validate syntax - rsyslogd command not available"
    fi
    
    # PROOF 4: Verify log file existence and permissions
    echo ""
    echo "4. VERIFYING LOG FILE STATUS:"
    echo "-----------------------------"
    log_files_exist=0
    checked_files=0
    
    for log_file in /var/log/messages /var/log/secure /var/log/maillog /var/log/cron /var/log/syslog; do
        if [ -f "$log_file" ]; then
            ((log_files_exist++))
            permissions=$(stat -c "%a" "$log_file" 2>/dev/null || echo "unknown")
            owner=$(stat -c "%U:%G" "$log_file" 2>/dev/null || echo "unknown:unknown")
            echo "✓ $log_file: EXISTS ($permissions, $owner)"
        else
            echo "✗ $log_file: MISSING"
            final_status_pass=false
        fi
        ((checked_files++))
    done
    
    echo ""
    echo "Log files present: $log_files_exist/$checked_files"
    
    # PROOF 5: Test logging functionality
    echo ""
    echo "5. TESTING LOGGING FUNCTIONALITY:"
    echo "---------------------------------"
    test_message="LOGGING-CONFIG-TEST-$(date +%Y%m%d-%H%M%S)-$(hostname)"
    
    if logger "LOGGING-CONFIG-TEST: $test_message" 2>/dev/null; then
        echo "PASS: Test message sent successfully"
        echo "Test message: $test_message"
        
        # Try to find the test message in common log files
        found=false
        for log_file in /var/log/messages /var/log/syslog; do
            if [ -f "$log_file" ] && tail -10 "$log_file" 2>/dev/null | grep -q "$test_message"; then
                echo "PASS: Test message found in $log_file"
                found=true
                break
            fi
        done
        
        if [ "$found" = false ]; then
            echo "INFO: Test message not found in common log files (may be in different location)"
        fi
    else
        echo "WARNING: Could not send test message via logger"
        final_status_pass=false
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review and customize logging configuration for organizational needs"
    echo "• Ensure all critical applications and services are being logged"
    echo "• Verify log rotation and retention policies are appropriate"
    echo "• Test log aggregation and monitoring systems"
    echo "• Ensure sufficient storage capacity for log files"
    echo "• Document logging configuration for audit purposes"
    echo ""
    echo "LOGGING CONFIGURATION COMMANDS:"
    echo "==============================="
    echo ""
    echo "VIEW CURRENT CONFIGURATION:"
    echo "  cat /etc/rsyslog.conf"
    echo "  ls -la /etc/rsyslog.d/"
    echo "  grep -r '/var/log' /etc/rsyslog.conf /etc/rsyslog.d/"
    echo ""
    echo "VALIDATE CONFIGURATION:"
    echo "  rsyslogd -N 1"
    echo "  systemctl restart rsyslog"
    echo ""
    echo "TEST LOGGING:"
    echo "  logger \"Test authentication message\" --priority auth.info"
    echo "  logger \"Test cron message\" --priority cron.info"
    echo "  logger \"Test mail message\" --priority mail.info"
    echo ""
    echo "MONITOR LOGS:"
    echo "  tail -f /var/log/messages"
    echo "  tail -f /var/log/secure"
    echo "  tail -f /var/log/cron"
    echo "  journalctl -f"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Logging configuration verification completed"
        echo "NOTE: Manual review required to customize configuration for organizational needs"
    else
        echo ""
        echo "WARNING: Logging configuration issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="