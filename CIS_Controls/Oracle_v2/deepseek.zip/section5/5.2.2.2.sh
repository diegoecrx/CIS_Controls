#!/usr/bin/env bash
# Script: 5.2.2.2.sh
# Item: 5.2.2.2 Ensure audit logs are not automatically deleted (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.2.2.sh"
ITEM_NAME="5.2.2.2 Ensure audit logs are not automatically deleted (Automated)"
DESCRIPTION="This remediation ensures audit logs are not automatically deleted by setting max_log_file_action to keep_logs."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit logs automatic deletion configuration..."
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Check if max_log_file_action is configured correctly
    if grep -q '^max_log_file_action' /etc/audit/auditd.conf 2>/dev/null; then
        max_log_file_action=$(grep '^max_log_file_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$max_log_file_action" = "keep_logs" ]; then
            echo "PASS: audit logs automatic deletion properly disabled"
            echo "PROOF: max_log_file_action = keep_logs configured in /etc/audit/auditd.conf"
            return 0
        else
            echo "FAIL: max_log_file_action is set to $max_log_file_action instead of keep_logs"
            echo "PROOF: max_log_file_action = $max_log_file_action found in /etc/audit/auditd.conf"
            return 1
        fi
    fi
    
    echo "FAIL: audit logs automatic deletion not configured"
    echo "PROOF: No max_log_file_action setting found in /etc/audit/auditd.conf"
    return 1
}
# Function to fix
fix_audit_logs_deletion() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Check if max_log_file_action is already configured
    if grep -q '^max_log_file_action' /etc/audit/auditd.conf; then
        echo " - Updating existing max_log_file_action setting"
        sed -i 's/^max_log_file_action.*/max_log_file_action = keep_logs/' /etc/audit/auditd.conf
    else
        echo " - Adding max_log_file_action = keep_logs to /etc/audit/auditd.conf"
        echo "max_log_file_action = keep_logs" >> /etc/audit/auditd.conf
    fi
    
    # Restart auditd service to apply changes (if running)
    if systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Restarting auditd service to apply changes"
        service auditd restart 2>/dev/null || systemctl restart auditd
    fi
    
    echo " - audit logs deletion configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_logs_deletion
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit logs automatic deletion properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="