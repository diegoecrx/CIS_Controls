#!/usr/bin/env bash
# Script: 5.1.4.sh
# Item: 5.1.4 Ensure all logfiles have appropriate access configured (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.4.sh"
ITEM_NAME="5.1.4 Ensure all logfiles have appropriate access configured (Automated)"
DESCRIPTION="This remediation ensures all logfiles have appropriate access configured."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking logfile permissions and ownership..."
    
    l_uidmin="$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"
    l_issues_found=""
    
    # Check files in /var/log with potential issues
    while IFS= read -r -d $'\0' l_file; do
        if [ -e "$l_file" ]; then
            l_stat="$(stat -Lc '%n^%#a^%U^%u^%G^%g' "$l_file")"
            IFS="^" read -r l_fname l_mode l_user l_uid l_group l_gid <<< "$l_stat"
            l_bname="$(basename "$l_fname")"
            
            case "$l_bname" in
                lastlog|lastlog.*|wtmp|wtmp.*|wtmp-*|btmp|btmp.*|btmp-*|README)
                    perm_mask='0113'
                    l_auser="root"
                    l_agroup="(root|utmp)"
                    ;;
                secure|auth.log|syslog|messages)
                    perm_mask='0137'
                    l_auser="(root|syslog)"
                    l_agroup="(root|adm)"
                    ;;
                SSSD|sssd)
                    perm_mask='0117'
                    l_auser="(root|SSSD)"
                    l_agroup="(root|SSSD)"
                    ;;
                gdm|gdm3)
                    perm_mask='0117'
                    l_auser="root"
                    l_agroup="(root|gdm|gdm3)"
                    ;;
                *.journal|*.journal~)
                    perm_mask='0137'
                    l_auser="root"
                    l_agroup="(root|systemd-journal)"
                    ;;
                *)
                    perm_mask='0137'
                    l_auser="(root|syslog)"
                    l_agroup="(root|adm)"
                    ;;
            esac
            
            # Check permissions
            if [ $(( $l_mode & $perm_mask )) -gt 0 ]; then
                l_issues_found="${l_issues_found}permission:$l_fname "
            fi
            
            # Check ownership
            if [[ ! "$l_user" =~ $l_auser ]]; then
                l_issues_found="${l_issues_found}owner:$l_fname "
            fi
            
            # Check group ownership
            if [[ ! "$l_group" =~ $l_agroup ]]; then
                l_issues_found="${l_issues_found}group:$l_fname "
            fi
        fi
    done < <(find -L /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0 2>/dev/null)
    
    if [ -n "$l_issues_found" ]; then
        echo "FAIL: Logfiles with inappropriate access found"
        echo "PROOF: Issues found: $l_issues_found"
        return 1
    fi
    
    echo "PASS: All logfiles have appropriate access configured"
    echo "PROOF: No permission or ownership issues found in /var/log"
    return 0
}
# Function to fix
fix_logfile_access() {
    echo "Applying fix..."
    
    l_op2="" l_output2=""
    l_uidmin="$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"
    
    file_test_fix() {
        l_op2=""
        l_fuser="root"
        l_fgroup="root"
        
        if [ $(( $l_mode & $perm_mask )) -gt 0 ]; then
            l_op2="$l_op2\n - Mode: \"$l_mode\" should be \"$maxperm\" or more restrictive\n - Removing excess permissions"
            chmod "$l_rperms" "$l_fname"
        fi
        
        if [[ ! "$l_user" =~ $l_auser ]]; then
            l_op2="$l_op2\n - Owned by: \"$l_user\" and should be owned by \"${l_auser//|/ or }\"\n - Changing ownership to: \"$l_fuser\""
            chown "$l_fuser" "$l_fname"
        fi
        
        if [[ ! "$l_group" =~ $l_agroup ]]; then
            l_op2="$l_op2\n - Group owned by: \"$l_group\" and should be group owned by \"${l_agroup//|/ or }\"\n - Changing group ownership to: \"$l_fgroup\""
            chgrp "$l_fgroup" "$l_fname"
        fi
        
        [ -n "$l_op2" ] && l_output2="$l_output2\n - File: \"$l_fname\" is:$l_op2\n"
    }
    
    unset a_file && a_file=()
    
    # Create array with stat of files that could possibly fail one of the audits
    while IFS= read -r -d $'\0' l_file; do
        [ -e "$l_file" ] && a_file+=("$(stat -Lc '%n^%#a^%U^%u^%G^%g' "$l_file")")
    done < <(find -L /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0 2>/dev/null)
    
    while IFS="^" read -r l_fname l_mode l_user l_uid l_group l_gid; do
        l_bname="$(basename "$l_fname")"
        case "$l_bname" in
            lastlog|lastlog.*|wtmp|wtmp.*|wtmp-*|btmp|btmp.*|btmp-*|README)
                perm_mask='0113'
                maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
                l_rperms="ug-x,o-wx"
                l_auser="root"
                l_agroup="(root|utmp)"
                file_test_fix
                ;;
            secure|auth.log|syslog|messages)
                perm_mask='0137'
                maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
                l_rperms="u-x,g-wx,o-rwx"
                l_auser="(root|syslog)"
                l_agroup="(root|adm)"
                file_test_fix
                ;;
            SSSD|sssd)
                perm_mask='0117'
                maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
                l_rperms="ug-x,o-rwx"
                l_auser="(root|SSSD)"
                l_agroup="(root|SSSD)"
                file_test_fix
                ;;
            gdm|gdm3)
                perm_mask='0117'
                l_rperms="ug-x,o-rwx"
                maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
                l_auser="root"
                l_agroup="(root|gdm|gdm3)"
                file_test_fix
                ;;
            *.journal|*.journal~)
                perm_mask='0137'
                maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
                l_rperms="u-x,g-wx,o-rwx"
                l_auser="root"
                l_agroup="(root|systemd-journal)"
                file_test_fix
                ;;
            *)
                perm_mask='0137'
                maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
                l_rperms="u-x,g-wx,o-rwx"
                l_auser="(root|syslog)"
                l_agroup="(root|adm)"
                if [ "$l_uid" -lt "$l_uidmin" ] && [ -z "$(awk -v grp="$l_group" -F: '$1==grp {print $4}' /etc/group)" ]; then
                    if [[ ! "$l_user" =~ $l_auser ]]; then
                        l_auser="(root|syslog|$l_user)"
                    fi
                    if [[ ! "$l_group" =~ $l_agroup ]]; then
                        l_tst=""
                        while l_out3="" read -r l_duid; do
                            [ "$l_duid" -ge "$l_uidmin" ] && l_tst=failed
                        done <<< "$(awk -F: '$4=='"$l_gid"' {print $3}' /etc/passwd)"
                        [ "$l_tst" != "failed" ] && l_agroup="(root|adm|$l_group)"
                    fi
                fi
                file_test_fix
                ;;
        esac
    done <<< "$(printf '%s\n' "${a_file[@]}")"
    
    unset a_file
    
    # Report results
    if [ -z "$l_output2" ]; then
        echo " - All files in /var/log/ have appropriate permissions and ownership"
        echo " - No changes required"
    else
        echo -e " - Changes made:$l_output2"
    fi
    
    echo " - Logfile access configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_logfile_access
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: All logfiles have appropriate access configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="