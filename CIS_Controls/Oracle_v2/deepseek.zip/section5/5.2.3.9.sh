#!/usr/bin/env bash
# Script: 5.2.3.9.sh
# Item: 5.2.3.9 Ensure discretionary access control permission modification events are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.9.sh"
ITEM_NAME="5.2.3.9 Ensure discretionary access control permission modification events are collected (Automated)"
DESCRIPTION="This remediation ensures discretionary access control permission modification events are collected by configuring audit rules for permission changes."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking discretionary access control permission modification audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check for perm_mod audit rules in running configuration
    perm_mod_rules_found=true
    
    # Check b64 rules (for 64-bit systems)
    if [[ "$arch" == "x86_64" ]]; then
        # Check chmod rules for b64
        if ! auditctl -l | grep -q "\-a always,exit \-F arch=b64 \-S chmod,fchmod,fchmodat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod"; then
            perm_mod_rules_found=false
        fi
        # Check chown rules for b64
        if ! auditctl -l | grep -q "\-a always,exit \-F arch=b64 \-S chown,fchown,lchown,fchownat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod"; then
            perm_mod_rules_found=false
        fi
        # Check xattr rules for b64
        if ! auditctl -l | grep -q "\-a always,exit \-F arch=b64 \-S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod"; then
            perm_mod_rules_found=false
        fi
    fi
    
    # Check b32 rules
    # Check chmod rules for b32
    if ! auditctl -l | grep -q "\-a always,exit \-F arch=b32 \-S chmod,fchmod,fchmodat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod"; then
        perm_mod_rules_found=false
    fi
    # Check chown rules for b32
    if ! auditctl -l | grep -q "\-a always,exit \-F arch=b32 \-S lchown,fchown,chown,fchownat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod"; then
        perm_mod_rules_found=false
    fi
    # Check xattr rules for b32
    if ! auditctl -l | grep -q "\-a always,exit \-F arch=b32 \-S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod"; then
        perm_mod_rules_found=false
    fi
    
    if [ "$perm_mod_rules_found" = false ]; then
        echo "FAIL: perm_mod audit rules not found in running configuration"
        echo "PROOF: Required audit rules not present in auditctl -l output"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        b32_chmod_found=false
        b32_chown_found=false
        b32_xattr_found=false
        b64_chmod_found=true
        b64_chown_found=true
        b64_xattr_found=true
        
        if grep -r "\-a always,exit \-F arch=b32 \-S chmod,fchmod,fchmodat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_chmod_found=true
        fi
        
        if grep -r "\-a always,exit \-F arch=b32 \-S lchown,fchown,chown,fchownat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_chown_found=true
        fi
        
        if grep -r "\-a always,exit \-F arch=b32 \-S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_xattr_found=true
        fi
        
        if [[ "$arch" == "x86_64" ]]; then
            if ! grep -r "\-a always,exit \-F arch=b64 \-S chmod,fchmod,fchmodat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_chmod_found=false
            fi
            if ! grep -r "\-a always,exit \-F arch=b64 \-S chown,fchown,lchown,fchownat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_chown_found=false
            fi
            if ! grep -r "\-a always,exit \-F arch=b64 \-S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_xattr_found=false
            fi
        fi
        
        if [ "$b32_chmod_found" = true ] && [ "$b32_chown_found" = true ] && [ "$b32_xattr_found" = true ] && [ "$b64_chmod_found" = true ] && [ "$b64_chown_found" = true ] && [ "$b64_xattr_found" = true ]; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: perm_mod audit rules not found in configuration files"
        echo "PROOF: Required audit rules not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: discretionary access control permission modification audit rules properly configured"
    echo "PROOF: All required perm_mod audit rules found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_perm_mod_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    echo " - Using UID_MIN value: $UID_MIN"
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        b32_chmod_exists=false
        b32_chown_exists=false
        b32_xattr_exists=false
        b64_chmod_exists=true
        b64_chown_exists=true
        b64_xattr_exists=true
        
        if grep -r "\-a always,exit \-F arch=b32 \-S chmod,fchmod,fchmodat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_chmod_exists=true
        fi
        
        if grep -r "\-a always,exit \-F arch=b32 \-S lchown,fchown,chown,fchownat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_chown_exists=true
        fi
        
        if grep -r "\-a always,exit \-F arch=b32 \-S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_xattr_exists=true
        fi
        
        if [[ "$arch" == "x86_64" ]]; then
            if ! grep -r "\-a always,exit \-F arch=b64 \-S chmod,fchmod,fchmodat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_chmod_exists=false
            fi
            if ! grep -r "\-a always,exit \-F arch=b64 \-S chown,fchown,lchown,fchownat \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_chown_exists=false
            fi
            if ! grep -r "\-a always,exit \-F arch=b64 \-S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr \-F auid>=$UID_MIN \-F auid!=unset \-F key=perm_mod" /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_xattr_exists=false
            fi
        fi
        
        if [ "$b32_chmod_exists" = true ] && [ "$b32_chown_exists" = true ] && [ "$b32_xattr_exists" = true ] && [ "$b64_chmod_exists" = true ] && [ "$b64_chown_exists" = true ] && [ "$b64_xattr_exists" = true ]; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating perm_mod audit rules in /etc/audit/rules.d/50-perm_mod.rules"
        
        if [[ "$arch" == "x86_64" ]]; then
            # 64-bit system - create rules for both b64 and b32
            cat > /etc/audit/rules.d/50-perm_mod.rules << EOF
## Monitor discretionary access control permission modification events
-a always,exit -F arch=b64 -S chmod,fchmod,fchmodat -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b64 -S chown,fchown,lchown,fchownat -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b32 -S chmod,fchmod,fchmodat -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b32 -S lchown,fchown,chown,fchownat -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b64 -S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b32 -S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
EOF
        else
            # 32-bit system - create rules for b32 only
            cat > /etc/audit/rules.d/50-perm_mod.rules << EOF
## Monitor discretionary access control permission modification events
-a always,exit -F arch=b32 -S chmod,fchmod,fchmodat -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b32 -S lchown,fchown,chown,fchownat -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
-a always,exit -F arch=b32 -S setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr -F auid>=${UID_MIN} -F auid!=unset -F key=perm_mod
EOF
        fi
    else
        echo " - Perm_mod audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - perm_mod audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_perm_mod_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: discretionary access control permission modification audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="