#!/usr/bin/env bash

# Script: 5.1.2.1.1.sh
# Item: 5.1.2.1.1 Ensure systemd-journal-remote is installed (Manual)
# Description: "Run the following command to install system-journal-gateway:
# # yum install system-journal-gateway"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="5.1.2.1.1.sh"
ITEM_NAME="5.1.2.1.1 Ensure systemd-journal-remote is installed (Manual)"
DESCRIPTION="Ensure systemd-journal-remote is installed for remote journal logging"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking systemd-journal-remote installation status..."
    echo ""

    # Display current systemd-journal-remote status
    echo "Current systemd-journal-remote status:"
    echo "======================================"
    
    # Check if systemd-journal-remote is installed
    echo "Package installation status:"
    echo "---------------------------"
    
    # Check using package managers
    journal_remote_installed=false
    journal_remote_package=""
    
    # Check for RPM-based systems
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q systemd-journal-remote >/dev/null 2>&1; then
            echo "✓ systemd-journal-remote: INSTALLED (RPM)"
            journal_remote_installed=true
            journal_remote_package="systemd-journal-remote"
        elif rpm -q systemd-journal-gateway >/dev/null 2>&1; then
            echo "✓ systemd-journal-gateway: INSTALLED (RPM)"
            journal_remote_installed=true
            journal_remote_package="systemd-journal-gateway"
        else
            echo "✗ systemd-journal-remote: NOT INSTALLED (RPM)"
        fi
    fi
    
    # Check for DEB-based systems
    if command -v dpkg >/dev/null 2>&1 && [ "$journal_remote_installed" = false ]; then
        if dpkg -l | grep -q 'systemd-journal-remote'; then
            echo "✓ systemd-journal-remote: INSTALLED (DEB)"
            journal_remote_installed=true
            journal_remote_package="systemd-journal-remote"
        elif dpkg -l | grep -q 'systemd-journal-gateway'; then
            echo "✓ systemd-journal-gateway: INSTALLED (DEB)"
            journal_remote_installed=true
            journal_remote_package="systemd-journal-gateway"
        else
            echo "✗ systemd-journal-remote: NOT INSTALLED (DEB)"
        fi
    fi
    
    echo ""
    
    # Check for binary existence
    echo "Binary availability:"
    echo "-------------------"
    if command -v systemd-journal-remote >/dev/null 2>&1; then
        echo "✓ systemd-journal-remote binary: AVAILABLE"
        systemd-journal-remote --version 2>/dev/null | head -1 || echo "Version information available"
    elif command -v systemd-journal-gateway >/dev/null 2>&1; then
        echo "✓ systemd-journal-gateway binary: AVAILABLE"
        systemd-journal-gateway --version 2>/dev/null | head -1 || echo "Version information available"
    else
        echo "✗ systemd-journal-remote binary: NOT AVAILABLE"
    fi
    
    echo ""
    
    # Check service status
    echo "Service status:"
    echo "---------------"
    if systemctl is-active systemd-journal-remote >/dev/null 2>&1; then
        echo "✓ systemd-journal-remote service: ACTIVE"
    else
        echo "✗ systemd-journal-remote service: INACTIVE"
    fi
    
    if systemctl is-enabled systemd-journal-remote >/dev/null 2>&1; then
        echo "✓ systemd-journal-remote service: ENABLED at boot"
    else
        echo "✗ systemd-journal-remote service: DISABLED at boot"
    fi
    
    echo ""
    
    # Check gateway service status
    echo "Gateway service status:"
    echo "-----------------------"
    if systemctl is-active systemd-journal-gateway >/dev/null 2>&1; then
        echo "✓ systemd-journal-gateway service: ACTIVE"
    else
        echo "✗ systemd-journal-gateway service: INACTIVE"
    fi
    
    if systemctl is-enabled systemd-journal-gateway >/dev/null 2>&1; then
        echo "✓ systemd-journal-gateway service: ENABLED at boot"
    else
        echo "✗ systemd-journal-gateway service: DISABLED at boot"
    fi
    
    echo ""
    
    # Check configuration files
    echo "Configuration files:"
    echo "-------------------"
    if [ -f /etc/systemd/journal-upload.conf ]; then
        echo "✓ /etc/systemd/journal-upload.conf: EXISTS"
        echo "  Sample configuration:"
        grep -E '^(URL|ServerKeyFile|ServerCertificateFile|TrustedCertificateFile)' /etc/systemd/journal-upload.conf 2>/dev/null | head -3 || echo "  No specific remote configuration"
    else
        echo "✗ /etc/systemd/journal-upload.conf: MISSING"
    fi
    
    if [ -f /etc/systemd/journal-remote.conf ]; then
        echo "✓ /etc/systemd/journal-remote.conf: EXISTS"
    else
        echo "✗ /etc/systemd/journal-remote.conf: MISSING"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_package_availability()
    {
        echo " - Checking package availability in repositories..."
        
        # Check RPM repositories
        if command -v yum >/dev/null 2>&1; then
            if yum list available systemd-journal-remote >/dev/null 2>&1; then
                echo " - AVAILABLE: systemd-journal-remote in yum repositories"
                return 0
            elif yum list available systemd-journal-gateway >/dev/null 2>&1; then
                echo " - AVAILABLE: systemd-journal-gateway in yum repositories"
                return 0
            else
                echo " - NOT AVAILABLE: Neither package found in yum repositories"
                return 1
            fi
        elif command -v dnf >/dev/null 2>&1; then
            if dnf list available systemd-journal-remote >/dev/null 2>&1; then
                echo " - AVAILABLE: systemd-journal-remote in dnf repositories"
                return 0
            elif dnf list available systemd-journal-gateway >/dev/null 2>&1; then
                echo " - AVAILABLE: systemd-journal-gateway in dnf repositories"
                return 0
            else
                echo " - NOT AVAILABLE: Neither package found in dnf repositories"
                return 1
            fi
        elif command -v apt-cache >/dev/null 2>&1; then
            if apt-cache show systemd-journal-remote >/dev/null 2>&1; then
                echo " - AVAILABLE: systemd-journal-remote in apt repositories"
                return 0
            elif apt-cache show systemd-journal-gateway >/dev/null 2>&1; then
                echo " - AVAILABLE: systemd-journal-gateway in apt repositories"
                return 0
            else
                echo " - NOT AVAILABLE: Neither package found in apt repositories"
                return 1
            fi
        else
            echo " - UNKNOWN: Cannot check package repositories"
            return 1
        fi
    }

    check_systemd_journald_status()
    {
        echo " - Checking systemd-journald status..."
        
        if systemctl is-active systemd-journald >/dev/null 2>&1; then
            echo " - ACTIVE: systemd-journald service is running"
            
            # Check journal storage
            if command -v journalctl >/dev/null 2>&1; then
                journal_size=$(journalctl --disk-usage 2>/dev/null | head -1 || echo "unknown")
                echo " - JOURNAL SIZE: $journal_size"
            fi
        else
            echo " - INACTIVE: systemd-journald service is not running"
        fi
    }

    check_remote_journal_functionality()
    {
        echo " - Checking remote journal functionality..."
        
        if [ "$journal_remote_installed" = true ]; then
            echo " - INSTALLED: Remote journal packages are installed"
            
            # Check if any remote journal services are configured to run
            if systemctl list-unit-files | grep -E 'systemd-journal-(remote|gateway|upload)' | grep -q enabled; then
                echo " - CONFIGURED: Remote journal services are enabled"
            else
                echo " - NOT CONFIGURED: Remote journal services are not enabled"
            fi
        else
            echo " - NOT INSTALLED: Remote journal functionality not available"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing systemd-journal-remote remediation guidance..."
        
        echo ""
        echo "SYSTEMD-JOURNAL-REMOTE REMEDIATION GUIDANCE:"
        echo "============================================"
        echo ""
        
        if [ "$journal_remote_installed" = false ]; then
            echo "INSTALLATION COMMANDS:"
            echo "---------------------"
            
            # RPM-based systems
            if command -v yum >/dev/null 2>&1; then
                echo "For yum-based systems (RHEL/CentOS):"
                echo "  yum install systemd-journal-remote"
                echo "  -OR-"
                echo "  yum install systemd-journal-gateway"
                echo ""
            elif command -v dnf >/dev/null 2>&1; then
                echo "For dnf-based systems (Fedora):"
                echo "  dnf install systemd-journal-remote"
                echo "  -OR-"
                echo "  dnf install systemd-journal-gateway"
                echo ""
            elif command -v apt-get >/dev/null 2>&1; then
                echo "For apt-based systems (Debian/Ubuntu):"
                echo "  apt-get update"
                echo "  apt-get install systemd-journal-remote"
                echo ""
            else
                echo "Unknown package manager - please use your system's package manager to install:"
                echo "  systemd-journal-remote OR systemd-journal-gateway"
                echo ""
            fi
        fi
        
        echo "SERVICE MANAGEMENT:"
        echo "------------------"
        echo "Enable and start the service:"
        echo "  systemctl enable systemd-journal-remote"
        echo "  systemctl start systemd-journal-remote"
        echo ""
        echo "For gateway functionality:"
        echo "  systemctl enable systemd-journal-gateway"
        echo "  systemctl start systemd-journal-gateway"
        echo ""
        echo "CONFIGURATION:"
        echo "--------------"
        echo "Edit configuration files:"
        echo "  /etc/systemd/journal-upload.conf    # For uploading to remote server"
        echo "  /etc/systemd/journal-remote.conf    # For receiving remote journals"
        echo ""
        echo "VERIFICATION:"
        echo "-------------"
        echo "Check service status:"
        echo "  systemctl status systemd-journal-remote"
        echo "  systemctl status systemd-journal-gateway"
        echo ""
        echo "Check installation:"
        echo "  rpm -q systemd-journal-remote    # RPM systems"
        echo "  dpkg -l systemd-journal-remote   # DEB systems"
        echo ""
        echo "USAGE SCENARIOS:"
        echo "----------------"
        echo "• systemd-journal-remote: For receiving journals from remote hosts"
        echo "• systemd-journal-gateway: For providing HTTP journal access"
        echo "• systemd-journal-upload: For uploading journals to remote servers"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking package availability..."
    check_package_availability
    remediation_applied=true
    
    echo ""
    echo "Checking systemd-journald status..."
    check_systemd_journald_status
    remediation_applied=true
    
    echo ""
    echo "Checking remote journal functionality..."
    check_remote_journal_functionality
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No systemd journal system detected"
    fi

    echo ""
    echo "Remediation of systemd-journal-remote installation complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify package installation
    echo ""
    echo "1. VERIFYING PACKAGE INSTALLATION:"
    echo "----------------------------------"
    if [ "$journal_remote_installed" = true ]; then
        echo "PASS: systemd-journal-remote or related package is INSTALLED"
        echo "PROOF: $journal_remote_package is installed"
        
        # Show package details
        if command -v rpm >/dev/null 2>&1; then
            echo "Package details:"
            rpm -qi "$journal_remote_package" 2>/dev/null | grep -E '(Name|Version|Release|Install Date)' | head -4
        elif command -v dpkg >/dev/null 2>&1; then
            echo "Package details:"
            dpkg -s "$journal_remote_package" 2>/dev/null | grep -E '(Package|Version|Status)' | head -3
        fi
    else
        echo "FAIL: systemd-journal-remote is NOT INSTALLED"
        echo "PROOF: No systemd-journal-remote or systemd-journal-gateway package found"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify binary availability
    echo ""
    echo "2. VERIFYING BINARY AVAILABILITY:"
    echo "---------------------------------"
    if command -v systemd-journal-remote >/dev/null 2>&1 || command -v systemd-journal-gateway >/dev/null 2>&1; then
        echo "PASS: systemd-journal-remote or gateway binary is AVAILABLE"
        if command -v systemd-journal-remote >/dev/null 2>&1; then
            echo "PROOF (systemd-journal-remote --version):"
            systemd-journal-remote --version 2>/dev/null | head -1 || echo "Binary available"
        else
            echo "PROOF (systemd-journal-gateway --version):"
            systemd-journal-gateway --version 2>/dev/null | head -1 || echo "Binary available"
        fi
    else
        echo "FAIL: systemd-journal-remote binary is NOT AVAILABLE"
        echo "PROOF: systemd-journal-remote command not found"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify service availability
    echo ""
    echo "3. VERIFYING SERVICE AVAILABILITY:"
    echo "----------------------------------"
    services_available=0
    
    if systemctl list-unit-files | grep -q 'systemd-journal-remote'; then
        echo "PASS: systemd-journal-remote service unit exists"
        ((services_available++))
    else
        echo "INFO: systemd-journal-remote service unit not found"
    fi
    
    if systemctl list-unit-files | grep -q 'systemd-journal-gateway'; then
        echo "PASS: systemd-journal-gateway service unit exists"
        ((services_available++))
    else
        echo "INFO: systemd-journal-gateway service unit not found"
    fi
    
    if [ $services_available -eq 0 ]; then
        echo "INFO: No remote journal services available (may need installation)"
    fi
    
    # PROOF 4: Verify configuration files
    echo ""
    echo "4. VERIFYING CONFIGURATION FILES:"
    echo "---------------------------------"
    config_files_exist=0
    
    if [ -f /etc/systemd/journal-upload.conf ]; then
        echo "PASS: /etc/systemd/journal-upload.conf exists"
        ((config_files_exist++))
        echo "PROOF (file size): $(wc -l < /etc/systemd/journal-upload.conf) lines"
    else
        echo "INFO: /etc/systemd/journal-upload.conf does not exist"
    fi
    
    if [ -f /etc/systemd/journal-remote.conf ]; then
        echo "PASS: /etc/systemd/journal-remote.conf exists"
        ((config_files_exist++))
        echo "PROOF (file size): $(wc -l < /etc/systemd/journal-remote.conf) lines"
    else
        echo "INFO: /etc/systemd/journal-remote.conf does not exist"
    fi
    
    if [ $config_files_exist -eq 0 ]; then
        echo "INFO: No remote journal configuration files found"
    fi
    
    # PROOF 5: Verify systemd-journald is functional
    echo ""
    echo "5. VERIFYING SYSTEMD-JOURNALD FUNCTIONALITY:"
    echo "--------------------------------------------"
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        echo "PASS: systemd-journald service is ACTIVE"
        echo "PROOF (systemctl is-active systemd-journald): active"
        
        if command -v journalctl >/dev/null 2>&1; then
            echo "Journal statistics:"
            journalctl --disk-usage 2>/dev/null | head -1 || echo "Journal information available"
        fi
    else
        echo "WARNING: systemd-journald service is INACTIVE"
        echo "PROOF (systemctl is-active systemd-journald): inactive"
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Determine if remote journal functionality is required for your environment"
    echo "• Choose between systemd-journal-remote and systemd-journal-gateway based on needs"
    echo "• Configure remote journal services according to organizational policy"
    echo "• Set up appropriate network security for journal transmission"
    echo "• Test remote journal functionality in a non-production environment"
    echo "• Document the remote journal configuration for audit purposes"
    echo ""
    echo "PACKAGE MANAGEMENT COMMANDS:"
    echo "============================"
    echo ""
    echo "INSTALLATION:"
    echo "  yum install systemd-journal-remote      # RHEL/CentOS"
    echo "  dnf install systemd-journal-remote      # Fedora"
    echo "  apt-get install systemd-journal-remote  # Debian/Ubuntu"
    echo ""
    echo "VERIFICATION:"
    echo "  rpm -q systemd-journal-remote           # Check RPM installation"
    echo "  dpkg -l systemd-journal-remote          # Check DEB installation"
    echo "  systemd-journal-remote --version        # Check binary version"
    echo ""
    echo "SERVICE MANAGEMENT:"
    echo "  systemctl enable systemd-journal-remote"
    echo "  systemctl start systemd-journal-remote"
    echo "  systemctl status systemd-journal-remote"
    echo ""
    echo "CONFIGURATION:"
    echo "  vi /etc/systemd/journal-upload.conf"
    echo "  vi /etc/systemd/journal-remote.conf"
    echo "  systemctl daemon-reload"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: systemd-journal-remote installation verification completed"
        echo "NOTE: Manual configuration required to set up remote journal functionality"
    else
        echo ""
        echo "WARNING: systemd-journal-remote installation issues detected - manual installation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="