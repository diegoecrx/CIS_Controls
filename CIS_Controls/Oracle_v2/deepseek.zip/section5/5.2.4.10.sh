#!/usr/bin/env bash
# Script: 5.2.4.10.sh
# Item: 5.2.4.10 Ensure audit tools belong to group root (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.10.sh"
ITEM_NAME="5.2.4.10 Ensure audit tools belong to group root (Automated)"
DESCRIPTION="This remediation ensures audit tools belong to group root and have appropriate permissions."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit tools group ownership and permissions..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Define audit tools to check
    audit_tools=(
        "/sbin/auditctl"
        "/sbin/aureport"
        "/sbin/ausearch"
        "/sbin/autrace"
        "/sbin/auditd"
        "/sbin/augenrules"
    )
    
    # Check each audit tool
    non_root_group_tools=()
    improper_permissions_tools=()
    missing_tools=()
    
    for tool in "${audit_tools[@]}"; do
        if [ ! -f "$tool" ]; then
            missing_tools+=("$tool")
            continue
        fi
        
        # Check group ownership
        group=$(stat -c "%G" "$tool")
        if [ "$group" != "root" ]; then
            non_root_group_tools+=("$tool:$group")
        fi
        
        # Check permissions (group and other write should not be set)
        current_perms=$(stat -c "%a" "$tool")
        if [ $((0$current_perms & 022)) -ne 0 ]; then
            improper_permissions_tools+=("$tool:$current_perms")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        echo "FAIL: Some audit tools are missing"
        echo "PROOF: Missing audit tools:"
        for tool in "${missing_tools[@]}"; do
            echo "  $tool"
        done
        return 1
    fi
    
    if [ ${#non_root_group_tools[@]} -gt 0 ]; then
        echo "FAIL: audit tools not belonging to group root found"
        echo "PROOF: Tools not belonging to group root:"
        for tool_group in "${non_root_group_tools[@]}"; do
            tool=$(echo "$tool_group" | cut -d: -f1)
            group=$(echo "$tool_group" | cut -d: -f2)
            echo "  $tool: belongs to group $group"
        done
        return 1
    fi
    
    if [ ${#improper_permissions_tools[@]} -gt 0 ]; then
        echo "FAIL: audit tools with improper permissions found"
        echo "PROOF: Tools with group/other write permissions:"
        for tool_perm in "${improper_permissions_tools[@]}"; do
            tool=$(echo "$tool_perm" | cut -d: -f1)
            perm=$(echo "$tool_perm" | cut -d: -f2)
            echo "  $tool: permissions $perm"
        done
        return 1
    fi
    
    echo "PASS: audit tools group ownership and permissions properly configured"
    echo "PROOF: All audit tools belong to group root and have appropriate permissions"
    return 0
}
# Function to fix
fix_audit_tools_group_ownership() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Define audit tools to fix
    audit_tools=(
        "/sbin/auditctl"
        "/sbin/aureport"
        "/sbin/ausearch"
        "/sbin/autrace"
        "/sbin/auditd"
        "/sbin/augenrules"
    )
    
    echo " - Checking and fixing audit tools group ownership and permissions"
    
    fixed_permissions=0
    fixed_ownership=0
    missing_tools=0
    
    # Check each tool individually for detailed reporting
    for tool in "${audit_tools[@]}"; do
        if [ ! -f "$tool" ]; then
            echo " - Warning: $tool not found"
            ((missing_tools++))
            continue
        fi
        
        current_perms=$(stat -c "%a" "$tool")
        current_group=$(stat -c "%G" "$tool")
        current_owner=$(stat -c "%U" "$tool")
        
        # Check and fix permissions
        if [ $((0$current_perms & 022)) -ne 0 ]; then
            echo " - Fixing permissions for $tool (was $current_perms)"
            chmod go-w "$tool"
            ((fixed_permissions++))
        fi
        
        # Check and fix ownership
        if [ "$current_owner" != "root" ] || [ "$current_group" != "root" ]; then
            echo " - Fixing ownership for $tool (was $current_owner:$current_group)"
            chown root:root "$tool"
            ((fixed_ownership++))
        fi
    done
    
    # Run comprehensive fixes (commands from the benchmark)
    echo " - Running comprehensive permissions fix"
    existing_tools=()
    for tool in "${audit_tools[@]}"; do
        if [ -f "$tool" ]; then
            existing_tools+=("$tool")
        fi
    done
    
    if [ ${#existing_tools[@]} -gt 0 ]; then
        # Remove group and other write permissions
        chmod go-w "${existing_tools[@]}" 2>/dev/null || true
        
        # Set owner and group to root
        chown root:root "${existing_tools[@]}" 2>/dev/null || true
    fi
    
    if [ $missing_tools -gt 0 ]; then
        echo " - Warning: $missing_tools audit tools were not found"
    fi
    
    if [ $fixed_permissions -gt 0 ] || [ $fixed_ownership -gt 0 ]; then
        echo " - Fixed permissions for $fixed_permissions tools and ownership for $fixed_ownership tools"
    else
        echo " - All existing audit tools already had correct permissions and ownership"
    fi
    
    echo " - audit tools group ownership and permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_tools_group_ownership
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit tools group ownership and permissions properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="