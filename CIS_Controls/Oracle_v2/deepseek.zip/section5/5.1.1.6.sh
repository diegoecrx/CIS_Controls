#!/usr/bin/env bash

# Script: 5.1.1.6.sh
# Item: 5.1.1.6 Ensure rsyslog is configured to send logs to a remote log host (Manual)
# Description: "Edit the /etc/rsyslog.conf and /etc/rsyslog.d/*.conf files and add the following line
# (where loghost.example.com is the name of your central log host). The target directive
# may either be a fully qualified domain name or an IP address.
# *.* action(type=""omfwd"" target=""192.168.2.100"" port=""514"" protocol=""tcp""
# action.resumeRetryCount=""100""
# queue.type=""LinkedList"" queue.size=""1000"")
# Run the following command to reload the rsyslogd configuration:
# # systemctl restart rsyslog"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="5.1.1.6.sh"
ITEM_NAME="5.1.1.6 Ensure rsyslog is configured to send logs to a remote log host (Manual)"
DESCRIPTION="Ensure rsyslog is configured to forward logs to a remote log host for centralized logging"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current rsyslog remote logging configuration..."
    echo ""

    # Display current rsyslog remote logging status
    echo "Current rsyslog remote logging status:"
    echo "======================================"
    
    # Check if rsyslog is installed and running
    if ! command -v rsyslogd >/dev/null 2>&1; then
        echo "rsyslog is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    if ! systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "rsyslog is NOT ACTIVE on this system"
        echo "WARNING: Logging may not be functioning"
    fi
    
    echo "rsyslog service status:"
    echo "-----------------------"
    systemctl is-active rsyslog >/dev/null 2>&1 && echo "ACTIVE" || echo "INACTIVE"
    systemctl is-enabled rsyslog >/dev/null 2>&1 && echo "ENABLED at boot" || echo "DISABLED at boot"
    
    echo ""
    
    # Check for remote logging configuration
    echo "Remote logging configuration check:"
    echo "-----------------------------------"
    
    # Check main configuration file
    echo "Main configuration (/etc/rsyslog.conf):"
    if [ -f /etc/rsyslog.conf ]; then
        remote_config_count=$(grep -c -E '(omfwd|@|@@)' /etc/rsyslog.conf 2>/dev/null || echo "0")
        echo "Remote forwarding rules found: $remote_config_count"
        
        if [ "$remote_config_count" -gt 0 ]; then
            echo "Remote forwarding configuration:"
            grep -E '(omfwd|@|@@)' /etc/rsyslog.conf | grep -v '^#' | head -5
        fi
    else
        echo "WARNING: /etc/rsyslog.conf does not exist"
    fi
    
    echo ""
    
    # Check additional configuration files
    echo "Additional configuration files (/etc/rsyslog.d/):"
    echo "-------------------------------------------------"
    if [ -d /etc/rsyslog.d ]; then
        remote_files_count=0
        for conf_file in $(find /etc/rsyslog.d -name "*.conf" -type f 2>/dev/null); do
            if grep -q -E '(omfwd|@|@@)' "$conf_file" 2>/dev/null; then
                ((remote_files_count++))
                echo "Remote config found in: $(basename "$conf_file")"
                grep -E '(omfwd|@|@@)' "$conf_file" | grep -v '^#' | head -2
            fi
        done
        echo "Total files with remote configuration: $remote_files_count"
    else
        echo "No additional configuration directory (/etc/rsyslog.d)"
    fi
    
    echo ""
    
    # Check for modern vs legacy configuration
    echo "Remote logging method analysis:"
    echo "-------------------------------"
    
    # Check for modern omfwd configuration
    omfwd_count=$(grep -r -c 'omfwd' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    if [ "$omfwd_count" -gt 0 ]; then
        echo "✓ Modern omfwd configuration: FOUND ($omfwd_count instances)"
        echo "Sample omfwd configuration:"
        grep -r -h 'omfwd' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -1
    else
        echo "✗ Modern omfwd configuration: NOT FOUND"
    fi
    
    echo ""
    
    # Check for legacy forwarding syntax
    legacy_count=$(grep -r -c -E '(@@|@)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    if [ "$legacy_count" -gt 0 ]; then
        echo "✓ Legacy forwarding syntax: FOUND ($legacy_count instances)"
        echo "Sample legacy configuration:"
        grep -r -h -E '(@@|@)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -1
    else
        echo "✗ Legacy forwarding syntax: NOT FOUND"
    fi
    
    echo ""
    
    # Check protocol and port configuration
    echo "Protocol and port configuration:"
    echo "--------------------------------"
    tcp_count=$(grep -r -c 'protocol="tcp"' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    udp_count=$(grep -r -c 'protocol="udp"' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    
    if [ "$tcp_count" -gt 0 ]; then
        echo "✓ TCP protocol: CONFIGURED ($tcp_count instances)"
    else
        echo "✗ TCP protocol: NOT CONFIGURED"
    fi
    
    if [ "$udp_count" -gt 0 ]; then
        echo "✓ UDP protocol: CONFIGURED ($udp_count instances)"
    else
        echo "✗ UDP protocol: NOT CONFIGURED"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_remote_host_configuration()
    {
        echo " - Checking remote log host configuration..."
        
        remote_hosts=$(grep -r -h -E '(target=|@|@@)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | \
                      grep -v '^#' | \
                      grep -o -E '(target="[^"]+"|@[^[:space:]]+|@@[^[:space:]]+)' | \
                      head -5 || echo "none")
        
        if [ "$remote_hosts" != "none" ]; then
            echo " - FOUND: Remote log hosts configured:"
            echo "$remote_hosts" | while read -r host; do
                echo "   - $host"
            done
        else
            echo " - MISSING: No remote log hosts configured"
        fi
    }

    check_queue_configuration()
    {
        echo " - Checking queue configuration for reliability..."
        
        queue_configs=$(grep -r -h -E '(queue\.|action\.resumeRetryCount)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | \
                       grep -v '^#' | head -3 || echo "none")
        
        if [ "$queue_configs" != "none" ]; then
            echo " - FOUND: Queue reliability configuration:"
            echo "$queue_configs" | while read -r config; do
                echo "   - $config"
            done
        else
            echo " - MISSING: No queue reliability configuration"
        fi
    }

    check_configuration_syntax()
    {
        echo " - Checking rsyslog configuration syntax..."
        
        if command -v rsyslogd >/dev/null 2>&1; then
            if rsyslogd -N 1 >/dev/null 2>&1; then
                echo " - SUCCESS: rsyslog configuration syntax is valid"
            else
                echo " - ERROR: rsyslog configuration syntax validation failed"
                echo " - Run 'rsyslogd -N 1' to see specific errors"
            fi
        else
            echo " - WARNING: Cannot validate syntax - rsyslogd not found"
        fi
    }

    check_firewall_connectivity()
    {
        echo " - Checking potential firewall and connectivity considerations..."
        
        # Check if common syslog ports are open locally
        if command -v ss >/dev/null 2>&1; then
            tcp_listen=$(ss -tln | grep ':514 ' | wc -l || echo "0")
            udp_listen=$(ss -uln | grep ':514 ' | wc -l || echo "0")
            
            if [ "$tcp_listen" -gt 0 ]; then
                echo " - INFO: TCP port 514 is listening (may be receiving logs)"
            fi
            if [ "$udp_listen" -gt 0 ]; then
                echo " - INFO: UDP port 514 is listening (may be receiving logs)"
            fi
        fi
        
        echo " - NOTE: Ensure firewall rules allow outbound connections to remote log host"
        echo " - NOTE: Verify network connectivity to remote log host"
    }

    provide_remediation_guidance()
    {
        echo " - Providing remote logging remediation guidance..."
        
        echo ""
        echo "REMOTE LOGGING REMEDIATION GUIDANCE:"
        echo "===================================="
        echo ""
        echo "MODERN CONFIGURATION (Recommended):"
        echo "----------------------------------"
        echo "Add to /etc/rsyslog.conf or /etc/rsyslog.d/remote.conf:"
        echo ""
        cat << 'EOF'
*.* action(
    type="omfwd"
    target="loghost.example.com"
    port="514"
    protocol="tcp"
    action.resumeRetryCount="100"
    queue.type="LinkedList"
    queue.size="1000"
    )
EOF
        echo ""
        echo "LEGACY CONFIGURATION (Alternative):"
        echo "----------------------------------"
        echo "For TCP forwarding:"
        echo "  *.* @@loghost.example.com:514"
        echo ""
        echo "For UDP forwarding (less reliable):"
        echo "  *.* @loghost.example.com:514"
        echo ""
        echo "CONFIGURATION STEPS:"
        echo "--------------------"
        echo "1. Replace 'loghost.example.com' with your actual log host IP/FQDN"
        echo "2. Choose appropriate protocol (TCP recommended for reliability)"
        echo "3. Configure in /etc/rsyslog.conf or create /etc/rsyslog.d/remote.conf"
        echo "4. Validate configuration: rsyslogd -N 1"
        echo "5. Restart rsyslog: systemctl restart rsyslog"
        echo "6. Test remote logging: logger \"Test remote logging message\""
        echo ""
        echo "SECURITY CONSIDERATIONS:"
        echo "-----------------------"
        echo "• Use TLS encryption for sensitive environments"
        echo "• Configure firewall rules for outbound syslog traffic"
        echo "• Consider network segmentation for log traffic"
        echo "• Use dedicated service accounts if authentication is required"
        echo ""
        echo "VERIFICATION COMMANDS:"
        echo "---------------------"
        echo "rsyslogd -N 1                      # Validate configuration"
        echo "systemctl status rsyslog           # Check service status"
        echo "logger \"Test remote log message\"   # Test remote logging"
        echo "tcpdump -i any port 514            # Monitor syslog traffic (if needed)"
        echo "tail -f /var/log/rsyslog           # Check for forwarding errors"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking remote host configuration..."
    check_remote_host_configuration
    remediation_applied=true
    
    echo ""
    echo "Checking queue configuration..."
    check_queue_configuration
    remediation_applied=true
    
    echo ""
    echo "Checking configuration syntax..."
    check_configuration_syntax
    remediation_applied=true
    
    echo ""
    echo "Checking firewall considerations..."
    check_firewall_connectivity
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No rsyslog configuration detected"
    fi

    echo ""
    echo "Remediation of remote logging configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify rsyslog service status
    echo ""
    echo "1. VERIFYING RSYSLOG SERVICE STATUS:"
    echo "------------------------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "PASS: rsyslog service is ACTIVE"
        echo "PROOF (systemctl is-active rsyslog): active"
        echo ""
        echo "Service details:"
        systemctl status rsyslog --no-pager -l 2>/dev/null | head -3
    else
        echo "FAIL: rsyslog service is INACTIVE"
        echo "PROOF (systemctl is-active rsyslog): inactive"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify remote logging configuration exists
    echo ""
    echo "2. VERIFYING REMOTE LOGGING CONFIGURATION:"
    echo "------------------------------------------"
    remote_config_found=false
    
    # Check for modern omfwd configuration
    omfwd_configs=$(grep -r -h 'omfwd' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -2)
    if [ -n "$omfwd_configs" ]; then
        echo "PASS: Modern omfwd configuration found"
        echo "PROOF (omfwd configuration):"
        echo "$omfwd_configs"
        remote_config_found=true
    else
        # Check for legacy configuration
        legacy_configs=$(grep -r -h -E '(@@|@)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -2)
        if [ -n "$legacy_configs" ]; then
            echo "PASS: Legacy remote forwarding configuration found"
            echo "PROOF (legacy configuration):"
            echo "$legacy_configs"
            remote_config_found=true
        else
            echo "FAIL: No remote logging configuration found"
            echo "PROOF: No omfwd, @@, or @ directives found in configuration"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify configuration syntax
    echo ""
    echo "3. VERIFYING CONFIGURATION SYNTAX:"
    echo "----------------------------------"
    if command -v rsyslogd >/dev/null 2>&1; then
        if rsyslogd -N 1 >/dev/null 2>&1; then
            echo "PASS: rsyslog configuration syntax is valid"
            echo "PROOF (rsyslogd -N 1): exit code 0"
        else
            echo "FAIL: rsyslog configuration syntax validation failed"
            echo "PROOF (rsyslogd -N 1): non-zero exit code"
            final_status_pass=false
        fi
    else
        echo "INFO: Cannot validate syntax - rsyslogd command not available"
    fi
    
    # PROOF 4: Verify protocol configuration
    echo ""
    echo "4. VERIFYING PROTOCOL CONFIGURATION:"
    echo "------------------------------------"
    tcp_configured=$(grep -r -c 'protocol="tcp"' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    udp_configured=$(grep -r -c 'protocol="udp"' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    
    if [ "$tcp_configured" -gt 0 ]; then
        echo "PASS: TCP protocol configured ($tcp_configured instances)"
        echo "PROOF: TCP protocol found in configuration"
    elif [ "$udp_configured" -gt 0 ]; then
        echo "INFO: UDP protocol configured ($udp_configured instances)"
        echo "PROOF: UDP protocol found in configuration"
        echo "NOTE: TCP is recommended for reliable delivery"
    else
        echo "INFO: Protocol not explicitly configured (may use default)"
    fi
    
    # PROOF 5: Verify queue and reliability configuration
    echo ""
    echo "5. VERIFYING RELIABILITY CONFIGURATION:"
    echo "---------------------------------------"
    queue_configured=$(grep -r -c -E '(queue\.|action\.resumeRetryCount)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | awk -F: '{sum += $2} END {print sum}' || echo "0")
    
    if [ "$queue_configured" -gt 0 ]; then
        echo "PASS: Queue reliability features configured ($queue_configured instances)"
        echo "PROOF (sample configuration):"
        grep -r -h -E '(queue\.|action\.resumeRetryCount)' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -1
    else
        echo "INFO: No explicit queue reliability configuration"
        echo "NOTE: Consider adding queue configuration for network reliability"
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Replace placeholder hostname/IP with actual log server address"
    echo "• Verify network connectivity to remote log host"
    echo "• Configure firewall rules for outbound syslog traffic"
    echo "• Test log reception on remote log server"
    echo "• Monitor for forwarding errors in local log files"
    echo "• Consider TLS encryption for sensitive environments"
    echo "• Document remote logging configuration for audit purposes"
    echo ""
    echo "REMOTE LOGGING CONFIGURATION COMMANDS:"
    echo "======================================"
    echo ""
    echo "VIEW CURRENT CONFIGURATION:"
    echo "  grep -r -E '(omfwd|@|@@)' /etc/rsyslog.conf /etc/rsyslog.d/"
    echo "  cat /etc/rsyslog.d/remote.conf 2>/dev/null || echo 'No remote config'"
    echo ""
    echo "CONFIGURE REMOTE LOGGING:"
    echo "  echo '*.* action(type=\"omfwd\" target=\"loghost.example.com\" port=\"514\" protocol=\"tcp\" action.resumeRetryCount=\"100\" queue.type=\"LinkedList\" queue.size=\"1000\")' > /etc/rsyslog.d/remote.conf"
    echo ""
    echo "VALIDATE AND RESTART:"
    echo "  rsyslogd -N 1"
    echo "  systemctl restart rsyslog"
    echo ""
    echo "TEST REMOTE LOGGING:"
    echo "  logger \"Test remote logging configuration\""
    echo "  tail -f /var/log/rsyslog | grep -i error"
    echo ""
    echo "MONITOR NETWORK TRAFFIC:"
    echo "  tcpdump -i any -n port 514"

    if [ "$final_status_pass" = true ] && [ "$remote_config_found" = true ]; then
        echo ""
        echo "SUCCESS: Remote logging configuration verification completed"
        echo "NOTE: Manual review required to verify actual log host configuration and connectivity"
    else
        echo ""
        echo "WARNING: Remote logging configuration issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="