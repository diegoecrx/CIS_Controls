#!/usr/bin/env bash
# Script: 5.2.3.21.sh
# Item: 5.2.3.21 Ensure the running and on disk configuration is the same (Manual)
set -euo pipefail
SCRIPT_NAME="5.2.3.21.sh"
ITEM_NAME="5.2.3.21 Ensure the running and on disk configuration is the same (Manual)"
DESCRIPTION="This remediation ensures running and on disk audit configuration is the same by running augenrules --load."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit configuration consistency..."
    
    # Run auditctl -s to get enabled flag
    enabled_flag=$(auditctl -s | grep "enabled" | awk '{print $2}' || true)
    
    if [ "$enabled_flag" = "2" ]; then
        echo "FAIL: Configuration locked, reboot may be required after changes"
        echo "PROOF: auditctl -s shows enabled $enabled_flag"
    fi
    
    # Compare running rules with on-disk rules
    running_rules=$(auditctl -l)
    disk_rules=$(augenrules --check 2>&1)
    
    if echo "$disk_rules" | grep -q "No change"; then
        echo "PASS: Running and on-disk configurations match"
        echo "PROOF (augenrules --check): $disk_rules"
        return 0
    else
        echo "FAIL: Configurations do not match"
        echo "PROOF (augenrules --check): $disk_rules"
        return 1
    fi
}
# Function to fix
fix_audit_config() {
    echo "Applying fix..."
    augenrules --load
    echo " - Merged and loaded rules with augenrules --load"
    
    # Check if reboot required
    enabled_flag=$(auditctl -s | grep "enabled" | awk '{print $2}')
    if [ "$enabled_flag" = "2" ]; then
        echo " - Reboot required to load rules"
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_config
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Configurations match"
    else
        echo "FAIL: Issues remain - manual review needed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="