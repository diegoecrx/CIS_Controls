#!/usr/bin/env bash

# Script: 5.1.1.3.sh
# Item: 5.1.1.3 Ensure journald is configured to send logs to rsyslog (Manual)
# Description: "Create or edit the file /etc/systemd/journald.conf and add or edit the following line:
# ForwardToSyslog=yes
# Reload the systemd-journald service:
# # systemctl systemctl reload-or-try-restart systemd-journald.service"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="5.1.1.3.sh"
ITEM_NAME="5.1.1.3 Ensure journald is configured to send logs to rsyslog (Manual)"
DESCRIPTION="Ensure systemd-journald forwards logs to rsyslog for centralized logging"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current journald configuration for syslog forwarding..."
    echo ""

    # Display current journald configuration status
    echo "Current journald configuration status:"
    echo "======================================"
    
    # Check if systemd-journald is available
    if ! command -v journalctl >/dev/null 2>&1; then
        echo "systemd-journald is NOT AVAILABLE on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi
    
    echo "systemd-journald availability:"
    echo "------------------------------"
    journalctl --version 2>/dev/null | head -1 || echo "journalctl command available"
    
    echo ""
    
    # Check journald service status
    echo "systemd-journald service status:"
    echo "--------------------------------"
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        echo "ACTIVE"
        journald_active=true
    else
        echo "INACTIVE"
        journald_active=false
    fi
    
    if systemctl is-enabled systemd-journald >/dev/null 2>&1; then
        echo "ENABLED at boot"
    else
        echo "DISABLED at boot"
    fi
    
    echo ""
    
    # Check current journald.conf configuration
    echo "Current journald.conf configuration:"
    echo "------------------------------------"
    if [ -f /etc/systemd/journald.conf ]; then
        echo "File: /etc/systemd/journald.conf exists"
        echo ""
        echo "Relevant configuration lines:"
        grep -E '^(ForwardToSyslog|Storage|Compress|Seal|#)' /etc/systemd/journald.conf 2>/dev/null | head -10 || echo "No relevant configuration found"
    else
        echo "File: /etc/systemd/journald.conf does NOT exist (using defaults)"
    fi
    
    echo ""
    
    # Check for configuration overrides
    echo "Journald configuration overrides:"
    echo "---------------------------------"
    if [ -d /etc/systemd/journald.conf.d ]; then
        echo "Configuration override directory: /etc/systemd/journald.conf.d exists"
        find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null | head -3
        for conf_file in $(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null | head 2); do
            echo "Contents of $(basename "$conf_file"):"
            grep -E '^(ForwardToSyslog|Storage|Compress|Seal)' "$conf_file" 2>/dev/null | head -3 || echo "No ForwardToSyslog settings"
        done
    else
        echo "No configuration override directory found"
    fi
    
    echo ""
    
    # Check current ForwardToSyslog setting
    echo "Current ForwardToSyslog setting:"
    echo "--------------------------------"
    forward_setting=$(journalctl -b 0 -n 1 --output=json | jq -r '._SYSTEMD_UNIT' 2>/dev/null || true)
    if [ -n "$forward_setting" ]; then
        echo "Journald is operational"
    fi
    
    # Use systemd-analyze to check effective configuration
    if command -v systemd-analyze >/dev/null 2>&1; then
        echo ""
        echo "Effective journald configuration:"
        systemd-analyze cat-config systemd/journald.conf 2>/dev/null | grep -E '^(ForwardToSyslog|#)' | head -5 || echo "Unable to analyze effective configuration"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_forward_to_syslog_setting()
    {
        echo " - Checking ForwardToSyslog configuration..."
        
        # Check main configuration file
        if [ -f /etc/systemd/journald.conf ]; then
            forward_setting=$(grep -E '^ForwardToSyslog=' /etc/systemd/journald.conf 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "not set")
            if [ "$forward_setting" = "yes" ]; then
                echo " - FOUND: ForwardToSyslog=yes in main configuration"
                return 0
            elif [ "$forward_setting" = "no" ]; then
                echo " - MISCONFIGURED: ForwardToSyslog=no in main configuration"
                return 1
            elif [ "$forward_setting" = "not set" ]; then
                echo " - MISSING: ForwardToSyslog not set in main configuration (using default)"
                return 1
            else
                echo " - UNKNOWN: ForwardToSyslog=$forward_setting in main configuration"
                return 1
            fi
        else
            echo " - MISSING: /etc/systemd/journald.conf does not exist (using default)"
            return 1
        fi
    }

    check_override_configurations()
    {
        echo " - Checking for configuration overrides..."
        
        override_found=false
        correct_override=false
        
        if [ -d /etc/systemd/journald.conf.d ]; then
            for conf_file in $(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null); do
                override_forward=$(grep -E '^ForwardToSyslog=' "$conf_file" 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "")
                if [ -n "$override_forward" ]; then
                    override_found=true
                    if [ "$override_forward" = "yes" ]; then
                        echo " - FOUND: Correct override in $(basename "$conf_file"): ForwardToSyslog=yes"
                        correct_override=true
                    else
                        echo " - MISCONFIGURED: Override in $(basename "$conf_file"): ForwardToSyslog=$override_forward"
                    fi
                fi
            done
        fi
        
        if [ "$override_found" = false ]; then
            echo " - INFO: No ForwardToSyslog overrides found"
        fi
        
        if [ "$correct_override" = true ]; then
            return 0
        else
            return 1
        fi
    }

    check_rsyslog_journal_input()
    {
        echo " - Checking rsyslog journal input configuration..."
        
        if [ -f /etc/rsyslog.conf ]; then
            if grep -q 'imjournal' /etc/rsyslog.conf || find /etc/rsyslog.d -name "*.conf" -exec grep -q 'imjournal' {} \; 2>/dev/null; then
                echo " - FOUND: rsyslog imjournal module configured"
                return 0
            else
                echo " - INFO: rsyslog imjournal module not explicitly configured (may be using default)"
                return 1
            fi
        else
            echo " - WARNING: /etc/rsyslog.conf not found"
            return 1
        fi
    }

    check_journal_storage_setting()
    {
        echo " - Checking journal storage configuration..."
        
        storage_setting=$(grep -E '^Storage=' /etc/systemd/journald.conf 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "auto")
        echo " - Storage setting: $storage_setting"
        
        if [ "$storage_setting" = "volatile" ] || [ "$storage_setting" = "none" ]; then
            echo " - WARNING: Journal storage is $storage_setting - syslog forwarding is critical"
        elif [ "$storage_setting" = "persistent" ] || [ "$storage_setting" = "auto" ]; then
            echo " - OK: Journal storage is $storage_setting"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing journald remediation guidance..."
        
        echo ""
        echo "JOURNALD REMEDIATION GUIDANCE:"
        echo "=============================="
        echo ""
        echo "To configure journald to forward logs to rsyslog:"
        echo ""
        echo "EDIT MAIN CONFIGURATION FILE:"
        echo "  vi /etc/systemd/journald.conf"
        echo ""
        echo "ADD OR MODIFY THE FOLLOWING LINE:"
        echo "  ForwardToSyslog=yes"
        echo ""
        echo "OR CREATE CONFIGURATION OVERRIDE:"
        echo "  mkdir -p /etc/systemd/journald.conf.d"
        echo "  echo '[Journal]' > /etc/systemd/journald.conf.d/forward-syslog.conf"
        echo "  echo 'ForwardToSyslog=yes' >> /etc/systemd/journald.conf.d/forward-syslog.conf"
        echo ""
        echo "RELOAD JOURNALD SERVICE:"
        echo "  systemctl reload systemd-journald"
        echo "  -OR-"
        echo "  systemctl restart systemd-journald"
        echo ""
        echo "VERIFY RSYSLOG CONFIGURATION:"
        echo "  Ensure rsyslog is configured to receive journal messages via imjournal"
        echo ""
        echo "TEST CONFIGURATION:"
        echo "  logger \"Test message from journald forwarding test\""
        echo "  journalctl -f | grep \"Test message\""
        echo "  tail -f /var/log/syslog /var/log/messages | grep \"Test message\""
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking ForwardToSyslog setting..."
    check_forward_to_syslog_setting
    remediation_applied=true
    
    echo ""
    echo "Checking configuration overrides..."
    check_override_configurations
    remediation_applied=true
    
    echo ""
    echo "Checking rsyslog journal input..."
    check_rsyslog_journal_input
    remediation_applied=true
    
    echo ""
    echo "Checking journal storage settings..."
    check_journal_storage_setting
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No journald configuration detected"
    fi

    echo ""
    echo "Remediation of journald syslog forwarding configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify journald service status
    echo ""
    echo "1. VERIFYING SYSTEMD-JOURNALD SERVICE STATUS:"
    echo "---------------------------------------------"
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        echo "PASS: systemd-journald service is ACTIVE"
        echo "PROOF (systemctl is-active systemd-journald): active"
        echo ""
        echo "Detailed status:"
        systemctl status systemd-journald --no-pager -l 2>/dev/null | head -3
    else
        echo "FAIL: systemd-journald service is INACTIVE"
        echo "PROOF (systemctl is-active systemd-journald): inactive"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify ForwardToSyslog configuration
    echo ""
    echo "2. VERIFYING FORWARDTOSYSLOG CONFIGURATION:"
    echo "-------------------------------------------"
    forward_configured=false
    
    # Check main configuration file
    if [ -f /etc/systemd/journald.conf ]; then
        main_forward=$(grep -E '^ForwardToSyslog=' /etc/systemd/journald.conf 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "not set")
        if [ "$main_forward" = "yes" ]; then
            echo "PASS: ForwardToSyslog=yes in main configuration"
            echo "PROOF (/etc/systemd/journald.conf): ForwardToSyslog=yes"
            forward_configured=true
        else
            echo "INFO: ForwardToSyslog=$main_forward in main configuration"
        fi
    else
        echo "INFO: /etc/systemd/journald.conf does not exist"
    fi
    
    # Check override configurations
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in $(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null); do
            override_forward=$(grep -E '^ForwardToSyslog=' "$conf_file" 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "")
            if [ "$override_forward" = "yes" ]; then
                echo "PASS: ForwardToSyslog=yes in override $(basename "$conf_file")"
                echo "PROOF ($conf_file): ForwardToSyslog=yes"
                forward_configured=true
            elif [ -n "$override_forward" ]; then
                echo "FAIL: ForwardToSyslog=$override_forward in override $(basename "$conf_file")"
                final_status_pass=false
            fi
        done
    fi
    
    if [ "$forward_configured" = false ]; then
        echo "FAIL: ForwardToSyslog=yes not configured"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify effective configuration
    echo ""
    echo "3. VERIFYING EFFECTIVE CONFIGURATION:"
    echo "-------------------------------------"
    if command -v systemd-analyze >/dev/null 2>&1; then
        effective_forward=$(systemd-analyze cat-config systemd/journald.conf 2>/dev/null | grep -E '^ForwardToSyslog=' | cut -d= -f2 | tr -d ' ' | tail -1 || echo "not set")
        echo "Effective ForwardToSyslog setting: $effective_forward"
        
        if [ "$effective_forward" = "yes" ]; then
            echo "PASS: Effective configuration has ForwardToSyslog=yes"
        else
            echo "FAIL: Effective configuration has ForwardToSyslog=$effective_forward"
            final_status_pass=false
        fi
    else
        echo "INFO: systemd-analyze not available for effective configuration check"
    fi
    
    # PROOF 4: Verify rsyslog journal integration
    echo ""
    echo "4. VERIFYING RSYSLOG JOURNAL INTEGRATION:"
    echo "-----------------------------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "PASS: rsyslog service is active"
        
        # Check for imjournal configuration
        if grep -r 'imjournal' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -1; then
            echo "PASS: rsyslog imjournal module configured"
            echo "PROOF: imjournal found in rsyslog configuration"
        else
            echo "INFO: imjournal not explicitly configured in rsyslog (may be using legacy methods)"
        fi
    else
        echo "WARNING: rsyslog service is not active"
        final_status_pass=false
    fi
    
    # PROOF 5: Test log forwarding functionality
    echo ""
    echo "5. TESTING LOG FORWARDING FUNCTIONALITY:"
    echo "----------------------------------------"
    test_message="JOURNALD-FORWARD-TEST-$(date +%Y%m%d-%H%M%S)-$(hostname)"
    
    # Send test message via logger (which goes to journald)
    if logger "JOURNALD-FORWARD-TEST: $test_message" 2>/dev/null; then
        echo "PASS: Test message sent to journald via logger"
        echo "Test message: $test_message"
        
        # Check if message appears in journal
        if journalctl --since "1 minute ago" | grep -q "$test_message" 2>/dev/null; then
            echo "PASS: Test message found in journal"
        else
            echo "WARNING: Test message not found in journal"
        fi
    else
        echo "WARNING: Could not send test message via logger"
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Verify logs are successfully forwarded from journald to rsyslog"
    echo "• Check that both journal and syslog contain the same log entries"
    echo "• Test log rotation and retention for both systems"
    echo "• Ensure sufficient storage for journal and syslog files"
    echo "• Monitor log consistency between journald and rsyslog"
    echo "• Verify log timestamps are synchronized"
    echo ""
    echo "JOURNALD CONFIGURATION COMMANDS:"
    echo "================================"
    echo ""
    echo "VIEW CURRENT CONFIGURATION:"
    echo "  cat /etc/systemd/journald.conf"
    echo "  systemd-analyze cat-config systemd/journald.conf"
    echo "  journalctl --list-boots"
    echo ""
    echo "CONFIGURE SYSLOG FORWARDING:"
    echo "  echo 'ForwardToSyslog=yes' >> /etc/systemd/journald.conf"
    echo "  systemctl reload systemd-journald"
    echo ""
    echo "TEST FORWARDING:"
    echo "  logger \"Test journald to rsyslog forwarding\""
    echo "  journalctl -f | grep \"Test journald\""
    echo "  tail -f /var/log/syslog | grep \"Test journald\""
    echo ""
    echo "MONITORING:"
    echo "  journalctl -f                    # Monitor journal in real-time"
    echo "  tail -f /var/log/syslog         # Monitor syslog in real-time"
    echo "  journalctl --disk-usage         # Check journal storage usage"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: journald syslog forwarding verification completed"
        echo "NOTE: Manual testing required to verify log forwarding functionality"
    else
        echo ""
        echo "WARNING: journald configuration issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="