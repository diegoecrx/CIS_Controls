#!/usr/bin/env bash
# Script: 5.1.2.1.2.sh
# Item: 5.1.2.1.2 Ensure systemd-journal-remote is configured (Manual)
set -euo pipefail
SCRIPT_NAME="5.1.2.1.2.sh"
ITEM_NAME="5.1.2.1.2 Ensure systemd-journal-remote is configured (Manual)"
DESCRIPTION="This remediation ensures systemd-journal-remote is configured in /etc/systemd/journal-upload.conf."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/systemd/journal-upload.conf configuration..."
    
    conf_file="/etc/systemd/journal-upload.conf"
    if [ ! -f "$conf_file" ]; then
        echo "FAIL: Configuration file does not exist"
        echo "PROOF: File not found"
        return 1
    fi
    
    url=$(grep '^URL=' "$conf_file" || true)
    keyfile=$(grep '^ServerKeyFile=' "$conf_file" || true)
    certfile=$(grep '^ServerCertificateFile=' "$conf_file" || true)
    trustfile=$(grep '^TrustedCertificateFile=' "$conf_file" || true)
    
    if [ -n "$url" ] && [ -n "$keyfile" ] && [ -n "$certfile" ] && [ -n "$trustfile" ]; then
        echo "PASS: All required lines present"
        echo "PROOF (URL): $url"
        echo "PROOF (ServerKeyFile): $keyfile"
        echo "PROOF (ServerCertificateFile): $certfile"
        echo "PROOF (TrustedCertificateFile): $trustfile"
        return 0
    else
        echo "FAIL: Missing configuration lines"
        echo "PROOF (URL): $url"
        echo "PROOF (ServerKeyFile): $keyfile"
        echo "PROOF (ServerCertificateFile): $certfile"
        echo "PROOF (TrustedCertificateFile): $trustfile"
        return 1
    fi
}
# Function to fix
fix_journal_remote() {
    echo "Applying fix with example values (customize as needed)..."
    
    conf_file="/etc/systemd/journal-upload.conf"
    mkdir -p /etc/systemd
    
    # Backup if exists
    [ -f "$conf_file" ] && cp "$conf_file" "$conf_file.bak.$(date +%Y%m%d)"
    
    # Add or update lines
    grep -q '^URL=' "$conf_file" && sed -i 's/^URL=.*/URL=192.168.50.42/' "$conf_file" || echo "URL=192.168.50.42" >> "$conf_file"
    grep -q '^ServerKeyFile=' "$conf_file" && sed -i 's/^ServerKeyFile=.*/ServerKeyFile=\/etc\/ssl\/private\/journal-upload.pem/' "$conf_file" || echo "ServerKeyFile=/etc/ssl/private/journal-upload.pem" >> "$conf_file"
    grep -q '^ServerCertificateFile=' "$conf_file" && sed -i 's/^ServerCertificateFile=.*/ServerCertificateFile=\/etc\/ssl\/certs\/journal-upload.pem/' "$conf_file" || echo "ServerCertificateFile=/etc/ssl/certs/journal-upload.pem" >> "$conf_file"
    grep -q '^TrustedCertificateFile=' "$conf_file" && sed -i 's/^TrustedCertificateFile=.*/TrustedCertificateFile=\/etc\/ssl\/ca\/trusted.pem/' "$conf_file" || echo "TrustedCertificateFile=/etc/ssl/ca/trusted.pem" >> "$conf_file"
    
    echo " - Configured with example values"
    
    # Restart service
    echo " - Restarting systemd-journal-upload"
    systemctl restart systemd-journal-upload.service 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journal_remote
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: systemd-journal-remote configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="