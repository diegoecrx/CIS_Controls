#!/usr/bin/env bash
# Script: 5.1.2.6.sh
# Item: 5.1.2.6 Ensure journald log rotation is configured per site policy (Manual)
set -euo pipefail
SCRIPT_NAME="5.1.2.6.sh"
ITEM_NAME="5.1.2.6 Ensure journald log rotation is configured per site policy (Manual)"
DESCRIPTION="This remediation ensures journald log rotation parameters are configured in /etc/systemd/journald.conf."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/systemd/journald.conf configuration..."
    
    conf_file="/etc/systemd/journald.conf"
    if [ ! -f "$conf_file" ]; then
        echo "FAIL: Configuration file does not exist"
        echo "PROOF: File not found"
        return 1
    fi
    
    # Check for presence of rotation parameters
    system_max_use=$(grep '^SystemMaxUse=' "$conf_file" || true)
    system_keep_free=$(grep '^SystemKeepFree=' "$conf_file" || true)
    runtime_max_use=$(grep '^RuntimeMaxUse=' "$conf_file" || true)
    runtime_keep_free=$(grep '^RuntimeKeepFree=' "$conf_file" || true)
    max_file_sec=$(grep '^MaxFileSec=' "$conf_file" || true)
    
    if [ -n "$system_max_use" ] && [ -n "$system_keep_free" ] && [ -n "$runtime_max_use" ] && [ -n "$runtime_keep_free" ] && [ -n "$max_file_sec" ]; then
        echo "PASS: All rotation parameters present"
        echo "PROOF (SystemMaxUse): $system_max_use"
        echo "PROOF (SystemKeepFree): $system_keep_free"
        echo "PROOF (RuntimeMaxUse): $runtime_max_use"
        echo "PROOF (RuntimeKeepFree): $runtime_keep_free"
        echo "PROOF (MaxFileSec): $max_file_sec"
        return 0
    else
        echo "FAIL: Missing rotation parameters"
        echo "PROOF (SystemMaxUse): $system_max_use"
        echo "PROOF (SystemKeepFree): $system_keep_free"
        echo "PROOF (RuntimeMaxUse): $runtime_max_use"
        echo "PROOF (RuntimeKeepFree): $runtime_keep_free"
        echo "PROOF (MaxFileSec): $max_file_sec"
        return 1
    fi
}
# Function to fix with example values (manual adjustment needed per policy)
fix_journald_rotation() {
    echo "Applying example configuration (adjust per site policy)..."
    
    conf_file="/etc/systemd/journald.conf"
    # Backup if exists
    [ -f "$conf_file" ] && cp "$conf_file" "$conf_file.bak.$(date +%Y%m%d)"
    
    # Add or update lines with example values
    grep -q '^SystemMaxUse=' "$conf_file" && sed -i 's/^SystemMaxUse=.*/SystemMaxUse=1G/' "$conf_file" || echo "SystemMaxUse=1G" >> "$conf_file"
    grep -q '^SystemKeepFree=' "$conf_file" && sed -i 's/^SystemKeepFree=.*/SystemKeepFree=2G/' "$conf_file" || echo "SystemKeepFree=2G" >> "$conf_file"
    grep -q '^RuntimeMaxUse=' "$conf_file" && sed -i 's/^RuntimeMaxUse=.*/RuntimeMaxUse=100M/' "$conf_file" || echo "RuntimeMaxUse=100M" >> "$conf_file"
    grep -q '^RuntimeKeepFree=' "$conf_file" && sed -i 's/^RuntimeKeepFree=.*/RuntimeKeepFree=200M/' "$conf_file" || echo "RuntimeKeepFree=200M" >> "$conf_file"
    grep -q '^MaxFileSec=' "$conf_file" && sed -i 's/^MaxFileSec=.*/MaxFileSec=1month/' "$conf_file" || echo "MaxFileSec=1month" >> "$conf_file"
    
    echo " - Configured with example values"
    
    # Restart journald to apply
    echo " - Restarting systemd-journald"
    systemctl restart systemd-journald.service
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed (verify values per policy)"
    else
        fix_journald_rotation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Journald rotation configured"
    else
        echo "FAIL: Issues remain - manual review needed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="