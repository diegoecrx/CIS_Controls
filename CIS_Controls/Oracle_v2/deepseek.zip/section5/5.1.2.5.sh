#!/usr/bin/env bash

# Script: 5.1.2.5.sh
# Item: 5.1.2.5 Ensure journald is not configured to send logs to rsyslog (Manual)
# Description: "Edit the /etc/systemd/journald.conf file and ensure that ForwardToSyslog=yes is
# removed.
# Restart the service:
# # systemctl systemctl reload-or-try-restart systemd-journald.service"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="5.1.2.5.sh"
ITEM_NAME="5.1.2.5 Ensure journald is not configured to send logs to rsyslog (Manual)"
DESCRIPTION="Ensure systemd-journald is not configured to forward logs to rsyslog when using remote journal logging"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current journald configuration for rsyslog forwarding..."
    echo ""

    # Display current journald configuration status
    echo "Current journald configuration status:"
    echo "======================================"
    
    # Check if systemd-journald is available
    if ! command -v journalctl >/dev/null 2>&1; then
        echo "systemd-journald is NOT AVAILABLE on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi
    
    echo "systemd-journald availability:"
    echo "------------------------------"
    journalctl --version 2>/dev/null | head -1 || echo "journalctl command available"
    
    echo ""
    
    # Check journald service status
    echo "systemd-journald service status:"
    echo "--------------------------------"
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        echo "ACTIVE"
        journald_active=true
    else
        echo "INACTIVE"
        journald_active=false
    fi
    
    if systemctl is-enabled systemd-journald >/dev/null 2>&1; then
        echo "ENABLED at boot"
    else
        echo "DISABLED at boot"
    fi
    
    echo ""
    
    # Check current journald.conf configuration for ForwardToSyslog
    echo "Current ForwardToSyslog configuration:"
    echo "--------------------------------------"
    if [ -f /etc/systemd/journald.conf ]; then
        echo "File: /etc/systemd/journald.conf exists"
        echo ""
        echo "ForwardToSyslog settings:"
        grep -E '^ForwardToSyslog=' /etc/systemd/journald.conf 2>/dev/null | head -5 || echo "No ForwardToSyslog setting found in main config"
    else
        echo "File: /etc/systemd/journald.conf does NOT exist (using defaults)"
    fi
    
    echo ""
    
    # Check for configuration overrides
    echo "Journald configuration overrides:"
    echo "---------------------------------"
    if [ -d /etc/systemd/journald.conf.d ]; then
        echo "Configuration override directory: /etc/systemd/journald.conf.d exists"
        override_files=$(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null | wc -l)
        echo "Number of override files: $override_files"
        
        if [ "$override_files" -gt 0 ]; then
            echo ""
            echo "ForwardToSyslog settings in overrides:"
            for conf_file in $(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null); do
                forward_setting=$(grep -E '^ForwardToSyslog=' "$conf_file" 2>/dev/null || echo "")
                if [ -n "$forward_setting" ]; then
                    echo "$(basename "$conf_file"): $forward_setting"
                fi
            done
            if [ -z "$forward_setting" ]; then
                echo "No ForwardToSyslog settings found in override files"
            fi
        fi
    else
        echo "No configuration override directory found"
    fi
    
    echo ""
    
    # Check effective configuration
    echo "Effective ForwardToSyslog configuration:"
    echo "----------------------------------------"
    if command -v systemd-analyze >/dev/null 2>&1; then
        effective_forward=$(systemd-analyze cat-config systemd/journald.conf 2>/dev/null | grep -E '^ForwardToSyslog=' | tail -1 || echo "not set")
        echo "Effective setting: $effective_forward"
    else
        echo "systemd-analyze not available for effective configuration check"
    fi
    
    echo ""
    
    # Check if systemd-journal-remote is installed and configured
    echo "systemd-journal-remote status:"
    echo "------------------------------"
    if command -v systemd-journal-remote >/dev/null 2>&1 || command -v systemd-journal-gateway >/dev/null 2>&1; then
        echo "systemd-journal-remote/gateway: INSTALLED"
        if systemctl is-active systemd-journal-remote >/dev/null 2>&1 || systemctl is-active systemd-journal-gateway >/dev/null 2>&1; then
            echo "Remote journal service: ACTIVE"
            remote_journal_active=true
        else
            echo "Remote journal service: INACTIVE"
            remote_journal_active=false
        fi
    else
        echo "systemd-journal-remote/gateway: NOT INSTALLED"
        remote_journal_active=false
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_forward_to_syslog_setting()
    {
        echo " - Checking ForwardToSyslog configuration..."
        
        forward_to_syslog_found=false
        forward_to_syslog_value=""
        
        # Check main configuration file
        if [ -f /etc/systemd/journald.conf ]; then
            main_forward=$(grep -E '^ForwardToSyslog=' /etc/systemd/journald.conf 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "not set")
            if [ "$main_forward" != "not set" ]; then
                echo " - FOUND: ForwardToSyslog=$main_forward in main configuration"
                forward_to_syslog_found=true
                forward_to_syslog_value="$main_forward"
            fi
        fi
        
        # Check override configurations
        if [ -d /etc/systemd/journald.conf.d ]; then
            for conf_file in $(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null); do
                override_forward=$(grep -E '^ForwardToSyslog=' "$conf_file" 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "")
                if [ -n "$override_forward" ]; then
                    echo " - FOUND: ForwardToSyslog=$override_forward in override $(basename "$conf_file")"
                    forward_to_syslog_found=true
                    forward_to_syslog_value="$override_forward"
                fi
            done
        fi
        
        if [ "$forward_to_syslog_found" = false ]; then
            echo " - OK: No ForwardToSyslog configuration found (using default)"
        elif [ "$forward_to_syslog_value" = "no" ]; then
            echo " - OK: ForwardToSyslog=no (correctly disabled)"
        else
            echo " - MISCONFIGURED: ForwardToSyslog=$forward_to_syslog_value (should be removed or set to 'no')"
        fi
    }

    check_remote_journal_capability()
    {
        echo " - Checking remote journal capability..."
        
        if [ "$remote_journal_active" = true ]; then
            echo " - ACTIVE: Remote journal services are running"
            echo " - NOTE: ForwardToSyslog should be disabled when using remote journal"
        else
            echo " - INACTIVE: No remote journal services detected"
            echo " - NOTE: Consider organizational policy for log forwarding"
        fi
    }

    check_journal_storage_configuration()
    {
        echo " - Checking journal storage configuration..."
        
        storage_setting=$(grep -E '^Storage=' /etc/systemd/journald.conf 2>/dev/null | cut -d= -f2 | tr -d ' ' || echo "auto")
        echo " - Storage setting: $storage_setting"
        
        if [ "$storage_setting" = "persistent" ]; then
            echo " - OK: Journal storage is persistent"
        elif [ "$storage_setting" = "volatile" ]; then
            echo " - WARNING: Journal storage is volatile - ensure alternative logging exists"
        elif [ "$storage_setting" = "auto" ]; then
            echo " - INFO: Journal storage is auto-configured"
        else
            echo " - INFO: Journal storage: $storage_setting"
        fi
    }

    check_rsyslog_status()
    {
        echo " - Checking rsyslog status..."
        
        if systemctl is-active rsyslog >/dev/null 2>&1; then
            echo " - ACTIVE: rsyslog service is running"
            if [ "$remote_journal_active" = true ]; then
                echo " - NOTE: Both rsyslog and remote journal are active - check for duplicate logs"
            fi
        else
            echo " - INACTIVE: rsyslog service is not running"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing journald remediation guidance..."
        
        echo ""
        echo "JOURNALD REMEDIATION GUIDANCE:"
        echo "=============================="
        echo ""
        echo "To ensure journald does not forward logs to rsyslog:"
        echo ""
        echo "REMOVE FORWARDTOSYSLOG FROM MAIN CONFIGURATION:"
        echo "  Edit /etc/systemd/journald.conf and remove or comment out:"
        echo "  #ForwardToSyslog=yes"
        echo ""
        echo "OR SET TO 'NO' EXPLICITLY:"
        echo "  echo 'ForwardToSyslog=no' >> /etc/systemd/journald.conf"
        echo ""
        echo "REMOVE FROM OVERRIDE FILES:"
        echo "  Check and edit files in /etc/systemd/journald.conf.d/"
        echo "  Remove any lines containing 'ForwardToSyslog=yes'"
        echo ""
        echo "RELOAD JOURNALD SERVICE:"
        echo "  systemctl reload systemd-journald"
        echo "  -OR-"
        echo "  systemctl restart systemd-journald"
        echo ""
        echo "WHEN TO DISABLE FORWARDTOSYSLOG:"
        echo "  • When using systemd-journal-remote for centralized logging"
        echo "  • When journald persistent storage is sufficient"
        echo "  • When organizational policy specifies journal-only logging"
        echo "  • To avoid duplicate logs in both journal and syslog"
        echo ""
        echo "VERIFICATION COMMANDS:"
        echo "  systemd-analyze cat-config systemd/journald.conf | grep ForwardToSyslog"
        echo "  grep -r 'ForwardToSyslog' /etc/systemd/journald.conf /etc/systemd/journald.conf.d/"
        echo "  systemctl status systemd-journald"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking ForwardToSyslog setting..."
    check_forward_to_syslog_setting
    remediation_applied=true
    
    echo ""
    echo "Checking remote journal capability..."
    check_remote_journal_capability
    remediation_applied=true
    
    echo ""
    echo "Checking journal storage configuration..."
    check_journal_storage_configuration
    remediation_applied=true
    
    echo ""
    echo "Checking rsyslog status..."
    check_rsyslog_status
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No journald configuration detected"
    fi

    echo ""
    echo "Remediation of journald rsyslog forwarding configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify journald service status
    echo ""
    echo "1. VERIFYING SYSTEMD-JOURNALD SERVICE STATUS:"
    echo "---------------------------------------------"
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        echo "PASS: systemd-journald service is ACTIVE"
        echo "PROOF (systemctl is-active systemd-journald): active"
        echo ""
        echo "Service details:"
        systemctl status systemd-journald --no-pager -l 2>/dev/null | head -3
    else
        echo "FAIL: systemd-journald service is INACTIVE"
        echo "PROOF (systemctl is-active systemd-journald): inactive"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify ForwardToSyslog is not set to "yes"
    echo ""
    echo "2. VERIFYING FORWARDTOSYSLOG IS NOT ENABLED:"
    echo "---------------------------------------------"
    forward_to_syslog_enabled=false
    
    # Check effective configuration
    if command -v systemd-analyze >/dev/null 2>&1; then
        effective_forward=$(systemd-analyze cat-config systemd/journald.conf 2>/dev/null | grep -E '^ForwardToSyslog=' | tail -1 | cut -d= -f2 | tr -d ' ' || echo "not set")
        if [ "$effective_forward" = "yes" ]; then
            echo "FAIL: ForwardToSyslog=yes in effective configuration"
            echo "PROOF (effective configuration): ForwardToSyslog=yes"
            forward_to_syslog_enabled=true
            final_status_pass=false
        elif [ "$effective_forward" = "no" ] || [ "$effective_forward" = "not set" ]; then
            echo "PASS: ForwardToSyslog is not enabled"
            echo "PROOF (effective configuration): ForwardToSyslog=$effective_forward"
        else
            echo "INFO: ForwardToSyslog=$effective_forward"
            echo "PROOF (effective configuration): ForwardToSyslog=$effective_forward"
        fi
    else
        # Fallback to file checking
        if grep -r -E '^ForwardToSyslog=yes' /etc/systemd/journald.conf /etc/systemd/journald.conf.d/ >/dev/null 2>&1; then
            echo "FAIL: ForwardToSyslog=yes found in configuration files"
            echo "PROOF:"
            grep -r -h '^ForwardToSyslog=yes' /etc/systemd/journald.conf /etc/systemd/journald.conf.d/ 2>/dev/null | head -2
            forward_to_syslog_enabled=true
            final_status_pass=false
        else
            echo "PASS: No ForwardToSyslog=yes found in configuration files"
            echo "PROOF: No ForwardToSyslog=yes directives found"
        fi
    fi
    
    # PROOF 3: Verify configuration files
    echo ""
    echo "3. VERIFYING CONFIGURATION FILES:"
    echo "---------------------------------"
    if [ -f /etc/systemd/journald.conf ]; then
        forward_settings=$(grep -E '^ForwardToSyslog=' /etc/systemd/journald.conf 2>/dev/null || echo "not set")
        echo "Main config ForwardToSyslog: $forward_settings"
    else
        echo "INFO: /etc/systemd/journald.conf does not exist"
    fi
    
    if [ -d /etc/systemd/journald.conf.d ]; then
        override_count=$(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null | wc -l)
        echo "Override config files: $override_count"
        if [ "$override_count" -gt 0 ]; then
            for conf_file in $(find /etc/systemd/journald.conf.d -name "*.conf" -type f 2>/dev/null | head 2); do
                override_forward=$(grep -E '^ForwardToSyslog=' "$conf_file" 2>/dev/null || echo "not set")
                echo "$(basename "$conf_file"): $override_forward"
            done
        fi
    else
        echo "No override configuration directory"
    fi
    
    # PROOF 4: Verify remote journal status
    echo ""
    echo "4. VERIFYING REMOTE JOURNAL STATUS:"
    echo "-----------------------------------"
    if command -v systemd-journal-remote >/dev/null 2>&1 || command -v systemd-journal-gateway >/dev/null 2>&1; then
        echo "PASS: systemd-journal-remote/gateway is INSTALLED"
        
        if systemctl is-active systemd-journal-remote >/dev/null 2>&1; then
            echo "ACTIVE: systemd-journal-remote service is running"
        elif systemctl is-active systemd-journal-gateway >/dev/null 2>&1; then
            echo "ACTIVE: systemd-journal-gateway service is running"
        else
            echo "INACTIVE: Remote journal services are not running"
        fi
    else
        echo "INFO: systemd-journal-remote/gateway is NOT INSTALLED"
    fi
    
    # PROOF 5: Verify rsyslog status
    echo ""
    echo "5. VERIFYING RSYSLOG STATUS:"
    echo "----------------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "ACTIVE: rsyslog service is running"
        if [ "$forward_to_syslog_enabled" = true ]; then
            echo "NOTE: Logs may be duplicated in both journal and rsyslog"
        fi
    else
        echo "INACTIVE: rsyslog service is not running"
        if [ "$forward_to_syslog_enabled" = false ]; then
            echo "NOTE: Journal is the primary logging system"
        fi
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Determine if rsyslog forwarding is needed for your environment"
    echo "• Consider organizational logging policy and requirements"
    echo "• Ensure alternative logging methods are in place if disabling rsyslog forwarding"
    echo "• Test logging functionality after configuration changes"
    echo "• Monitor for any logging gaps or issues"
    echo "• Document the logging architecture for audit purposes"
    echo ""
    echo "CONFIGURATION MANAGEMENT COMMANDS:"
    echo "=================================="
    echo ""
    echo "VIEW CURRENT CONFIGURATION:"
    echo "  systemd-analyze cat-config systemd/journald.conf | grep ForwardToSyslog"
    echo "  grep -r 'ForwardToSyslog' /etc/systemd/journald.conf /etc/systemd/journald.conf.d/"
    echo ""
    echo "DISABLE RSYSLOG FORWARDING:"
    echo "  sed -i 's/^ForwardToSyslog=yes/#ForwardToSyslog=yes/' /etc/systemd/journald.conf"
    echo "  echo 'ForwardToSyslog=no' >> /etc/systemd/journald.conf"
    echo ""
    echo "RELOAD CONFIGURATION:"
    echo "  systemctl reload systemd-journald"
    echo "  systemctl status systemd-journald"
    echo ""
    echo "VERIFY LOGGING:"
    echo "  logger \"Test journal-only logging\""
    echo "  journalctl -f | grep \"Test journal-only logging\""
    echo "  # Verify message appears in journal but not necessarily in /var/log/messages"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Journald rsyslog forwarding verification completed"
        echo "NOTE: Manual review required to confirm logging architecture meets organizational needs"
    else
        echo ""
        echo "WARNING: Journald configuration issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="