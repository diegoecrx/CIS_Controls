#!/usr/bin/env bash

# Script: 2.2.6_v2.sh
# Item: 2.2.6 Ensure samba file server services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.6_v2.sh"
ITEM_NAME="2.2.6 Ensure samba file server services are not in use (Automated)"
DESCRIPTION="This remediation ensures Samba file server services are not in use by removing or masking the services. FORCE VERSION - Comprehensive Samba removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_samba_status
check_samba_status() {
    echo "Checking Samba status..."
    
    samba_installed=false
    samba_running=false
    samba_enabled=false
    samba_masked=false
    
    # Check for Samba packages
    samba_packages=("samba" "samba-common" "samba-client" "samba-server" "samba4" "samba-common-bin")
    
    for pkg in "${samba_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                samba_installed=true
                echo " - $pkg package is installed"
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                samba_installed=true
                echo " - $pkg package is installed"
            fi
        fi
    done
    
    # Check for Samba processes
    if pgrep smbd >/dev/null 2>&1 || pgrep nmbd >/dev/null 2>&1 || pgrep winbindd >/dev/null 2>&1; then
        samba_running=true
        echo " - Samba processes running:"
        pgrep smbd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep nmbd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep winbindd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
    fi
    
    # Check for Samba services
    samba_services=("smb" "nmb" "winbind" "samba" "samba-ad-dc")
    
    for service in "${samba_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            # Check if service is running
            if systemctl is-active "$service" >/dev/null 2>&1; then
                samba_running=true
                echo " - $service.service is running"
            fi
            
            # Check if service is enabled
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                samba_enabled=true
                echo " - $service.service is enabled"
            fi
            
            # Check if service is masked
            if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                samba_masked=true
                echo " - $service.service is masked"
            fi
        fi
    done
    
    # Check for Samba network services
    if netstat -tulpn 2>/dev/null | grep -E ':139 |:445 ' | grep -v grep; then
        echo " - WARNING: Samba network services detected:"
        netstat -tulpn 2>/dev/null | grep -E ':139 |:445 '
    fi
    
    # Check for Samba configuration files
    samba_configs=("/etc/samba" "/etc/smb.conf" "/var/lib/samba" "/var/log/samba")
    for config in "${samba_configs[@]}"; do
        if [ -e "$config" ]; then
            echo " - Samba configuration found: $config"
        fi
    done
    
    # Check for active Samba shares
    if command -v smbstatus >/dev/null 2>&1; then
        if smbstatus 2>/dev/null | grep -q "Service"; then
            echo " - WARNING: Active Samba shares detected"
            smbstatus 2>/dev/null | head -10
        fi
    fi
    
    # Check for Samba in authentication
    if grep -q "winbind" /etc/nsswitch.conf 2>/dev/null; then
        echo " - WARNING: Samba winbind configured in /etc/nsswitch.conf"
    fi
    
    if grep -q "pam_winbind.so" /etc/pam.d/* 2>/dev/null; then
        echo " - WARNING: Samba PAM module configured"
    fi
    
    return 0
}

# Function to stop_samba_services
stop_samba_services() {
    echo "Stopping Samba services..."
    
    # Stop Samba processes first
    for process in smbd nmbd winbindd samba; do
        if pgrep "$process" >/dev/null 2>&1; then
            echo " - Stopping $process processes..."
            pkill -TERM "$process" 2>/dev/null || true
            sleep 2
            
            # Force kill if still running
            if pgrep "$process" >/dev/null 2>&1; then
                echo " - Force stopping $process processes..."
                pkill -KILL "$process" 2>/dev/null || true
                sleep 1
            fi
        fi
    done
    
    # Stop services using systemctl
    samba_services=("smb" "nmb" "winbind" "samba" "samba-ad-dc")
    
    for service in "${samba_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service.service..."
            if systemctl stop "$service" 2>&1; then
                echo "   - $service.service stopped"
            else
                echo "   - WARNING: Could not stop $service.service via systemctl"
            fi
        fi
    done
    
    # Additional stop for any Samba related services
    systemctl list-unit-files | grep -E "(smb|nmb|winbind|samba)" | awk '{print $1}' | while read -r service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Verify no Samba processes are running
    running_processes=0
    for process in smbd nmbd winbindd samba; do
        if pgrep "$process" >/dev/null 2>&1; then
            running_processes=$((running_processes + 1))
        fi
    done
    
    if [ "$running_processes" -gt 0 ]; then
        echo " - CRITICAL: Samba processes still running after stop attempts"
        return 1
    else
        echo " - No Samba processes running"
    fi
    
    # Kill any remaining Samba processes
    for process in smbd nmbd winbindd samba; do
        pkill -9 "$process" 2>/dev/null || true
    done
    
    return 0
}

# Function to remove_samba_packages
remove_samba_packages() {
    local pkg_mgr="$1"
    
    echo "Removing Samba packages..."
    
    # List of Samba-related packages
    samba_packages=("samba" "samba-common" "samba-client" "samba-server" "samba4" 
                    "samba-common-bin" "samba-winbind" "samba-winbind-modules" 
                    "samba-dc" "samba-tools")
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove Samba packages..."
            for pkg in "${samba_packages[@]}"; do
                if $pkg_mgr list installed "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if $pkg_mgr remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        apt)
            echo " - Using apt to remove Samba packages..."
            export DEBIAN_FRONTEND=noninteractive
            for pkg in "${samba_packages[@]}"; do
                if dpkg -l "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if apt-get remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        zypper)
            echo " - Using zypper to remove Samba packages..."
            for pkg in "${samba_packages[@]}"; do
                if zypper search --installed-only "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if zypper --non-interactive remove "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove Samba packages"
            return 1
            ;;
    esac
    
    # Clean up package cache and dependencies
    case "$pkg_mgr" in
        yum|dnf)
            $pkg_mgr autoremove -y 2>/dev/null || true
            ;;
        apt)
            apt-get autoremove -y 2>/dev/null || true
            ;;
    esac
    
    echo " - Package removal completed"
    return 0
}

# Function to mask_samba_services
mask_samba_services() {
    echo "Masking Samba services..."
    
    # List of Samba services to mask
    samba_services=("smb" "nmb" "winbind" "samba" "samba-ad-dc")
    
    for service in "${samba_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                if systemctl mask "$service" 2>&1; then
                    echo " - $service.service masked"
                else
                    echo " - WARNING: Could not mask $service.service"
                fi
            else
                echo " - $service.service already masked"
            fi
        fi
    done
    
    # Mask any other Samba related services
    systemctl list-unit-files | grep -E "(smb|nmb|winbind|samba)" | awk '{print $1}' | while read -r service; do
        if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
            systemctl mask "$service" 2>/dev/null && echo " - $service masked" || true
        fi
    done
    
    return 0
}

# Function to disable_samba_services
disable_samba_services() {
    echo "Disabling Samba services..."
    
    # List of Samba services to disable
    samba_services=("smb" "nmb" "winbind" "samba" "samba-ad-dc")
    
    for service in "${samba_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl disable "$service" 2>&1; then
                    echo " - $service.service disabled"
                else
                    echo " - WARNING: Could not disable $service.service"
                fi
            else
                echo " - $service.service already disabled"
            fi
        fi
    done
    
    # Disable any other Samba related services
    systemctl list-unit-files | grep -E "(smb|nmb|winbind|samba)" | awk '{print $1}' | while read -r service; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            systemctl disable "$service" 2>/dev/null && echo " - $service disabled" || true
        fi
    done
    
    return 0
}

# Function to cleanup_samba_configs
cleanup_samba_configs() {
    echo "Cleaning up Samba configuration files..."
    
    # List of Samba configuration files to remove or disable
    config_files=(
        "/etc/samba"
        "/etc/smb.conf"
        "/var/lib/samba"
        "/var/log/samba"
        "/var/cache/samba"
        "/etc/pam.d/winbind"
        "/etc/security/pam_winbind.conf"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -e "$config_file" ]; then
            if [ -f "$config_file" ]; then
                # Create backup and disable
                backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp "$config_file" "$backup_file"
                echo " - Backed up $config_file to $backup_file"
                
                # Comment out all active configurations
                sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$config_file" 2>/dev/null || true
                echo " - Disabled configurations in $config_file"
            elif [ -d "$config_file" ]; then
                # For directories, backup and disable contents
                backup_dir="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp -r "$config_file" "$backup_dir" 2>/dev/null || true
                echo " - Backed up $config_file to $backup_dir"
                
                # Disable all configuration files in directory
                find "$config_file" -type f -name "*.conf" -exec sh -c 'echo "# REMEDIATED: $(cat {})" > {}' \; 2>/dev/null || true
                echo " - Disabled configuration files in $config_file"
            fi
        fi
    done
    
    # Remove Samba from authentication configurations
    if [ -f "/etc/nsswitch.conf" ]; then
        if grep -q "winbind" /etc/nsswitch.conf; then
            cp /etc/nsswitch.conf "/etc/nsswitch.conf.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i 's/winbind//g' /etc/nsswitch.conf 2>/dev/null || true
            sed -i 's/,,/,/g' /etc/nsswitch.conf 2>/dev/null || true
            sed -i 's/^$//g' /etc/nsswitch.conf 2>/dev/null || true
            echo " - Removed winbind from /etc/nsswitch.conf"
        fi
    fi
    
    # Remove Samba PAM configurations
    if [ -d "/etc/pam.d" ]; then
        find /etc/pam.d -type f -exec grep -l "pam_winbind.so" {} \; | while read -r pam_file; do
            cp "$pam_file" "${pam_file}.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i '/pam_winbind.so/d' "$pam_file" 2>/dev/null || true
            echo " - Removed Samba PAM from $pam_file"
        done
    fi
    
    # Remove Samba from Kerberos configuration if present
    if [ -f "/etc/krb5.conf" ]; then
        if grep -q "winbind" /etc/krb5.conf; then
            cp /etc/krb5.conf "/etc/krb5.conf.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i '/winbind/d' /etc/krb5.conf 2>/dev/null || true
            echo " - Removed winbind from Kerberos configuration"
        fi
    fi
    
    # Clean up Samba runtime files
    if [ -d "/var/run/samba" ]; then
        rm -rf /var/run/samba/* 2>/dev/null || true
        echo " - Cleaned up Samba runtime files"
    fi
    
    # Remove any Samba related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -E "(samba|smb|winbind)" "$cron_file" 2>/dev/null; then
                sed -i '/samba\|smb\|winbind/d' "$cron_file" 2>/dev/null || true
                echo " - Removed Samba references from $cron_file"
            fi
        done
    fi
    
    return 0
}

# Function to block_samba_ports
block_samba_ports() {
    echo "Blocking Samba network ports..."
    
    # Samba uses ports 139 (NetBIOS) and 445 (SMB)
    if command -v firewall-cmd >/dev/null 2>&1; then
        # firewalld
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld to block Samba ports..."
            firewall-cmd --permanent --remove-service=samba 2>/dev/null || true
            firewall-cmd --permanent --remove-service=samba-client 2>/dev/null || true
            firewall-cmd --permanent --remove-port=139/tcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=445/tcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=137/udp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=138/udp 2>/dev/null || true
            firewall-cmd --reload 2>/dev/null || true
            echo " - firewalld configured to block Samba ports"
        fi
    fi
    
    # Additional iptables rules for non-firewalld systems
    if command -v iptables >/dev/null 2>&1; then
        echo " - Adding iptables rules to block Samba..."
        # Block SMB ports
        iptables -I INPUT -p tcp --dport 139 -j DROP 2>/dev/null || true
        iptables -I INPUT -p tcp --dport 445 -j DROP 2>/dev/null || true
        iptables -I INPUT -p udp --dport 137 -j DROP 2>/dev/null || true
        iptables -I INPUT -p udp --dport 138 -j DROP 2>/dev/null || true
        echo " - iptables rules added (if supported)"
    fi
    
    return 0
}

# Function to verify_samba_removal
verify_samba_removal() {
    echo "Verifying Samba remediation..."
    
    verification_passed=true
    
    # Check if Samba packages are installed
    samba_packages=("samba" "samba-common" "samba-client")
    for pkg in "${samba_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        fi
    done
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: Samba packages are not installed"
    fi
    
    # Check if Samba services are running
    samba_services=("smb" "nmb" "winbind")
    for service in "${samba_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo "FAIL: $service.service is running"
            verification_passed=false
        else
            echo "PASS: $service.service is not running"
        fi
    done
    
    # Check if Samba services are enabled or masked
    for service in "${samba_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                    echo "PASS: $service.service is masked"
                else
                    echo "FAIL: $service.service is enabled"
                    verification_passed=false
                fi
            else
                echo "PASS: $service.service is not enabled"
            fi
        fi
    done
    
    # Check for Samba processes
    running_processes=0
    for process in smbd nmbd winbindd; do
        if pgrep "$process" >/dev/null 2>&1; then
            running_processes=$((running_processes + 1))
            echo "FAIL: $process process is running"
            verification_passed=false
        fi
    done
    
    if [ "$running_processes" -eq 0 ]; then
        echo "PASS: No Samba processes running"
    fi
    
    # Check for Samba network services
    if ss -tulpn 2>/dev/null | grep -E ':139 |:445 ' | grep -E '(smbd|samba)'; then
        echo "FAIL: Samba network services detected"
        verification_passed=false
    else
        echo "PASS: No Samba network services detected"
    fi
    
    # Check for Samba in authentication
    if grep -q "winbind" /etc/nsswitch.conf 2>/dev/null; then
        echo "WARNING: winbind still configured in /etc/nsswitch.conf"
        # Not necessarily a failure, but should be noted
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current Samba status..."
    echo ""

    # Check current Samba status
    check_samba_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable Samba
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING SAMBA FILE SERVER SERVICES"
    echo "==================================================================="
    echo ""

    # Stop Samba services first
    if ! stop_samba_services; then
        echo " - WARNING: Some issues stopping Samba services"
    fi
    echo ""

    # Try to remove Samba packages
    if remove_samba_packages "$pkg_mgr"; then
        echo " - Package removal attempted"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking services instead"
        removal_method="masked"
    fi
    echo ""

    # Mask and disable services (especially if package removal failed)
    if [ "$removal_method" = "masked" ]; then
        if mask_samba_services; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        if disable_samba_services; then
            echo " - Service disabling successful"
        fi
    fi
    echo ""

    # Cleanup configuration files
    cleanup_samba_configs
    echo ""

    # Block network ports
    block_samba_ports
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_samba_removal; then
        echo ""
        echo "SUCCESS: Samba file server services have been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ Samba packages removed"
        else
            echo "✓ Samba services masked and disabled"
        fi
        echo "✓ Samba services stopped"
        echo "✓ Samba processes terminated"
        echo "✓ Configuration files disabled"
        echo "✓ Authentication configurations cleaned"
        echo "✓ Network ports blocked"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: Samba remediation may not be complete"
        echo "Some Samba components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining Samba processes: ps aux | grep -E '(smbd|nmbd|winbindd)'"
        echo "2. Verify Samba services are masked: systemctl list-unit-files | grep -E '(smb|nmb|winbind)'"
        echo "3. Manually remove Samba packages if needed"
        echo "4. Check network ports: ss -tulpn | grep -E ':139|:445'"
        echo "5. Verify no Samba configuration files remain in /etc/samba*"
        echo "6. Check /etc/nsswitch.conf and remove any winbind references"
        echo "7. Review PAM configurations in /etc/pam.d/ for winbind references"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Packages installed: $(if command -v rpm >/dev/null && rpm -q samba >/dev/null 2>&1; then echo "YES"; elif command -v dpkg >/dev/null && dpkg -l samba >/dev/null 2>&1; then echo "YES"; else echo "NO"; fi)"
    echo "Services running: $(systemctl is-active smb 2>/dev/null || echo "NO")"
    echo "Services enabled: $(systemctl is-enabled smb 2>/dev/null || echo "NO")"
    echo "Processes running: $( (pgrep smbd 2>/dev/null | wc -l; pgrep nmbd 2>/dev/null | wc -l; pgrep winbindd 2>/dev/null | wc -l) | awk '{sum+=$1} END {print sum}')"
    echo "Network port 139: $(ss -tulpn 2>/dev/null | grep -c ':139 ' || echo "0")"
    echo "Network port 445: $(ss -tulpn 2>/dev/null | grep -c ':445 ' || echo "0")"
    echo "Winbind in nsswitch: $(grep -c winbind /etc/nsswitch.conf 2>/dev/null || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="