#!/usr/bin/env bash
# Script: 2.2.18.sh
# Item: 2.2.18 Ensure web server services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures web server services (httpd/nginx) are not in use by removing or masking httpd.socket, httpd.service, nginx.service, and related packages. FORCE VERSION - Comprehensive web server removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.18.sh"
ITEM_NAME="2.2.18 Ensure web server services are not in use (Automated)"
DESCRIPTION="This remediation ensures web server services (httpd/nginx) are not in use by removing or masking httpd.socket, httpd.service, nginx.service, and related packages. FORCE VERSION - Comprehensive web server removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_websrv_status() {
  echo "Checking web server status..."
  local services=(httpd.service httpd.socket nginx.service)
  local packages=(httpd nginx)
  for svc in "${services[@]}"; do
    if systemctl is-active $svc >/dev/null 2>&1; then
      echo " - $svc is active."
    fi
    if systemctl is-enabled $svc >/dev/null 2>&1; then
      echo " - $svc is enabled."
    fi
  done
  for pkg in "${packages[@]}"; do
    if rpm -q $pkg >/dev/null 2>&1; then
      echo " - $pkg package is installed."
    fi
  done
  if ss -tulpn 2>/dev/null | grep -Eq ':80|:443'; then
    echo " - Web server ports 80/443 are open."
  fi
}

stop_websrv_services() {
  echo "Stopping httpd.socket, httpd.service, nginx.service..."
  systemctl stop httpd.socket httpd.service nginx.service 2>/dev/null || true
  pkill -TERM httpd 2>/dev/null || true
  pkill -KILL httpd 2>/dev/null || true
  pkill -TERM nginx 2>/dev/null || true
  pkill -KILL nginx 2>/dev/null || true
}

remove_websrv_packages() {
  local pkg_mgr="$1"
  local packages=(httpd nginx)
  echo "Removing httpd and nginx packages if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    for pkg in "${packages[@]}"; do
      $pkg_mgr remove -y $pkg 2>/dev/null || echo " - WARNING: Could not remove $pkg (may be a dependency)."
    done
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_websrv_services() {
  echo "Masking httpd.socket, httpd.service, nginx.service..."
  systemctl mask httpd.socket httpd.service nginx.service 2>/dev/null || true
}

verify_websrv_removal() {
  echo "Verifying web server remediation..."
  local failed=false
  local services=(httpd.socket httpd.service nginx.service)
  local packages=(httpd nginx)
  for pkg in "${packages[@]}"; do
    if rpm -q $pkg >/dev/null 2>&1; then
      echo "FAIL: $pkg package is still installed."
      failed=true
    fi
  done
  for svc in "${services[@]}"; do
    if systemctl is-enabled $svc 2>/dev/null | grep -vq masked; then
      echo "FAIL: $svc is not masked."
      failed=true
    fi
    if systemctl is-active $svc 2>/dev/null | grep -vq inactive; then
      echo "FAIL: $svc is still active."
      failed=true
    fi
  done
  if ss -tulpn 2>/dev/null | grep -Eq ':80|:443'; then
    echo "FAIL: Web server ports 80/443 are still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_websrv_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING WEB SERVER SERVICES"
echo "==================================================================="
echo ""

stop_websrv_services
remove_websrv_packages "$PKG_MGR"
mask_websrv_services
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_websrv_removal; then
  echo "SUCCESS: Web server services have been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Services stopped and processes terminated."
  echo "✓ Packages removed or services masked."
  echo "✓ Services will not start at boot."
else
  echo "WARNING: Web server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q httpd nginx"
  echo "2. Ensure services are masked: systemctl status httpd.service httpd.socket nginx.service"
  echo "3. Check ports: ss -tulpn | grep -E ':80|:443'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
