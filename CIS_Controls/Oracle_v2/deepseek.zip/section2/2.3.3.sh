#!/usr/bin/env bash
# Script: 2.3.3.sh
# Item: 2.3.3 Ensure nis client is not installed (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures the NIS client is not installed by removing the ypbind package.

set -euo pipefail

SCRIPT_NAME="2.3.3.sh"
ITEM_NAME="2.3.3 Ensure nis client is not installed (Automated)"
DESCRIPTION="This remediation ensures the NIS client is not installed by removing the ypbind package."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

echo

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_nis_client() {
  echo "Checking for ypbind package..."
  if rpm -q ypbind >/dev/null 2>&1; then
    echo " - ypbind package is installed."
  else
    echo " - ypbind package is not installed."
  fi
}

remove_nis_client() {
  local pkg_mgr="$1"
  echo "Removing ypbind package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y ypbind 2>/dev/null || echo " - WARNING: Could not remove ypbind (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

verify_nis_client_removal() {
  echo "Verifying NIS client remediation..."
  if rpm -q ypbind >/dev/null 2>&1; then
    echo "FAIL: ypbind package is still installed."
    return 1
  else
    echo "PASS: ypbind package is not installed."
    return 0
  fi
}

check_nis_client
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""
remove_nis_client "$PKG_MGR"
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
verify_nis_client_removal
result=$?
if [ $result -eq 0 ]; then
  echo "SUCCESS: ypbind package has been successfully removed."
else
  echo "WARNING: NIS client remediation may not be complete. Manual review recommended."
  echo "1. Verify package removal: rpm -q ypbind"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
