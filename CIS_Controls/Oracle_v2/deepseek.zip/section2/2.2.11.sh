#!/usr/bin/env bash
# Script: 2.2.11.sh
# Item: 2.2.11 Ensure print server services are not in use (Automated)
# Profile Applicability: Level 1 - Server
# Description: This remediation ensures print server services (cups) are not in use by removing or masking the cups.socket and cups.service and cups package. FORCE VERSION - Comprehensive print server removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.11.sh"
ITEM_NAME="2.2.11 Ensure print server services are not in use (Automated)"
DESCRIPTION="This remediation ensures print server services (cups) are not in use by removing or masking the cups.socket and cups.service and cups package. FORCE VERSION - Comprehensive print server removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_cups_status() {
  echo "Checking print server status..."
  if systemctl is-active cups.service >/dev/null 2>&1; then
    echo " - cups.service is active."
  fi
  if systemctl is-active cups.socket >/dev/null 2>&1; then
    echo " - cups.socket is active."
  fi
  if systemctl is-enabled cups.service >/dev/null 2>&1; then
    echo " - cups.service is enabled."
  fi
  if systemctl is-enabled cups.socket >/dev/null 2>&1; then
    echo " - cups.socket is enabled."
  fi
  if rpm -q cups >/dev/null 2>&1; then
    echo " - cups package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':631'; then
    echo " - Print server port 631 is open."
  fi
}

stop_cups_service() {
  echo "Stopping cups.socket and cups.service..."
  systemctl stop cups.socket cups.service 2>/dev/null || true
  pkill -TERM cupsd 2>/dev/null || true
  pkill -KILL cupsd 2>/dev/null || true
}

remove_cups_package() {
  local pkg_mgr="$1"
  echo "Removing cups package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y cups 2>/dev/null || echo " - WARNING: Could not remove cups (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_cups_service() {
  echo "Masking cups.socket and cups.service..."
  systemctl mask cups.socket cups.service 2>/dev/null || true
}

verify_cups_removal() {
  echo "Verifying print server remediation..."
  local failed=false
  if rpm -q cups >/dev/null 2>&1; then
    echo "FAIL: cups package is still installed."
    failed=true
  fi
  for svc in cups.socket cups.service; do
    if systemctl is-enabled $svc 2>/dev/null | grep -vq masked; then
      echo "FAIL: $svc is not masked."
      failed=true
    fi
    if systemctl is-active $svc 2>/dev/null | grep -vq inactive; then
      echo "FAIL: $svc is still active."
      failed=true
    fi
  done
  if ss -tulpn 2>/dev/null | grep -Eq ':631'; then
    echo "FAIL: Print server port 631 is still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_cups_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING PRINT SERVER SERVICE"
echo "==================================================================="
echo ""

stop_cups_service
remove_cups_package "$PKG_MGR"
mask_cups_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_cups_removal; then
  echo "SUCCESS: Print server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: Print server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q cups"
  echo "2. Ensure services are masked: systemctl status cups.service cups.socket"
  echo "3. Check port: ss -tulpn | grep ':631'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
