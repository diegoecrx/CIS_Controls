#!/usr/bin/env bash
# Script: 6.2.1.sh
# Item: 6.2.1 Ensure accounts in /etc/passwd use shadowed passwords (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.1.sh"
ITEM_NAME="6.2.1 Ensure accounts in /etc/passwd use shadowed passwords (Automated)"
DESCRIPTION="This remediation ensures all accounts in /etc/passwd use shadowed passwords."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check for unshadowed passwords
check_shadowed_passwords() {
    echo "Checking for accounts using unshadowed passwords..."
    
    # Check if any accounts have non-'x' or non-'*' in password field
    unshadowed=$(awk -F: '($2 != "x" && $2 != "*" && $2 != "!") {print $1":"$2}' /etc/passwd || true)
    
    if [ -z "$unshadowed" ]; then
        echo "PASS: All accounts use shadowed passwords"
        echo "PROOF: No unshadowed passwords found in /etc/passwd"
        return 0
    else
        echo "FAIL: Found accounts with unshadowed passwords:"
        echo "$unshadowed" | while read -r line; do
            user=$(echo "$line" | awk -F: '{print $1}')
            echo "  - $user"
        done
        return 1
    fi
}
# Function to fix unshadowed passwords
fix_shadowed_passwords() {
    echo "Migrating unshadowed passwords to shadow..."
    
    # Run pwconv to migrate passwords to shadow
    pwconv 2>/dev/null || true
    
    echo " - Executed pwconv to migrate passwords to /etc/shadow"
    
    # Verify all password fields are now 'x'
    awk -F: '($2 != "x" && $2 != "*" && $2 != "!") {print $1}' /etc/passwd | while read -r user; do
        echo "WARNING: Account $user still has unshadowed password after pwconv"
        echo "  - Locking this account for manual investigation"
        usermod -L "$user" 2>/dev/null || true
    done
}
# Main remediation
{
    shadow_ok=true
    if ! check_shadowed_passwords; then
        shadow_ok=false
    fi
    if [ "$shadow_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_shadowed_passwords
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_shadowed_passwords; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: All accounts use shadowed passwords"
    else
        echo "FAIL: Issues remain - manual investigation may be required"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
