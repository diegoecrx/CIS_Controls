#!/usr/bin/env bash
# Script: 6.2.6.sh
# Item: 6.2.6 Ensure no duplicate user names exist (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.6.sh"
ITEM_NAME="6.2.6 Ensure no duplicate user names exist (Automated)"
DESCRIPTION="This remediation ensures no duplicate user names exist in /etc/passwd."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for duplicate user names in /etc/passwd..."
    
    # Check if /etc/passwd exists
    if [ ! -f /etc/passwd ]; then
        echo "FAIL: /etc/passwd does not exist"
        echo "PROOF: File /etc/passwd not found"
        return 1
    fi
    
    # Find duplicate usernames
    duplicate_usernames=()
    while read -r username; do
        # Count occurrences of this username
        count=$(grep -c "^$username:" /etc/passwd)
        if [ "$count" -gt 1 ]; then
            duplicate_usernames+=("$username:$count")
        fi
    done < <(awk -F: '{print $1}' /etc/passwd | sort | uniq -d)
    
    if [ ${#duplicate_usernames[@]} -gt 0 ]; then
        echo "FAIL: Duplicate user names found"
        echo "PROOF: Usernames with multiple entries:"
        for entry in "${duplicate_usernames[@]}"; do
            username=$(echo "$entry" | cut -d: -f1)
            count=$(echo "$entry" | cut -d: -f2)
            echo "  $username: $count occurrences"
            
            # Show the duplicate entries
            echo "    Entries:"
            grep "^$username:" /etc/passwd | while IFS=: read -r user pass uid gid gecos home shell; do
                echo "      UID: $uid, Home: $home, Shell: $shell"
            done
        done
        return 1
    fi
    
    echo "PASS: No duplicate user names found"
    echo "PROOF: All usernames in /etc/passwd are unique"
    return 0
}
# Function to fix
fix_duplicate_usernames() {
    echo "Applying fix..."
    
    # Check if /etc/passwd exists
    if [ ! -f /etc/passwd ]; then
        echo " - ERROR: /etc/passwd does not exist - cannot proceed"
        return 1
    fi
    
    echo " - Scanning /etc/passwd for duplicate usernames..."
    
    # Find duplicate usernames
    duplicate_usernames=()
    while read -r username; do
        count=$(grep -c "^$username:" /etc/passwd)
        if [ "$count" -gt 1 ]; then
            duplicate_usernames+=("$username")
        fi
    done < <(awk -F: '{print $1}' /etc/passwd | sort | uniq -d)
    
    if [ ${#duplicate_usernames[@]} -eq 0 ]; then
        echo " - No duplicate usernames found"
        return 0
    fi
    
    echo " - Found ${#duplicate_usernames[@]} duplicate usernames"
    
    # Create backup of /etc/passwd
    cp /etc/passwd /etc/passwd.backup.$(date +%Y%m%d_%H%M%S)
    echo " - Created backup of /etc/passwd"
    
    # Process each duplicate username
    for username in "${duplicate_usernames[@]}"; do
        echo " - Processing duplicate username: $username"
        
        # Get all entries for this username
        entries=()
        while IFS=: read -r user pass uid gid gecos home shell; do
            entries+=("$user:$pass:$uid:$gid:$gecos:$home:$shell")
        done < <(grep "^$username:" /etc/passwd)
        
        if [ ${#entries[@]} -gt 1 ]; then
            echo " - Found ${#entries[@]} entries for username: $username"
            
            # Keep the first entry as-is, rename the others
            first_entry="${entries[0]}"
            echo " - Keeping first entry: $first_entry"
            
            # Remove all entries for this username
            grep -v "^$username:" /etc/passwd > /tmp/passwd.tmp
            
            # Add back the first entry
            echo "$first_entry" >> /tmp/passwd.tmp
            
            # Rename and add the duplicate entries
            for ((i=1; i<${#entries[@]}; i++)); do
                entry="${entries[$i]}"
                IFS=: read -r user pass uid gid gecos home shell <<< "$entry"
                
                # Create new unique username
                new_username="${username}_dup${i}"
                counter=1
                while grep -q "^$new_username:" /tmp/passwd.tmp; do
                    new_username="${username}_dup${i}_${counter}"
                    ((counter++))
                done
                
                echo " - Renaming duplicate entry to: $new_username (UID: $uid)"
                
                # Add renamed entry
                echo "$new_username:$pass:$uid:$gid:$gecos:$home:$shell" >> /tmp/passwd.tmp
                
                # Update corresponding entries in /etc/shadow if it exists
                if [ -f /etc/shadow ] && grep -q "^$username:" /etc/shadow; then
                    # For shadow file, we need to be careful as there might be multiple shadow entries too
                    # We'll update based on the assumption that shadow entries correspond to passwd entries
                    echo " - Note: Manual review of /etc/shadow may be required for user $new_username"
                fi
                
                # Update corresponding entries in /etc/group if user has a private group
                if grep -q "^$username:" /etc/group; then
                    sed -i "s/^$username:/$new_username:/" /etc/group
                fi
            done
            
            # Replace /etc/passwd with updated version
            mv /tmp/passwd.tmp /etc/passwd
            chmod 644 /etc/passwd
            chown root:root /etc/passwd
        fi
    done
    
    echo " - Duplicate usernames remediation completed"
    echo " - NOTE: Manual review of /etc/shadow and /etc/group may be required"
    echo " - NOTE: File ownerships will automatically reflect changes due to unique UIDs"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_duplicate_usernames
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: No duplicate user names found"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="