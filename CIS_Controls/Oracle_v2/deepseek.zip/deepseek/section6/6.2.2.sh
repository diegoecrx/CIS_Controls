#!/usr/bin/env bash
# Script: 6.2.2.sh
# Item: 6.2.2 Ensure /etc/shadow password fields are not empty (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.2.sh"
ITEM_NAME="6.2.2 Ensure /etc/shadow password fields are not empty (Automated)"
DESCRIPTION="This remediation ensures /etc/shadow password fields are not empty by locking accounts with empty passwords."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for accounts with empty password fields in /etc/shadow..."
    
    # Check if /etc/shadow exists
    if [ ! -f /etc/shadow ]; then
        echo "FAIL: /etc/shadow does not exist"
        echo "PROOF: File /etc/shadow not found"
        return 1
    fi
    
    # Find accounts with empty password fields
    empty_password_accounts=()
    while IFS=: read -r username password rest; do
        # Skip comments and empty lines
        if [[ "$username" =~ ^#.*$ ]] || [ -z "$username" ]; then
            continue
        fi
        
        # Check if password field is empty
        if [ -z "$password" ]; then
            empty_password_accounts+=("$username")
        fi
    done < /etc/shadow
    
    if [ ${#empty_password_accounts[@]} -gt 0 ]; then
        echo "FAIL: Accounts with empty password fields found"
        echo "PROOF: Accounts with empty passwords:"
        for account in "${empty_password_accounts[@]}"; do
            echo "  $account"
        done
        return 1
    fi
    
    echo "PASS: No accounts with empty password fields found"
    echo "PROOF: All accounts in /etc/shadow have password fields configured"
    return 0
}
# Function to fix
fix_empty_password_fields() {
    echo "Applying fix..."
    
    # Check if /etc/shadow exists
    if [ ! -f /etc/shadow ]; then
        echo " - ERROR: /etc/shadow does not exist - cannot proceed"
        return 1
    fi
    
    echo " - Scanning /etc/shadow for accounts with empty password fields..."
    
    # Find and lock accounts with empty password fields
    empty_password_accounts=()
    while IFS=: read -r username password rest; do
        # Skip comments and empty lines
        if [[ "$username" =~ ^#.*$ ]] || [ -z "$username" ]; then
            continue
        fi
        
        # Check if password field is empty
        if [ -z "$password" ]; then
            empty_password_accounts+=("$username")
        fi
    done < /etc/shadow
    
    if [ ${#empty_password_accounts[@]} -eq 0 ]; then
        echo " - No accounts with empty password fields found"
        return 0
    fi
    
    echo " - Found ${#empty_password_accounts[@]} accounts with empty password fields"
    
    for account in "${empty_password_accounts[@]}"; do
        echo " - Processing account: $account"
        
        # Check if account is currently logged in
        if who | grep -q "^$account "; then
            echo " - WARNING: Account $account is currently logged in"
            echo " - Consider investigating active sessions before locking"
        fi
        
        # Lock the account
        echo " - Locking account: $account"
        if passwd -l "$account" >/dev/null 2>&1; then
            echo " - Successfully locked account: $account"
        else
            echo " - Warning: Failed to lock account: $account"
        fi
    done
    
    echo " - Empty password fields remediation completed"
    echo " - NOTE: Locked accounts should be investigated to determine their purpose"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_empty_password_fields
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: No accounts with empty password fields found"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="