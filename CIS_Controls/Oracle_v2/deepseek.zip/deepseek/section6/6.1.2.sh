#!/usr/bin/env bash
# Script: 6.1.2.sh
# Item: 6.1.2 Ensure permissions on /etc/passwd- are configured (Automated)
set -euo pipefail
SCRIPT_NAME="6.1.2.sh"
ITEM_NAME="6.1.2 Ensure permissions on /etc/passwd- are configured (Automated)"
DESCRIPTION="This remediation ensures permissions on /etc/passwd- are configured correctly (0644 root:root)."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/passwd- permissions and ownership..."
    
    # Check if /etc/passwd- exists
    if [ ! -f /etc/passwd- ]; then
        echo "PASS: /etc/passwd- does not exist"
        echo "PROOF: Backup file /etc/passwd- not found (acceptable)"
        return 0
    fi
    
    # Get current permissions, owner, and group
    current_perms=$(stat -c "%a" /etc/passwd-)
    current_owner=$(stat -c "%U" /etc/passwd-)
    current_group=$(stat -c "%G" /etc/passwd-)
    
    # Check permissions (should be 0644)
    if [ "$current_perms" != "644" ]; then
        echo "FAIL: /etc/passwd- has incorrect permissions"
        echo "PROOF: Current permissions are $current_perms (should be 644)"
        return 1
    fi
    
    # Check owner (should be root)
    if [ "$current_owner" != "root" ]; then
        echo "FAIL: /etc/passwd- has incorrect owner"
        echo "PROOF: Current owner is $current_owner (should be root)"
        return 1
    fi
    
    # Check group (should be root)
    if [ "$current_group" != "root" ]; then
        echo "FAIL: /etc/passwd- has incorrect group"
        echo "PROOF: Current group is $current_group (should be root)"
        return 1
    fi
    
    echo "PASS: /etc/passwd- permissions and ownership properly configured"
    echo "PROOF: Access: (0644/-rw-r--r--) Uid: (0/root) Gid: (0/root)"
    return 0
}
# Function to fix
fix_passwd_backup_permissions() {
    echo "Applying fix..."
    
    # Check if /etc/passwd- exists
    if [ ! -f /etc/passwd- ]; then
        echo " - /etc/passwd- does not exist - no action needed"
        return 0
    fi
    
    # Get current status for reporting
    current_perms=$(stat -c "%a" /etc/passwd-)
    current_owner=$(stat -c "%U" /etc/passwd-)
    current_group=$(stat -c "%G" /etc/passwd-)
    
    echo " - Current status: permissions=$current_perms owner=$current_owner group=$current_group"
    
    # Fix permissions (remove execute for user, write for group and other)
    echo " - Setting correct permissions on /etc/passwd-"
    chmod u-x,go-wx /etc/passwd-
    
    # Fix ownership
    echo " - Setting correct ownership on /etc/passwd-"
    chown root:root /etc/passwd-
    
    # Verify changes
    new_perms=$(stat -c "%a" /etc/passwd-)
    new_owner=$(stat -c "%U" /etc/passwd-)
    new_group=$(stat -c "%G" /etc/passwd-)
    
    echo " - New status: permissions=$new_perms owner=$new_owner group=$new_group"
    echo " - /etc/passwd- permissions and ownership configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_passwd_backup_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: /etc/passwd- permissions and ownership properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="