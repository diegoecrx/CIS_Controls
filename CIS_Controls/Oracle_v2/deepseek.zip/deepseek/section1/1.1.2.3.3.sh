#!/usr/bin/env bash

# Script: 1.1.2.3.3_v2.sh
# Item: 1.1.2.3.3 Ensure nosuid option set on /home partition (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.3.3_v2.sh"
ITEM_NAME="1.1.2.3.3 Ensure nosuid option set on /home partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /home partition. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /home mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /home mount information:"
    mount | grep -E '\s/home\s' || echo "No separate /home mount found"
    echo ""

    # Check if /home is a separate partition
    echo "Checking if /home is a separate partition:"
    home_device=$(df /home --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$home_device" ] && [ -n "$root_device" ] && [ "$home_device" != "$root_device" ]; then
        echo "PASS: /home is on separate partition: $home_device"
        home_is_separate=true
    else
        echo "FAIL: /home is NOT on separate partition"
        echo "PROOF: /home shares device with root filesystem"
        home_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /home partition if needed
    if [ "$home_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /HOME PARTITION WITH nosuid OPTION"
        echo "==================================================================="
        echo ""

        # Call the partition creation script first
        /usr/bin/env bash 1.1.2.3.1_v2.sh
        home_is_separate=true
    fi

    echo "Applying nosuid remediation..."

    # Function to update fstab with nosuid option
    update_fstab_nosuid()
    {
        # Check if /home entry exists in fstab
        if grep -q -E '\s/home\s' /etc/fstab; then
            echo " - Checking /home entry in /etc/fstab for nosuid option"
            
            # Get the current /home entry
            current_entry=$(grep -E '\s/home\s' /etc/fstab)
            
            # Check if nosuid option is already present
            if echo "$current_entry" | grep -q 'nosuid'; then
                echo " - nosuid option already present in /etc/fstab"
                return 0
            else
                echo " - Adding nosuid option to /etc/fstab"
                
                # Create backup of fstab
                cp /etc/fstab /etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)
                
                # Create temporary fstab without /home entry
                grep -v -E '\s/home\s' /etc/fstab > /etc/fstab.tmp
                
                # Add nosuid option to the mount options field (4th field)
                if echo "$current_entry" | grep -q 'defaults,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nosuid,/' | sed 's/,,/,/g')
                else
                    # If no defaults, add nosuid to options
                    updated_entry=$(echo "$current_entry" | awk '{$4=$4",nosuid"; print}')
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /home entry in /etc/fstab with nosuid option"
            fi
        else
            echo " - ERROR: No /home entry found in /etc/fstab"
            return 1
        fi
    }

    # Function to remount /home with nosuid option
    remount_home_nosuid()
    {
        echo " - Checking /home mount for nosuid option"
        
        # Check if /home is mounted as separate filesystem
        if mount | grep -q -E '\s/home\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/home\s')
            
            # Check if nosuid is already set in current mount
            if echo "$mount_line" | grep -q 'nosuid'; then
                echo " - nosuid option already set on current /home mount"
            else
                echo " - Remounting /home with nosuid option"
                # Add nosuid to current options and remount
                if mount -o remount,nosuid /home; then
                    echo " - SUCCESS: /home remounted with nosuid option"
                else
                    echo " - WARNING: Could not remount /home with nosuid option"
                    return 1
                fi
            fi
        else
            echo " - ERROR: /home is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nosuid; then
        remount_home_nosuid
    else
        echo " - Skipping remount due to missing /home configuration"
    fi

    echo ""
    echo "Remediation of nosuid option on /home partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /home is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /home IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "----------------------------------------------------"
    mount_output=$(mount | grep -E '\s/home\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /home is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /home is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nosuid option in current mount
    echo ""
    echo "2. VERIFYING nosuid OPTION IN CURRENT MOUNT:"
    echo "-------------------------------------------"
    mount_line=$(mount | grep -E '\s/home\s' || true)
    if echo "$mount_line" | grep -q 'nosuid'; then
        echo "PASS: nosuid option set on current /home mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nosuid option NOT set on current /home mount"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify nosuid option in fstab
    echo ""
    echo "3. VERIFYING nosuid OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/home\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nosuid'; then
            echo "PASS: nosuid option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nosuid option NOT found in /etc/fstab"
            final_status_pass=false
        fi
    else
        echo "FAIL: No /home entry found in /etc/fstab"
        final_status_pass=false
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        echo "FORCE MODE SUMMARY:"
        echo "==================="
        echo "✓ Separate /home partition created (if needed)"
        echo "✓ nosuid option applied to /home partition"
        echo "✓ Configuration persisted in /etc/fstab"
        echo "✓ Backups created for safety"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="