#!/usr/bin/env bash

# Script: 1.1.2.5.3_v2.sh
# Item: 1.1.2.5.3 Ensure nosuid option set on /var/tmp partition (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.5.3_v2.sh"
ITEM_NAME="1.1.2.5.3 Ensure nosuid option set on /var/tmp partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /var/tmp partition. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /var/tmp mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /var/tmp mount information:"
    mount | grep -E '\s/var/tmp\s' || echo "No separate /var/tmp mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/tmp:"
    grep -E '\s/var/tmp\s' /etc/fstab || echo "No /var/tmp entry in /etc/fstab"
    echo ""

    # Check if /var/tmp is a separate partition
    echo "Checking if /var/tmp is a separate partition:"
    vartmp_device=$(df /var/tmp --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$vartmp_device" ] && [ -n "$var_device" ] && [ "$vartmp_device" != "$var_device" ]; then
        echo "PASS: /var/tmp is on separate partition: $vartmp_device"
        vartmp_is_separate=true
    elif [ -n "$vartmp_device" ] && [ -n "$root_device" ] && [ "$vartmp_device" != "$root_device" ]; then
        echo "PASS: /var/tmp is on separate partition: $vartmp_device"
        vartmp_is_separate=true
    else
        echo "FAIL: /var/tmp is NOT on separate partition"
        if [ -n "$vartmp_device" ]; then
            echo "PROOF: /var/tmp shares device with $vartmp_device"
        else
            echo "PROOF: /var/tmp is not mounted separately"
        fi
        vartmp_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /var/tmp partition if needed
    if [ "$vartmp_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /VAR/TMP PARTITION WITH nosuid OPTION"
        echo "==================================================================="
        echo ""

        # Call the partition creation script first if available
        if [ -f "1.1.2.5.1_v2.sh" ]; then
            /usr/bin/env bash 1.1.2.5.1_v2.sh
        else
            echo " - WARNING: 1.1.2.5.1_v2.sh not found. Creating partition manually with enforced nosuid option..."
            
            # Manual partition creation as fallback
            echo " - Creating backup of /var/tmp to /var_tmp_backup_$(date +%Y%m%d_%H%M%S)..."
            backup_dir="/var_tmp_backup_$(date +%Y%m%d_%H%M%S)"
            mkdir -p "/$backup_dir"
            
            # Backup existing data
            if [ -d "/var/tmp" ] && [ "$(ls -A /var/tmp 2>/dev/null)" ]; then
                echo " - Backing up existing /var/tmp contents..."
                cp -a "/var/tmp"/* "/$backup_dir/" 2>/dev/null || true
            fi
            
            # Create loop device partition
            echo " - Creating 1GB disk image at /var_tmp_partition.img..."
            dd if=/dev/zero of=/var_tmp_partition.img bs=1M count=1024 status=progress
            mkfs.ext4 -F /var_tmp_partition.img
            
            # Mount and setup
            mkdir -p /mnt/newvartmp
            mount -o loop /var_tmp_partition.img /mnt/newvartmp
            chmod 1777 /mnt/newvartmp
            
            # Restore data
            if [ -d "/$backup_dir" ] && [ "$(ls -A /$backup_dir)" ]; then
                echo " - Restoring data to new partition..."
                cp -a "/$backup_dir"/* /mnt/newvartmp/ 2>/dev/null || true
            fi
            
            # Replace /var/tmp
            if [ -d "/var/tmp" ]; then
                mv /var/tmp /var/tmp.old
            fi
            mkdir -p /var/tmp
            umount /mnt/newvartmp
            
            # Mount with STRICT nosuid option
            echo " - Mounting with strict nosuid enforcement..."
            mount -o loop /var_tmp_partition.img /var/tmp
            mount -o remount,nosuid,nodev,noexec /var/tmp
            chmod 1777 /var/tmp
            
            # Update fstab with nosuid option
            cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
            echo "/var_tmp_partition.img /var/tmp ext4 loop,nosuid,nodev,noexec 0 0" >> /etc/fstab
            
            rmdir /mnt/newvartmp
            echo " - SUCCESS: Manual /var/tmp partition creation with enforced nosuid option completed"
        fi
        vartmp_is_separate=true
    fi

    echo "Applying nosuid remediation..."

    # Function to update fstab with nosuid option
    update_fstab_nosuid()
    {
        # Check if /var/tmp entry exists in fstab
        if grep -q -E '\s/var/tmp\s' /etc/fstab; then
            echo " - Checking /var/tmp entry in /etc/fstab for nosuid option"
            
            # Get the current /var/tmp entry
            current_entry=$(grep -E '\s/var/tmp\s' /etc/fstab)
            
            # Check if nosuid option is already present
            if echo "$current_entry" | grep -q 'nosuid'; then
                echo " - nosuid option already present in /etc/fstab"
                return 0
            else
                echo " - Adding nosuid option to /etc/fstab"
                
                # Create backup of fstab
                cp /etc/fstab /etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)
                echo " - Backup created: /etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)"
                
                # Create temporary fstab without /var/tmp entry
                grep -v -E '\s/var/tmp\s' /etc/fstab > /etc/fstab.tmp
                
                # Add nosuid option to the mount options field (4th field)
                if echo "$current_entry" | grep -q 'defaults,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nosuid,/' | sed 's/,,/,/g')
                elif echo "$current_entry" | grep -q 'loop,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/loop,/loop,nosuid,/' | sed 's/,,/,/g')
                else
                    # If no specific options, add nosuid to beginning
                    updated_entry=$(echo "$current_entry" | awk '{$4=$4",nosuid"; print}')
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /var/tmp entry in /etc/fstab with nosuid option"
            fi
        else
            echo " - ERROR: No /var/tmp entry found in /etc/fstab"
            return 1
        fi
    }

    # Function to remount /var/tmp with nosuid option
    remount_vartmp_nosuid()
    {
        echo " - Checking /var/tmp mount for nosuid option"
        
        # Check if /var/tmp is mounted as separate filesystem
        if mount | grep -q -E '\s/var/tmp\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/var/tmp\s')
            
            # Check if nosuid is already set in current mount
            if echo "$mount_line" | grep -q 'nosuid'; then
                echo " - nosuid option shown in mount output"
                
                # Test if nosuid is actually working
                echo " - Testing if nosuid is actually enforced..."
                test_binary="/var/tmp/test_suid_$$"
                
                # Create a simple test binary
                cat > "${test_binary}.c" << 'EOF'
#include <stdio.h>
int main() { printf("Test executed\n"); return 0; }
EOF
                
                if command -v gcc >/dev/null 2>&1; then
                    if gcc -o "$test_binary" "${test_binary}.c" 2>/dev/null; then
                        # Try to set setuid bit
                        if chmod u+s "$test_binary" 2>/dev/null; then
                            # Try to execute as setuid
                            if "$test_binary" 2>/dev/null; then
                                echo " - WARNING: nosuid option shown but setuid execution still works"
                                rm -f "$test_binary" "${test_binary}.c"
                                
                                # Try forceful remount
                                echo " - Attempting forceful remount to enforce nosuid..."
                                if mount -o remount,nosuid,nodev,noexec /var/tmp; then
                                    echo " - SUCCESS: Forceful remount completed"
                                    return 0
                                else
                                    echo " - ERROR: Could not perform forceful remount"
                                    return 1
                                fi
                            else
                                echo " - SUCCESS: nosuid properly enforced - setuid execution blocked"
                                rm -f "$test_binary" "${test_binary}.c"
                                return 0
                            fi
                        else
                            echo " - SUCCESS: nosuid properly enforced - cannot set setuid bit"
                            rm -f "$test_binary" "${test_binary}.c"
                            return 0
                        fi
                    else
                        echo " - INFO: Could not compile test binary, assuming nosuid is working"
                        rm -f "${test_binary}.c"
                        return 0
                    fi
                else
                    echo " - INFO: gcc not available, testing setuid bit setting only..."
                    # Simple test - try to set setuid on existing file
                    test_file="/var/tmp/test_setuid_$$"
                    touch "$test_file"
                    if chmod u+s "$test_file" 2>/dev/null; then
                        echo " - WARNING: nosuid option shown but setuid bit can be set"
                        rm -f "$test_file"
                        # Try forceful remount
                        mount -o remount,nosuid,nodev,noexec /var/tmp
                        return 1
                    else
                        echo " - SUCCESS: nosuid properly enforced - cannot set setuid bit"
                        rm -f "$test_file"
                        return 0
                    fi
                fi
            else
                echo " - nosuid option NOT set on current /var/tmp mount"
                echo " - Remounting /var/tmp with nosuid option"
                # Add nosuid to current options and remount
                if mount -o remount,nosuid /var/tmp; then
                    echo " - SUCCESS: /var/tmp remounted with nosuid option"
                else
                    echo " - WARNING: Could not remount /var/tmp with nosuid option"
                    return 1
                fi
            fi
        else
            echo " - ERROR: /var/tmp is not mounted as separate filesystem"
            return 1
        fi
    }

    # Function to remove existing setuid files from /var/tmp
    remove_setuid_files()
    {
        echo " - Scanning for setuid files in /var/tmp..."
        setuid_files=$(find /var/tmp -type f -perm /4000 2>/dev/null | wc -l)
        if [ "$setuid_files" -gt 0 ]; then
            echo " - WARNING: Found $setuid_files setuid files in /var/tmp"
            echo " - Removing setuid bits for security..."
            find /var/tmp -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null || true
            echo " - SUCCESS: Setuid bits removed from files in /var/tmp"
            
            # Verify removal
            remaining_setuid=$(find /var/tmp -type f -perm /4000 2>/dev/null | wc -l)
            if [ "$remaining_setuid" -gt 0 ]; then
                echo " - WARNING: $remaining_setuid setuid files still remain after removal attempt"
                echo " - Forcing removal with more aggressive method..."
                find /var/tmp -type f -perm /4000 -exec chmod 0755 {} \; 2>/dev/null || true
            fi
        else
            echo " - PASS: No setuid files found in /var/tmp"
        fi
    }

    # Apply remediation steps
    if update_fstab_nosuid; then
        remount_vartmp_nosuid
        remove_setuid_files
    else
        echo " - Skipping remount due to missing /var/tmp configuration"
    fi

    echo ""
    echo "Remediation of nosuid option on /var/tmp partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /var/tmp is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var/tmp IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/var/tmp\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /var/tmp is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /var/tmp is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nosuid option in current mount AND test enforcement
    echo ""
    echo "2. VERIFYING nosuid OPTION ENFORCEMENT:"
    echo "--------------------------------------"
    mount_line=$(mount | grep -E '\s/var/tmp\s' || true)
    if echo "$mount_line" | grep -q 'nosuid'; then
        echo "PASS: nosuid option shown in mount output"
        echo "PROOF (mount output):"
        echo "$mount_line"
        
        # ACTUALLY TEST if nosuid is working
        echo " - Testing actual nosuid enforcement..."
        test_file="/var/tmp/verify_nosuid_$$"
        touch "$test_file"
        
        # Test 1: Try to set setuid bit
        if chmod u+s "$test_file" 2>/dev/null; then
            echo "FAIL: nosuid option shown BUT setuid bit can be set"
            echo "PROOF: chmod u+s succeeded despite nosuid option"
            
            # Test 2: Try to execute a setuid binary if one exists
            if [ -x "$test_file" ]; then
                # Make it executable first
                chmod +x "$test_file"
                # This won't actually do anything but tests if execution is blocked
                if "$test_file" 2>/dev/null; then
                    echo "FAIL: Setuid binary execution succeeded despite nosuid"
                else
                    echo "INFO: Setuid binary cannot execute (may be due to other reasons)"
                fi
            fi
            
            rm -f "$test_file"
            final_status_pass=false
            
            # Try emergency fix
            echo " - Applying emergency fix: unmount and remount..."
            umount /var/tmp 2>/dev/null || true
            mount -o loop,nosuid,nodev,noexec /var_tmp_partition.img /var/tmp
            chmod 1777 /var/tmp
            
            # Test again
            touch "$test_file"
            if chmod u+s "$test_file" 2>/dev/null; then
                echo " - EMERGENCY FIX FAILED: Setuid bit can still be set"
                rm -f "$test_file"
            else
                echo " - EMERGENCY FIX SUCCESS: nosuid now properly enforced"
                rm -f "$test_file"
                final_status_pass=true
            fi
        else
            echo "PASS: nosuid option properly enforced - cannot set setuid bit"
            echo "PROOF: chmod u+s failed as expected with nosuid"
            rm -f "$test_file"
        fi
    else
        echo "FAIL: nosuid option NOT shown in mount output"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify nosuid option in fstab
    echo ""
    echo "3. VERIFYING nosuid OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/var/tmp\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nosuid'; then
            echo "PASS: nosuid option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nosuid option NOT found in /etc/fstab"
            final_status_pass=false
        fi
    else
        echo "FAIL: No /var/tmp entry found in /etc/fstab"
        final_status_pass=false
    fi

    # PROOF 4: Verify no setuid files remain in /var/tmp
    echo ""
    echo "4. VERIFYING NO SETUID FILES IN /var/tmp:"
    echo "----------------------------------------"
    setuid_files=$(find /var/tmp -type f -perm /4000 2>/dev/null | wc -l)
    if [ "$setuid_files" -eq 0 ]; then
        echo "PASS: No setuid files found in /var/tmp"
        echo "PROOF: find /var/tmp -type f -perm /4000 returned 0 files"
    else
        echo "WARNING: Found $setuid_files setuid files in /var/tmp"
        echo " - Forcing removal..."
        find /var/tmp -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null
        final_status_pass=false
    fi

    # PROOF 5: Test with actual binary compilation if gcc available
    echo ""
    echo "5. COMPREHENSIVE SETUID EXECUTION TEST:"
    echo "--------------------------------------"
    if command -v gcc >/dev/null 2>&1; then
        test_binary="/var/tmp/comprehensive_test_$$"
        cat > "${test_binary}.c" << 'EOF'
#include <stdio.h>
#include <unistd.h>
int main() { 
    printf("UID: %d, EUID: %d\n", getuid(), geteuid());
    return 0;
}
EOF
        
        if gcc -o "$test_binary" "${test_binary}.c" 2>/dev/null; then
            chmod +x "$test_binary"
            # Try to set setuid
            if chmod u+s "$test_binary" 2>/dev/null; then
                echo "FAIL: Comprehensive test - can set setuid bit on compiled binary"
                # Try to execute to see if it actually runs with elevated privileges
                output=$("$test_binary" 2>/dev/null || echo "execution_failed")
                echo "Execution output: $output"
                final_status_pass=false
            else
                echo "PASS: Comprehensive test - cannot set setuid bit on compiled binary"
            fi
            rm -f "$test_binary" "${test_binary}.c"
        else
            echo "INFO: Comprehensive test skipped - compilation failed"
            rm -f "${test_binary}.c"
        fi
    else
        echo "INFO: Comprehensive test skipped - gcc not available"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo "nosuid option is properly configured and enforced on /var/tmp"
        echo ""
        echo "FORCE MODE SUMMARY:"
        echo "==================="
        echo "✓ Separate /var/tmp partition created (if needed)"
        echo "✓ nosuid option applied to /var/tmp partition"
        echo "✓ Configuration persisted in /etc/fstab"
        echo "✓ Setuid files removed from /var/tmp"
        echo "✓ nosuid enforcement verified through testing"
        echo "✓ Backups created for safety"
    else
        echo ""
        echo "CRITICAL: nosuid option is not being properly enforced"
        echo "The mount shows nosuid but setuid operations can still be performed."
        echo "This may require manual investigation of the filesystem configuration."
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="