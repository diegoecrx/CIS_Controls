#!/usr/bin/env bash
# Script: 1.4.2.sh
# Item: 1.4.2 Ensure ptrace_scope is restricted (Automated)
set -euo pipefail
SCRIPT_NAME="1.4.2.sh"
ITEM_NAME="1.4.2 Ensure ptrace_scope is restricted (Automated)"
DESCRIPTION="This remediation ensures ptrace_scope is restricted by setting kernel.yama.ptrace_scope=1."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current ptrace_scope status..."
    current_value=$(sysctl kernel.yama.ptrace_scope | awk '{print $3}' || true)
    if [ "$current_value" = "1" ]; then
        echo "PASS: kernel.yama.ptrace_scope is 1"
        echo "PROOF: sysctl output: kernel.yama.ptrace_scope = $current_value"
        return 0
    else
        echo "FAIL: kernel.yama.ptrace_scope is $current_value"
        echo "PROOF: sysctl output: kernel.yama.ptrace_scope = $current_value"
        return 1
    fi
}
# Function to fix
fix_ptrace() {
    echo "Applying fix..."
    conf_file="/etc/sysctl.d/60-kernel_sysctl.conf"
    echo "kernel.yama.ptrace_scope = 1" >> "$conf_file"
    echo " - Added to $conf_file"
    sysctl -w kernel.yama.ptrace_scope=1 >/dev/null 2>&1
    echo " - Applied with sysctl -w"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ptrace
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ptrace_scope restricted"
    else
        echo "FAIL: ptrace_scope not restricted"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="