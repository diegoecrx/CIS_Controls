#!/usr/bin/env bash

# Script: 1.1.2.4.2_v2.sh
# Item: 1.1.2.4.2 Ensure nodev option set on /var partition (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.4.2_v2.sh"
ITEM_NAME="1.1.2.4.2 Ensure nodev option set on /var partition (Automated)"
DESCRIPTION="This remediation ensures the nodev option is set on the /var partition. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /var mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /var mount information:"
    mount | grep -E '\s/var\s' || echo "No separate /var mount found"
    echo ""

    # Check if /var is a separate partition
    echo "Checking if /var is a separate partition:"
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$var_device" ] && [ -n "$root_device" ] && [ "$var_device" != "$root_device" ]; then
        echo "PASS: /var is on separate partition: $var_device"
        var_is_separate=true
    else
        echo "FAIL: /var is NOT on separate partition"
        echo "PROOF: /var shares device with root filesystem"
        var_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /var partition if needed
    if [ "$var_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /VAR PARTITION WITH nodev OPTION"
        echo "==================================================================="
        echo ""

        # Call the partition creation script first
        /usr/bin/env bash 1.1.2.4.1_v2.sh
        var_is_separate=true
    fi

    echo "Applying nodev remediation..."

    # Function to update fstab with nodev option
    update_fstab_nodev()
    {
        # Check if /var entry exists in fstab
        if grep -q -E '\s/var\s' /etc/fstab; then
            echo " - Checking /var entry in /etc/fstab for nodev option"
            
            # Get the current /var entry
            current_entry=$(grep -E '\s/var\s' /etc/fstab)
            
            # Check if nodev option is already present
            if echo "$current_entry" | grep -q 'nodev'; then
                echo " - nodev option already present in /etc/fstab"
                return 0
            else
                echo " - Adding nodev option to /etc/fstab"
                
                # Create backup of fstab
                cp /etc/fstab /etc/fstab.backup.nodev.$(date +%Y%m%d_%H%M%S)
                
                # Create temporary fstab without /var entry
                grep -v -E '\s/var\s' /etc/fstab > /etc/fstab.tmp
                
                # Add nodev option to the mount options field (4th field)
                if echo "$current_entry" | grep -q 'defaults,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nodev,/' | sed 's/,,/,/g')
                else
                    # If no defaults, add nodev to options
                    updated_entry=$(echo "$current_entry" | awk '{$4=$4",nodev"; print}')
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /var entry in /etc/fstab with nodev option"
            fi
        else
            echo " - ERROR: No /var entry found in /etc/fstab"
            return 1
        fi
    }

    # Function to remount /var with nodev option
    remount_var_nodev()
    {
        echo " - Checking /var mount for nodev option"
        
        # Check if /var is mounted as separate filesystem
        if mount | grep -q -E '\s/var\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/var\s')
            
            # Check if nodev is already set in current mount
            if echo "$mount_line" | grep -q 'nodev'; then
                echo " - nodev option already set on current /var mount"
            else
                echo " - Remounting /var with nodev option"
                # Add nodev to current options and remount
                if mount -o remount,nodev /var; then
                    echo " - SUCCESS: /var remounted with nodev option"
                else
                    echo " - WARNING: Could not remount /var with nodev option"
                    return 1
                fi
            fi
        else
            echo " - ERROR: /var is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nodev; then
        remount_var_nodev
    else
        echo " - Skipping remount due to missing /var configuration"
    fi

    echo ""
    echo "Remediation of nodev option on /var partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /var is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "---------------------------------------------------"
    mount_output=$(mount | grep -E '\s/var\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /var is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /var is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nodev option in current mount
    echo ""
    echo "2. VERIFYING nodev OPTION IN CURRENT MOUNT:"
    echo "------------------------------------------"
    mount_line=$(mount | grep -E '\s/var\s' || true)
    if echo "$mount_line" | grep -q 'nodev'; then
        echo "PASS: nodev option set on current /var mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nodev option NOT set on current /var mount"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify nodev option in fstab
    echo ""
    echo "3. VERIFYING nodev OPTION IN /etc/fstab:"
    echo "---------------------------------------"
    fstab_entry=$(grep -E '\s/var\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nodev'; then
            echo "PASS: nodev option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nodev option NOT found in /etc/fstab"
            final_status_pass=false
        fi
    else
        echo "FAIL: No /var entry found in /etc/fstab"
        final_status_pass=false
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        echo "FORCE MODE SUMMARY:"
        echo "==================="
        echo "✓ Separate /var partition created (if needed)"
        echo "✓ nodev option applied to /var partition"
        echo "✓ Configuration persisted in /etc/fstab"
        echo "✓ Backups created for safety"
        echo ""
        echo "SECURITY BENEFITS FOR /var:"
        echo "• Prevents device file creation in system directories"
        echo "• Blocks potential device-based attacks on logs and data"
        echo "• Enhances system security by limiting device creation"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="