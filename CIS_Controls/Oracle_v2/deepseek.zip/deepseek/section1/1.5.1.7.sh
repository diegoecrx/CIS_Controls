#!/usr/bin/env bash
# Script: 1.5.1.7.sh
# Item: 1.5.1.7 Ensure the MCS Translation Service (mcstrans) is not installed (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.7.sh"
ITEM_NAME="1.5.1.7 Ensure the MCS Translation Service (mcstrans) is not installed (Automated)"
DESCRIPTION="This remediation ensures mcstrans is not installed using yum remove."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking if mcstrans is installed..."
    if rpm -q mcstrans >/dev/null 2>&1; then
        echo "FAIL: mcstrans is installed"
        echo "PROOF: $(rpm -q mcstrans)"
        return 1
    else
        echo "PASS: mcstrans is not installed"
        echo "PROOF: rpm -q mcstrans returned not installed"
        return 0
    fi
}
# Function to uninstall
uninstall_mcstrans() {
    echo "Uninstalling mcstrans..."
    yum remove -y mcstrans >/dev/null 2>&1
    echo " - Removed mcstrans"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        uninstall_mcstrans
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: mcstrans not installed"
    else
        echo "FAIL: mcstrans still installed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="