#!/usr/bin/env bash

# Script: 1.1.2.1.3.sh
# Item: 1.1.2.1.3 Ensure nosuid option set on /tmp partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.1.3.sh"
ITEM_NAME="1.1.2.1.3 Ensure nosuid option set on /tmp partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /tmp partition to prevent execution of setuid programs."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /tmp mount options..."
    echo ""

    # Display current mount status and options
    echo "Current /tmp mount information:"
    mount | grep -E '\s/tmp\s' || echo "No separate /tmp mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /tmp:"
    grep -E '\s/tmp\s' /etc/fstab || echo "No /tmp entry in /etc/fstab"
    echo ""

    echo "Applying remediation..."

    # Function to update fstab with nosuid option
    update_fstab_nosuid()
    {
        # Check if /tmp entry exists in fstab
        if grep -q -E '\s/tmp\s' /etc/fstab; then
            echo " - Updating /tmp entry in /etc/fstab to include nosuid option"
            
            # Get the current /tmp entry
            current_entry=$(grep -E '\s/tmp\s' /etc/fstab)
            
            # Check if nosuid option is already present
            if echo "$current_entry" | grep -q -E '(^|[[:space:]])nosuid([[:space:]]|$)'; then
                echo " - nosuid option already present in /etc/fstab"
                return 0
            fi
            
            # Create temporary fstab without /tmp entry
            grep -v -E '\s/tmp\s' /etc/fstab > /etc/fstab.tmp
            
            # Add nosuid option to the mount options field (4th field)
            updated_entry=$(echo "$current_entry" | awk '
            {
                for(i=1; i<=NF; i++) {
                    if(i==4) {
                        # Add nosuid to mount options if not already present
                        if($i ~ /nosuid/) {
                            print $0
                        } else {
                            # Handle options with and without commas
                            if($i ~ /,$/) {
                                gsub(/,$/, "", $i)
                                $i = $i ",nosuid"
                            } else {
                                $i = $i ",nosuid"
                            }
                            # Reconstruct the line
                            for(j=1; j<=NF; j++) {
                                printf "%s", $j
                                if(j<NF) printf " "
                            }
                            printf "\n"
                        }
                    }
                }
            }')
            
            # If awk processing failed, use sed as fallback
            if [ -z "$updated_entry" ]; then
                updated_entry=$(echo "$current_entry" | sed -E 's/(\sdefaults,?|\s[rw]+,?)([^[:space:]]*)/\1nosuid,\2/' | sed 's/,,/,/g')
            fi
            
            echo "$updated_entry" >> /etc/fstab.tmp
            
            # Backup original and replace
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo " - SUCCESS: Updated /tmp entry in /etc/fstab with nosuid option"
        else
            echo " - WARNING: No /tmp entry found in /etc/fstab. Please ensure /tmp is configured as separate partition first."
            return 1
        fi
    }

    # Function to remount /tmp with nosuid option
    remount_tmp_nosuid()
    {
        echo " - Remounting /tmp with nosuid option"
        
        # Check if /tmp is mounted as separate filesystem
        if mount | grep -q -E '\s/tmp\s'; then
            # Get current mount options
            current_opts=$(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' | tr -d '()')
            
            # Check if nosuid is already set in current mount
            if echo "$current_opts" | grep -q -E '(^|[[:space:]],)nosuid([[:space:]],|$)'; then
                echo " - nosuid option already set on current /tmp mount"
            else
                # Add nosuid to current options and remount
                if mount -o remount,nosuid /tmp; then
                    echo " - SUCCESS: /tmp remounted with nosuid option"
                else
                    echo " - WARNING: Could not remount /tmp with nosuid option"
                    return 1
                fi
            fi
        else
            echo " - WARNING: /tmp is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nosuid; then
        remount_tmp_nosuid
    else
        echo " - Skipping remount due to missing /tmp configuration"
    fi

    echo ""
    echo "Remediation of nosuid option on /tmp partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /tmp is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /tmp IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "---------------------------------------------------"
    mount_output=$(mount | grep -E '\s/tmp\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /tmp is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /tmp is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nosuid option in current mount
    echo ""
    echo "2. VERIFYING nosuid OPTION IN CURRENT MOUNT:"
    echo "-------------------------------------------"
    mount_options=$(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' || true)
    if echo "$mount_options" | grep -q -E '(^|[[:space:]],)nosuid([[:space:]],|$)'; then
        echo "PASS: nosuid option set on current /tmp mount"
        echo "PROOF (mount options):"
        echo "$mount_options"
    else
        echo "FAIL: nosuid option NOT set on current /tmp mount - attempting remount"
        if mount -o remount,nosuid /tmp 2>/dev/null; then
            mount_options=$(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' || true)
            if echo "$mount_options" | grep -q -E '(^|[[:space:]],)nosuid([[:space:]],|$)'; then
                echo "PASS: nosuid option now set on /tmp mount"
                echo "PROOF (mount options):"
                echo "$mount_options"
            else
                echo "FAIL: Could not set nosuid option on /tmp mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /tmp with nosuid option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nosuid option in fstab
    echo ""
    echo "3. VERIFYING nosuid OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/tmp\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q -E '(^|[[:space:]])nosuid([[:space:]]|$)'; then
            echo "PASS: nosuid option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nosuid option NOT found in /etc/fstab - updating now"
            # Remove existing entry
            grep -v -E '\s/tmp\s' /etc/fstab > /etc/fstab.tmp
            # Add nosuid to mount options (4th field)
            updated_entry=$(echo "$fstab_entry" | awk '
            {
                for(i=1; i<=NF; i++) {
                    if(i==4) {
                        if($i ~ /nosuid/) {
                            print $0
                        } else {
                            if($i ~ /,$/) {
                                gsub(/,$/, "", $i)
                                $i = $i ",nosuid"
                            } else {
                                $i = $i ",nosuid"
                            }
                            for(j=1; j<=NF; j++) {
                                printf "%s", $j
                                if(j<NF) printf " "
                            }
                            printf "\n"
                        }
                    }
                }
            }')
            echo "$updated_entry" >> /etc/fstab.tmp
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nosuid option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/tmp\s' /etc/fstab
        fi
    else
        echo "FAIL: No /tmp entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_options=$(grep -E '\s/tmp\s' /etc/fstab | awk '{print $4}' | grep -o 'nosuid' || true)
    mount_options=$(mount | grep -E '\s/tmp\s' | grep -o 'nosuid' || true)
    
    if [ -n "$fstab_options" ] && [ -n "$mount_options" ]; then
        echo "PASS: nosuid option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab: $(grep -E '\s/tmp\s' /etc/fstab | awk '{print $4}')"
        echo "  mount: $(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_options" ] && [ -z "$mount_options" ]; then
        echo "FAIL: nosuid in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_options" ] && [ -n "$mount_options" ]; then
        echo "FAIL: nosuid in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nosuid option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Verify nosuid effectiveness by checking for setuid files
    echo ""
    echo "5. VERIFYING NO SETUID FILES IN /tmp:"
    echo "------------------------------------"
    setuid_files=$(find /tmp -type f -perm /4000 2>/dev/null | wc -l)
    if [ "$setuid_files" -eq 0 ]; then
        echo "PASS: No setuid files found in /tmp"
        echo "PROOF: find /tmp -type f -perm /4000 returned 0 files"
    else
        echo "WARNING: Found $setuid_files setuid files in /tmp"
        echo "PROOF (first 5 setuid files):"
        find /tmp -type f -perm /4000 2>/dev/null | head -5
        echo " - Removing setuid bits from files in /tmp"
        find /tmp -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null || true
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="