#!/usr/bin/env bash

# Script: 1.1.2.1.2.sh
# Item: 1.1.2.1.2 Ensure nodev option set on /tmp partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.1.2.sh"
ITEM_NAME="1.1.2.1.2 Ensure nodev option set on /tmp partition (Automated)"
DESCRIPTION="This remediation ensures the nodev option is set on the /tmp partition to prevent device files."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /tmp mount options..."
    echo ""

    # Display current mount status and options
    echo "Current /tmp mount information:"
    mount | grep -E '\s/tmp\s' || echo "No separate /tmp mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /tmp:"
    grep -E '\s/tmp\s' /etc/fstab || echo "No /tmp entry in /etc/fstab"
    echo ""

    echo "Applying remediation..."

    # Function to update fstab with nodev option
    update_fstab_nodev()
    {
        # Check if /tmp entry exists in fstab
        if grep -q -E '\s/tmp\s' /etc/fstab; then
            echo " - Updating /tmp entry in /etc/fstab to include nodev option"
            
            # Get the current /tmp entry
            current_entry=$(grep -E '\s/tmp\s' /etc/fstab)
            
            # Check if nodev option is already present
            if echo "$current_entry" | grep -q -E '(^|[[:space:]])nodev([[:space:]]|$)'; then
                echo " - nodev option already present in /etc/fstab"
                return 0
            fi
            
            # Create temporary fstab without /tmp entry
            grep -v -E '\s/tmp\s' /etc/fstab > /etc/fstab.tmp
            
            # Add nodev option to the mount options field (4th field)
            updated_entry=$(echo "$current_entry" | awk '
            {
                for(i=1; i<=NF; i++) {
                    if(i==4) {
                        # Add nodev to mount options if not already present
                        if($i ~ /nodev/) {
                            print $0
                        } else {
                            # Handle options with and without commas
                            if($i ~ /,$/) {
                                gsub(/,$/, "", $i)
                                $i = $i ",nodev"
                            } else {
                                $i = $i ",nodev"
                            }
                            # Reconstruct the line
                            for(j=1; j<=NF; j++) {
                                printf "%s", $j
                                if(j<NF) printf " "
                            }
                            printf "\n"
                        }
                    }
                }
            }')
            
            # If awk processing failed, use sed as fallback
            if [ -z "$updated_entry" ]; then
                updated_entry=$(echo "$current_entry" | sed -E 's/(\sdefaults,?|\s[rw]+,?)([^[:space:]]*)/\1nodev,\2/' | sed 's/,,/,/g')
            fi
            
            echo "$updated_entry" >> /etc/fstab.tmp
            
            # Backup original and replace
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo " - SUCCESS: Updated /tmp entry in /etc/fstab with nodev option"
        else
            echo " - WARNING: No /tmp entry found in /etc/fstab. Please ensure /tmp is configured as separate partition first."
            return 1
        fi
    }

    # Function to remount /tmp with nodev option
    remount_tmp_nodev()
    {
        echo " - Remounting /tmp with nodev option"
        
        # Check if /tmp is mounted as separate filesystem
        if mount | grep -q -E '\s/tmp\s'; then
            # Get current mount options
            current_opts=$(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' | tr -d '()')
            
            # Check if nodev is already set in current mount
            if echo "$current_opts" | grep -q -E '(^|[[:space:]],)nodev([[:space:]],|$)'; then
                echo " - nodev option already set on current /tmp mount"
            else
                # Add nodev to current options and remount
                if mount -o remount,nodev /tmp; then
                    echo " - SUCCESS: /tmp remounted with nodev option"
                else
                    echo " - WARNING: Could not remount /tmp with nodev option"
                    return 1
                fi
            fi
        else
            echo " - WARNING: /tmp is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nodev; then
        remount_tmp_nodev
    else
        echo " - Skipping remount due to missing /tmp configuration"
    fi

    echo ""
    echo "Remediation of nodev option on /tmp partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /tmp is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /tmp IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "---------------------------------------------------"
    mount_output=$(mount | grep -E '\s/tmp\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /tmp is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /tmp is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nodev option in current mount
    echo ""
    echo "2. VERIFYING nodev OPTION IN CURRENT MOUNT:"
    echo "------------------------------------------"
    mount_options=$(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' || true)
    if echo "$mount_options" | grep -q -E '(^|[[:space:]],)nodev([[:space:]],|$)'; then
        echo "PASS: nodev option set on current /tmp mount"
        echo "PROOF (mount options):"
        echo "$mount_options"
    else
        echo "FAIL: nodev option NOT set on current /tmp mount - attempting remount"
        if mount -o remount,nodev /tmp 2>/dev/null; then
            mount_options=$(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' || true)
            if echo "$mount_options" | grep -q -E '(^|[[:space:]],)nodev([[:space:]],|$)'; then
                echo "PASS: nodev option now set on /tmp mount"
                echo "PROOF (mount options):"
                echo "$mount_options"
            else
                echo "FAIL: Could not set nodev option on /tmp mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /tmp with nodev option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nodev option in fstab
    echo ""
    echo "3. VERIFYING nodev OPTION IN /etc/fstab:"
    echo "---------------------------------------"
    fstab_entry=$(grep -E '\s/tmp\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q -E '(^|[[:space:]])nodev([[:space:]]|$)'; then
            echo "PASS: nodev option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nodev option NOT found in /etc/fstab - updating now"
            # Remove existing entry
            grep -v -E '\s/tmp\s' /etc/fstab > /etc/fstab.tmp
            # Add nodev to mount options (4th field)
            updated_entry=$(echo "$fstab_entry" | awk '
            {
                for(i=1; i<=NF; i++) {
                    if(i==4) {
                        if($i ~ /nodev/) {
                            print $0
                        } else {
                            if($i ~ /,$/) {
                                gsub(/,$/, "", $i)
                                $i = $i ",nodev"
                            } else {
                                $i = $i ",nodev"
                            }
                            for(j=1; j<=NF; j++) {
                                printf "%s", $j
                                if(j<NF) printf " "
                            }
                            printf "\n"
                        }
                    }
                }
            }')
            echo "$updated_entry" >> /etc/fstab.tmp
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nodev option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/tmp\s' /etc/fstab
        fi
    else
        echo "FAIL: No /tmp entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_options=$(grep -E '\s/tmp\s' /etc/fstab | awk '{print $4}' | grep -o 'nodev' || true)
    mount_options=$(mount | grep -E '\s/tmp\s' | grep -o 'nodev' || true)
    
    if [ -n "$fstab_options" ] && [ -n "$mount_options" ]; then
        echo "PASS: nodev option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab: $(grep -E '\s/tmp\s' /etc/fstab | awk '{print $4}')"
        echo "  mount: $(mount | grep -E '\s/tmp\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_options" ] && [ -z "$mount_options" ]; then
        echo "FAIL: nodev in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_options" ] && [ -n "$mount_options" ]; then
        echo "FAIL: nodev in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nodev option missing in both fstab and current mount"
        final_status_pass=false
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="