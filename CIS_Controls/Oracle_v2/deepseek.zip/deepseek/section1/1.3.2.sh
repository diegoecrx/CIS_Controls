#!/usr/bin/env bash
# Script: 1.3.2.sh
# Item: 1.3.2 Ensure permissions on bootloader config are configured (Automated)
set -euo pipefail
SCRIPT_NAME="1.3.2.sh"
ITEM_NAME="1.3.2 Ensure permissions on bootloader config are configured (Automated)"
DESCRIPTION="This remediation ensures permissions on bootloader config are configured."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to detect bootloader type
detect_bootloader_type() {
    if [ -d "/sys/firmware/efi" ]; then
        echo "UEFI"
    else
        echo "BIOS"
    fi
}
# Function to fix UEFI
fix_uefi() {
    echo "Fixing UEFI bootloader config..."
    fstab_line=$(grep -E '\s/boot/efi\s' /etc/fstab || true)
    if [ -n "$fstab_line" ]; then
        if echo "$fstab_line" | grep -q 'fmask=0077' && echo "$fstab_line" | grep -q 'uid=0' && echo "$fstab_line" | grep -q 'gid=0'; then
            echo " - Options already set"
        else
            sed -i '/\s\/boot\/efi\s/s/defaults/defaults,umask=0027,fmask=0077,uid=0,gid=0/' /etc/fstab
            echo " - Updated /etc/fstab"
            echo "Note: Reboot may be required"
        fi
    else
        echo " - No /boot/efi entry in fstab"
    fi
}
# Function to fix BIOS
fix_bios() {
    echo "Fixing BIOS bootloader config..."
    for file in /boot/grub2/grub.cfg /boot/grub2/grubenv /boot/grub2/user.cfg; do
        if [ -f "$file" ]; then
            chown root:root "$file"
            chmod u-x,go-rwx "$file"
            echo " - Fixed $file"
        fi
    done
}
# Function to check current status
check_current_status() {
    bootloader_type=$(detect_bootloader_type)
    echo "Bootloader type: $bootloader_type"
    echo ""
    if [ "$bootloader_type" = "UEFI" ]; then
        echo "/etc/fstab for /boot/efi:"
        grep -E '\s/boot/efi\s' /etc/fstab || echo "No entry"
    else
        for file in /boot/grub2/grub.cfg /boot/grub2/grubenv /boot/grub2/user.cfg; do
            if [ -f "$file" ]; then
                echo "$file permissions:"
                ls -l "$file"
            fi
        done
    fi
}
# Main remediation
{
    check_current_status
    echo ""
    echo "Applying remediation..."
    bootloader_type=$(detect_bootloader_type)
    if [ "$bootloader_type" = "UEFI" ]; then
        fix_uefi
    else
        fix_bios
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    bootloader_type=$(detect_bootloader_type)
    if [ "$bootloader_type" = "UEFI" ]; then
        fstab_line=$(grep -E '\s/boot/efi\s' /etc/fstab || true)
        if echo "$fstab_line" | grep -q 'fmask=0077' && echo "$fstab_line" | grep -q 'uid=0' && echo "$fstab_line" | grep -q 'gid=0'; then
            echo "PASS: UEFI options set"
            echo "PROOF: $fstab_line"
        else
            echo "FAIL: UEFI options not set"
            echo "PROOF: $fstab_line"
            final_pass=false
        fi
    else
        for file in /boot/grub2/grub.cfg /boot/grub2/grubenv /boot/grub2/user.cfg; do
            if [ -f "$file" ]; then
                perm=$(stat -c '%a %U %G' "$file")
                if [ "$(echo $perm | awk '{print $1}')" = "600" ] && [ "$(echo $perm | awk '{print $2}')" = "root" ] && [ "$(echo $perm | awk '{print $3}')" = "root" ]; then
                    echo "PASS: $file permissions correct"
                    echo "PROOF: $perm"
                else
                    echo "FAIL: $file permissions incorrect"
                    echo "PROOF: $perm"
                    final_pass=false
                fi
            fi
        done
    fi
    echo ""
    echo "==================================================================="
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Permissions configured"
    else
        echo "WARNING: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="