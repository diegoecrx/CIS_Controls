#!/usr/bin/env bash
# Script: 2.2.19.sh
# Item: 2.2.19 Ensure xinetd services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures xinetd services are not in use by removing or masking the xinetd.service and xinetd package. FORCE VERSION - Comprehensive xinetd removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.19.sh"
ITEM_NAME="2.2.19 Ensure xinetd services are not in use (Automated)"
DESCRIPTION="This remediation ensures xinetd services are not in use by removing or masking the xinetd.service and xinetd package. FORCE VERSION - Comprehensive xinetd removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_xinetd_status() {
  echo "Checking xinetd service status..."
  if systemctl is-active xinetd.service >/dev/null 2>&1; then
    echo " - xinetd.service is active."
  fi
  if systemctl is-enabled xinetd.service >/dev/null 2>&1; then
    echo " - xinetd.service is enabled."
  fi
  if rpm -q xinetd >/dev/null 2>&1; then
    echo " - xinetd package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -i xinetd | grep -q LISTEN; then
    echo " - xinetd is listening on some port."
  fi
}

stop_xinetd_service() {
  echo "Stopping xinetd.service..."
  systemctl stop xinetd.service 2>/dev/null || true
  pkill -TERM xinetd 2>/dev/null || true
  pkill -KILL xinetd 2>/dev/null || true
}

remove_xinetd_package() {
  local pkg_mgr="$1"
  echo "Removing xinetd package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y xinetd 2>/dev/null || echo " - WARNING: Could not remove xinetd (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_xinetd_service() {
  echo "Masking xinetd.service..."
  systemctl mask xinetd.service 2>/dev/null || true
}

verify_xinetd_removal() {
  echo "Verifying xinetd service remediation..."
  local failed=false
  if rpm -q xinetd >/dev/null 2>&1; then
    echo "FAIL: xinetd package is still installed."
    failed=true
  fi
  if systemctl is-enabled xinetd.service 2>/dev/null | grep -vq masked; then
    echo "FAIL: xinetd.service is not masked."
    failed=true
  fi
  if systemctl is-active xinetd.service 2>/dev/null | grep -vq inactive; then
    echo "FAIL: xinetd.service is still active."
    failed=true
  fi
  if ss -tulpn 2>/dev/null | grep -i xinetd | grep -q LISTEN; then
    echo "FAIL: xinetd is still listening on some port."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_xinetd_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING XINETD SERVICE"
echo "==================================================================="
echo ""

stop_xinetd_service
remove_xinetd_package "$PKG_MGR"
mask_xinetd_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_xinetd_removal; then
  echo "SUCCESS: xinetd service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: xinetd remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q xinetd"
  echo "2. Ensure service is masked: systemctl status xinetd.service"
  echo "3. Check for listening state using: ss -tulpn | grep -i xinetd"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
