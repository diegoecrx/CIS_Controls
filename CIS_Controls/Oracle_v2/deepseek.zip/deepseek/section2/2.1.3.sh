#!/usr/bin/env bash

# Script: 2.1.3_v2.sh
# Item: 2.1.3 Ensure chrony is not run as the root user (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.1.3_v2.sh"
ITEM_NAME="2.1.3 Ensure chrony is not run as the root user (Automated)"
DESCRIPTION="This remediation ensures chrony is not run as the root user. FORCE VERSION - Configures chrony to run as non-root user."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check_chrony_installation
check_chrony_installation() {
    echo "Checking chrony installation..."
    
    if ! command -v chronyd >/dev/null 2>&1; then
        echo "FAIL: chrony is not installed"
        return 1
    fi
    
    echo "PASS: chrony is installed"
    return 0
}

# Function to create_chrony_user
create_chrony_user() {
    echo "Ensuring chrony user exists..."
    
    # Check if chrony user exists
    if getent passwd chrony >/dev/null 2>&1; then
        echo " - chrony user already exists"
        return 0
    fi
    
    # Create chrony user and group
    echo " - Creating chrony user and group..."
    
    # Check if useradd supports system user creation
    if useradd --help 2>&1 | grep -q -- --system; then
        useradd --system --no-create-home --shell /sbin/nologin chrony 2>/dev/null || \
        useradd -r -s /sbin/nologin chrony 2>/dev/null
    else
        useradd -r -s /sbin/nologin chrony 2>/dev/null
    fi
    
    # Verify user creation
    if getent passwd chrony >/dev/null 2>&1; then
        echo " - SUCCESS: chrony user created"
        return 0
    else
        echo "ERROR: Failed to create chrony user"
        return 1
    fi
}

# Function to configure_sysconfig_chronyd
configure_sysconfig_chronyd() {
    echo "Configuring /etc/sysconfig/chronyd..."
    
    # Create directory if it doesn't exist
    mkdir -p /etc/sysconfig
    
    # Backup existing file
    if [ -f "/etc/sysconfig/chronyd" ]; then
        cp /etc/sysconfig/chronyd "/etc/sysconfig/chronyd.backup.$(date +%Y%m%d_%H%M%S)"
        echo " - Backup created: /etc/sysconfig/chronyd.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Check if OPTIONS line exists
    if grep -q '^OPTIONS=' /etc/sysconfig/chronyd 2>/dev/null; then
        # Replace existing OPTIONS line
        sed -i 's/^OPTIONS=.*/OPTIONS="-u chrony"/' /etc/sysconfig/chronyd
        echo " - Updated existing OPTIONS line"
    else
        # Add OPTIONS line
        echo 'OPTIONS="-u chrony"' >> /etc/sysconfig/chronyd
        echo " - Added OPTIONS line"
    fi
    
    # Ensure the file has proper permissions
    chmod 644 /etc/sysconfig/chronyd
    chown root:root /etc/sysconfig/chronyd
    
    echo " - /etc/sysconfig/chronyd configured with OPTIONS=\"-u chrony\""
}

# Function to configure_systemd_service
configure_systemd_service() {
    echo "Configuring systemd service for chrony..."
    
    # Check if systemd service file exists
    if [ ! -f "/usr/lib/systemd/system/chronyd.service" ] && [ ! -f "/lib/systemd/system/chronyd.service" ]; then
        echo " - WARNING: chronyd systemd service file not found in standard locations"
        return 1
    fi
    
    # Find the service file
    service_file=""
    for location in "/usr/lib/systemd/system/chronyd.service" "/lib/systemd/system/chronyd.service"; do
        if [ -f "$location" ]; then
            service_file="$location"
            break
        fi
    done
    
    if [ -z "$service_file" ]; then
        echo " - ERROR: Could not find chronyd systemd service file"
        return 1
    fi
    
    echo " - Found service file: $service_file"
    
    # Backup service file
    cp "$service_file" "${service_file}.backup.$(date +%Y%m%d_%H%M%S)"
    
    # Check if service already runs as non-root
    if grep -q '^User=chrony' "$service_file" && grep -q '^Group=chrony' "$service_file"; then
        echo " - Service already configured to run as chrony user"
        return 0
    fi
    
    # Configure service to run as chrony user
    if grep -q '^\[Service\]' "$service_file"; then
        # Remove any existing User/Group directives
        sed -i '/^User=/d; /^Group=/d' "$service_file"
        
        # Add User and Group directives after [Service] line
        sed -i '/^\[Service\]/a\User=chrony\nGroup=chrony' "$service_file"
        echo " - Added User=chrony and Group=chrony to service file"
    else
        echo " - WARNING: Could not find [Service] section in service file"
        return 1
    fi
    
    # Reload systemd
    systemctl daemon-reload
    echo " - Systemd daemon reloaded"
}

# Function to set_chrony_permissions
set_chrony_permissions() {
    echo "Setting proper file permissions for chrony user..."
    
    # Set ownership on chrony directories and files
    directories=(
        "/var/lib/chrony"
        "/var/log/chrony"
        "/run/chrony"
        "/etc/chrony.keys"
    )
    
    for dir in "${directories[@]}"; do
        if [ -e "$dir" ]; then
            if [ -f "$dir" ]; then
                # It's a file
                if getent group chrony >/dev/null 2>&1; then
                    chown chrony:chrony "$dir" 2>/dev/null || true
                else
                    chown chrony "$dir" 2>/dev/null || true
                fi
            else
                # It's a directory
                if getent group chrony >/dev/null 2>&1; then
                    chown chrony:chrony "$dir" 2>/dev/null || true
                else
                    chown chrony "$dir" 2>/dev/null || true
                fi
            fi
            echo " - Set ownership on: $dir"
        fi
    done
    
    # Set specific permissions on key files
    if [ -f "/etc/chrony.keys" ]; then
        chmod 640 /etc/chrony.keys
        echo " - Set permissions on /etc/chrony.keys to 640"
    fi
    
    if [ -f "/etc/chrony.conf" ]; then
        chmod 644 /etc/chrony.conf
        echo " - Set permissions on /etc/chrony.conf to 644"
    fi
    
    # Ensure chrony can write to its directories
    if [ -d "/var/lib/chrony" ]; then
        chmod 755 /var/lib/chrony
    fi
    
    if [ -d "/var/log/chrony" ]; then
        chmod 755 /var/log/chrony
    fi
}

# Function to restart_chrony_service
restart_chrony_service() {
    echo "Restarting chrony service..."
    
    # Try to reload first (if supported)
    if systemctl try-reload-or-restart chronyd 2>&1; then
        echo " - Service reloaded successfully"
    else
        echo " - Reload failed, attempting full restart..."
        if systemctl restart chronyd 2>&1; then
            echo " - Service restarted successfully"
        else
            echo " - WARNING: Service restart failed"
            return 1
        fi
    fi
    
    # Wait for service to stabilize
    sleep 3
    
    # Check service status
    if systemctl is-active chronyd >/dev/null 2>&1; then
        echo " - chronyd service is running"
        return 0
    else
        echo " - ERROR: chronyd service is not running after restart"
        return 1
    fi
}

# Function to verify_chrony_user
verify_chrony_user() {
    echo "Verifying chrony is running as non-root user..."
    
    # Check if chronyd process is running
    if ! pgrep chronyd >/dev/null 2>&1; then
        echo "FAIL: chronyd process not found"
        return 1
    fi
    
    # Get the user running chronyd
    chronyd_pid=$(pgrep chronyd | head -1)
    if [ -z "$chronyd_pid" ]; then
        echo "FAIL: Could not find chronyd PID"
        return 1
    fi
    
    chronyd_user=$(ps -o user= -p "$chronyd_pid" | tr -d ' ')
    
    if [ "$chronyd_user" = "root" ]; then
        echo "FAIL: chronyd is running as root"
        return 1
    elif [ "$chronyd_user" = "chrony" ]; then
        echo "PASS: chronyd is running as chrony user"
        return 0
    else
        echo "WARNING: chronyd is running as $chronyd_user (not root, but not chrony)"
        return 0  # Still acceptable as long as it's not root
    fi
}

# Function to verify_sysconfig
verify_sysconfig() {
    echo "Verifying /etc/sysconfig/chronyd configuration..."
    
    if [ ! -f "/etc/sysconfig/chronyd" ]; then
        echo "FAIL: /etc/sysconfig/chronyd does not exist"
        return 1
    fi
    
    if grep -q '^OPTIONS="-u chrony"' /etc/sysconfig/chronyd; then
        echo "PASS: OPTIONS=\"-u chrony\" found in /etc/sysconfig/chronyd"
        return 0
    else
        echo "FAIL: OPTIONS=\"-u chrony\" not found in /etc/sysconfig/chronyd"
        return 1
    fi
}

# Function to verify_systemd_config
verify_systemd_config() {
    echo "Verifying systemd service configuration..."
    
    # Find service file
    service_file=""
    for location in "/usr/lib/systemd/system/chronyd.service" "/lib/systemd/system/chronyd.service"; do
        if [ -f "$location" ]; then
            service_file="$location"
            break
        fi
    done
    
    if [ -z "$service_file" ]; then
        echo "INFO: Could not find chronyd systemd service file for verification"
        return 0
    fi
    
    if grep -q '^User=chrony' "$service_file" && grep -q '^Group=chrony' "$service_file"; then
        echo "PASS: systemd service configured with User=chrony and Group=chrony"
        return 0
    else
        echo "INFO: systemd service not explicitly configured for chrony user (relying on OPTIONS)"
        return 0
    fi
}

# Main remediation function
{
    echo "Checking current chrony configuration..."
    echo ""

    # Check if chrony is installed
    if ! check_chrony_installation; then
        echo "ERROR: chrony must be installed first. Please run 2.1.1 and 2.1.2 remediation scripts."
        exit 1
    fi

    # Check current running user
    echo "Checking current chrony process user..."
    if verify_chrony_user; then
        echo "PASS: chrony is already running as non-root user"
        current_user_correct=true
    else
        echo "FAIL: chrony is running as root or not running"
        current_user_correct=false
    fi

    echo ""

    # FORCE MODE: Configure chrony to run as non-root
    echo "==================================================================="
    echo "FORCE MODE: CONFIGURING CHRONY TO RUN AS NON-ROOT USER"
    echo "==================================================================="
    echo ""

    # Create chrony user if needed
    if ! create_chrony_user; then
        echo "ERROR: Failed to create chrony user"
        exit 1
    fi
    echo ""

    # Configure /etc/sysconfig/chronyd
    configure_sysconfig_chronyd
    echo ""

    # Configure systemd service (if available)
    if configure_systemd_service; then
        echo " - Systemd service configured"
    else
        echo " - Using sysconfig method only"
    fi
    echo ""

    # Set file permissions
    set_chrony_permissions
    echo ""

    # Restart chrony service
    if restart_chrony_service; then
        echo " - Service restarted successfully"
    else
        echo " - WARNING: Service restart had issues"
    fi
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    verification_passed=true

    # Verify chrony is running as non-root
    if verify_chrony_user; then
        echo "PASS: chrony is running as non-root user"
    else
        echo "FAIL: chrony is still running as root"
        verification_passed=false
    fi
    echo ""

    # Verify sysconfig
    if verify_sysconfig; then
        echo "PASS: /etc/sysconfig/chronyd properly configured"
    else
        echo "FAIL: /etc/sysconfig/chronyd not properly configured"
        verification_passed=false
    fi
    echo ""

    # Verify systemd config
    verify_systemd_config
    echo ""

    # Show current process information
    echo "Current chrony process information:"
    if pgrep chronyd >/dev/null; then
        chronyd_pid=$(pgrep chronyd | head -1)
        echo " - PID: $chronyd_pid"
        echo " - User: $(ps -o user= -p "$chronyd_pid" | tr -d ' ')"
        echo " - Command: $(ps -o command= -p "$chronyd_pid")"
    else
        echo " - No chronyd process found"
    fi
    echo ""

    # Final status
    echo "==================================================================="
    if [ "$verification_passed" = true ]; then
        echo "SUCCESS: chrony is properly configured to run as non-root user"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        echo "✓ chrony user created and configured"
        echo "✓ /etc/sysconfig/chronyd configured with OPTIONS=\"-u chrony\""
        echo "✓ Systemd service configured (if applicable)"
        echo "✓ File permissions set for chrony user"
        echo "✓ Service running as non-root user"
        echo "✓ Time synchronization maintained"
    else
        echo "PARTIAL SUCCESS: Some configurations applied but verification failed"
        echo ""
        echo "RECOMMENDED ACTIONS:"
        echo "==================="
        echo "1. Check system logs: journalctl -u chronyd"
        echo "2. Verify chrony user exists: getent passwd chrony"
        echo "3. Manually restart chronyd: systemctl restart chronyd"
        echo "4. Check process: ps aux | grep chronyd"
    fi

    # Show configuration summary
    echo ""
    echo "CONFIGURATION SUMMARY:"
    echo "====================="
    echo "chrony user: $(getent passwd chrony 2>/dev/null | cut -d: -f3 || echo 'Not found')"
    echo "Service status: $(systemctl is-active chronyd 2>/dev/null || echo 'unknown')"
    echo "Running as user: $(ps -o user= -p $(pgrep chronyd 2>/dev/null | head -1) 2>/dev/null | tr -d ' ' || echo 'unknown')"
    echo "OPTIONS in sysconfig: $(grep '^OPTIONS=' /etc/sysconfig/chronyd 2>/dev/null || echo 'Not set')"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="