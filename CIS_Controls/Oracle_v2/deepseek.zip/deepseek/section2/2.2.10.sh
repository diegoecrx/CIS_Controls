#!/usr/bin/env bash
# Script: 2.2.10.sh
# Item: 2.2.10 Ensure nis server services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures NIS server services are not in use by removing or masking the ypserv.service and ypserv package. FORCE VERSION - Comprehensive NIS server removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.10.sh"
ITEM_NAME="2.2.10 Ensure nis server services are not in use (Automated)"
DESCRIPTION="This remediation ensures NIS server services are not in use by removing or masking the ypserv.service and ypserv package. FORCE VERSION - Comprehensive NIS server removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_nis_status() {
  echo "Checking NIS server status..."
  if systemctl is-active ypserv.service >/dev/null 2>&1; then
    echo " - ypserv.service is active."
  fi
  if systemctl is-enabled ypserv.service >/dev/null 2>&1; then
    echo " - ypserv.service is enabled."
  fi
  if rpm -q ypserv >/dev/null 2>&1; then
    echo " - ypserv package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':111'; then
    echo " - NIS port 111 is open (rpcbind)."
  fi
}

stop_nis_service() {
  echo "Stopping ypserv.service..."
  systemctl stop ypserv.service 2>/dev/null || true
  pkill -TERM ypserv 2>/dev/null || true
  pkill -KILL ypserv 2>/dev/null || true
}

remove_nis_package() {
  local pkg_mgr="$1"
  echo "Removing ypserv package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y ypserv 2>/dev/null || echo " - WARNING: Could not remove ypserv (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_nis_service() {
  echo "Masking ypserv.service..."
  systemctl mask ypserv.service 2>/dev/null || true
}

verify_nis_removal() {
  echo "Verifying NIS server remediation..."
  local failed=false
  if rpm -q ypserv >/dev/null 2>&1; then
    echo "FAIL: ypserv package is still installed."
    failed=true
  fi
  if systemctl is-enabled ypserv.service 2>/dev/null | grep -vq masked; then
    echo "FAIL: ypserv.service is not masked."
    failed=true
  fi
  if systemctl is-active ypserv.service 2>/dev/null | grep -vq inactive; then
    echo "FAIL: ypserv.service is still active."
    failed=true
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':111'; then
    echo "FAIL: NIS port 111 is still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_nis_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING NIS SERVER SERVICE"
echo "==================================================================="
echo ""

stop_nis_service
remove_nis_package "$PKG_MGR"
mask_nis_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_nis_removal; then
  echo "SUCCESS: NIS server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: NIS server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q ypserv"
  echo "2. Ensure service is masked: systemctl status ypserv.service"
  echo "3. Check port: ss -tulpn | grep ':111'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
