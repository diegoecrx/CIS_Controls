#!/usr/bin/env bash
# Script: 5.2.3.3.sh
# Item: 5.2.3.3 Ensure events that modify the sudo log file are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.3.sh"
ITEM_NAME="5.2.3.3 Ensure events that modify the sudo log file are collected (Automated)"
DESCRIPTION="This remediation ensures events that modify the sudo log file are collected by configuring audit rules."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking sudo log file audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Find sudo log file configuration
    SUDO_LOG_FILE=$(grep -r logfile /etc/sudoers* 2>/dev/null | sed -e 's/.*logfile=//;s/,.*$//' -e 's/"//g' | head -1)
    
    if [ -z "$SUDO_LOG_FILE" ]; then
        echo "PASS: No sudo log file configured"
        echo "PROOF: No logfile setting found in sudoers configuration"
        return 0
    fi
    
    # Check for sudo log file audit rules in running configuration
    if ! auditctl -l | grep -q "\-w $SUDO_LOG_FILE \-p wa \-k sudo_log_file"; then
        echo "FAIL: sudo log file audit rules not found in running configuration"
        echo "PROOF: Required audit rule for $SUDO_LOG_FILE not present in auditctl -l output"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "\-w $SUDO_LOG_FILE \-p wa \-k sudo_log_file" /etc/audit/rules.d/ >/dev/null 2>&1; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: sudo log file audit rules not found in configuration files"
        echo "PROOF: Required audit rule for $SUDO_LOG_FILE not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: sudo log file audit rules properly configured"
    echo "PROOF: Audit rule for sudo log file $SUDO_LOG_FILE found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_sudo_log_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Find sudo log file configuration
    SUDO_LOG_FILE=$(grep -r logfile /etc/sudoers* 2>/dev/null | sed -e 's/.*logfile=//;s/,.*$//' -e 's/"//g' | head -1)
    
    if [ -z "$SUDO_LOG_FILE" ]; then
        echo " - No sudo log file configured in sudoers, no audit rule needed"
        return
    fi
    
    echo " - Found sudo log file: $SUDO_LOG_FILE"
    
    # Check if rule already exists in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "\-w $SUDO_LOG_FILE \-p wa \-k sudo_log_file" /etc/audit/rules.d/ >/dev/null 2>&1; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating sudo log file audit rules in /etc/audit/rules.d/50-sudo.rules"
        cat > /etc/audit/rules.d/50-sudo.rules << EOF
## Monitor events that modify the sudo log file
-w ${SUDO_LOG_FILE} -p wa -k sudo_log_file
EOF
    else
        echo " - Sudo log file audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - sudo log file audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_sudo_log_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: sudo log file audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="