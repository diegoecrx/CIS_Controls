#!/usr/bin/env bash
# Script: 5.2.3.5.sh
# Item: 5.2.3.5 Ensure events that modify the system's network environment are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.5.sh"
ITEM_NAME="5.2.3.5 Ensure events that modify the system's network environment are collected (Automated)"
DESCRIPTION="This remediation ensures events that modify the system's network environment are collected by configuring audit rules."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking network environment modification audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check for system-locale audit rules in running configuration
    system_locale_rules_found=true
    
    # Check b64 rule (for 64-bit systems)
    if [[ "$arch" == "x86_64" ]]; then
        if ! auditctl -l | grep -q '\-a always,exit \-F arch=b64 \-S sethostname,setdomainname \-k system-locale'; then
            system_locale_rules_found=false
        fi
    fi
    
    # Check b32 rule
    if ! auditctl -l | grep -q '\-a always,exit \-F arch=b32 \-S sethostname,setdomainname \-k system-locale'; then
        system_locale_rules_found=false
    fi
    
    # Check file watch rules
    required_files=(
        "/etc/issue"
        "/etc/issue.net"
        "/etc/hosts"
        "/etc/sysconfig/network"
        "/etc/sysconfig/network-scripts/"
    )
    
    for file in "${required_files[@]}"; do
        if ! auditctl -l | grep -q "\-w $file \-p wa \-k system-locale"; then
            system_locale_rules_found=false
            break
        fi
    done
    
    if [ "$system_locale_rules_found" = false ]; then
        echo "FAIL: system-locale audit rules not found in running configuration"
        echo "PROOF: Required audit rules not present in auditctl -l output"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        b32_rule_found=false
        b64_rule_found=true
        files_rules_found=true
        
        if grep -r '\-a always,exit \-F arch=b32 \-S sethostname,setdomainname \-k system-locale' /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_rule_found=true
        fi
        
        if [[ "$arch" == "x86_64" ]]; then
            if ! grep -r '\-a always,exit \-F arch=b64 \-S sethostname,setdomainname \-k system-locale' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_rule_found=false
            fi
        fi
        
        for file in "${required_files[@]}"; do
            if ! grep -r "\-w $file \-p wa \-k system-locale" /etc/audit/rules.d/ >/dev/null 2>&1; then
                files_rules_found=false
                break
            fi
        done
        
        if [ "$b32_rule_found" = true ] && [ "$b64_rule_found" = true ] && [ "$files_rules_found" = true ]; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: system-locale audit rules not found in configuration files"
        echo "PROOF: Required audit rules not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: network environment modification audit rules properly configured"
    echo "PROOF: All required system-locale audit rules found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_system_locale_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        b32_exists=false
        b64_exists=true
        files_exists=true
        
        if grep -r '\-a always,exit \-F arch=b32 \-S sethostname,setdomainname \-k system-locale' /etc/audit/rules.d/ >/dev/null 2>&1; then
            b32_exists=true
        fi
        
        if [[ "$arch" == "x86_64" ]]; then
            if ! grep -r '\-a always,exit \-F arch=b64 \-S sethostname,setdomainname \-k system-locale' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_exists=false
            fi
        fi
        
        required_files=(
            "/etc/issue"
            "/etc/issue.net"
            "/etc/hosts"
            "/etc/sysconfig/network"
            "/etc/sysconfig/network-scripts/"
        )
        
        for file in "${required_files[@]}"; do
            if ! grep -r "\-w $file \-p wa \-k system-locale" /etc/audit/rules.d/ >/dev/null 2>&1; then
                files_exists=false
                break
            fi
        done
        
        if [ "$b32_exists" = true ] && [ "$b64_exists" = true ] && [ "$files_exists" = true ]; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating system-locale audit rules in /etc/audit/rules.d/50-system_locale.rules"
        
        if [[ "$arch" == "x86_64" ]]; then
            # 64-bit system - create rules for both b64 and b32
            cat > /etc/audit/rules.d/50-system_locale.rules << 'EOF'
## Monitor events that modify the system's network environment
-a always,exit -F arch=b64 -S sethostname,setdomainname -k system-locale
-a always,exit -F arch=b32 -S sethostname,setdomainname -k system-locale
-w /etc/issue -p wa -k system-locale
-w /etc/issue.net -p wa -k system-locale
-w /etc/hosts -p wa -k system-locale
-w /etc/sysconfig/network -p wa -k system-locale
-w /etc/sysconfig/network-scripts/ -p wa -k system-locale
EOF
        else
            # 32-bit system - create rule for b32 only
            cat > /etc/audit/rules.d/50-system_locale.rules << 'EOF'
## Monitor events that modify the system's network environment
-a always,exit -F arch=b32 -S sethostname,setdomainname -k system-locale
-w /etc/issue -p wa -k system-locale
-w /etc/issue.net -p wa -k system-locale
-w /etc/hosts -p wa -k system-locale
-w /etc/sysconfig/network -p wa -k system-locale
-w /etc/sysconfig/network-scripts/ -p wa -k system-locale
EOF
        fi
    else
        echo " - System-locale audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - system-locale audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_system_locale_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: network environment modification audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="