#!/usr/bin/env bash
# Script: 5.2.3.4.sh
# Item: 5.2.3.4 Ensure events that modify date and time information are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.4.sh"
ITEM_NAME="5.2.3.4 Ensure events that modify date and time information are collected (Automated)"
DESCRIPTION="This remediation ensures events that modify date and time information are collected by configuring audit rules."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking date and time modification audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check for time-change audit rules in running configuration
    time_change_rules_found=true
    
    # Check b64 rule (for 64-bit systems)
    if [[ "$arch" == "x86_64" ]]; then
        if ! auditctl -l | grep -q '\-a always,exit \-F arch=b64 \-S adjtimex,settimeofday,clock_settime \-k time-change'; then
            time_change_rules_found=false
        fi
    fi
    
    # Check b32 rule with appropriate system calls
    if [[ "$arch" == "x86_64" ]]; then
        # 64-bit system - check for b32 rule without stime
        if ! auditctl -l | grep -q '\-a always,exit \-F arch=b32 \-S adjtimex,settimeofday,clock_settime \-k time-change'; then
            time_change_rules_found=false
        fi
    else
        # 32-bit system - check for b32 rule with stime
        if ! auditctl -l | grep -q '\-a always,exit \-F arch=b32 \-S adjtimex,settimeofday,clock_settime,stime \-k time-change'; then
            time_change_rules_found=false
        fi
    fi
    
    # Check /etc/localtime rule
    if ! auditctl -l | grep -q '\-w /etc/localtime \-p wa \-k time-change'; then
        time_change_rules_found=false
    fi
    
    if [ "$time_change_rules_found" = false ]; then
        echo "FAIL: time-change audit rules not found in running configuration"
        echo "PROOF: Required audit rules not present in auditctl -l output"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        b32_rule_found=false
        b64_rule_found=true
        localtime_rule_found=false
        
        if [[ "$arch" == "x86_64" ]]; then
            if grep -r '\-a always,exit \-F arch=b32 \-S adjtimex,settimeofday,clock_settime \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b32_rule_found=true
            fi
            if ! grep -r '\-a always,exit \-F arch=b64 \-S adjtimex,settimeofday,clock_settime \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_rule_found=false
            fi
        else
            if grep -r '\-a always,exit \-F arch=b32 \-S adjtimex,settimeofday,clock_settime,stime \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b32_rule_found=true
            fi
        fi
        
        if grep -r '\-w /etc/localtime \-p wa \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
            localtime_rule_found=true
        fi
        
        if [ "$b32_rule_found" = true ] && [ "$b64_rule_found" = true ] && [ "$localtime_rule_found" = true ]; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: time-change audit rules not found in configuration files"
        echo "PROOF: Required audit rules not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: date and time modification audit rules properly configured"
    echo "PROOF: All required time-change audit rules found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_time_change_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        b32_exists=false
        b64_exists=true
        localtime_exists=false
        
        if [[ "$arch" == "x86_64" ]]; then
            if grep -r '\-a always,exit \-F arch=b32 \-S adjtimex,settimeofday,clock_settime \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b32_exists=true
            fi
            if ! grep -r '\-a always,exit \-F arch=b64 \-S adjtimex,settimeofday,clock_settime \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b64_exists=false
            fi
        else
            if grep -r '\-a always,exit \-F arch=b32 \-S adjtimex,settimeofday,clock_settime,stime \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
                b32_exists=true
            fi
        fi
        
        if grep -r '\-w /etc/localtime \-p wa \-k time-change' /etc/audit/rules.d/ >/dev/null 2>&1; then
            localtime_exists=true
        fi
        
        if [ "$b32_exists" = true ] && [ "$b64_exists" = true ] && [ "$localtime_exists" = true ]; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating time-change audit rules in /etc/audit/rules.d/50-time-change.rules"
        
        if [[ "$arch" == "x86_64" ]]; then
            # 64-bit system - create rules for both b64 and b32
            cat > /etc/audit/rules.d/50-time-change.rules << 'EOF'
## Monitor events that modify date and time information
-a always,exit -F arch=b64 -S adjtimex,settimeofday,clock_settime -k time-change
-a always,exit -F arch=b32 -S adjtimex,settimeofday,clock_settime -k time-change
-w /etc/localtime -p wa -k time-change
EOF
        else
            # 32-bit system - create rule for b32 only with stime
            cat > /etc/audit/rules.d/50-time-change.rules << 'EOF'
## Monitor events that modify date and time information
-a always,exit -F arch=b32 -S adjtimex,settimeofday,clock_settime,stime -k time-change
-w /etc/localtime -p wa -k time-change
EOF
        fi
    else
        echo " - Time-change audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - time-change audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_time_change_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: date and time modification audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="