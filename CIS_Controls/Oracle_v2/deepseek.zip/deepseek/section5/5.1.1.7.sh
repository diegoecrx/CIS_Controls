#!/usr/bin/env bash
# Script: 5.1.1.7.sh
# Item: 5.1.1.7 Ensure rsyslog is not configured to receive logs from a remote client (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.1.7.sh"
ITEM_NAME="5.1.1.7 Ensure rsyslog is not configured to receive logs from a remote client (Automated)"
DESCRIPTION="This remediation ensures rsyslog is not configured to receive logs from remote clients."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking rsyslog remote client configuration..."
    
    # Check if rsyslog package is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo "FAIL: rsyslog package is not installed"
        echo "PROOF: rpm -q rsyslog returned no package found"
        return 1
    fi
    
    # Check for remote log server configuration in rsyslog.conf
    remote_config_found=""
    
    # Check new format configurations
    if grep -E '^\s*module\s*\(\s*load\s*=\s*["\047]imtcp["\047]\s*\)' /etc/rsyslog.conf 2>/dev/null; then
        remote_config_found="${remote_config_found}imtcp-module-load "
    fi
    
    if grep -E '^\s*input\s*\(\s*type\s*=\s*["\047]imtcp["\047].*port\s*=\s*["\047]514["\047]' /etc/rsyslog.conf 2>/dev/null; then
        remote_config_found="${remote_config_found}imtcp-input-514 "
    fi
    
    # Check old format configurations
    if grep -E '^\s*\$ModLoad\s+imtcp' /etc/rsyslog.conf 2>/dev/null; then
        remote_config_found="${remote_config_found}modload-imtcp "
    fi
    
    if grep -E '^\s*\$InputTCPServerRun' /etc/rsyslog.conf 2>/dev/null; then
        remote_config_found="${remote_config_found}inputtcpserverrun "
    fi
    
    # Check rsyslog.d directory
    if [ -d /etc/rsyslog.d ]; then
        for conf_file in /etc/rsyslog.d/*.conf; do
            if [ -f "$conf_file" ]; then
                # Check new format
                if grep -E '^\s*module\s*\(\s*load\s*=\s*["\047]imtcp["\047]\s*\)' "$conf_file" 2>/dev/null; then
                    remote_config_found="${remote_config_found}imtcp-module-load-$(basename "$conf_file") "
                fi
                
                if grep -E '^\s*input\s*\(\s*type\s*=\s*["\047]imtcp["\047].*port\s*=\s*["\047]514["\047]' "$conf_file" 2>/dev/null; then
                    remote_config_found="${remote_config_found}imtcp-input-514-$(basename "$conf_file") "
                fi
                
                # Check old format
                if grep -E '^\s*\$ModLoad\s+imtcp' "$conf_file" 2>/dev/null; then
                    remote_config_found="${remote_config_found}modload-imtcp-$(basename "$conf_file") "
                fi
                
                if grep -E '^\s*\$InputTCPServerRun' "$conf_file" 2>/dev/null; then
                    remote_config_found="${remote_config_found}inputtcpserverrun-$(basename "$conf_file") "
                fi
            fi
        done
    fi
    
    if [ -n "$remote_config_found" ]; then
        echo "FAIL: rsyslog is configured to receive remote logs"
        echo "PROOF: Remote log server configurations found: $remote_config_found"
        return 1
    fi
    
    echo "PASS: rsyslog is not configured to receive logs from remote clients"
    echo "PROOF: No remote log server configuration found"
    return 0
}
# Function to fix
fix_rsyslog_remote_config() {
    echo "Applying fix..."
    
    # Check if rsyslog package is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo " - Installing rsyslog package"
        yum install -y rsyslog
    fi
    
    echo " - Removing remote log server configurations from rsyslog.conf"
    
    # Remove configurations from rsyslog.conf
    # Remove new format configurations
    sed -i '/^\s*module\s*(\s*load\s*=\s*["\047]imtcp["\047]\s*)/d' /etc/rsyslog.conf
    sed -i '/^\s*input\s*(\s*type\s*=\s*["\047]imtcp["\047].*port\s*=\s*["\047]514["\047]/d' /etc/rsyslog.conf
    
    # Remove old format configurations
    sed -i '/^\s*\$ModLoad\s\+imtcp/d' /etc/rsyslog.conf
    sed -i '/^\s*\$InputTCPServerRun/d' /etc/rsyslog.conf
    
    # Remove configurations from rsyslog.d directory
    if [ -d /etc/rsyslog.d ]; then
        for conf_file in /etc/rsyslog.d/*.conf; do
            if [ -f "$conf_file" ]; then
                echo " - Removing remote log server configurations from $(basename "$conf_file")"
                
                # Remove new format configurations
                sed -i '/^\s*module\s*(\s*load\s*=\s*["\047]imtcp["\047]\s*)/d' "$conf_file"
                sed -i '/^\s*input\s*(\s*type\s*=\s*["\047]imtcp["\047].*port\s*=\s*["\047]514["\047]/d' "$conf_file"
                
                # Remove old format configurations
                sed -i '/^\s*\$ModLoad\s\+imtcp/d' "$conf_file"
                sed -i '/^\s*\$InputTCPServerRun/d' "$conf_file"
            fi
        done
    fi
    
    # Restart rsyslog service to apply changes
    echo " - Restarting rsyslog service"
    systemctl restart rsyslog
    
    echo " - rsyslog remote client configuration removal completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_rsyslog_remote_config
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: rsyslog is not configured to receive logs from remote clients"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="