#!/usr/bin/env bash
# Script: 5.2.4.9.sh
# Item: 5.2.4.9 Ensure audit tools are owned by root (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.9.sh"
ITEM_NAME="5.2.4.9 Ensure audit tools are owned by root (Automated)"
DESCRIPTION="This remediation ensures audit tools are owned by root user."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit tools ownership..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Define audit tools to check
    audit_tools=(
        "/sbin/auditctl"
        "/sbin/aureport"
        "/sbin/ausearch"
        "/sbin/autrace"
        "/sbin/auditd"
        "/sbin/augenrules"
    )
    
    # Check each audit tool
    non_root_owned_tools=()
    missing_tools=()
    
    for tool in "${audit_tools[@]}"; do
        if [ ! -f "$tool" ]; then
            missing_tools+=("$tool")
            continue
        fi
        
        owner=$(stat -c "%U" "$tool")
        if [ "$owner" != "root" ]; then
            non_root_owned_tools+=("$tool:$owner")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        echo "FAIL: Some audit tools are missing"
        echo "PROOF: Missing audit tools:"
        for tool in "${missing_tools[@]}"; do
            echo "  $tool"
        done
        return 1
    fi
    
    if [ ${#non_root_owned_tools[@]} -gt 0 ]; then
        echo "FAIL: audit tools not owned by root found"
        echo "PROOF: Tools not owned by root:"
        for tool_owner in "${non_root_owned_tools[@]}"; do
            tool=$(echo "$tool_owner" | cut -d: -f1)
            owner=$(echo "$tool_owner" | cut -d: -f2)
            echo "  $tool: owned by $owner"
        done
        return 1
    fi
    
    echo "PASS: audit tools ownership properly configured"
    echo "PROOF: All audit tools are owned by root"
    return 0
}
# Function to fix
fix_audit_tools_ownership() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Define audit tools to fix
    audit_tools=(
        "/sbin/auditctl"
        "/sbin/aureport"
        "/sbin/ausearch"
        "/sbin/autrace"
        "/sbin/auditd"
        "/sbin/augenrules"
    )
    
    echo " - Checking and fixing audit tools ownership"
    
    fixed_tools=0
    missing_tools=0
    
    for tool in "${audit_tools[@]}"; do
        if [ ! -f "$tool" ]; then
            echo " - Warning: $tool not found"
            ((missing_tools++))
            continue
        fi
        
        current_owner=$(stat -c "%U" "$tool")
        
        if [ "$current_owner" != "root" ]; then
            echo " - Changing ownership of $tool from $current_owner to root"
            chown root "$tool"
            ((fixed_tools++))
        else
            echo " - $tool already owned by root"
        fi
    done
    
    # Run comprehensive ownership fix (command from the benchmark)
    echo " - Running comprehensive ownership fix"
    existing_tools=()
    for tool in "${audit_tools[@]}"; do
        if [ -f "$tool" ]; then
            existing_tools+=("$tool")
        fi
    done
    
    if [ ${#existing_tools[@]} -gt 0 ]; then
        chown root "${existing_tools[@]}" 2>/dev/null || true
    fi
    
    # Ensure proper group ownership as well
    echo " - Ensuring proper group ownership for audit tools"
    for tool in "${audit_tools[@]}"; do
        if [ -f "$tool" ]; then
            chgrp root "$tool" 2>/dev/null || true
        fi
    done
    
    if [ $missing_tools -gt 0 ]; then
        echo " - Warning: $missing_tools audit tools were not found"
    fi
    
    if [ $fixed_tools -gt 0 ]; then
        echo " - Fixed ownership for $fixed_tools audit tools"
    else
        echo " - All existing audit tools already owned by root"
    fi
    
    echo " - audit tools ownership configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_tools_ownership
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit tools ownership properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="