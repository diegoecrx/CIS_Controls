#!/usr/bin/env bash
# Script: 5.2.4.1.sh
# Item: 5.2.4.1 Ensure the audit log directory is 0750 or more restrictive (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.1.sh"
ITEM_NAME="5.2.4.1 Ensure the audit log directory is 0750 or more restrictive (Automated)"
DESCRIPTION="This remediation ensures the audit log directory has permissions of 0750 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit log directory permissions..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | tr -d ' ')
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
    fi
    
    log_dir=$(dirname "$log_file")
    
    if [ ! -d "$log_dir" ]; then
        echo "FAIL: audit log directory does not exist"
        echo "PROOF: Directory $log_dir not found"
        return 1
    fi
    
    # Get current permissions
    current_perms=$(stat -c "%a" "$log_dir")
    
    # Check if permissions are 0750 or more restrictive
    # More restrictive means lower octal value
    if [ "$current_perms" -le 750 ]; then
        # Additional check to ensure group write and other permissions are not set
        if [ $((0$current_perms & 027)) -eq 0 ]; then
            echo "PASS: audit log directory permissions properly configured"
            echo "PROOF: Directory $log_dir has permissions $current_perms (0750 or more restrictive)"
            return 0
        fi
    fi
    
    echo "FAIL: audit log directory permissions are too permissive"
    echo "PROOF: Directory $log_dir has permissions $current_perms (should be 0750 or more restrictive)"
    return 1
}
# Function to fix
fix_audit_log_directory_permissions() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | tr -d ' ')
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
        echo " - Using default log file path: $log_file"
    fi
    
    log_dir=$(dirname "$log_file")
    
    # Create audit log directory if it doesn't exist
    if [ ! -d "$log_dir" ]; then
        echo " - Creating audit log directory: $log_dir"
        mkdir -p "$log_dir"
    fi
    
    # Get current permissions
    current_perms=$(stat -c "%a" "$log_dir")
    echo " - Current permissions for $log_dir: $current_perms"
    
    # Set permissions to 0750
    echo " - Setting permissions to 0750 for $log_dir"
    chmod 0750 "$log_dir"
    
    # Verify ownership (should be root:root)
    current_owner=$(stat -c "%U:%G" "$log_dir")
    if [ "$current_owner" != "root:root" ]; then
        echo " - Setting ownership to root:root for $log_dir"
        chown root:root "$log_dir"
    fi
    
    echo " - audit log directory permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_log_directory_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit log directory permissions properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="