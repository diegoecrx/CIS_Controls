#!/usr/bin/env bash
# Script: 5.1.2.1.4.sh
# Item: 5.1.2.1.4 Ensure journald is not configured to receive logs from a remote client (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.2.1.4.sh"
ITEM_NAME="5.1.2.1.4 Ensure journald is not configured to receive logs from a remote client (Automated)"
DESCRIPTION="This remediation ensures journald is not configured to receive logs from remote clients by masking systemd-journal-remote.socket."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking journald remote client configuration..."
    
    # Check if systemd-journal-remote.socket is masked
    if ! systemctl is-masked systemd-journal-remote.socket >/dev/null 2>&1; then
        echo "FAIL: systemd-journal-remote.socket is not masked"
        echo "PROOF: systemctl is-masked systemd-journal-remote.socket shows not masked"
        return 1
    fi
    
    # Check if systemd-journal-remote.socket is active
    if systemctl is-active systemd-journal-remote.socket >/dev/null 2>&1; then
        echo "FAIL: systemd-journal-remote.socket is active"
        echo "PROOF: systemctl is-active systemd-journal-remote.socket shows active"
        return 1
    fi
    
    # Check if systemd-journal-remote.socket is enabled
    if systemctl is-enabled systemd-journal-remote.socket >/dev/null 2>&1; then
        echo "FAIL: systemd-journal-remote.socket is enabled"
        echo "PROOF: systemctl is-enabled systemd-journal-remote.socket shows enabled"
        return 1
    fi
    
    echo "PASS: journald is not configured to receive logs from remote clients"
    echo "PROOF: systemd-journal-remote.socket is masked and inactive"
    return 0
}
# Function to fix
fix_journald_remote_config() {
    echo "Applying fix..."
    
    # Stop and mask systemd-journal-remote.socket
    echo " - Stopping and masking systemd-journal-remote.socket"
    systemctl --now mask systemd-journal-remote.socket
    
    echo " - journald remote client configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journald_remote_config
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: journald is not configured to receive logs from remote clients"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="