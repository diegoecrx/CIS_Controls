#!/usr/bin/env bash
# Script: 5.1.2.2.sh
# Item: 5.1.2.2 Ensure journald service is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.2.2.sh"
ITEM_NAME="5.1.2.2 Ensure journald service is enabled (Automated)"
DESCRIPTION="This remediation ensures journald service is enabled and running properly."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking journald service status..."
    
    # Check if systemd-journald service exists
    if ! systemctl list-unit-files | grep -q "systemd-journald.service"; then
        echo "FAIL: systemd-journald.service not found"
        echo "PROOF: systemd-journald.service not present in unit files"
        return 1
    fi
    
    # Check the status of systemd-journald service
    service_status=$(systemctl is-enabled systemd-journald.service 2>/dev/null || echo "unknown")
    
    # According to CIS benchmark, systemd-journald should be "static"
    if [ "$service_status" != "static" ]; then
        echo "FAIL: systemd-journald service status is not static"
        echo "PROOF: systemctl is-enabled systemd-journald.service shows $service_status (expected: static)"
        return 1
    fi
    
    # Check if systemd-journald service is active
    if ! systemctl is-active systemd-journald.service >/dev/null 2>&1; then
        echo "FAIL: systemd-journald service is not active"
        echo "PROOF: systemctl is-active systemd-journald.service shows inactive"
        return 1
    fi
    
    # Check if systemd-journald service is masked
    if systemctl is-masked systemd-journald.service >/dev/null 2>&1; then
        echo "FAIL: systemd-journald service is masked"
        echo "PROOF: systemctl is-masked systemd-journald.service shows masked"
        return 1
    fi
    
    echo "PASS: journald service properly enabled and running"
    echo "PROOF: systemd-journald.service is static and active"
    return 0
}
# Function to fix
fix_journald_service() {
    echo "Applying fix..."
    
    # Check if systemd-journald is masked and unmask if necessary
    if systemctl is-masked systemd-journald.service >/dev/null 2>&1; then
        echo " - Unmasking systemd-journald service"
        systemctl unmask systemd-journald.service
    fi
    
    # Start systemd-journald if it's not active
    if ! systemctl is-active systemd-journald.service >/dev/null 2>&1; then
        echo " - Starting systemd-journald service"
        systemctl start systemd-journald.service
    fi
    
    # Verify the service status after changes
    service_status=$(systemctl is-enabled systemd-journald.service 2>/dev/null || echo "unknown")
    if [ "$service_status" != "static" ]; then
        echo " - WARNING: systemd-journald service status is $service_status instead of static"
        echo " - This may require investigation as the service should normally be static"
    fi
    
    echo " - journald service configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journald_service
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: journald service properly enabled and running"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="