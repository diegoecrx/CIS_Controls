#!/usr/bin/env bash
# Script: 5.2.2.3.sh
# Item: 5.2.2.3 Ensure system is disabled when audit logs are full (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.2.3.sh"
ITEM_NAME="5.2.2.3 Ensure system is disabled when audit logs are full (Automated)"
DESCRIPTION="This remediation ensures system is disabled when audit logs are full by configuring disk_full_action and disk_error_action."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit system disable configuration..."
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Check disk_full_action setting
    disk_full_action_configured=false
    if grep -q '^disk_full_action' /etc/audit/auditd.conf 2>/dev/null; then
        disk_full_action=$(grep '^disk_full_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$disk_full_action" = "halt" ] || [ "$disk_full_action" = "single" ]; then
            disk_full_action_configured=true
        fi
    fi
    
    # Check disk_error_action setting
    disk_error_action_configured=false
    if grep -q '^disk_error_action' /etc/audit/auditd.conf 2>/dev/null; then
        disk_error_action=$(grep '^disk_error_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$disk_error_action" = "syslog" ] || [ "$disk_error_action" = "single" ] || [ "$disk_error_action" = "halt" ]; then
            disk_error_action_configured=true
        fi
    fi
    
    # Check if both settings are properly configured
    if [ "$disk_full_action_configured" = false ]; then
        echo "FAIL: disk_full_action not properly configured"
        echo "PROOF: disk_full_action not set to halt or single in /etc/audit/auditd.conf"
        return 1
    fi
    
    if [ "$disk_error_action_configured" = false ]; then
        echo "FAIL: disk_error_action not properly configured"
        echo "PROOF: disk_error_action not set to syslog, single, or halt in /etc/audit/auditd.conf"
        return 1
    fi
    
    echo "PASS: system disable when audit logs are full properly configured"
    echo "PROOF: disk_full_action = $disk_full_action and disk_error_action = $disk_error_action configured in /etc/audit/auditd.conf"
    return 0
}
# Function to fix
fix_audit_system_disable() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Configure disk_full_action
    if grep -q '^disk_full_action' /etc/audit/auditd.conf; then
        current_disk_full_action=$(grep '^disk_full_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$current_disk_full_action" != "halt" ] && [ "$current_disk_full_action" != "single" ]; then
            echo " - Updating disk_full_action to halt"
            sed -i 's/^disk_full_action.*/disk_full_action = halt/' /etc/audit/auditd.conf
        else
            echo " - disk_full_action already properly configured: $current_disk_full_action"
        fi
    else
        echo " - Adding disk_full_action = halt to /etc/audit/auditd.conf"
        echo "disk_full_action = halt" >> /etc/audit/auditd.conf
    fi
    
    # Configure disk_error_action
    if grep -q '^disk_error_action' /etc/audit/auditd.conf; then
        current_disk_error_action=$(grep '^disk_error_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$current_disk_error_action" != "syslog" ] && [ "$current_disk_error_action" != "single" ] && [ "$current_disk_error_action" != "halt" ]; then
            echo " - Updating disk_error_action to halt"
            sed -i 's/^disk_error_action.*/disk_error_action = halt/' /etc/audit/auditd.conf
        else
            echo " - disk_error_action already properly configured: $current_disk_error_action"
        fi
    else
        echo " - Adding disk_error_action = halt to /etc/audit/auditd.conf"
        echo "disk_error_action = halt" >> /etc/audit/auditd.conf
    fi
    
    # Restart auditd service to apply changes (if running)
    if systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Restarting auditd service to apply changes"
        service auditd restart 2>/dev/null || systemctl restart auditd
    fi
    
    echo " - audit system disable configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_system_disable
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: system disable when audit logs are full properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="