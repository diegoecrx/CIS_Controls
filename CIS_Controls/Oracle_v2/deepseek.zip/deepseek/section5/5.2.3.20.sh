#!/usr/bin/env bash
# Script: 5.2.3.20.sh
# Item: 5.2.3.20 Ensure the audit configuration is immutable (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.20.sh"
ITEM_NAME="5.2.3.20 Ensure the audit configuration is immutable (Automated)"
DESCRIPTION="This remediation ensures the audit configuration is immutable by setting the audit system to immutable mode."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit configuration immutability..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Check if audit system is in immutable mode (enabled=2)
    if auditctl -s | grep "enabled" | grep -q "2"; then
        immutable_running=true
    else
        immutable_running=false
    fi
    
    # Check for immutable rule in configuration files
    immutable_config=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "^-e 2" /etc/audit/rules.d/ >/dev/null 2>&1; then
            immutable_config=true
        fi
    fi
    
    # Check specifically for the 99-finalize.rules file
    finalize_file_exists=false
    if [ -f /etc/audit/rules.d/99-finalize.rules ]; then
        if grep -q "^-e 2" /etc/audit/rules.d/99-finalize.rules; then
            finalize_file_exists=true
        fi
    fi
    
    if [ "$immutable_running" = false ]; then
        echo "FAIL: audit configuration is not in immutable mode"
        echo "PROOF: auditctl -s shows enabled != 2"
        return 1
    fi
    
    if [ "$immutable_config" = false ]; then
        echo "FAIL: immutable audit configuration not found in rule files"
        echo "PROOF: No -e 2 rule found in /etc/audit/rules.d/"
        return 1
    fi
    
    if [ "$finalize_file_exists" = false ]; then
        echo "FAIL: 99-finalize.rules file does not contain -e 2"
        echo "PROOF: /etc/audit/rules.d/99-finalize.rules missing or does not contain -e 2"
        return 1
    fi
    
    echo "PASS: audit configuration is properly set to immutable"
    echo "PROOF: Audit system is in immutable mode (enabled=2) and configuration files contain -e 2 rule"
    return 0
}
# Function to fix
fix_audit_immutable_config() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Check if 99-finalize.rules already has -e 2
    if [ -f /etc/audit/rules.d/99-finalize.rules ]; then
        if ! grep -q "^-e 2" /etc/audit/rules.d/99-finalize.rules; then
            echo " - Adding -e 2 to existing /etc/audit/rules.d/99-finalize.rules"
            echo "-e 2" >> /etc/audit/rules.d/99-finalize.rules
        else
            echo " - /etc/audit/rules.d/99-finalize.rules already contains -e 2"
        fi
    else
        echo " - Creating /etc/audit/rules.d/99-finalize.rules with -e 2"
        printf '%s\n' "-e 2" > /etc/audit/rules.d/99-finalize.rules
    fi
    
    # Remove any existing -e 2 rules from other files to avoid conflicts
    echo " - Removing any duplicate -e 2 rules from other rule files"
    for rule_file in /etc/audit/rules.d/*.rules; do
        if [ -f "$rule_file" ] && [ "$rule_file" != "/etc/audit/rules.d/99-finalize.rules" ]; then
            if grep -q "^-e 2" "$rule_file"; then
                echo " - Removing -e 2 from $rule_file"
                sed -i '/^-e 2/d' "$rule_file"
            fi
        fi
    done
    
    # Check current audit status
    current_status=$(auditctl -s | grep "enabled" | awk '{print $2}')
    
    if [ "$current_status" != "2" ]; then
        echo " - Loading audit rules into active configuration"
        augenrules --load
        
        # Check if reboot is required
        new_status=$(auditctl -s | grep "enabled" | awk '{print $2}')
        if [ "$new_status" != "2" ]; then
            echo " - WARNING: Reboot required to enable immutable audit configuration"
        else
            echo " - Audit configuration successfully set to immutable mode"
        fi
    else
        echo " - Audit configuration already in immutable mode"
    fi
    
    echo " - audit immutable configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_immutable_config
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit configuration is properly set to immutable"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="