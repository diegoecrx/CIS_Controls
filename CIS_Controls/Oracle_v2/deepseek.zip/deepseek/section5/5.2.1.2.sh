#!/usr/bin/env bash
# Script: 5.2.1.2.sh
# Item: 5.2.1.2 Ensure auditing for processes that start prior to auditd is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.1.2.sh"
ITEM_NAME="5.2.1.2 Ensure auditing for processes that start prior to auditd is enabled (Automated)"
DESCRIPTION="This remediation ensures auditing for processes that start prior to auditd is enabled by adding audit=1 to kernel parameters."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit kernel parameter configuration..."
    
    # Check current kernel command line
    if grep -q "audit=1" /proc/cmdline 2>/dev/null; then
        cmdline_has_audit=true
    else
        cmdline_has_audit=false
    fi
    
    # Check grub configuration
    grub_has_audit=false
    if [ -f /etc/default/grub ]; then
        if grep -q 'GRUB_CMDLINE_LINUX.*audit=1' /etc/default/grub 2>/dev/null; then
            grub_has_audit=true
        fi
    fi
    
    # Check if current kernel has audit=1
    if [ "$cmdline_has_audit" = false ]; then
        echo "FAIL: audit=1 not found in current kernel command line"
        echo "PROOF: /proc/cmdline does not contain audit=1"
        return 1
    fi
    
    # Check if grub configuration has audit=1
    if [ "$grub_has_audit" = false ]; then
        echo "FAIL: audit=1 not configured in grub"
        echo "PROOF: /etc/default/grub GRUB_CMDLINE_LINUX does not contain audit=1"
        return 1
    fi
    
    echo "PASS: audit kernel parameter properly configured"
    echo "PROOF: audit=1 found in both current kernel and grub configuration"
    return 0
}
# Function to fix
fix_audit_kernel_parameter() {
    echo "Applying fix..."
    
    # Update kernel parameters using grubby
    echo " - Updating kernel parameters with grubby"
    grubby --update-kernel ALL --args 'audit=1'
    
    # Update /etc/default/grub
    if [ -f /etc/default/grub ]; then
        echo " - Updating /etc/default/grub"
        
        # Check if GRUB_CMDLINE_LINUX exists
        if grep -q '^GRUB_CMDLINE_LINUX=' /etc/default/grub; then
            # Check if audit=1 is already present
            if ! grep -q 'GRUB_CMDLINE_LINUX.*audit=1' /etc/default/grub; then
                # Add audit=1 to existing GRUB_CMDLINE_LINUX
                sed -i 's/\(GRUB_CMDLINE_LINUX="[^"]*\)"/\1 audit=1"/' /etc/default/grub
            else
                echo " - audit=1 already present in GRUB_CMDLINE_LINUX"
            fi
        else
            # Add GRUB_CMDLINE_LINUX with audit=1
            echo 'GRUB_CMDLINE_LINUX="audit=1"' >> /etc/default/grub
        fi
    else
        echo " - Creating /etc/default/grub with audit=1"
        cat > /etc/default/grub << 'EOF'
GRUB_TIMEOUT=5
GRUB_DISTRIBUTOR="$(sed 's, release .*$,,g' /etc/system-release)"
GRUB_DEFAULT=saved
GRUB_DISABLE_SUBMENU=true
GRUB_TERMINAL_OUTPUT="console"
GRUB_CMDLINE_LINUX="audit=1"
GRUB_DISABLE_RECOVERY="true"
EOF
    fi
    
    # Regenerate grub configuration
    echo " - Regenerating grub configuration"
    if [ -f /boot/efi/EFI/oracle/grub.cfg ]; then
        # UEFI system
        grub2-mkconfig -o /boot/efi/EFI/oracle/grub.cfg
    elif [ -f /boot/grub2/grub.cfg ]; then
        # BIOS system
        grub2-mkconfig -o /boot/grub2/grub.cfg
    else
        echo " - Warning: Could not locate grub configuration file"
    fi
    
    echo " - audit kernel parameter configuration completed"
    echo " - NOTE: A reboot is required for the changes to take effect"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_kernel_parameter
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit kernel parameter properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="