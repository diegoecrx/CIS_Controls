#!/usr/bin/env bash
# Script: 5.2.4.3.sh
# Item: 5.2.4.3 Ensure only authorized users own audit log files (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.3.sh"
ITEM_NAME="5.2.4.3 Ensure only authorized users own audit log files (Automated)"
DESCRIPTION="This remediation ensures only authorized users (root) own audit log files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit log files ownership..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs 2>/dev/null)
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
    fi
    
    log_dir=$(dirname "$log_file")
    
    if [ ! -d "$log_dir" ]; then
        echo "FAIL: audit log directory does not exist"
        echo "PROOF: Directory $log_dir not found"
        return 1
    fi
    
    # Check for audit log files not owned by root
    non_root_owned_files=()
    while IFS= read -r -d '' file; do
        non_root_owned_files+=("$file")
    done < <(find "$log_dir" -type f ! -user root -print0 2>/dev/null)
    
    if [ ${#non_root_owned_files[@]} -gt 0 ]; then
        echo "FAIL: audit log files not owned by root found"
        echo "PROOF: Files not owned by root:"
        for file in "${non_root_owned_files[@]}"; do
            owner=$(stat -c "%U" "$file")
            echo "  $file: owned by $owner"
        done
        return 1
    fi
    
    echo "PASS: audit log files ownership properly configured"
    echo "PROOF: All audit log files in $log_dir are owned by root"
    return 0
}
# Function to fix
fix_audit_log_files_ownership() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs 2>/dev/null)
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
        echo " - Using default log file path: $log_file"
    fi
    
    log_dir=$(dirname "$log_file")
    
    # Create audit log directory if it doesn't exist
    if [ ! -d "$log_dir" ]; then
        echo " - Creating audit log directory: $log_dir"
        mkdir -p "$log_dir"
        chown root:root "$log_dir"
    fi
    
    echo " - Checking audit log files ownership in: $log_dir"
    
    # Find and fix files not owned by root
    non_root_owned_files=()
    while IFS= read -r -d '' file; do
        non_root_owned_files+=("$file")
    done < <(find "$log_dir" -type f ! -user root -print0 2>/dev/null)
    
    if [ ${#non_root_owned_files[@]} -gt 0 ]; then
        echo " - Found ${#non_root_owned_files[@]} files not owned by root"
        
        for file in "${non_root_owned_files[@]}"; do
            old_owner=$(stat -c "%U" "$file")
            echo " - Changing ownership of $file from $old_owner to root"
            chown root "$file"
        done
    else
        echo " - All audit log files are already owned by root"
    fi
    
    # Ensure all audit log files are owned by root (run the command from the benchmark)
    echo " - Running comprehensive ownership fix"
    find "$log_dir" -type f ! -user root -exec chown root {} + 2>/dev/null || true
    
    echo " - audit log files ownership configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_log_files_ownership
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit log files ownership properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="