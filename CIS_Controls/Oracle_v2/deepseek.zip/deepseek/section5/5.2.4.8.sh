#!/usr/bin/env bash
# Script: 5.2.4.8.sh
# Item: 5.2.4.8 Ensure audit tools are 755 or more restrictive (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.8.sh"
ITEM_NAME="5.2.4.8 Ensure audit tools are 755 or more restrictive (Automated)"
DESCRIPTION="This remediation ensures audit tools have permissions of 755 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit tools permissions..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Define audit tools to check
    audit_tools=(
        "/sbin/auditctl"
        "/sbin/aureport"
        "/sbin/ausearch"
        "/sbin/autrace"
        "/sbin/auditd"
        "/sbin/augenrules"
    )
    
    # Check each audit tool
    improper_tools=()
    missing_tools=()
    
    for tool in "${audit_tools[@]}"; do
        if [ ! -f "$tool" ]; then
            missing_tools+=("$tool")
            continue
        fi
        
        current_perms=$(stat -c "%a" "$tool")
        
        # Check if permissions are more permissive than 755
        # Group and other write permissions should not be set (mask 022)
        if [ $((0$current_perms & 022)) -ne 0 ]; then
            improper_tools+=("$tool:$current_perms")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        echo "FAIL: Some audit tools are missing"
        echo "PROOF: Missing audit tools:"
        for tool in "${missing_tools[@]}"; do
            echo "  $tool"
        done
        return 1
    fi
    
    if [ ${#improper_tools[@]} -gt 0 ]; then
        echo "FAIL: audit tools with improper permissions found"
        echo "PROOF: Tools with permissions more permissive than 755:"
        for tool_perm in "${improper_tools[@]}"; do
            tool=$(echo "$tool_perm" | cut -d: -f1)
            perm=$(echo "$tool_perm" | cut -d: -f2)
            echo "  $tool: $perm"
        done
        return 1
    fi
    
    echo "PASS: audit tools permissions properly configured"
    echo "PROOF: All audit tools have permissions 755 or more restrictive"
    return 0
}
# Function to fix
fix_audit_tools_permissions() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Define audit tools to fix
    audit_tools=(
        "/sbin/auditctl"
        "/sbin/aureport"
        "/sbin/ausearch"
        "/sbin/autrace"
        "/sbin/auditd"
        "/sbin/augenrules"
    )
    
    echo " - Checking and fixing audit tools permissions"
    
    fixed_tools=0
    missing_tools=0
    
    for tool in "${audit_tools[@]}"; do
        if [ ! -f "$tool" ]; then
            echo " - Warning: $tool not found"
            ((missing_tools++))
            continue
        fi
        
        current_perms=$(stat -c "%a" "$tool")
        
        # Check if permissions need fixing (group/other write permissions)
        if [ $((0$current_perms & 022)) -ne 0 ]; then
            echo " - Fixing permissions for $tool (was $current_perms)"
            chmod go-w "$tool"
            new_perms=$(stat -c "%a" "$tool")
            echo " - New permissions for $tool: $new_perms"
            ((fixed_tools++))
        else
            echo " - $tool already has correct permissions ($current_perms)"
        fi
    done
    
    # Run comprehensive permissions fix (command from the benchmark)
    echo " - Running comprehensive permissions fix"
    existing_tools=()
    for tool in "${audit_tools[@]}"; do
        if [ -f "$tool" ]; then
            existing_tools+=("$tool")
        fi
    done
    
    if [ ${#existing_tools[@]} -gt 0 ]; then
        chmod go-w "${existing_tools[@]}" 2>/dev/null || true
    fi
    
    # Ensure proper ownership for audit tools
    echo " - Ensuring proper ownership for audit tools"
    for tool in "${audit_tools[@]}"; do
        if [ -f "$tool" ]; then
            chown root:root "$tool" 2>/dev/null || true
        fi
    done
    
    if [ $missing_tools -gt 0 ]; then
        echo " - Warning: $missing_tools audit tools were not found"
    fi
    
    if [ $fixed_tools -gt 0 ]; then
        echo " - Fixed permissions for $fixed_tools audit tools"
    else
        echo " - All existing audit tools already had correct permissions"
    fi
    
    echo " - audit tools permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_tools_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit tools permissions properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="