#!/usr/bin/env bash
# Script: 5.2.3.6.sh
# Item: 5.2.3.6 Ensure use of privileged commands are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.6.sh"
ITEM_NAME="5.2.3.6 Ensure use of privileged commands are collected (Automated)"
DESCRIPTION="This remediation ensures use of privileged commands are collected by configuring audit rules for setuid/setgid programs."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking privileged commands audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    # Find all setuid/setgid programs
    privileged_programs=()
    while IFS= read -r -d '' program; do
        privileged_programs+=("$program")
    done < <(find / -xdev -perm /6000 -type f -print0 2>/dev/null)
    
    if [ ${#privileged_programs[@]} -eq 0 ]; then
        echo "PASS: No privileged programs found"
        echo "PROOF: No setuid/setgid programs detected"
        return 0
    fi
    
    # Check if audit rules exist for privileged programs
    missing_rules=()
    for program in "${privileged_programs[@]}"; do
        if ! auditctl -l | grep -q "\-a always,exit \-F path=$program \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k privileged"; then
            missing_rules+=("$program")
        fi
    done
    
    if [ ${#missing_rules[@]} -gt 0 ]; then
        echo "FAIL: Privileged command audit rules missing for some programs"
        echo "PROOF: Missing audit rules for ${#missing_rules[@]} privileged programs"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        # Count rules in config files
        config_rule_count=0
        for program in "${privileged_programs[@]}"; do
            if grep -r "\-a always,exit \-F path=$program \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k privileged" /etc/audit/rules.d/ >/dev/null 2>&1; then
                ((config_rule_count++))
            fi
        done
        
        if [ $config_rule_count -eq ${#privileged_programs[@]} ]; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: Privileged command audit rules not found in configuration files"
        echo "PROOF: Not all privileged programs have audit rules in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: Privileged command audit rules properly configured"
    echo "PROOF: All ${#privileged_programs[@]} privileged programs have audit rules in both running configuration and rule files"
    return 0
}
# Function to fix
fix_privileged_commands_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    echo " - Using UID_MIN value: $UID_MIN"
    
    AUDIT_RULE_FILE="/etc/audit/rules.d/50-privileged.rules"
    NEW_DATA=()
    
    echo " - Scanning for privileged programs..."
    
    # Find all partitions excluding nodev filesystems and those with noexec/nosuid
    for PARTITION in $(findmnt -n -l -k -it $(awk '/nodev/ { print $2 }' /proc/filesystems | paste -sd,) | grep -Pv "noexec|nosuid" | awk '{print $1}'); do
        echo " - Scanning partition: $PARTITION"
        
        # Find setuid/setgid programs in this partition
        readarray -t DATA < <(find "${PARTITION}" -xdev -perm /6000 -type f 2>/dev/null | awk -v UID_MIN=${UID_MIN} '{print "-a always,exit -F path=" $1 " -F perm=x -F auid>="UID_MIN" -F auid!=unset -k privileged" }')
        
        for ENTRY in "${DATA[@]}"; do
            if [ -n "$ENTRY" ]; then
                NEW_DATA+=("${ENTRY}")
            fi
        done
    done
    
    if [ ${#NEW_DATA[@]} -eq 0 ]; then
        echo " - No privileged programs found, creating empty rule file"
        echo "## Privileged command audit rules" > "${AUDIT_RULE_FILE}"
        echo "## No setuid/setgid programs found" >> "${AUDIT_RULE_FILE}"
    else
        echo " - Found ${#NEW_DATA[@]} privileged programs"
        
        # Read existing rules if file exists
        OLD_DATA=()
        if [ -f "${AUDIT_RULE_FILE}" ]; then
            readarray -t OLD_DATA < "${AUDIT_RULE_FILE}" 2>/dev/null || true
        fi
        
        # Combine old and new data
        COMBINED_DATA=( "${OLD_DATA[@]}" "${NEW_DATA[@]}" )
        
        # Create rule file with header and sorted unique rules
        {
            echo "## Monitor use of privileged commands"
            printf '%s\n' "${COMBINED_DATA[@]}" | grep -v '^##' | sort -u
        } > "${AUDIT_RULE_FILE}"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - privileged commands audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_privileged_commands_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Privileged command audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="