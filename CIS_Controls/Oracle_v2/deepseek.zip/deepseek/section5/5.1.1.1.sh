#!/usr/bin/env bash
# Script: 5.1.1.1.sh
# Item: 5.1.1.1 Ensure rsyslog is installed (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.1.1.sh"
ITEM_NAME="5.1.1.1 Ensure rsyslog is installed (Automated)"
DESCRIPTION="This remediation ensures rsyslog is installed on the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking rsyslog installation..."
    
    # Check if rsyslog package is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo "FAIL: rsyslog package is not installed"
        echo "PROOF: rpm -q rsyslog returned no package found"
        return 1
    fi
    
    echo "PASS: rsyslog properly installed"
    echo "PROOF: rsyslog package is installed"
    return 0
}
# Function to fix
fix_rsyslog_installation() {
    echo "Applying fix..."
    
    # Install rsyslog package
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo " - Installing rsyslog package"
        yum install -y rsyslog
    else
        echo " - rsyslog package already installed"
    fi
    
    echo " - rsyslog installation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_rsyslog_installation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: rsyslog properly installed"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="