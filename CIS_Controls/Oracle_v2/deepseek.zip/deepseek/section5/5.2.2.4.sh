#!/usr/bin/env bash
# Script: 5.2.2.4.sh
# Item: 5.2.2.4 Ensure system warns when audit logs are low on space (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.2.4.sh"
ITEM_NAME="5.2.2.4 Ensure system warns when audit logs are low on space (Automated)"
DESCRIPTION="This remediation ensures system warns when audit logs are low on space by configuring space_left_action and admin_space_left_action."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit low space warning configuration..."
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Check space_left_action setting
    space_left_action_configured=false
    if grep -q '^space_left_action' /etc/audit/auditd.conf 2>/dev/null; then
        space_left_action=$(grep '^space_left_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$space_left_action" = "email" ] || [ "$space_left_action" = "exec" ] || [ "$space_left_action" = "single" ] || [ "$space_left_action" = "halt" ]; then
            space_left_action_configured=true
        fi
    fi
    
    # Check admin_space_left_action setting
    admin_space_left_action_configured=false
    if grep -q '^admin_space_left_action' /etc/audit/auditd.conf 2>/dev/null; then
        admin_space_left_action=$(grep '^admin_space_left_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$admin_space_left_action" = "single" ] || [ "$admin_space_left_action" = "halt" ]; then
            admin_space_left_action_configured=true
        fi
    fi
    
    # Check if both settings are properly configured
    if [ "$space_left_action_configured" = false ]; then
        echo "FAIL: space_left_action not properly configured"
        echo "PROOF: space_left_action not set to email, exec, single, or halt in /etc/audit/auditd.conf"
        return 1
    fi
    
    if [ "$admin_space_left_action_configured" = false ]; then
        echo "FAIL: admin_space_left_action not properly configured"
        echo "PROOF: admin_space_left_action not set to single or halt in /etc/audit/auditd.conf"
        return 1
    fi
    
    echo "PASS: system warning for low audit log space properly configured"
    echo "PROOF: space_left_action = $space_left_action and admin_space_left_action = $admin_space_left_action configured in /etc/audit/auditd.conf"
    return 0
}
# Function to fix
fix_audit_low_space_warning() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Configure space_left_action
    if grep -q '^space_left_action' /etc/audit/auditd.conf; then
        current_space_left_action=$(grep '^space_left_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$current_space_left_action" != "email" ] && [ "$current_space_left_action" != "exec" ] && [ "$current_space_left_action" != "single" ] && [ "$current_space_left_action" != "halt" ]; then
            echo " - Updating space_left_action to email"
            sed -i 's/^space_left_action.*/space_left_action = email/' /etc/audit/auditd.conf
        else
            echo " - space_left_action already properly configured: $current_space_left_action"
        fi
    else
        echo " - Adding space_left_action = email to /etc/audit/auditd.conf"
        echo "space_left_action = email" >> /etc/audit/auditd.conf
    fi
    
    # Configure admin_space_left_action
    if grep -q '^admin_space_left_action' /etc/audit/auditd.conf; then
        current_admin_space_left_action=$(grep '^admin_space_left_action' /etc/audit/auditd.conf | awk '{print $3}')
        if [ "$current_admin_space_left_action" != "single" ] && [ "$current_admin_space_left_action" != "halt" ]; then
            echo " - Updating admin_space_left_action to single"
            sed -i 's/^admin_space_left_action.*/admin_space_left_action = single/' /etc/audit/auditd.conf
        else
            echo " - admin_space_left_action already properly configured: $current_admin_space_left_action"
        fi
    else
        echo " - Adding admin_space_left_action = single to /etc/audit/auditd.conf"
        echo "admin_space_left_action = single" >> /etc/audit/auditd.conf
    fi
    
    # Restart auditd service to apply changes (if running)
    if systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Restarting auditd service to apply changes"
        service auditd restart 2>/dev/null || systemctl restart auditd
    fi
    
    echo " - audit low space warning configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_low_space_warning
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: system warning for low audit log space properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="