#!/usr/bin/env bash
# Script: 5.3.1.sh
# Item: 5.3.1 Ensure AIDE is installed (Automated)
set -euo pipefail
SCRIPT_NAME="5.3.1.sh"
ITEM_NAME="5.3.1 Ensure AIDE is installed (Automated)"
DESCRIPTION="This remediation ensures AIDE (Advanced Intrusion Detection Environment) is installed and initialized."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking AIDE installation and initialization..."
    
    # Check if AIDE package is installed
    if ! rpm -q aide >/dev/null 2>&1; then
        echo "FAIL: AIDE package is not installed"
        echo "PROOF: rpm -q aide returned no package found"
        return 1
    fi
    
    # Check if AIDE is initialized (database exists)
    if [ ! -f /var/lib/aide/aide.db.gz ]; then
        echo "FAIL: AIDE database not initialized"
        echo "PROOF: /var/lib/aide/aide.db.gz does not exist"
        return 1
    fi
    
    echo "PASS: AIDE properly installed and initialized"
    echo "PROOF: AIDE package is installed and database exists at /var/lib/aide/aide.db.gz"
    return 0
}
# Function to fix
fix_aide_installation() {
    echo "Applying fix..."
    
    # Install AIDE package
    if ! rpm -q aide >/dev/null 2>&1; then
        echo " - Installing AIDE package"
        yum install -y aide
    else
        echo " - AIDE package already installed"
    fi
    
    # Check if AIDE database exists
    if [ ! -f /var/lib/aide/aide.db.gz ]; then
        echo " - Initializing AIDE database"
        
        # Create AIDE directory if it doesn't exist
        if [ ! -d /var/lib/aide ]; then
            mkdir -p /var/lib/aide
        fi
        
        # Initialize AIDE database
        echo " - Running aide --init (this may take several minutes)"
        aide --init
        
        # Move the new database to the correct location
        if [ -f /var/lib/aide/aide.db.new.gz ]; then
            echo " - Moving initialized database to correct location"
            mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
        else
            echo " - Warning: aide --init did not create expected database file"
        fi
    else
        echo " - AIDE database already exists"
    fi
    
    # Verify database was created successfully
    if [ -f /var/lib/aide/aide.db.gz ]; then
        echo " - AIDE database successfully created/verified"
        # Display database information
        db_size=$(du -h /var/lib/aide/aide.db.gz | cut -f1)
        echo " - Database size: $db_size"
    else
        echo " - Warning: AIDE database creation may have failed"
    fi
    
    echo " - AIDE installation and initialization completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_aide_installation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: AIDE properly installed and initialized"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="