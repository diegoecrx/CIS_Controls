#!/usr/bin/env bash
# Script: 5.2.4.2.sh
# Item: 5.2.4.2 Ensure audit log files are mode 0640 or less permissive (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.2.sh"
ITEM_NAME="5.2.4.2 Ensure audit log files are mode 0640 or less permissive (Automated)"
DESCRIPTION="This remediation ensures audit log files have permissions of 0640 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit log files permissions..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs 2>/dev/null)
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
    fi
    
    log_dir=$(dirname "$log_file")
    
    if [ ! -d "$log_dir" ]; then
        echo "FAIL: audit log directory does not exist"
        echo "PROOF: Directory $log_dir not found"
        return 1
    fi
    
    # Check for audit log files with improper permissions
    # Acceptable permissions: 0600, 0400, 0200, 0000, 0640, 0440, 0040
    improper_files=()
    while IFS= read -r -d '' file; do
        improper_files+=("$file")
    done < <(find "$log_dir" -type f \( ! -perm 0600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -print0 2>/dev/null)
    
    if [ ${#improper_files[@]} -gt 0 ]; then
        echo "FAIL: audit log files with improper permissions found"
        echo "PROOF: Files with permissions more permissive than 0640:"
        for file in "${improper_files[@]}"; do
            perms=$(stat -c "%a" "$file")
            echo "  $file: $perms"
        done
        return 1
    fi
    
    echo "PASS: audit log files permissions properly configured"
    echo "PROOF: All audit log files in $log_dir have permissions 0640 or more restrictive"
    return 0
}
# Function to fix
fix_audit_log_files_permissions() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs 2>/dev/null)
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
        echo " - Using default log file path: $log_file"
    fi
    
    log_dir=$(dirname "$log_file")
    
    # Create audit log directory if it doesn't exist
    if [ ! -d "$log_dir" ]; then
        echo " - Creating audit log directory: $log_dir"
        mkdir -p "$log_dir"
    fi
    
    echo " - Checking audit log files in: $log_dir"
    
    # Find and fix files with improper permissions
    improper_files=()
    while IFS= read -r -d '' file; do
        improper_files+=("$file")
    done < <(find "$log_dir" -type f \( ! -perm 0600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -print0 2>/dev/null)
    
    if [ ${#improper_files[@]} -gt 0 ]; then
        echo " - Found ${#improper_files[@]} files with improper permissions"
        
        for file in "${improper_files[@]}"; do
            old_perms=$(stat -c "%a" "$file")
            echo " - Fixing permissions for $file (was $old_perms)"
            chmod u-x,g-wx,o-rwx "$file"
            new_perms=$(stat -c "%a" "$file")
            echo " - New permissions for $file: $new_perms"
        done
    else
        echo " - No files with improper permissions found"
    fi
    
    # Ensure proper ownership (root:root) for all audit files
    echo " - Ensuring proper ownership for audit log files"
    find "$log_dir" -type f -exec chown root:root {} \; 2>/dev/null
    
    echo " - audit log files permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_log_files_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit log files permissions properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="