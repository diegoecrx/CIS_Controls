#!/usr/bin/env bash
# Script: 5.2.3.8.sh
# Item: 5.2.3.8 Ensure events that modify user/group information are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.8.sh"
ITEM_NAME="5.2.3.8 Ensure events that modify user/group information are collected (Automated)"
DESCRIPTION="This remediation ensures events that modify user/group information are collected by configuring audit rules for identity files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking user/group information modification audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Define required identity files to monitor
    required_files=(
        "/etc/group"
        "/etc/passwd"
        "/etc/gshadow"
        "/etc/shadow"
        "/etc/security/opasswd"
    )
    
    # Check for identity audit rules in running configuration
    identity_rules_found=true
    missing_files=()
    
    for file in "${required_files[@]}"; do
        if ! auditctl -l | grep -q "\-w $file \-p wa \-k identity"; then
            identity_rules_found=false
            missing_files+=("$file")
        fi
    done
    
    if [ "$identity_rules_found" = false ]; then
        echo "FAIL: identity audit rules not found in running configuration"
        echo "PROOF: Missing audit rules for files: ${missing_files[*]}"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        config_missing_files=()
        
        for file in "${required_files[@]}"; do
            if ! grep -r "\-w $file \-p wa \-k identity" /etc/audit/rules.d/ >/dev/null 2>&1; then
                config_missing_files+=("$file")
            fi
        done
        
        if [ ${#config_missing_files[@]} -eq 0 ]; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: identity audit rules not found in configuration files"
        echo "PROOF: Required audit rules not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: user/group information modification audit rules properly configured"
    echo "PROOF: All required identity audit rules found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_identity_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Define required identity files to monitor
    required_files=(
        "/etc/group"
        "/etc/passwd"
        "/etc/gshadow"
        "/etc/shadow"
        "/etc/security/opasswd"
    )
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        missing_rules=0
        
        for file in "${required_files[@]}"; do
            if ! grep -r "\-w $file \-p wa \-k identity" /etc/audit/rules.d/ >/dev/null 2>&1; then
                ((missing_rules++))
            fi
        done
        
        if [ $missing_rules -eq 0 ]; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating identity audit rules in /etc/audit/rules.d/50-identity.rules"
        cat > /etc/audit/rules.d/50-identity.rules << 'EOF'
## Monitor events that modify user/group information
-w /etc/group -p wa -k identity
-w /etc/passwd -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/security/opasswd -p wa -k identity
EOF
    else
        echo " - Identity audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - identity audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_identity_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: user/group information modification audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="