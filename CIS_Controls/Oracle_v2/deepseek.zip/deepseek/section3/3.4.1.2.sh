#!/usr/bin/env bash
# Script: 3.4.1.2.sh
# Item: 3.4.1.2 Ensure a single firewall configuration utility is in use (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.1.2.sh"
ITEM_NAME="3.4.1.2 Ensure a single firewall configuration utility is in use (Automated)"
DESCRIPTION="This remediation ensures only one firewall configuration utility is active (defaults to iptables for Oracle Linux 7)."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking firewall configuration utility status..."
    
    # Count active firewall services
    active_count=0
    firewall_status=""
    
    # Check firewalld
    if systemctl is-active firewalld >/dev/null 2>&1; then
        active_count=$((active_count + 1))
        firewall_status="${firewall_status}firewalld(active) "
    fi
    
    # Check nftables
    if systemctl is-active nftables >/dev/null 2>&1; then
        active_count=$((active_count + 1))
        firewall_status="${firewall_status}nftables(active) "
    fi
    
    # Check iptables
    if systemctl is-active iptables >/dev/null 2>&1; then
        active_count=$((active_count + 1))
        firewall_status="${firewall_status}iptables(active) "
    fi
    
    # Check ip6tables
    if systemctl is-active ip6tables >/dev/null 2>&1; then
        active_count=$((active_count + 1))
        firewall_status="${firewall_status}ip6tables(active) "
    fi
    
    if [ $active_count -eq 0 ]; then
        echo "FAIL: No firewall service is active"
        echo "PROOF: No active firewall services found"
        return 1
    elif [ $active_count -gt 1 ]; then
        echo "FAIL: Multiple firewall services are active"
        echo "PROOF: Active services: $firewall_status"
        return 1
    fi
    
    # Check for conflicting packages
    conflicting_packages=""
    
    # If iptables is the chosen firewall, check for conflicting packages
    if systemctl is-active iptables >/dev/null 2>&1; then
        if rpm -q firewalld >/dev/null 2>&1 && systemctl is-enabled firewalld >/dev/null 2>&1; then
            conflicting_packages="${conflicting_packages}firewalld(enabled) "
        fi
        if rpm -q nftables >/dev/null 2>&1 && systemctl is-enabled nftables >/dev/null 2>&1; then
            conflicting_packages="${conflicting_packages}nftables(enabled) "
        fi
    fi
    
    if [ -n "$conflicting_packages" ]; then
        echo "FAIL: Conflicting firewall packages are enabled"
        echo "PROOF: Enabled conflicting services: $conflicting_packages"
        return 1
    fi
    
    echo "PASS: Single firewall configuration utility in use"
    echo "PROOF: Active firewall: $firewall_status"
    return 0
}
# Function to fix
fix_single_firewall_utility() {
    echo "Applying fix..."
    echo " - Configuring iptables as the single firewall utility (Oracle Linux 7 default)"
    
    # Stop conflicting services
    if systemctl is-active firewalld >/dev/null 2>&1; then
        echo " - Stopping firewalld service"
        systemctl stop firewalld 2>/dev/null || true
    fi
    
    if systemctl is-active nftables >/dev/null 2>&1; then
        echo " - Stopping nftables service"
        systemctl stop nftables 2>/dev/null || true
    fi
    
    # Mask conflicting services
    if systemctl is-enabled firewalld >/dev/null 2>&1; then
        echo " - Masking firewalld service"
        systemctl mask firewalld 2>/dev/null || true
    fi
    
    if systemctl is-enabled nftables >/dev/null 2>&1; then
        echo " - Masking nftables service"
        systemctl mask nftables 2>/dev/null || true
    fi
    
    # Ensure iptables and iptables-services are installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    # Enable and start iptables services
    if ! systemctl is-active iptables >/dev/null 2>&1; then
        echo " - Starting iptables service"
        systemctl enable iptables 2>/dev/null || true
        systemctl start iptables 2>/dev/null || true
    fi
    
    if ! systemctl is-active ip6tables >/dev/null 2>&1; then
        echo " - Starting ip6tables service"
        systemctl enable ip6tables 2>/dev/null || true
        systemctl start ip6tables 2>/dev/null || true
    fi
    
    echo " - Single firewall utility configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_single_firewall_utility
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Single firewall configuration utility properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="