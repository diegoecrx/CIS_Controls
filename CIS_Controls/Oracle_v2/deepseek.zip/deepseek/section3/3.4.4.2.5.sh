#!/usr/bin/env bash
# Script: 3.4.4.2.5.sh
# Item: 3.4.4.2.5 Ensure iptables rules are saved (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.2.5.sh"
ITEM_NAME="3.4.4.2.5 Ensure iptables rules are saved (Automated)"
DESCRIPTION="This remediation ensures iptables rules are saved and persistent across reboots."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking iptables rules save configuration..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    # Check if saved rules file exists
    if [ ! -f /etc/sysconfig/iptables ]; then
        echo "FAIL: /etc/sysconfig/iptables file does not exist"
        echo "PROOF: Saved iptables rules file not found"
        return 1
    fi
    
    # Check if iptables service is enabled
    if ! systemctl is-enabled iptables >/dev/null 2>&1; then
        echo "FAIL: iptables service is not enabled"
        echo "PROOF: systemctl is-enabled iptables shows disabled"
        return 1
    fi
    
    # Check if current running rules match saved rules
    current_rules=$(iptables-save | grep -v '^#' | sort)
    saved_rules=$(cat /etc/sysconfig/iptables | grep -v '^#' | sort)
    
    if [ "$current_rules" != "$saved_rules" ]; then
        echo "FAIL: Current iptables rules do not match saved rules"
        echo "PROOF: Running configuration differs from saved configuration"
        return 1
    fi
    
    # Check for essential rules
    essential_missing=""
    
    # Check for loopback rules
    if ! iptables -L INPUT -n | grep -q "ACCEPT.*lo"; then
        essential_missing="${essential_missing}loopback-accept "
    fi
    
    if ! iptables -L INPUT -n | grep -q "DROP.*127.0.0.0/8"; then
        essential_missing="${essential_missing}loopback-drop "
    fi
    
    # Check for default DROP policies
    if ! iptables -L | grep -q "Chain INPUT (policy DROP)"; then
        essential_missing="${essential_missing}input-drop-policy "
    fi
    
    if ! iptables -L | grep -q "Chain FORWARD (policy DROP)"; then
        essential_missing="${essential_missing}forward-drop-policy "
    fi
    
    if ! iptables -L | grep -q "Chain OUTPUT (policy DROP)"; then
        essential_missing="${essential_missing}output-drop-policy "
    fi
    
    if [ -n "$essential_missing" ]; then
        echo "FAIL: Essential iptables rules are missing"
        echo "PROOF: Missing rules: $essential_missing"
        return 1
    fi
    
    echo "PASS: iptables rules properly saved and configured"
    echo "PROOF: Rules are saved, persistent, and include essential security configurations"
    return 0
}
# Function to fix
fix_iptables_rules_saved() {
    echo "Applying fix..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Configuring essential iptables rules"
    
    # Ensure basic security rules are in place
    # Allow loopback traffic
    if ! iptables -L INPUT -n | grep -q "ACCEPT.*lo"; then
        echo " - Adding loopback input accept rule"
        iptables -A INPUT -i lo -j ACCEPT
    fi
    
    if ! iptables -L OUTPUT -n | grep -q "ACCEPT.*lo"; then
        echo " - Adding loopback output accept rule"
        iptables -A OUTPUT -o lo -j ACCEPT
    fi
    
    # Drop invalid loopback traffic
    if ! iptables -L INPUT -n | grep -q "DROP.*127.0.0.0/8"; then
        echo " - Adding loopback source drop rule"
        iptables -A INPUT -s 127.0.0.0/8 -j DROP
    fi
    
    # Allow established and related connections
    if ! iptables -L INPUT -n | grep -q "ESTABLISHED,RELATED"; then
        echo " - Adding established/related input rule"
        iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    fi
    
    if ! iptables -L OUTPUT -n | grep -q "NEW,ESTABLISHED"; then
        echo " - Adding new/established output rule"
        iptables -A OUTPUT -m state --state NEW,ESTABLISHED -j ACCEPT
    fi
    
    # Allow SSH (port 22) - critical for remote management
    if ! iptables -L INPUT -n | grep -q "tcp dpt:22"; then
        echo " - Adding SSH access rule"
        iptables -A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT
    fi
    
    # Set default DROP policies
    echo " - Setting default DROP policies"
    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT DROP
    
    # Save the current iptables rules
    echo " - Saving iptables rules to /etc/sysconfig/iptables"
    service iptables save 2>/dev/null || iptables-save > /etc/sysconfig/iptables
    
    # Enable iptables service to ensure rules persist across reboots
    if ! systemctl is-enabled iptables >/dev/null 2>&1; then
        echo " - Enabling iptables service"
        systemctl enable iptables
    fi
    
    # Ensure iptables service is running
    if ! systemctl is-active iptables >/dev/null 2>&1; then
        echo " - Starting iptables service"
        systemctl start iptables
    fi
    
    echo " - iptables rules save configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_rules_saved
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: iptables rules properly saved and configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="