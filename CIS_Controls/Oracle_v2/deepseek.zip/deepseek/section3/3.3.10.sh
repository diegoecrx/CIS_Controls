#!/usr/bin/env bash
# Script: 3.3.10.sh
# Item: 3.3.10 Ensure tcp syn cookies is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.10.sh"
ITEM_NAME="3.3.10 Ensure tcp syn cookies is enabled (Automated)"
DESCRIPTION="This remediation ensures TCP SYN cookies are enabled to protect against SYN flood attacks."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking TCP SYN cookies configuration..."
    
    # Check current running value
    tcp_syncookies=$(sysctl net.ipv4.tcp_syncookies 2>/dev/null | awk '{print $3}')
    
    if [ "$tcp_syncookies" != "1" ]; then
        echo "FAIL: net.ipv4.tcp_syncookies is not enabled"
        echo "PROOF: net.ipv4.tcp_syncookies = $tcp_syncookies"
        return 1
    fi
    
    # Check configuration files for conflicting settings
    if grep -Pq '^\s*net\.ipv4\.tcp_syncookies\s*=\s*[^1]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.tcp_syncookies disabled in configuration"
        echo "PROOF: net.ipv4.tcp_syncookies set to non-1 in config files"
        return 1
    fi
    
    echo "PASS: TCP SYN cookies properly enabled"
    echo "PROOF: net.ipv4.tcp_syncookies = 1"
    return 0
}
# Function to fix
fix_tcp_syn_cookies() {
    echo "Applying fix..."
    
    # Remove any existing conflicting entries
    sed -i '/^\s*net\.ipv4\.tcp_syncookies\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.tcp_syncookies\s*=/d' {} \; 2>/dev/null || true
    
    # Add TCP SYN cookies configuration
    echo " - Configuring TCP SYN cookies"
    echo "net.ipv4.tcp_syncookies = 1" >> /etc/sysctl.d/60-netipv4_sysctl.conf
    
    # Set active kernel parameters
    sysctl -w net.ipv4.tcp_syncookies=1 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    echo " - TCP SYN cookies configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_tcp_syn_cookies
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: TCP SYN cookies properly enabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="