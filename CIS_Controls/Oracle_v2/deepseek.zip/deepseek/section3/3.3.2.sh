#!/usr/bin/env bash
# Script: 3.3.2.sh
# Item: 3.3.2 Ensure packet redirect sending is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.2.sh"
ITEM_NAME="3.3.2 Ensure packet redirect sending is disabled (Automated)"
DESCRIPTION="This remediation ensures packet redirect sending is disabled for IPv4."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking packet redirect sending configuration..."
    
    # Check current running values
    all_send_redirects=$(sysctl net.ipv4.conf.all.send_redirects 2>/dev/null | awk '{print $3}')
    default_send_redirects=$(sysctl net.ipv4.conf.default.send_redirects 2>/dev/null | awk '{print $3}')
    
    if [ "$all_send_redirects" != "0" ]; then
        echo "FAIL: net.ipv4.conf.all.send_redirects is not disabled"
        echo "PROOF: net.ipv4.conf.all.send_redirects = $all_send_redirects"
        return 1
    fi
    
    if [ "$default_send_redirects" != "0" ]; then
        echo "FAIL: net.ipv4.conf.default.send_redirects is not disabled"
        echo "PROOF: net.ipv4.conf.default.send_redirects = $default_send_redirects"
        return 1
    fi
    
    # Check configuration files for conflicting settings
    if grep -Pq '^\s*net\.ipv4\.conf\.all\.send_redirects\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.conf.all.send_redirects enabled in configuration"
        echo "PROOF: net.ipv4.conf.all.send_redirects set to non-zero in config files"
        return 1
    fi
    
    if grep -Pq '^\s*net\.ipv4\.conf\.default\.send_redirects\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.conf.default.send_redirects enabled in configuration"
        echo "PROOF: net.ipv4.conf.default.send_redirects set to non-zero in config files"
        return 1
    fi
    
    echo "PASS: Packet redirect sending properly disabled"
    echo "PROOF: Both all and default send_redirects set to 0"
    return 0
}
# Function to fix
fix_packet_redirect_sending() {
    echo "Applying fix..."
    
    # Remove any existing conflicting entries
    sed -i '/^\s*net\.ipv4\.conf\.all\.send_redirects\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    sed -i '/^\s*net\.ipv4\.conf\.default\.send_redirects\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.conf\.all\.send_redirects\s*=/d' {} \; 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.conf\.default\.send_redirects\s*=/d' {} \; 2>/dev/null || true
    
    # Add packet redirect sending configuration
    echo " - Configuring packet redirect sending"
    {
        echo "net.ipv4.conf.all.send_redirects = 0"
        echo "net.ipv4.conf.default.send_redirects = 0"
    } >> /etc/sysctl.d/60-netipv4_sysctl.conf
    
    # Set active kernel parameters
    sysctl -w net.ipv4.conf.all.send_redirects=0 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.send_redirects=0 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    echo " - Packet redirect sending configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_packet_redirect_sending
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Packet redirect sending properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="