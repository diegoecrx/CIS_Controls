#!/usr/bin/env bash
# Script: 3.4.4.3.5.sh
# Item: 3.4.4.3.5 Ensure ip6tables rules are saved (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.3.5.sh"
ITEM_NAME="3.4.4.3.5 Ensure ip6tables rules are saved (Automated)"
DESCRIPTION="This remediation ensures ip6tables rules are saved and persistent across reboots."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ip6tables rules save configuration..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    # Check if saved rules file exists
    if [ ! -f /etc/sysconfig/ip6tables ]; then
        echo "FAIL: /etc/sysconfig/ip6tables file does not exist"
        echo "PROOF: Saved ip6tables rules file not found"
        return 1
    fi
    
    # Check if ip6tables service is enabled
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo "FAIL: ip6tables service is not enabled"
        echo "PROOF: systemctl is-enabled ip6tables shows disabled"
        return 1
    fi
    
    # Check if current running rules match saved rules
    current_rules=$(ip6tables-save | grep -v '^#' | sort)
    saved_rules=$(cat /etc/sysconfig/ip6tables | grep -v '^#' | sort)
    
    if [ "$current_rules" != "$saved_rules" ]; then
        echo "FAIL: Current ip6tables rules do not match saved rules"
        echo "PROOF: Running IPv6 configuration differs from saved configuration"
        return 1
    fi
    
    # Check for essential rules
    essential_missing=""
    
    # Check for IPv6 loopback rules
    if ! ip6tables -L INPUT -n | grep -q "ACCEPT.*lo"; then
        essential_missing="${essential_missing}ipv6-loopback-accept "
    fi
    
    if ! ip6tables -L INPUT -n | grep -q "DROP.*::1"; then
        essential_missing="${essential_missing}ipv6-loopback-drop "
    fi
    
    # Check for default DROP policies
    if ! ip6tables -L | grep -q "Chain INPUT (policy DROP)"; then
        essential_missing="${essential_missing}ipv6-input-drop-policy "
    fi
    
    if ! ip6tables -L | grep -q "Chain FORWARD (policy DROP)"; then
        essential_missing="${essential_missing}ipv6-forward-drop-policy "
    fi
    
    if ! ip6tables -L | grep -q "Chain OUTPUT (policy DROP)"; then
        essential_missing="${essential_missing}ipv6-output-drop-policy "
    fi
    
    if [ -n "$essential_missing" ]; then
        echo "FAIL: Essential ip6tables rules are missing"
        echo "PROOF: Missing IPv6 rules: $essential_missing"
        return 1
    fi
    
    echo "PASS: ip6tables rules properly saved and configured"
    echo "PROOF: IPv6 rules are saved, persistent, and include essential security configurations"
    return 0
}
# Function to fix
fix_ip6tables_rules_saved() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Configuring essential ip6tables rules"
    
    # Ensure basic IPv6 security rules are in place
    # Allow IPv6 loopback traffic
    if ! ip6tables -L INPUT -n | grep -q "ACCEPT.*lo"; then
        echo " - Adding IPv6 loopback input accept rule"
        ip6tables -A INPUT -i lo -j ACCEPT
    fi
    
    if ! ip6tables -L OUTPUT -n | grep -q "ACCEPT.*lo"; then
        echo " - Adding IPv6 loopback output accept rule"
        ip6tables -A OUTPUT -o lo -j ACCEPT
    fi
    
    # Drop invalid IPv6 loopback traffic
    if ! ip6tables -L INPUT -n | grep -q "DROP.*::1"; then
        echo " - Adding IPv6 loopback source drop rule"
        ip6tables -A INPUT -s ::1 -j DROP
    fi
    
    # Allow established and related connections
    if ! ip6tables -L INPUT -n | grep -q "ESTABLISHED,RELATED"; then
        echo " - Adding IPv6 established/related input rule"
        ip6tables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    fi
    
    if ! ip6tables -L OUTPUT -n | grep -q "NEW,ESTABLISHED"; then
        echo " - Adding IPv6 new/established output rule"
        ip6tables -A OUTPUT -m state --state NEW,ESTABLISHED -j ACCEPT
    fi
    
    # Allow SSH (port 22) - critical for remote management
    if ! ip6tables -L INPUT -n | grep -q "tcp dpt:22"; then
        echo " - Adding IPv6 SSH access rule"
        ip6tables -A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT
    fi
    
    # Set default DROP policies
    echo " - Setting default DROP policies for IPv6"
    ip6tables -P INPUT DROP
    ip6tables -P FORWARD DROP
    ip6tables -P OUTPUT DROP
    
    # Save the current ip6tables rules
    echo " - Saving ip6tables rules to /etc/sysconfig/ip6tables"
    service ip6tables save 2>/dev/null || ip6tables-save > /etc/sysconfig/ip6tables
    
    # Enable ip6tables service to ensure rules persist across reboots
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo " - Enabling ip6tables service"
        systemctl enable ip6tables
    fi
    
    # Ensure ip6tables service is running
    if ! systemctl is-active ip6tables >/dev/null 2>&1; then
        echo " - Starting ip6tables service"
        systemctl start ip6tables
    fi
    
    echo " - ip6tables rules save configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip6tables_rules_saved
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ip6tables rules properly saved and configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="