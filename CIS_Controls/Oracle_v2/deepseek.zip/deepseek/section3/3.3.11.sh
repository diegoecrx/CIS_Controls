#!/usr/bin/env bash
# Script: 3.3.11.sh
# Item: 3.3.11 Ensure ipv6 router advertisements are not accepted (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.11.sh"
ITEM_NAME="3.3.11 Ensure ipv6 router advertisements are not accepted (Automated)"
DESCRIPTION="This remediation ensures IPv6 router advertisements are not accepted when IPv6 is enabled."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking IPv6 router advertisement configuration..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check current running values
    ipv6_all_accept_ra=$(sysctl net.ipv6.conf.all.accept_ra 2>/dev/null | awk '{print $3}')
    ipv6_default_accept_ra=$(sysctl net.ipv6.conf.default.accept_ra 2>/dev/null | awk '{print $3}')
    
    if [ "$ipv6_all_accept_ra" != "0" ]; then
        echo "FAIL: net.ipv6.conf.all.accept_ra is not disabled"
        echo "PROOF: net.ipv6.conf.all.accept_ra = $ipv6_all_accept_ra"
        return 1
    fi
    
    if [ "$ipv6_default_accept_ra" != "0" ]; then
        echo "FAIL: net.ipv6.conf.default.accept_ra is not disabled"
        echo "PROOF: net.ipv6.conf.default.accept_ra = $ipv6_default_accept_ra"
        return 1
    fi
    
    # Check configuration files for conflicting settings
    if grep -Pq '^\s*net\.ipv6\.conf\.all\.accept_ra\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv6.conf.all.accept_ra enabled in configuration"
        echo "PROOF: net.ipv6.conf.all.accept_ra set to non-zero in config files"
        return 1
    fi
    
    if grep -Pq '^\s*net\.ipv6\.conf\.default\.accept_ra\s*=\s*[^0]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv6.conf.default.accept_ra enabled in configuration"
        echo "PROOF: net.ipv6.conf.default.accept_ra set to non-zero in config files"
        return 1
    fi
    
    echo "PASS: IPv6 router advertisements properly disabled"
    echo "PROOF: Both all and default accept_ra set to 0"
    return 0
}
# Function to fix
fix_ipv6_router_advertisements() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Remove any existing conflicting entries
    sed -i '/^\s*net\.ipv6\.conf\.all\.accept_ra\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    sed -i '/^\s*net\.ipv6\.conf\.default\.accept_ra\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv6\.conf\.all\.accept_ra\s*=/d' {} \; 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv6\.conf\.default\.accept_ra\s*=/d' {} \; 2>/dev/null || true
    
    # Add IPv6 router advertisement configuration
    echo " - Configuring IPv6 router advertisements"
    {
        echo "net.ipv6.conf.all.accept_ra = 0"
        echo "net.ipv6.conf.default.accept_ra = 0"
    } >> /etc/sysctl.d/60-netipv6_sysctl.conf
    
    # Set active kernel parameters
    sysctl -w net.ipv6.conf.all.accept_ra=0 >/dev/null 2>&1
    sysctl -w net.ipv6.conf.default.accept_ra=0 >/dev/null 2>&1
    sysctl -w net.ipv6.route.flush=1 >/dev/null 2>&1
    
    echo " - IPv6 router advertisement configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ipv6_router_advertisements
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: IPv6 router advertisements properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="