#!/usr/bin/env bash
# Script: 3.2.1.sh
# Item: 3.2.1 Ensure dccp kernel module is not available (Automated)
set -euo pipefail
SCRIPT_NAME="3.2.1.sh"
ITEM_NAME="3.2.1 Ensure dccp kernel module is not available (Automated)"
DESCRIPTION="This remediation ensures the dccp kernel module is not available by blacklisting and disabling it."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking dccp kernel module..."
    
    l_mname="dccp"
    l_mtype="net"
    l_mpath="/lib/modules/**/kernel/$l_mtype"
    l_mpname="$(tr '-' '_' <<< "$l_mname")"
    l_mndir="$(tr '-' '/' <<< "$l_mname")"
    
    # Check if module exists in any kernel
    l_module_exists=false
    for l_mdir in $l_mpath; do
        if [ -d "$l_mdir/$l_mndir" ] && [ -n "$(ls -A $l_mdir/$l_mndir 2>/dev/null)" ]; then
            l_module_exists=true
            break
        fi
    done
    
    if [ "$l_module_exists" = false ]; then
        echo "PASS: dccp module does not exist on the system"
        echo "PROOF: No dccp module found in kernel directories"
        return 0
    fi
    
    # Check if module is blacklisted
    if ! modprobe --showconfig | grep -Pq -- "^\h*blacklist\h+$l_mpname\b"; then
        echo "FAIL: dccp module is not blacklisted"
        echo "PROOF: blacklist entry not found for dccp"
        return 1
    fi
    
    # Check if module is set to not loadable (for running kernel)
    if [ -d "/lib/modules/$(uname -r)/kernel/$l_mtype/$l_mndir" ] && [ -n "$(ls -A /lib/modules/$(uname -r)/kernel/$l_mtype/$l_mndir 2>/dev/null)" ]; then
        l_loadable="$(modprobe -n -v "$l_mname" 2>/dev/null)"
        [ "$(wc -l <<< "$l_loadable")" -gt "1" ] && l_loadable="$(grep -P -- "(^\h*install|\b$l_mname)\b" <<< "$l_loadable")"
        if ! grep -Pq -- '^\h*install\h+/bin/(true|false)' <<< "$l_loadable"; then
            echo "FAIL: dccp module is loadable in running kernel"
            echo "PROOF: install /bin/false not set for dccp"
            return 1
        fi
    fi
    
    # Check if module is currently loaded
    if lsmod | grep -q "^$l_mname\b" 2>/dev/null; then
        echo "FAIL: dccp module is currently loaded"
        echo "PROOF: $l_mname found in lsmod output"
        return 1
    fi
    
    echo "PASS: dccp kernel module properly disabled"
    echo "PROOF: dccp module blacklisted and not loadable"
    return 0
}
# Module fix functions
module_loadable_fix() {
    local l_mname="$1"
    local l_mpname="$2"
    
    # If the module is currently loadable, add "install {MODULE_NAME} /bin/false"
    l_loadable="$(modprobe -n -v "$l_mname" 2>/dev/null)"
    [ "$(wc -l <<< "$l_loadable")" -gt "1" ] && l_loadable="$(grep -P -- "(^\h*install|\b$l_mname)\b" <<< "$l_loadable")"
    if ! grep -Pq -- '^\h*install\h+/bin/(true|false)' <<< "$l_loadable"; then
        echo " - Setting module: $l_mname to be not loadable"
        echo "install $l_mname /bin/false" >> /etc/modprobe.d/"$l_mpname".conf
    fi
}
module_loaded_fix() {
    local l_mname="$1"
    
    # If the module is currently loaded, unload the module
    if lsmod | grep -q "^$l_mname\b" 2>/dev/null; then
        echo " - Unloading module $l_mname"
        modprobe -r "$l_mname" 2>/dev/null || true
    fi
}
module_deny_fix() {
    local l_mname="$1"
    local l_mpname="$2"
    
    # If the module isn't deny listed, denylist the module
    if ! modprobe --showconfig | grep -Pq -- "^\h*blacklist\h+$l_mpname\b"; then
        echo " - Blacklisting $l_mname"
        echo "blacklist $l_mname" >> /etc/modprobe.d/"$l_mpname".conf
    fi
}
# Function to fix
fix_dccp_module() {
    echo "Applying fix..."
    
    l_mname="dccp"
    l_mtype="net"
    l_mpath="/lib/modules/**/kernel/$l_mtype"
    l_mpname="$(tr '-' '_' <<< "$l_mname")"
    l_mndir="$(tr '-' '/' <<< "$l_mname")"
    
    # Check if the module exists on the system
    for l_mdir in $l_mpath; do
        if [ -d "$l_mdir/$l_mndir" ] && [ -n "$(ls -A $l_mdir/$l_mndir 2>/dev/null)" ]; then
            echo " - Module: $l_mname exists in $l_mdir"
            echo " - Checking if disabled..."
            module_deny_fix "$l_mname" "$l_mpname"
            if [ "$l_mdir" = "/lib/modules/$(uname -r)/kernel/$l_mtype" ]; then
                module_loadable_fix "$l_mname" "$l_mpname"
                module_loaded_fix "$l_mname"
            fi
        else
            echo " - Module: $l_mname doesn't exist in $l_mdir"
        fi
    done
    
    echo " - Remediation of module: $l_mname complete"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_dccp_module
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: dccp kernel module properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="