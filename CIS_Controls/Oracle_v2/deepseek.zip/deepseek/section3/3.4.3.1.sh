#!/usr/bin/env bash
# Script: 3.4.3.1.sh
# Item: 3.4.3.1 Ensure nftables is installed (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.1.sh"
ITEM_NAME="3.4.3.1 Ensure nftables is installed (Automated)"
DESCRIPTION="This remediation ensures nftables is installed on the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables installation..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    echo "PASS: nftables properly installed"
    echo "PROOF: nftables package is installed"
    return 0
}
# Function to fix
fix_nftables_installation() {
    echo "Applying fix..."
    
    # Install nftables package
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package"
        yum install -y nftables
    else
        echo " - nftables package already installed"
    fi
    
    echo " - nftables installation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_installation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables properly installed"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="