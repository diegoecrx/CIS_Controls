#!/usr/bin/env bash

# Script: 4.2.7.sh
# Item: 4.2.7 Ensure sshd ClientAliveInterval and ClientAliveCountMax are configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.7.sh"
ITEM_NAME="4.2.7 Ensure sshd ClientAliveInterval and ClientAliveCountMax are configured (Automated)"
DESCRIPTION="This remediation ensures SSH ClientAliveInterval and ClientAliveCountMax directives are configured in sshd_config."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH ClientAlive configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"

# Recommended values (CIS suggests 15 seconds and 3 retries max)
CLIENT_ALIVE_INTERVAL="15"
CLIENT_ALIVE_COUNT_MAX="3"

if [ ! -f "$SSHD_CONFIG" ]; then
  echo "ERROR: $SSHD_CONFIG not found"
  exit 1
fi

# Check current configuration
echo "Current ClientAliveInterval directive in $SSHD_CONFIG:"
current_interval=$(grep -Pi '^\s*ClientAliveInterval\s+' "$SSHD_CONFIG" || echo "Not configured")
echo "$current_interval"

echo ""
echo "Current ClientAliveCountMax directive in $SSHD_CONFIG:"
current_count=$(grep -Pi '^\s*ClientAliveCountMax\s+' "$SSHD_CONFIG" || echo "Not configured")
echo "$current_count"
echo ""

echo "Applying remediation..."
echo ""

# Backup sshd_config
cp "$SSHD_CONFIG" "${SSHD_CONFIG}.bak.$(date +%Y%m%d%H%M%S)"
echo " - Created backup of $SSHD_CONFIG"

# Remove any existing ClientAliveInterval directives (commented or uncommented)
sed -i '/^\s*#\?\s*ClientAliveInterval\s/d' "$SSHD_CONFIG"
echo " - Removed existing ClientAliveInterval directives"

# Remove any existing ClientAliveCountMax directives (commented or uncommented)
sed -i '/^\s*#\?\s*ClientAliveCountMax\s/d' "$SSHD_CONFIG"
echo " - Removed existing ClientAliveCountMax directives"

# Find the line number of the first Match directive
match_line=$(grep -n "^Match" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "")

if [ -n "$match_line" ]; then
  # Insert directives before Match
  sed -i "${match_line}i ClientAliveInterval $CLIENT_ALIVE_INTERVAL" "$SSHD_CONFIG"
  sed -i "${match_line}i ClientAliveCountMax $CLIENT_ALIVE_COUNT_MAX" "$SSHD_CONFIG"
  echo " - Inserted 'ClientAliveInterval $CLIENT_ALIVE_INTERVAL' before Match directive"
  echo " - Inserted 'ClientAliveCountMax $CLIENT_ALIVE_COUNT_MAX' before Match directive"
else
  # No Match directive, append to end
  echo "" >> "$SSHD_CONFIG"
  echo "ClientAliveInterval $CLIENT_ALIVE_INTERVAL" >> "$SSHD_CONFIG"
  echo "ClientAliveCountMax $CLIENT_ALIVE_COUNT_MAX" >> "$SSHD_CONFIG"
  echo " - Appended 'ClientAliveInterval $CLIENT_ALIVE_INTERVAL' to end of file"
  echo " - Appended 'ClientAliveCountMax $CLIENT_ALIVE_COUNT_MAX' to end of file"
fi

echo ""
echo " - SUCCESS: Applied ClientAlive configuration"
echo ""

echo "Remediation of SSH ClientAlive configuration complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

final_status_pass=true

echo ""
echo "1. VERIFYING ClientAliveInterval IS SET:"
echo "----------------------------------------"

current_interval=$(grep -Pi '^\s*ClientAliveInterval\s+' "$SSHD_CONFIG" || true)

if [ -n "$current_interval" ]; then
  echo "PASS: ClientAliveInterval directive is configured"
  echo "PROOF:"
  echo "$current_interval"
  
  # Extract the value
  interval_value=$(echo "$current_interval" | awk '{print $2}' | grep -o '[0-9]*')
  
  if [ -n "$interval_value" ] && [ "$interval_value" -gt 0 ] && [ "$interval_value" -le 900 ]; then
    echo "PASS: ClientAliveInterval is set to $interval_value (within recommended range 1-900)"
  else
    echo "WARNING: ClientAliveInterval value may be outside recommended range"
  fi
else
  echo "FAIL: ClientAliveInterval directive is NOT configured"
  final_status_pass=false
fi

echo ""
echo "2. VERIFYING ClientAliveCountMax IS SET:"
echo "----------------------------------------"

current_count=$(grep -Pi '^\s*ClientAliveCountMax\s+' "$SSHD_CONFIG" || true)

if [ -n "$current_count" ]; then
  echo "PASS: ClientAliveCountMax directive is configured"
  echo "PROOF:"
  echo "$current_count"
  
  # Extract the value
  count_value=$(echo "$current_count" | awk '{print $2}' | grep -o '[0-9]*')
  
  if [ -n "$count_value" ] && [ "$count_value" -le 3 ]; then
    echo "PASS: ClientAliveCountMax is set to $count_value (within recommended range 0-3)"
  else
    echo "WARNING: ClientAliveCountMax value may be higher than recommended"
  fi
else
  echo "FAIL: ClientAliveCountMax directive is NOT configured"
  final_status_pass=false
fi

echo ""
echo "3. VERIFYING SSHD CONFIGURATION SYNTAX:"
echo "---------------------------------------"

if sshd -t 2>&1; then
  echo "PASS: SSHD configuration syntax is valid"
else
  echo "FAIL: SSHD configuration has syntax errors"
  echo "PROOF:"
  sshd -t 2>&1 || true
  final_status_pass=false
fi

echo ""
echo "4. RELOADING SSHD SERVICE:"
echo "-------------------------"

if systemctl reload-or-try-restart sshd.service 2>&1; then
  echo "PASS: SSHD service reloaded successfully"
else
  echo "FAIL: Failed to reload SSHD service"
  final_status_pass=false
fi

echo ""
echo "5. VERIFYING SSHD SERVICE STATUS:"
echo "---------------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "PASS: SSHD service is active"
  echo "PROOF:"
  systemctl status sshd.service --no-pager -l | head -10
else
  echo "FAIL: SSHD service is not active"
  final_status_pass=false
fi

echo ""
echo "6. TESTING ACTUAL CONFIGURATION IN USE:"
echo "---------------------------------------"

echo "PROOF (sshd -T output for ClientAlive settings):"
sshd -T | grep -i "^clientalive" || echo "Could not retrieve ClientAlive configuration"

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
