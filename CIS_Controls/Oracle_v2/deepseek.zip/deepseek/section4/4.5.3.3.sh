#!/usr/bin/env bash
# Script: 4.5.3.3.sh
# Item: 4.5.3.3 Ensure default user umask is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.3.3.sh"
ITEM_NAME="4.5.3.3 Ensure default user umask is configured (Automated)"
DESCRIPTION="This remediation ensures default user umask is 0027 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current umask settings
check_umask_settings() {
    echo "Checking umask settings in system files..."
    l_output=""
    l_output2=""
    
    # Check /etc/profile.d/*.sh files
    while IFS= read -r -d $'\0' l_file; do
        if [ -f "$l_file" ]; then
            if grep -q 'umask 027' "$l_file" 2>/dev/null; then
                l_output="$l_output\n - umask is set correctly in \"$l_file\""
            elif grep -q 'umask' "$l_file" 2>/dev/null; then
                l_output2="$l_output2\n - \"$l_file\""
            fi
        fi
    done < <(find /etc/profile.d/ -type f -name '*.sh' -print0 2>/dev/null || true)
    
    # Check /etc/profile
    if [ -f /etc/profile ]; then
        if grep -q 'umask 027' /etc/profile 2>/dev/null; then
            l_output="$l_output\n - umask is set correctly in \"/etc/profile\""
        elif grep -q 'umask' /etc/profile 2>/dev/null; then
            l_output2="$l_output2\n - \"/etc/profile\""
        fi
    fi
    
    # Check /etc/bashrc
    if [ -f /etc/bashrc ]; then
        if grep -q 'umask 027' /etc/bashrc 2>/dev/null; then
            l_output="$l_output\n - umask is set correctly in \"/etc/bashrc\""
        elif grep -q 'umask' /etc/bashrc 2>/dev/null; then
            l_output2="$l_output2\n - \"/etc/bashrc\""
        fi
    fi
    
    # Check /etc/login.defs
    if [ -f /etc/login.defs ]; then
        if grep -q 'UMASK 027' /etc/login.defs 2>/dev/null; then
            l_output="$l_output\n - UMASK is set correctly in \"/etc/login.defs\""
        elif grep -q 'UMASK' /etc/login.defs 2>/dev/null; then
            l_output2="$l_output2\n - \"/etc/login.defs\""
        fi
    fi
    
    if [ -z "$l_output2" ]; then
        if [ -n "$l_output" ]; then
            echo "PASS: Restrictive umask is configured"
            echo "PROOF:$l_output"
            return 0
        else
            return 1
        fi
    else
        echo "FAIL: Non-restrictive umask found in:$l_output2"
        return 1
    fi
}
# Function to fix umask settings
fix_umask_settings() {
    echo "Fixing umask settings..."
    
    # Remove non-restrictive umask from /etc/profile and /etc/bashrc
    sed -i '/^[[:space:]]*umask[[:space:]]*022/d' /etc/profile 2>/dev/null || true
    sed -i '/^[[:space:]]*umask[[:space:]]*022/d' /etc/bashrc 2>/dev/null || true
    
    # Remove non-restrictive umask from /etc/profile.d/*.sh
    if [ -d /etc/profile.d ]; then
        for file in /etc/profile.d/*.sh; do
            if [ -f "$file" ]; then
                sed -i '/^[[:space:]]*umask[[:space:]]*022/d' "$file"
            fi
        done
    fi
    
    # Check if umask is already configured correctly, if not add it
    if ! grep -q 'umask 027' /etc/profile 2>/dev/null; then
        echo "" >> /etc/profile
        echo "# Set umask for security" >> /etc/profile
        echo "umask 027" >> /etc/profile
        echo " - Configured umask 027 in /etc/profile"
    fi
    
    # Update /etc/login.defs
    if [ -f /etc/login.defs ]; then
        sed -i 's/^UMASK.*/UMASK 027/' /etc/login.defs
        if ! grep -q '^UMASK' /etc/login.defs; then
            echo "UMASK 027" >> /etc/login.defs
        fi
        echo " - Configured UMASK 027 in /etc/login.defs"
    fi
}
# Main remediation
{
    umask_ok=true
    if ! check_umask_settings; then
        umask_ok=false
    fi
    if [ "$umask_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_umask_settings
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_umask_settings; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Default user umask is properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
