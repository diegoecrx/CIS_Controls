#!/usr/bin/env bash

# Script: 4.2.5.sh
# Item: 4.2.5 Ensure sshd Banner is configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.5.sh"
ITEM_NAME="4.2.5 Ensure sshd Banner is configured (Automated)"
DESCRIPTION="This remediation ensures the SSH Banner directive is set to /etc/issue.net in sshd_config."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH Banner configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"
BANNER_FILE="/etc/issue.net"

if [ ! -f "$SSHD_CONFIG" ]; then
  echo "ERROR: $SSHD_CONFIG not found"
  exit 1
fi

# Check current Banner configuration
echo "Current Banner directive in $SSHD_CONFIG:"
current_banner=$(grep -Pi '^\s*Banner\s+' "$SSHD_CONFIG" || echo "Not configured")
echo "$current_banner"
echo ""

# Create /etc/issue.net if it doesn't exist
if [ ! -f "$BANNER_FILE" ]; then
  echo "WARNING: $BANNER_FILE does not exist - creating with default content"
  cat > "$BANNER_FILE" << 'EOF'
Authorized access only!
Unauthorized access to this system is forbidden and will be prosecuted by law.
By accessing this system, you agree that your actions may be monitored.
EOF
  echo "Created $BANNER_FILE with default warning banner"
  echo ""
fi

echo "Applying remediation..."
echo ""

# Backup sshd_config
cp "$SSHD_CONFIG" "${SSHD_CONFIG}.bak.$(date +%Y%m%d%H%M%S)"
echo " - Created backup of $SSHD_CONFIG"

# Remove any existing Banner directives (commented or uncommented)
sed -i '/^\s*#\?\s*Banner\s/d' "$SSHD_CONFIG"
echo " - Removed existing Banner directives"

# Find the line number of the first Match directive
match_line=$(grep -n "^Match" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "")

if [ -n "$match_line" ]; then
  # Insert Banner directive before Match
  sed -i "${match_line}i Banner $BANNER_FILE" "$SSHD_CONFIG"
  echo " - Inserted 'Banner $BANNER_FILE' before Match directive at line $match_line"
else
  # No Match directive, append to end
  echo "" >> "$SSHD_CONFIG"
  echo "Banner $BANNER_FILE" >> "$SSHD_CONFIG"
  echo " - Appended 'Banner $BANNER_FILE' to end of file"
fi

echo ""
echo " - SUCCESS: Applied Banner configuration"
echo ""

echo "Remediation of SSH Banner configuration complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

final_status_pass=true

echo ""
echo "1. VERIFYING BANNER DIRECTIVE IS SET:"
echo "-------------------------------------"

current_banner=$(grep -Pi '^\s*Banner\s+' "$SSHD_CONFIG" || true)

if [ -n "$current_banner" ]; then
  echo "PASS: Banner directive is configured"
  echo "PROOF:"
  echo "$current_banner"
  
  # Check if it points to /etc/issue.net
  if echo "$current_banner" | grep -q "/etc/issue.net"; then
    echo "PASS: Banner is set to /etc/issue.net"
  else
    echo "WARNING: Banner is not set to /etc/issue.net"
    echo "Current value: $current_banner"
    final_status_pass=false
  fi
else
  echo "FAIL: Banner directive is NOT configured"
  final_status_pass=false
fi

echo ""
echo "2. VERIFYING BANNER FILE EXISTS:"
echo "--------------------------------"

if [ -f "$BANNER_FILE" ]; then
  echo "PASS: $BANNER_FILE exists"
  echo "PROOF (file content):"
  cat "$BANNER_FILE"
else
  echo "FAIL: $BANNER_FILE does not exist"
  final_status_pass=false
fi

echo ""
echo "3. VERIFYING SSHD CONFIGURATION SYNTAX:"
echo "---------------------------------------"

if sshd -t 2>&1; then
  echo "PASS: SSHD configuration syntax is valid"
else
  echo "FAIL: SSHD configuration has syntax errors"
  echo "PROOF:"
  sshd -t 2>&1 || true
  final_status_pass=false
fi

echo ""
echo "4. RELOADING SSHD SERVICE:"
echo "-------------------------"

if systemctl reload-or-try-restart sshd.service 2>&1; then
  echo "PASS: SSHD service reloaded successfully"
else
  echo "FAIL: Failed to reload SSHD service"
  final_status_pass=false
fi

echo ""
echo "5. VERIFYING SSHD SERVICE STATUS:"
echo "---------------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "PASS: SSHD service is active"
  echo "PROOF:"
  systemctl status sshd.service --no-pager -l | head -10
else
  echo "FAIL: SSHD service is not active"
  final_status_pass=false
fi

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
