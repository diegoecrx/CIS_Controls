#!/usr/bin/env bash
# Script: 4.2.13.sh
# Item: 4.2.13 Ensure sshd LoginGraceTime is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.13.sh"
ITEM_NAME="4.2.13 Ensure sshd LoginGraceTime is configured (Automated)"
DESCRIPTION="This remediation ensures sshd LoginGraceTime is configured to 60 in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^LoginGraceTime' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && (echo "$conf_line" | grep -qi '60' || echo "$conf_line" | grep -qi '1m'); then
        echo "PASS: LoginGraceTime is 60 or 1m"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: LoginGraceTime not 60 or 1m"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_logingracetime() {
    echo "Applying fix..."
    sed -i '/^LoginGraceTime/d' /etc/ssh/sshd_config
    echo "LoginGraceTime 60" >> /etc/ssh/sshd_config
    echo " - Set LoginGraceTime 60"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_logingracetime
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: LoginGraceTime configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="