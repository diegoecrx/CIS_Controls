#!/usr/bin/env bash
# Script: 4.5.2.4.sh
# Item: 4.5.2.4 Ensure root password is set (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.2.4.sh"
ITEM_NAME="4.5.2.4 Ensure root password is set (Automated)"
DESCRIPTION="This remediation ensures the root account has a password set."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check if root password is set
check_root_password() {
    echo "Checking root password status..."
    root_shadow=$(grep '^root:' /etc/shadow | awk -F: '{print $2}')
    
    if [ -z "$root_shadow" ]; then
        echo "FAIL: root shadow entry is empty"
        echo "PROOF: grep '^root:' /etc/shadow shows empty password field"
        return 1
    fi
    
    # Check if password field is locked (!) or disabled (*)
    if [[ "$root_shadow" == "!"* ]] || [[ "$root_shadow" == "*"* ]]; then
        echo "FAIL: root account is locked or has no password set"
        echo "PROOF: Password field is $root_shadow"
        return 1
    fi
    
    # Check if password field contains a valid hash
    if [[ "$root_shadow" =~ ^\$[0-9]+ ]]; then
        echo "PASS: root account has a password set"
        echo "PROOF: Password field contains a valid hash"
        return 0
    else
        echo "FAIL: root account password is not properly hashed"
        echo "PROOF: Password field is $root_shadow"
        return 1
    fi
}
# Main remediation
{
    password_ok=true
    if ! check_root_password; then
        password_ok=false
    fi
    if [ "$password_ok" = true ]; then
        echo "No remediation needed"
    else
        echo ""
        echo "==================================================================="
        echo "MANUAL INTERVENTION REQUIRED"
        echo "==================================================================="
        echo "To set the root password, run:"
        echo "# passwd root"
        echo ""
        echo "You will be prompted to enter a new root password."
        echo "The password must meet complexity requirements:"
        echo "- At least 8 characters long"
        echo "- Mix of uppercase, lowercase, numbers, and special characters"
        echo ""
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_root_password; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: root password is set"
    else
        echo "FAIL: root password is not set - manual intervention required"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
