#!/usr/bin/env bash
# Script: 4.4.2.4.4.sh
# Item: 4.4.2.4.4 Ensure pam_unix includes use_authtok (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.2.4.4.sh"
ITEM_NAME="4.4.2.4.4 Ensure pam_unix includes use_authtok (Automated)"
DESCRIPTION="This remediation ensures password pam_unix line includes use_authtok argument."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check PAM files for use_authtok on password pam_unix line
check_pam_files() {
    echo "Checking PAM files for use_authtok on password pam_unix line..."
    fail=false
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo "Checking $file..."
        unix_password_line=$(grep '^password.*pam_unix.so' "$file" || true)
        if [ -z "$unix_password_line" ]; then
            echo "FAIL: No password pam_unix.so line found in $file"
            echo "PROOF: No password pam_unix.so line"
            fail=true
        else
            if echo "$unix_password_line" | grep -q 'use_authtok'; then
                echo "PASS: use_authtok present on password pam_unix line in $file"
                echo "PROOF: $unix_password_line"
            else
                echo "FAIL: use_authtok missing on password pam_unix line in $file"
                echo "PROOF: $unix_password_line"
                fail=true
            fi
        fi
    done
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix PAM files
fix_pam_files() {
    echo "Fixing PAM files..."
    for file in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
        echo " - Processing $file"
        if grep -q '^password.*pam_unix.so' "$file"; then
            if ! grep -q '^password.*pam_unix.so.*use_authtok' "$file"; then
                sed -ri '/^password.*pam_unix.so/ s/$/ use_authtok/' "$file"
                echo "   - Added use_authtok to password pam_unix line"
            else
                echo "   - use_authtok already present"
            fi
        fi
    done
}
# Main remediation
{
    pam_ok=true
    if ! check_pam_files; then
        pam_ok=false
    fi
    if [ "$pam_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_pam_files
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_pam_files; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: pam_unix includes use_authtok"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
