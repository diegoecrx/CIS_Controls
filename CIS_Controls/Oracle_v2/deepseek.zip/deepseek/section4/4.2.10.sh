#!/usr/bin/env bash
# Script: 4.2.10.sh
# Item: 4.2.10 Ensure sshd HostbasedAuthentication is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.10.sh"
ITEM_NAME="4.2.10 Ensure sshd HostbasedAuthentication is disabled (Automated)"
DESCRIPTION="This remediation ensures sshd HostbasedAuthentication is disabled by setting to no in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^HostbasedAuthentication' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -qi 'no'; then
        echo "PASS: HostbasedAuthentication no set"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: HostbasedAuthentication not no"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_hostbased() {
    echo "Applying fix..."
    sed -i '/^HostbasedAuthentication/d' /etc/ssh/sshd_config
    echo "HostbasedAuthentication no" >> /etc/ssh/sshd_config
    echo " - Set HostbasedAuthentication no"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_hostbased
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: HostbasedAuthentication disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="