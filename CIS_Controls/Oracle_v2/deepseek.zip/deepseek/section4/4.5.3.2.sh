#!/usr/bin/env bash
# Script: 4.5.3.2.sh
# Item: 4.5.3.2 Ensure default user shell timeout is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.3.2.sh"
ITEM_NAME="4.5.3.2 Ensure default user shell timeout is configured (Automated)"
DESCRIPTION="This remediation ensures shell timeout (TMOUT) is configured to 900 seconds or less."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check TMOUT configuration
check_tmout() {
    echo "Checking TMOUT configuration..."
    TMOUT_VAL=0
    found=false
    
    # Check /etc/profile
    if [ -f /etc/profile ]; then
        profile_tmout=$(grep -E 'TMOUT=' /etc/profile | grep -v '^#' | head -1 || true)
        if [ -n "$profile_tmout" ]; then
            TMOUT_VAL=$(echo "$profile_tmout" | sed 's/.*TMOUT=\([0-9]*\).*/\1/')
            found=true
            echo "Found TMOUT in /etc/profile: $TMOUT_VAL"
        fi
    fi
    
    # Check /etc/bashrc
    if [ -f /etc/bashrc ] && [ "$found" = false ]; then
        bashrc_tmout=$(grep -E 'TMOUT=' /etc/bashrc | grep -v '^#' | head -1 || true)
        if [ -n "$bashrc_tmout" ]; then
            TMOUT_VAL=$(echo "$bashrc_tmout" | sed 's/.*TMOUT=\([0-9]*\).*/\1/')
            found=true
            echo "Found TMOUT in /etc/bashrc: $TMOUT_VAL"
        fi
    fi
    
    # Check /etc/profile.d/*.sh files
    if [ "$found" = false ] && [ -d /etc/profile.d ]; then
        for file in /etc/profile.d/*.sh; do
            if [ -f "$file" ]; then
                profiled_tmout=$(grep -E 'TMOUT=' "$file" | grep -v '^#' | head -1 || true)
                if [ -n "$profiled_tmout" ]; then
                    TMOUT_VAL=$(echo "$profiled_tmout" | sed 's/.*TMOUT=\([0-9]*\).*/\1/')
                    found=true
                    echo "Found TMOUT in $file: $TMOUT_VAL"
                    break
                fi
            fi
        done
    fi
    
    if [ "$found" = false ] || [ "$TMOUT_VAL" = "0" ]; then
        echo "FAIL: TMOUT is not properly configured"
        echo "PROOF: No valid TMOUT found or TMOUT=0"
        return 1
    fi
    
    if [ "$TMOUT_VAL" -le 900 ] && [ "$TMOUT_VAL" -gt 0 ]; then
        echo "PASS: TMOUT is set to $TMOUT_VAL (1-900 seconds)"
        echo "PROOF: TMOUT=$TMOUT_VAL"
        return 0
    else
        echo "FAIL: TMOUT is set to $TMOUT_VAL (should be 1-900)"
        echo "PROOF: TMOUT=$TMOUT_VAL"
        return 1
    fi
}
# Function to fix TMOUT configuration
fix_tmout() {
    echo "Fixing TMOUT configuration..."
    
    # Remove any existing TMOUT settings
    sed -i '/TMOUT=/d' /etc/profile 2>/dev/null || true
    sed -i '/TMOUT=/d' /etc/bashrc 2>/dev/null || true
    
    if [ -d /etc/profile.d ]; then
        for file in /etc/profile.d/*.sh; do
            if [ -f "$file" ]; then
                sed -i '/TMOUT=/d' "$file"
            fi
        done
    fi
    
    # Add TMOUT to /etc/profile
    echo "" >> /etc/profile
    echo "# Set session timeout" >> /etc/profile
    echo "TMOUT=900" >> /etc/profile
    echo "readonly TMOUT" >> /etc/profile
    echo "export TMOUT" >> /etc/profile
    
    echo " - Configured TMOUT=900 in /etc/profile"
}
# Main remediation
{
    tmout_ok=true
    if ! check_tmout; then
        tmout_ok=false
    fi
    if [ "$tmout_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_tmout
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_tmout; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Shell timeout is properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
