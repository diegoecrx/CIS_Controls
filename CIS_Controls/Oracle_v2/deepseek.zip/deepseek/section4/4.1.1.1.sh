#!/usr/bin/env bash
# Script: 4.1.1.1.sh
# Item: 4.1.1.1 Ensure cron daemon is enabled and active (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures the cron daemon (crond) is enabled and active by unmasking, enabling and starting the service.

set -euo pipefail

SCRIPT_NAME="4.1.1.1.sh"
ITEM_NAME="4.1.1.1 Ensure cron daemon is enabled and active (Automated)"
DESCRIPTION="This remediation ensures the cron daemon (crond) is enabled and active by unmasking, enabling and starting the service."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

systemctl unmask crond 2>/dev/null || true
systemctl --now enable crond 2>/dev/null

# Verification
status=$(systemctl is-enabled crond 2>/dev/null)
active=$(systemctl is-active crond 2>/dev/null)

if [ "$status" = "enabled" ] && [ "$active" = "active" ]; then
  echo "SUCCESS: crond is enabled and active."
else
  echo "FAIL: crond could not be enabled and/or started."
  echo "Status: $status, Active: $active"
fi

echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
