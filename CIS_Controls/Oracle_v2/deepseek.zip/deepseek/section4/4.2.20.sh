#!/usr/bin/env bash
# Script: 4.2.20.sh
# Item: 4.2.20 Ensure sshd PermitRootLogin is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.20.sh"
ITEM_NAME="4.2.20 Ensure sshd PermitRootLogin is disabled (Automated)"
DESCRIPTION="This remediation ensures sshd PermitRootLogin is disabled by setting to no in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^PermitRootLogin' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -qi 'no'; then
        echo "PASS: PermitRootLogin no set"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: PermitRootLogin not no"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_permitrootlogin() {
    echo "Applying fix..."
    sed -i '/^PermitRootLogin/d' /etc/ssh/sshd_config
    echo "PermitRootLogin no" >> /etc/ssh/sshd_config
    echo " - Set PermitRootLogin no"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_permitrootlogin
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: PermitRootLogin disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="