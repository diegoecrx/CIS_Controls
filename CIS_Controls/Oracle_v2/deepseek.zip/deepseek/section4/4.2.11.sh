#!/usr/bin/env bash
# Script: 4.2.11.sh
# Item: 4.2.11 Ensure sshd IgnoreRhosts is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.11.sh"
ITEM_NAME="4.2.11 Ensure sshd IgnoreRhosts is enabled (Automated)"
DESCRIPTION="This remediation ensures sshd IgnoreRhosts is enabled by setting to yes in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^IgnoreRhosts' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -qi 'yes'; then
        echo "PASS: IgnoreRhosts yes set"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: IgnoreRhosts not yes"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_ignore_rhosts() {
    echo "Applying fix..."
    sed -i '/^IgnoreRhosts/d' /etc/ssh/sshd_config
    echo "IgnoreRhosts yes" >> /etc/ssh/sshd_config
    echo " - Set IgnoreRhosts yes"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ignore_rhosts
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: IgnoreRhosts enabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="