#!/usr/bin/env bash
# Script: 4.3.7.sh
# Item: 4.3.7 Ensure access to the su command is restricted (Automated)
set -euo pipefail
SCRIPT_NAME="4.3.7.sh"
ITEM_NAME="4.3.7 Ensure access to the su command is restricted (Automated)"
DESCRIPTION="This remediation ensures access to su is restricted by creating sugroup and configuring pam_wheel."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking su restriction..."
    if getent group sugroup >/dev/null; then
        group_status="PASS: sugroup exists"
    else
        group_status="FAIL: sugroup does not exist"
    fi
    pam_line=$(grep '^auth required pam_wheel.so use_uid group=sugroup' /etc/pam.d/su || true)
    if [ -n "$pam_line" ]; then
        pam_status="PASS: PAM line present"
    else
        pam_status="FAIL: PAM line missing"
    fi
    echo "$group_status"
    echo "PROOF: $(getent group sugroup || echo "No group")"
    echo "$pam_status"
    echo "PROOF: $pam_line"
    if [[ "$group_status" == PASS* ]] && [[ "$pam_status" == PASS* ]]; then
        return 0
    else
        return 1
    fi
}
# Function to fix
fix_su_restriction() {
    echo "Applying fix..."
    if ! getent group sugroup >/dev/null; then
        groupadd sugroup
        echo " - Created sugroup"
    fi
    if ! grep -q '^auth required pam_wheel.so use_uid group=sugroup' /etc/pam.d/su; then
        echo "auth required pam_wheel.so use_uid group=sugroup" >> /etc/pam.d/su
        echo " - Added PAM line"
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_su_restriction
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: su access restricted"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="