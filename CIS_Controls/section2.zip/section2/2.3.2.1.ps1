###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.2.1 (L1) Ensure
# 'Audit: Force audit policy subcategory settings (Windows Vista or later)
#  to override audit policy category settings' is set to 'Enabled' (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\
#   Audit: Force audit policy subcategory settings (Windows Vista or later)
#          to override audit policy category settings
#
# Mechanism: Sets HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy = 1
# Applies to: Domain Controllers and Member/Standalone servers
# Post-change: Forces Group Policy refresh
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.2.1 (L1) Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled' (Automated)"
$POLICY_PATH        = "Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings"
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Enabled"
$TARGET_STATE_TEXT  = "Enabled"

# Registry details
$RegPath  = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
$RegName  = 'SCENoApplyLegacyAuditPolicy'   # DWORD: 1=Enabled, 0 or missing=Disabled
$TargetDW = 1

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}

function Get-AuditOverrideState {
    try {
        $val = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName
        if ($null -eq $val) { return 'Disabled' }
        if ([int]$val -eq 1) { 'Enabled' } else { 'Disabled' }
    } catch { 'Unknown' }
}

function Set-AuditOverrideEnabled {
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    New-ItemProperty -Path $RegPath -Name $RegName -PropertyType DWord -Value $TargetDW -Force | Out-Null
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.2.1.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure the system uses audit *subcategory* policy and ignores legacy category policy (Enabled)."
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController | ForEach-Object { $_ }

# Read current value (pre)
$pre = Get-AuditOverrideState
Write-Host ("Current status: {0}" -f $pre)
Write-Host ""
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
}
Write-Host ""

# Remediate if needed
$changed = $false
if ($pre -ne $TARGET_STATE_TEXT) {
    Write-Host "[ACTION] Enabling audit subcategory override (setting SCENoApplyLegacyAuditPolicy=1) ..."
    Set-AuditOverrideEnabled | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify post
$post       = Get-AuditOverrideState
$compliant  = ($post -eq $TARGET_STATE_TEXT)

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Audit: Force audit policy subcategory override : target={0}  pre={1}  post={2}" -f $TARGET_STATE_TEXT, $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if ($compliant) {'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if ($changed) {'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
