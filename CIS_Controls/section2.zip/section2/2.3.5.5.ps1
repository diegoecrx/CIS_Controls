###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.5.5 (L1) Ensure
# 'Domain controller: Require strong (Windows 2000 or later) session key'
# is set to 'Enabled' (DC only) (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\
#   Domain controller: Require strong (Windows 2000 or later) session key
#
# Mechanism: Sets HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters\RequireStrongKey
#   REG_DWORD: 1 = Enabled (CIS target)
#              0 = Disabled
# Applies to: Domain Controllers only (Member/Standalone -> N/A)
# Post-change: Forces Group Policy refresh
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.5.5 (L1) Ensure 'Domain controller: Require strong (Windows 2000 or later) session key' is set to 'Enabled' (DC only)"
$POLICY_PATH        = "Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Domain controller: Require strong (Windows 2000 or later) session key"
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Enabled (DC only)."
$TARGET_STATE_TEXT  = "Enabled"

# Registry details
$RegPath  = 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters'
$RegName  = 'RequireStrongKey'     # DWORD: 1=Enabled, 0=Disabled
$TargetDW = 1

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}

function Get-RequireStrongKeyState {
    try {
        $val = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName
        if ($null -eq $val) { return 'Disabled' }  # Not defined behaves as Disabled
        if ([int]$val -eq 1) { 'Enabled' } else { 'Disabled' }
    } catch { 'Unknown' }
}

function Set-RequireStrongKeyEnabled {
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    New-ItemProperty -Path $RegPath -Name $RegName -PropertyType DWord -Value $TargetDW -Force | Out-Null
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.5.5.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Require strong (Windows 2000 or later) secure channel session keys on Domain Controllers (Enabled)."
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController

# Read current value (pre)
$pre = Get-RequireStrongKeyState
Write-Host ("Current status: {0}" -f $pre)
Write-Host ""

if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
    Write-Host ""

    $changed = $false
    if ($pre -ne $TARGET_STATE_TEXT) {
        Write-Host "[ACTION] Enabling 'RequireStrongKey' (setting to 1) ..."
        Set-RequireStrongKeyEnabled | Out-Null
        $changed = $true
    }

    try {
        gpupdate /target:computer /force | Out-Null
        secedit /refreshpolicy machine_policy /enforce | Out-Null
    } catch { }

    $post      = Get-RequireStrongKeyState
    $compliant = ($post -eq $TARGET_STATE_TEXT)

} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "This control applies to Domain Controllers only. Skipping remediation."
    Write-Host ""
    $changed   = $false
    $post      = $pre
    $compliant = $false
}

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Domain controller: Require strong session key : target={0}  pre={1}  post={2}" -f $TARGET_STATE_TEXT, $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if ($compliant) {'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if ($changed) {'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
