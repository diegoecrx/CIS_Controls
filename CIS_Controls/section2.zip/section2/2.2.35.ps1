###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.2.35 (L1) Ensure 'Restore files and directories'
# is set to 'Administrators, Backup Operators' (Automated)
#
# Configures user right:
#   SeRestorePrivilege ("Restore files and directories")
# Applies via Local Security Policy (secedit) on DCs and Member/Standalone,
# then forces a policy refresh.
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.2.35 (L1) Ensure 'Restore files and directories' is set to 'Administrators, Backup Operators' (Automated)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\User Rights Assignment\Restore files and directories'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Administrators, Backup Operators (CIS requirement)."
$RIGHT_KEY          = 'SeRestorePrivilege'               # [Privilege Rights] key
$TARGET_LIST        = @('*S-1-5-32-544','*S-1-5-32-551') # Administrators, Backup Operators (SIDs)

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -First 1).DomainRole
        return ($role -ge 4)    # 4/5 = DC roles
    } catch { return $false }
}

function To-Display-PrincipalList([string[]]$arr){
    if ($null -eq $arr -or $arr.Count -eq 0) { return 'No one' }
    return ($arr -join ', ')
}

# Read current principals for a user right from secedit export.
function Get-UserRight([string]$rightKey){
    $tmpName = "secexport_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $tmpPath = Join-Path $env:TEMP $tmpName
    try{
        secedit /export /cfg $tmpPath /quiet | Out-Null
        $content = Get-Content $tmpPath -Raw
        $block = [regex]::Match($content,"(\[Privilege Rights\]\s*)(?<body>[\s\S]*?)(\r?\n\[|$)",'Singleline').Groups['body'].Value
        if (-not $block) { return @() }
        $line  = ($block -split "(\r?\n)") | Where-Object { $_ -match "^\s*$([regex]::Escape($rightKey))\s*=\s*(.*)$" } | Select-Object -First 1
        if (-not $line){ return @() }
        $value = [regex]::Match($line,"=\s*(.*)$").Groups[1].Value.Trim()
        if ([string]::IsNullOrWhiteSpace($value)){ return @() }
        $parts = $value -split '\s*,\s*' | Where-Object { $_ -and $_ -ne '' }
        return ,$parts
    } finally {
        Remove-Item $tmpPath -Force -ErrorAction SilentlyContinue
    }
}

# Set the user right to exactly the provided principals.
function Set-UserRight([string]$rightKey, [string[]]$principals){
    $cfgName = "secpol_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $dbName  = "secedit_{0:yyyyMMdd_HHmmss}.sdb" -f (Get-Date)
    $bkpName = "secedit_backup_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)

    $tempCfg = Join-Path $env:TEMP $cfgName
    $dbPath  = Join-Path $env:TEMP $dbName
    $backup  = Join-Path $env:TEMP $bkpName

    # Backup current policy
    secedit /export /cfg $backup /quiet | Out-Null
    Write-Host "[BACKUP] Current security policy exported to: $backup"

    $val = ($principals -and $principals.Count -gt 0) ? ($principals -join ',') : ''
$template = @"
[Unicode]
Unicode=yes
[Privilege Rights]
$rightKey = $val
[Version]
signature="$`CHICAGO$`"
Revision=1
"@
    $template | Out-File -FilePath $tempCfg -Encoding Unicode -Force

    secedit /configure /db $dbPath /cfg $tempCfg /quiet | Out-Null
    Remove-Item $tempCfg -Force -ErrorAction SilentlyContinue
    return $true
}

# Compare two principal lists ignoring order/whitespace/case
function Compare-PrincipalSets([string[]]$a,[string[]]$b){
    $norm = { param($x) ($x | ForEach-Object { $_.Trim().ToUpperInvariant() }) | Sort-Object -Unique }
    $aa = & $norm $a
    $bb = & $norm $b
    if ($aa.Count -ne $bb.Count) { return $false }
    for($i=0;$i -lt $aa.Count;$i++){ if ($aa[$i] -ne $bb[$i]) { return $false } }
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation:"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Restore files and directories' is set to 'Administrators, Backup Operators' (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController | ForEach-Object { $_ }

# Read current value (pre)
$preList = Get-UserRight -rightKey $RIGHT_KEY
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $preList))
Write-Host ""

# Role banner
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
}
Write-Host ""

# Remediate if needed
$needChange = -not (Compare-PrincipalSets $preList $TARGET_LIST)
$changed = $false
if ($needChange) {
    Set-UserRight -rightKey $RIGHT_KEY -principals $TARGET_LIST | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify post
$postList  = Get-UserRight -rightKey $RIGHT_KEY
$compliant = (Compare-PrincipalSets $postList $TARGET_LIST)

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $postList))
$preDisp    = To-Display-PrincipalList $preList
$postDisp   = To-Display-PrincipalList $postList
$targetDisp = To-Display-PrincipalList $TARGET_LIST
Write-Host ("Restore Files And Directories : target={0}  pre={1}  post={2}" -f $targetDisp, $preDisp, $postDisp)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
