###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.6.5 (L1) Ensure
# 'Domain member: Maximum machine account password age'
# is set to '30 or fewer days, but not 0' (Member Server only) (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\
#   Domain member: Maximum machine account password age
#
# Mechanism: Sets HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters\MaximumPasswordAge
#   REG_DWORD: N (days). CIS target: 1..30 (not 0)
# Applies to: Member/Standalone servers (Domain Controllers -> N/A)
# Post-change: Forces Group Policy refresh
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME        = "2.3.6.5 (L1) Ensure 'Domain member: Maximum machine account password age' is set to '30 or fewer days, but not 0' (MS only)"
$POLICY_PATH         = "Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Domain member: Maximum machine account password age"
$PROFILE_DC          = "Level 1 - Domain Controller"
$PROFILE_MS          = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT  = "30 days (Windows default)."
$TARGET_TEXT         = "1..30 days (not 0)"
$TARGET_MAX_DAYS     = 30
$TARGET_MIN_DAYS     = 1

# Registry details
$RegPath  = 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters'
$RegName  = 'MaximumPasswordAge'     # DWORD (days)

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -First 1).DomainRole
        return ($role -ge 4)    # 4/5 = DC roles
    } catch { return $false }
}

function Get-MaxPwdAgeDays {
    try {
        $val = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName
        if ($null -eq $val) { return 30 }   # Treat undefined as Windows default (30)
        return [int]$val
    } catch { return $null }
}

function Set-MaxPwdAgeDays([int]$days) {
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    New-ItemProperty -Path $RegPath -Name $RegName -PropertyType DWord -Value $days -Force | Out-Null
    return $true
}

function Is-Compliant([Nullable[int]]$days){
    if ($days -eq $null) { return $false }
    return ($days -ge $TARGET_MIN_DAYS -and $days -le $TARGET_MAX_DAYS)
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.6.5.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure domain members rotate their machine account passwords within 30 days (or fewer), and not 0."
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController

# Read current value (pre)
$preDays = Get-MaxPwdAgeDays
$preText = if ($preDays -ne $null) { "$preDays days" } else { "Unknown" }

Write-Host ("Current status: {0}" -f $preText)
Write-Host ""

if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "This control applies to Member Servers only. Skipping remediation."
    Write-Host ""
    $changed   = $false
    $postDays  = $preDays
    $compliant = $false
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
    Write-Host ""

    $changed = $false
    if (-not (Is-Compliant $preDays)) {
        Write-Host ("[ACTION] Setting 'MaximumPasswordAge' to {0} days ..." -f $TARGET_MAX_DAYS)
        Set-MaxPwdAgeDays -days $TARGET_MAX_DAYS | Out-Null
        $changed = $true
    }

    # Force policy refresh
    try {
        gpupdate /target:computer /force | Out-Null
        secedit /refreshpolicy machine_policy /enforce | Out-Null
    } catch { }

    # Verify post
    $postDays  = Get-MaxPwdAgeDays
    $compliant = Is-Compliant $postDays
}

# ------------------------------- Status Block --------------------------------
$postText = if ($postDays -ne $null) { "$postDays days" } else { "Unknown" }

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $postText)
Write-Host ("Domain member: Maximum machine account password age : target={0}  pre={1}  post={2}" -f $TARGET_TEXT, $preText, $postText)
Write-Host ("Compliant: {0}" -f ($(if ($compliant) {'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if ($changed) {'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
