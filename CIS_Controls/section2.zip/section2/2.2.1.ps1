###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# 2.2.1.ps1
# CIS Control - 2.2.1 (L1) Ensure 'Access Credential Manager as a trusted caller'
# is set to 'No one' (Automated)
#
# This script remediates and verifies the user right:
#   SeTrustedCredManAccessPrivilege  ("Access Credential Manager as a trusted caller")
# on BOTH Domain Controllers and Member/Standalone servers using Local Security
# Policy (secedit). Domain-wide enforcement should be done via a GPO.
###############################################################################

<#
.SYNOPSIS
    Automated remediation for CIS Control 2.2.1 (Access Credential Manager as a trusted caller)

.DESCRIPTION
    Ensures 'Access Credential Manager as a trusted caller' is assigned to 'No one'
    per CIS 2.2.1 for Windows Server 2022.

    Profile Applicability:
      - Level 1 - Domain Controller
      - Level 1 - Member Server

    Typical default (Microsoft): Not Defined (effectively no one locally).

.NOTES
    Run as Administrator.
    Applies via Local Security Policy (secedit) and forces a policy refresh.
#>

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Script Metadata / Constants ----------------------
$SCRIPT_NAME        = "2.2.1.ps1"
$CONTROL_NAME       = "2.2.1 (L1) Ensure 'Access Credential Manager as a trusted caller' is set to 'No one' (Automated)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\User Rights Assignment\Access Credential Manager as a trusted caller'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Not Defined (no assignments)."
$RIGHT_KEY          = 'SeTrustedCredManAccessPrivilege'   # User Right key name in [Privilege Rights]
$TARGET_LIST        = @()  # "No one" -> empty list

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -First 1).DomainRole
        return ($role -ge 4)    # 4/5 = DC roles
    } catch { return $false }
}

function To-Display-PrincipalList([string[]]$arr){
    if ($null -eq $arr -or $arr.Count -eq 0) { return 'No one' }
    return ($arr -join ', ')
}

# Reads current principals assigned to a given user right from secedit export.
# Returns string[] (SIDs or account names), or empty array when not set.
function Get-UserRight([string]$rightKey){
    $tmpName = "secexport_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $tmpPath = Join-Path $env:TEMP $tmpName
    try {
        secedit /export /cfg $tmpPath /quiet | Out-Null
        $content = Get-Content $tmpPath -Raw
        # Extract [Privilege Rights] block robustly
        $block = [regex]::Match($content, "(\[Privilege Rights\]\s*)(?<body>[\s\S]*?)(\r?\n\[|$)", 'Singleline').Groups['body'].Value
        if (-not $block) { return @() }
        $line = ($block -split "(\r?\n)") | Where-Object { $_ -match "^\s*$([regex]::Escape($rightKey))\s*=\s*(.*)$" } | Select-Object -First 1
        if (-not $line) { return @() } # not defined
        $value = [regex]::Match($line, "=\s*(.*)$").Groups[1].Value.Trim()
        if ([string]::IsNullOrWhiteSpace($value)) { return @() } # explicitly empty -> no one
        $parts = $value -split '\s*,\s*' | Where-Object { $_ -and $_ -ne '' }
        return ,$parts
    } finally {
        Remove-Item $tmpPath -Force -ErrorAction SilentlyContinue
    }
}

# Sets the user right to the provided principal list (string[]).
# For "No one", pass an empty array -> writes an empty assignment.
function Set-UserRight([string]$rightKey, [string[]]$principals){
    $cfgName = "secpol_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)
    $dbName  = "secedit_{0:yyyyMMdd_HHmmss}.sdb" -f (Get-Date)
    $bkpName = "secedit_backup_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date)

    $tempCfg = Join-Path $env:TEMP $cfgName
    $dbPath  = Join-Path $env:TEMP $dbName
    $backup  = Join-Path $env:TEMP $bkpName

    # Backup local policy
    secedit /export /cfg $backup /quiet | Out-Null
    Write-Host "[BACKUP] Current security policy exported to: $backup"

    # Build Privilege Rights template; empty assignment clears the right
    $val = ($principals -and $principals.Count -gt 0) ? ($principals -join ',') : ''
$template = @"
[Unicode]
Unicode=yes
[Privilege Rights]
$rightKey = $val
[Version]
signature="$`CHICAGO$`"
Revision=1
"@
    $template | Out-File -FilePath $tempCfg -Encoding Unicode -Force

    # Apply template
    secedit /configure /db $dbPath /cfg $tempCfg /quiet | Out-Null

    # Cleanup template (keep DB/backup if you want historical trace)
    Remove-Item $tempCfg -Force -ErrorAction SilentlyContinue
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: $SCRIPT_NAME"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Access Credential Manager as a trusted caller' is set to 'No one' (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController
$machine = Get-CimInstance Win32_ComputerSystem | Select-Object -First 1
$partOfDomain = [bool]$machine.PartOfDomain

# Read current value (pre)
$preList = Get-UserRight -rightKey $RIGHT_KEY
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $preList))
Write-Host ""

# Match requested layout banner (use secedit for both roles for this user right)
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
}
Write-Host ""

# Decide if change is needed: compliant when list is empty (No one)
$needChange = ($preList.Count -ne 0)

$changed = $false
if ($needChange) {
    Set-UserRight -rightKey $RIGHT_KEY -principals $TARGET_LIST | Out-Null
    $changed = $true
}

# ---- Force policy refresh (as requested) ----
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify after remediation (post)
$postList = Get-UserRight -rightKey $RIGHT_KEY
$compliant = ($postList.Count -eq 0)

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $postList))
$preDisp  = To-Display-PrincipalList $preList
$postDisp = To-Display-PrincipalList $postList
Write-Host ("Access Cred. Manager as Trusted Caller : target={0}  pre={1}  post={2}" -f 'No one', $preDisp, $postDisp)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
