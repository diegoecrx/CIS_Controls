###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.1.2 (L1) Ensure 'Accounts: Guest account status'
# is set to 'Disabled' (Member Server only) (Automated)
#
# Implements the Security Option:
#   Path:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\Accounts: Guest account status
#
# Notes:
# - Control scope: Member Server (MS) only. Domain Controllers (DC) have no
#   local accounts; this control is not applicable on DCs.
# - Uses Win32_UserAccount (RID 501) to find the built-in Guest
#   account in a locale-independent way, then disables it if needed.
# - Forces Group Policy refresh after remediation.
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME        = "2.3.1.2 (L1) Ensure 'Accounts: Guest account status' is set to 'Disabled' (MS only)"
$POLICY_PATH         = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Accounts: Guest account status'
$PROFILE_DC          = "Level 1 - Domain Controller"
$PROFILE_MS          = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT  = "Disabled (Member Server only)."
$TARGET_STATE        = 'Disabled'   # Desired end state

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -First 1).DomainRole
        return ($role -ge 4) # 4/5 = Backup/Primary Domain Controller
    } catch {
        return $false
    }
}

# Returns the built-in Guest local account object (RID 501) on MS/Standalone
function Get-LocalBuiltinGuest {
    try {
        # RID 501 is the built-in Guest; LocalAccount=$true restricts to local SAM
        $acct = Get-CimInstance Win32_UserAccount -Filter "LocalAccount = True" |
                Where-Object { $_.SID -match '-501$' } |
                Select-Object -First 1
        return $acct
    } catch {
        return $null
    }
}

# Enable/Disable the local built-in Guest by localized name
function Set-LocalGuestState([string]$AccountName, [string]$state){
    # $state must be 'Enabled' or 'Disabled'
    $switch = if ($state -eq 'Disabled') { '/active:no' } else { '/active:yes' }
    & net user $AccountName $switch | Out-Null
}

# Map boolean Disabled flag to friendly string
function To-State([bool]$isDisabled){
    if ($isDisabled) { 'Disabled' } else { 'Enabled' }
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.1.2.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Accounts: Guest account status' is set to 'Disabled' (MS only) (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController

if ($isDC) {
    # DC: Not applicable. There is no local Guest account on DCs.
    Write-Host ""
    Write-Host "Detected: Domain Controller"
    Write-Host "This control applies to Member Servers only. Skipping remediation."
    Write-Host ""
    $pre  = 'N/A'
    $post = 'N/A'
    $changed = $false
    $compliant = $false
} else {
    Write-Host ""
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (local SAM account state)"
    Write-Host ""

    $acct = Get-LocalBuiltinGuest
    if ($null -eq $acct) {
        Write-Host "[WARN] Could not locate the built-in Guest account (RID 501)."
        $pre = 'Unknown'
        $post = 'Unknown'
        $changed = $false
        $compliant = $false
    } else {
        $pre = To-State -isDisabled:$acct.Disabled

        # Remediate if needed
        $changed = $false
        if ($pre -ne $TARGET_STATE) {
            Write-Host ("[ACTION] Setting built-in Guest ('{0}') to Disabled ..." -f $acct.Name)
            Set-LocalGuestState -AccountName $acct.Name -state $TARGET_STATE
            $changed = $true
        }

        # Force policy refresh
        try {
            gpupdate /target:computer /force | Out-Null
            secedit /refreshpolicy machine_policy /enforce | Out-Null
        } catch { }

        # Verify post
        $acctPost = Get-LocalBuiltinGuest
        if ($null -ne $acctPost) {
            $post = To-State -isDisabled:$acctPost.Disabled
        } else {
            $post = 'Unknown'
        }

        $compliant = ($post -eq $TARGET_STATE)
    }
}

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Accounts: Guest account status : target={0}  pre={1}  post={2}" -f $TARGET_STATE, $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
