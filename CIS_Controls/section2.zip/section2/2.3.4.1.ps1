###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.4.1 (L1) Ensure
# 'Devices: Allowed to format and eject removable NTFS media'
# is set to 'Administrators' (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\
#   Devices: Allowed to format and eject removable NTFS media
#
# Mechanism: Sets HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\AllocateDASD
#   0 = Administrators
#   1 = Administrators and Power Users
#   2 = Administrators and Interactive Users
# Applies to: Domain Controllers and Member/Standalone servers
# Post-change: Forces Group Policy refresh
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.4.1 (L1) Ensure 'Devices: Allowed to format and eject removable NTFS media' is set to 'Administrators' (Automated)"
$POLICY_PATH        = "Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Devices: Allowed to format and eject removable NTFS media"
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Administrators"
$TARGET_STATE_TEXT  = "Administrators"
$TARGET_CODE        = 0   # AllocateDASD

# Registry details
$RegPath  = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
$RegName  = 'AllocateDASD'   # REG_SZ: "0","1","2"

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}

function Convert-CodeToText([int]$code){
    switch ($code) {
        0 { 'Administrators' }
        1 { 'Administrators and Power Users' }
        2 { 'Administrators and Interactive Users' }
        default { 'Unknown' }
    }
}

function Get-AllocateDASDState {
    try {
        $raw = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName
        if ($null -eq $raw -or $raw -eq '') { return 'Unknown' }
        $num = 0
        if ([int]::TryParse($raw, [ref]$num)) {
            return (Convert-CodeToText -code $num)
        } else {
            return (Convert-CodeToText -code 0)
        }
    } catch { 'Unknown' }
}

function Set-AllocateDASD([int]$code){
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    # Use REG_SZ (string) as used by Winlogon 'Allocate*' policies
    New-ItemProperty -Path $RegPath -Name $RegName -PropertyType String -Value ($code.ToString()) -Force | Out-Null
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.4.1.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Restrict formatting/ejecting removable NTFS media to Administrators only (Automated)."
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController | ForEach-Object { $_ }

# Read current value (pre)
$pre = Get-AllocateDASDState
Write-Host ("Current status: {0}" -f $pre)
Write-Host ""
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
}
Write-Host ""

# Remediate if needed
$changed = $false
if ($pre -ne $TARGET_STATE_TEXT) {
    Write-Host "[ACTION] Setting 'AllocateDASD' to Administrators (0) ..."
    Set-AllocateDASD -code $TARGET_CODE | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify post
$post       = Get-AllocateDASDState
$compliant  = ($post -eq $TARGET_STATE_TEXT)

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Devices: Allowed to format and eject removable NTFS media : target={0}  pre={1}  post={2}" -f $TARGET_STATE_TEXT, $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if ($compliant) {'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if ($changed) {'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
