###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.1.4 (L1) Ensure 'Accounts: Rename guest account'
# is set to a unique name (not 'Guest') (Member Server only) (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\Accounts: Rename guest account
#
# Notes:
# - Scope: Member Server (MS) only. DCs have no local SAM; this control is N/A.
# - We locate the built-in Guest by RID 501 (locale-independent) and
#   rename it if its name is still the default 'Guest'.
# - Compliance is TRUE if the final name != 'Guest' (any non-default).
# - After remediation, Group Policy is refreshed.
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.1.4 (L1) Ensure 'Accounts: Rename guest account' is not 'Guest' (MS only)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Accounts: Rename guest account'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Set to a unique, non-default name (not 'Guest')."
# Target rename to use if still default. Adjust to your org standard if desired.
$TARGET_NAME        = 'CIS_Guest'

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -First 1).DomainRole
        return ($role -ge 4) # 4/5 = Backup/Primary Domain Controller
    } catch { return $false }
}

# Returns the built-in Guest (RID 501) local account object (MS/Standalone)
function Get-LocalBuiltinGuest {
    try {
        Get-CimInstance Win32_UserAccount -Filter "LocalAccount = True" |
            Where-Object { $_.SID -match '-501$' } |
            Select-Object -First 1
    } catch { $null }
}

# Rename local user by current name -> new name (uses LocalAccounts module)
function Rename-LocalGuestSafely([string]$CurrentName, [string]$NewName){
    try {
        if (Get-Command -Name Rename-LocalUser -ErrorAction SilentlyContinue) {
            Rename-LocalUser -Name $CurrentName -NewName $NewName -ErrorAction Stop
        } else {
            wmic useraccount where "name='$CurrentName' and LocalAccount='True'" rename "$NewName" | Out-Null
        }
        return $true
    } catch {
        Write-Host ("[ERROR] Rename failed: {0}" -f $_.Exception.Message)
        return $false
    }
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.1.4.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure the built-in Guest account is renamed to a unique value (not 'Guest') (MS only) (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController
$changed = $false
$pre = 'N/A'; $post = 'N/A'; $compliant = $false

if ($isDC) {
    Write-Host ""
    Write-Host "Detected: Domain Controller"
    Write-Host "This control applies to Member Servers only. Skipping remediation."
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (local SAM account rename)"
    Write-Host ""

    $acct = Get-LocalBuiltinGuest
    if ($null -eq $acct) {
        Write-Host "[WARN] Could not locate the built-in Guest account (RID 501)."
        $pre = 'Unknown'
        $post = 'Unknown'
        $changed = $false
        $compliant = $false
    } else {
        $pre = $acct.Name

        # If still default name, rename to target
        if ($acct.Name -eq 'Guest') {
            Write-Host ("[ACTION] Renaming built-in Guest account from '{0}' to '{1}' ..." -f $acct.Name, $TARGET_NAME)
            $changed = Rename-LocalGuestSafely -CurrentName $acct.Name -NewName $TARGET_NAME
        }

        # Force policy refresh
        try {
            gpupdate /target:computer /force | Out-Null
            secedit /refreshpolicy machine_policy /enforce | Out-Null
        } catch { }

        # Verify post
        $acctPost = Get-LocalBuiltinGuest
        if ($null -ne $acctPost) {
            $post = $acctPost.Name
        } else {
            $post = if ($changed) { $TARGET_NAME } else { 'Unknown' }
        }

        # Compliance: name is not 'Guest'
        $compliant = ($post -ne 'Guest')
    }
}

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Accounts: Rename guest account : target<>'Guest' (using '$TARGET_NAME' if default)  pre={0}  post={1}" -f $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
