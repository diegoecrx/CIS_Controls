###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.2.43 (L1) Ensure 'Impersonate a client after authentication'
# is set to "Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE"
# and (when IIS Web Server role is installed) "IIS_IUSRS" (Automated)
#
# Configures user right:
#   SeImpersonatePrivilege ("Impersonate a client after authentication")
# Applies via Local Security Policy (secedit) on DCs and Member/Standalone,
# then forces a policy refresh.
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME = "2.2.43 (L1) Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE' and (when IIS is installed) 'IIS_IUSRS' (Automated)"
$POLICY_PATH  = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\User Rights Assignment\Impersonate a client after authentication'
$PROFILE_DC   = "Level 1 - Domain Controller"
$PROFILE_MS   = "Level 1 - Member Server"

# Locale-independent principals (SIDs):
#   Administrators         -> *S-1-5-32-544
#   LOCAL SERVICE          -> *S-1-5-19
#   NETWORK SERVICE        -> *S-1-5-20
#   SERVICE                -> *S-1-5-6
#   IIS_IUSRS (if IIS)     -> *S-1-5-32-568
$RIGHT_KEY    = 'SeImpersonatePrivilege'
$BASE_TARGETS = @('*S-1-5-32-544','*S-1-5-19','*S-1-5-20','*S-1-5-6')

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}
function To-Display-PrincipalList([string[]]$arr){
    if (-not $arr -or $arr.Count -eq 0) { 'No one' } else { $arr -join ', ' }
}
function Get-IISInstalled {
    try {
        if (Get-Command Get-WindowsFeature -ErrorAction Stop) {
            return ((Get-WindowsFeature -Name Web-Server).Installed)
        }
    } catch { }
    return $false
}

# Read current principals for a user right from secedit export.
function Get-UserRight([string]$rightKey){
    $tmp = Join-Path $env:TEMP ("secexport_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date))
    try{
        secedit /export /cfg $tmp /quiet | Out-Null
        $raw  = Get-Content $tmp -Raw
        $body = [regex]::Match($raw,"(\[Privilege Rights\]\s*)(?<b>[\s\S]*?)(\r?\n\[|$)",'Singleline').Groups['b'].Value
        if (-not $body) { return @() }
        $line = ($body -split "(\r?\n)") | Where-Object { $_ -match "^\s*$([regex]::Escape($rightKey))\s*=\s*(.*)$" } | Select-Object -First 1
        if (-not $line) { return @() }
        $val  = [regex]::Match($line,"=\s*(.*)$").Groups[1].Value.Trim()
        if ([string]::IsNullOrWhiteSpace($val)) { return @() }
        ,($val -split '\s*,\s*' | Where-Object { $_ })
    } finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
}

# Set the user right to exactly the provided principals.
function Set-UserRight([string]$rightKey, [string[]]$principals){
    $cfg  = Join-Path $env:TEMP ("secpol_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date))
    $db   = Join-Path $env:TEMP ("secedit_{0:yyyyMMdd_HHmmss}.sdb" -f (Get-Date))
    $bkp  = Join-Path $env:TEMP ("secedit_backup_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date))

    secedit /export /cfg $bkp /quiet | Out-Null
    Write-Host "[BACKUP] Current security policy exported to: $bkp"

    $val = ($principals -and $principals.Count -gt 0) ? ($principals -join ',') : ''
@"
[Unicode]
Unicode=yes
[Privilege Rights]
$rightKey = $val
[Version]
signature="$`CHICAGO$`"
Revision=1
"@ | Out-File -FilePath $cfg -Encoding Unicode -Force

    secedit /configure /db $db /cfg $cfg /quiet | Out-Null
    Remove-Item $cfg -Force -ErrorAction SilentlyContinue
    $true
}

# Compare two principal lists ignoring order/whitespace/case
function Compare-PrincipalSets([string[]]$a,[string[]]$b){
    $norm = { param($x) ($x | ForEach-Object { $_.Trim().ToUpperInvariant() }) | Sort-Object -Unique }
    $aa = & $norm $a
    $bb = & $norm $b
    if ($aa.Count -ne $bb.Count) { return $false }
    for($i=0;$i -lt $aa.Count;$i++){ if ($aa[$i] -ne $bb[$i]) { return $false } }
    $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation:"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE' and (when IIS is installed) 'IIS_IUSRS' (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE (add IIS_IUSRS if IIS role is installed)"
# --------------------------------- Run ---------------------------------------
$isDC        = Get-IsDomainController
$iisPresent  = Get-IISInstalled
$TARGET_LIST = @()
$TARGET_LIST += $BASE_TARGETS
if ($iisPresent) { $TARGET_LIST += '*S-1-5-32-568' }  # IIS_IUSRS

# Read current value (pre)
$preList = Get-UserRight -rightKey $RIGHT_KEY
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $preList))
Write-Host ""

# Role banner (same remediation path for both roles)
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
}
if ($iisPresent) { Write-Host "[INFO] IIS Web Server detected -> including IIS_IUSRS in target assignment" }
Write-Host ""

# Remediate if needed
$needChange = -not (Compare-PrincipalSets $preList $TARGET_LIST)
$changed = $false
if ($needChange) {
    Set-UserRight -rightKey $RIGHT_KEY -principals $TARGET_LIST | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify post
$postList  = Get-UserRight -rightKey $RIGHT_KEY
$compliant = Compare-PrincipalSets $postList $TARGET_LIST

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $postList))
$preDisp    = To-Display-PrincipalList $preList
$postDisp   = To-Display-PrincipalList $postList
$targetDisp = To-Display-PrincipalList $TARGET_LIST
Write-Host ("Impersonate A Client After Authentication : target={0}  pre={1}  post={2}" -f $targetDisp, $preDisp, $postDisp)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
