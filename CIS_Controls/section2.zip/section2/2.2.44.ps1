###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.2.44 (L1) Ensure 'Profile system performance'
# is set to 'Administrators, NT SERVICE\WdiServiceHost' (Automated)
#
# Configures user right:
#   SeSystemProfilePrivilege ("Profile system performance")
# Applies via Local Security Policy (secedit) on DCs and Member/Standalone,
# then forces a policy refresh.
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.2.44 (L1) Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\WdiServiceHost' (Automated)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\User Rights Assignment\Profile system performance'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Administrators, NT SERVICE\WdiServiceHost (CIS requirement)."
$RIGHT_KEY          = 'SeSystemProfilePrivilege'          # [Privilege Rights] key

# Target principals:
# - Administrators (locale-independent via SID)
# - NT SERVICE\WdiServiceHost (service SID-backed account; use name form)
$TARGET_LIST        = @('*S-1-5-32-544','NT SERVICE\WdiServiceHost')

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}
function To-Display-PrincipalList([string[]]$arr){
    if (-not $arr -or $arr.Count -eq 0) { 'No one' } else { $arr -join ', ' }
}
# Read current principals for a user right from secedit export.
function Get-UserRight([string]$rightKey){
    $tmp = Join-Path $env:TEMP ("secexport_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date))
    try{
        secedit /export /cfg $tmp /quiet | Out-Null
        $raw = Get-Content $tmp -Raw
        $body = [regex]::Match($raw,"(\[Privilege Rights\]\s*)(?<b>[\s\S]*?)(\r?\n\[|$)",'Singleline').Groups['b'].Value
        if (-not $body) { return @() }
        $line = ($body -split "(\r?\n)") | Where-Object { $_ -match "^\s*$([regex]::Escape($rightKey))\s*=\s*(.*)$" } | Select-Object -First 1
        if (-not $line) { return @() }
        $val = [regex]::Match($line,"=\s*(.*)$").Groups[1].Value.Trim()
        if ([string]::IsNullOrWhiteSpace($val)) { return @() }
        ,($val -split '\s*,\s*' | Where-Object { $_ })
    } finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
}
# Set the user right to exactly the provided principals.
function Set-UserRight([string]$rightKey, [string[]]$principals){
    $cfg  = Join-Path $env:TEMP ("secpol_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date))
    $db   = Join-Path $env:TEMP ("secedit_{0:yyyyMMdd_HHmmss}.sdb" -f (Get-Date))
    $bkp  = Join-Path $env:TEMP ("secedit_backup_{0:yyyyMMdd_HHmmss}.cfg" -f (Get-Date))

    secedit /export /cfg $bkp /quiet | Out-Null
    Write-Host "[BACKUP] Current security policy exported to: $bkp"

    $val = ($principals -and $principals.Count -gt 0) ? ($principals -join ',') : ''
@"
[Unicode]
Unicode=yes
[Privilege Rights]
$rightKey = $val
[Version]
signature="$`CHICAGO$`"
Revision=1
"@ | Out-File -FilePath $cfg -Encoding Unicode -Force

    secedit /configure /db $db /cfg $cfg /quiet | Out-Null
    Remove-Item $cfg -Force -ErrorAction SilentlyContinue
    $true
}
# Compare two principal lists ignoring order/whitespace/case
function Compare-PrincipalSets([string[]]$a,[string[]]$b){
    $norm = { param($x) ($x | ForEach-Object { $_.Trim().ToUpperInvariant() }) | Sort-Object -Unique }
    $aa = & $norm $a; $bb = & $norm $b
    if ($aa.Count -ne $bb.Count) { return $false }
    for($i=0;$i -lt $aa.Count;$i++){ if ($aa[$i] -ne $bb[$i]) { return $false } }
    $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation:"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\WdiServiceHost' (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC    = Get-IsDomainController
$preList = Get-UserRight -rightKey $RIGHT_KEY
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $preList))
Write-Host ""
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (secedit.exe)"
}
Write-Host ""

$needChange = -not (Compare-PrincipalSets $preList $TARGET_LIST)
$changed = $false
if ($needChange) {
    Set-UserRight -rightKey $RIGHT_KEY -principals $TARGET_LIST | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

$postList  = Get-UserRight -rightKey $RIGHT_KEY
$compliant = Compare-PrincipalSets $postList $TARGET_LIST

Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current threshold: {0}" -f (To-Display-PrincipalList $postList))
$preDisp    = To-Display-PrincipalList $preList
$postDisp   = To-Display-PrincipalList $postList
$targetDisp = To-Display-PrincipalList $TARGET_LIST
Write-Host ("Profile System Performance : target={0}  pre={1}  post={2}" -f $targetDisp, $preDisp, $postDisp)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
