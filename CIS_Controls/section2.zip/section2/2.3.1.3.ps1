###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.1.3 (L1) Ensure 'Accounts: Rename administrator account'
# is set to a unique name (not 'Administrator') (Member Server only) (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\Accounts: Rename administrator account
#
# Notes:
# - Scope: Member Server (MS) only. DCs have no local SAM; this control is N/A.
# - We locate the built-in Administrator by RID 500 (locale-independent) and
#   rename it if its current name is still the default 'Administrator'.
# - Compliance is TRUE if the final name != 'Administrator' (any non-default).
# - After remediation, Group Policy is refreshed.
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.1.3 (L1) Ensure 'Accounts: Rename administrator account' is not 'Administrator' (MS only)"
$POLICY_PATH        = 'Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Accounts: Rename administrator account'
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Set to a unique, non-default name (not 'Administrator')."
# Target rename to use if still default. Adjust to your org standard if desired.
$TARGET_NAME        = 'CIS_Admin'

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try {
        $role = (Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -First 1).DomainRole
        return ($role -ge 4) # 4/5 = Backup/Primary Domain Controller
    } catch { return $false }
}

# Returns the built-in Administrator (RID 500) local account object (MS/Standalone)
function Get-LocalBuiltinAdministrator {
    try {
        Get-CimInstance Win32_UserAccount -Filter "LocalAccount = True" |
            Where-Object { $_.SID -match '-500$' } |
            Select-Object -First 1
    } catch { $null }
}

# Rename local user by current name -> new name (uses LocalAccounts module)
function Rename-LocalAdminSafely([string]$CurrentName, [string]$NewName){
    try {
        # Prefer Rename-LocalUser when available (Server 2022 default)
        if (Get-Command -Name Rename-LocalUser -ErrorAction SilentlyContinue) {
            Rename-LocalUser -Name $CurrentName -NewName $NewName -ErrorAction Stop
        } else {
            # Fallback to 'wmic' for older shells
            wmic useraccount where "name='$CurrentName' and LocalAccount='True'" rename "$NewName" | Out-Null
        }
        return $true
    } catch {
        Write-Host ("[ERROR] Rename failed: {0}" -f $_.Exception.Message)
        return $false
    }
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.1.3.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure the built-in Administrator account is renamed to a unique value (not 'Administrator') (MS only) (Automated)"
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController
$changed = $false
$pre = 'N/A'; $post = 'N/A'; $compliant = $false

if ($isDC) {
    Write-Host ""
    Write-Host "Detected: Domain Controller"
    Write-Host "This control applies to Member Servers only. Skipping remediation."
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Local Security Policy (local SAM account rename)"
    Write-Host ""

    $acct = Get-LocalBuiltinAdministrator
    if ($null -eq $acct) {
        Write-Host "[WARN] Could not locate the built-in Administrator account (RID 500)."
        $pre = 'Unknown'
        $post = 'Unknown'
        $changed = $false
        $compliant = $false
    } else {
        $pre = $acct.Name

        # If still default name, rename to target
        if ($acct.Name -eq 'Administrator') {
            Write-Host ("[ACTION] Renaming built-in Administrator account from '{0}' to '{1}' ..." -f $acct.Name, $TARGET_NAME)
            $changed = Rename-LocalAdminSafely -CurrentName $acct.Name -NewName $TARGET_NAME
        }

        # Force policy refresh
        try {
            gpupdate /target:computer /force | Out-Null
            secedit /refreshpolicy machine_policy /enforce | Out-Null
        } catch { }

        # Verify post
        $acctPost = Get-LocalBuiltinAdministrator
        if ($null -ne $acctPost) {
            $post = $acctPost.Name
        } else {
            # If lookup by RID failed after rename (rare), fall back by name assumption
            $post = if ($changed) { $TARGET_NAME } else { 'Unknown' }
        }

        # Compliance: name is not 'Administrator'
        $compliant = ($post -ne 'Administrator')
    }
}

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Accounts: Rename administrator account : target<>'Administrator' (using '$TARGET_NAME' if default)  pre={0}  post={1}" -f $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if($compliant){'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if($changed){'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
