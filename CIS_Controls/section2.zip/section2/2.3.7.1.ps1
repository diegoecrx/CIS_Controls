###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.7.1 (L1) Ensure
# 'Interactive logon: Do not display last user name'
# is set to 'Enabled' (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\
#   Interactive logon: Do not display last user name
#
# Mechanism: Sets HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\DontDisplayLastUserName
#   REG_DWORD: 1 = Enabled (CIS target)
#              0 or missing = Disabled
# Applies to: Domain Controllers and Member/Standalone servers
# Post-change: Forces Group Policy refresh
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.7.1 (L1) Ensure 'Interactive logon: Do not display last user name' is set to 'Enabled'"
$POLICY_PATH        = "Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Interactive logon: Do not display last user name"
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Disabled (Windows default shows last signed-in user)."
$TARGET_STATE_TEXT  = "Enabled"

# Registry details
$RegPath  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
$RegName  = 'DontDisplayLastUserName'   # DWORD: 1=Enabled, 0=Disabled
$TargetDW = 1

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}

function Get-LastUserNameDisplayState {
    try {
        $val = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName
        if ($null -eq $val) { return 'Disabled' }  # Absent behaves as Disabled (show last user)
        if ([int]$val -eq 1) { 'Enabled' } else { 'Disabled' }
    } catch { 'Unknown' }
}

function Set-LastUserNameHidden {
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    New-ItemProperty -Path $RegPath -Name $RegName -PropertyType DWord -Value $TargetDW -Force | Out-Null
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.7.1.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Hide the last signed-in user name on the logon screen (Enabled)."
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController | ForEach-Object { $_ }

# Read current value (pre)
$pre = Get-LastUserNameDisplayState
Write-Host ("Current status: {0}" -f $pre)
Write-Host ""
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
}
Write-Host ""

# Remediate if needed
$changed = $false
if ($pre -ne $TARGET_STATE_TEXT) {
    Write-Host "[ACTION] Enabling 'Do not display last user name' (setting DontDisplayLastUserName=1) ..."
    Set-LastUserNameHidden | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify post
$post       = Get-LastUserNameDisplayState
$compliant  = ($post -eq $TARGET_STATE_TEXT)

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Interactive logon: Do not display last user name : target={0}  pre={1}  post={2}" -f $TARGET_STATE_TEXT, $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if ($compliant) {'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if ($changed) {'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
