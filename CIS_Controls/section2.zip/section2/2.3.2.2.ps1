###############################################################################
# CIS Microsoft Windows Server 2022 Benchmark
# CIS Control - 2.3.2.2 (L1) Ensure
# 'Audit: Shut down system immediately if unable to log security audits'
# is set to 'Disabled' (Automated)
#
# Implements the Security Option:
#   Computer Configuration\Policies\Windows Settings\Security Settings\
#   Local Policies\Security Options\
#   Audit: Shut down system immediately if unable to log security audits
#
# Mechanism: Sets HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\CrashOnAuditFail = 0
# Applies to: Domain Controllers and Member/Standalone servers
# Post-change: Forces Group Policy refresh
###############################################################################

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# -------------------------- Constants ----------------------
$CONTROL_NAME       = "2.3.2.2 (L1) Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled' (Automated)"
$POLICY_PATH        = "Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Audit: Shut down system immediately if unable to log security audits"
$PROFILE_DC         = "Level 1 - Domain Controller"
$PROFILE_MS         = "Level 1 - Member Server"
$DEFAULT_VALUE_TEXT = "Disabled"
$TARGET_STATE_TEXT  = "Disabled"

# Registry details
$RegPath  = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
$RegName  = 'CrashOnAuditFail'   # DWORD: 0=Disabled, 1=Enabled
$TargetDW = 0

# ------------------------------- Helpers ------------------------------------
function Get-IsDomainController {
    try { return ((Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole -ge 4) } catch { return $false }
}

function Get-CrashOnAuditFailState {
    try {
        $val = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName
        if ($null -eq $val) { return 'Disabled' }           # Absent behaves as Disabled
        if ([int]$val -eq 0) { 'Disabled' } else { 'Enabled' }
    } catch { 'Unknown' }
}

function Set-CrashOnAuditFailDisabled {
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    New-ItemProperty -Path $RegPath -Name $RegName -PropertyType DWord -Value $TargetDW -Force | Out-Null
    return $true
}

# ------------------------------- Banner / Info -------------------------------
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host "=============================================="
Write-Host "Automated Remediation: 2.3.2.2.ps1"
Write-Host "$CONTROL_NAME"
Write-Host "=============================================="
Write-Host ""
Write-Host "Description:"
Write-Host "Ensure the system does NOT crash when it cannot log security audits (Disabled)."
Write-Host ""
Write-Host "Configuration file: $POLICY_PATH"
Write-Host "Profile Domain Controller: $PROFILE_DC"
Write-Host "Profile Member Server: $PROFILE_MS"
Write-Host "Default value: $DEFAULT_VALUE_TEXT"

# --------------------------------- Run ---------------------------------------
$isDC = Get-IsDomainController | ForEach-Object { $_ }

# Read current value (pre)
$pre = Get-CrashOnAuditFailState
Write-Host ("Current status: {0}" -f $pre)
Write-Host ""
if ($isDC) {
    Write-Host "Detected: Domain Controller"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
} else {
    Write-Host "Detected: Member Server or Stand-alone"
    Write-Host "Applying remediation via: Registry (Security Option) + gpupdate"
}
Write-Host ""

# Remediate if needed
$changed = $false
if ($pre -ne $TARGET_STATE_TEXT) {
    Write-Host "[ACTION] Disabling 'CrashOnAuditFail' (setting CrashOnAuditFail=0) ..."
    Set-CrashOnAuditFailDisabled | Out-Null
    $changed = $true
}

# Force policy refresh
try {
    gpupdate /target:computer /force | Out-Null
    secedit /refreshpolicy machine_policy /enforce | Out-Null
} catch { }

# Verify post
$post       = Get-CrashOnAuditFailState
$compliant  = ($post -eq $TARGET_STATE_TEXT)

# ------------------------------- Status Block --------------------------------
Write-Host ""
Write-Host "=============================================="
Write-Host "Remediation Status:"
Write-Host ""
Write-Host ("Current status: {0}" -f $post)
Write-Host ("Audit: Crash on audit fail : target={0}  pre={1}  post={2}" -f $TARGET_STATE_TEXT, $pre, $post)
Write-Host ("Compliant: {0}" -f ($(if ($compliant) {'TRUE'} else {'FALSE'})))
Write-Host ("Changed: {0}" -f ($(if ($changed) {'YES'} else {'NO'})))
Write-Host "=============================================="
Write-Host ""
