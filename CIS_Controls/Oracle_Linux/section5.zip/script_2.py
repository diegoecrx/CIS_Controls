
# Verification for Section 5
print("="*80)
print("SECTION 5 VERIFICATION")
print("="*80)
print()

# Check template adherence
automated_count_s5 = df_section5['item_name'].str.contains('Automated', case=False, na=False).sum()
manual_count_s5 = df_section5['item_name'].str.contains('Manual', case=False, na=False).sum()

print(f"Total scripts generated: {len(df_section5)}")
print(f"Automated scripts (template_automated.sh): {automated_count_s5}")
print(f"Manual scripts (template_manual.sh): {manual_count_s5}")
print()

# Verify each script
print("File Verification:")
all_valid = True
for idx, row in df_section5.iterrows():
    script_name = row['script_name']
    filename = f"{output_dir_section5}/{script_name}.sh"
    
    if not os.path.exists(filename):
        print(f"  ✗ MISSING: {filename}")
        all_valid = False

if all_valid:
    print(f"✓ All {len(df_section5)} scripts verified successfully!")

print()
print("="*80)
print(f"✓ SECTION 5 COMPLETE - ALL {len(df_section5)} SCRIPTS GENERATED!")
print("="*80)
