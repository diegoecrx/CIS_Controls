#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 5.2.3.2.sh
# CIS Control - 5.2.3.2 Ensure cramfs kernel module is not available (Automated)

# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="5.2.3.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function with error categorization
log_message() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    # Also log to error log if it's an error
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Enhanced backup function with validation
backup_file() {
    local file_path="$1"

    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    if [ ! -r "$file_path" ]; then
        log_message "ERROR" "Cannot read file for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        echo "$BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Function to check if cramfs module is loaded
check_module_loaded() {
    if lsmod | grep -q "^cramfs[[:space:]]"; then
        log_message "WARNING" "cramfs module is currently loaded"
        return 0
    else
        log_message "INFO" "cramfs module is not loaded"
        return 1
    fi
}

# Function to check if cramfs module is loadable
check_module_loadable() {
    local loadable_output
    loadable_output=$(modprobe -n -v cramfs 2>/dev/null)
    
    if echo "$loadable_output" | grep -q "install /bin/true\|install /bin/false"; then
        log_message "INFO" "cramfs module is already configured to be not loadable"
        return 1
    elif echo "$loadable_output" | grep -q "install cramfs"; then
        log_message "WARNING" "cramfs module is currently loadable"
        return 0
    else
        log_message "INFO" "cramfs module configuration not found"
        return 1
    fi
}

# Function to check if cramfs module is blacklisted
check_module_blacklisted() {
    if modprobe --showconfig | grep -q "^[[:space:]]*blacklist[[:space:]]\+cramfs\b"; then
        log_message "INFO" "cramfs module is already blacklisted"
        return 0
    else
        log_message "WARNING" "cramfs module is not blacklisted"
        return 1
    fi
}

# Function to check if cramfs module exists on system
check_module_exists() {
    local module_name="cramfs"
    local module_type="fs"
    local module_path="/lib/modules/$(uname -r)/kernel/$module_type"
    local module_dir
    
    # Convert module name to directory path
    module_dir=$(echo "$module_name" | tr '-' '/')
    
    if [ -d "$module_path/$module_dir" ] && [ -n "$(ls -A "$module_path/$module_dir" 2>/dev/null)" ]; then
        log_message "WARNING" "cramfs module exists in current kernel: $module_path/$module_dir"
        return 0
    else
        log_message "INFO" "cramfs module does not exist in current kernel"
        return 1
    fi
}

# Function to check if cramfs module exists in any installed kernel
check_module_exists_any_kernel() {
    local module_name="cramfs"
    local module_type="fs"
    local found=1
    local kernel_dir
    
    for kernel_dir in /lib/modules/*; do
        # Skip if not a directory
        [ -d "$kernel_dir" ] || continue
        
        local module_path="$kernel_dir/kernel/$module_type"
        local module_dir
        
        # Convert module name to directory path
        module_dir=$(echo "$module_name" | tr '-' '/')
        
        if [ -d "$module_path/$module_dir" ] && [ -n "$(ls -A "$module_path/$module_dir" 2>/dev/null)" ]; then
            log_message "WARNING" "cramfs module exists in kernel: $kernel_dir"
            found=0
        fi
    done
    
    return $found
}

# Function to make module not loadable
make_module_not_loadable() {
    local module_name="cramfs"
    local config_file="/etc/modprobe.d/${module_name}.conf"
    
    log_message "INFO" "Making cramfs module not loadable"
    
    # Backup existing config file if it exists
    if [ -f "$config_file" ]; then
        backup_file "$config_file"
    fi
    
    # Add install command to disable module loading
    if ! grep -q "^[[:space:]]*install[[:space:]]\+$module_name[[:space:]]\+/bin/false" "$config_file" 2>/dev/null; then
        echo "install $module_name /bin/false" >> "$config_file"
        log_message "SUCCESS" "Added 'install cramfs /bin/false' to $config_file"
    else
        log_message "INFO" "Module already configured to be not loadable in $config_file"
    fi
}

# Function to blacklist module
blacklist_module() {
    local module_name="cramfs"
    local config_file="/etc/modprobe.d/${module_name}.conf"
    
    log_message "INFO" "Blacklisting cramfs module"
    
    # Backup existing config file if it exists
    if [ -f "$config_file" ]; then
        backup_file "$config_file"
    fi
    
    # Add blacklist entry
    if ! grep -q "^[[:space:]]*blacklist[[:space:]]\+$module_name\b" "$config_file" 2>/dev/null; then
        echo "blacklist $module_name" >> "$config_file"
        log_message "SUCCESS" "Added 'blacklist cramfs' to $config_file"
    else
        log_message "INFO" "Module already blacklisted in $config_file"
    fi
}

# Function to unload module
unload_module() {
    local module_name="cramfs"
    
    log_message "INFO" "Attempting to unload cramfs module"
    
    if lsmod | grep -q "^$module_name[[:space:]]"; then
        if modprobe -r "$module_name" 2>/dev/null; then
            log_message "SUCCESS" "Successfully unloaded cramfs module"
        else
            log_message "ERROR" "Failed to unload cramfs module"
            return 1
        fi
    else
        log_message "INFO" "cramfs module is not loaded, no need to unload"
    fi
    
    return 0
}

# Function to display remediation information
display_remediation_info() {
    echo ""
    echo "=========================================================================="
    echo "  5.2.3.2 Ensure cramfs kernel module is not available (Automated)"
    echo "=========================================================================="
    echo ""
    echo "CIS Benchmark 5.2.3.2 requires the cramfs kernel module to be disabled"
    echo "to prevent the use of the legacy cram filesystem."
    echo ""
    echo "Remediation Steps:"
    echo "  1. Configure module to be not loadable: Add 'install cramfs /bin/false'"
    echo "  2. Blacklist the module: Add 'blacklist cramfs'"
    echo "  3. Unload the module if currently loaded"
    echo "  4. Apply to all installed kernels if module exists"
    echo ""
    echo "Configuration files will be created in /etc/modprobe.d/"
    echo "Existing configurations will be backed up to: $BACKUP_DIR"
    echo ""
    echo "=========================================================================="
    echo ""
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"

    # Display remediation information (no user input required for automated)
    display_remediation_info

    log_message "INFO" "Beginning cramfs module remediation process"

    # Check current state
    local module_loaded=0
    local module_loadable=0
    local module_blacklisted=0
    local module_exists=0
    local module_exists_any=0

    check_module_loaded || module_loaded=$?
    check_module_loadable || module_loadable=$?
    check_module_blacklisted || module_blacklisted=$?
    check_module_exists || module_exists=$?
    check_module_exists_any_kernel || module_exists_any=$?

    # Apply remediation based on current state
    local remediation_applied=0

    # If module exists in current kernel or any installed kernel
    if [ "$module_exists" -eq 0 ] || [ "$module_exists_any" -eq 0 ]; then
        log_message "INFO" "cramfs module exists on system, applying full remediation"

        # Always blacklist the module if it exists anywhere
        if blacklist_module; then
            remediation_applied=1
        fi

        # If module exists in current running kernel
        if [ "$module_exists" -eq 0 ]; then
            # Make module not loadable for current kernel
            if make_module_not_loadable; then
                remediation_applied=1
            fi

            # Unload module if currently loaded
            if [ "$module_loaded" -eq 0 ]; then
                if unload_module; then
                    remediation_applied=1
                fi
            fi
        fi
    else
        log_message "INFO" "cramfs module does not exist on system, no remediation needed"
        echo ""
        echo "=========================================================================="
        echo "  No Remediation Required"
        echo "=========================================================================="
        echo ""
        echo "The cramfs kernel module was not found in any installed kernel."
        echo "The system is compliant with CIS Benchmark 5.2.3.2."
        echo ""
        log_message "SUCCESS" "System compliant - no remediation needed"
        return 0
    fi

    # Verify remediation
    log_message "INFO" "Verifying remediation results"

    local verification_passed=0
    local verification_failed=0

    # Check if module is blacklisted
    if check_module_blacklisted; then
        log_message "SUCCESS" "Verification: cramfs module is blacklisted"
        verification_passed=$((verification_passed + 1))
    else
        log_message "WARNING" "Verification: cramfs module blacklisting may have failed"
        verification_failed=$((verification_failed + 1))
    fi

    # Check if module is not loadable (only for current kernel)
    if check_module_exists; then
        if ! check_module_loadable; then
            log_message "SUCCESS" "Verification: cramfs module is not loadable"
            verification_passed=$((verification_passed + 1))
        else
            log_message "WARNING" "Verification: cramfs module may still be loadable"
            verification_failed=$((verification_failed + 1))
        fi
    fi

    # Check if module is unloaded
    if ! check_module_loaded; then
        log_message "SUCCESS" "Verification: cramfs module is not loaded"
        verification_passed=$((verification_passed + 1))
    else
        log_message "WARNING" "Verification: cramfs module is still loaded"
        verification_failed=$((verification_failed + 1))
    fi

    # Display final results
    echo ""
    echo "=========================================================================="
    echo "  Remediation Complete"
    echo "=========================================================================="
    echo ""
    echo "Verification Results:"
    echo "  Passed: $verification_passed"
    echo "  Warnings: $verification_failed"
    echo ""

    if [ "$verification_failed" -eq 0 ]; then
        echo "The system is now compliant with CIS Benchmark 5.2.3.2."
        log_message "SUCCESS" "Remediation completed successfully: $SCRIPT_NAME"
    else
        echo "Some verification checks failed. Please review the warnings above."
        echo "The system may require manual intervention for full compliance."
        log_message "WARNING" "Remediation completed with warnings: $SCRIPT_NAME"
    fi

    echo ""
    echo "Configuration files created/modified in /etc/modprobe.d/:"
    ls -la /etc/modprobe.d/*cramfs* 2>/dev/null || echo "No cramfs configuration files found"
    echo ""

    if [ "$remediation_applied" -eq 1 ]; then
        log_message "INFO" "Remediation actions were applied during this execution"
    else
        log_message "INFO" "No remediation actions were needed"
    fi

    return $((verification_failed > 0 ? 1 : 0))
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi

    main_remediation
    exit $?
fi