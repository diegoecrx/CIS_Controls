
# Create README for Section 2

readme_section2 = []
readme_section2.append("="*80)
readme_section2.append("CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 2 REMEDIATION SCRIPTS")
readme_section2.append("="*80)
readme_section2.append("")
readme_section2.append(f"Total Scripts Generated: 30")
readme_section2.append(f"Generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
readme_section2.append("")
readme_section2.append("="*80)
readme_section2.append("SCRIPT BREAKDOWN")
readme_section2.append("="*80)
readme_section2.append("")
readme_section2.append(f"Automated Scripts (template_automated.sh): 29")
readme_section2.append(f"Manual Scripts (template_manual.sh): 1")
readme_section2.append("")
readme_section2.append("="*80)
readme_section2.append("ALL GENERATED SCRIPTS")
readme_section2.append("="*80)
readme_section2.append("")

# Group by category
current_category = ''
category_ranges = {
    '2.1': 'Time Synchronization',
    '2.2': 'Special Services',
    '2.3': 'Service Clients'
}

for idx, row in df_section2.iterrows():
    script_name = row['script_name']
    item_name = row['item_name']
    
    # Determine category
    for cat_prefix, cat_name in category_ranges.items():
        if script_name.startswith(cat_prefix):
            if cat_name != current_category:
                current_category = cat_name
                readme_section2.append(f"\n{'─'*80}")
                readme_section2.append(f"{current_category}")
                readme_section2.append(f"{'─'*80}")
            break
    
    # Determine type
    script_type = "Automated" if "Automated" in item_name else "Manual"
    
    readme_section2.append(f"  {script_name}.sh - {script_type}")
    readme_section2.append(f"    {item_name}")

readme_section2.append("")
readme_section2.append("="*80)
readme_section2.append("TEMPLATE STRUCTURE")
readme_section2.append("="*80)
readme_section2.append("")
readme_section2.append("AUTOMATED SCRIPTS follow template_automated.sh structure:")
readme_section2.append("  - Standard variables (SCRIPT_NAME, BACKUP_DIR, LOG_FILE, ERROR_LOG)")
readme_section2.append("  - Enhanced logging with log_message() function")
readme_section2.append("  - Backup functionality with backup_file() function")
readme_section2.append("  - Check functions for current state verification")
readme_section2.append("  - Remediation functions for applying fixes")
readme_section2.append("  - Verification functions for post-remediation checks")
readme_section2.append("  - main_remediation() orchestrating function")
readme_section2.append("  - Comprehensive error handling and logging")
readme_section2.append("")
readme_section2.append("MANUAL SCRIPTS follow template_manual.sh structure:")
readme_section2.append("  - Same foundational structure as automated scripts")
readme_section2.append("  - Interactive user prompts with 3 options:")
readme_section2.append("    1. Display detailed information")
readme_section2.append("    2. Proceed with remediation")
readme_section2.append("    3. Exit without changes")
readme_section2.append("  - Require manual review and approval before execution")
readme_section2.append("")
readme_section2.append("="*80)
readme_section2.append("USAGE")
readme_section2.append("="*80)
readme_section2.append("")
readme_section2.append("To execute a script:")
readme_section2.append("  1. Ensure you have root privileges")
readme_section2.append("  2. Make the script executable: chmod +x <script_name>.sh")
readme_section2.append("  3. Run the script: sudo ./<script_name>.sh")
readme_section2.append("")
readme_section2.append("Automated scripts will:")
readme_section2.append("  - Display remediation information")
readme_section2.append("  - Check current compliance state")
readme_section2.append("  - Apply remediations if needed")
readme_section2.append("  - Verify changes")
readme_section2.append("  - Log all actions to /var/log/cis_remediation.log")
readme_section2.append("")
readme_section2.append("Manual scripts will:")
readme_section2.append("  - Present options for user selection")
readme_section2.append("  - Display detailed information when requested")
readme_section2.append("  - Wait for user confirmation before applying changes")
readme_section2.append("  - Provide guidance for manual verification")
readme_section2.append("")
readme_section2.append("="*80)
readme_section2.append("IMPORTANT NOTES")
readme_section2.append("="*80)
readme_section2.append("")
readme_section2.append("1. All scripts create backups in /tmp/cis_backup/")
readme_section2.append("2. All actions are logged to /var/log/cis_remediation.log")
readme_section2.append("3. Errors are tracked in /var/log/cis_error_analysis.log")
readme_section2.append("4. Some changes may require system reboot to take effect")
readme_section2.append("5. Review CIS Benchmark documentation before applying remediations")
readme_section2.append("6. Test in non-production environment first")
readme_section2.append("")
readme_section2.append("="*80)

readme_text = '\n'.join(readme_section2)
with open(f'{output_dir_section2}/README.txt', 'w') as f:
    f.write(readme_text)

print(readme_text)
print(f"\n✓ README saved to {output_dir_section2}/README.txt")
