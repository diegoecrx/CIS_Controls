
# Load the templates again
with open('template_automated.sh', 'r') as f:
    template_automated = f.read()

with open('template_manual.sh', 'r') as f:
    template_manual = f.read()

# Create output directory for Section 2
output_dir_section2 = "cis_remediation_scripts_section2"
os.makedirs(output_dir_section2, exist_ok=True)

print("Generating Section 2 Scripts")
print("="*80)
print(f"Total scripts to generate: {len(df_section2)}")
print()

# Generate all scripts
scripts_generated = 0

for idx, row in df_section2.iterrows():
    script_name = row['script_name']
    item_name = row['item_name']
    remediation = str(row['remediation'])
    is_automated = 'Automated' in item_name
    is_manual = 'Manual' in item_name
    
    # Choose template and customize
    if is_manual:
        script_content = template_manual
        script_content = script_content.replace('1.2.3', script_name)
        script_content = script_content.replace(
            '1.2.3 Ensure repo_gpgcheck is globally activated (Manual)',
            item_name
        )
    else:
        script_content = template_automated
        script_content = script_content.replace('1.1.1.1', script_name)
        script_content = script_content.replace(
            '1.1.1.1 Ensure cramfs kernel module is not available (Automated)',
            item_name
        )
    
    # Write to file
    filename = f"{output_dir_section2}/{script_name}.sh"
    with open(filename, 'w') as f:
        f.write(script_content)
    
    scripts_generated += 1
    
    if (idx + 1) % 10 == 0:
        print(f"  Generated {idx + 1}/{len(df_section2)} scripts...")

print(f"\n✓ Successfully generated {scripts_generated} scripts!")

# Verify
final_count = len([f for f in os.listdir(output_dir_section2) if f.endswith('.sh')])
print(f"✓ Files created: {final_count}")
print(f"✓ Expected: {len(df_section2)}")
print(f"✓ Match: {'YES' if final_count == len(df_section2) else 'NO'}")
