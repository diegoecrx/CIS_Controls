
# Load the new Section 2 spreadsheet
import pandas as pd
import os
import re

file_path = "CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section2.xlsx"
df_section2 = pd.read_excel(file_path)

print("Section 2 Spreadsheet Analysis")
print("="*80)
print(f"\nColumn names: {df_section2.columns.tolist()}")
print(f"\nDataframe shape: {df_section2.shape}")
print(f"Number of remediations: {len(df_section2)}")

print("\n\nFirst 5 rows:")
print(df_section2.head())

print("\n\nData types:")
print(df_section2.dtypes)

# Check for Automated vs Manual
automated_count = df_section2['item_name'].str.contains('Automated', case=False, na=False).sum()
manual_count = df_section2['item_name'].str.contains('Manual', case=False, na=False).sum()

print(f"\n\nAutomated controls: {automated_count}")
print(f"Manual controls: {manual_count}")
print(f"Total: {len(df_section2)}")
