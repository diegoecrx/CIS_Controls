
# Create comprehensive final report for Section 2

print("="*100)
print("COMPLETE SECTION 2 SCRIPT LISTING (30 SCRIPTS)")
print("="*100)
print()

for i, script_file in enumerate(sorted(all_files_s2), 1):
    script_name = script_file.replace('.sh', '')
    row = df_section2[df_section2['script_name'] == script_name]
    if not row.empty:
        item_name = row.iloc[0]['item_name']
        script_type = "AUTO" if "Automated" in item_name else "MANUAL"
        print(f"{i:2d}. {script_file:20s} [{script_type:6s}] - {item_name}")

print()
print("="*100)
print("COMPARISON: SECTION 1 vs SECTION 2")
print("="*100)
print()
print(f"{'Metric':<40} {'Section 1':<15} {'Section 2':<15}")
print("-"*70)
print(f"{'Total Scripts':<40} {70:<15} {30:<15}")
print(f"{'Automated Scripts':<40} {66:<15} {29:<15}")
print(f"{'Manual Scripts':<40} {4:<15} {1:<15}")
print(f"{'Total Controls':<40} {70:<15} {30:<15}")
print()

print("="*100)
print("SUMMARY")
print("="*100)
print()
print("✓ Section 1: 70 scripts (66 Automated, 4 Manual)")
print("✓ Section 2: 30 scripts (29 Automated, 1 Manual)")
print()
print("✓ TOTAL: 100 CIS Oracle Linux 7 Benchmark Scripts Generated")
print()
print("Both sections are ready for deployment:")
print("  - cis_oracle_linux_7_section1_scripts.zip")
print("  - cis_oracle_linux_7_section2_scripts.zip")
print()
