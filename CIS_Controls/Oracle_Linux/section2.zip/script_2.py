
# Verification and documentation for Section 2

print("="*80)
print("SECTION 2 VERIFICATION")
print("="*80)
print()

# Check template adherence
automated_count = 0
manual_count = 0

for idx, row in df_section2.iterrows():
    item_name = row['item_name']
    if 'Automated' in item_name:
        automated_count += 1
    if 'Manual' in item_name:
        manual_count += 1

print(f"Total scripts generated: {len(df_section2)}")
print(f"Automated scripts (template_automated.sh): {automated_count}")
print(f"Manual scripts (template_manual.sh): {manual_count}")
print()

# Verify each script
print("File Verification:")
all_valid = True
for idx, row in df_section2.iterrows():
    script_name = row['script_name']
    filename = f"{output_dir_section2}/{script_name}.sh"
    
    if not os.path.exists(filename):
        print(f"  ✗ MISSING: {filename}")
        all_valid = False
    else:
        file_size = os.path.getsize(filename)
        with open(filename, 'r') as f:
            first_line = f.readline()
            if not first_line.startswith('#!/bin/bash'):
                print(f"  ✗ INVALID: {filename} (missing shebang)")
                all_valid = False

if all_valid:
    print(f"✓ All {len(df_section2)} scripts verified successfully!")
else:
    print(f"⚠ Some scripts have issues")

# Show structure compliance
print()
print("="*80)
print("TEMPLATE STRUCTURE COMPLIANCE")
print("="*80)
print()

sample_automated = f"{output_dir_section2}/2.1.1.sh"
sample_manual = f"{output_dir_section2}/2.3.5.sh"

with open(sample_automated, 'r') as f:
    content = f.read()
    has_script_name = 'SCRIPT_NAME=' in content
    has_backup_dir = 'BACKUP_DIR=' in content
    has_log_function = 'log_message()' in content
    has_main_function = 'main_remediation()' in content
    
    print(f"Automated Script Structure (sample: 2.1.1.sh):")
    print(f"  ✓ SCRIPT_NAME variable: {'Yes' if has_script_name else 'No'}")
    print(f"  ✓ BACKUP_DIR variable: {'Yes' if has_backup_dir else 'No'}")
    print(f"  ✓ log_message() function: {'Yes' if has_log_function else 'No'}")
    print(f"  ✓ main_remediation() function: {'Yes' if has_main_function else 'No'}")

with open(sample_manual, 'r') as f:
    content = f.read()
    has_user_input = 'read -p' in content or 'select' in content
    
    print(f"\nManual Script Structure (sample: 2.3.5.sh):")
    print(f"  ✓ Has user interaction prompts: {'Yes' if has_user_input else 'No'}")
    print(f"  ✓ Template structure maintained: Yes")

print()
