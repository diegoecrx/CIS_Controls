#!/bin/bash

###############################################################################
# CIS Oracle Linux 7 Benchmark
# 3.4.4.3.2.sh
# CIS Control - 3.4.4.3.2 Ensure repo_gpgcheck is globally activated (Manual)

# This script implements proper CIS controls with comprehensive error handling
###############################################################################

SCRIPT_NAME="3.4.4.3.2.sh"
BACKUP_DIR="/tmp/cis_backup"
LOG_FILE="/var/log/cis_remediation.log"
ERROR_LOG="/var/log/cis_error_analysis.log"

# Create backup directory
mkdir -p "$BACKUP_DIR" 2>/dev/null || {
    echo "Failed to create backup directory: $BACKUP_DIR"
    exit 1
}

# Enhanced logging function with error categorization
log_message() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] [$SCRIPT_NAME] $message" | tee -a "$LOG_FILE"

    # Also log to error log if it's an error
    if [ "$level" = "ERROR" ]; then
        echo "[$timestamp] [$SCRIPT_NAME] ERROR: $message" >> "$ERROR_LOG"
    fi
}

# Enhanced backup function with validation
backup_file() {
    local file_path="$1"

    if [ ! -f "$file_path" ]; then
        log_message "WARNING" "File does not exist for backup: $file_path"
        return 1
    fi

    if [ ! -r "$file_path" ]; then
        log_message "ERROR" "Cannot read file for backup: $file_path"
        return 1
    fi

    local backup_name="$(basename "$file_path").$(date +%Y%m%d_%H%M%S).backup"

    if cp "$file_path" "$BACKUP_DIR/$backup_name" 2>/dev/null; then
        log_message "INFO" "Backed up $file_path to $BACKUP_DIR/$backup_name"
        echo "$BACKUP_DIR/$backup_name"
        return 0
    else
        log_message "ERROR" "Failed to backup $file_path"
        return 1
    fi
}

# Function to check global repo_gpgcheck setting
check_global_repo_gpgcheck() {
    local yum_conf="/etc/yum.conf"
    
    if [ ! -f "$yum_conf" ]; then
        log_message "ERROR" "Configuration file not found: $yum_conf"
        return 1
    fi

    # Check if repo_gpgcheck=1 exists in the [main] section
    if awk '
        /^\[main\]/ { in_main=1 }
        /^\[/ && !/^\[main\]/ { in_main=0 }
        in_main && /^repo_gpgcheck=1$/ { found=1 }
        END { exit !found }
    ' "$yum_conf"; then
        log_message "INFO" "Global repo_gpgcheck is set to 1 in $yum_conf"
        return 0
    else
        log_message "WARNING" "Global repo_gpgcheck is not set to 1 in $yum_conf"
        return 1
    fi
}

# Function to check repository-specific repo_gpgcheck settings
check_repo_repo_gpgcheck() {
    local repo_files="/etc/yum.repos.d/*.repo"
    local non_compliant_repos=()
    local compliant_repos=()
    local has_non_compliant=1
    
    for repo_file in $repo_files; do
        [ -f "$repo_file" ] || continue
        
        # Check each repository section in the file
        while IFS= read -r section; do
            if [ -n "$section" ]; then
                # Check if repo_gpgcheck=1 exists in this specific section
                if awk -v section="$section" '
                    $0 ~ "\\[" section "\\]" { in_section=1; next }
                    in_section && /^\[/ { in_section=0; exit }
                    in_section && /^repo_gpgcheck=1$/ { found=1; exit }
                    END { exit !found }
                ' "$repo_file"; then
                    log_message "INFO" "Repository $repo_file [$section] has repo_gpgcheck=1"
                    compliant_repos+=("$repo_file [$section]")
                else
                    log_message "WARNING" "Repository $repo_file [$section] does not have repo_gpgcheck=1"
                    non_compliant_repos+=("$repo_file [$section]")
                    has_non_compliant=0
                fi
            fi
        done < <(grep "^\[.*\]" "$repo_file" | tr -d '[]')
    done
    
    # Log summary
    if [ "$has_non_compliant" -eq 1 ]; then
        log_message "SUCCESS" "All repository-specific repo_gpgcheck settings are compliant"
        return 0
    else
        log_message "WARNING" "Found ${#non_compliant_repos[@]} non-compliant repository sections"
        for repo in "${non_compliant_repos[@]}"; do
            log_message "INFO" "Non-compliant: $repo"
        done
        return 1
    fi
}

# Function to set global repo_gpgcheck
set_global_repo_gpgcheck() {
    local yum_conf="/etc/yum.conf"
    
    log_message "INFO" "Setting global repo_gpgcheck in $yum_conf"
    
    # Backup the file
    if ! backup_file "$yum_conf"; then
        log_message "ERROR" "Failed to backup $yum_conf"
        return 1
    fi
    
    # Check if [main] section exists
    if ! grep -q "^\[main\]" "$yum_conf"; then
        log_message "WARNING" "[main] section not found in $yum_conf, adding it"
        echo -e "\n[main]" >> "$yum_conf"
    fi
    
    # Remove existing repo_gpgcheck line in [main] section and add new one
    if awk '
        /^\[main\]/ { in_main=1 }
        /^\[/ && !/^\[main\]/ { in_main=0 }
        in_main && /^repo_gpgcheck=/ { next }
        { print }
        /^\[main\]/ && !added { 
            print "repo_gpgcheck=1"
            added=1
        }
        END { if (!added) print "repo_gpgcheck=1" }
    ' "$yum_conf" > "$yum_conf.tmp"; then
        if mv "$yum_conf.tmp" "$yum_conf"; then
            log_message "SUCCESS" "Successfully set global repo_gpgcheck=1 in $yum_conf"
            return 0
        else
            log_message "ERROR" "Failed to replace $yum_conf"
            return 1
        fi
    else
        log_message "ERROR" "Failed to process $yum_conf"
        return 1
    fi
}

# Function to set repository-specific repo_gpgcheck
set_repo_repo_gpgcheck() {
    local repo_files="/etc/yum.repos.d/*.repo"
    local files_modified=0
    local sections_modified=0
    
    for repo_file in $repo_files; do
        [ -f "$repo_file" ] || continue
        
        local file_modified=0
        local temp_created=0
        
        # Backup the repository file
        if ! backup_file "$repo_file"; then
            log_message "ERROR" "Failed to backup $repo_file"
            continue
        fi
        
        # Create temporary file for processing
        local temp_file
        temp_file=$(mktemp)
        temp_created=1
        
        # Process the repository file
        local current_section=""
        local section_modified=0
        
        while IFS= read -r line; do
            # Detect section headers
            if [[ "$line" =~ ^\[(.+)\] ]]; then
                # If we were in a section that didn't have repo_gpgcheck, add it
                if [[ -n "$current_section" ]] && [[ "$section_modified" -eq 0 ]]; then
                    echo "repo_gpgcheck=1" >> "$temp_file"
                    log_message "INFO" "Added repo_gpgcheck=1 to section [$current_section] in $repo_file"
                    ((sections_modified++))
                fi
                current_section="${BASH_REMATCH[1]}"
                section_modified=0
                echo "$line" >> "$temp_file"
                continue
            fi
            
            # Check for existing repo_gpgcheck in current section
            if [[ -n "$current_section" ]] && [[ "$line" =~ ^repo_gpgcheck= ]]; then
                if [[ "$line" == "repo_gpgcheck=1" ]]; then
                    echo "$line" >> "$temp_file"
                    section_modified=1
                else
                    echo "repo_gpgcheck=1" >> "$temp_file"
                    log_message "INFO" "Updated repo_gpgcheck to 1 in section [$current_section] in $repo_file"
                    section_modified=1
                    file_modified=1
                    ((sections_modified++))
                fi
                continue
            fi
            
            echo "$line" >> "$temp_file"
        done < "$repo_file"
        
        # Handle the last section if it didn't have repo_gpgcheck
        if [[ -n "$current_section" ]] && [[ "$section_modified" -eq 0 ]]; then
            echo "repo_gpgcheck=1" >> "$temp_file"
            log_message "INFO" "Added repo_gpgcheck=1 to section [$current_section] in $repo_file"
            file_modified=1
            ((sections_modified++))
        fi
        
        # Replace the original file if modifications were made
        if [[ "$file_modified" -eq 1 ]]; then
            if mv "$temp_file" "$repo_file"; then
                log_message "SUCCESS" "Successfully updated $repo_file"
                files_modified=$((files_modified + 1))
            else
                log_message "ERROR" "Failed to update $repo_file"
            fi
        else
            rm -f "$temp_file"
            log_message "INFO" "No changes needed for $repo_file"
        fi
        
    done
    
    if [[ "$sections_modified" -gt 0 ]]; then
        log_message "SUCCESS" "Modified $sections_modified repository sections across $files_modified files"
        return 0
    else
        log_message "INFO" "No repository sections needed modification"
        return 1
    fi
}

# Function to show step-by-step remediation
show_remediation_steps() {
    echo ""
    echo "=========================================================================="
    echo "  Step-by-Step Remediation Instructions"
    echo "=========================================================================="
    echo ""
    echo "To manually configure repo_gpgcheck:"
    echo ""
    echo "1. Global Configuration:"
    echo "   Edit /etc/yum.conf and ensure the [main] section contains:"
    echo "   repo_gpgcheck=1"
    echo ""
    echo "   Example:"
    echo "   [main]"
    echo "   repo_gpgcheck=1"
    echo ""
    echo "2. Repository-specific Configuration:"
    echo "   For each repository file in /etc/yum.repos.d/*.repo:"
    echo "   - Edit the file"
    echo "   - For each repository section ([section-name]), ensure it contains:"
    echo "     repo_gpgcheck=1"
    echo ""
    echo "   Example:"
    echo "   [ol7_latest]"
    echo "   name=Oracle Linux $releasever Latest ($basearch)"
    echo "   baseurl=https://yum.oracle.com/repo/OracleLinux/OL7/latest/$basearch/"
    echo "   gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-oracle"
    echo "   gpgcheck=1"
    echo "   repo_gpgcheck=1"
    echo ""
    echo "3. Verification:"
    echo "   Run these commands to verify the configuration:"
    echo "   - Check global: grep '^repo_gpgcheck=1' /etc/yum.conf"
    echo "   - Check repositories: grep -r '^repo_gpgcheck=1' /etc/yum.repos.d/"
    echo ""
    echo "=========================================================================="
    echo ""
}

# Function to prompt user for remediation choice
prompt_user_for_remediation() {
    echo ""
    echo "=========================================================================="
    echo "  3.4.4.3.2 Ensure repo_gpgcheck is globally activated (Manual)"
    echo "=========================================================================="
    echo ""
    echo "Issue: repo_gpgcheck is not properly configured"
    echo ""
    echo "CIS Benchmark 3.4.4.3.2 requires repo_gpgcheck to be set to 1 for:"
    echo "  - Global configuration in /etc/yum.conf [main] section"
    echo "  - All repository configurations in /etc/yum.repos.d/*.repo"
    echo ""
    echo "This ensures GPG signature checking on repository metadata for"
    echo "enhanced package integrity verification."
    echo ""
    echo "Recommended Remediation:"
    echo "  Apply both global and repository-specific configurations:"
    echo "  1. Set repo_gpgcheck=1 in /etc/yum.conf [main] section"
    echo "  2. Set repo_gpgcheck=1 in all repository files in /etc/yum.repos.d/"
    echo ""
    echo "=========================================================================="
    echo ""
    echo "What would you like to do?"
    echo ""
    echo "  1) Apply recommended remediation"
    echo "  2) Show step-by-step remediation"
    echo "  3) Skip remediation"
    echo ""

    while true; do
        read -p "Enter your choice [1-3]: " choice
        case $choice in
            1)
                log_message "INFO" "User selected: Apply remediation"
                return 1
                ;;
            2)
                log_message "INFO" "User selected: Show step-by-step remediation"
                return 2
                ;;
            3)
                log_message "INFO" "User selected: Skip remediation"
                return 3
                ;;
            *)
                echo "Invalid choice. Please enter 1, 2, or 3."
                ;;
        esac
    done
}

# Function to verify remediation with consistent logic
verify_remediation() {
    local verification_passed=0
    local verification_failed=0
    
    echo ""
    echo "=========================================================================="
    echo "  Remediation Verification"
    echo "=========================================================================="
    echo ""
    
    # Verify global configuration
    echo "Global Configuration:"
    if check_global_repo_gpgcheck; then
        echo "  ✓ PASS: Global repo_gpgcheck is properly configured"
        verification_passed=$((verification_passed + 1))
    else
        echo "  ✗ FAIL: Global repo_gpgcheck is not properly configured"
        verification_failed=$((verification_failed + 1))
        # Show what's actually in the file for debugging
        echo "  Current /etc/yum.conf [main] section:"
        awk '/^\[main\]/,/^\[/' /etc/yum.conf | grep -E "(repo_gpgcheck|\[)" | sed 's/^/    /'
    fi
    echo ""
    
    # Verify repository configurations
    echo "Repository Configurations:"
    if check_repo_repo_gpgcheck; then
        echo "  ✓ PASS: All repository repo_gpgcheck settings are compliant"
        verification_passed=$((verification_passed + 1))
    else
        echo "  ✗ FAIL: Some repository repo_gpgcheck settings are not compliant"
        verification_failed=$((verification_failed + 1))
        # Show a few examples of what's wrong
        echo "  Sample of non-compliant repositories:"
        local count=0
        for repo_file in /etc/yum.repos.d/*.repo; do
            [ -f "$repo_file" ] || continue
            while IFS= read -r section; do
                if [ -n "$section" ]; then
                    if ! awk -v section="$section" '
                        $0 ~ "\\[" section "\\]" { in_section=1; next }
                        in_section && /^\[/ { in_section=0; exit }
                        in_section && /^repo_gpgcheck=1$/ { found=1; exit }
                        END { exit !found }
                    ' "$repo_file"; then
                        if [ "$count" -lt 5 ]; then  # Show only first 5 for brevity
                            echo "    - $repo_file [$section]"
                            count=$((count + 1))
                        fi
                    fi
                fi
            done < <(grep "^\[.*\]" "$repo_file" | tr -d '[]')
        done
        if [ "$count" -ge 5 ]; then
            echo "    ... and more"
        fi
    fi
    echo ""
    
    # Return results
    echo "$verification_passed:$verification_failed"
}

# Main remediation function
main_remediation() {
    log_message "INFO" "Starting remediation: $SCRIPT_NAME"

    # Since this is a Manual remediation, prompt user for action
    prompt_user_for_remediation
    local user_choice=$?

    case $user_choice in
        1) # Apply remediation
            log_message "INFO" "Applying repo_gpgcheck remediation"
            
            # Apply global configuration
            if set_global_repo_gpgcheck; then
                log_message "SUCCESS" "Global repo_gpgcheck configuration applied"
            else
                log_message "ERROR" "Failed to apply global repo_gpgcheck configuration"
            fi
            
            # Apply repository configurations
            if set_repo_repo_gpgcheck; then
                log_message "SUCCESS" "Repository repo_gpgcheck configurations applied"
            else
                log_message "WARNING" "No repository configurations needed modification or failed"
            fi
            
            # Verify remediation
            log_message "INFO" "Verifying remediation results"
            local verification_results
            verification_results=$(verify_remediation)
            local verification_passed="${verification_results%:*}"
            local verification_failed="${verification_results#*:}"
            
            # Display final results
            echo "=========================================================================="
            echo "  Verification Results"
            echo "=========================================================================="
            echo ""
            echo "Tests Passed: $verification_passed"
            echo "Tests Failed: $verification_failed"
            echo ""
            
            if [ "$verification_failed" -eq 0 ]; then
                echo "The system is now compliant with CIS Benchmark 3.4.4.3.2."
                log_message "SUCCESS" "Remediation completed successfully: $SCRIPT_NAME"
            else
                echo "Some verification checks failed. Manual review may be required."
                log_message "WARNING" "Remediation completed with warnings: $SCRIPT_NAME"
            fi
            ;;
            
        2) # Show step-by-step remediation
            show_remediation_steps
            log_message "INFO" "Step-by-step remediation instructions displayed"
            ;;
            
        3) # Skip remediation
            log_message "WARNING" "Remediation skipped by user"
            log_message "WARNING" "System is NOT compliant with CIS Benchmark 3.4.4.3.2"
            echo ""
            echo "=========================================================================="
            echo "  Remediation Skipped"
            echo "=========================================================================="
            echo ""
            echo "The system remains non-compliant with CIS Benchmark 3.4.4.3.2"
            echo "Manual intervention required to meet compliance requirements"
            echo ""
            ;;
    esac
    
    echo ""
    
    return $((verification_failed > 0 ? 1 : 0))
}

# Execute main function if script is run directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Error: This script must be run as root"
        log_message "ERROR" "Script must be run as root"
        exit 1
    fi

    main_remediation
    exit $?
fi