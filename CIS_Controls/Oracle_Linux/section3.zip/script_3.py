
# Create README for Section 3
readme_section3 = []
readme_section3.append("="*80)
readme_section3.append("CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 3 REMEDIATION SCRIPTS")
readme_section3.append("="*80)
readme_section3.append("")
readme_section3.append(f"Total Scripts Generated: 46")
readme_section3.append(f"Generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
readme_section3.append("")
readme_section3.append("="*80)
readme_section3.append("SCRIPT BREAKDOWN")
readme_section3.append("="*80)
readme_section3.append("")
readme_section3.append(f"Automated Scripts (template_automated.sh): 39")
readme_section3.append(f"Manual Scripts (template_manual.sh): 7")
readme_section3.append("")
readme_section3.append("="*80)
readme_section3.append("ALL GENERATED SCRIPTS")
readme_section3.append("="*80)
readme_section3.append("")

# Group by category
current_category = ''
category_ranges = {
    '3.1': 'Network Configuration',
    '3.2': 'Network Kernel Modules',
    '3.3': 'Network Parameters (Host Only)',
    '3.4': 'Firewall Configuration'
}

for idx, row in df_section3.iterrows():
    script_name = row['script_name']
    item_name = row['item_name']
    
    # Determine category
    for cat_prefix, cat_name in category_ranges.items():
        if script_name.startswith(cat_prefix):
            if cat_name != current_category:
                current_category = cat_name
                readme_section3.append(f"\n{'─'*80}")
                readme_section3.append(f"{current_category}")
                readme_section3.append(f"{'─'*80}")
            break
    
    # Determine type
    script_type = "Automated" if "Automated" in item_name else "Manual"
    
    readme_section3.append(f"  {script_name}.sh - {script_type}")
    readme_section3.append(f"    {item_name}")

readme_section3.append("")
readme_section3.append("="*80)
readme_section3.append("TEMPLATE STRUCTURE")
readme_section3.append("="*80)
readme_section3.append("")
readme_section3.append("AUTOMATED SCRIPTS follow template_automated.sh structure:")
readme_section3.append("  - Standard variables (SCRIPT_NAME, BACKUP_DIR, LOG_FILE, ERROR_LOG)")
readme_section3.append("  - Enhanced logging with log_message() function")
readme_section3.append("  - Backup functionality with backup_file() function")
readme_section3.append("  - Check functions for current state verification")
readme_section3.append("  - Remediation functions for applying fixes")
readme_section3.append("  - Verification functions for post-remediation checks")
readme_section3.append("  - main_remediation() orchestrating function")
readme_section3.append("  - Comprehensive error handling and logging")
readme_section3.append("")
readme_section3.append("MANUAL SCRIPTS follow template_manual.sh structure:")
readme_section3.append("  - Same foundational structure as automated scripts")
readme_section3.append("  - Interactive user prompts with 3 options:")
readme_section3.append("    1. Display detailed information")
readme_section3.append("    2. Proceed with remediation")
readme_section3.append("    3. Exit without changes")
readme_section3.append("  - Require manual review and approval before execution")
readme_section3.append("")
readme_section3.append("="*80)
readme_section3.append("USAGE")
readme_section3.append("="*80)
readme_section3.append("")
readme_section3.append("To execute a script:")
readme_section3.append("  1. Ensure you have root privileges")
readme_section3.append("  2. Make the script executable: chmod +x <script_name>.sh")
readme_section3.append("  3. Run the script: sudo ./<script_name>.sh")
readme_section3.append("")
readme_section3.append("="*80)
readme_section3.append("IMPORTANT NOTES")
readme_section3.append("="*80)
readme_section3.append("")
readme_section3.append("1. All scripts create backups in /tmp/cis_backup/")
readme_section3.append("2. All actions are logged to /var/log/cis_remediation.log")
readme_section3.append("3. Errors are tracked in /var/log/cis_error_analysis.log")
readme_section3.append("4. Some changes may require system reboot to take effect")
readme_section3.append("5. Review CIS Benchmark documentation before applying remediations")
readme_section3.append("6. Test in non-production environment first")
readme_section3.append("")
readme_section3.append("="*80)

readme_text = '\n'.join(readme_section3)
with open(f'{output_dir_section3}/README.txt', 'w') as f:
    f.write(readme_text)

print(readme_text)
print(f"\n✓ README saved to {output_dir_section3}/README.txt")
