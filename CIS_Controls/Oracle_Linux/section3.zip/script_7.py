
# Show sample scripts from Section 3

print("="*80)
print("SECTION 3 - SAMPLE SCRIPT VERIFICATION")
print("="*80)
print()

# Show header of an automated script from section 3
print("SECTION 3 AUTOMATED SCRIPT SAMPLE (3.2.1.sh) - First 35 lines:")
print("-"*80)
with open(f"{output_dir_section3}/3.2.1.sh", 'r') as f:
    lines = f.readlines()
    for i, line in enumerate(lines[:35], 1):
        print(f"{i:3d}: {line}", end='')
print()
print()

# Show header of a manual script from section 3
print("SECTION 3 MANUAL SCRIPT SAMPLE (3.1.1.sh) - First 35 lines:")
print("-"*80)
with open(f"{output_dir_section3}/3.1.1.sh", 'r') as f:
    lines = f.readlines()
    for i, line in enumerate(lines[:35], 1):
        print(f"{i:3d}: {line}", end='')
print()
print()

print("="*100)
print("✓✓✓ SECTION 3 COMPLETE - ALL 46 SCRIPTS GENERATED AND VERIFIED ✓✓✓")
print("="*100)
print()
print(f"Location: {output_dir_section3}/")
print(f"Archive:  {zip_filename_s3}")
print(f"Manifest: DELIVERY_MANIFEST_SECTION3.txt")
print()
print("All scripts are ready for deployment!")
print()
