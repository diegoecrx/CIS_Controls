
# Load Section 4 spreadsheet
import pandas as pd
import os
import zipfile

file_path = "CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section4.xlsx"
df_section4 = pd.read_excel(file_path)

print("="*80)
print("SECTION 4 SPREADSHEET ANALYSIS")
print("="*80)
print()

print(f"Column names: {df_section4.columns.tolist()}")
print(f"\nDataframe shape: {df_section4.shape}")
print(f"Number of remediations: {len(df_section4)}")

print("\n\nFirst 5 rows:")
print(df_section4.head())

# Check for Automated vs Manual
automated_count = df_section4['item_name'].str.contains('Automated', case=False, na=False).sum()
manual_count = df_section4['item_name'].str.contains('Manual', case=False, na=False).sum()

print(f"\n\nAutomated controls: {automated_count}")
print(f"Manual controls: {manual_count}")
print(f"Total: {len(df_section4)}")
