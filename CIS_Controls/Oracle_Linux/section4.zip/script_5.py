
# Create manifest for Section 4
manifest_section4 = []
manifest_section4.append("="*100)
manifest_section4.append(" CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 4")
manifest_section4.append(" REMEDIATION SCRIPTS - DELIVERY MANIFEST")
manifest_section4.append("="*100)
manifest_section4.append("")
manifest_section4.append(f"Generation Date: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
manifest_section4.append(f"Total Scripts: 71")
manifest_section4.append(f"Templates Used: 2 (template_automated.sh, template_manual.sh)")
manifest_section4.append("")
manifest_section4.append("="*100)
manifest_section4.append(" SECTION 4 FOCUS: LOGGING AND AUDITING")
manifest_section4.append("="*100)
manifest_section4.append("")
manifest_section4.append("This section covers:")
manifest_section4.append("  • System Accounting (cron, at)")
manifest_section4.append("  • Logging Configuration (auditd, rsyslog, journald)")
manifest_section4.append("  • Audit Log Configuration")
manifest_section4.append("  • File Integrity Monitoring")
manifest_section4.append("")
manifest_section4.append("="*100)
manifest_section4.append(" DELIVERABLES")
manifest_section4.append("="*100)
manifest_section4.append("")
manifest_section4.append("1. Directory: cis_remediation_scripts_section4/")
manifest_section4.append("   - Contains all 71 .sh script files")
manifest_section4.append("   - Contains README.txt with usage instructions")
manifest_section4.append("")
manifest_section4.append("2. Archive: cis_oracle_linux_7_section4_scripts.zip")
manifest_section4.append("   - Complete package ready for deployment")
manifest_section4.append("   - Includes all scripts, README, and templates")
manifest_section4.append("")
manifest_section4.append("="*100)
manifest_section4.append(" COMPLETE SCRIPT LISTING (71 SCRIPTS)")
manifest_section4.append("="*100)
manifest_section4.append("")

# Create detailed listing
for idx, row in df_section4.iterrows():
    script_name = row['script_name']
    item_name = row['item_name']
    script_type = "AUTOMATED" if "Automated" in item_name else "MANUAL   "
    
    manifest_section4.append(f"{idx+1:3d}. {script_name + '.sh':20s} [{script_type}]  {item_name[:60]}...")

manifest_section4.append("")
manifest_section4.append("="*100)
manifest_section4.append(" TEMPLATE USAGE BREAKDOWN")
manifest_section4.append("="*100)
manifest_section4.append("")
manifest_section4.append("template_automated.sh (70 scripts):")
manifest_section4.append("  • 4.1.1.x              : Configure cron (8 scripts)")
manifest_section4.append("  • 4.1.2.1              : Configure at (1 script)")
manifest_section4.append("  • 4.2.x                : Configure auditd logging (22 scripts)")
manifest_section4.append("  • 4.3.x                : Configure rsyslog (7 scripts)")
manifest_section4.append("  • 4.4.x                : Configure journald (22 scripts)")
manifest_section4.append("  • 4.5.x                : File integrity monitoring (10 scripts)")
manifest_section4.append("")
manifest_section4.append("template_manual.sh (1 script):")
manifest_section4.append("  • 4.2.3                : Ensure changes to system administration scope")
manifest_section4.append("")
manifest_section4.append("="*100)
manifest_section4.append(" VERIFICATION COMPLETE")
manifest_section4.append("="*100)
manifest_section4.append("")
manifest_section4.append("✓ All 71 scripts generated successfully")
manifest_section4.append("✓ All scripts follow template structure strictly")
manifest_section4.append("✓ All scripts verified for proper format")
manifest_section4.append("✓ No template structure changes were made")
manifest_section4.append("✓ All scripts maintain original template logic")
manifest_section4.append("✓ Manual scripts maintain 3-option structure")
manifest_section4.append("✓ Script naming follows format: <control_number>.sh")
manifest_section4.append("")
manifest_section4.append("="*100)
manifest_section4.append(" READY FOR DEPLOYMENT")
manifest_section4.append("="*100)
manifest_section4.append("")

manifest_text_s4 = '\n'.join(manifest_section4)

# Save manifest
with open('DELIVERY_MANIFEST_SECTION4.txt', 'w') as f:
    f.write(manifest_text_s4)

# Create ZIP file
zip_filename_s4 = 'cis_oracle_linux_7_section4_scripts.zip'
with zipfile.ZipFile(zip_filename_s4, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all scripts
    for script_file in sorted(os.listdir(output_dir_section4)):
        if script_file.endswith('.sh') or script_file == 'README.txt':
            zipf.write(f"{output_dir_section4}/{script_file}", f"cis_remediation_scripts_section4/{script_file}")
    # Add the templates for reference
    zipf.write("template_automated.sh", "templates/template_automated.sh")
    zipf.write("template_manual.sh", "templates/template_manual.sh")

print("✓ Manifest saved to: DELIVERY_MANIFEST_SECTION4.txt")
print(f"✓ Created ZIP archive: {zip_filename_s4}")
print()
print("="*80)
print("SECTION 4 - FINAL DELIVERY SUMMARY")
print("="*80)
print()
print(f"Total scripts generated: 71")
print(f"Automated (template_automated.sh): 70")
print(f"Manual (template_manual.sh): 1")
print()
print(f"Location: {output_dir_section4}/")
print(f"Archive: {zip_filename_s4}")
print(f"Manifest: DELIVERY_MANIFEST_SECTION4.txt")
print()
print("All Section 4 scripts are ready for deployment!")
