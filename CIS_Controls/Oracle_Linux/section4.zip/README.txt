================================================================================
CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 4 REMEDIATION SCRIPTS
================================================================================

Total Scripts Generated: 71
Generated on: 2025-10-30 21:06:31

================================================================================
SCRIPT BREAKDOWN
================================================================================

Automated Scripts (template_automated.sh): 70
Manual Scripts (template_manual.sh): 1

================================================================================
SECTION 4 FOCUS
================================================================================

Logging and Auditing
  - Configure system accounting (cron, at)
  - Configure system logging (auditd, rsyslog, journald)
  - Ensure logfile integrity
  - Configure audit logs

================================================================================
ALL GENERATED SCRIPTS
================================================================================


────────────────────────────────────────────────────────────────────────────────
Configure cron
────────────────────────────────────────────────────────────────────────────────
  4.1.1.1.sh - Automated
    4.1.1.1 Ensure cron daemon is enabled and active (Automated)
  4.1.1.2.sh - Automated
    4.1.1.2 Ensure permissions on /etc/crontab are configured (Automated)
  4.1.1.3.sh - Automated
    4.1.1.3 Ensure permissions on /etc/cron.hourly are configured (Automated)
  4.1.1.4.sh - Automated
    4.1.1.4 Ensure permissions on /etc/cron.daily are configured (Automated)
  4.1.1.5.sh - Automated
    4.1.1.5 Ensure permissions on /etc/cron.weekly are configured (Automated)
  4.1.1.6.sh - Automated
    4.1.1.6 Ensure permissions on /etc/cron.monthly are configured (Automated)
  4.1.1.7.sh - Automated
    4.1.1.7 Ensure permissions on /etc/cron.d are configured (Automated)
  4.1.1.8.sh - Automated
    4.1.1.8 Ensure crontab is restricted to authorized users (Automated)

────────────────────────────────────────────────────────────────────────────────
Configure at
────────────────────────────────────────────────────────────────────────────────
  4.1.2.1.sh - Automated
    4.1.2.1 Ensure at is restricted to authorized users (Automated)

────────────────────────────────────────────────────────────────────────────────
Configure Logging - auditd
────────────────────────────────────────────────────────────────────────────────
  4.2.1.sh - Automated
    4.2.1 Ensure permissions on /etc/ssh/sshd_config are configured (Automated)
  4.2.2.sh - Automated
    4.2.2 Ensure permissions on SSH private host key files are configured (Automated)
  4.2.3.sh - Automated
    4.2.3 Ensure permissions on SSH public host key files are configured (Automated)
  4.2.4.sh - Automated
    4.2.4 Ensure sshd access is configured (Automated)
  4.2.5.sh - Automated
    4.2.5 Ensure sshd Banner is configured (Automated)
  4.2.6.sh - Automated
    4.2.6 Ensure sshd Ciphers are configured (Automated)
  4.2.7.sh - Automated
    4.2.7 Ensure sshd ClientAliveInterval and ClientAliveCountMax are configured (Automated)
  4.2.8.sh - Automated
    4.2.8 Ensure sshd DisableForwarding is enabled (Automated)
  4.2.9.sh - Automated
    4.2.9 Ensure sshd GSSAPIAuthentication is disabled (Automated)
  4.2.10.sh - Automated
    4.2.10 Ensure sshd HostbasedAuthentication is disabled (Automated)
  4.2.11.sh - Automated
    4.2.11 Ensure sshd IgnoreRhosts is enabled (Automated)
  4.2.12.sh - Automated
    4.2.12 Ensure sshd KexAlgorithms is configured (Automated)
  4.2.13.sh - Automated
    4.2.13 Ensure sshd LoginGraceTime is configured (Automated)
  4.2.14.sh - Automated
    4.2.14 Ensure sshd LogLevel is configured (Automated)
  4.2.15.sh - Automated
    4.2.15 Ensure sshd MACs are configured (Automated)
  4.2.16.sh - Automated
    4.2.16 Ensure sshd MaxAuthTries is configured (Automated)
  4.2.17.sh - Automated
    4.2.17 Ensure sshd MaxSessions is configured (Automated)
  4.2.18.sh - Automated
    4.2.18 Ensure sshd MaxStartups is configured (Automated)
  4.2.19.sh - Automated
    4.2.19 Ensure sshd PermitEmptyPasswords is disabled (Automated)
  4.2.20.sh - Automated
    4.2.20 Ensure sshd PermitRootLogin is disabled (Automated)
  4.2.21.sh - Automated
    4.2.21 Ensure sshd PermitUserEnvironment is disabled (Automated)
  4.2.22.sh - Automated
    4.2.22 Ensure sshd UsePAM is enabled (Automated)

────────────────────────────────────────────────────────────────────────────────
Configure Logging - rsyslog
────────────────────────────────────────────────────────────────────────────────
  4.3.1.sh - Automated
    4.3.1 Ensure sudo is installed (Automated)
  4.3.2.sh - Automated
    4.3.2 Ensure sudo commands use pty (Automated)
  4.3.3.sh - Automated
    4.3.3 Ensure sudo log file exists (Automated)
  4.3.4.sh - Automated
    4.3.4 Ensure users must provide password for escalation (Automated)
  4.3.5.sh - Automated
    4.3.5 Ensure re-authentication for privilege escalation is not disabled globally (Automated)
  4.3.6.sh - Automated
    4.3.6 Ensure sudo authentication timeout is configured correctly (Automated)
  4.3.7.sh - Automated
    4.3.7 Ensure access to the su command is restricted (Automated)

────────────────────────────────────────────────────────────────────────────────
Configure Logging - journald
────────────────────────────────────────────────────────────────────────────────
  4.4.1.1.sh - Automated
    4.4.1.1 Ensure latest version of pam is installed (Automated)
  4.4.1.2.sh - Automated
    4.4.1.2 Ensure libpwquality is installed (Automated)
  4.4.2.1.1.sh - Automated
    4.4.2.1.1 Ensure pam_faillock module is enabled (Automated)
  4.4.2.1.2.sh - Automated
    4.4.2.1.2 Ensure password failed attempts lockout is configured (Automated)
  4.4.2.1.3.sh - Automated
    4.4.2.1.3 Ensure password unlock time is configured (Automated)
  4.4.2.1.4.sh - Automated
    4.4.2.1.4 Ensure password failed attempts lockout includes root account (Automated)
  4.4.2.2.1.sh - Automated
    4.4.2.2.1 Ensure pam_pwquality module is enabled (Automated)
  4.4.2.2.2.sh - Automated
    4.4.2.2.2 Ensure password number of changed characters is configured (Automated)
  4.4.2.2.3.sh - Automated
    4.4.2.2.3 Ensure password length is configured (Automated)
  4.4.2.2.4.sh - Manual
    4.4.2.2.4 Ensure password complexity is configured (Manual)
  4.4.2.2.5.sh - Automated
    4.4.2.2.5 Ensure password same consecutive characters is configured (Automated)
  4.4.2.2.6.sh - Automated
    4.4.2.2.6 Ensure password maximum sequential characters is configured (Automated)
  4.4.2.2.7.sh - Automated
    4.4.2.2.7 Ensure password dictionary check is enabled (Automated)
  4.4.2.3.1.sh - Automated
    4.4.2.3.1 Ensure pam_pwhistory module is enabled (Automated)
  4.4.2.3.2.sh - Automated
    4.4.2.3.2 Ensure password history remember is configured (Automated)
  4.4.2.3.3.sh - Automated
    4.4.2.3.3 Ensure password history is enforced for the root user (Automated)
  4.4.2.3.4.sh - Automated
    4.4.2.3.4 Ensure pam_pwhistory includes use_authtok (Automated)
  4.4.2.4.1.sh - Automated
    4.4.2.4.1 Ensure pam_unix does not include nullok (Automated)
  4.4.2.4.2.sh - Automated
    4.4.2.4.2 Ensure pam_unix does not include remember (Automated)
  4.4.2.4.3.sh - Automated
    4.4.2.4.3 Ensure pam_unix includes a strong password hashing algorithm (Automated)
  4.4.2.4.4.sh - Automated
    4.4.2.4.4 Ensure pam_unix includes use_authtok (Automated)

────────────────────────────────────────────────────────────────────────────────
Configure File Integrity Monitoring
────────────────────────────────────────────────────────────────────────────────
  4.5.1.1.sh - Automated
    4.5.1.1 Ensure strong password hashing algorithm is configured (Automated)
  4.5.1.2.sh - Automated
    4.5.1.2 Ensure password expiration is 365 days or less (Automated)
  4.5.1.3.sh - Automated
    4.5.1.3 Ensure password expiration warning days is 7 or more (Automated)
  4.5.1.4.sh - Automated
    4.5.1.4 Ensure inactive password lock is 30 days or less (Automated)
  4.5.1.5.sh - Automated
    4.5.1.5 Ensure all users last password change date is in the past (Automated)
  4.5.2.1.sh - Automated
    4.5.2.1 Ensure default group for the root account is GID 0 (Automated)
  4.5.2.2.sh - Automated
    4.5.2.2 Ensure root user umask is configured (Automated)
  4.5.2.3.sh - Automated
    4.5.2.3 Ensure system accounts are secured (Automated)
  4.5.2.4.sh - Automated
    4.5.2.4 Ensure root password is set (Automated)
  4.5.3.1.sh - Automated
    4.5.3.1 Ensure nologin is not listed in /etc/shells (Automated)
  4.5.3.2.sh - Automated
    4.5.3.2 Ensure default user shell timeout is configured (Automated)
  4.5.3.3.sh - Automated
    4.5.3.3 Ensure default user umask is configured (Automated)

================================================================================
USAGE
================================================================================

To execute a script:
  1. Ensure you have root privileges
  2. Make the script executable: chmod +x <script_name>.sh
  3. Run the script: sudo ./<script_name>.sh

================================================================================
IMPORTANT NOTES
================================================================================

1. All scripts create backups in /tmp/cis_backup/
2. All actions are logged to /var/log/cis_remediation.log
3. Errors are tracked in /var/log/cis_error_analysis.log
4. Some changes may require system reboot to take effect
5. Review CIS Benchmark documentation before applying remediations
6. Test in non-production environment first

================================================================================