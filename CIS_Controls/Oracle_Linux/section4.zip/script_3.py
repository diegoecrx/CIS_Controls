
# Verification for Section 4
print("="*80)
print("SECTION 4 VERIFICATION")
print("="*80)
print()

# Check template adherence
automated_count_s4 = df_section4['item_name'].str.contains('Automated', case=False, na=False).sum()
manual_count_s4 = df_section4['item_name'].str.contains('Manual', case=False, na=False).sum()

print(f"Total scripts generated: {len(df_section4)}")
print(f"Automated scripts (template_automated.sh): {automated_count_s4}")
print(f"Manual scripts (template_manual.sh): {manual_count_s4}")
print()

# Verify each script
print("File Verification:")
all_valid = True
for idx, row in df_section4.iterrows():
    script_name = row['script_name']
    filename = f"{output_dir_section4}/{script_name}.sh"
    
    if not os.path.exists(filename):
        print(f"  ✗ MISSING: {filename}")
        all_valid = False
    else:
        with open(filename, 'r') as f:
            first_line = f.readline()
            if not first_line.startswith('#!/bin/bash'):
                print(f"  ✗ INVALID: {filename} (missing shebang)")
                all_valid = False

if all_valid:
    print(f"✓ All {len(df_section4)} scripts verified successfully!")
else:
    print(f"⚠ Some scripts have issues")

print()
print("="*80)
print(f"✓ SECTION 4 COMPLETE - ALL {len(df_section4)} SCRIPTS GENERATED!")
print("="*80)
