
# Create README for Section 4
readme_section4 = []
readme_section4.append("="*80)
readme_section4.append("CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 4 REMEDIATION SCRIPTS")
readme_section4.append("="*80)
readme_section4.append("")
readme_section4.append(f"Total Scripts Generated: 71")
readme_section4.append(f"Generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
readme_section4.append("")
readme_section4.append("="*80)
readme_section4.append("SCRIPT BREAKDOWN")
readme_section4.append("="*80)
readme_section4.append("")
readme_section4.append(f"Automated Scripts (template_automated.sh): 70")
readme_section4.append(f"Manual Scripts (template_manual.sh): 1")
readme_section4.append("")
readme_section4.append("="*80)
readme_section4.append("SECTION 4 FOCUS")
readme_section4.append("="*80)
readme_section4.append("")
readme_section4.append("Logging and Auditing")
readme_section4.append("  - Configure system accounting (cron, at)")
readme_section4.append("  - Configure system logging (auditd, rsyslog, journald)")
readme_section4.append("  - Ensure logfile integrity")
readme_section4.append("  - Configure audit logs")
readme_section4.append("")
readme_section4.append("="*80)
readme_section4.append("ALL GENERATED SCRIPTS")
readme_section4.append("="*80)
readme_section4.append("")

# Group by category
print("Creating README for Section 4...")
current_category = ''
category_ranges = {
    '4.1.1': 'Configure cron',
    '4.1.2': 'Configure at',
    '4.2': 'Configure Logging - auditd',
    '4.3': 'Configure Logging - rsyslog',
    '4.4': 'Configure Logging - journald',
    '4.5': 'Configure File Integrity Monitoring'
}

for idx, row in df_section4.iterrows():
    script_name = row['script_name']
    item_name = row['item_name']
    
    # Determine category
    for cat_prefix, cat_name in category_ranges.items():
        if script_name.startswith(cat_prefix):
            if cat_name != current_category:
                current_category = cat_name
                readme_section4.append(f"\n{'─'*80}")
                readme_section4.append(f"{current_category}")
                readme_section4.append(f"{'─'*80}")
            break
    
    # Determine type
    script_type = "Automated" if "Automated" in item_name else "Manual"
    
    readme_section4.append(f"  {script_name}.sh - {script_type}")
    readme_section4.append(f"    {item_name}")

readme_section4.append("")
readme_section4.append("="*80)
readme_section4.append("USAGE")
readme_section4.append("="*80)
readme_section4.append("")
readme_section4.append("To execute a script:")
readme_section4.append("  1. Ensure you have root privileges")
readme_section4.append("  2. Make the script executable: chmod +x <script_name>.sh")
readme_section4.append("  3. Run the script: sudo ./<script_name>.sh")
readme_section4.append("")
readme_section4.append("="*80)
readme_section4.append("IMPORTANT NOTES")
readme_section4.append("="*80)
readme_section4.append("")
readme_section4.append("1. All scripts create backups in /tmp/cis_backup/")
readme_section4.append("2. All actions are logged to /var/log/cis_remediation.log")
readme_section4.append("3. Errors are tracked in /var/log/cis_error_analysis.log")
readme_section4.append("4. Some changes may require system reboot to take effect")
readme_section4.append("5. Review CIS Benchmark documentation before applying remediations")
readme_section4.append("6. Test in non-production environment first")
readme_section4.append("")
readme_section4.append("="*80)

readme_text = '\n'.join(readme_section4)
with open(f'{output_dir_section4}/README.txt', 'w') as f:
    f.write(readme_text)

print(f"✓ README saved to {output_dir_section4}/README.txt")
print(f"✓ Total lines: {len(readme_section4)}")
