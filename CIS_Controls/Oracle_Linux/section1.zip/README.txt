================================================================================
CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 1 REMEDIATION SCRIPTS
================================================================================

Total Scripts Generated: 70
Generated on: 2025-10-30 19:11:06

================================================================================
SCRIPT BREAKDOWN
================================================================================

Automated Scripts (template_automated.sh): 66
Manual Scripts (template_manual.sh): 4

================================================================================
ALL GENERATED SCRIPTS
================================================================================


────────────────────────────────────────────────────────────────────────────────
Kernel Modules
────────────────────────────────────────────────────────────────────────────────
  1.1.1.1.sh - Automated
    1.1.1.1 Ensure cramfs kernel module is not available (Automated)
  1.1.1.2.sh - Automated
    1.1.1.2 Ensure freevxfs kernel module is not available (Automated)
  1.1.1.3.sh - Automated
    1.1.1.3 Ensure hfs kernel module is not available (Automated)
  1.1.1.4.sh - Automated
    1.1.1.4 Ensure hfsplus kernel module is not available (Automated)
  1.1.1.5.sh - Automated
    1.1.1.5 Ensure jffs2 kernel module is not available (Automated)
  1.1.1.6.sh - Automated
    1.1.1.6 Ensure squashfs kernel module is not available (Automated)
  1.1.1.7.sh - Automated
    1.1.1.7 Ensure udf kernel module is not available (Automated)
  1.1.1.8.sh - Automated
    1.1.1.8 Ensure usb-storage kernel module is not available (Automated)

────────────────────────────────────────────────────────────────────────────────
/tmp Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.1.1.sh - Automated
    1.1.2.1.1 Ensure /tmp is a separate partition (Automated)
  1.1.2.1.2.sh - Automated
    1.1.2.1.2 Ensure nodev option set on /tmp partition (Automated)
  1.1.2.1.3.sh - Automated
    1.1.2.1.3 Ensure nosuid option set on /tmp partition (Automated)
  1.1.2.1.4.sh - Automated
    1.1.2.1.4 Ensure noexec option set on /tmp partition (Automated)

────────────────────────────────────────────────────────────────────────────────
/dev/shm Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.2.1.sh - Automated
    1.1.2.2.1 Ensure /dev/shm is a separate partition (Automated)
  1.1.2.2.2.sh - Automated
    1.1.2.2.2 Ensure nodev option set on /dev/shm partition (Automated)
  1.1.2.2.3.sh - Automated
    1.1.2.2.3 Ensure nosuid option set on /dev/shm partition (Automated)
  1.1.2.2.4.sh - Automated
    1.1.2.2.4 Ensure noexec option set on /dev/shm partition (Automated)

────────────────────────────────────────────────────────────────────────────────
/home Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.3.1.sh - Automated
    1.1.2.3.1 Ensure separate partition exists for /home (Automated)
  1.1.2.3.2.sh - Automated
    1.1.2.3.2 Ensure nodev option set on /home partition (Automated)
  1.1.2.3.3.sh - Automated
    1.1.2.3.3 Ensure nosuid option set on /home partition (Automated)

────────────────────────────────────────────────────────────────────────────────
/var Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.4.1.sh - Automated
    1.1.2.4.1 Ensure separate partition exists for /var (Automated)
  1.1.2.4.2.sh - Automated
    1.1.2.4.2 Ensure nodev option set on /var partition (Automated)
  1.1.2.4.3.sh - Automated
    1.1.2.4.3 Ensure nosuid option set on /var partition (Automated)

────────────────────────────────────────────────────────────────────────────────
/var/tmp Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.5.1.sh - Automated
    1.1.2.5.1 Ensure separate partition exists for /var/tmp (Automated)
  1.1.2.5.2.sh - Automated
    1.1.2.5.2 Ensure nodev option set on /var/tmp partition (Automated)
  1.1.2.5.3.sh - Automated
    1.1.2.5.3 Ensure nosuid option set on /var/tmp partition (Automated)
  1.1.2.5.4.sh - Automated
    1.1.2.5.4 Ensure noexec option set on /var/tmp partition (Automated)

────────────────────────────────────────────────────────────────────────────────
/var/log Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.6.1.sh - Automated
    1.1.2.6.1 Ensure separate partition exists for /var/log (Automated)
  1.1.2.6.2.sh - Automated
    1.1.2.6.2 Ensure nodev option set on /var/log partition (Automated)
  1.1.2.6.3.sh - Automated
    1.1.2.6.3 Ensure nosuid option set on /var/log partition (Automated)
  1.1.2.6.4.sh - Automated
    1.1.2.6.4 Ensure noexec option set on /var/log partition (Automated)

────────────────────────────────────────────────────────────────────────────────
/var/log/audit Partition Configuration
────────────────────────────────────────────────────────────────────────────────
  1.1.2.7.1.sh - Automated
    1.1.2.7.1 Ensure separate partition exists for /var/log/audit (Automated)
  1.1.2.7.2.sh - Automated
    1.1.2.7.2 Ensure nodev option set on /var/log/audit partition (Automated)
  1.1.2.7.3.sh - Automated
    1.1.2.7.3 Ensure nosuid option set on /var/log/audit partition (Automated)
  1.1.2.7.4.sh - Automated
    1.1.2.7.4 Ensure noexec option set on /var/log/audit partition (Automated)

────────────────────────────────────────────────────────────────────────────────
Package Management
────────────────────────────────────────────────────────────────────────────────
  1.2.1.sh - Manual
    1.2.1 Ensure GPG keys are configured (Manual)
  1.2.2.sh - Automated
    1.2.2 Ensure gpgcheck is globally activated (Automated)
  1.2.3.sh - Manual
    1.2.3 Ensure repo_gpgcheck is globally activated (Manual)
  1.2.4.sh - Manual
    1.2.4 Ensure package manager repositories are configured (Manual)
  1.2.5.sh - Manual
    1.2.5 Ensure updates, patches, and additional security software are installed (Manual)

────────────────────────────────────────────────────────────────────────────────
Bootloader Configuration
────────────────────────────────────────────────────────────────────────────────
  1.3.1.sh - Automated
    1.3.1 Ensure bootloader password is set (Automated)
  1.3.2.sh - Automated
    1.3.2 Ensure permissions on bootloader config are configured (Automated)
  1.3.3.sh - Automated
    1.3.3 Ensure authentication required for single user mode (Automated)

────────────────────────────────────────────────────────────────────────────────
Kernel Parameters
────────────────────────────────────────────────────────────────────────────────
  1.4.1.sh - Automated
    1.4.1 Ensure address space layout randomization (ASLR) is enabled (Automated)
  1.4.2.sh - Automated
    1.4.2 Ensure ptrace_scope is restricted (Automated)
  1.4.3.sh - Automated
    1.4.3 Ensure core dump backtraces are disabled (Automated)
  1.4.4.sh - Automated
    1.4.4 Ensure core dump storage is disabled (Automated)

────────────────────────────────────────────────────────────────────────────────
AppArmor/SELinux Configuration
────────────────────────────────────────────────────────────────────────────────
  1.5.1.1.sh - Automated
    1.5.1.1 Ensure SELinux is installed (Automated)
  1.5.1.2.sh - Automated
    1.5.1.2 Ensure SELinux is not disabled in bootloader configuration (Automated)
  1.5.1.3.sh - Automated
    1.5.1.3 Ensure SELinux policy is configured (Automated)
  1.5.1.4.sh - Automated
    1.5.1.4 Ensure the SELinux mode is not disabled (Automated)
  1.5.1.5.sh - Automated
    1.5.1.5 Ensure the SELinux mode is enforcing (Automated)
  1.5.1.6.sh - Automated
    1.5.1.6 Ensure no unconfined services exist (Automated)
  1.5.1.7.sh - Automated
    1.5.1.7 Ensure the MCS Translation Service (mcstrans) is not installed (Automated)
  1.5.1.8.sh - Automated
    1.5.1.8 Ensure SETroubleshoot is not installed (Automated)

────────────────────────────────────────────────────────────────────────────────
Mandatory Access Control
────────────────────────────────────────────────────────────────────────────────
  1.6.1.sh - Automated
    1.6.1 Ensure message of the day is configured properly (Automated)
  1.6.2.sh - Automated
    1.6.2 Ensure local login warning banner is configured properly (Automated)
  1.6.3.sh - Automated
    1.6.3 Ensure remote login warning banner is configured properly (Automated)
  1.6.4.sh - Automated
    1.6.4 Ensure access to /etc/motd is configured (Automated)
  1.6.5.sh - Automated
    1.6.5 Ensure access to /etc/issue is configured (Automated)
  1.6.6.sh - Automated
    1.6.6 Ensure access to /etc/issue.net is configured (Automated)

────────────────────────────────────────────────────────────────────────────────
Warning Banners
────────────────────────────────────────────────────────────────────────────────
  1.7.1.sh - Automated
    1.7.1 Ensure GNOME Display Manager is removed (Automated)
  1.7.2.sh - Automated
    1.7.2 Ensure GDM login banner is configured (Automated)
  1.7.3.sh - Automated
    1.7.3 Ensure GDM disable-user-list option is enabled (Automated)
  1.7.4.sh - Automated
    1.7.4 Ensure GDM screen locks when the user is idle (Automated)
  1.7.5.sh - Automated
    1.7.5 Ensure GDM screen locks cannot be overridden (Automated)
  1.7.6.sh - Automated
    1.7.6 Ensure GDM automatic mounting of removable media is disabled (Automated)
  1.7.7.sh - Automated
    1.7.7 Ensure GDM disabling automatic mounting of removable media is not overridden (Automated)
  1.7.8.sh - Automated
    1.7.8 Ensure GDM autorun-never is enabled (Automated)
  1.7.9.sh - Automated
    1.7.9 Ensure GDM autorun-never is not overridden (Automated)
  1.7.10.sh - Automated
    1.7.10 Ensure XDMCP is not enabled (Automated)

================================================================================
TEMPLATE STRUCTURE
================================================================================

AUTOMATED SCRIPTS follow template_automated.sh structure:
  - Standard variables (SCRIPT_NAME, BACKUP_DIR, LOG_FILE, ERROR_LOG)
  - Enhanced logging with log_message() function
  - Backup functionality with backup_file() function
  - Check functions for current state verification
  - Remediation functions for applying fixes
  - Verification functions for post-remediation checks
  - main_remediation() orchestrating function
  - Comprehensive error handling and logging

MANUAL SCRIPTS follow template_manual.sh structure:
  - Same foundational structure as automated scripts
  - Interactive user prompts with 3 options:
    1. Display detailed information
    2. Proceed with remediation
    3. Exit without changes
  - Require manual review and approval before execution

================================================================================
USAGE
================================================================================

To execute a script:
  1. Ensure you have root privileges
  2. Make the script executable: chmod +x <script_name>.sh
  3. Run the script: sudo ./<script_name>.sh

Automated scripts will:
  - Display remediation information
  - Check current compliance state
  - Apply remediations if needed
  - Verify changes
  - Log all actions to /var/log/cis_remediation.log

Manual scripts will:
  - Present options for user selection
  - Display detailed information when requested
  - Wait for user confirmation before applying changes
  - Provide guidance for manual verification

================================================================================
IMPORTANT NOTES
================================================================================

1. All scripts create backups in /tmp/cis_backup/
2. All actions are logged to /var/log/cis_remediation.log
3. Errors are tracked in /var/log/cis_error_analysis.log
4. Some changes may require system reboot to take effect
5. Review CIS Benchmark documentation before applying remediations
6. Test in non-production environment first

================================================================================