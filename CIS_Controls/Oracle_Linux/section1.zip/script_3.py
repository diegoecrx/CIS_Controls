
# I'll now create ALL 70 scripts efficiently
# First, let me load the templates

with open('template_automated.sh', 'r') as f:
    template_automated = f.read()

with open('template_manual.sh', 'r') as f:
    template_manual = f.read()

# Create comprehensive generator functions
# I'll create a master function that routes to appropriate generators

def extract_info_from_item(item_name):
    """Extract key information from item name"""
    info = {
        'is_automated': 'Automated' in item_name,
        'is_manual': 'Manual' in item_name,
        'type': 'unknown'
    }
    
    # Categorize by type
    if 'kernel module' in item_name.lower():
        info['type'] = 'kernel_module'
        match = re.search(r'Ensure (\S+) kernel module', item_name)
        info['module_name'] = match.group(1) if match else 'unknown'
    elif 'separate partition' in item_name.lower() and 'option' not in item_name.lower():
        info['type'] = 'separate_partition'
        match = re.search(r'/(tmp|var|home|dev/shm)[\w/]*', item_name)
        info['partition'] = match.group(0) if match else '/tmp'
    elif any(opt in item_name.lower() for opt in ['nodev', 'nosuid', 'noexec']):
        info['type'] = 'mount_option'
        match = re.search(r'/(tmp|var|home|dev/shm)[\w/]*', item_name)
        info['partition'] = match.group(0) if match else '/tmp'
        match = re.search(r'(nodev|nosuid|noexec)', item_name, re.IGNORECASE)
        info['option'] = match.group(1).lower() if match else 'nodev'
    elif 'gpgcheck' in item_name.lower() and info['is_automated']:
        info['type'] = 'gpgcheck_automated'
    elif info['is_manual']:
        info['type'] = 'manual'
    else:
        info['type'] = 'generic_automated'
    
    return info

# Test categorization
print("Testing categorization:")
for idx in [0, 8, 9, 35, 36]:
    row = df.iloc[idx]
    info = extract_info_from_item(row['item_name'])
    print(f"{row['script_name']}: {info['type']}")
