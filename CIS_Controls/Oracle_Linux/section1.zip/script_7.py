
# Create a comprehensive summary of all generated scripts

summary = []
summary.append("="*80)
summary.append("CIS ORACLE LINUX 7 BENCHMARK v4.0.0 - SECTION 1 REMEDIATION SCRIPTS")
summary.append("="*80)
summary.append("")
summary.append(f"Total Scripts Generated: 70")
summary.append(f"Generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
summary.append("")
summary.append("="*80)
summary.append("SCRIPT BREAKDOWN")
summary.append("="*80)
summary.append("")
summary.append(f"Automated Scripts (template_automated.sh): 66")
summary.append(f"Manual Scripts (template_manual.sh): 4")
summary.append("")
summary.append("="*80)
summary.append("ALL GENERATED SCRIPTS")
summary.append("="*80)
summary.append("")

# Group by category
categories = {
    '1.1.1': 'Kernel Modules',
    '1.1.2.1': '/tmp Partition Configuration',
    '1.1.2.2': '/dev/shm Partition Configuration',
    '1.1.2.3': '/home Partition Configuration',
    '1.1.2.4': '/var Partition Configuration',
    '1.1.2.5': '/var/tmp Partition Configuration',
    '1.1.2.6': '/var/log Partition Configuration',
    '1.1.2.7': '/var/log/audit Partition Configuration',
    '1.2': 'Package Management',
    '1.3': 'Bootloader Configuration',
    '1.4': 'Kernel Parameters',
    '1.5.1': 'AppArmor/SELinux Configuration',
    '1.6': 'Mandatory Access Control',
    '1.7': 'Warning Banners'
}

current_category = ''

for idx, row in df.iterrows():
    script_name = row['script_name']
    item_name = row['item_name']
    
    # Determine category
    for cat_prefix, cat_name in categories.items():
        if script_name.startswith(cat_prefix):
            if cat_name != current_category:
                current_category = cat_name
                summary.append(f"\n{'─'*80}")
                summary.append(f"{current_category}")
                summary.append(f"{'─'*80}")
            break
    
    # Determine type
    script_type = "Automated" if "Automated" in item_name else "Manual"
    
    summary.append(f"  {script_name}.sh - {script_type}")
    summary.append(f"    {item_name}")

summary.append("")
summary.append("="*80)
summary.append("TEMPLATE STRUCTURE")
summary.append("="*80)
summary.append("")
summary.append("AUTOMATED SCRIPTS follow template_automated.sh structure:")
summary.append("  - Standard variables (SCRIPT_NAME, BACKUP_DIR, LOG_FILE, ERROR_LOG)")
summary.append("  - Enhanced logging with log_message() function")
summary.append("  - Backup functionality with backup_file() function")
summary.append("  - Check functions for current state verification")
summary.append("  - Remediation functions for applying fixes")
summary.append("  - Verification functions for post-remediation checks")
summary.append("  - main_remediation() orchestrating function")
summary.append("  - Comprehensive error handling and logging")
summary.append("")
summary.append("MANUAL SCRIPTS follow template_manual.sh structure:")
summary.append("  - Same foundational structure as automated scripts")
summary.append("  - Interactive user prompts with 3 options:")
summary.append("    1. Display detailed information")
summary.append("    2. Proceed with remediation")
summary.append("    3. Exit without changes")
summary.append("  - Require manual review and approval before execution")
summary.append("")
summary.append("="*80)
summary.append("USAGE")
summary.append("="*80)
summary.append("")
summary.append("To execute a script:")
summary.append("  1. Ensure you have root privileges")
summary.append("  2. Make the script executable: chmod +x <script_name>.sh")
summary.append("  3. Run the script: sudo ./<script_name>.sh")
summary.append("")
summary.append("Automated scripts will:")
summary.append("  - Display remediation information")
summary.append("  - Check current compliance state")
summary.append("  - Apply remediations if needed")
summary.append("  - Verify changes")
summary.append("  - Log all actions to /var/log/cis_remediation.log")
summary.append("")
summary.append("Manual scripts will:")
summary.append("  - Present options for user selection")
summary.append("  - Display detailed information when requested")
summary.append("  - Wait for user confirmation before applying changes")
summary.append("  - Provide guidance for manual verification")
summary.append("")
summary.append("="*80)
summary.append("IMPORTANT NOTES")
summary.append("="*80)
summary.append("")
summary.append("1. All scripts create backups in /tmp/cis_backup/")
summary.append("2. All actions are logged to /var/log/cis_remediation.log")
summary.append("3. Errors are tracked in /var/log/cis_error_analysis.log")
summary.append("4. Some changes may require system reboot to take effect")
summary.append("5. Review CIS Benchmark documentation before applying remediations")
summary.append("6. Test in non-production environment first")
summary.append("")
summary.append("="*80)

# Save summary
summary_text = '\n'.join(summary)
with open(f'{output_dir}/README.txt', 'w') as f:
    f.write(summary_text)

print(summary_text)

print(f"\n✓ Summary saved to {output_dir}/README.txt")
