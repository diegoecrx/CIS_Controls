
# Let me reload the data and continue
import pandas as pd
import os
import re

# Read the Excel file again
file_path = "CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx"
df = pd.read_excel(file_path)

# Check existing generated scripts
output_dir = "cis_remediation_scripts"
existing_scripts = [f for f in os.listdir(output_dir) if f.endswith('.sh')]

print(f"Already generated: {len(existing_scripts)} scripts")
print(f"Total required: {len(df)} scripts")
print(f"Remaining: {len(df) - len(existing_scripts)} scripts")

# List remaining scripts
all_script_names = set(df['script_name'].tolist())
generated_script_names = set([f.replace('.sh', '') for f in existing_scripts])
remaining_script_names = all_script_names - generated_script_names

print(f"\nRemaining scripts to generate:")
remaining_df = df[df['script_name'].isin(remaining_script_names)].sort_values('script_name')
for idx, row in remaining_df.iterrows():
    print(f"  {row['script_name']}: {row['item_name'][:65]}...")
