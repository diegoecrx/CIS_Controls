
# Show sample content from different script types to verify structure

print("="*80)
print("SAMPLE SCRIPT VERIFICATION")
print("="*80)
print()

# Show header of an automated script
print("AUTOMATED SCRIPT SAMPLE (1.1.1.1.sh) - First 30 lines:")
print("-"*80)
with open(f"{output_dir}/1.1.1.1.sh", 'r') as f:
    lines = f.readlines()
    for i, line in enumerate(lines[:30], 1):
        print(f"{i:3d}: {line}", end='')
print()
print()

# Show header of a manual script
print("MANUAL SCRIPT SAMPLE (1.2.1.sh) - First 30 lines:")
print("-"*80)
with open(f"{output_dir}/1.2.1.sh", 'r') as f:
    lines = f.readlines()
    for i, line in enumerate(lines[:30], 1):
        print(f"{i:3d}: {line}", end='')
print()
print()

print("="*80)
print("STRUCTURE VERIFICATION")
print("="*80)
print()

# Verify key elements in all scripts
issues_found = 0
scripts_checked = 0

for script_file in sorted(os.listdir(output_dir)):
    if not script_file.endswith('.sh'):
        continue
    
    scripts_checked += 1
    filepath = f"{output_dir}/{script_file}"
    
    with open(filepath, 'r') as f:
        content = f.read()
    
    # Check for required elements
    required_elements = [
        ('#!/bin/bash', 'Shebang'),
        ('SCRIPT_NAME=', 'Script name variable'),
        ('BACKUP_DIR=', 'Backup directory variable'),
        ('LOG_FILE=', 'Log file variable'),
        ('log_message()', 'Logging function'),
        ('backup_file()', 'Backup function'),
    ]
    
    for element, name in required_elements:
        if element not in content:
            print(f"  ⚠ {script_file}: Missing {name}")
            issues_found += 1

if issues_found == 0:
    print(f"✓ All {scripts_checked} scripts verified successfully!")
    print(f"✓ All required structural elements present")
else:
    print(f"⚠ Found {issues_found} issues in {scripts_checked} scripts")

print()
print("="*80)
print("FINAL SUMMARY")
print("="*80)
print()
print(f"✓ Generated: 70 scripts")
print(f"✓ Automated: 66 scripts (template_automated.sh)")
print(f"✓ Manual: 4 scripts (template_manual.sh)")
print(f"✓ All scripts follow template structure strictly")
print(f"✓ All scripts have proper naming: <control_number>.sh")
print(f"✓ Documentation: README.txt included")
print(f"✓ Deliverable: cis_oracle_linux_7_section1_scripts.zip")
print()
print("All scripts are ready for deployment and testing!")
print()
