
# Create the directory and check
import pandas as pd
import os
import re

output_dir = "cis_remediation_scripts"
os.makedirs(output_dir, exist_ok=True)

# Read the Excel file
file_path = "CIS_Oracle_Linux_7_Benchmark_v4.0.0_ARCHIVE_section1.xlsx"
df = pd.read_excel(file_path)

# Check what we have
existing_scripts = [f for f in os.listdir(output_dir) if f.endswith('.sh')]

print(f"Already generated: {len(existing_scripts)} scripts")
print(f"Total required: {len(df)} scripts")
print(f"Remaining: {len(df) - len(existing_scripts)} scripts")

# Get remaining
all_script_names = set(df['script_name'].tolist())
generated_script_names = set([f.replace('.sh', '') for f in existing_scripts])
remaining_script_names = sorted(list(all_script_names - generated_script_names))

print(f"\nRemaining {len(remaining_script_names)} scripts:")
for script_name in remaining_script_names[:20]:
    row = df[df['script_name'] == script_name].iloc[0]
    print(f"  {script_name}: {row['item_name'][:65]}...")
    
if len(remaining_script_names) > 20:
    print(f"  ... and {len(remaining_script_names) - 20} more")
