# 2.3.10.11.ps1
(& {
  $regKey = "HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters"
  $regValue = "RequireStrongKey"
  $after = 1
  $valueType = "DWord"
  $dcOnly = $false
  $msOnly = $false

  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $isDC = $role -in 4,5

  if ($dcOnly -and -not $isDC) {
    Write-Output "Control: 2.3.10.11 (L1) Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow' (MS only) (Automated)"
    Write-Output "Note: This control applies to Domain Controllers only"
    return
  }

  if ($msOnly -and $isDC) {
    Write-Output "Control: 2.3.10.11 (L1) Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow' (MS only) (Automated)"
    Write-Output "Note: This control applies to Member Servers only"
    return
  }

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    if ($valueType -eq "DWord") {
      Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force
    }
    elseif ($valueType -eq "String") {
      Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type String -Force
    }
    elseif ($valueType -eq "MultiString") {
      Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type MultiString -Force
    }

    Write-Output "Control: 2.3.10.11 (L1) Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow' (MS only) (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Windows Settings\\Security Settings\\Local Policies\\Security Options"
    Write-Output "Name: RequireStrongKey"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 2.3.10.11 (L1) Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow' (MS only) (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
