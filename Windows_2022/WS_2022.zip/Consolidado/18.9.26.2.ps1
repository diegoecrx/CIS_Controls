# 18.9.26.2.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows"
  $regValue = "ConfiguresLSASStorunasaprotectedprocess"
  $after = 1
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.9.26.2 (NG) Ensure 'Configures LSASS to run as a protected process' is set to 'Enabled: Enabled with UEFI Lock' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: ConfiguresLSASStorunasaprotectedprocess"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.9.26.2 (NG) Ensure 'Configures LSASS to run as a protected process' is set to 'Enabled: Enabled with UEFI Lock' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
