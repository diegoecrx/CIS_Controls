(& {
  $regKey = "HKLM:\System\CurrentControlSet\Control\Lsa"
  $regValue = "2_2_23"
  $after = 1
  $valueType = "DWord"
  $dcOnly = $true
  $msOnly = $true
  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $isDC = $role -in 4,5

  if ($dcOnly -and -not $isDC) {
    Write-Output "Control: 2.2.23 2.2.23 (L1) Ensure 'Deny log on as a batch job' to include 'Guests' (Automated)"
    Write-Output "Note: This control applies to Domain Controllers only"
    return
  }
  if ($msOnly -and $isDC) {
    Write-Output "Control: 2.2.23 2.2.23 (L1) Ensure 'Deny log on as a batch job' to include 'Guests' (Automated)"
    Write-Output "Note: This control applies to Member Servers only"
    return
  }

  try {
    if (-not (Test-Path $regKey)) { New-Item -Path $regKey -Force | Out-Null }
    $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
    $current = if ($null -ne $currentProperty) { $currentProperty.$regValue } else { 'N/A' }
    Write-Output "Control: 2.2.23 2.2.23 (L1) Ensure 'Deny log on as a batch job' to include 'Guests' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options"
    Write-Output "Name: $regValue"
    Write-Output "Current: $current"
    Write-Output "After: $after"
    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type $valueType -Force
  } catch {
    Write-Output "ERROR: 2.2.23 encountered issue - $($_.Exception.Message)"
  }
})
