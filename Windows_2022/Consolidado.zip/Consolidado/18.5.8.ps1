# 18.5.8.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog"
  $regValue = "MSSSafeDllSearchModeEnableSafeDLLsearchmode"
  $after = 1
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.5.8 (L1) Ensure 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: MSSSafeDllSearchModeEnableSafeDLLsearchmode"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.5.8 (L1) Ensure 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})
