# 18.7.7.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc"
  $regValue = "Ports"
  $after = 0
  $valueType = "String"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type String -Force

    Write-Output "Control: 18.7.7 (L1) Ensure 'Configure RPC over TCP port' is set to 'Enabled: 0' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: ConfigureRPCoverTCPport"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.7.7 (L1) Ensure 'Configure RPC over TCP port' is set to 'Enabled: 0' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})