# 18.5.2.ps1
(& {
  $regKey = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters"
  $regValue = "DisableIPSourceRouting"
  $after = 2
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.5.2 (L1) Ensure 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\MSS (Legacy)"
    Write-Output "Name: DisableIPSourceRouting"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.5.2 (L1) Ensure 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})