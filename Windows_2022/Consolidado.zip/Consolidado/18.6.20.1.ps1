# 18.6.20.1.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WCN\Registrars"
  $enableRegistrars = "EnableRegistrars"
  $disableInBand802DOT11Registrar = "DisableInBand802DOT11Registrar"
  $disableFlashConfigRegistrar = "DisableFlashConfigRegistrar"
  $disableUPnPRegistrar = "DisableUPnPRegistrar"
  $disableWPDRegistrar = "DisableWPDRegistrar"
  $after = 0

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentEnableRegistrars = Get-ItemProperty -Path $regKey -Name $enableRegistrars -ErrorAction SilentlyContinue
      $currentEnableRegistrarsValue = $currentEnableRegistrars.$enableRegistrars
    }
    catch {
      $currentEnableRegistrarsValue = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $enableRegistrars -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $disableInBand802DOT11Registrar -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $disableFlashConfigRegistrar -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $disableUPnPRegistrar -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $disableWPDRegistrar -Value $after -Type DWord -Force

    Write-Output "Control: 18.6.20.1 (L2) Ensure 'Configuration of wireless settings using Windows Connect Now' is set to 'Disabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: ConfigurationofwirelesssettingsusingWindowsConnectNow"
    Write-Output "Current EnableRegistrars: $currentEnableRegistrarsValue"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.6.20.1 (L2) Ensure 'Configuration of wireless settings using Windows Connect Now' is set to 'Disabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})