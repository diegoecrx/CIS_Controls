# 18.10.26.3.2.ps1
(& {
    $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Setup"
    $regValue = "MaxSize"
    $after = 32768  # Minimum required size in KB (32,768 KB = 32 MB)
    $valueType = "DWord"

    try {
        # Create registry path if it doesn't exist
        if (-not (Test-Path $regKey)) {
            New-Item -Path $regKey -Force -ErrorAction Stop | Out-Null
        }

        # Get current value
        $current = "Not Configured"
        $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
        if ($null -ne $currentProperty -and $null -ne $currentProperty.$regValue) {
            $current = $currentProperty.$regValue
        }

        # Only set if current value is less than required minimum (32,768 KB)
        if ($current -eq "Not Configured" -or $current -lt 32768) {
            Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type $valueType -Force -ErrorAction Stop
            Write-Output "Status: Policy updated to minimum required size (32,768 KB)"
        } else {
            Write-Output "Status: Already compliant (Current size: $current KB)"
        }

        Write-Output "Control: 18.10.26.3.2 (L1) Ensure 'Setup: Specify the maximum log file size (KB)' is set to 'Enabled: 32,768 or greater' (Automated)"
        Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Administrative Templates\Windows Components\Event Log Service\Setup"
        Write-Output "Registry Path: $regKey"
        Write-Output "Value Name: $regValue"
        Write-Output "Current: $current"
        Write-Output "Required: 32,768 KB or greater"
        Write-Output "Set To: $after KB (32 MB)"
        Write-Output "Note: Value represents maximum log file size in kilobytes"
    }
    catch {
        Write-Output "Control: 18.10.26.3.2 (L1) Ensure 'Setup: Specify the maximum log file size (KB)' is set to 'Enabled: 32,768 or greater' (Automated)"
        Write-Output "Error: $($_.Exception.Message)"
        exit 1
    }
})