# 2.3.11.6.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
  $regValue = "ForceLogoffWhenHourExpire"
  $after = 1
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = if ($currentProperty.$regValue -eq 1) { "enabled" } else { "disabled" }
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 2.3.11.6 (L1) Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Windows Settings\\Security Settings\\Local Policies\\Security Options"
    Write-Output "Name: ForceLogoffWhenHourExpire"
    Write-Output "Current: $current"
    Write-Output "After: enabled"
  }
  catch {
    Write-Output "Control: 2.3.11.6 (L1) Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})