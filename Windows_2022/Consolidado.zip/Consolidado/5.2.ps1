# 5.2.ps1
(& {
  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $serviceName = "Spooler"
  $after = "Disabled"
  
  if ($role -notin 4, 5) {
    # Member Server
    try {
      # Get current service state
      $service = Get-Service -Name $serviceName -ErrorAction Stop
      $currentStartType = $service.StartType
      $currentStatus = $service.Status
      
      # Stop the service if running
      if ($service.Status -eq 'Running') {
        Stop-Service -Name $serviceName -Force -ErrorAction Stop
      }
      
      # Disable the service
      Set-Service -Name $serviceName -StartupType Disabled -ErrorAction Stop
      
      Write-Output "Control: 5.2 (L2) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (MS only) (Automated)"
      Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\System Services\Print Spooler"
      Write-Output "Name: Spooler"
      Write-Output "Current: $currentStartType"
      Write-Output "After: Disabled"
    }
    catch {
      Write-Output "Control: 5.2 (L2) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (MS only) (Automated)"
      Write-Output "Error: $($_.Exception.Message)"
    }
  } else {
    Write-Output "Control: 5.2 (L2) Ensure 'Print Spooler (Spooler)' is set to 'Disabled' (MS only) (Automated)"
    Write-Output "Note: This control applies to Member Servers only"
  }
})
