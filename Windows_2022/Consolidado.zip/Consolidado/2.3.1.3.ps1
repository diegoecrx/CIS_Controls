# 2.3.1.3.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
  $regValue = "NewAdministratorName"
  $after = "NewAdminName"
  $valueType = "String"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Administrator"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type String -Force

    Write-Output "Control: 2.3.1.3 (L1) Configure 'Accounts: Rename administrator account' (Automated)"
    Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options"
    Write-Output "Name: NewAdministratorName"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 2.3.1.3 (L1) Configure 'Accounts: Rename administrator account' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})