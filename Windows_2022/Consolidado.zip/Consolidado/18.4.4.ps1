# 18.4.4.ps1
(& {
  $regKey1 = "HKLM:\SOFTWARE\Microsoft\Cryptography\OID\EncodingType 0\CertDllCreateCertificateChainEngine\Config"
  $regKey2 = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Cryptography\OID\EncodingType 0\CertDllCreateCertificateChainEngine\Config"
  $regValue = "EnableCertificatePadding"
  $after = 1
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey1)) {
      New-Item -Path $regKey1 -Force | Out-Null
    }
    if (-not (Test-Path $regKey2)) {
      New-Item -Path $regKey2 -Force | Out-Null
    }

    try {
      $currentProperty1 = Get-ItemProperty -Path $regKey1 -Name $regValue -ErrorAction SilentlyContinue
      $current1 = $currentProperty1.$regValue
    }
    catch {
      $current1 = "Not Configured"
    }

    try {
      $currentProperty2 = Get-ItemProperty -Path $regKey2 -Name $regValue -ErrorAction SilentlyContinue
      $current2 = $currentProperty2.$regValue
    }
    catch {
      $current2 = "Not Configured"
    }

    Set-ItemProperty -Path $regKey1 -Name $regValue -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey2 -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.4.4 (L1) Ensure 'Enable Certificate Padding' is set to 'Enabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\MS Security Guide"
    Write-Output "Name: EnableCertificatePadding"
    Write-Output "Current: Default=$current1, 32-bit=$current2"
    Write-Output "After: Default=$after, 32-bit=$after"
  }
  catch {
    Write-Output "Control: 18.4.4 (L1) Ensure 'Enable Certificate Padding' is set to 'Enabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})