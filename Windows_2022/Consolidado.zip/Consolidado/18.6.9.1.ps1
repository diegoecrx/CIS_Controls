# 18.6.9.1.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LLTD"
  $enableLLTDIO = "EnableLLTDIO"
  $allowLLTDIOOnPublicNet = "AllowLLTDIOOnPublicNet"
  $allowLLTDIOOndomain = "AllowLLTDIOOndomain"
  $prohibitLLTDIOOnPrivateNet = "ProhibitLLTDIOOnPrivateNet"
  $after = 0

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentEnableLLTDIO = Get-ItemProperty -Path $regKey -Name $enableLLTDIO -ErrorAction SilentlyContinue
      $currentEnableLLTDIOValue = $currentEnableLLTDIO.$enableLLTDIO
    }
    catch {
      $currentEnableLLTDIOValue = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $enableLLTDIO -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $allowLLTDIOOnPublicNet -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $allowLLTDIOOndomain -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $prohibitLLTDIOOnPrivateNet -Value $after -Type DWord -Force

    Write-Output "Control: 18.6.9.1 (L2) Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: TurnonMapperIOLLTDIOdriver"
    Write-Output "Current EnableLLTDIO: $currentEnableLLTDIOValue"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.6.9.1 (L2) Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})