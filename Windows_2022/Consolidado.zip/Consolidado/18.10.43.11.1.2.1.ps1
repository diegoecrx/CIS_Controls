# 18.10.43.11.1.2.1.ps1
(& {
    $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\ASR"
    $regValue = "26190899-1602-49e8-8b27-eb1d0a1ce869"
    $after = 1  # 1 = Block, 2 = Audit
    $valueType = "DWord"

    try {
        # Create registry path if it doesn't exist
        if (-not (Test-Path $regKey)) {
            New-Item -Path $regKey -Force -ErrorAction Stop | Out-Null
        }

        # Get current value
        $current = "Not Configured"
        $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
        if ($null -ne $currentProperty -and $null -ne $currentProperty.$regValue) {
            $current = $currentProperty.$regValue
        }

        # Only set if current value is not compliant (not 1 or 2)
        if ($current -notin @(1, 2)) {
            Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type $valueType -Force -ErrorAction Stop
            Write-Output "Status: Policy updated to 'Block' mode"
        } else {
            Write-Output "Status: Already compliant (Current mode: $current)"
        }

        Write-Output "Control: 18.10.43.11.1.2.1 (L2) Ensure 'Configure how aggressively Remote Encryption Protection blocks threats' is set to 'Enabled: Medium' or higher (Automated)"
        Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Administrative Templates\Windows Components\Microsoft Defender Antivirus\Microsoft Defender Exploit Guard\Attack Surface Reduction"
        Write-Output "Registry Path: $regKey"
        Write-Output "Value Name: $regValue"
        Write-Output "Current: $current"
        Write-Output "Required: 1 (Block) or 2 (Audit)"
        Write-Output "Set To: $after (Block)"
        Write-Output "Note: Values - 0 = Off, 1 = Block, 2 = Audit"
        Write-Output "Rule GUID: 26190899-1602-49e8-8b27-eb1d0a1ce869 (Block remote encryption)"
        Write-Output "Note: This control refers to the same ASR rule as 18.10.43.11.1.1.2"
    }
    catch {
        Write-Output "Control: 18.10.43.11.1.2.1 (L2) Ensure 'Configure how aggressively Remote Encryption Protection blocks threats' is set to 'Enabled: Medium' or higher (Automated)"
        Write-Output "Error: $($_.Exception.Message)"
        exit 1
    }
})