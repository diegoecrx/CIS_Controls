# 18.10.89.1.3.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client"
  $regValue = "AllowDigest"
  $after = 0
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.10.89.1.3 (L1) Ensure 'Disallow Digest authentication' is set to 'Enabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\Windows Components\\Windows Remote Management (WinRM)\\WinRM Client"
    Write-Output "Name: AllowDigest"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.10.89.1.3 (L1) Ensure 'Disallow Digest authentication' is set to 'Enabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})