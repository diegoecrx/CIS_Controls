# 2.2.24.ps1
(& {
  $privilegeName = "SeDenyServiceLogonRight"
  $expectedUsers = "Guests"
  
  try {
    # Configure the privilege through security policy
    $seceditOutput = [System.IO.Path]::GetTempFileName()
    secedit /export /cfg $seceditOutput /areas USER_RIGHTS | Out-Null
    
    $configContent = Get-Content $seceditOutput
    $newContent = @()
    $privilegeFound = $false
    
    foreach ($line in $configContent) {
      if ($line -match "^$privilegeName\s*=") {
        $newContent += "$privilegeName = $expectedUsers"
        $privilegeFound = $true
      } else {
        $newContent += $line
      }
    }
    
    if (-not $privilegeFound) {
      $newContent += "$privilegeName = $expectedUsers"
    }
    
    $newConfig = [System.IO.Path]::GetTempFileName()
    $newContent | Out-File $newConfig -Encoding ASCII
    
    secedit /configure /db secedit.sdb /cfg $newConfig /areas USER_RIGHTS | Out-Null
    gpupdate /force | Out-Null
    
    Remove-Item $seceditOutput -ErrorAction SilentlyContinue
    Remove-Item $newConfig -ErrorAction SilentlyContinue
    
    Write-Output "Control: 2.2.24 (L1) Ensure 'Deny log on as a service' to include 'Guests' (Automated)"
    Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\User Rights Assignment"
    Write-Output "Name: $privilegeName"
    Write-Output "Current: NULL"
    Write-Output "After: $expectedUsers"
  }
  catch {
    Write-Output "Control: 2.2.24 (L1) Ensure 'Deny log on as a service' to include 'Guests' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})