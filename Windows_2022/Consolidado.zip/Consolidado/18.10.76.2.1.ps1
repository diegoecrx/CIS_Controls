# 18.10.76.2.1.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System"
  $regValue1 = "EnableSmartScreen"
  $regValue2 = "ShellSmartScreenLevel"
  $after1 = 1
  $after2 = "Block"
  $valueType1 = "DWord"
  $valueType2 = "String"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty1 = Get-ItemProperty -Path $regKey -Name $regValue1 -ErrorAction SilentlyContinue
      $current1 = $currentProperty1.$regValue1
    }
    catch {
      $current1 = "Not Configured"
    }

    try {
      $currentProperty2 = Get-ItemProperty -Path $regKey -Name $regValue2 -ErrorAction SilentlyContinue
      $current2 = $currentProperty2.$regValue2
    }
    catch {
      $current2 = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue1 -Value $after1 -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $regValue2 -Value $after2 -Type String -Force

    Write-Output "Control: 18.10.76.2.1 (L1) Ensure 'Configure Windows Defender SmartScreen' is set to 'Enabled: Warn and prevent bypass' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\Windows Components\\File Explorer"
    Write-Output "Name: EnableSmartScreen, ShellSmartScreenLevel"
    Write-Output "Current: EnableSmartScreen=$current1, ShellSmartScreenLevel=$current2"
    Write-Output "After: EnableSmartScreen=$after1, ShellSmartScreenLevel=$after2"
  }
  catch {
    Write-Output "Control: 18.10.76.2.1 (L1) Ensure 'Configure Windows Defender SmartScreen' is set to 'Enabled: Warn and prevent bypass' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})