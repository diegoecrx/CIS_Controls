# 18.10.26.2.2.ps1
(& {
    $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security"
    $regValue = "MaxSize"
    $after = 196608  # Minimum required size in KB (196,608 KB = 192 MB)
    $valueType = "DWord"

    try {
        # Create registry path if it doesn't exist
        if (-not (Test-Path $regKey)) {
            New-Item -Path $regKey -Force -ErrorAction Stop | Out-Null
        }

        # Get current value
        $current = "Not Configured"
        $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
        if ($null -ne $currentProperty -and $null -ne $currentProperty.$regValue) {
            $current = $currentProperty.$regValue
        }

        # Only set if current value is less than required minimum (196,608 KB)
        if ($current -eq "Not Configured" -or $current -lt 196608) {
            Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type $valueType -Force -ErrorAction Stop
            Write-Output "Status: Policy updated to minimum required size (196,608 KB)"
        } else {
            Write-Output "Status: Already compliant (Current size: $current KB)"
        }

        Write-Output "Control: 18.10.26.2.2 (L1) Ensure 'Security: Specify the maximum log file size (KB)' is set to 'Enabled: 196,608 or greater' (Automated)"
        Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Administrative Templates\Windows Components\Event Log Service\Security"
        Write-Output "Registry Path: $regKey"
        Write-Output "Value Name: $regValue"
        Write-Output "Current: $current"
        Write-Output "Required: 196,608 KB or greater"
        Write-Output "Set To: $after KB (192 MB)"
        Write-Output "Note: Value represents maximum log file size in kilobytes"
    }
    catch {
        Write-Output "Control: 18.10.26.2.2 (L1) Ensure 'Security: Specify the maximum log file size (KB)' is set to 'Enabled: 196,608 or greater' (Automated)"
        Write-Output "Error: $($_.Exception.Message)"
        exit 1
    }
})