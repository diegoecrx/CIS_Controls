# 18.10.93.4.2.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
  $regValue1 = "DeferFeatureUpdates"
  $regValue2 = "DeferFeatureUpdatesPeriodInDays"
  $after1 = 1
  $after2 = 180
  $valueType1 = "DWord"
  $valueType2 = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty1 = Get-ItemProperty -Path $regKey -Name $regValue1 -ErrorAction SilentlyContinue
      $current1 = $currentProperty1.$regValue1
    }
    catch {
      $current1 = "Not Configured"
    }

    try {
      $currentProperty2 = Get-ItemProperty -Path $regKey -Name $regValue2 -ErrorAction SilentlyContinue
      $current2 = $currentProperty2.$regValue2
    }
    catch {
      $current2 = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue1 -Value $after1 -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $regValue2 -Value $after2 -Type DWord -Force

    Write-Output "Control: 18.10.93.4.2 (L1) Ensure 'Select when Preview Builds and Feature Updates are received' is set to 'Enabled: 180 or more days' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\Windows Components\\Windows Update"
    Write-Output "Name: DeferFeatureUpdates, DeferFeatureUpdatesPeriodInDays"
    Write-Output "Current: DeferFeatureUpdates=$current1, DeferFeatureUpdatesPeriodInDays=$current2"
    Write-Output "After: DeferFeatureUpdates=$after1, DeferFeatureUpdatesPeriodInDays=$after2"
  }
  catch {
    Write-Output "Control: 18.10.93.4.2 (L1) Ensure 'Select when Preview Builds and Feature Updates are received' is set to 'Enabled: 180 or more days' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})