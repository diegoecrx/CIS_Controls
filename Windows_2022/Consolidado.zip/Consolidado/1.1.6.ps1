# 1.1.6.ps1
(& {
    try {
        $role = (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).DomainRole
        $after = 1  # 1 = Enabled
        
        Write-Output "Control: 1.1.6 (L1) Ensure 'Relax minimum password length limits' is set to 'Enabled' (Automated)"
        Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Password Policy\Relax minimum password length limits"
        Write-Output "Name: RelaxMinimumPasswordLengthLimits"
        
        # Domain roles 4 and 5 are Domain Controllers
        if ($role -notin @(4, 5)) {
            $tempPath = $env:TEMP
            $beforeInf = Join-Path $tempPath 'before_policy.inf'
            $afterInf = Join-Path $tempPath 'relaxpasswordlength.inf'
            
            # Export current policy
            $exportResult = secedit /export /cfg $beforeInf /areas SECURITYPOLICY /quiet 2>&1
            if ($LASTEXITCODE -ne 0) {
                throw "Failed to export security policy: $exportResult"
            }
            
            # Read current value
            $current = 0
            if (Test-Path $beforeInf) {
                $beforeLine = Select-String -Path $beforeInf -Pattern '^RelaxMinimumPasswordLengthLimits\s*=\s*(\d+)' | Select-Object -First 1
                if ($beforeLine) {
                    $current = [int]$beforeLine.Matches[0].Groups[1].Value
                }
            }
            
            Write-Output "Current: $current"
            Write-Output "After: $after"
            
            # Only apply changes if current value is different
            if ($current -ne $after) {
                # Create new policy file
                Set-Content -Path $afterInf -Encoding ascii -Value @(
                    '[Unicode]'
                    'Unicode=yes'
                    '[System Access]'
                    "RelaxMinimumPasswordLengthLimits = $after"
                    '[Version]'
                    'signature="`$CHICAGO`$"'
                    'Revision=1'
                ) -ErrorAction Stop
                
                # Apply new policy
                $configureResult = secedit /configure /db "$tempPath\secedit.sdb" /cfg $afterInf /areas SECURITYPOLICY /quiet 2>&1
                if ($LASTEXITCODE -ne 0) {
                    throw "Failed to configure security policy: $configureResult"
                }
                
                Write-Output "Status: Policy updated successfully"
            } else {
                Write-Output "Status: Already compliant"
            }
            
            # Cleanup temporary files
            Remove-Item $beforeInf, $afterInf -Force -ErrorAction SilentlyContinue
            Remove-Item "$tempPath\secedit.sdb" -Force -ErrorAction SilentlyContinue
            Remove-Item "$tempPath\secedit.sdb.jfm" -Force -ErrorAction SilentlyContinue
            
        } else {
            Write-Output "Note: This setting applies to Member Servers only, not Domain Controllers"
            Write-Output "Current: N/A (Domain Controller)"
            Write-Output "After: N/A (Domain Controller)"
        }
    }
    catch {
        Write-Error "Failed to apply control 1.1.6: $($_.Exception.Message)"
        exit 1
    }
})