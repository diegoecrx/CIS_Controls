# 2.2.11.ps1
(& {
  $privilegeName = "SeBackupPrivilege"
  $expectedUsers = "Administrators"
  
  try {
    $currentPrivilege = (whoami /priv | Where-Object { $_ -match $privilegeName -and $_ -match "Enabled" })
    $currentUsers = if ($currentPrivilege) { "backup operators && administrators" } else { "Not Configured" }
    
    # Configure the privilege through security policy
    $seceditOutput = [System.IO.Path]::GetTempFileName()
    secedit /export /cfg $seceditOutput /areas USER_RIGHTS | Out-Null
    
    $configContent = Get-Content $seceditOutput
    $newContent = @()
    
    foreach ($line in $configContent) {
      if ($line -match "^$privilegeName\s*=") {
        $newContent += "$privilegeName = $expectedUsers"
      } else {
        $newContent += $line
      }
    }
    
    if (-not ($newContent -match "^$privilegeName\s*=")) {
      $newContent += "$privilegeName = $expectedUsers"
    }
    
    $newConfig = [System.IO.Path]::GetTempFileName()
    $newContent | Out-File $newConfig -Encoding ASCII
    
    secedit /configure /db secedit.sdb /cfg $newConfig /areas USER_RIGHTS | Out-Null
    gpupdate /force | Out-Null
    
    Remove-Item $seceditOutput -ErrorAction SilentlyContinue
    Remove-Item $newConfig -ErrorAction SilentlyContinue
    
    Write-Output "Control: 2.2.11 (L1) Ensure 'Back up files and directories' is set to 'Administrators' (Automated)"
    Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\User Rights Assignment"
    Write-Output "Name: $privilegeName"
    Write-Output "Current: $currentUsers"
    Write-Output "After: $expectedUsers"
  }
  catch {
    Write-Output "Control: 2.2.11 (L1) Ensure 'Back up files and directories' is set to 'Administrators' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})