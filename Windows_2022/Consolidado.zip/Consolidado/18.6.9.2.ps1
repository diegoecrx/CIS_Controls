# 18.6.9.2.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LLTD"
  $enableRspndr = "EnableRspndr"
  $allowRspndrOnPublicNet = "AllowRspndrOnPublicNet"
  $allowRspndrOndomain = "AllowRspndrOndomain"
  $prohibitRspndrOnPrivateNet = "ProhibitRspndrOnPrivateNet"
  $after = 0

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentEnableRspndr = Get-ItemProperty -Path $regKey -Name $enableRspndr -ErrorAction SilentlyContinue
      $currentEnableRspndrValue = $currentEnableRspndr.$enableRspndr
    }
    catch {
      $currentEnableRspndrValue = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $enableRspndr -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $allowRspndrOnPublicNet -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $allowRspndrOndomain -Value $after -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $prohibitRspndrOnPrivateNet -Value $after -Type DWord -Force

    Write-Output "Control: 18.6.9.2 (L2) Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: TurnonResponderRSPNDRdriver"
    Write-Output "Current EnableRspndr: $currentEnableRspndrValue"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.6.9.2 (L2) Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})