# 18.5.12.ps1
(& {
  $regKey = "HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security"
  $regValue = "WarningLevel"
  $after = 90
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.5.12 (L1) Ensure 'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning' is set to 'Enabled: 90% or less' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\MSS (Legacy)"
    Write-Output "Name: WarningLevel"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.5.12 (L1) Ensure 'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning' is set to 'Enabled: 90% or less' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})