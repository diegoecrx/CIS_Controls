# 18.6.14.1.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths"
  $netlogonValue = "\\*\NETLOGON"
  $sysvolValue = "\\*\SYSVOL"
  $after = "RequireMutualAuthentication=1,RequireIntegrity=1,RequirePrivacy=1"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentNetlogon = Get-ItemProperty -Path $regKey -Name $netlogonValue -ErrorAction SilentlyContinue
      $currentNetlogonValue = $currentNetlogon.$netlogonValue
    }
    catch {
      $currentNetlogonValue = "Not Configured"
    }

    try {
      $currentSysvol = Get-ItemProperty -Path $regKey -Name $sysvolValue -ErrorAction SilentlyContinue
      $currentSysvolValue = $currentSysvol.$sysvolValue
    }
    catch {
      $currentSysvolValue = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $netlogonValue -Value $after -Force
    Set-ItemProperty -Path $regKey -Name $sysvolValue -Value $after -Force

    Write-Output "Control: 18.6.14.1 (L1) Ensure 'Hardened UNC Paths' is set to 'Enabled, with 'Require Mutual Authentication', 'Require Integrity', and 'Require Privacy' set for all NETLOGON and SYSVOL shares' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: HardenedUNCPaths"
    Write-Output "Current NETLOGON: $currentNetlogonValue"
    Write-Output "Current SYSVOL: $currentSysvolValue"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.6.14.1 (L1) Ensure 'Hardened UNC Paths' is set to 'Enabled, with 'Require Mutual Authentication', 'Require Integrity', and 'Require Privacy' set for all NETLOGON and SYSVOL shares' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})