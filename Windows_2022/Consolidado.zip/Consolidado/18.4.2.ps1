# 18.4.2.ps1
(& {
  $regKey = "HKLM:\SYSTEM\CurrentControlSet\Services\mrxsmb10"
  $regValue = "Start"
  $after = 4
  $valueType = "DWord"

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
      $current = $currentProperty.$regValue
    }
    catch {
      $current = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type DWord -Force

    Write-Output "Control: 18.4.2 (L1) Ensure 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates\\MS Security Guide"
    Write-Output "Name: Start"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  }
  catch {
    Write-Output "Control: 18.4.2 (L1) Ensure 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})