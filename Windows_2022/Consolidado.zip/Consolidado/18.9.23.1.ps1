# 18.9.23.1.ps1
(& {
  $regKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters"
  $devicePKInitBehavior = "DevicePKInitBehavior"
  $devicePKInitEnabled = "DevicePKInitEnabled"
  $afterBehavior = 0
  $afterEnabled = 1

  try {
    if (-not (Test-Path $regKey)) {
      New-Item -Path $regKey -Force | Out-Null
    }

    try {
      $currentBehavior = Get-ItemProperty -Path $regKey -Name $devicePKInitBehavior -ErrorAction SilentlyContinue
      $currentBehaviorValue = $currentBehavior.$devicePKInitBehavior
    }
    catch {
      $currentBehaviorValue = "Not Configured"
    }

    Set-ItemProperty -Path $regKey -Name $devicePKInitBehavior -Value $afterBehavior -Type DWord -Force
    Set-ItemProperty -Path $regKey -Name $devicePKInitEnabled -Value $afterEnabled -Type DWord -Force

    Write-Output "Control: 18.9.23.1 (L2) Ensure 'Support device authentication using certificate' is set to 'Enabled: Automatic' (Automated)"
    Write-Output "Path:  Computer Configuration\\Policies\\Administrative Templates"
    Write-Output "Name: Supportdeviceauthenticationusingcertificate"
    Write-Output "Current DevicePKInitBehavior: $currentBehaviorValue"
    Write-Output "After DevicePKInitBehavior: $afterBehavior"
    Write-Output "After DevicePKInitEnabled: $afterEnabled"
  }
  catch {
    Write-Output "Control: 18.9.23.1 (L2) Ensure 'Support device authentication using certificate' is set to 'Enabled: Automatic' (Automated)"
    Write-Output "Error: $($_.Exception.Message)"
  }
})