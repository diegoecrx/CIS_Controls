# 1.2.2.ps1
(& {
  $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
  $after = 5
  
  if ($role -in 4, 5) {
    Import-Module ActiveDirectory -ErrorAction Stop
    $currentPolicy = Get-ADDefaultDomainPasswordPolicy
    $current = $currentPolicy.LockoutThreshold
    Set-ADDefaultDomainPasswordPolicy -Identity $currentPolicy.DistinguishedName -LockoutThreshold $after
    
    Write-Output "Control: 1.2.2 (L1) Ensure 'Account lockout threshold' is set to '5 or fewer invalid logon attempt(s), but not 0' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Account lockout threshold"
    Write-Output "Name: LockoutBadCount"
    Write-Output "Current: $current"
    Write-Output "After: $after"
  } else {
    $tempPath = $env:TEMP
    $beforeInf = Join-Path $tempPath 'before_policy.inf'
    $afterInf = Join-Path $tempPath 'lockoutthreshold.inf'
    
    secedit /export /cfg $beforeInf /areas SECURITYPOLICY /quiet | Out-Null
    $beforeLine = Select-String -Path $beforeInf -Pattern '^LockoutBadCount\s*=\s*(\d+)' | Select-Object -First 1
    $current = if ($beforeLine) { [int]$beforeLine.Matches[0].Groups[1].Value } else { 0 }
    
    Set-Content -Path $afterInf -Encoding ascii -Value @(
      '[Unicode]',
      'Unicode=yes',
      '[System Access]',
      "LockoutBadCount = $after",
      '[Version]',
      'signature="$CHICAGO$"',
      'Revision=1'
    )
    
    secedit /configure /db "$tempPath\secedit.sdb" /cfg $afterInf /areas SECURITYPOLICY /quiet | Out-Null
    
    Write-Output "Control: 1.2.2 (L1) Ensure 'Account lockout threshold' is set to '5 or fewer invalid logon attempt(s), but not 0' (Automated)"
    Write-Output "Path:  Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policy\Account lockout threshold"
    Write-Output "Name: LockoutBadCount"
    Write-Output "Current: $current"
    Write-Output "After: $after"
    
    Remove-Item $beforeInf, $afterInf -Force -ErrorAction SilentlyContinue
  }
})
