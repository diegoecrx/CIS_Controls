# 18.10.43.10.5.ps1
(& {
    $regKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection"
    $regValue = "DisableScriptScanning"
    $after = 0
    $valueType = "DWord"

    try {
        # Create registry path if it doesn't exist
        if (-not (Test-Path $regKey)) {
            New-Item -Path $regKey -Force -ErrorAction Stop | Out-Null
        }

        # Get current value
        $current = "Not Configured"
        $currentProperty = Get-ItemProperty -Path $regKey -Name $regValue -ErrorAction SilentlyContinue
        if ($null -ne $currentProperty -and $null -ne $currentProperty.$regValue) {
            $current = $currentProperty.$regValue
        }

        # Set the registry value
        Set-ItemProperty -Path $regKey -Name $regValue -Value $after -Type $valueType -Force -ErrorAction Stop

        Write-Output "Control: 18.10.43.10.5 (L1) Ensure 'Turn on script scanning' is set to 'Enabled' (Automated)"
        Write-Output "Path: Computer Configuration\Policies\Windows Settings\Security Settings\Administrative Templates\Windows Components\Microsoft Defender Antivirus\Real-time Protection"
        Write-Output "Registry Path: $regKey"
        Write-Output "Value Name: $regValue"
        Write-Output "Current: $current"
        Write-Output "After: $after"
        Write-Output "Status: Successfully configured"
        Write-Output "Note: 0 = Enabled (Script scanning enabled), 1 = Disabled (Script scanning disabled)"
    }
    catch {
        Write-Output "Control: 18.10.43.10.5 (L1) Ensure 'Turn on script scanning' is set to 'Enabled' (Automated)"
        Write-Output "Error: $($_.Exception.Message)"
        exit 1
    }
})