#!/usr/bin/env bash

# Script: 4.2.4.sh
# Item: 4.2.4 Ensure sshd access is configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.4.sh"
ITEM_NAME="4.2.4 Ensure sshd access is configured (Automated)"
DESCRIPTION="This remediation ensures SSH access is properly configured with AllowUsers, AllowGroups, DenyUsers, or DenyGroups directives."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH daemon configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"
BACKUP_CONFIG="/etc/ssh/sshd_config.backup.$(date +%Y%m%d_%H%M%S)"

# Check if sshd_config exists
if [ ! -f "$SSHD_CONFIG" ]; then
    echo "ERROR: SSH daemon configuration file $SSHD_CONFIG not found"
    exit 1
fi

# Create backup of original configuration
echo "Creating backup of SSH configuration: $BACKUP_CONFIG"
cp "$SSHD_CONFIG" "$BACKUP_CONFIG"
echo "Backup created successfully"
echo ""

# Function to remove existing access control directives
remove_existing_access_controls() {
    # Remove existing directives but preserve in comments for reference
    sed -i.bak -E 's/^\s*(AllowUsers|AllowGroups|DenyUsers|DenyGroups)\s+/# & # Removed by 4.2.4.sh /' "$SSHD_CONFIG"
    rm -f "${SSHD_CONFIG}.bak"
}

# Function to check if access control is configured
check_access_control() {
    local has_control=false
    
    # Check for any active access control directives (not commented out)
    if grep -E '^\s*(AllowUsers|AllowGroups|DenyUsers|DenyGroups)\s+' "$SSHD_CONFIG" > /dev/null 2>&1; then
        has_control=true
    fi
    
    echo "$has_control"
}

# Function to display current access configuration
display_current_config() {
    echo "Current SSH access configuration:"
    echo "---------------------------------"
    
    local access_directives=$(grep -E '^\s*(AllowUsers|AllowGroups|DenyUsers|DenyGroups)\s+' "$SSHD_CONFIG" 2>/dev/null || true)
    
    if [ -z "$access_directives" ]; then
        echo "No active access control directives found"
    else
        echo "$access_directives"
    fi
    
    # Show commented directives for reference
    local commented_directives=$(grep -E '^\s*#\s*(AllowUsers|AllowGroups|DenyUsers|DenyGroups)\s+' "$SSHD_CONFIG" 2>/dev/null || true)
    if [ -n "$commented_directives" ]; then
        echo ""
        echo "Commented directives (for reference):"
        echo "$commented_directives"
    fi
    echo ""
}

# Function to validate SSH configuration
validate_sshd_config() {
    if sshd -t -f "$SSHD_CONFIG"; then
        return 0
    else
        return 1
    fi
}

# Display current configuration
display_current_config

# Check if access control is already configured
if [ "$(check_access_control)" = "true" ]; then
    echo "Access control is already configured in $SSHD_CONFIG"
    echo ""
    echo "Current configuration appears to be compliant."
else
    echo "WARNING: No active access control directives found in $SSHD_CONFIG"
    echo ""
    
    # Interactive configuration
    echo "You need to configure SSH access control using one of the following options:"
    echo "1. AllowUsers - Specify allowed users (recommended: specify specific users)"
    echo "2. AllowGroups - Specify allowed groups" 
    echo "3. DenyUsers - Specify denied users"
    echo "4. DenyGroups - Specify denied groups"
    echo "5. Skip manual configuration"
    echo ""
    
    read -p "Choose option (1-5): " choice
    
    case $choice in
        1)
            read -p "Enter allowed users (space-separated, e.g., master root): " users
            if [ -n "$users" ]; then
                echo "Adding: AllowUsers $users"
                # Remove any existing access controls first
                remove_existing_access_controls
                # Add new directive at the end of the file
                echo "" >> "$SSHD_CONFIG"
                echo "# SSH access control added by 4.2.4.sh" >> "$SSHD_CONFIG"
                echo "AllowUsers $users" >> "$SSHD_CONFIG"
            else
                echo "No users specified. Skipping configuration."
            fi
            ;;
        2)
            read -p "Enter allowed groups (space-separated): " groups
            if [ -n "$groups" ]; then
                echo "Adding: AllowGroups $groups"
                remove_existing_access_controls
                echo "" >> "$SSHD_CONFIG"
                echo "# SSH access control added by 4.2.4.sh" >> "$SSHD_CONFIG"
                echo "AllowGroups $groups" >> "$SSHD_CONFIG"
            else
                echo "No groups specified. Skipping configuration."
            fi
            ;;
        3)
            read -p "Enter denied users (space-separated): " users
            if [ -n "$users" ]; then
                echo "Adding: DenyUsers $users"
                remove_existing_access_controls
                echo "" >> "$SSHD_CONFIG"
                echo "# SSH access control added by 4.2.4.sh" >> "$SSHD_CONFIG"
                echo "DenyUsers $users" >> "$SSHD_CONFIG"
            else
                echo "No users specified. Skipping configuration."
            fi
            ;;
        4)
            read -p "Enter denied groups (space-separated): " groups
            if [ -n "$groups" ]; then
                echo "Adding: DenyGroups $groups"
                remove_existing_access_controls
                echo "" >> "$SSHD_CONFIG"
                echo "# SSH access control added by 4.2.4.sh" >> "$SSHD_CONFIG"
                echo "DenyGroups $groups" >> "$SSHD_CONFIG"
            else
                echo "No groups specified. Skipping configuration."
            fi
            ;;
        *)
            echo "Manual configuration skipped."
            echo "You must manually edit $SSHD_CONFIG and add one of:"
            echo "  AllowUsers <userlist>"
            echo "  AllowGroups <grouplist>"
            echo "  DenyUsers <userlist>" 
            echo "  DenyGroups <grouplist>"
            echo ""
            echo "Then run: systemctl reload-or-try-restart sshd.service"
            ;;
    esac
fi

echo ""

# Validate configuration before reloading
if [ -n "$choice" ] && [ "$choice" -ge 1 ] && [ "$choice" -le 4 ]; then
    echo "Validating SSH configuration syntax..."
    if validate_sshd_config; then
        echo "SUCCESS: SSH configuration syntax is valid"
    else
        echo "ERROR: SSH configuration syntax is invalid"
        echo "Restoring original configuration from backup..."
        cp "$BACKUP_CONFIG" "$SSHD_CONFIG"
        echo "Please check the SSH configuration manually"
        exit 1
    fi
    echo ""
fi

# Reload SSH service if configuration was modified
if [ -n "$choice" ] && [ "$choice" -ge 1 ] && [ "$choice" -le 4 ]; then
    echo "Configuration has been modified. Reloading SSH service..."
    
    # Display new configuration
    echo ""
    echo "New SSH access configuration:"
    echo "-----------------------------"
    grep -E '^\s*(AllowUsers|AllowGroups|DenyUsers|DenyGroups)\s+' "$SSHD_CONFIG" || echo "No active access control directives found"
    echo ""
    
    # Reload SSH service
    if systemctl is-active sshd.service > /dev/null 2>&1; then
        echo "Reloading SSH service..."
        if systemctl reload-or-try-restart sshd.service; then
            echo "SUCCESS: SSH service reloaded successfully"
        else
            echo "ERROR: Failed to reload SSH service"
            echo "Please check the service status and configuration manually:"
            echo "systemctl status sshd.service"
            echo "journalctl -u sshd.service"
            echo ""
            echo "Original configuration restored from backup."
            cp "$BACKUP_CONFIG" "$SSHD_CONFIG"
            exit 1
        fi
    else
        echo "WARNING: SSH service is not active. Configuration saved but service not reloaded."
    fi
else
    echo "No changes made to SSH configuration."
fi

echo ""

# Final verification
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="
echo ""

echo "Current SSH access control configuration:"
echo "----------------------------------------"
access_config=$(grep -E '^\s*(AllowUsers|AllowGroups|DenyUsers|DenyGroups)\s+' "$SSHD_CONFIG" 2>/dev/null || true)

if [ -n "$access_config" ]; then
    echo "PASS: Access control is configured:"
    echo "$access_config"
    
    # Validate final configuration
    echo ""
    echo "Validating final configuration..."
    if validate_sshd_config; then
        echo "PASS: Final SSH configuration syntax is valid"
    else
        echo "FAIL: Final SSH configuration syntax is invalid"
        echo "Restoring original configuration..."
        cp "$BACKUP_CONFIG" "$SSHD_CONFIG"
        exit 1
    fi
else
    echo "FAIL: No access control directives found"
    echo ""
    echo "Manual remediation required:"
    echo "Edit $SSHD_CONFIG and add one of:"
    echo "  AllowUsers <userlist>"
    echo "  AllowGroups <grouplist>"
    echo "  DenyUsers <userlist>" 
    echo "  DenyGroups <grouplist>"
    echo ""
    echo "Then run: systemctl reload-or-try-restart sshd.service"
    exit 1
fi

echo ""
echo "SSH service status:"
echo "-------------------"
if systemctl is-active sshd.service > /dev/null 2>&1; then
    echo "PASS: SSH service is active"
    systemctl status sshd.service --no-pager -l | head -10
else
    echo "WARNING: SSH service is not active"
fi

echo ""
echo "Configuration file proof:"
echo "-------------------------"
ls -la "$SSHD_CONFIG"
echo "Last modified configuration section:"
tail -10 "$SSHD_CONFIG" | grep -A 5 -B 5 -E '^(Allow|Deny)' || tail -10 "$SSHD_CONFIG"

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="