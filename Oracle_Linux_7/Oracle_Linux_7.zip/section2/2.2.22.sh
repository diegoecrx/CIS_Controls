#!/usr/bin/env bash

# Script: 2.2.22.sh
# Item: 2.2.22 Ensure only approved services are listening on a network interface (Manual)
# Description: "Run the following commands to stop the service and remove the package containing
# the service:
# # systemctl stop <service_name>.socket <service_name>.service
# # yum remove <package_name>
# -OR- If required packages have a dependency:
# Run the following commands to stop and mask the service and socket:
# # systemctl stop <service_name>.socket <service_name>.service
# # systemctl mask <service_name>.socket <service_name>.service
# Note: replace <service_name> with the appropriate service name."
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="2.2.22.sh"
ITEM_NAME="2.2.22 Ensure only approved services are listening on a network interface (Manual)"
DESCRIPTION="Ensure only approved services are listening on network interfaces according to site policy."
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current status of network services and listeners..."
    echo ""

    # Display current network listening services
    echo "Current network listening services:"
    echo "==================================="
    
    # Get all listening services
    echo "All network listeners:"
    echo "----------------------"
    if command -v ss >/dev/null 2>&1; then
        ss -tulpn | head -15
    elif command -v netstat >/dev/null 2>&1; then
        netstat -tulpn | head -15
    else
        echo "Network socket tools not available"
    fi
    
    echo ""
    
    # Get services listening on specific interfaces
    echo "Services listening on all interfaces (0.0.0.0 or ::):"
    echo "-----------------------------------------------------"
    if command -v ss >/dev/null 2>&1; then
        ss -tulpn | grep -E '0\.0\.0\.0|\:\:' | head -10
    elif command -v netstat >/dev/null 2>&1; then
        netstat -tulpn | grep -E '0\.0\.0\.0|\:\:' | head -10
    fi
    
    echo ""
    
    # Get systemd services with sockets
    echo "Systemd socket-activated services:"
    echo "----------------------------------"
    systemctl list-unit-files --type=socket | grep enabled | head -10
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    identify_network_services()
    {
        echo " - Identifying network services and their packages..."
        
        # Get listening services with process information
        if command -v ss >/dev/null 2>&1; then
            listening_services=$(ss -tulpn | awk '/LISTEN/ {print $NF}' | cut -d'"' -f2 | sort -u | grep -v "^$" || true)
        else
            listening_services=$(netstat -tulpn 2>/dev/null | awk '/LISTEN/ {print $7}' | cut -d'/' -f2 | sort -u | grep -v "^$" || true)
        fi
        
        if [ -n "$listening_services" ]; then
            echo " - Found the following network services:"
            for service in $listening_services; do
                echo "   - $service"
                
                # Try to find package information
                if command -v dpkg >/dev/null 2>&1; then
                    package=$(dpkg -S "/proc/$(pgrep -o "$service")/exe" 2>/dev/null | cut -d':' -f1 || true)
                    if [ -n "$package" ]; then
                        echo "     Package: $package"
                    fi
                elif command -v rpm >/dev/null 2>&1; then
                    package=$(rpm -qf "/proc/$(pgrep -o "$service")/exe" 2>/dev/null || true)
                    if [ -n "$package" ]; then
                        echo "     Package: $package"
                    fi
                fi
                
                # Check if service is managed by systemd
                if systemctl is-active "$service" >/dev/null 2>&1; then
                    echo "     Systemd: Active"
                fi
            done
        else
            echo " - No network services identified"
        fi
    }

    check_unapproved_services()
    {
        echo " - Checking for common unapproved services..."
        
        # Common services that should typically not be listening on networks
        common_unapproved=("telnet" "rsh" "rlogin" "rexec" "tftp" "ypbind" "chargen" "echo" "discard" "daytime")
        
        for service in "${common_unapproved[@]}"; do
            if ss -tulpn | grep -q "$service" || netstat -tulpn 2>/dev/null | grep -q "$service"; then
                echo " - WARNING: Unapproved service '$service' found listening"
            fi
        done
        
        # Check for services on non-standard ports
        echo " - Checking for services on non-standard ports..."
        standard_ports=("22" "80" "443" "53" "25" "587" "993" "995" "21" "110" "143")
        if command -v ss >/dev/null 2>&1; then
            non_standard=$(ss -tulpn | awk '/LISTEN/ {print $5}' | awk -F':' '{print $NF}' | sort -u | grep -vE "$(IFS=\|; echo "${standard_ports[*]}")" || true)
            if [ -n "$non_standard" ]; then
                echo " - Services listening on non-standard ports: $non_standard"
            fi
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing remediation guidance for identified services..."
        
        # This function provides guidance rather than taking automatic action
        # since service approval is organization-specific
        
        echo ""
        echo "REMEDIATION GUIDANCE:"
        echo "====================="
        echo ""
        echo "For each unapproved service identified above:"
        echo ""
        echo "OPTION 1 - Remove package (if not required):"
        echo "  systemctl stop <service_name>.socket <service_name>.service"
        echo "  yum remove <package_name>"
        echo "  -OR-"
        echo "  apt-get remove <package_name>"
        echo ""
        echo "OPTION 2 - Mask service (if package has dependencies):"
        echo "  systemctl stop <service_name>.socket <service_name>.service"
        echo "  systemctl mask <service_name>.socket <service_name>.service"
        echo ""
        echo "OPTION 3 - Disable service (if needed occasionally):"
        echo "  systemctl stop <service_name>.socket <service_name>.service"
        echo "  systemctl disable <service_name>.socket <service_name>.service"
        echo ""
        echo "Replace <service_name> with the actual service name from above."
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Identifying network services..."
    identify_network_services
    remediation_applied=true
    
    echo ""
    echo "Checking for unapproved services..."
    check_unapproved_services
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No network services detected - no remediation required"
    fi

    echo ""
    echo "Remediation of network services complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify current network listeners
    echo ""
    echo "1. VERIFYING CURRENT NETWORK LISTENERS:"
    echo "---------------------------------------"
    if command -v ss >/dev/null 2>&1; then
        echo "All network listeners (ss -tulpn):"
        ss -tulpn
        listener_count=$(ss -tulpn | grep -c "LISTEN" || true)
        echo ""
        echo "Total listeners: $listener_count"
    else
        echo "Network socket tools not available for detailed verification"
    fi
    
    # PROOF 2: Verify services listening on all interfaces
    echo ""
    echo "2. VERIFYING SERVICES LISTENING ON ALL INTERFACES:"
    echo "--------------------------------------------------"
    if command -v ss >/dev/null 2>&1; then
        all_interface_listeners=$(ss -tulpn | grep -E '0\.0\.0\.0|\:\:' || true)
        if [ -n "$all_interface_listeners" ]; then
            echo "Services listening on all interfaces:"
            echo "$all_interface_listeners"
            all_if_count=$(echo "$all_interface_listeners" | grep -c "LISTEN" || true)
            echo ""
            echo "Services on all interfaces: $all_if_count"
        else
            echo "PASS: No services listening on all interfaces"
        fi
    fi
    
    # PROOF 3: Verify common unapproved services are not running
    echo ""
    echo "3. VERIFYING COMMON UNAPPROVED SERVICES:"
    echo "----------------------------------------"
    common_unapproved=("telnet" "rsh" "rlogin" "rexec" "tftp" "ypbind")
    unapproved_found=false
    
    for service in "${common_unapproved[@]}"; do
        if pgrep "$service" >/dev/null 2>&1; then
            echo "FAIL: Unapproved service '$service' is running"
            echo "PROOF (process info):"
            pgrep -a "$service" | head -3
            unapproved_found=true
            final_status_pass=false
        fi
    done
    
    if [ "$unapproved_found" = false ]; then
        echo "PASS: No common unapproved services found running"
    fi
    
    # PROOF 4: Verify systemd socket services
    echo ""
    echo "4. VERIFYING SYSTEMD SOCKET SERVICES:"
    echo "-------------------------------------"
    socket_services=$(systemctl list-unit-files --type=socket | grep enabled | head -10)
    if [ -n "$socket_services" ]; then
        echo "Enabled socket services:"
        echo "$socket_services"
        echo ""
        echo "PROOF (detailed socket status):"
        for socket in $(systemctl list-unit-files --type=socket | grep enabled | awk '{print $1}' | head -5); do
            echo "Service: $socket"
            systemctl is-active "$socket" 2>/dev/null || echo "Not active"
        done
    else
        echo "PASS: No enabled socket services found"
    fi
    
    # PROOF 5: Manual verification steps reminder
    echo ""
    echo "5. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review all network listeners against approved services list"
    echo "• Verify each service has legitimate business purpose"
    echo "• Check service configurations for security settings"
    echo "• Validate firewall rules restrict access appropriately"
    echo "• Ensure services use encrypted protocols where possible"
    echo ""
    echo "MANUAL REMEDIATION COMMANDS:"
    echo "============================"
    echo ""
    echo "To STOP and REMOVE a service package:"
    echo "  systemctl stop <service>.socket <service>.service"
    echo "  yum remove <package>"
    echo "  -OR-"
    echo "  apt-get remove <package>"
    echo ""
    echo "To STOP and MASK a service (if dependencies exist):"
    echo "  systemctl stop <service>.socket <service>.service"
    echo "  systemctl mask <service>.socket <service>.service"
    echo ""
    echo "To DISABLE a service (keep installed but not auto-start):"
    echo "  systemctl stop <service>.socket <service>.service"
    echo "  systemctl disable <service>.socket <service>.service"
    echo ""
    echo "NETWORK ANALYSIS TOOLS:"
    echo "  ss -tulpn                    # List all listeners"
    echo "  netstat -tulpn              # Alternative listener list"
    echo "  lsof -i                      # List open network files"
    echo "  systemctl list-units --type=service  # List all services"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Network service verification completed"
        echo "NOTE: Manual review required to approve all listening services"
    else
        echo ""
        echo "WARNING: Unapproved services detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="