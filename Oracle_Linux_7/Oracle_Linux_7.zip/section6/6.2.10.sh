#!/usr/bin/env bash
# Script: 6.2.10.sh
# Item: 6.2.10 Ensure local interactive user home directories are configured (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.10.sh"
ITEM_NAME="6.2.10 Ensure local interactive user home directories are configured (Automated)"
DESCRIPTION="This remediation ensures local interactive user home directories are properly configured with correct ownership and permissions."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking local interactive user home directories configuration..."
    
    # Get valid shells
    l_valid_shells="^($( awk -F\/ '$NF != "nologin" {print}' /etc/shells | sed -rn '/^\//{s,/,\\/,g;p}' | paste -s -d '|' - ))$"
    
    # Populate array with users and user home location
    unset a_uarr && a_uarr=()
    while read -r l_epu l_eph; do
        a_uarr+=("$l_epu $l_eph")
    done <<< "$(awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " " $(NF-1) }' /etc/passwd)"
    
    issues_found=false
    l_mask='0027'
    
    echo " - Found ${#a_uarr[@]} local interactive users"
    
    for user_home in "${a_uarr[@]}"; do
        read -r l_user l_home <<< "$user_home"
        
        if [ -d "$l_home" ]; then
            # Check ownership and permissions
            while read -r l_own l_mode; do
                # Check ownership
                if [ "$l_user" != "$l_own" ]; then
                    echo "FAIL: User $l_user home directory $l_home is owned by $l_own"
                    issues_found=true
                fi
                
                # Check permissions
                if [ $(( $l_mode & $l_mask )) -gt 0 ]; then
                    l_max="$( printf '%o' $(( 0777 & ~$l_mask)) )"
                    echo "FAIL: User $l_user home directory $l_home has excessive permissions ($l_mode)"
                    issues_found=true
                fi
            done <<< "$(stat -Lc '%U %#a' "$l_home")"
        else
            echo "FAIL: User $l_user home directory $l_home does not exist"
            issues_found=true
        fi
    done
    
    if [ "$issues_found" = true ]; then
        echo "PROOF: Home directory ownership and/or permission issues found"
        return 1
    fi
    
    echo "PASS: Local interactive user home directories properly configured"
    echo "PROOF: All home directories exist with correct ownership and permissions"
    return 0
}
# Function to fix
fix_user_home_directories() {
    echo "Applying fix..."
    
    l_output2=""
    l_valid_shells="^($( awk -F\/ '$NF != "nologin" {print}' /etc/shells | sed -rn '/^\//{s,/,\\/,g;p}' | paste -s -d '|' - ))$"
    
    # Populate array with users and user home location
    unset a_uarr && a_uarr=()
    while read -r l_epu l_eph; do
        a_uarr+=("$l_epu $l_eph")
    done <<< "$(awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " " $(NF-1) }' /etc/passwd)"
    
    l_asize="${#a_uarr[@]}"
    [ "$l_asize" -gt "10000" ] && echo -e "\n ** INFO **\n - \"$l_asize\" Local interactive users found on the system\n - This may be a long running process\n"
    
    while read -r l_user l_home; do
        if [ -d "$l_home" ]; then
            l_mask='0027'
            l_max="$( printf '%o' $(( 0777 & ~$l_mask)) )"
            
            while read -r l_own l_mode; do
                # Fix ownership
                if [ "$l_user" != "$l_own" ]; then
                    l_output2="$l_output2\n - User: \"$l_user\" Home \"$l_home\" is owned by: \"$l_own\"\n - changing ownership to: \"$l_user\"\n"
                    chown "$l_user" "$l_home"
                fi
                
                # Fix permissions
                if [ $(( $l_mode & $l_mask )) -gt 0 ]; then
                    l_output2="$l_output2\n - User: \"$l_user\" Home \"$l_home\" is mode: \"$l_mode\" should be mode: \"$l_max\" or more restrictive\n - removing excess permissions\n"
                    chmod g-w,o-rwx "$l_home"
                fi
            done <<< "$(stat -Lc '%U %#a' "$l_home")"
        else
            l_output2="$l_output2\n - User: \"$l_user\" Home \"$l_home\" Doesn't exist\n - Creating home directory according to site policy"
            
            # Create missing home directory
            if [ ! -d "$l_home" ]; then
                echo " - Creating home directory for user $l_user: $l_home"
                mkdir -p "$l_home"
                chown "$l_user" "$l_home"
                chmod 750 "$l_home"
                
                # Copy skeleton files if available
                if [ -d /etc/skel ]; then
                    cp -r /etc/skel/. "$l_home/"
                    chown -R "$l_user" "$l_home"
                fi
            fi
        fi
    done <<< "$(printf '%s\n' "${a_uarr[@]}")"
    
    if [ -z "$l_output2" ]; then
        echo " - No modification needed to local interactive users home directories"
    else
        echo -e "\n$l_output2"
    fi
    
    echo " - Local interactive user home directories configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_user_home_directories
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Local interactive user home directories properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="