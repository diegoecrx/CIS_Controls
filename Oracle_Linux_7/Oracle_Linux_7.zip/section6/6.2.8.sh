#!/usr/bin/env bash
# Script: 6.2.8.sh
# Item: 6.2.8 Ensure root path integrity (Automated)
set -euo pipefail

SCRIPT_NAME="6.2.8.sh"
ITEM_NAME="6.2.8 Ensure root path integrity (Automated)"
DESCRIPTION="This remediation ensures root PATH integrity by checking and fixing path directories."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check if a directory is a system symlink (should be excluded from permission checks)
is_system_symlink() {
    local dir="$1"
    
    # Check if it's a symlink
    if [ -L "$dir" ]; then
        # Common system symlinks that typically have 777 permissions
        case "$dir" in
            "/sbin"|"/bin"|"/lib"|"/lib64")
                return 0  # It's a system symlink
                ;;
        esac
        
        # Check if it points to /usr directory (common in modern systems)
        local target
        target=$(readlink -f "$dir" 2>/dev/null || true)
        if [[ "$target" == /usr/* ]]; then
            return 0  # It's a system symlink to /usr
        fi
    fi
    
    return 1  # Not a system symlink
}

# Function to check current status
check_current_status() {
    echo "Checking root PATH integrity..."
    
    # Get root's PATH
    root_path=$(su - root -c 'echo $PATH' 2>/dev/null || echo "$PATH")
    echo " - Root PATH: $root_path"
    
    # Split PATH into components
    IFS=':' read -ra path_dirs <<< "$root_path"
    
    issues_found=false
    compliant=true
    
    for i in "${!path_dirs[@]}"; do
        dir="${path_dirs[$i]}"
        
        # Check for empty directory (::)
        if [ -z "$dir" ]; then
            echo "FAIL: Empty directory found in PATH at position $((i+1))"
            echo "PROOF: Empty PATH component (::)"
            issues_found=true
            compliant=false
            continue
        fi
        
        # Check for current directory (.)
        if [ "$dir" = "." ]; then
            echo "FAIL: Current working directory (.) found in PATH"
            echo "PROOF: PATH contains '.'"
            issues_found=true
            compliant=false
            continue
        fi
        
        # Check if directory exists
        if [ ! -e "$dir" ]; then
            echo "FAIL: PATH directory does not exist: $dir"
            echo "PROOF: Directory $dir not found"
            issues_found=true
            compliant=false
            continue
        fi
        
        # Check if it's actually a directory
        if [ ! -d "$dir" ]; then
            echo "FAIL: PATH component is not a directory: $dir"
            echo "PROOF: $dir is not a directory"
            issues_found=true
            compliant=false
            continue
        fi
        
        # Skip permission checks for system symlinks
        if is_system_symlink "$dir"; then
            echo "INFO: $dir is a system symlink (skipping permission checks)"
            continue
        fi
        
        # Check ownership (should be root)
        dir_owner=$(stat -c "%U" "$dir")
        if [ "$dir_owner" != "root" ]; then
            echo "FAIL: PATH directory not owned by root: $dir"
            echo "PROOF: $dir owned by $dir_owner (should be root)"
            issues_found=true
            compliant=false
        fi
        
        # Check permissions (should be 755 or more restrictive)
        dir_perms=$(stat -c "%a" "$dir")
        # Check if group or other has write permission
        if [ $((0$dir_perms & 022)) -ne 0 ]; then
            echo "FAIL: PATH directory has excessive permissions: $dir"
            echo "PROOF: $dir has permissions $dir_perms (group/other writable)"
            issues_found=true
            compliant=false
        fi
    done
    
    # Check for trailing colon
    if [[ "$root_path" == *: ]]; then
        echo "FAIL: PATH has trailing colon"
        echo "PROOF: PATH ends with ':'"
        issues_found=true
        compliant=false
    fi
    
    if [ "$compliant" = true ]; then
        echo "PASS: Root PATH integrity is properly configured"
        echo "PROOF: All PATH directories exist, are owned by root, and have appropriate permissions"
        return 0
    else
        return 1
    fi
}

# Function to fix
fix_root_path_integrity() {
    echo "Applying fix..."
    
    # Get current root PATH
    root_path=$(su - root -c 'echo $PATH' 2>/dev/null || echo "$PATH")
    echo " - Current root PATH: $root_path"
    
    # Split PATH into components
    IFS=':' read -ra path_dirs <<< "$root_path"
    
    # Build new clean PATH
    new_path_dirs=()
    
    for dir in "${path_dirs[@]}"; do
        # Skip empty directories
        if [ -z "$dir" ]; then
            echo " - Removing empty directory from PATH"
            continue
        fi
        
        # Skip current directory
        if [ "$dir" = "." ]; then
            echo " - Removing current directory (.) from PATH"
            continue
        fi
        
        # Check if directory exists
        if [ ! -e "$dir" ]; then
            echo " - Removing non-existent directory from PATH: $dir"
            continue
        fi
        
        # Check if it's actually a directory
        if [ ! -d "$dir" ]; then
            echo " - Removing non-directory from PATH: $dir"
            continue
        fi
        
        # Skip system symlinks for permission changes
        if is_system_symlink "$dir"; then
            echo " - Keeping system symlink: $dir"
            new_path_dirs+=("$dir")
            continue
        fi
        
        # Fix ownership if needed
        dir_owner=$(stat -c "%U" "$dir")
        if [ "$dir_owner" != "root" ]; then
            echo " - Fixing ownership of $dir (was $dir_owner, setting to root)"
            chown root "$dir" 2>/dev/null || echo " - Warning: Could not change ownership of $dir"
        fi
        
        # Fix permissions if needed
        dir_perms=$(stat -c "%a" "$dir")
        if [ $((0$dir_perms & 022)) -ne 0 ]; then
            echo " - Fixing permissions of $dir (was $dir_perms, removing group/other write)"
            chmod go-w "$dir" 2>/dev/null || echo " - Warning: Could not change permissions of $dir"
        fi
        
        # Add to new PATH
        new_path_dirs+=("$dir")
    done
    
    # Build new PATH string
    new_path=$(IFS=':'; echo "${new_path_dirs[*]}")
    
    # Remove trailing colon if present
    new_path="${new_path%:}"
    
    echo " - New cleaned PATH: $new_path"
    
    # Update root's PATH in common profile files
    profile_files=(
        "/root/.bashrc"
        "/root/.bash_profile"
        "/root/.profile"
    )
    
    for profile_file in "${profile_files[@]}"; do
        if [ -f "$profile_file" ]; then
            echo " - Updating PATH in $profile_file"
            
            # Remove existing PATH exports
            sed -i '/^export PATH=/d' "$profile_file"
            sed -i '/^PATH=/d' "$profile_file"
            
            # Add new PATH
            echo "export PATH=\"$new_path\"" >> "$profile_file"
        fi
    done
    
    # Also update /etc/environment if it exists
    if [ -f /etc/environment ]; then
        echo " - Updating PATH in /etc/environment"
        sed -i '/^PATH=/d' /etc/environment
        echo "PATH=\"$new_path\"" >> /etc/environment
    fi
    
    echo " - Root PATH integrity remediation completed"
    echo " - NOTE: New PATH will take effect in new shell sessions"
}

# Main remediation
{
    echo "Initial Status Check:"
    echo "====================="
    if check_current_status; then
        echo "✓ No remediation needed - system is already compliant"
    else
        echo ""
        echo "Remediation Required:"
        echo "===================="
        fix_root_path_integrity
    fi
    
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo ""
        echo "SUCCESS: Root PATH integrity properly configured"
        echo ""
        echo "Summary:"
        echo "  ✓ No empty directories in PATH"
        echo "  ✓ No current directory (.) in PATH" 
        echo "  ✓ No trailing colon in PATH"
        echo "  ✓ All PATH directories exist and are directories"
        echo "  ✓ All non-system PATH directories owned by root"
        echo "  ✓ All non-system PATH directories have appropriate permissions (755 or more restrictive)"
    else
        echo ""
        echo "WARNING: Some issues may require manual attention"
        echo ""
        echo "Note: System symlinks like /bin and /sbin may have 777 permissions"
        echo "which is normal when they point to /usr directories"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="