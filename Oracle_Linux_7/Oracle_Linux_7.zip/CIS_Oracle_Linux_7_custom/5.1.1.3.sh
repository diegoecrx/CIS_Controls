#!/usr/bin/env bash

# Script: 5.1.1.3.sh
# Item: 5.1.1.3 Ensure journald is configured to send logs to rsyslog (Manual)
# Description: Configure systemd-journald to forward logs to rsyslog

set -euo pipefail

SCRIPT_NAME="5.1.1.3.sh"
ITEM_NAME="5.1.1.3 Ensure journald is configured to send logs to rsyslog (Manual)"
DESCRIPTION="Configure systemd-journald to forward logs to rsyslog for centralized logging"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check if systemd-journald exists
check_journald_available() {
    if ! command -v journalctl >/dev/null 2>&1; then
        echo "systemd-journald is not available on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi
    echo "✓ systemd-journald is available"
}

# Function to check current ForwardToSyslog setting
check_current_forward_setting() {
    echo "Checking current ForwardToSyslog configuration..."
    echo ""
    
    local config_file="/etc/systemd/journald.conf"
    local override_dir="/etc/systemd/journald.conf.d"
    
    # Check main configuration file
    if [ -f "$config_file" ]; then
        echo "Main configuration file: $config_file"
        if grep -E '^#?ForwardToSyslog=' "$config_file" >/dev/null 2>&1; then
            local current_setting=$(grep -E '^#?ForwardToSyslog=' "$config_file" | tail -1 | cut -d= -f2 | tr -d ' ')
            if [ "$current_setting" = "yes" ]; then
                echo "✓ ForwardToSyslog=yes (enabled)"
                return 0
            else
                echo "✗ ForwardToSyslog=$current_setting (should be 'yes')"
                return 1
            fi
        else
            echo "✗ ForwardToSyslog not configured (using default)"
            return 1
        fi
    else
        echo "✗ Configuration file $config_file does not exist"
        return 1
    fi
}

# Function to check override configurations
check_override_configs() {
    local override_dir="/etc/systemd/journald.conf.d"
    
    if [ -d "$override_dir" ]; then
        echo ""
        echo "Checking configuration overrides in $override_dir:"
        for conf_file in "$override_dir"/*.conf; do
            if [ -f "$conf_file" ]; then
                if grep -E '^#?ForwardToSyslog=' "$conf_file" >/dev/null 2>&1; then
                    local setting=$(grep -E '^#?ForwardToSyslog=' "$conf_file" | tail -1 | cut -d= -f2 | tr -d ' ')
                    echo "  $(basename "$conf_file"): ForwardToSyslog=$setting"
                    if [ "$setting" = "yes" ]; then
                        return 0
                    fi
                fi
            fi
        done
    fi
    return 1
}

# Function to configure ForwardToSyslog
configure_forward_syslog() {
    echo ""
    echo "Configuring ForwardToSyslog=yes..."
    
    local config_file="/etc/systemd/journald.conf"
    
    # Create backup
    if [ -f "$config_file" ]; then
        cp "$config_file" "$config_file.backup.$(date +%Y%m%d_%H%M%S)"
        echo "✓ Created backup: $config_file.backup.*"
    fi
    
    # Check if file exists, create if not
    if [ ! -f "$config_file" ]; then
        echo "Creating new configuration file: $config_file"
        touch "$config_file"
    fi
    
    # Remove any existing ForwardToSyslog lines
    if grep -q '^#*ForwardToSyslog=' "$config_file" 2>/dev/null; then
        sed -i '/^#*ForwardToSyslog=/d' "$config_file"
        echo "✓ Removed existing ForwardToSyslog settings"
    fi
    
    # Ensure [Journal] section exists
    if ! grep -q '^\[Journal\]' "$config_file" 2>/dev/null; then
        echo "[Journal]" >> "$config_file"
        echo "✓ Added [Journal] section"
    fi
    
    # Add ForwardToSyslog setting
    echo "ForwardToSyslog=yes" >> "$config_file"
    echo "✓ Added ForwardToSyslog=yes"
    
    # Verify the setting was added
    if grep -q '^ForwardToSyslog=yes' "$config_file" 2>/dev/null; then
        echo "✓ Configuration verified"
        return 0
    else
        echo "✗ Configuration failed"
        return 1
    fi
}

# Function to reload journald service
reload_journald_service() {
    echo ""
    echo "Reloading systemd-journald service..."
    
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        if systemctl reload-or-try-restart systemd-journald; then
            echo "✓ systemd-journald service reloaded successfully"
            return 0
        else
            echo "✗ Failed to reload systemd-journald service"
            return 1
        fi
    else
        echo "⚠ systemd-journald service is not active"
        return 1
    fi
}

# Function to check rsyslog configuration
check_rsyslog_config() {
    echo ""
    echo "Checking rsyslog configuration..."
    
    if ! command -v rsyslogd >/dev/null 2>&1; then
        echo "⚠ rsyslog is not installed"
        return 1
    fi
    
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "✓ rsyslog service is active"
        
        # Check for imjournal module
        if grep -r 'imjournal' /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | head -1 >/dev/null; then
            echo "✓ rsyslog imjournal module configured"
            return 0
        else
            echo "⚠ imjournal module not found in rsyslog configuration"
            echo "  (rsyslog may be using legacy syslog socket)"
            return 1
        fi
    else
        echo "⚠ rsyslog service is not active"
        return 1
    fi
}

# Function to test log forwarding
test_log_forwarding() {
    echo ""
    echo "Testing log forwarding..."
    
    local test_id="JOURNALD-TEST-$(date +%s)"
    local test_message="Test message for journald to rsyslog forwarding - $test_id"
    
    # Send test message
    if logger "$test_message"; then
        echo "✓ Test message sent via logger: $test_id"
        
        # Check if message appears in journal
        sleep 1
        if journalctl --since "1 minute ago" | grep -q "$test_id" 2>/dev/null; then
            echo "✓ Test message found in journal"
        else
            echo "⚠ Test message not found in journal"
        fi
        
        # Check if message appears in syslog (if rsyslog is active)
        if systemctl is-active rsyslog >/dev/null 2>&1; then
            sleep 1
            if grep -r "$test_id" /var/log/messages /var/log/syslog /var/log/rsyslog/* 2>/dev/null | head -1 >/dev/null; then
                echo "✓ Test message found in syslog"
                return 0
            else
                echo "⚠ Test message not found in syslog"
                return 1
            fi
        fi
    else
        echo "✗ Failed to send test message"
        return 1
    fi
}

# Main execution
main() {
    echo "Initial System Check:"
    echo "===================="
    
    # Check if journald is available
    check_journald_available
    echo ""
    
    # Check current configuration
    local needs_config=false
    if ! check_current_forward_setting; then
        needs_config=true
    fi
    
    # Check overrides
    if check_override_configs; then
        echo "✓ Override configuration found with correct setting"
        needs_config=false
    fi
    
    echo ""
    echo "Service Status:"
    echo "==============="
    
    # Check journald service
    if systemctl is-active systemd-journald >/dev/null 2>&1; then
        echo "✓ systemd-journald: active"
    else
        echo "✗ systemd-journald: inactive"
    fi
    
    # Check rsyslog service
    check_rsyslog_config
    
    echo ""
    
    # Apply configuration if needed
    if [ "$needs_config" = true ]; then
        echo "Configuration Required:"
        echo "======================"
        
        if configure_forward_syslog; then
            if reload_journald_service; then
                echo ""
                echo "✓ Configuration applied successfully"
            else
                echo ""
                echo "⚠ Configuration applied but service reload failed"
            fi
        else
            echo ""
            echo "✗ Configuration failed"
        fi
    else
        echo "✓ No configuration needed - ForwardToSyslog is already set to 'yes'"
    fi
    
    echo ""
    echo "Final Verification:"
    echo "==================="
    
    # Final check
    if check_current_forward_setting || check_override_configs; then
        echo ""
        echo "✓ ForwardToSyslog is properly configured"
        
        # Test functionality
        test_log_forwarding
        
        echo ""
        echo "SUCCESS: journald is configured to send logs to rsyslog"
    else
        echo ""
        echo "✗ ForwardToSyslog is not properly configured"
        echo ""
        echo "Manual configuration required:"
        echo "=============================="
        echo "1. Edit /etc/systemd/journald.conf"
        echo "2. Add or modify: ForwardToSyslog=yes"
        echo "3. Reload service: systemctl reload systemd-journald"
        echo ""
        echo "Or use command:"
        echo "echo 'ForwardToSyslog=yes' >> /etc/systemd/journald.conf && systemctl reload systemd-journald"
    fi
    
    echo ""
    echo "Configuration File Status:"
    echo "=========================="
    if [ -f "/etc/systemd/journald.conf" ]; then
        echo "Current /etc/systemd/journald.conf ForwardToSyslog settings:"
        grep -E '^#?ForwardToSyslog=' /etc/systemd/journald.conf 2>/dev/null || echo "  (not set)"
    else
        echo "/etc/systemd/journald.conf: (file does not exist)"
    fi
}

# Execute main function
main

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="