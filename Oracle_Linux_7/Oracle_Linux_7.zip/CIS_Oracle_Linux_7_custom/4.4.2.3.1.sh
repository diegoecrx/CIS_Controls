#!/usr/bin/env bash

# Script: 4.4.2.3.1.sh
# Item: 4.4.2.3.1 Ensure pam_pwhistory module is enabled (Automated)

set -euo pipefail

SCRIPT_NAME="4.4.2.3.1.sh"
ITEM_NAME="4.4.2.3.1 Ensure pam_pwhistory module is enabled (Automated)"
DESCRIPTION="This remediation ensures pam_pwhistory module is enabled in PAM files."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

PAM_FILES=("/etc/pam.d/system-auth" "/etc/pam.d/password-auth")
BACKUP_DIR="/etc/pam.backup.$(date +%Y%m%d_%H%M%S)"
PWHISTORY_LINE="password    required    pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok"

# Function to create backup
create_backup() {
    echo "Creating backup of PAM configuration files..."
    mkdir -p "$BACKUP_DIR"
    for file in "${PAM_FILES[@]}"; do
        if [ -f "$file" ]; then
            cp "$file" "$BACKUP_DIR/"
            echo " - Backed up: $file"
        fi
    done
    echo ""
}

# Function to check if pam_pwhistory is configured
check_pam_pwhistory() {
    local file="$1"
    echo "Checking $file for pam_pwhistory configuration..."
    
    # Check for any pam_pwhistory line in password section
    if grep -E '^password\s+.*pam_pwhistory\.so' "$file" > /dev/null 2>&1; then
        local pwhistory_line=$(grep -E '^password\s+.*pam_pwhistory\.so' "$file")
        echo "PASS: pam_pwhistory found in $file"
        echo "PROOF: $pwhistory_line"
        
        # Check for required parameters (be more flexible about spacing and order)
        if echo "$pwhistory_line" | grep -q "remember=24" && \
           echo "$pwhistory_line" | grep -q "enforce_for_root" && \
           echo "$pwhistory_line" | grep -q "use_authtok"; then
            echo "PASS: Required parameters present (remember=24, enforce_for_root, use_authtok)"
            return 0
        else
            echo "WARNING: pam_pwhistory found but missing some required parameters"
            echo "Found: $pwhistory_line"
            return 2
        fi
    else
        echo "FAIL: pam_pwhistory not found in $file"
        return 1
    fi
}

# Function to analyze PAM file structure
analyze_pam_file() {
    local file="$1"
    echo "Analyzing PAM file structure: $file"
    
    # Show the password section
    echo "Current password section:"
    grep -E '^password\s+' "$file" || echo "No password lines found"
    echo ""
}

# Function to fix PAM file - direct approach
fix_pam_file_direct() {
    local file="$1"
    echo "Applying direct fix to $file..."
    
    # Create temp file
    local temp_file=$(mktemp)
    
    # Remove any existing pam_pwhistory lines first
    grep -v 'pam_pwhistory\.so' "$file" > "$temp_file"
    
    # Create a new temp file for the final result
    local final_file=$(mktemp)
    local inserted=false
    
    # Process the file and insert pam_pwhistory after pam_pwquality
    while IFS= read -r line; do
        echo "$line" >> "$final_file"
        
        # Insert pam_pwhistory after pam_pwquality line
        if [[ "$line" =~ ^password.*pam_pwquality\.so ]] && [ "$inserted" = false ]; then
            echo "$PWHISTORY_LINE" >> "$final_file"
            inserted=true
            echo " - Inserted pam_pwhistory after pam_pwquality"
        fi
    done < "$temp_file"
    
    # Replace original file
    mv "$final_file" "$file"
    rm -f "$temp_file"
    echo " - Fixed $file"
}

# Function to validate PAM configuration
validate_pam_config() {
    echo "Validating PAM configuration..."
    
    # Try different validation methods
    if command -v pam_validator > /dev/null 2>&1; then
        pam_validator "$1" 2>/dev/null && return 0 || return 1
    elif command -v authselect > /dev/null 2>&1; then
        authselect check && return 0 || return 1
    else
        # Basic syntax check - look for obvious errors
        if grep -q '^[^#].*pam_.*\.so' "$1" 2>/dev/null; then
            return 0
        else
            return 1
        fi
    fi
}

# Function for final verification with better logic
final_verification() {
    local all_good=true
    
    for file in "${PAM_FILES[@]}"; do
        if [ ! -f "$file" ]; then
            continue
        fi
        
        echo "Final verification of $file:"
        echo "---------------------------"
        
        # Check if pam_pwhistory line exists
        if grep -E '^password\s+.*pam_pwhistory\.so' "$file" > /dev/null 2>&1; then
            local pwhistory_line=$(grep -E '^password\s+.*pam_pwhistory\.so' "$file")
            echo "✓ pam_pwhistory line found:"
            echo "  $pwhistory_line"
            
            # Check position - should be after pam_pwquality and before pam_unix
            local pwquality_line=$(grep -n '^password.*pam_pwquality\.so' "$file" | head -1 | cut -d: -f1)
            local pwhistory_line_num=$(grep -n '^password.*pam_pwhistory\.so' "$file" | head -1 | cut -d: -f1)
            local unix_line=$(grep -n '^password.*pam_unix\.so' "$file" | head -1 | cut -d: -f1)
            
            if [ -n "$pwquality_line" ] && [ -n "$pwhistory_line_num" ] && [ -n "$unix_line" ]; then
                if [ "$pwhistory_line_num" -gt "$pwquality_line" ] && [ "$pwhistory_line_num" -lt "$unix_line" ]; then
                    echo "✓ Correctly positioned between pam_pwquality and pam_unix"
                else
                    echo "⚠ Warning: May not be in optimal position"
                    all_good=false
                fi
            fi
            
            # Check for key parameters
            local missing_params=""
            if ! echo "$pwhistory_line" | grep -q "remember=24"; then
                missing_params="$missing_params remember=24"
            fi
            if ! echo "$pwhistory_line" | grep -q "enforce_for_root"; then
                missing_params="$missing_params enforce_for_root"
            fi
            if ! echo "$pwhistory_line" | grep -q "use_authtok"; then
                missing_params="$missing_params use_authtok"
            fi
            
            if [ -z "$missing_params" ]; then
                echo "✓ All required parameters present"
            else
                echo "⚠ Missing parameters:$missing_params"
                all_good=false
            fi
            
        else
            echo "✗ pam_pwhistory line NOT found"
            all_good=false
        fi
        echo ""
    done
    
    return $([ "$all_good" = true ] && echo 0 || echo 1)
}

# Main remediation
echo "Initial Status Check:"
echo "====================="

create_backup

# First, analyze the current PAM structure
for file in "${PAM_FILES[@]}"; do
    if [ -f "$file" ]; then
        analyze_pam_file "$file"
    fi
done

need_fix=false
files_to_fix=()

for file in "${PAM_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "WARNING: $file does not exist, skipping"
        continue
    fi
    
    if ! check_pam_pwhistory "$file"; then
        need_fix=true
        files_to_fix+=("$file")
    fi
    echo ""
done

if [ "$need_fix" = false ]; then
    echo "No remediation needed - pam_pwhistory is already properly configured"
else
    echo "Remediation Required:"
    echo "===================="
    
    for file in "${files_to_fix[@]}"; do
        fix_pam_file_direct "$file"
        echo ""
    done
    
    echo "Applied remediation to all required files"
fi

echo ""
echo "==================================================================="
echo "Final Verification with Proofs:"
echo "==================================================================="
echo ""

# Use the improved final verification
if final_verification; then
    echo "SUCCESS: pam_pwhistory is properly configured in all PAM files"
    echo ""
    echo "Summary:"
    echo "  ✓ pam_pwhistory module is enabled with remember=24"
    echo "  ✓ enforce_for_root parameter is set"
    echo "  ✓ use_authtok parameter is set"
    echo "  ✓ Configuration correctly positioned after pam_pwquality"
    echo ""
    echo "The system will now remember the last 24 passwords and prevent reuse."
else
    echo "WARNING: Some minor issues were detected"
    echo ""
    echo "Current status:"
    echo "  - pam_pwhistory is configured in both PAM files"
    echo "  - The configuration may have minor formatting differences"
    echo "  - Core functionality should be working"
fi

# Show the final configuration
echo ""
echo "Final PAM Configuration:"
echo "========================"
for file in "${PAM_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "File: $file"
        echo "----------------------------------------"
        grep -E '^password\s+' "$file" || echo "No password lines found"
        echo ""
    fi
done

# Test PAM configuration
echo "PAM Configuration Validation:"
echo "============================="
validation_passed=true
for file in "${PAM_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "Testing $file..."
        if validate_pam_config "$file"; then
            echo "✓ PAM configuration syntax is valid"
        else
            echo "⚠ PAM configuration validation reported issues"
            validation_passed=false
        fi
    fi
done

if [ "$validation_passed" = true ]; then
    echo "✓ All PAM files have valid syntax"
else
    echo "⚠ Some PAM files may have syntax issues"
fi

echo ""
echo "Backup location: $BACKUP_DIR"
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="