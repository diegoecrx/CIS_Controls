#!/usr/bin/env bash
# Script: 5.3.2.sh
# Item: 5.3.2 Ensure filesystem integrity is regularly checked (Automated)
set -euo pipefail
SCRIPT_NAME="5.3.2.sh"
ITEM_NAME="5.3.2 Ensure filesystem integrity is regularly checked (Automated)"
DESCRIPTION="This remediation ensures filesystem integrity is regularly checked using AIDE with systemd timer."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking filesystem integrity check configuration..."
    
    # Check if AIDE package is installed
    if ! rpm -q aide >/dev/null 2>&1; then
        echo "FAIL: AIDE package is not installed"
        echo "PROOF: rpm -q aide returned no package found"
        return 1
    fi
    
    # Check for systemd timer configuration (preferred method)
    systemd_timer_configured=false
    if [ -f /etc/systemd/system/aidecheck.service ] && [ -f /etc/systemd/system/aidecheck.timer ]; then
        # Check if timer is enabled
        if systemctl is-enabled aidecheck.timer >/dev/null 2>&1; then
            systemd_timer_configured=true
        fi
    fi
    
    # Check for cron configuration (alternative method)
    cron_configured=false
    if crontab -u root -l 2>/dev/null | grep -q "/usr/sbin/aide --check"; then
        cron_configured=true
    fi
    
    if [ "$systemd_timer_configured" = true ]; then
        echo "PASS: filesystem integrity checking properly configured with systemd timer"
        echo "PROOF: aidecheck.service and aidecheck.timer are configured and enabled"
        return 0
    elif [ "$cron_configured" = true ]; then
        echo "PASS: filesystem integrity checking properly configured with cron"
        echo "PROOF: AIDE check scheduled in root crontab"
        return 0
    fi
    
    echo "FAIL: filesystem integrity checking not configured"
    echo "PROOF: Neither systemd timer nor cron job found for AIDE checks"
    return 1
}
# Function to fix
fix_filesystem_integrity_check() {
    echo "Applying fix..."
    
    # Check if AIDE package is installed
    if ! rpm -q aide >/dev/null 2>&1; then
        echo " - Installing AIDE package"
        yum install -y aide
    fi
    
    # Configure systemd timer (preferred method)
    echo " - Configuring AIDE check with systemd timer"
    
    # Create aidecheck.service
    echo " - Creating /etc/systemd/system/aidecheck.service"
    cat > /etc/systemd/system/aidecheck.service << 'EOF'
[Unit]
Description=Aide Check

[Service]
Type=simple
ExecStart=/usr/sbin/aide --check

[Install]
WantedBy=multi-user.target
EOF
    
    # Create aidecheck.timer
    echo " - Creating /etc/systemd/system/aidecheck.timer"
    cat > /etc/systemd/system/aidecheck.timer << 'EOF'
[Unit]
Description=Aide check every day at 5AM

[Timer]
OnCalendar=*-*-* 05:00:00
Unit=aidecheck.service

[Install]
WantedBy=multi-user.target
EOF
    
    # Set proper ownership and permissions
    echo " - Setting ownership and permissions for systemd files"
    chown root:root /etc/systemd/system/aidecheck.*
    chmod 0644 /etc/systemd/system/aidecheck.*
    
    # Reload systemd and enable services
    echo " - Reloading systemd daemon"
    systemctl daemon-reload
    
    echo " - Enabling aidecheck.service"
    systemctl enable aidecheck.service
    
    echo " - Enabling and starting aidecheck.timer"
    systemctl --now enable aidecheck.timer
    
    # Remove any existing cron jobs to avoid duplication
    echo " - Checking for existing cron jobs"
    if crontab -u root -l 2>/dev/null | grep -q "/usr/sbin/aide --check"; then
        echo " - Removing existing AIDE cron job to avoid duplication"
        (crontab -u root -l 2>/dev/null | grep -v "/usr/sbin/aide --check") | crontab -u root -
    fi
    
    echo " - filesystem integrity check configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_filesystem_integrity_check
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: filesystem integrity checking properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="