#!/usr/bin/env bash

# Script: 1.1.2.5.1.sh
# Item: 1.1.2.5.1 Ensure separate partition exists for /var/tmp (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.5.1.sh"
ITEM_NAME="1.1.2.5.1 Ensure separate partition exists for /var/tmp (Automated)"
DESCRIPTION="This remediation ensures /var/tmp is mounted as a separate partition. FORCE VERSION - Automatically creates separate partition with backups."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /var/tmp mount status..."
    echo ""

    # Display current mount status
    echo "Current /var/tmp mount information:"
    mount | grep -E '\s/var/tmp\s' || echo "No separate /var/tmp mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/tmp:"
    grep -E '\s/var/tmp\s' /etc/fstab || echo "No /var/tmp entry in /etc/fstab"
    echo ""

    # Check if /var/tmp is a separate partition
    echo "Checking if /var/tmp is a separate partition:"
    vartmp_device=$(df /var/tmp --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$vartmp_device" ] && [ -n "$var_device" ] && [ "$vartmp_device" != "$var_device" ]; then
        echo "PASS: /var/tmp is on separate partition: $vartmp_device"
        vartmp_is_separate=true
    elif [ -n "$vartmp_device" ] && [ -n "$root_device" ] && [ "$vartmp_device" != "$root_device" ]; then
        echo "PASS: /var/tmp is on separate partition: $vartmp_device"
        vartmp_is_separate=true
    else
        echo "FAIL: /var/tmp is NOT on separate partition"
        if [ -n "$vartmp_device" ]; then
            echo "PROOF: /var/tmp shares device with $vartmp_device"
        else
            echo "PROOF: /var/tmp is not mounted separately"
        fi
        vartmp_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /var/tmp partition if needed
    if [ "$vartmp_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /VAR/TMP PARTITION"
        echo "==================================================================="
        echo ""

        # Function to backup /var/tmp data
        backup_vartmp_data() {
            echo " - Creating backup of /var/tmp to /var_tmp_backup_$(date +%Y%m%d_%H%M%S)..."
            backup_dir="/var_tmp_backup_$(date +%Y%m%d_%H%M%S)"
            mkdir -p "/$backup_dir"
            
            # Check if /var/tmp exists and has files
            if [ -d "/var/tmp" ] && [ "$(ls -A /var/tmp 2>/dev/null)" ]; then
                echo " - Backing up existing /var/tmp contents..."
                if command -v rsync >/dev/null 2>&1; then
                    rsync -a "/var/tmp/" "/$backup_dir/" 
                else
                    cp -a "/var/tmp"/* "/$backup_dir/" 2>/dev/null || true
                fi
                echo " - SUCCESS: /var/tmp data backed up to /$backup_dir"
            else
                echo " - INFO: /var/tmp is empty or doesn't exist, no data to backup"
            fi
            echo "$backup_dir"
            return 0
        }

        # Function to create loop device /var/tmp partition
        create_loop_vartmp() {
            local backup_dir=$1
            echo " - Creating loop device /var/tmp partition..."
            
            # Create a 1GB file for loop device (tmp doesn't need much space)
            echo " - Creating 1GB disk image at /var_tmp_partition.img..."
            dd if=/dev/zero of=/var_tmp_partition.img bs=1M count=1024 status=progress
            echo " - Formatting as ext4 filesystem..."
            mkfs.ext4 -F /var_tmp_partition.img
            
            # Mount loop device to temporary location
            mkdir -p /mnt/newvartmp
            mount -o loop /var_tmp_partition.img /mnt/newvartmp
            
            # Set proper permissions for tmp directory
            echo " - Setting proper permissions for /var/tmp..."
            chmod 1777 /mnt/newvartmp
            
            # Restore data from backup if it exists
            if [ -d "/$backup_dir" ] && [ "$(ls -A /$backup_dir)" ]; then
                echo " - Restoring data to new partition..."
                cp -a "/$backup_dir"/* /mnt/newvartmp/ 2>/dev/null || true
            fi
            
            # Backup old /var/tmp and mount new partition
            echo " - Replacing /var/tmp with new partition..."
            if [ -d "/var/tmp" ]; then
                mv /var/tmp /var/tmp.old
            fi
            mkdir -p /var/tmp
            umount /mnt/newvartmp
            mount -o loop /var_tmp_partition.img /var/tmp
            
            # Set permissions again after mount
            chmod 1777 /var/tmp
            
            # Add to fstab with secure options
            echo " - Updating /etc/fstab with secure mount options..."
            cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
            echo "/var_tmp_partition.img /var/tmp ext4 loop,nosuid,nodev,noexec 0 0" >> /etc/fstab
            
            # Cleanup
            rmdir /mnt/newvartmp
            echo " - SUCCESS: Loop device /var/tmp partition created"
        }

        # Function to verify /var exists and create if needed
        ensure_var_exists() {
            if [ ! -d "/var" ]; then
                echo " - WARNING: /var directory doesn't exist, creating it..."
                mkdir -p /var
            fi
            if [ ! -d "/var/tmp" ]; then
                echo " - WARNING: /var/tmp directory doesn't exist, creating it..."
                mkdir -p /var/tmp
            fi
        }

        # Main partition creation logic
        ensure_var_exists
        backup_dir=$(backup_vartmp_data)
        create_loop_vartmp "$backup_dir"
        
        vartmp_is_separate=true
        echo " - FORCE MODE: Separate /var/tmp partition creation completed"
        echo ""
    fi

    echo "Remediation of /var/tmp partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /var/tmp is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var/tmp IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/var/tmp\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /var/tmp is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /var/tmp is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify /var/tmp entry exists in fstab
    echo ""
    echo "2. VERIFYING /var/tmp ENTRY IN /etc/fstab:"
    echo "------------------------------------------"
    fstab_entry=$(grep -E '\s/var/tmp\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        echo "PASS: /var/tmp entry found in /etc/fstab"
        echo "PROOF (/etc/fstab entry):"
        echo "$fstab_entry"
    else
        echo "FAIL: /var/tmp entry NOT found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify filesystem consistency
    echo ""
    echo "3. VERIFYING FILESYSTEM CONSISTENCY:"
    echo "-----------------------------------"
    if mount | grep -q -E '\s/var/tmp\s' && grep -q -E '\s/var/tmp\s' /etc/fstab; then
        echo "PASS: /var/tmp mount consistent with /etc/fstab configuration"
    else
        echo "FAIL: /var/tmp mount inconsistent with /etc/fstab"
        final_status_pass=false
    fi

    # PROOF 4: Verify proper permissions
    echo ""
    echo "4. VERIFYING /var/tmp PERMISSIONS:"
    echo "---------------------------------"
    vartmp_perms=$(stat -c "%a" /var/tmp 2>/dev/null || echo "unknown")
    if [ "$vartmp_perms" = "1777" ]; then
        echo "PASS: /var/tmp has correct permissions (1777)"
        echo "PROOF: permissions are $vartmp_perms"
    else
        echo "FAIL: /var/tmp has incorrect permissions ($vartmp_perms), should be 1777"
        echo " - Fixing permissions..."
        chmod 1777 /var/tmp
        final_status_pass=false
    fi

    # PROOF 5: Verify secure mount options
    echo ""
    echo "5. VERIFYING SECURE MOUNT OPTIONS:"
    echo "---------------------------------"
    mount_options=$(mount | grep -E '\s/var/tmp\s' | grep -o -E 'nosuid|nodev|noexec' | tr '\n' ',' | sed 's/,$//')
    if echo "$mount_options" | grep -q "nosuid" && \
       echo "$mount_options" | grep -q "nodev" && \
       echo "$mount_options" | grep -q "noexec"; then
        echo "PASS: /var/tmp mounted with nosuid,nodev,noexec options"
        echo "PROOF (mount options): $mount_options"
    else
        echo "FAIL: /var/tmp missing some security options"
        echo "PROOF (mount options): $mount_options"
        echo " - Remounting with secure options..."
        mount -o remount,nosuid,nodev,noexec /var/tmp
        final_status_pass=false
    fi

    # PROOF 6: Verify data accessibility
    echo ""
    echo "6. VERIFYING DATA ACCESSIBILITY:"
    echo "-------------------------------"
    # Test write access
    test_file="/var/tmp/test_write_$$.txt"
    if echo "test" > "$test_file" 2>/dev/null; then
        echo "PASS: Write access verified in /var/tmp"
        rm -f "$test_file"
    else
        echo "FAIL: Cannot write to /var/tmp"
        final_status_pass=false
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        echo "FORCE MODE SUMMARY:"
        echo "==================="
        echo "✓ Separate /var/tmp partition created automatically"
        echo "✓ Backup created: /var/tmp.old and /var_tmp_backup_*"
        echo "✓ Configuration persisted in /etc/fstab"
        echo "✓ Secure mount options applied (nosuid,nodev,noexec)"
        echo "✓ Proper permissions set (1777)"
        echo "✓ All existing data preserved and migrated"
        echo ""
        echo "SECURITY BENEFITS:"
        echo "• Prevents /var/tmp from filling other filesystems"
        echo "• Blocks executable files with noexec option"
        echo "• Prevents setuid programs with nosuid option"
        echo "• Blocks device files with nodev option"
        echo "• Isolates temporary files from system partitions"
        echo ""
        echo "NOTE: Old /var/tmp data preserved in /var/tmp.old and backup directory"
        echo "You can remove these after verifying the new partition works correctly."
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="