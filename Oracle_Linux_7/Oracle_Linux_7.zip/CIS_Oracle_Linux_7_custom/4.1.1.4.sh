#!/usr/bin/env bash
# Script: 4.1.1.4.sh
# Item: 4.1.1.4 Ensure permissions on /etc/cron.daily are configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.1.1.4.sh"
ITEM_NAME="4.1.1.4 Ensure permissions on /etc/cron.daily are configured (Automated)"
DESCRIPTION="This remediation ensures proper ownership and permissions on /etc/cron.daily directory."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/cron.daily permissions configuration..."
    
    # Check if /etc/cron.daily directory exists
    if [ ! -d /etc/cron.daily ]; then
        echo "FAIL: /etc/cron.daily directory does not exist"
        echo "PROOF: /etc/cron.daily directory not found"
        return 1
    fi
    
    # Check ownership - must be root:root
    local current_owner=$(stat -c "%U:%G" /etc/cron.daily 2>/dev/null)
    if [ "$current_owner" != "root:root" ]; then
        echo "FAIL: /etc/cron.daily ownership is incorrect"
        echo "PROOF: Current ownership is $current_owner, should be root:root"
        return 1
    fi
    
    # Check permissions - must be 700 (og-rwx)
    local current_perms=$(stat -c "%a" /etc/cron.daily 2>/dev/null)
    if [ "$current_perms" != "700" ]; then
        echo "FAIL: /etc/cron.daily permissions are incorrect"
        echo "PROOF: Current permissions are $current_perms, should be 700"
        return 1
    fi
    
    # Additional verification using symbolic permissions
    local symbolic_perms=$(stat -c "%A" /etc/cron.daily 2>/dev/null)
    if [[ ! "$symbolic_perms" =~ ^drwx------$ ]]; then
        echo "FAIL: /etc/cron.daily symbolic permissions are incorrect"
        echo "PROOF: Current symbolic permissions are $symbolic_perms, should be drwx------"
        return 1
    fi
    
    echo "PASS: /etc/cron.daily permissions properly configured"
    echo "PROOF: Ownership is root:root and permissions are 700 (drwx------)"
    return 0
}
# Function to fix
fix_cron_daily_permissions() {
    echo "Applying fix..."
    
    # Check if /etc/cron.daily exists
    if [ ! -d /etc/cron.daily ]; then
        echo " - /etc/cron.daily directory does not exist, creating it"
        mkdir -p /etc/cron.daily
        echo " - Created /etc/cron.daily directory"
    fi
    
    # Force remediation - always apply the required steps
    
    # Set ownership to root:root
    echo " - Setting ownership to root:root"
    chown root:root /etc/cron.daily/
    
    # Set permissions to 700 (og-rwx)
    echo " - Setting permissions to 700 (og-rwx)"
    chmod 700 /etc/cron.daily/
    
    # Verify the changes were applied
    echo " - Verifying permissions configuration"
    
    local final_owner=$(stat -c "%U:%G" /etc/cron.daily 2>/dev/null)
    local final_perms=$(stat -c "%a" /etc/cron.daily 2>/dev/null)
    
    if [ "$final_owner" = "root:root" ] && [ "$final_perms" = "700" ]; then
        echo " - Successfully configured /etc/cron.daily permissions"
    else
        echo " - WARNING: Permissions may not have been set correctly"
        echo "   Final ownership: $final_owner"
        echo "   Final permissions: $final_perms"
    fi
    
    echo " - /etc/cron.daily permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_cron_daily_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: /etc/cron.daily permissions properly configured"
        echo ""
        echo "Current directory status:"
        echo "------------------------"
        ls -ld /etc/cron.daily
        echo ""
        echo "Detailed permissions:"
        echo "--------------------"
        stat /etc/cron.daily | head -4
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Manual configuration required. Run these commands:"
        echo "chown root:root /etc/cron.daily/"
        echo "chmod og-rwx /etc/cron.daily/"
        echo ""
        echo "Current directory status:"
        echo "------------------------"
        ls -ld /etc/cron.daily 2>/dev/null || echo "/etc/cron.daily does not exist"
        echo ""
        echo "Verification commands:"
        echo "---------------------"
        echo "stat -c '%U:%G %a %A' /etc/cron.daily"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="