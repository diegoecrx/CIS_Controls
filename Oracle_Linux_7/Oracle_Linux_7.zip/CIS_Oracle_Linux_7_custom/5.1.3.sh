#!/usr/bin/env bash
# Script: 5.1.3.sh
# Item: 5.1.3 Ensure logrotate is configured (Manual)
set -euo pipefail
SCRIPT_NAME="5.1.3.sh"
ITEM_NAME="5.1.3 Ensure logrotate is configured (Manual)"
DESCRIPTION="This remediation ensures logrotate is configured per site policy with example settings."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking logrotate configuration..."
    
    conf_file="/etc/logrotate.conf"
    if [ ! -f "$conf_file" ]; then
        echo "FAIL: /etc/logrotate.conf does not exist"
        echo "PROOF: File not found"
        return 1
    fi
    
    # Check for basic rotation parameters (example: weekly, rotate 4, etc.)
    weekly=$(grep '^weekly' "$conf_file" || true)
    rotate=$(grep '^rotate' "$conf_file" || true)
    create=$(grep '^create' "$conf_file" || true)
    
    if [ -n "$weekly" ] && [ -n "$rotate" ] && [ -n "$create" ]; then
        echo "PASS: Basic rotation parameters present"
        echo "PROOF (weekly): $weekly"
        echo "PROOF (rotate): $rotate"
        echo "PROOF (create): $create"
        return 0
    else
        echo "FAIL: Missing basic rotation parameters"
        echo "PROOF (weekly): $weekly"
        echo "PROOF (rotate): $rotate"
        echo "PROOF (create): $create"
        return 1
    fi
}
# Function to fix with example configuration
fix_logrotate() {
    echo "Applying example configuration (adjust per site policy)..."
    
    conf_file="/etc/logrotate.conf"
    # Backup
    [ -f "$conf_file" ] && cp "$conf_file" "$conf_file.bak.$(date +%Y%m%d)"
    
    # Add example lines if missing
    grep -q '^weekly' "$conf_file" || echo "weekly" >> "$conf_file"
    grep -q '^rotate 4' "$conf_file" || echo "rotate 4" >> "$conf_file"
    grep -q '^create' "$conf_file" || echo "create" >> "$conf_file"
    grep -q '^dateext' "$conf_file" || echo "dateext" >> "$conf_file"
    grep -q '^compress' "$conf_file" || echo "compress" >> "$conf_file"
    
    echo " - Added example settings to $conf_file"
    
    # Restart logrotate if needed (logrotate is cron-based, no service)
    echo "Note: Logrotate runs via cron; no restart needed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed (verify per policy)"
    else
        fix_logrotate
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Logrotate configured"
    else
        echo "FAIL: Issues remain - manual review needed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="