#!/usr/bin/env bash
# Script: 4.5.1.3.sh
# Item: 4.5.1.3 Ensure password expiration warning days is 7 or more (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.1.3.sh"
ITEM_NAME="4.5.1.3 Ensure password expiration warning days is 7 or more (Automated)"
DESCRIPTION="This remediation ensures PASS_WARN_AGE is 7 or more in login.defs and for all users."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check /etc/login.defs
check_login_defs() {
    echo "Checking /etc/login.defs..."
    pass_warn_age=$(grep -E '^[[:space:]]*PASS_WARN_AGE[[:space:]]' /etc/login.defs || true)
    if [ -n "$pass_warn_age" ]; then
        days=$(echo "$pass_warn_age" | awk '{print $2}')
        if [ "$days" -ge 7 ]; then
            echo "PASS: PASS_WARN_AGE $days"
            echo "PROOF: $pass_warn_age"
            return 0
        else
            echo "FAIL: PASS_WARN_AGE $days (should be 7 or more)"
            echo "PROOF: $pass_warn_age"
            return 1
        fi
    else
        echo "FAIL: PASS_WARN_AGE not set"
        echo "PROOF: No PASS_WARN_AGE line found"
        return 1
    fi
}
# Function to check user accounts
check_users() {
    echo "Checking user accounts..."
    fail=false
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            warn_days=$(chage -l "$user" 2>/dev/null | grep "Number of days of warning" | awk -F: '{print $2}' | tr -d ' ')
            if [ -n "$warn_days" ] && [ "$warn_days" -ge 7 ]; then
                echo "PASS: $user has warndays=$warn_days"
            else
                echo "FAIL: $user has warndays=$warn_days (should be 7 or more)"
                fail=true
            fi
        fi
    done < /etc/passwd
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix /etc/login.defs
fix_login_defs() {
    echo "Fixing /etc/login.defs..."
    sed -ri 's/^\s*PASS_WARN_AGE\s+.*$/PASS_WARN_AGE 7/' /etc/login.defs
    if ! grep -q '^PASS_WARN_AGE' /etc/login.defs; then
        echo "PASS_WARN_AGE 7" >> /etc/login.defs
    fi
    echo " - Set PASS_WARN_AGE 7"
}
# Function to fix user accounts
fix_users() {
    echo "Fixing user accounts..."
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            warn_days=$(chage -l "$user" 2>/dev/null | grep "Number of days of warning" | awk -F: '{print $2}' | tr -d ' ')
            if [ -z "$warn_days" ] || [ "$warn_days" -lt 7 ]; then
                chage --warndays 7 "$user"
                echo " - Set warndays=7 for $user"
            fi
        fi
    done < /etc/passwd
}
# Main remediation
{
    login_ok=true
    users_ok=true
    if ! check_login_defs; then
        login_ok=false
    fi
    if ! check_users; then
        users_ok=false
    fi
    if [ "$login_ok" = true ] && [ "$users_ok" = true ]; then
        echo "No remediation needed"
    else
        if [ "$login_ok" = false ]; then
            fix_login_defs
        fi
        if [ "$users_ok" = false ]; then
            fix_users
        fi
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_login_defs; then
        final_pass=false
    fi
    if ! check_users; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: Password expiration warning days is 7 or more"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
