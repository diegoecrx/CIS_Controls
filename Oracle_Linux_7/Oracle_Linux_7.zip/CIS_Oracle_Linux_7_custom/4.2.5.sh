#!/usr/bin/env bash

# Script: 4.2.5.sh
# Item: 4.2.5 Ensure sshd Banner is configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.5.sh"
ITEM_NAME="4.2.5 Ensure sshd Banner is configured (Automated)"
DESCRIPTION="This remediation ensures the SSH Banner directive is set to /etc/issue.net in sshd_config with a proper security warning banner."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH Banner configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"
BANNER_FILE="/etc/issue.net"
BACKUP_CONFIG="${SSHD_CONFIG}.backup.$(date +%Y%m%d_%H%M%S)"

if [ ! -f "$SSHD_CONFIG" ]; then
  echo "ERROR: $SSHD_CONFIG not found"
  exit 1
fi

# Create backup of sshd_config
echo "Creating backup of SSH configuration: $BACKUP_CONFIG"
cp "$SSHD_CONFIG" "$BACKUP_CONFIG"
echo "Backup created successfully"
echo ""

# Check current Banner configuration
echo "Current Banner directive in $SSHD_CONFIG:"
current_banner=$(grep -Pi '^\s*Banner\s+' "$SSHD_CONFIG" || echo "Not configured")
echo "$current_banner"
echo ""

# Create /etc/issue.net with clean, professional security banner
echo "Creating/updating $BANNER_FILE with security warning banner..."
cat > "$BANNER_FILE" << 'EOF'
NOTICE TO USERS

This system is restricted to authorized users for legitimate business purposes.
Unauthorized access is prohibited and will be prosecuted under applicable laws.

All activities on this system are subject to monitoring and logging for security and compliance purposes. 
By accessing this system, you consent to this monitoring.

If you do not agree to these terms, disconnect immediately.

EOF

echo "Created/updated $BANNER_FILE with clean security warning banner"
echo ""

# Set proper permissions on banner file
chmod 644 "$BANNER_FILE"
chown root:root "$BANNER_FILE"
echo "Set proper permissions on $BANNER_FILE (root:root, 644)"
echo ""

echo "Applying remediation to SSH configuration..."
echo ""

# Remove any existing Banner directives (commented or uncommented)
sed -i '/^\s*#\?\s*Banner\s/d' "$SSHD_CONFIG"
echo " - Removed existing Banner directives"

# Find the line number of the first Match directive
match_line=$(grep -n "^\s*Match\s" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "")

if [ -n "$match_line" ]; then
  # Insert Banner directive before the first Match block
  sed -i "${match_line}i Banner $BANNER_FILE" "$SSHD_CONFIG"
  echo " - Inserted 'Banner $BANNER_FILE' before Match directive at line $match_line"
else
  # No Match directive found, append to end with proper formatting
  echo "" >> "$SSHD_CONFIG"
  echo "# SSH Banner configuration - Added by 4.2.5.sh" >> "$SSHD_CONFIG"
  echo "Banner $BANNER_FILE" >> "$SSHD_CONFIG"
  echo " - Appended 'Banner $BANNER_FILE' to end of file"
fi

echo ""
echo " - SUCCESS: Applied Banner configuration"
echo ""

# Validate SSH configuration syntax before proceeding
echo "Validating SSH configuration syntax..."
if ! sshd -t -f "$SSHD_CONFIG"; then
  echo "ERROR: SSH configuration syntax is invalid after changes"
  echo "Restoring original configuration from backup..."
  cp "$BACKUP_CONFIG" "$SSHD_CONFIG"
  echo "Please check the configuration manually"
  exit 1
fi

echo "PASS: SSH configuration syntax is valid"
echo ""

echo "Remediation of SSH Banner configuration complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

final_status_pass=true

echo ""
echo "1. VERIFYING BANNER DIRECTIVE IS SET:"
echo "-------------------------------------"

current_banner=$(grep -Pi '^\s*Banner\s+' "$SSHD_CONFIG" || true)

if [ -n "$current_banner" ]; then
  echo "PASS: Banner directive is configured"
  echo "PROOF:"
  echo "$current_banner"
  
  # Check if it points to /etc/issue.net
  if echo "$current_banner" | grep -qi "/etc/issue.net"; then
    echo "PASS: Banner is set to /etc/issue.net"
    
    # Verify it's before any Match statements
    banner_line=$(grep -n "^\s*Banner\s" "$SSHD_CONFIG" | head -1 | cut -d: -f1)
    first_match_line=$(grep -n "^\s*Match\s" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "9999")
    
    if [ "$banner_line" -lt "$first_match_line" ]; then
      echo "PASS: Banner directive is correctly placed before Match statements"
    else
      echo "WARNING: Banner directive may be after Match statements"
      final_status_pass=false
    fi
  else
    echo "FAIL: Banner is not set to /etc/issue.net"
    echo "Current value: $current_banner"
    final_status_pass=false
  fi
else
  echo "FAIL: Banner directive is NOT configured"
  final_status_pass=false
fi

echo ""
echo "2. VERIFYING BANNER FILE EXISTS AND HAS PROPER CONTENT:"
echo "------------------------------------------------------"

if [ -f "$BANNER_FILE" ]; then
  echo "PASS: $BANNER_FILE exists"
  echo "PROOF (file permissions):"
  ls -la "$BANNER_FILE"
  echo ""
  echo "PROOF (file content):"
  echo "==================================================================="
  cat "$BANNER_FILE"
  echo "==================================================================="
  
  # Check file permissions
  file_perm=$(stat -c "%a" "$BANNER_FILE")
  file_owner=$(stat -c "%U:%G" "$BANNER_FILE")
  
  if [ "$file_perm" = "644" ]; then
    echo "PASS: Banner file has correct permissions (644)"
  else
    echo "WARNING: Banner file has incorrect permissions ($file_perm), expected 644"
    final_status_pass=false
  fi
  
  if [ "$file_owner" = "root:root" ]; then
    echo "PASS: Banner file has correct ownership (root:root)"
  else
    echo "WARNING: Banner file has incorrect ownership ($file_owner), expected root:root"
    final_status_pass=false
  fi
else
  echo "FAIL: $BANNER_FILE does not exist"
  final_status_pass=false
fi

echo ""
echo "3. VERIFYING SSHD CONFIGURATION SYNTAX:"
echo "---------------------------------------"

if sshd -t -f "$SSHD_CONFIG" 2>/dev/null; then
  echo "PASS: SSHD configuration syntax is valid"
else
  echo "FAIL: SSHD configuration has syntax errors"
  echo "PROOF:"
  sshd -t -f "$SSHD_CONFIG" 2>&1 || true
  final_status_pass=false
fi

echo ""
echo "4. RELOADING SSHD SERVICE:"
echo "--------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "Reloading SSHD service..."
  if systemctl reload-or-try-restart sshd.service >/dev/null 2>&1; then
    echo "PASS: SSHD service reloaded successfully"
  else
    echo "FAIL: Failed to reload SSHD service"
    echo "Checking service status..."
    systemctl status sshd.service --no-pager -l | head -20
    final_status_pass=false
  fi
else
  echo "WARNING: SSHD service is not active - configuration saved but service not reloaded"
fi

echo ""
echo "5. VERIFYING SSHD SERVICE STATUS:"
echo "---------------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "PASS: SSHD service is active"
  echo "PROOF (service status):"
  systemctl status sshd.service --no-pager -l | head -5
else
  echo "FAIL: SSHD service is not active"
  final_status_pass=false
fi

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
  echo ""
  echo "Summary of changes:"
  echo "  ✓ Configured Banner directive in $SSHD_CONFIG"
  echo "  ✓ Created/updated security warning banner in $BANNER_FILE"
  echo "  ✓ Set proper file permissions and ownership"
  echo "  ✓ Validated SSH configuration syntax"
  echo "  ✓ Reloaded SSH service successfully"
  echo ""
  echo "The clean, professional banner will now be displayed to all users during SSH login attempts."
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="