#!/usr/bin/env bash

# Script: 4.5.1.4.sh
# Item: 4.5.1.4 Ensure inactive password lock is 30 days or less (Automated)

set -euo pipefail

SCRIPT_NAME="4.5.1.4.sh"
ITEM_NAME="4.5.1.4 Ensure inactive password lock is 30 days or less (Automated)"
DESCRIPTION="This remediation ensures inactive password lock is set to 30 days or less."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check /etc/default/useradd
check_useradd() {
    echo "Checking /etc/default/useradd..."
    if [ ! -f /etc/default/useradd ]; then
        echo "FAIL: /etc/default/useradd not found"
        echo "PROOF: File does not exist"
        return 1
    fi
    
    inactive=$(grep -E '^[[:space:]]*INACTIVE[[:space:]]*=' /etc/default/useradd || true)
    if [ -n "$inactive" ]; then
        days=$(echo "$inactive" | awk -F= '{print $2}' | tr -d ' ')
        if [ "$days" = "-1" ]; then
            echo "FAIL: INACTIVE=$days (password never expires)"
            echo "PROOF: $inactive"
            return 1
        elif [ "$days" -gt 0 ] && [ "$days" -le 30 ]; then
            echo "PASS: INACTIVE=$days"
            echo "PROOF: $inactive"
            return 0
        else
            echo "FAIL: INACTIVE=$days (should be 1-30)"
            echo "PROOF: $inactive"
            return 1
        fi
    else
        echo "FAIL: INACTIVE not set"
        echo "PROOF: No INACTIVE line found"
        return 1
    fi
}

# Function to check user accounts
check_users() {
    echo "Checking user accounts..."
    echo ""
    
    local fail=false
    local user_count=0
    local compliant_count=0
    
    # Get list of regular users
    local users_to_check=()
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            users_to_check+=("$user")
        fi
    done < <(grep -v '^#' /etc/passwd)
    
    for user in "${users_to_check[@]}"; do
        ((user_count++))
        
        # Get the inactive setting for the user
        local inactive_days
        if inactive_days=$(chage -l "$user" 2>/dev/null | grep "Password inactive" | awk -F: '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'); then
            
            if [ "$inactive_days" = "never" ] || [ -z "$inactive_days" ]; then
                echo "FAIL: $user - Password never expires (inactive: $inactive_days)"
                echo "PROOF: inactive=$inactive_days"
                fail=true
            elif [[ "$inactive_days" =~ ^[0-9]+$ ]]; then
                if [ "$inactive_days" -le 30 ] && [ "$inactive_days" -gt 0 ]; then
                    echo "PASS: $user - Inactive days: $inactive_days"
                    echo "PROOF: inactive=$inactive_days"
                    ((compliant_count++))
                else
                    echo "FAIL: $user - Inactive days: $inactive_days (should be 1-30)"
                    echo "PROOF: inactive=$inactive_days"
                    fail=true
                fi
            else
                # Date format - check if it's a valid future date (compliant)
                echo "PASS: $user - Password inactive date: $inactive_days"
                echo "PROOF: inactive=$inactive_days"
                ((compliant_count++))
            fi
        else
            echo "FAIL: $user - Cannot read password information"
            echo "PROOF: Cannot execute 'chage -l $user'"
            fail=true
        fi
    done
    
    echo ""
    echo "Summary: $compliant_count out of $user_count users compliant"
    
    if [ "$fail" = false ] && [ "$user_count" -gt 0 ]; then
        return 0
    else
        return 1
    fi
}

# Function to fix /etc/default/useradd
fix_useradd() {
    echo "Fixing /etc/default/useradd..."
    if useradd -D -f 30 2>/dev/null; then
        echo "✓ Set default INACTIVE=30 for new users"
        echo "PROOF: Executed 'useradd -D -f 30'"
    else
        echo "✗ Failed to set default INACTIVE value"
        return 1
    fi
}

# Function to check if a user needs fixing
user_needs_fix() {
    local user="$1"
    local inactive_info
    
    inactive_info=$(chage -l "$user" 2>/dev/null | grep "Password inactive" | awk -F: '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    
    if [ -z "$inactive_info" ] || [ "$inactive_info" = "never" ]; then
        return 0  # Needs fix
    elif [[ "$inactive_info" =~ ^[0-9]+$ ]]; then
        if [ "$inactive_info" -le 0 ] || [ "$inactive_info" -gt 30 ]; then
            return 0  # Needs fix
        else
            return 1  # Compliant
        fi
    else
        # Date format - means it's already set to a future date, so compliant
        return 1  # Compliant
    fi
}

# Function to fix user accounts
fix_users() {
    echo "Fixing user accounts..."
    echo ""
    
    local fixed_count=0
    local total_users=0
    
    # Get list of regular users
    local users_to_fix=()
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -ge 1000 ] && [ "$user" != "nobody" ]; then
            users_to_fix+=("$user")
        fi
    done < <(grep -v '^#' /etc/passwd)
    
    total_users=${#users_to_fix[@]}
    
    for user in "${users_to_fix[@]}"; do
        # Get current inactive setting
        local inactive_days
        inactive_days=$(chage -l "$user" 2>/dev/null | grep "Password inactive" | awk -F: '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        
        # Check if user needs fixing
        if user_needs_fix "$user"; then
            if chage --inactive 30 "$user" 2>/dev/null; then
                echo "✓ Set inactive=30 for $user (was: $inactive_days)"
                echo "PROOF: Executed 'chage --inactive 30 $user'"
                ((fixed_count++))
            else
                echo "✗ Failed to set inactive=30 for $user"
            fi
        else
            echo "✓ $user already compliant: $inactive_days"
            echo "PROOF: inactive=$inactive_days"
        fi
    done
    
    echo ""
    echo "Fixed $fixed_count out of $total_users users"
}

# Function for final verification
final_verification() {
    echo "Final Verification:"
    echo "==================="
    
    local all_good=true
    
    # Check /etc/default/useradd
    echo ""
    echo "1. Checking /etc/default/useradd:"
    if check_useradd; then
        echo "   ✓ Default setting is correct"
    else
        echo "   ✗ Default setting needs attention"
        all_good=false
    fi
    
    # Check user accounts
    echo ""
    echo "2. Checking user accounts:"
    if check_users; then
        echo "   ✓ All user accounts are compliant"
    else
        echo "   ✗ Some user accounts need attention"
        all_good=false
    fi
    
    return $([ "$all_good" = true ] && echo 0 || echo 1)
}

# Main remediation
echo "Initial Status Check:"
echo "====================="

useradd_ok=true
users_ok=true

if ! check_useradd; then
    useradd_ok=false
fi

echo ""

if ! check_users; then
    users_ok=false
fi

echo ""

if [ "$useradd_ok" = true ] && [ "$users_ok" = true ]; then
    echo "✓ No remediation needed - system is already compliant"
else
    echo "Remediation Required:"
    echo "===================="
    echo ""
    
    # Force automatic remediation for both areas
    echo "Applying automatic remediation..."
    echo ""
    
    if [ "$useradd_ok" = false ]; then
        fix_useradd
        echo ""
    fi
    
    # Always check and fix users if needed
    fix_users
    echo ""
    
    echo "✓ Applied remediation to all required areas"
fi

echo ""
echo "==================================================================="
echo "Final Verification with Proofs:"
echo "==================================================================="

if final_verification; then
    echo ""
    echo "SUCCESS: Inactive password lock is properly configured (30 days or less)"
    echo ""
    echo "Summary:"
    echo "  ✓ Default INACTIVE setting in /etc/default/useradd is 30"
    echo "  ✓ All user accounts have password inactivity set to 30 days or future date"
    echo "  ✓ System will automatically lock accounts after 30 days of inactivity"
else
    echo ""
    echo "WARNING: Some issues may require manual attention"
    echo ""
    echo "Manual commands:"
    echo "  To set default for new users: useradd -D -f 30"
    echo "  To set for existing user: chage --inactive 30 <username>"
    echo "  To check a user: chage -l <username>"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="