#!/usr/bin/env bash

# Script: 4.2.6.sh
# Item: 4.2.6 Ensure sshd Ciphers are configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.6.sh"
ITEM_NAME="4.2.6 Ensure sshd Ciphers are configured (Automated)"
DESCRIPTION="This remediation ensures SSH Ciphers directive is configured with strong ciphers in sshd_config."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH Ciphers configuration..."
echo ""

SSHD_CONFIG="/etc/ssh/sshd_config"

# Strong ciphers recommended by CIS
STRONG_CIPHERS="chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr"

if [ ! -f "$SSHD_CONFIG" ]; then
  echo "ERROR: $SSHD_CONFIG not found"
  exit 1
fi

# Check current Ciphers configuration
echo "Current Ciphers directive in $SSHD_CONFIG:"
current_ciphers=$(grep -Pi '^\s*Ciphers\s+' "$SSHD_CONFIG" || echo "Not configured")
echo "$current_ciphers"
echo ""

echo "Applying remediation..."
echo ""

# Backup sshd_config
cp "$SSHD_CONFIG" "${SSHD_CONFIG}.bak.$(date +%Y%m%d%H%M%S)"
echo " - Created backup of $SSHD_CONFIG"

# Remove any existing Ciphers directives (commented or uncommented)
sed -i '/^\s*#\?\s*Ciphers\s/d' "$SSHD_CONFIG"
echo " - Removed existing Ciphers directives"

# Find the line number of the first Match directive
match_line=$(grep -n "^Match" "$SSHD_CONFIG" | head -1 | cut -d: -f1 || echo "")

if [ -n "$match_line" ]; then
  # Insert Ciphers directive before Match
  sed -i "${match_line}i Ciphers $STRONG_CIPHERS" "$SSHD_CONFIG"
  echo " - Inserted 'Ciphers $STRONG_CIPHERS' before Match directive at line $match_line"
else
  # No Match directive, append to end
  echo "" >> "$SSHD_CONFIG"
  echo "Ciphers $STRONG_CIPHERS" >> "$SSHD_CONFIG"
  echo " - Appended 'Ciphers $STRONG_CIPHERS' to end of file"
fi

echo ""
echo " - SUCCESS: Applied Ciphers configuration"
echo ""

echo "Remediation of SSH Ciphers configuration complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

final_status_pass=true

echo ""
echo "1. VERIFYING CIPHERS DIRECTIVE IS SET:"
echo "--------------------------------------"

current_ciphers=$(grep -Pi '^\s*Ciphers\s+' "$SSHD_CONFIG" || true)

if [ -n "$current_ciphers" ]; then
  echo "PASS: Ciphers directive is configured"
  echo "PROOF:"
  echo "$current_ciphers"
  
  # Check if it contains strong ciphers
  if echo "$current_ciphers" | grep -q "chacha20-poly1305@openssh.com"; then
    echo "PASS: Strong ciphers are configured"
  else
    echo "WARNING: Ciphers may not include recommended strong algorithms"
    echo "Recommended: $STRONG_CIPHERS"
  fi
else
  echo "FAIL: Ciphers directive is NOT configured"
  final_status_pass=false
fi

echo ""
echo "2. VERIFYING NO WEAK CIPHERS ARE CONFIGURED:"
echo "--------------------------------------------"

weak_ciphers_found=false

# Check for weak ciphers
if echo "$current_ciphers" | grep -Pq "(3des|blowfish|cast128|arcfour|aes128-cbc|aes192-cbc|aes256-cbc)"; then
  echo "WARNING: Weak ciphers detected in configuration"
  echo "PROOF:"
  echo "$current_ciphers" | grep -Po "(3des|blowfish|cast128|arcfour|aes128-cbc|aes192-cbc|aes256-cbc)"
  weak_ciphers_found=true
fi

if [ "$weak_ciphers_found" = false ]; then
  echo "PASS: No weak ciphers (3des, blowfish, cast128, arcfour, cbc modes) detected"
else
  echo "FAIL: Weak ciphers should be removed from configuration"
fi

echo ""
echo "3. VERIFYING SSHD CONFIGURATION SYNTAX:"
echo "---------------------------------------"

if sshd -t 2>&1; then
  echo "PASS: SSHD configuration syntax is valid"
else
  echo "FAIL: SSHD configuration has syntax errors"
  echo "PROOF:"
  sshd -t 2>&1 || true
  final_status_pass=false
fi

echo ""
echo "4. RELOADING SSHD SERVICE:"
echo "-------------------------"

if systemctl reload-or-try-restart sshd.service 2>&1; then
  echo "PASS: SSHD service reloaded successfully"
else
  echo "FAIL: Failed to reload SSHD service"
  final_status_pass=false
fi

echo ""
echo "5. VERIFYING SSHD SERVICE STATUS:"
echo "---------------------------------"

if systemctl is-active sshd.service >/dev/null 2>&1; then
  echo "PASS: SSHD service is active"
  echo "PROOF:"
  systemctl status sshd.service --no-pager -l | head -10
else
  echo "FAIL: SSHD service is not active"
  final_status_pass=false
fi

echo ""
echo "6. TESTING ACTUAL CIPHERS IN USE:"
echo "---------------------------------"

echo "PROOF (sshd -T output for Ciphers):"
sshd -T | grep -i "^ciphers" || echo "Could not retrieve cipher configuration"

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
