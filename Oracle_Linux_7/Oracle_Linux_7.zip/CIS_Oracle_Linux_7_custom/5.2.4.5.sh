#!/usr/bin/env bash
# Script: 5.2.4.5.sh
# Item: 5.2.4.5 Ensure audit configuration files are 640 or more restrictive (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.5.sh"
ITEM_NAME="5.2.4.5 Ensure audit configuration files are 640 or more restrictive (Automated)"
DESCRIPTION="This remediation ensures audit configuration files have permissions of 640 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit configuration files permissions..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if /etc/audit directory exists
    if [ ! -d /etc/audit ]; then
        echo "FAIL: /etc/audit directory does not exist"
        echo "PROOF: Directory /etc/audit not found"
        return 1
    fi
    
    # Find audit configuration files with improper permissions
    improper_files=()
    while IFS= read -r -d '' file; do
        perms=$(stat -c "%a" "$file")
        # Check if permissions are more permissive than 640
        # More permissive means higher octal value or specific permission bits set
        if [ "$perms" -gt 640 ] || [ $((0$perms & 0137)) -ne 0 ]; then
            improper_files+=("$file:$perms")
        fi
    done < <(find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -print0 2>/dev/null)
    
    if [ ${#improper_files[@]} -gt 0 ]; then
        echo "FAIL: audit configuration files with improper permissions found"
        echo "PROOF: Files with permissions more permissive than 640:"
        for file_perm in "${improper_files[@]}"; do
            file=$(echo "$file_perm" | cut -d: -f1)
            perm=$(echo "$file_perm" | cut -d: -f2)
            echo "  $file: $perm"
        done
        return 1
    fi
    
    # Check if any audit configuration files exist
    config_files=()
    while IFS= read -r -d '' file; do
        config_files+=("$file")
    done < <(find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -print0 2>/dev/null)
    
    if [ ${#config_files[@]} -eq 0 ]; then
        echo "PASS: No audit configuration files found"
        echo "PROOF: No .conf or .rules files in /etc/audit/"
        return 0
    fi
    
    echo "PASS: audit configuration files permissions properly configured"
    echo "PROOF: All ${#config_files[@]} audit configuration files in /etc/audit/ have permissions 640 or more restrictive"
    return 0
}
# Function to fix
fix_audit_config_files_permissions() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure /etc/audit directory exists
    if [ ! -d /etc/audit ]; then
        echo " - Creating /etc/audit directory"
        mkdir -p /etc/audit
        chmod 750 /etc/audit
        chown root:root /etc/audit
    fi
    
    echo " - Checking audit configuration files permissions in /etc/audit/"
    
    # Find audit configuration files
    config_files=()
    while IFS= read -r -d '' file; do
        config_files+=("$file")
    done < <(find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -print0 2>/dev/null)
    
    if [ ${#config_files[@]} -eq 0 ]; then
        echo " - No audit configuration files found"
        return
    fi
    
    echo " - Found ${#config_files[@]} audit configuration files"
    
    # Check and fix permissions for each file
    fixed_files=0
    for file in "${config_files[@]}"; do
        current_perms=$(stat -c "%a" "$file")
        
        # Check if permissions need fixing
        if [ "$current_perms" -gt 640 ] || [ $((0$current_perms & 0137)) -ne 0 ]; then
            echo " - Fixing permissions for $file (was $current_perms)"
            chmod u-x,g-wx,o-rwx "$file"
            new_perms=$(stat -c "%a" "$file")
            echo " - New permissions for $file: $new_perms"
            ((fixed_files++))
        fi
    done
    
    if [ $fixed_files -eq 0 ]; then
        echo " - All audit configuration files already have correct permissions"
    else
        echo " - Fixed permissions for $fixed_files audit configuration files"
    fi
    
    # Run comprehensive permissions fix (command from the benchmark)
    echo " - Running comprehensive permissions fix"
    find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec chmod u-x,g-wx,o-rwx {} + 2>/dev/null || true
    
    # Ensure proper ownership for all audit configuration files
    echo " - Ensuring proper ownership for audit configuration files"
    find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec chown root:root {} + 2>/dev/null || true
    
    echo " - audit configuration files permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_config_files_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit configuration files permissions properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="