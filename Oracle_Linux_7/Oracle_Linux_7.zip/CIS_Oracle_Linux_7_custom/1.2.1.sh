#!/usr/bin/env bash

# Script: 1.2.1.sh
# Item: 1.2.1 Ensure GPG keys are configured (Manual)
# Description: Update your package manager GPG keys in accordance with site policy.
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="1.2.1.sh"
ITEM_NAME="1.2.1 Ensure GPG keys are configured (Manual)"
DESCRIPTION="Update your package manager GPG keys in accordance with site policy."
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to print detailed section header
print_section() {
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║ $1"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo ""
}

# Function to print status with color
print_status() {
    local status="$1"
    local message="$2"
    case "$status" in
        "PASS") echo "✓ PASS: $message" ;;
        "FAIL") echo "✗ FAIL: $message" ;;
        "WARN") echo "⚠ WARN: $message" ;;
        "INFO") echo "ℹ INFO: $message" ;;
        *) echo "  $message" ;;
    esac
}

# Function to check package signatures in detail
check_package_signatures() {
    print_section "DETAILED PACKAGE SIGNATURE ANALYSIS"
    
    if command -v rpm >/dev/null 2>&1; then
        echo "Analyzing RPM package signatures..."
        echo "===================================="
        
        # Count packages by signature status
        local total_packages=$(rpm -qa | wc -l)
        local unsigned_packages=$(rpm -qa --qf '%{NAME}-%{VERSION}-%{RELEASE} %{SIGPGP:pgpsig}\n' | grep -c "(none)" || true)
        local signed_packages=$((total_packages - unsigned_packages))
        
        print_status "INFO" "Total packages: $total_packages"
        print_status "INFO" "Signed packages: $signed_packages"
        print_status "INFO" "Unsigned packages: $unsigned_packages"
        
        if [ "$unsigned_packages" -gt 0 ]; then
            print_status "WARN" "Found $unsigned_packages unsigned packages"
            echo ""
            echo "Unsigned packages (first 10):"
            rpm -qa --qf '%{NAME}-%{VERSION}-%{RELEASE} %{SIGPGP:pgpsig}\n' | grep "(none)" | head -10
        fi
        
        # Check for specific signature issues
        echo ""
        echo "Checking for signature verification failures..."
        local bad_signatures=$(rpm -qa --checksig 2>&1 | grep -c "MISSING KEYS\|BAD signature" || true)
        if [ "$bad_signatures" -gt 0 ]; then
            print_status "FAIL" "Found $bad_signatures packages with bad or missing signatures"
            rpm -qa --checksig 2>&1 | grep -E "MISSING KEYS|BAD signature" | head -5
        else
            print_status "PASS" "No packages with bad signatures detected"
        fi
    fi
}

# Function to analyze repository configurations
analyze_repositories() {
    print_section "REPOSITORY CONFIGURATION ANALYSIS"
    
    if command -v yum >/dev/null 2>&1; then
        echo "YUM Repository Analysis:"
        echo "========================"
        
        # Check repository count and status
        local repo_count=$(yum repolist all 2>/dev/null | grep -c "repo id" || true)
        local enabled_repos=$(yum repolist enabled 2>/dev/null | grep -c "repo id" || true)
        
        print_status "INFO" "Total repositories: $repo_count"
        print_status "INFO" "Enabled repositories: $enabled_repos"
        
        # Check for repositories without GPG checking
        echo ""
        echo "Checking repository GPG settings..."
        local no_gpg_repos=0
        for repo in $(yum repolist all -q 2>/dev/null | awk '{print $1}' | grep -v "repo"); do
            local gpgcheck=$(yum config-manager --dump "$repo" 2>/dev/null | grep "gpgcheck" | awk -F'=' '{print $2}' | tr -d ' ' || echo "unknown")
            if [ "$gpgcheck" = "0" ] || [ "$gpgcheck" = "False" ]; then
                print_status "WARN" "Repository '$repo' has GPG checking disabled (gpgcheck=$gpgcheck)"
                no_gpg_repos=$((no_gpg_repos + 1))
            fi
        done
        
        if [ "$no_gpg_repos" -eq 0 ]; then
            print_status "PASS" "All repositories have GPG checking enabled"
        fi
        
        # List all repositories with their GPG status
        echo ""
        echo "Repository GPG Status:"
        echo "---------------------"
        yum repolist -v 2>/dev/null | grep -E "Repo-id|Repo-name|GPG-check" | head -20
    fi
}

# Function to perform detailed GPG key analysis
analyze_gpg_keys() {
    print_section "DETAILED GPG KEY ANALYSIS"
    
    # RPM-specific key analysis
    if command -v rpm >/dev/null 2>&1; then
        echo "RPM GPG Key Analysis:"
        echo "====================="
        
        # Get detailed key information
        local key_count=$(rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\n' 2>/dev/null | wc -l)
        print_status "INFO" "Found $key_count GPG keys in RPM database"
        
        if [ "$key_count" -gt 0 ]; then
            echo ""
            echo "Detailed GPG Key Information:"
            echo "-----------------------------"
            rpm -q gpg-pubkey --qf 'Key ID: %{VERSION}|%{RELEASE}\nInstall Date: %{INSTALLTIME:date}\nSummary: %{SUMMARY}\nDescription: %{DESCRIPTION}\n---\n' 2>/dev/null
            
            # Check for expired keys
            echo ""
            echo "Checking for key expiration..."
            # This would require more complex parsing of key details
            print_status "INFO" "Manual verification required for key expiration dates"
        fi
        
        # Check for Oracle Linux specific keys
        echo ""
        echo "Checking for Oracle Linux specific keys..."
        local oracle_keys=$(rpm -q gpg-pubkey --qf '%{SUMMARY}\n' 2>/dev/null | grep -c -i "oracle" || true)
        if [ "$oracle_keys" -gt 0 ]; then
            print_status "PASS" "Found $oracle_keys Oracle-related GPG keys"
        else
            print_status "WARN" "No Oracle-specific GPG keys found"
        fi
    fi
}

# Function to check system update status and security
check_update_status() {
    print_section "SYSTEM UPDATE AND SECURITY STATUS"
    
    if command -v yum >/dev/null 2>&1; then
        echo "Checking available security updates..."
        echo "======================================"
        
        # Check for security updates specifically
        if yum --security check-update >/dev/null 2>&1; then
            local security_updates=$(yum --security check-update 2>/dev/null | grep -c ".x86_64" || true)
            if [ "$security_updates" -gt 0 ]; then
                print_status "WARN" "Found $security_updates security updates available"
                echo ""
                echo "Security updates available (first 5):"
                yum --security check-update 2>/dev/null | grep ".x86_64" | head -5
            else
                print_status "PASS" "No security updates available - system is up to date"
            fi
        else
            print_status "INFO" "Security update check not available or requires different command"
            echo "Available updates:"
            yum check-update 2>/dev/null | grep ".x86_64" | head -10 || print_status "INFO" "No regular updates available"
        fi
    fi
}

# Function to verify package manager integrity
verify_package_manager() {
    print_section "PACKAGE MANAGER INTEGRITY VERIFICATION"
    
    local issues_found=0
    
    if command -v rpm >/dev/null 2>&1; then
        echo "Verifying RPM database integrity..."
        echo "=================================="
        
        # Check RPM database health
        if rpm -qa >/dev/null 2>&1; then
            print_status "PASS" "RPM database accessible and responsive"
        else
            print_status "FAIL" "RPM database has integrity issues"
            issues_found=$((issues_found + 1))
        fi
        
        # Verify a few critical packages
        echo ""
        echo "Verifying critical package signatures:"
        echo "-------------------------------------"
        local critical_packages=("kernel" "glibc" "openssl" "bash")
        for pkg in "${critical_packages[@]}"; do
            local pkg_version=$(rpm -q "$pkg" 2>/dev/null | head -1)
            if [ -n "$pkg_version" ] && [ "$pkg_version" != "package $pkg is not installed" ]; then
                if rpm --checksig "$pkg_version" >/dev/null 2>&1; then
                    print_status "PASS" "$pkg_version: Signature valid"
                else
                    print_status "FAIL" "$pkg_version: Signature INVALID or MISSING"
                    issues_found=$((issues_found + 1))
                fi
            else
                print_status "INFO" "Package $pkg not installed"
            fi
        done
    fi
    
    return $issues_found
}

# Main remediation function
{
    print_section "INITIAL GPG KEYS CONFIGURATION STATUS"
    
    echo "Checking current status of GPG keys configuration..."
    echo ""

    # Display current GPG keys status with more detail
    echo "Current GPG keys status:"
    echo "========================="
    
    # Check for APT (Debian/Ubuntu) with more detail
    if command -v apt-key >/dev/null 2>&1; then
        print_status "INFO" "APT package manager detected"
        echo "APT GPG Keys:"
        apt-key list 2>/dev/null | head -30 || print_status "WARN" "No GPG keys found or error listing APT keys"
    else
        print_status "INFO" "APT package manager not detected"
    fi
    
    echo ""
    
    # Check for RPM (RedHat/CentOS/Fedora) with more detail
    if command -v rpm >/dev/null 2>&1; then
        print_status "INFO" "RPM package manager detected"
        echo "RPM GPG Keys:"
        rpm -q gpg-pubkey --qf '%-30{NAME}-%{VERSION}-%{RELEASE} %{SUMMARY}\n' 2>/dev/null | head -15 || print_status "WARN" "No GPG keys found or error listing RPM keys"
    else
        print_status "INFO" "RPM package manager not detected"
    fi
    
    # Run detailed analyses
    analyze_gpg_keys
    analyze_repositories
    check_package_signatures
    check_update_status
    
    print_section "APPLYING REMEDIATION"
    
    echo "Applying remediation..."

    # Enhanced remediation functions
    update_apt_keys()
    {
        print_status "INFO" "Updating APT GPG keys..."
        if command -v apt-get >/dev/null 2>&1; then
            print_status "INFO" "Refreshing package lists..."
            if apt-get update >/dev/null 2>&1; then
                print_status "PASS" "Package lists refreshed successfully"
            else
                print_status "WARN" "Could not refresh package lists - checking for issues..."
                # Check for specific repository issues
                grep -r "deb" /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null | head -5
            fi
            
            # Check for specific repositories that might need key updates
            if [ -f /etc/apt/sources.list ] || [ -d /etc/apt/sources.list.d ]; then
                print_status "INFO" "Checking for repository key updates..."
                # This would typically be done manually based on site policy
                print_status "INFO" "Manual intervention required for specific repository keys"
            fi
        fi
    }

    update_rpm_keys()
    {
        print_status "INFO" "Updating RPM GPG keys..."
        if command -v rpm >/dev/null 2>&1; then
            print_status "INFO" "Checking RPM database integrity in detail..."
            local check_output
            check_output=$(rpm --checksig $(rpm -qa | head -20) 2>&1 || true)
            local error_count=$(echo "$check_output" | grep -c "MISSING KEYS\|BAD signature" || true)
            
            if [ "$error_count" -gt 0 ]; then
                print_status "FAIL" "Found $error_count packages with signature issues in sample check"
                echo "Sample of issues found:"
                echo "$check_output" | grep -E "MISSING KEYS|BAD signature" | head -5
            else
                print_status "PASS" "Sample package signature check passed"
            fi
            
            # Import any missing keys from configured repositories
            if command -v yum >/dev/null 2>&1; then
                print_status "INFO" "Refreshing YUM repository data..."
                if yum makecache >/dev/null 2>&1; then
                    print_status "PASS" "YUM repository cache updated successfully"
                else
                    print_status "WARN" "Could not refresh YUM repository data"
                fi
            elif command -v dnf >/dev/null 2>&1; then
                print_status "INFO" "Refreshing DNF repository data..."
                if dnf makecache >/dev/null 2>&1; then
                    print_status "PASS" "DNF repository cache updated successfully"
                else
                    print_status "WARN" "Could not refresh DNF repository data"
                fi
            fi
        fi
    }

    # Apply remediation based on detected package manager
    remediation_applied=false
    
    if command -v apt-key >/dev/null 2>&1 || command -v apt-get >/dev/null 2>&1; then
        print_section "APT-BASED SYSTEM REMEDIATION"
        print_status "INFO" "APT-based system detected - applying APT-specific remediation..."
        update_apt_keys
        remediation_applied=true
    fi
    
    if command -v rpm >/dev/null 2>&1; then
        print_section "RPM-BASED SYSTEM REMEDIATION"
        print_status "INFO" "RPM-based system detected - applying RPM-specific remediation..."
        update_rpm_keys
        remediation_applied=true
    fi

    if [ "$remediation_applied" = false ]; then
        print_status "WARN" "No supported package manager detected - manual configuration required"
    fi

    # Verify package manager integrity
    local integrity_issues=0
    verify_package_manager || integrity_issues=$?

    print_section "REMEDIATION COMPLETION"
    echo "Remediation of GPG keys configuration complete"
    if [ "$integrity_issues" -gt 0 ]; then
        print_status "WARN" "Found $integrity_issues package integrity issues during verification"
    fi

    # Final verification with comprehensive details
    print_section "FINAL STATUS VERIFICATION WITH DETAILED PROOFS"
    
    final_status_pass=true
    local issue_count=0
    
    # PROOF 1: Verify APT keys are configured
    print_section "VERIFYING APT GPG KEYS"
    if command -v apt-key >/dev/null 2>&1; then
        apt_key_count=$(apt-key list 2>/dev/null | grep -c "pub" || true)
        if [ "$apt_key_count" -gt 0 ]; then
            print_status "PASS" "$apt_key_count APT GPG keys configured"
            echo "Detailed APT Key Information:"
            apt-key list 2>/dev/null | head -20
        else
            print_status "FAIL" "No APT GPG keys found"
            issue_count=$((issue_count + 1))
            final_status_pass=false
        fi
    else
        print_status "INFO" "APT package manager not available"
    fi
    
    # PROOF 2: Verify RPM keys are configured
    print_section "VERIFYING RPM GPG KEYS"
    if command -v rpm >/dev/null 2>&1; then
        rpm_key_count=$(rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\n' 2>/dev/null | wc -l || true)
        if [ "$rpm_key_count" -gt 0 ]; then
            print_status "PASS" "$rpm_key_count RPM GPG keys configured"
            echo "Detailed RPM GPG Key Information:"
            rpm -q gpg-pubkey --qf 'Key: %{NAME}-%{VERSION}-%{RELEASE}\nDescription: %{DESCRIPTION}\nInstall Date: %{INSTALLTIME:date}\nSummary: %{SUMMARY}\n---\n' 2>/dev/null
        else
            print_status "FAIL" "No RPM GPG keys found"
            issue_count=$((issue_count + 1))
            final_status_pass=false
        fi
    else
        print_status "INFO" "RPM package manager not available"
    fi
    
    # PROOF 3: Verify package manager functionality with detailed output
    print_section "VERIFYING PACKAGE MANAGER FUNCTIONALITY"
    if command -v apt-get >/dev/null 2>&1; then
        print_status "INFO" "Testing APT package manager functionality..."
        apt_check_output=$(apt-get check 2>&1)
        if [ $? -eq 0 ]; then
            print_status "PASS" "APT package manager configured correctly"
            echo "Detailed output:"
            echo "$apt_check_output"
        else
            print_status "FAIL" "APT package manager has dependency or configuration issues"
            echo "Issue details:"
            echo "$apt_check_output"
            issue_count=$((issue_count + 1))
            final_status_pass=false
        fi
    elif command -v yum >/dev/null 2>&1; then
        print_status "INFO" "Testing YUM package manager functionality..."
        yum_check_output=$(yum check-update 2>&1)
        local yum_exit_code=$?
        if [ $yum_exit_code -eq 0 ] || [ $yum_exit_code -eq 100 ]; then
            print_status "PASS" "YUM package manager configured correctly"
            echo "Available updates count: $(echo \"$yum_check_output\" | grep -c \".x86_64\" || echo \"0\")"
        else
            print_status "FAIL" "YUM package manager has configuration issues"
            echo "Issue details:"
            echo "$yum_check_output"
            issue_count=$((issue_count + 1))
            final_status_pass=false
        fi
    fi
    
    # PROOF 4: Detailed manual verification requirements
    print_section "MANUAL VERIFICATION REQUIREMENTS"
    echo "This is a MANUAL control item. The following detailed verification is required:"
    echo ""
    echo "CRITICAL MANUAL CHECKS:"
    echo "======================="
    echo "1. KEY FINGERPRINT VERIFICATION:"
    echo "   • Compare GPG key fingerprints with trusted sources"
    echo "   • Verify Oracle Linux keys match official Oracle sources"
    echo "   • Check for any unauthorized or unexpected keys"
    echo ""
    echo "2. REPOSITORY SECURITY AUDIT:"
    echo "   • Review /etc/yum.repos.d/*.repo files"
    echo "   • Ensure gpgcheck=1 for all repositories"
    echo "   • Verify repository URLs are official and secure"
    echo "   • Remove any unofficial or unauthorized repositories"
    echo ""
    echo "3. KEY EXPIRATION CHECK:"
    echo "   • Check GPG key expiration dates"
    echo "   • Plan for key rotation before expiration"
    echo "   • Verify organizational key management policies"
    echo ""
    echo "4. PACKAGE SIGNATURE VERIFICATION:"
    echo "   • Spot-check critical package signatures"
    echo "   • Verify kernel, glibc, openssl signatures"
    echo "   • Ensure no unsigned packages in production"
    
    # Final summary
    print_section "COMPREHENSIVE ASSESSMENT SUMMARY"
    
    echo "ISSUES IDENTIFIED: $issue_count"
    echo "PACKAGE MANAGER INTEGRITY ISSUES: $integrity_issues"
    echo ""
    
    if [ "$final_status_pass" = true ] && [ "$issue_count" -eq 0 ] && [ "$integrity_issues" -eq 0 ]; then
        print_status "PASS" "Automated checks passed successfully"
        echo "NOTE: Manual verification still required per organizational policy"
    else
        print_status "WARN" "Found $issue_count configuration issues and $integrity_issues integrity issues"
        echo ""
        echo "RECOMMENDED ACTIONS:"
        echo "===================="
        if [ "$integrity_issues" -gt 0 ]; then
            echo "• Investigate package signature failures"
            echo "• Verify RPM database integrity"
            echo "• Consider reinstalling packages with bad signatures"
        fi
        if command -v rpm >/dev/null 2>&1 && [ "$(rpm -q gpg-pubkey | wc -l)" -eq 0 ]; then
            echo "• Import missing GPG keys for repositories"
        fi
        echo "• Perform manual verification as outlined above"
    fi

    echo ""
    echo "DETAILED FINDINGS:"
    echo "=================="
    echo "• Package manager: $(command -v yum || command -v dnf || command -v apt-get || echo 'Unknown')"
    echo "• GPG keys configured: $(rpm -q gpg-pubkey 2>/dev/null | wc -l || echo '0')"
    echo "• Repository count: $(yum repolist all 2>/dev/null | grep -c "repo id" || echo 'Unknown')"
    echo "• Security updates: $(yum --security check-update 2>/dev/null | grep -c ".x86_64" || echo 'Unknown')"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="