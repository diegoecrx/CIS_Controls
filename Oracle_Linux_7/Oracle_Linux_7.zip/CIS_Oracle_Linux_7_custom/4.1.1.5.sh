#!/usr/bin/env bash
# Script: 4.1.1.5.sh
# Item: 4.1.1.5 Ensure permissions on /etc/cron.weekly are configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.1.1.5.sh"
ITEM_NAME="4.1.1.5 Ensure permissions on /etc/cron.weekly are configured (Automated)"
DESCRIPTION="This remediation ensures proper ownership and permissions on /etc/cron.weekly directory."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/cron.weekly permissions configuration..."
    
    # Check if /etc/cron.weekly directory exists
    if [ ! -d /etc/cron.weekly ]; then
        echo "FAIL: /etc/cron.weekly directory does not exist"
        echo "PROOF: /etc/cron.weekly directory not found"
        return 1
    fi
    
    # Check ownership - must be root:root
    local current_owner=$(stat -c "%U:%G" /etc/cron.weekly 2>/dev/null)
    if [ "$current_owner" != "root:root" ]; then
        echo "FAIL: /etc/cron.weekly ownership is incorrect"
        echo "PROOF: Current ownership is $current_owner, should be root:root"
        return 1
    fi
    
    # Check permissions - must be 700 (og-rwx)
    local current_perms=$(stat -c "%a" /etc/cron.weekly 2>/dev/null)
    if [ "$current_perms" != "700" ]; then
        echo "FAIL: /etc/cron.weekly permissions are incorrect"
        echo "PROOF: Current permissions are $current_perms, should be 700"
        return 1
    fi
    
    # Additional verification using symbolic permissions
    local symbolic_perms=$(stat -c "%A" /etc/cron.weekly 2>/dev/null)
    if [[ ! "$symbolic_perms" =~ ^drwx------$ ]]; then
        echo "FAIL: /etc/cron.weekly symbolic permissions are incorrect"
        echo "PROOF: Current symbolic permissions are $symbolic_perms, should be drwx------"
        return 1
    fi
    
    echo "PASS: /etc/cron.weekly permissions properly configured"
    echo "PROOF: Ownership is root:root and permissions are 700 (drwx------)"
    return 0
}
# Function to fix
fix_cron_weekly_permissions() {
    echo "Applying fix..."
    
    # Check if /etc/cron.weekly exists
    if [ ! -d /etc/cron.weekly ]; then
        echo " - /etc/cron.weekly directory does not exist, creating it"
        mkdir -p /etc/cron.weekly
        echo " - Created /etc/cron.weekly directory"
    fi
    
    # Force remediation - always apply the required steps
    
    # Set ownership to root:root
    echo " - Setting ownership to root:root"
    chown root:root /etc/cron.weekly/
    
    # Set permissions to 700 (og-rwx)
    echo " - Setting permissions to 700 (og-rwx)"
    chmod 700 /etc/cron.weekly/
    
    # Verify the changes were applied
    echo " - Verifying permissions configuration"
    
    local final_owner=$(stat -c "%U:%G" /etc/cron.weekly 2>/dev/null)
    local final_perms=$(stat -c "%a" /etc/cron.weekly 2>/dev/null)
    
    if [ "$final_owner" = "root:root" ] && [ "$final_perms" = "700" ]; then
        echo " - Successfully configured /etc/cron.weekly permissions"
    else
        echo " - WARNING: Permissions may not have been set correctly"
        echo "   Final ownership: $final_owner"
        echo "   Final permissions: $final_perms"
    fi
    
    echo " - /etc/cron.weekly permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_cron_weekly_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: /etc/cron.weekly permissions properly configured"
        echo ""
        echo "Current directory status:"
        echo "------------------------"
        ls -ld /etc/cron.weekly
        echo ""
        echo "Detailed permissions:"
        echo "--------------------"
        stat /etc/cron.weekly | head -4
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Manual configuration required. Run these commands:"
        echo "chown root:root /etc/cron.weekly/"
        echo "chmod og-rwx /etc/cron.weekly/"
        echo ""
        echo "Current directory status:"
        echo "------------------------"
        ls -ld /etc/cron.weekly 2>/dev/null || echo "/etc/cron.weekly does not exist"
        echo ""
        echo "Verification commands:"
        echo "---------------------"
        echo "stat -c '%U:%G %a %A' /etc/cron.weekly"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="