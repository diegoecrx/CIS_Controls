#!/usr/bin/env bash
# Script: 5.1.2.6.sh
# Item: 5.1.2.6 Ensure journald log rotation is configured per site policy (Manual)
set -euo pipefail
SCRIPT_NAME="5.1.2.6.sh"
ITEM_NAME="5.1.2.6 Ensure journald log rotation is configured per site policy (Manual)"
DESCRIPTION="This remediation ensures journald log rotation parameters are configured in /etc/systemd/journald.conf according to site policy."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking /etc/systemd/journald.conf configuration..."
    
    conf_file="/etc/systemd/journald.conf"
    if [ ! -f "$conf_file" ]; then
        echo "FAIL: Configuration file does not exist"
        echo "PROOF: File not found"
        return 1
    fi
    
    # Check for presence of rotation parameters
    system_max_use=$(grep '^SystemMaxUse=' "$conf_file" || true)
    system_keep_free=$(grep '^SystemKeepFree=' "$conf_file" || true)
    runtime_max_use=$(grep '^RuntimeMaxUse=' "$conf_file" || true)
    runtime_keep_free=$(grep '^RuntimeKeepFree=' "$conf_file" || true)
    max_file_sec=$(grep '^MaxFileSec=' "$conf_file" || true)
    
    if [ -n "$system_max_use" ] && [ -n "$system_keep_free" ] && [ -n "$runtime_max_use" ] && [ -n "$runtime_keep_free" ] && [ -n "$max_file_sec" ]; then
        echo "PASS: All rotation parameters present"
        echo "PROOF (SystemMaxUse): $system_max_use"
        echo "PROOF (SystemKeepFree): $system_keep_free"
        echo "PROOF (RuntimeMaxUse): $runtime_max_use"
        echo "PROOF (RuntimeKeepFree): $runtime_keep_free"
        echo "PROOF (MaxFileSec): $max_file_sec"
        echo ""
        echo "NOTE: Verify these values comply with your site policy"
        return 0
    else
        echo "FAIL: Missing rotation parameters"
        echo "PROOF (SystemMaxUse): ${system_max_use:-Not configured}"
        echo "PROOF (SystemKeepFree): ${system_keep_free:-Not configured}"
        echo "PROOF (RuntimeMaxUse): ${runtime_max_use:-Not configured}"
        echo "PROOF (RuntimeKeepFree): ${runtime_keep_free:-Not configured}"
        echo "PROOF (MaxFileSec): ${max_file_sec:-Not configured}"
        return 1
    fi
}

# Function to fix with example values (manual adjustment needed per policy)
fix_journald_rotation() {
    echo "WARNING: This will configure example values. Adjust according to site policy!"
    echo "Example values being applied:"
    echo "  SystemMaxUse=1G      (Max disk space for system journals)"
    echo "  SystemKeepFree=2G    (Min free space for system journals)" 
    echo "  RuntimeMaxUse=100M   (Max disk space for runtime journals)"
    echo "  RuntimeKeepFree=200M (Min free space for runtime journals)"
    echo "  MaxFileSec=1month    (Max time to store journal files)"
    echo ""
    read -p "Continue with example configuration? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Aborted. Manual configuration required per site policy."
        exit 0
    fi
    
    echo "Applying example configuration (ADJUST VALUES PER SITE POLICY)..."
    
    conf_file="/etc/systemd/journald.conf"
    # Backup if exists
    if [ -f "$conf_file" ]; then
        backup_file="$conf_file.bak.$(date +%Y%m%d_%H%M%S)"
        cp "$conf_file" "$backup_file"
        echo " - Created backup: $backup_file"
    fi
    
    # Add or update lines with example values
    echo " - Configuring SystemMaxUse=1G"
    grep -q '^SystemMaxUse=' "$conf_file" && sed -i 's/^SystemMaxUse=.*/SystemMaxUse=1G/' "$conf_file" || echo "SystemMaxUse=1G" >> "$conf_file"
    
    echo " - Configuring SystemKeepFree=2G"
    grep -q '^SystemKeepFree=' "$conf_file" && sed -i 's/^SystemKeepFree=.*/SystemKeepFree=2G/' "$conf_file" || echo "SystemKeepFree=2G" >> "$conf_file"
    
    echo " - Configuring RuntimeMaxUse=100M"
    grep -q '^RuntimeMaxUse=' "$conf_file" && sed -i 's/^RuntimeMaxUse=.*/RuntimeMaxUse=100M/' "$conf_file" || echo "RuntimeMaxUse=100M" >> "$conf_file"
    
    echo " - Configuring RuntimeKeepFree=200M"
    grep -q '^RuntimeKeepFree=' "$conf_file" && sed -i 's/^RuntimeKeepFree=.*/RuntimeKeepFree=200M/' "$conf_file" || echo "RuntimeKeepFree=200M" >> "$conf_file"
    
    echo " - Configuring MaxFileSec=1month"
    grep -q '^MaxFileSec=' "$conf_file" && sed -i 's/^MaxFileSec=.*/MaxFileSec=1month/' "$conf_file" || echo "MaxFileSec=1month" >> "$conf_file"
    
    echo " - Example configuration applied"
    
    # Restart journald to apply
    echo " - Restarting systemd-journald"
    systemctl restart systemd-journald.service
    
    echo ""
    echo "IMPORTANT: Review and adjust values in /etc/systemd/journald.conf per your site policy"
    echo "See: man 5 journald.conf for detailed parameter information"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed (verify values comply with site policy)"
    else
        fix_journald_rotation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Journald rotation parameters configured"
        echo ""
        echo "NOTE: Values should be reviewed and adjusted per site policy"
    else
        echo "FAIL: Issues remain - manual configuration required"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="