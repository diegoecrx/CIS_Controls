#!/usr/bin/env bash
# Script: 4.5.2.3.sh
# Item: 4.5.2.3 Ensure system accounts are secured (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.2.3.sh"
ITEM_NAME="4.5.2.3 Ensure system accounts are secured (Automated)"
DESCRIPTION="This remediation ensures system accounts have nologin shell and are locked."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Get UID_MIN from /etc/login.defs
UID_MIN=$(awk '/^[[:space:]]*UID_MIN/{print $2}' /etc/login.defs)
NOLOGIN=$(command -v nologin)
# Function to check system accounts
check_system_accounts() {
    echo "Checking system accounts..."
    fail=false
    
    # Find system accounts (UID < UID_MIN and not root/halt/sync/shutdown/nfsnobody)
    while IFS=: read -r user _ uid _ _ _ shell; do
        if [[ ! "$user" =~ ^(root|halt|sync|shutdown|nfsnobody)$ ]]; then
            if [ "$uid" -lt "$UID_MIN" ] || [ "$uid" = "65534" ]; then
                if [ "$shell" != "$NOLOGIN" ]; then
                    echo "FAIL: System account $user has shell $shell (should be $NOLOGIN)"
                    fail=true
                else
                    # Check if account is locked
                    pass_status=$(grep "^$user:" /etc/shadow | awk -F: '{print $2}')
                    if [[ "$pass_status" == "!"* ]] || [[ "$pass_status" == "*"* ]]; then
                        echo "PASS: System account $user is secured (nologin shell, locked)"
                    else
                        echo "FAIL: System account $user has nologin but is not locked"
                        fail=true
                    fi
                fi
            fi
        fi
    done < /etc/passwd
    
    if [ "$fail" = false ]; then
        return 0
    else
        return 1
    fi
}
# Function to fix system accounts
fix_system_accounts() {
    echo "Fixing system accounts..."
    
    # Set nologin for all system accounts
    awk -F: -v uid_min="$UID_MIN" -v nologin="$NOLOGIN" \
        '($1!~/^(root|halt|sync|shutdown|nfsnobody)$/ && ($3<uid_min || $3 == 65534)) { print $1 }' \
        /etc/passwd | while read user; do
        usermod -s "$NOLOGIN" "$user"
        echo " - Set nologin shell for $user"
    done
    
    # Lock all accounts with nologin shell
    awk -F: '/nologin/ {print $1}' /etc/passwd | while read user; do
        if [ "$user" != "root" ]; then
            usermod -L "$user" 2>/dev/null || true
            echo " - Locked account $user"
        fi
    done
}
# Main remediation
{
    accounts_ok=true
    if ! check_system_accounts; then
        accounts_ok=false
    fi
    if [ "$accounts_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_system_accounts
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_system_accounts; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: System accounts are secured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
