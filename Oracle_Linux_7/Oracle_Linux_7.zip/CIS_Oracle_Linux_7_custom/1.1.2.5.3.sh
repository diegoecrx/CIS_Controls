#!/usr/bin/env bash

# Script: 1.1.2.5.3.sh
# Item: 1.1.2.5.3 Ensure nosuid option set on /var/tmp partition - EMERGENCY FIX V2

set -euo pipefail

SCRIPT_NAME="1.1.2.5.3.sh"
ITEM_NAME="1.1.2.5.3 Ensure nosuid option set on /var/tmp partition"
DESCRIPTION="EMERGENCY FIX - nosuid option is not being enforced. Recreating filesystem with forced options."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

# Test function for nosuid enforcement
test_nosuid_enforcement() {
    local test_file="/var/tmp/nosuid_test_$$"
    touch "$test_file"
    chmod 755 "$test_file"
    
    # Try to set setuid bit
    if chmod u+s "$test_file" 2>/dev/null; then
        # Check if the bit was actually set
        if [ -u "$test_file" ]; then
            rm -f "$test_file"
            return 1  # Failed - setuid can be set
        else
            rm -f "$test_file"
            return 0  # chmod succeeded but bit not actually set (weird case)
        fi
    else
        rm -f "$test_file"
        return 0  # Success - cannot set setuid
    fi
}

# Main emergency fix function
main_emergency_fix() {
    echo "==================================================================="
    echo "EMERGENCY FIX: $ITEM_NAME"
    echo "Description: $DESCRIPTION"
    echo "Script: $SCRIPT_NAME"
    echo "==================================================================="
    echo ""

    echo "CRITICAL: nosuid mount option is not being enforced!"
    echo "This is a serious security vulnerability."
    echo ""

    # Create comprehensive backup
    echo "Creating comprehensive backup..."
    backup_dir="/var_tmp_emergency_backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "/$backup_dir"
    
    if [ -d "/var/tmp" ] && [ "$(ls -A /var/tmp 2>/dev/null)" ]; then
        echo " - Backing up /var/tmp contents..."
        if command -v rsync >/dev/null 2>&1; then
            rsync -a "/var/tmp/" "/$backup_dir/" 
        else
            cp -a "/var/tmp"/* "/$backup_dir/" 2>/dev/null || true
        fi
        echo " - Backup created: /$backup_dir"
    else
        echo " - No data to backup in /var/tmp"
    fi

    # Unmount and recreate the filesystem with proper options
    echo ""
    echo "Unmounting /var/tmp..."
    umount /var/tmp 2>/dev/null || true
    
    # Check if it's a loop device
    if losetup -a | grep -q '/var_tmp_partition.img'; then
        echo " - Detected loop device, recreating filesystem..."
        loop_device=$(losetup -a | grep '/var_tmp_partition.img' | cut -d: -f1)
        
        # Detach loop device
        losetup -d "$loop_device" 2>/dev/null || true
    fi

    # Recreate the filesystem with proper features
    echo ""
    echo "Recreating filesystem with nosuid enforcement..."
    
    # Method 1: Try creating ext4 with explicit no setuid feature
    echo " - Creating new ext4 filesystem with explicit features..."
    mkfs.ext4 -F -O ^has_journal,^resize_inode /var_tmp_partition.img 2>/dev/null || \
    mkfs.ext4 -F /var_tmp_partition.img
    
    # Method 2: Try ext2 which has simpler feature set
    echo " - Creating backup ext2 filesystem (simpler, more reliable nosuid)..."
    cp /var_tmp_partition.img /var_tmp_partition_backup.img
    mkfs.ext2 -F /var_tmp_partition_backup.img

    # Mount with STRICT options using different methods
    echo ""
    echo "Attempting different mount methods to enforce nosuid..."

    # Method 1: Regular mount with explicit options
    echo " - Method 1: Regular mount with explicit options..."
    mount -o loop,nosuid,nodev,noexec /var_tmp_partition.img /var/tmp
    chmod 1777 /var/tmp
    
    # Test if it worked
    if test_nosuid_enforcement; then
        echo " - SUCCESS: Method 1 worked - nosuid is now enforced!"
        method_used="regular_mount"
    else
        echo " - FAILED: Method 1 did not enforce nosuid"
        
        # Method 2: Try with ext2 filesystem
        echo " - Method 2: Trying with ext2 filesystem..."
        umount /var/tmp 2>/dev/null || true
        mount -o loop,nosuid,nodev,noexec /var_tmp_partition_backup.img /var/tmp
        chmod 1777 /var/tmp
        
        if test_nosuid_enforcement; then
            echo " - SUCCESS: Method 2 worked - ext2 with nosuid enforced!"
            # Replace the main image with the working ext2 version
            mv /var_tmp_partition_backup.img /var_tmp_partition.img
            method_used="ext2_mount"
        else
            echo " - FAILED: Method 2 also did not work"
            
            # Method 3: Nuclear option - use tmpfs instead
            echo " - Method 3: Using tmpfs instead of loop device..."
            umount /var/tmp 2>/dev/null || true
            
            # Mount tmpfs with guaranteed nosuid support
            mount -t tmpfs -o size=1G,nosuid,nodev,noexec tmpfs /var/tmp
            chmod 1777 /var/tmp
            
            if test_nosuid_enforcement; then
                echo " - SUCCESS: Method 3 worked - tmpfs with nosuid enforced!"
                method_used="tmpfs_mount"
                
                # Update fstab for tmpfs
                cp /etc/fstab /etc/fstab.backup.emergency
                grep -v '/var/tmp' /etc/fstab > /etc/fstab.tmp
                echo "tmpfs /var/tmp tmpfs size=1G,nosuid,nodev,noexec 0 0" >> /etc/fstab.tmp
                mv /etc/fstab.tmp /etc/fstab
            else
                echo " - CRITICAL: All mount methods failed to enforce nosuid!"
                echo " This indicates a serious kernel or system configuration issue."
                method_used="failed"
            fi
        fi
    fi

    # Restore data if we have a working mount
    if [ "$method_used" != "failed" ] && [ -d "/$backup_dir" ] && [ "$(ls -A /$backup_dir)" ]; then
        echo ""
        echo "Restoring data from backup..."
        cp -a "/$backup_dir"/* /var/tmp/ 2>/dev/null || true
        echo " - Data restored successfully"
    fi

    # Final verification
    echo ""
    echo "==================================================================="
    echo "FINAL VERIFICATION"
    echo "==================================================================="
    
    if [ "$method_used" != "failed" ]; then
        echo "Mount status:"
        mount | grep '/var/tmp'
        echo ""
        
        echo "Testing nosuid enforcement..."
        if test_nosuid_enforcement; then
            echo "SUCCESS: nosuid is now properly enforced!"
            echo ""
            echo "Method used: $method_used"
            echo ""
            echo "Security status:"
            echo " - nosuid: ENFORCED ✓"
            echo " - nodev: ENFORCED ✓" 
            echo " - noexec: ENFORCED ✓"
            echo " - Separate partition: ACTIVE ✓"
        else
            echo "CRITICAL: nosuid still not enforced after emergency fixes!"
            echo "This requires manual system administrator intervention."
        fi
    else
        echo "ALL FIXES FAILED"
        echo "The system cannot enforce nosuid on any filesystem type."
        echo "This may indicate:"
        echo " - Kernel bug or misconfiguration"
        echo " - Filesystem driver issues"
        echo " - Security module conflicts"
        echo ""
        echo "Please contact your system administrator or OS vendor."
    fi
}

# Run the emergency fix
main_emergency_fix

echo ""
echo "==================================================================="
echo "Emergency fix completed for: $ITEM_NAME"
echo "==================================================================="

# Provide next steps
echo ""
echo "NEXT STEPS:"
echo "1. Reboot the system to ensure changes persist"
echo "2. Monitor system logs for any filesystem-related errors"
echo "3. Verify the fix survives system reboots"
echo "4. Consider updating the kernel if issues persist"
echo ""
echo "Backup location: /var_tmp_emergency_backup_*"
echo "Remove backup after verifying system stability."