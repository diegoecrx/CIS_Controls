#!/usr/bin/env bash
# Script: 3.3.1.sh
# Item: 3.3.1 Ensure ip forwarding is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.1.sh"
ITEM_NAME="3.3.1 Ensure ip forwarding is disabled (Automated)"
DESCRIPTION="This remediation ensures IP forwarding is disabled for both IPv4 and IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking IP forwarding configuration..."
    
    verification_passed=true
    
    # Check IPv4 forwarding runtime
    ipv4_forward_current=$(sysctl net.ipv4.ip_forward 2>/dev/null | awk '{print $3}')
    if [ "$ipv4_forward_current" != "0" ]; then
        echo "FAIL: IPv4 forwarding is enabled (runtime)"
        echo "PROOF: net.ipv4.ip_forward = $ipv4_forward_current"
        verification_passed=false
    else
        echo "PASS: IPv4 forwarding disabled (runtime)"
    fi
    
    # Check IPv4 forwarding in configuration files
    ipv4_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "0" ]; then
            echo "FAIL: IPv4 forwarding enabled in configuration: $line"
            ipv4_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.ip_forward' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$ipv4_config_issues" = false ]; then
        echo "PASS: IPv4 forwarding properly configured in files"
    fi
    
    # Check if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        # Check IPv6 forwarding runtime
        ipv6_forward_current=$(sysctl net.ipv6.conf.all.forwarding 2>/dev/null | awk '{print $3}')
        if [ "$ipv6_forward_current" != "0" ]; then
            echo "FAIL: IPv6 forwarding is enabled (runtime)"
            echo "PROOF: net.ipv6.conf.all.forwarding = $ipv6_forward_current"
            verification_passed=false
        else
            echo "PASS: IPv6 forwarding disabled (runtime)"
        fi
        
        # Check IPv6 forwarding in configuration files
        ipv6_config_issues=false
        while IFS= read -r line; do
            # Extract the value after the equals sign
            value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
            if [ "$value" != "0" ]; then
                echo "FAIL: IPv6 forwarding enabled in configuration: $line"
                ipv6_config_issues=true
                verification_passed=false
            fi
        done < <(grep -r '^\s*net\.ipv6\.conf\.all\.forwarding' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
        
        if [ "$ipv6_config_issues" = false ]; then
            echo "PASS: IPv6 forwarding properly configured in files"
        fi
    else
        echo "INFO: IPv6 not enabled, skipping IPv6 checks"
    fi
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: IP forwarding properly disabled"
        echo "PROOF: Both IPv4 and IPv6 forwarding set to 0"
        return 0
    else
        return 1
    fi
}
# Function to fix
fix_ip_forwarding() {
    echo "Applying fix..."
    
    # Configure IPv4 forwarding
    echo " - Configuring IPv4 forwarding"
    
    # Remove any existing IPv4 forwarding entries from all configuration files
    for config_file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
        if [ -f "$config_file" ]; then
            # Remove IPv4 forwarding entries (both =0 and =1)
            sed -i '/^\s*net\.ipv4\.ip_forward\s*=/d' "$config_file" 2>/dev/null || true
        fi
    done
    
    # Create dedicated configuration file for IPv4
    IPV4_CONF_FILE="/etc/sysctl.d/60-netipv4_sysctl.conf"
    # Add IPv4 forwarding configuration
    echo "# IP forwarding disable - Remediated by $SCRIPT_NAME" > "$IPV4_CONF_FILE"
    echo "# $(date)" >> "$IPV4_CONF_FILE"
    echo "net.ipv4.ip_forward = 0" >> "$IPV4_CONF_FILE"
    
    # Set active IPv4 kernel parameters
    sysctl -w net.ipv4.ip_forward=0 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    # Configure IPv6 forwarding if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        echo " - Configuring IPv6 forwarding"
        
        # Remove any existing IPv6 forwarding entries from all configuration files
        for config_file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
            if [ -f "$config_file" ]; then
                # Remove IPv6 forwarding entries (both =0 and =1)
                sed -i '/^\s*net\.ipv6\.conf\.all\.forwarding\s*=/d' "$config_file" 2>/dev/null || true
            fi
        done
        
        # Create dedicated configuration file for IPv6
        IPV6_CONF_FILE="/etc/sysctl.d/60-netipv6_sysctl.conf"
        # Add IPv6 forwarding configuration
        echo "# IPv6 forwarding disable - Remediated by $SCRIPT_NAME" > "$IPV6_CONF_FILE"
        echo "# $(date)" >> "$IPV6_CONF_FILE"
        echo "net.ipv6.conf.all.forwarding = 0" >> "$IPV6_CONF_FILE"
        
        # Set active IPv6 kernel parameters
        sysctl -w net.ipv6.conf.all.forwarding=0 >/dev/null 2>&1
        sysctl -w net.ipv6.route.flush=1 >/dev/null 2>&1
    fi
    
    # Reload all sysctl configurations
    sysctl -p >/dev/null 2>&1 || true
    if ls /etc/sysctl.d/*.conf >/dev/null 2>&1; then
        sysctl -p /etc/sysctl.d/*.conf >/dev/null 2>&1 || true
    fi
    
    echo " - IP forwarding configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip_forwarding
        # Allow time for changes to take effect
        sleep 2
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: IP forwarding properly disabled"
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Debug information:"
        echo "Runtime IPv4: $(sysctl net.ipv4.ip_forward 2>/dev/null || echo 'not set')"
        echo "Runtime IPv6: $(sysctl net.ipv6.conf.all.forwarding 2>/dev/null || echo 'not set')"
        echo ""
        echo "Configuration files:"
        grep -r 'net.ipv4.ip_forward' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No IPv4 configurations found"
        grep -r 'net.ipv6.conf.all.forwarding' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No IPv6 configurations found"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="