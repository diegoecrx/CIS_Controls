#!/usr/bin/env bash

# Script: 5.1.1.5.sh
# Item: 5.1.1.5 Ensure logging is configured (Manual)
# Description: Ensure comprehensive logging configuration in rsyslog according to site policy

set -euo pipefail

SCRIPT_NAME="5.1.1.5.sh"
ITEM_NAME="5.1.1.5 Ensure logging is configured (Manual)"
DESCRIPTION="Ensure comprehensive logging configuration in rsyslog according to site policy"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check if rsyslog is available
check_rsyslog_available() {
    if ! command -v rsyslogd >/dev/null 2>&1; then
        echo "rsyslog is not available on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi
    echo "✓ rsyslog is available"
}

# Function to check current configuration
check_current_config() {
    echo "Current rsyslog configuration:"
    echo "=============================="
    
    local main_config="/etc/rsyslog.conf"
    
    if [ -f "$main_config" ]; then
        echo "Main configuration file: $main_config"
        echo ""
        echo "Current logging rules:"
        echo "---------------------"
        grep -E '^[^#]' "$main_config" | grep -E '(^\$|^[a-z])' | head -20
    else
        echo "✗ Main configuration file not found: $main_config"
    fi
    
    echo ""
    
    # Check additional config files
    local override_dir="/etc/rsyslog.d"
    if [ -d "$override_dir" ]; then
        echo "Additional configuration files in $override_dir:"
        ls -la "$override_dir"/*.conf 2>/dev/null | head -5 || echo "  (none)"
    fi
}

# Function to check essential facilities
check_essential_facilities() {
    echo ""
    echo "Essential Facility Configuration Check:"
    echo "======================================"
    
    local facilities=(
        "authpriv.*"
        "mail.*" 
        "cron.*"
        "*.emerg"
        "kern.*"
        "daemon.*"
        "local0.*"
        "local1.*"
        "local2.*"
        "local3.*"
        "local4.*"
        "local5.*"
        "local6.*"
        "local7.*"
    )
    
    local missing=()
    local configured=()
    
    for facility in "${facilities[@]}"; do
        # Clean facility name for display
        local clean_facility=$(echo "$facility" | sed 's/\\.\\*//')
        
        if grep -r -E "^[^#]*${facility}" /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -q '/var/log'; then
            echo "✓ $clean_facility: configured"
            configured+=("$clean_facility")
        else
            echo "✗ $clean_facility: not configured"
            missing+=("$clean_facility")
        fi
    done
    
    echo ""
    echo "Summary: ${#configured[@]} configured, ${#missing[@]} missing"
    
    if [ ${#missing[@]} -gt 0 ]; then
        return 1
    else
        return 0
    fi
}

# Function to validate rsyslog syntax
validate_syntax() {
    echo ""
    echo "Syntax Validation:"
    echo "=================="
    
    if rsyslogd -N 1 >/dev/null 2>&1; then
        echo "✓ rsyslog configuration syntax is valid"
        return 0
    else
        echo "✗ rsyslog configuration syntax validation failed"
        echo ""
        echo "Running detailed validation:"
        rsyslogd -N 1
        return 1
    fi
}

# Function to fix common configuration issues
fix_configuration() {
    echo ""
    echo "Fixing Configuration Issues:"
    echo "============================"
    
    local main_config="/etc/rsyslog.conf"
    local backup_file="${main_config}.backup.$(date +%Y%m%d_%H%M%S)"
    
    # Create backup
    if [ -f "$main_config" ]; then
        cp "$main_config" "$backup_file"
        echo "✓ Created backup: $backup_file"
    fi
    
    # Fix syntax issues in listen.conf if it exists
    local listen_conf="/etc/rsyslog.d/listen.conf"
    if [ -f "$listen_conf" ]; then
        echo ""
        echo "Checking $listen_conf for syntax issues..."
        
        # Common fix: ensure proper module loading
        if grep -q "module(load=\"imtcp\")" "$listen_conf" && ! grep -q "input(type=\"imtcp\" port=\"514\")" "$listen_conf"; then
            echo "✓ Adding missing input configuration to $listen_conf"
            echo 'input(type="imtcp" port="514")' >> "$listen_conf"
        fi
    fi
    
    # Add missing essential configurations
    echo ""
    echo "Adding missing essential configurations..."
    
    # Create a supplemental configuration file
    local supplemental_conf="/etc/rsyslog.d/50-essential-facilities.conf"
    
    cat > "$supplemental_conf" << 'EOF'
# Essential logging facilities - Added by 5.1.1.5.sh
# Emergency messages to all users
*.emerg :omusrmsg:*

# Kernel messages
kern.* /var/log/kern.log

# Daemon messages  
daemon.* /var/log/daemon.log

# Local facilities
local0.* -/var/log/localmessages
local1.* -/var/log/localmessages
local2.* -/var/log/localmessages
local3.* -/var/log/localmessages
local4.* -/var/log/localmessages
local5.* -/var/log/localmessages
local6.* -/var/log/localmessages
local7.* -/var/log/localmessages

# Warnings and errors
*.=warning;*.=err -/var/log/warn
*.crit /var/log/warn
EOF

    echo "✓ Created supplemental configuration: $supplemental_conf"
    
    # Fix log file permissions
    echo ""
    echo "Fixing log file permissions..."
    
    local log_files=("/var/log/messages" "/var/log/secure" "/var/log/maillog" "/var/log/cron")
    
    for log_file in "${log_files[@]}"; do
        if [ -f "$log_file" ]; then
            # Set secure permissions (root:root, 640)
            chmod 640 "$log_file" 2>/dev/null && chown root:root "$log_file" 2>/dev/null
            local new_perm=$(stat -c "%a %U:%G" "$log_file" 2>/dev/null || echo "unknown")
            echo "✓ $log_file: $new_perm"
        fi
    done
}

# Function to restart rsyslog service
restart_rsyslog() {
    echo ""
    echo "Restarting rsyslog service:"
    echo "==========================="
    
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        if systemctl restart rsyslog; then
            echo "✓ rsyslog service restarted successfully"
            
            # Wait a moment for service to stabilize
            sleep 2
            
            if systemctl is-active rsyslog >/dev/null 2>&1; then
                echo "✓ rsyslog service is running"
                return 0
            else
                echo "✗ rsyslog service failed to start"
                return 1
            fi
        else
            echo "✗ Failed to restart rsyslog service"
            return 1
        fi
    else
        echo "⚠ rsyslog service is not active"
        return 1
    fi
}

# Function to test logging functionality
test_logging() {
    echo ""
    echo "Testing Logging Functionality:"
    echo "=============================="
    
    local test_id="TEST-$(date +%Y%m%d-%H%M%S)"
    local facilities=("authpriv" "cron" "daemon" "kern" "local0")
    
    for facility in "${facilities[@]}"; do
        local test_message="[$test_id] Test message from $facility facility"
        
        if logger -p "$facility.info" "$test_message" 2>/dev/null; then
            echo "✓ $facility: test message sent"
            
            # Give rsyslog a moment to process
            sleep 1
        else
            echo "⚠ $facility: failed to send test message"
        fi
    done
    
    echo ""
    echo "Check log files for test messages with ID: $test_id"
}

# Main execution
main() {
    echo "Initial System Check:"
    echo "===================="
    
    # Check if rsyslog is available
    check_rsyslog_available
    echo ""
    
    # Check service status
    echo "Service Status:"
    echo "==============="
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "✓ rsyslog service: active"
    else
        echo "✗ rsyslog service: inactive"
    fi
    
    if systemctl is-enabled rsyslog >/dev/null 2>&1; then
        echo "✓ rsyslog service: enabled at boot"
    else
        echo "✗ rsyslog service: disabled at boot"
    fi
    
    # Check current configuration
    check_current_config
    
    # Check essential facilities
    local needs_fix=false
    if ! check_essential_facilities; then
        needs_fix=true
    fi
    
    # Validate syntax
    if ! validate_syntax; then
        needs_fix=true
    fi
    
    echo ""
    
    # Apply fixes if needed
    if [ "$needs_fix" = true ]; then
        echo "Configuration Issues Detected:"
        echo "=============================="
        
        fix_configuration
        
        echo ""
        echo "Validating fixes..."
        
        # Restart service
        if restart_rsyslog; then
            # Re-validate syntax
            if validate_syntax; then
                echo ""
                echo "✓ Configuration fixes applied successfully"
            else
                echo ""
                echo "⚠ Configuration fixes applied but syntax validation still fails"
                echo "   Manual intervention may be required"
            fi
        else
            echo ""
            echo "✗ Failed to restart rsyslog service after configuration changes"
        fi
    else
        echo "✓ No configuration issues detected"
    fi
    
    echo ""
    echo "Final Configuration Check:"
    echo "=========================="
    
    # Final facility check
    check_essential_facilities
    
    echo ""
    echo "Service Status:"
    systemctl status rsyslog --no-pager | head -3
    
    # Test logging
    test_logging
    
    echo ""
    echo "Manual Configuration Notes:"
    echo "==========================="
    echo "This is a MANUAL control. Review and customize based on organizational needs:"
    echo ""
    echo "1. Essential facilities that should be configured:"
    echo "   - auth, authpriv.*    → /var/log/secure"
    echo "   - mail.*              → /var/log/mail (with sub-levels)"
    echo "   - cron.*              → /var/log/cron" 
    echo "   - kern.*              → /var/log/kern.log"
    echo "   - daemon.*            → /var/log/daemon.log"
    echo "   - *.emerg             → :omusrmsg:* (all users)"
    echo "   - local[0-7].*        → /var/log/localmessages"
    echo ""
    echo "2. Configuration files:"
    echo "   - /etc/rsyslog.conf (main configuration)"
    echo "   - /etc/rsyslog.d/*.conf (additional configurations)"
    echo ""
    echo "3. Validation commands:"
    echo "   rsyslogd -N 1        # Validate configuration syntax"
    echo "   systemctl status rsyslog    # Check service status"
    echo "   logger -p kern.info 'Test' # Test specific facility"
    echo ""
    echo "4. Log file locations to monitor:"
    echo "   /var/log/messages    # General messages"
    echo "   /var/log/secure      # Authentication logs"
    echo "   /var/log/cron        # Cron job logs"
    echo "   /var/log/maillog     # Mail logs"
    echo "   /var/log/kern.log    # Kernel logs (if configured)"
}

# Execute main function
main

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="