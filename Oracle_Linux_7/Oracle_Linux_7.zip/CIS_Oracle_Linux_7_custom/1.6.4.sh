#!/usr/bin/env bash
# Script: 1.6.4.sh
# Item: 1.6.4 Ensure access to /etc/motd is configured (Automated)
set -euo pipefail
SCRIPT_NAME="1.6.4.sh"
ITEM_NAME="1.6.4 Ensure access to /etc/motd is configured (Automated)"
DESCRIPTION="This remediation ensures access to /etc/motd is configured by setting permissions or removing the file."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/motd access..."
    motd_file=$(readlink -e /etc/motd 2>/dev/null || true)
    if [ -z "$motd_file" ]; then
        echo "PASS: /etc/motd does not exist"
        echo "PROOF: readlink -e /etc/motd returned empty"
        return 0
    fi
    owner=$(stat -c '%U:%G' "$motd_file")
    perm=$(stat -c '%a' "$motd_file")
    if [ "$owner" = "root:root" ] && [ "$perm" = "644" ] || [ "$perm" = "444" ]; then
        echo "PASS: Correct permissions and ownership"
        echo "PROOF: Owner $owner, Perm $perm"
        return 0
    else
        echo "FAIL: Incorrect permissions or ownership"
        echo "PROOF: Owner $owner, Perm $perm"
        return 1
    fi
}
# Function to fix
fix_motd() {
    echo "Applying fix..."
    motd_file=$(readlink -e /etc/motd 2>/dev/null || true)
    if [ -n "$motd_file" ]; then
        chown root:root "$motd_file"
        chmod u-x,go-wx "$motd_file"
        echo " - Set permissions on $motd_file"
    else
        echo " - No file to fix"
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_motd
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Access configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="