#!/usr/bin/env bash

# Script: 4.5.3.3.sh
# Item: 4.5.3.3 Ensure default user umask is configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.5.3.3.sh"
ITEM_NAME="4.5.3.3 Ensure default user umask is configured (Automated)"
DESCRIPTION="This remediation ensures default user umask is 027 or more restrictive."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check if umask is restrictive enough
is_restrictive_umask() {
    local umask_value="$1"
    
    # Check if umask is 0027, 027, or more restrictive
    case "$umask_value" in
        "0027"|"027"|"0077"|"077"|"0037"|"037"|"0057"|"057"|"0067"|"067"|"0070"|"070"|"0071"|"071"|"0072"|"072"|"0073"|"073"|"0074"|"074"|"0075"|"075"|"0076"|"076")
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# Function to check current umask settings
check_umask_settings() {
    echo "Checking umask settings in system files..."
    echo ""
    
    local l_output="" l_output2=""
    local compliant=true
    
    # Check files that should have restrictive umask
    local check_files=(
        "/etc/profile"
        "/etc/bashrc" 
        "/etc/bash.bashrc"
        "/etc/login.defs"
        "/etc/default/login"
    )
    
    # Check /etc/profile.d/*.sh files
    while IFS= read -r -d $'\0' l_file; do
        check_files+=("$l_file")
    done < <(find /etc/profile.d/ -type f -name '*.sh' -print0 2>/dev/null || true)
    
    # Check each file
    for l_file in "${check_files[@]}"; do
        if [ -f "$l_file" ]; then
            echo "Checking: $l_file"
            
            # Look for umask settings
            if grep -E '^[[:space:]]*umask[[:space:]]+[0-9]{3,4}' "$l_file" > /dev/null 2>&1; then
                local umask_line=$(grep -E '^[[:space:]]*umask[[:space:]]+[0-9]{3,4}' "$l_file" | head -1)
                local umask_value=$(echo "$umask_line" | awk '{print $2}')
                
                if is_restrictive_umask "$umask_value"; then
                    echo "  ✓ Restrictive umask found: $umask_value"
                    l_output="$l_output\n - $l_file: umask $umask_value (correct)"
                else
                    echo "  ✗ Non-restrictive umask: $umask_value"
                    l_output2="$l_output2\n - $l_file: umask $umask_value (should be 027 or more restrictive)"
                    compliant=false
                fi
            elif grep -E '^[[:space:]]*UMASK[[:space:]]+[0-9]{3,4}' "$l_file" > /dev/null 2>&1; then
                local umask_line=$(grep -E '^[[:space:]]*UMASK[[:space:]]+[0-9]{3,4}' "$l_file" | head -1)
                local umask_value=$(echo "$umask_line" | awk '{print $2}')
                
                if is_restrictive_umask "$umask_value"; then
                    echo "  ✓ Restrictive UMASK found: $umask_value"
                    l_output="$l_output\n - $l_file: UMASK $umask_value (correct)"
                else
                    echo "  ✗ Non-restrictive UMASK: $umask_value"
                    l_output2="$l_output2\n - $l_file: UMASK $umask_value (should be 027 or more restrictive)"
                    compliant=false
                fi
            else
                echo "  ⓘ No umask setting found"
            fi
        fi
    done
    
    # Check PAM configuration
    local pam_file="/etc/pam.d/postlogin"
    if [ -f "$pam_file" ]; then
        echo "Checking: $pam_file"
        if grep -E 'pam_umask\.so.*umask=0?[0-9]{3}' "$pam_file" > /dev/null 2>&1; then
            local pam_line=$(grep -E 'pam_umask\.so.*umask=0?[0-9]{3}' "$pam_file")
            local umask_value=$(echo "$pam_line" | grep -o 'umask=0\?[0-9]\{3\}' | cut -d= -f2)
            
            if is_restrictive_umask "$umask_value"; then
                echo "  ✓ Restrictive PAM umask found: $umask_value"
                l_output="$l_output\n - $pam_file: umask $umask_value (correct)"
            else
                echo "  ✗ Non-restrictive PAM umask: $umask_value"
                l_output2="$l_output2\n - $pam_file: umask $umask_value (should be 027 or more restrictive)"
                compliant=false
            fi
        else
            echo "  ⓘ No pam_umask setting found"
        fi
    fi
    
    echo ""
    
    # Print summary
    if [ -n "$l_output" ]; then
        echo "Correct configurations:"
        echo -e "$l_output"
        echo ""
    fi
    
    if [ -n "$l_output2" ]; then
        echo "Issues found:"
        echo -e "$l_output2"
        echo ""
        return 1
    fi
    
    if [ "$compliant" = true ]; then
        echo "✓ All umask settings are properly configured"
        return 0
    else
        return 1
    fi
}

# Function to fix umask settings
fix_umask_settings() {
    echo "Fixing umask settings..."
    echo ""
    
    # Remove or comment non-restrictive umask settings
    local files_to_fix=(
        "/etc/profile"
        "/etc/bashrc"
        "/etc/bash.bashrc"
    )
    
    for file in "${files_to_fix[@]}"; do
        if [ -f "$file" ]; then
            echo "Processing: $file"
            # Comment out any existing umask lines that are not restrictive
            if sed -i.bak.$(date +%Y%m%d) -E '/^[[:space:]]*umask[[:space:]]+[0-9]{3,4}/{
                /^[[:space:]]*umask[[:space:]]+(0027|027|0077|077|0037|037|0057|057|0067|067|0070|070|0071|071|0072|072|0073|073|0074|074|0075|075|0076|076)/b
                s/^/# & # Fixed by 4.5.3.3.sh - /
            }' "$file" 2>/dev/null; then
                echo "  ✓ Commented non-restrictive umask settings"
            fi
        fi
    done
    
    # Process /etc/profile.d/*.sh files
    if [ -d /etc/profile.d ]; then
        for file in /etc/profile.d/*.sh; do
            if [ -f "$file" ]; then
                echo "Processing: $file"
                if sed -i.bak.$(date +%Y%m%d) -E '/^[[:space:]]*umask[[:space:]]+[0-9]{3,4}/{
                    /^[[:space:]]*umask[[:space:]]+(0027|027|0077|077|0037|037|0057|057|0067|067|0070|070|0071|071|0072|072|0073|073|0074|074|0075|075|0076|076)/b
                    s/^/# & # Fixed by 4.5.3.3.sh - /
                }' "$file" 2>/dev/null; then
                    echo "  ✓ Commented non-restrictive umask settings"
                fi
            fi
        done
    fi
    
    # Update /etc/login.defs
    if [ -f /etc/login.defs ]; then
        echo "Processing: /etc/login.defs"
        if sed -i.bak.$(date +%Y%m%d) 's/^[[:space:]]*UMASK[[:space:]]\+[0-9]\+/UMASK 027/' /etc/login.defs 2>/dev/null; then
            echo "  ✓ Updated UMASK to 027"
        else
            # Add UMASK if it doesn't exist
            if ! grep -q '^[[:space:]]*UMASK' /etc/login.defs; then
                echo "UMASK 027" >> /etc/login.defs
                echo "  ✓ Added UMASK 027"
            fi
        fi
    fi
    
    # Ensure umask is set in system-wide profile
    local umask_file="/etc/profile.d/50-systemwide_umask.sh"
    echo "Creating: $umask_file"
    cat > "$umask_file" << 'EOF'
#!/bin/bash
# Set system-wide umask - Created by 4.5.3.3.sh
umask 027
EOF
    chmod 644 "$umask_file"
    echo "  ✓ Created system-wide umask configuration"
    
    echo ""
    echo "✓ Applied all umask fixes"
}

# Function for final verification
final_verification() {
    echo "Final Verification:"
    echo "==================="
    echo ""
    
    if check_umask_settings; then
        echo ""
        echo "SUCCESS: Default user umask is properly configured to 027 or more restrictive"
        return 0
    else
        echo ""
        echo "WARNING: Some umask settings may still need attention"
        return 1
    fi
}

# Main remediation
echo "Initial Status Check:"
echo "====================="

if check_umask_settings; then
    echo ""
    echo "✓ No remediation needed - system is already compliant"
else
    echo ""
    echo "Remediation Required:"
    echo "===================="
    echo ""
    
    # Create backup
    echo "Creating backups of configuration files..."
    mkdir -p /etc/backup.umask.$(date +%Y%m%d_%H%M%S)
    cp /etc/profile /etc/bashrc /etc/login.defs /etc/backup.umask.*/ 2>/dev/null || true
    echo "✓ Backups created"
    echo ""
    
    fix_umask_settings
fi

echo ""
echo "==================================================================="
echo "Final Verification with Proofs:"
echo "==================================================================="

if final_verification; then
    echo ""
    echo "Summary:"
    echo "  ✓ System-wide umask is set to 027 or more restrictive"
    echo "  ✓ Configuration files have been updated"
    echo "  ✓ New users will get correct umask settings"
    echo ""
    echo "The system is now configured with secure default umask settings."
else
    echo ""
    echo "Note: Manual verification may be required for some shell configurations."
    echo "If other shells are used, ensure their configuration files also set umask 027."
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="