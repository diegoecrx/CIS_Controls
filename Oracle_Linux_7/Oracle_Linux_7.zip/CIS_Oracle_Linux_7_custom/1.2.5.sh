#!/usr/bin/env bash

# Script: 1.2.5.sh
# Item: 1.2.5 Ensure updates, patches, and additional security software are installed (Manual)
# Description: "Use your package manager to update all packages on the system according to site
# policy.
# The following command will install all available updates:
# # yum update
# Once the update process is complete, verify if reboot is required to load changes.
# needs-restarting -r"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="1.2.5.sh"
ITEM_NAME="1.2.5 Ensure updates, patches, and additional security software are installed (Manual)"
DESCRIPTION="Use your package manager to update all packages on the system according to site policy."
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current status of system updates and patches..."
    echo ""

    # Display current update status
    echo "Current system update status:"
    echo "============================="
    
    # Check for APT (Debian/Ubuntu)
    if command -v apt-get >/dev/null 2>&1; then
        echo "APT package manager detected"
        echo "---------------------------"
        echo "Available updates:"
        apt list --upgradable 2>/dev/null | head -10 || echo "No available updates or error checking updates"
        
        echo ""
        echo "Security updates:"
        if command -v unattended-upgrade >/dev/null 2>&1; then
            unattended-upgrade --dry-run 2>/dev/null | grep -i "security" | head -5 || echo "No security updates configured or available"
        else
            echo "unattended-upgrades not installed"
        fi
        
        echo ""
        echo "Last update check:"
        stat /var/lib/apt/periodic/update-success-stamp 2>/dev/null | grep "Modify" || echo "No recent update check found"
    else
        echo "APT package manager not detected"
    fi
    
    echo ""
    
    # Check for RPM (RedHat/CentOS/Fedora)
    if command -v rpm >/dev/null 2>&1; then
        echo "RPM package manager detected"
        echo "---------------------------"
        
        if command -v yum >/dev/null 2>&1; then
            echo "YUM available updates:"
            yum check-update --security 2>/dev/null | head -10 || echo "No security updates available or error checking updates"
        fi
        
        if command -v dnf >/dev/null 2>&1; then
            echo ""
            echo "DNF available updates:"
            dnf check-update --security 2>/dev/null | head -10 || echo "No security updates available or error checking updates"
        fi
        
        echo ""
        echo "Security update information:"
        if command -v yum >/dev/null 2>&1; then
            yum updateinfo summary 2>/dev/null | head -10 || echo "No update info available"
        elif command -v dnf >/dev/null 2>&1; then
            dnf updateinfo summary 2>/dev/null | head -10 || echo "No update info available"
        fi
    else
        echo "RPM package manager not detected"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    update_apt_system()
    {
        echo " - Updating APT package database..."
        if apt-get update >/dev/null 2>&1; then
            echo " - SUCCESS: Package database updated"
        else
            echo " - WARNING: Could not update package database"
            return 1
        fi
        
        echo " - Checking for available updates..."
        update_count=$(apt list --upgradable 2>/dev/null | wc -l || true)
        if [ "$update_count" -gt 1 ]; then
            echo " - Found $((update_count-1)) packages with available updates"
            echo " - NOTE: Manual approval required for package updates"
            echo " - To apply updates manually, run: apt-get upgrade"
            echo " - For security updates only: unattended-upgrade --dry-run"
        else
            echo " - SUCCESS: System is up to date"
        fi
    }

    update_rpm_system()
    {
        echo " - Checking for available RPM updates..."
        
        if command -v dnf >/dev/null 2>&1; then
            update_count=$(dnf check-update 2>/dev/null | wc -l || true)
            if [ "$update_count" -gt 1 ]; then
                echo " - Found $((update_count-1)) packages with available updates"
                echo " - NOTE: Manual approval required for package updates"
                echo " - To apply updates manually, run: dnf update"
                echo " - For security updates only: dnf update --security"
            else
                echo " - SUCCESS: System is up to date"
            fi
        elif command -v yum >/dev/null 2>&1; then
            update_count=$(yum check-update 2>/dev/null | wc -l || true)
            if [ "$update_count" -gt 1 ]; then
                echo " - Found $((update_count-1)) packages with available updates"
                echo " - NOTE: Manual approval required for package updates"
                echo " - To apply updates manually, run: yum update"
                echo " - For security updates only: yum update --security"
            else
                echo " - SUCCESS: System is up to date"
            fi
        fi
    }

    check_reboot_required()
    {
        echo " - Checking if system reboot is required..."
        
        # Check for various reboot indicators
        reboot_required=false
        
        # Check if kernel was updated
        if [ -f /var/run/reboot-required ]; then
            echo " - REBOOT REQUIRED: Kernel or critical system component updated"
            cat /var/run/reboot-required 2>/dev/null || true
            reboot_required=true
        fi
        
        # Check for needs-restarting (RHEL/CentOS)
        if command -v needs-restarting >/dev/null 2>&1; then
            echo " - Checking for services needing restart..."
            needs-restarting -r >/dev/null 2>&1 && {
                echo " - REBOOT REQUIRED: System needs restart to complete updates"
                reboot_required=true
            } || echo " - No reboot required according to needs-restarting"
        fi
        
        # Check for running services using old libraries
        if command -v lsof >/dev/null 2>&1; then
            old_libs=$(lsof +L1 2>/dev/null | grep -v "COMMAND" | wc -l || true)
            if [ "$old_libs" -gt 0 ]; then
                echo " - WARNING: $old_libs processes using deleted library files"
            fi
        fi
        
        if [ "$reboot_required" = false ]; then
            echo " - No immediate reboot required"
        fi
    }

    # Apply remediation based on detected package manager
    remediation_applied=false
    
    if command -v apt-get >/dev/null 2>&1; then
        echo ""
        echo "APT-based system detected - checking for updates..."
        update_apt_system
        remediation_applied=true
    fi
    
    if command -v rpm >/dev/null 2>&1; then
        echo ""
        echo "RPM-based system detected - checking for updates..."
        update_rpm_system
        remediation_applied=true
    fi

    # Always check for reboot requirement
    echo ""
    check_reboot_required

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No supported package manager detected - manual update required"
    fi

    echo ""
    echo "Remediation of system updates complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify available updates
    echo ""
    echo "1. VERIFYING AVAILABLE UPDATES:"
    echo "-------------------------------"
    if command -v apt-get >/dev/null 2>&1; then
        echo "APT available updates:"
        update_count=$(apt list --upgradable 2>/dev/null | wc -l || true)
        if [ "$update_count" -le 1 ]; then
            echo "PASS: No pending updates available"
            echo "PROOF (apt list --upgradable): System is up to date"
        else
            echo "WARNING: $((update_count-1)) updates pending"
            echo "PROOF (first 5 available updates):"
            apt list --upgradable 2>/dev/null | head -6
            final_status_pass=false
        fi
    elif command -v dnf >/dev/null 2>&1; then
        echo "DNF available updates:"
        if dnf check-update >/dev/null 2>&1; then
            update_count=$(dnf check-update 2>/dev/null | wc -l || true)
            if [ "$update_count" -le 1 ]; then
                echo "PASS: No pending updates available"
                echo "PROOF (dnf check-update): System is up to date"
            else
                echo "WARNING: $((update_count-1)) updates pending"
                echo "PROOF (first 5 available updates):"
                dnf check-update 2>/dev/null | head -6
                final_status_pass=false
            fi
        else
            echo "PASS: No pending updates available"
            echo "PROOF (dnf check-update): System is up to date"
        fi
    elif command -v yum >/dev/null 2>&1; then
        echo "YUM available updates:"
        if yum check-update >/dev/null 2>&1; then
            update_count=$(yum check-update 2>/dev/null | wc -l || true)
            if [ "$update_count" -le 1 ]; then
                echo "PASS: No pending updates available"
                echo "PROOF (yum check-update): System is up to date"
            else
                echo "WARNING: $((update_count-1)) updates pending"
                echo "PROOF (first 5 available updates):"
                yum check-update 2>/dev/null | head -6
                final_status_pass=false
            fi
        else
            echo "PASS: No pending updates available"
            echo "PROOF (yum check-update): System is up to date"
        fi
    fi
    
    # PROOF 2: Verify security updates
    echo ""
    echo "2. VERIFYING SECURITY UPDATES:"
    echo "------------------------------"
    if command -v unattended-upgrade >/dev/null 2>&1; then
        echo "APT security updates:"
        unattended-upgrade --dry-run 2>/dev/null | grep -i "packages will be installed" || echo "No security updates pending"
    elif command -v dnf >/dev/null 2>&1; then
        echo "DNF security updates:"
        dnf updateinfo list security 2>/dev/null | head -5 || echo "No security updates available"
    elif command -v yum >/dev/null 2>&1; then
        echo "YUM security updates:"
        yum updateinfo list security 2>/dev/null | head -5 || echo "No security updates available"
    else
        echo "Security update tool not available"
    fi
    
    # PROOF 3: Verify reboot requirement
    echo ""
    echo "3. VERIFYING REBOOT REQUIREMENT:"
    echo "--------------------------------"
    reboot_required=false
    if [ -f /var/run/reboot-required ]; then
        echo "REBOOT REQUIRED: System restart needed"
        echo "PROOF (/var/run/reboot-required):"
        cat /var/run/reboot-required
        reboot_required=true
        final_status_pass=false
    elif command -v needs-restarting >/dev/null 2>&1; then
        if needs-restarting -r >/dev/null 2>&1; then
            echo "REBOOT REQUIRED: System restart needed (needs-restarting -r)"
            reboot_required=true
            final_status_pass=false
        else
            echo "PASS: No reboot required"
            echo "PROOF (needs-restarting -r): System does not require reboot"
        fi
    else
        echo "INFO: Reboot check tools not available"
        echo "Manual check required for kernel updates and service restarts"
    fi
    
    # PROOF 4: System uptime and kernel information
    echo ""
    echo "4. SYSTEM UPTIME AND KERNEL INFORMATION:"
    echo "----------------------------------------"
    echo "System uptime:"
    uptime
    echo ""
    echo "Current kernel version:"
    uname -r
    echo ""
    echo "Installed kernel packages:"
    if command -v dpkg >/dev/null 2>&1; then
        dpkg -l | grep linux-image | head -3
    elif command -v rpm >/dev/null 2>&1; then
        rpm -qa | grep kernel | head -3
    fi
    
    # PROOF 5: Manual verification steps reminder
    echo ""
    echo "5. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review and approve pending updates according to change management policy"
    echo "• Schedule maintenance windows for update installation"
    echo "• Test updates in non-production environment first"
    echo "• Ensure backups are current before applying updates"
    echo "• Coordinate reboots with stakeholders"
    echo ""
    echo "MANUAL UPDATE COMMANDS:"
    echo "APT Systems:"
    echo "  apt-get update && apt-get upgrade"
    echo "  unattended-upgrades (for automated security updates)"
    echo "RPM Systems:"
    echo "  yum update OR dnf update"
    echo "  yum update --security OR dnf update --security"
    echo ""
    echo "REBOOT VERIFICATION:"
    echo "  needs-restarting -r (RHEL/CentOS)"
    echo "  check /var/run/reboot-required (Debian/Ubuntu)"

    if [ "$final_status_pass" = true ] && [ "$reboot_required" = false ]; then
        echo ""
        echo "SUCCESS: System update verification completed"
        echo "NOTE: Manual review and approval required before applying updates"
    else
        echo ""
        echo "WARNING: Updates pending or reboot required - manual intervention needed"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="