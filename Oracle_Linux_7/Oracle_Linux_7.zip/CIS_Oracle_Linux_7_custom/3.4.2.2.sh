#!/usr/bin/env bash
# Script: 3.4.2.2.sh
# Item: 3.4.2.2 Ensure firewalld service enabled and running (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.2.2.sh"
ITEM_NAME="3.4.2.2 Ensure firewalld service enabled and running (Automated)"
DESCRIPTION="This remediation ensures firewalld service is enabled and running."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking firewalld service status..."
    
    # Check if firewalld package is installed
    if ! rpm -q firewalld >/dev/null 2>&1; then
        echo "FAIL: firewalld package is not installed"
        echo "PROOF: rpm -q firewalld returned no package found"
        return 1
    fi
    
    # Check if firewalld service is masked
    if systemctl is-masked firewalld >/dev/null 2>&1; then
        echo "FAIL: firewalld service is masked"
        echo "PROOF: systemctl is-masked firewalld shows masked"
        return 1
    fi
    
    # Check if firewalld service is enabled
    if ! systemctl is-enabled firewalld >/dev/null 2>&1; then
        echo "FAIL: firewalld service is not enabled"
        echo "PROOF: systemctl is-enabled firewalld shows disabled"
        return 1
    fi
    
    # Check if firewalld service is running
    if ! systemctl is-active firewalld >/dev/null 2>&1; then
        echo "FAIL: firewalld service is not running"
        echo "PROOF: systemctl is-active firewalld shows inactive"
        return 1
    fi
    
    echo "PASS: firewalld service properly enabled and running"
    echo "PROOF: firewalld is enabled and active"
    return 0
}
# Function to fix
fix_firewalld_service() {
    echo "Applying fix..."
    
    # Check if firewalld package is installed
    if ! rpm -q firewalld >/dev/null 2>&1; then
        echo " - Installing firewalld package"
        yum install -y firewalld
    fi
    
    # Unmask firewalld service if masked
    if systemctl is-masked firewalld >/dev/null 2>&1; then
        echo " - Unmasking firewalld service"
        systemctl unmask firewalld
    fi
    
    # Enable and start firewalld service
    if ! systemctl is-enabled firewalld >/dev/null 2>&1 || ! systemctl is-active firewalld >/dev/null 2>&1; then
        echo " - Enabling and starting firewalld service"
        systemctl --now enable firewalld
    fi
    
    echo " - firewalld service configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_firewalld_service
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: firewalld service properly enabled and running"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="