#!/usr/bin/env bash
# Script: 3.3.6.sh
# Item: 3.3.6 Ensure secure icmp redirects are not accepted (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.6.sh"
ITEM_NAME="3.3.6 Ensure secure icmp redirects are not accepted (Automated)"
DESCRIPTION="This remediation ensures secure ICMP redirects are not accepted for IPv4."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking secure ICMP redirect configuration..."
    
    verification_passed=true
    
    # Check current running values
    all_secure_redirects=$(sysctl net.ipv4.conf.all.secure_redirects 2>/dev/null | awk '{print $3}')
    default_secure_redirects=$(sysctl net.ipv4.conf.default.secure_redirects 2>/dev/null | awk '{print $3}')
    
    if [ "$all_secure_redirects" != "0" ]; then
        echo "FAIL: net.ipv4.conf.all.secure_redirects is not disabled (runtime)"
        echo "PROOF: net.ipv4.conf.all.secure_redirects = $all_secure_redirects"
        verification_passed=false
    else
        echo "PASS: net.ipv4.conf.all.secure_redirects disabled (runtime)"
    fi
    
    if [ "$default_secure_redirects" != "0" ]; then
        echo "FAIL: net.ipv4.conf.default.secure_redirects is not disabled (runtime)"
        echo "PROOF: net.ipv4.conf.default.secure_redirects = $default_secure_redirects"
        verification_passed=false
    else
        echo "PASS: net.ipv4.conf.default.secure_redirects disabled (runtime)"
    fi
    
    # Check configuration files for conflicting settings
    all_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "0" ]; then
            echo "FAIL: net.ipv4.conf.all.secure_redirects enabled in configuration: $line"
            all_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.conf\.all\.secure_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$all_config_issues" = false ]; then
        echo "PASS: net.ipv4.conf.all.secure_redirects properly configured in files"
    fi
    
    default_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "0" ]; then
            echo "FAIL: net.ipv4.conf.default.secure_redirects enabled in configuration: $line"
            default_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.conf\.default\.secure_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$default_config_issues" = false ]; then
        echo "PASS: net.ipv4.conf.default.secure_redirects properly configured in files"
    fi
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: Secure ICMP redirects properly disabled"
        echo "PROOF: Both all and default secure_redirects set to 0"
        return 0
    else
        return 1
    fi
}
# Function to fix
fix_secure_icmp_redirects() {
    echo "Applying fix..."
    
    # Remove any existing conflicting entries from all configuration files
    for config_file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
        if [ -f "$config_file" ]; then
            # Remove secure_redirects entries (both =0 and =1)
            sed -i '/^\s*net\.ipv4\.conf\.all\.secure_redirects\s*=/d' "$config_file" 2>/dev/null || true
            sed -i '/^\s*net\.ipv4\.conf\.default\.secure_redirects\s*=/d' "$config_file" 2>/dev/null || true
        fi
    done
    
    # Create dedicated configuration file
    CONFIG_FILE="/etc/sysctl.d/60-netipv4_sysctl.conf"
    # Add secure ICMP redirect configuration
    echo " - Configuring secure ICMP redirects"
    echo "# Secure ICMP redirect disable - Remediated by $SCRIPT_NAME" > "$CONFIG_FILE"
    echo "# $(date)" >> "$CONFIG_FILE"
    echo "net.ipv4.conf.all.secure_redirects = 0" >> "$CONFIG_FILE"
    echo "net.ipv4.conf.default.secure_redirects = 0" >> "$CONFIG_FILE"
    
    # Set active kernel parameters
    sysctl -w net.ipv4.conf.all.secure_redirects=0 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.secure_redirects=0 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    # Reload all sysctl configurations
    sysctl -p >/dev/null 2>&1 || true
    if ls /etc/sysctl.d/*.conf >/dev/null 2>&1; then
        sysctl -p /etc/sysctl.d/*.conf >/dev/null 2>&1 || true
    fi
    
    echo " - Secure ICMP redirect configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_secure_icmp_redirects
        # Allow time for changes to take effect
        sleep 2
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Secure ICMP redirects properly disabled"
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Debug information:"
        echo "Runtime all.secure_redirects: $(sysctl net.ipv4.conf.all.secure_redirects 2>/dev/null || echo 'not set')"
        echo "Runtime default.secure_redirects: $(sysctl net.ipv4.conf.default.secure_redirects 2>/dev/null || echo 'not set')"
        echo ""
        echo "Configuration files:"
        grep -r 'net.ipv4.conf.all.secure_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No all.secure_redirects configurations found"
        grep -r 'net.ipv4.conf.default.secure_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No default.secure_redirects configurations found"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="