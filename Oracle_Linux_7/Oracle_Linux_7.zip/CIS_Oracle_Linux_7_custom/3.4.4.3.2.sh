#!/usr/bin/env bash
# Script: 3.4.4.3.2.sh
# Item: 3.4.4.3.2 Ensure ip6tables outbound and established connections are configured (Manual)
set -euo pipefail
SCRIPT_NAME="3.4.4.3.2.sh"
ITEM_NAME="3.4.4.3.2 Ensure ip6tables outbound and established connections are configured (Manual)"
DESCRIPTION="This remediation ensures ip6tables outbound and established connections are properly configured for IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ip6tables outbound and established connection configuration..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    local missing_rules=0
    
    # Check for IPv6 established connection rules in INPUT chain
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "tcp.*state ESTABLISHED"; then
        echo "FAIL: IPv6 TCP established input rule not found"
        echo "PROOF: No 'INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT' rule found"
        ((missing_rules++))
    fi
    
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "udp.*state ESTABLISHED"; then
        echo "FAIL: IPv6 UDP established input rule not found"
        echo "PROOF: No 'INPUT -p udp -m state --state ESTABLISHED -j ACCEPT' rule found"
        ((missing_rules++))
    fi
    
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "icmp.*state ESTABLISHED"; then
        echo "FAIL: IPv6 ICMP established input rule not found"
        echo "PROOF: No 'INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT' rule found"
        ((missing_rules++))
    fi
    
    # Check for IPv6 outbound connection rules in OUTPUT chain
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -q "tcp.*state NEW,ESTABLISHED"; then
        echo "FAIL: IPv6 TCP outbound rule not found"
        echo "PROOF: No 'OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT' rule found"
        ((missing_rules++))
    fi
    
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -q "udp.*state NEW,ESTABLISHED"; then
        echo "FAIL: IPv6 UDP outbound rule not found"
        echo "PROOF: No 'OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT' rule found"
        ((missing_rules++))
    fi
    
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -q "icmp.*state NEW,ESTABLISHED"; then
        echo "FAIL: IPv6 ICMP outbound rule not found"
        echo "PROOF: No 'OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT' rule found"
        ((missing_rules++))
    fi
    
    if [ $missing_rules -gt 0 ]; then
        echo "FAIL: $missing_rules IPv6 connection rules are missing"
        return 1
    fi
    
    echo "PASS: ip6tables outbound and established connections properly configured"
    echo "PROOF: All required IPv6 connection state rules are present"
    return 0
}
# Function to fix
fix_ip6tables_connections() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Configuring ip6tables outbound and established connection rules"
    
    # Force remediation - always apply the rules (remove existing ones first if needed)
    echo " - Ensuring clean rule configuration"
    
    # Remove any existing connection state rules to avoid duplicates
    ip6tables -D INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT 2>/dev/null || true
    ip6tables -D INPUT -p udp -m state --state ESTABLISHED -j ACCEPT 2>/dev/null || true
    ip6tables -D INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT 2>/dev/null || true
    ip6tables -D OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT 2>/dev/null || true
    ip6tables -D OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT 2>/dev/null || true
    ip6tables -D OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT 2>/dev/null || true
    
    # Add IPv6 established connection rules to INPUT chain
    echo " - Adding IPv6 established connection rules (INPUT chain)"
    ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT
    
    # Add IPv6 outbound connection rules to OUTPUT chain
    echo " - Adding IPv6 outbound connection rules (OUTPUT chain)"
    ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT
    
    # Save ip6tables rules to make them persistent
    echo " - Saving ip6tables rules"
    if command -v service >/dev/null 2>&1; then
        service ip6tables save 2>/dev/null || ip6tables-save > /etc/sysconfig/ip6tables
    else
        ip6tables-save > /etc/sysconfig/ip6tables
    fi
    
    # Ensure ip6tables service is enabled
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo " - Enabling ip6tables service"
        systemctl enable ip6tables
    fi
    
    # Ensure ip6tables service is running
    if ! systemctl is-active ip6tables >/dev/null 2>&1; then
        echo " - Starting ip6tables service"
        systemctl start ip6tables
    fi
    
    echo " - ip6tables connection configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip6tables_connections
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ip6tables outbound and established connections properly configured"
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Manual configuration may be required. Use these commands:"
        echo "ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
        echo "ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
        echo "ip6tables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
        echo "ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "ip6tables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "service ip6tables save"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="