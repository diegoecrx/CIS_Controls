#!/usr/bin/env bash

# Script: 1.1.2.6.3.sh
# Item: 1.1.2.6.3 Ensure nosuid option set on /var/log partition (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.6.3.sh"
ITEM_NAME="1.1.2.6.3 Ensure nosuid option set on /var/log partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /var/log partition. FORCE VERSION - Uses multiple enforcement methods."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to fix_fstab_entry
fix_fstab_entry() {
    echo "Fixing /etc/fstab entry for /var/log..."
    
    # Create backup
    cp /etc/fstab "/etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)"
    
    # Check if entry exists and has nosuid
    if grep -q -E '\s/var/log\s' /etc/fstab; then
        echo " - /var/log entry exists in fstab"
        
        if grep -E '\s/var/log\s' /etc/fstab | grep -q 'nosuid'; then
            echo " - nosuid option already present"
        else
            echo " - Adding nosuid option to existing entry..."
            # Remove existing entry
            grep -v -E '\s/var/log\s' /etc/fstab > /etc/fstab.tmp
            # Get current entry and add nosuid
            current_entry=$(grep -E '\s/var/log\s' /etc/fstab)
            if echo "$current_entry" | grep -q 'loop,'; then
                updated_entry=$(echo "$current_entry" | sed 's/loop,/loop,nosuid,/' | sed 's/,,/,/g')
            elif echo "$current_entry" | grep -q 'defaults,'; then
                updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nosuid,/' | sed 's/,,/,/g')
            else
                updated_entry=$(echo "$current_entry" | awk '{$4=$4",nosuid"; print}')
            fi
            echo "$updated_entry" >> /etc/fstab.tmp
            mv /etc/fstab.tmp /etc/fstab
            echo " - Updated fstab entry with nosuid option"
        fi
    else
        echo " - No /var/log entry found, creating one..."
        echo "/var_log_partition.img /var/log ext4 loop,nosuid,nodev,noexec 0 2" >> /etc/fstab
        echo " - Created new fstab entry with nosuid option"
    fi
}

# Function to verify_nosuid_enforcement
verify_nosuid_enforcement() {
    local mount_point="$1"
    
    echo " - Testing nosuid enforcement..."
    
    # Create a test binary
    test_binary="$mount_point/test_suid_$$"
    test_source="$test_binary.c"
    
    # Create simple C program
    cat > "$test_source" << 'EOF'
#include <stdio.h>
int main() { 
    printf("SUID test executed\n"); 
    return 0; 
}
EOF
    
    # Try to compile if gcc available
    if command -v gcc >/dev/null 2>&1; then
        if gcc -o "$test_binary" "$test_source" 2>/dev/null; then
            # Try to set SUID bit
            if chmod u+s "$test_binary" 2>/dev/null; then
                echo "FAIL: Can set SUID bit despite nosuid"
                rm -f "$test_binary" "$test_source"
                return 1
            else
                echo "PASS: Cannot set SUID bit - nosuid enforced"
                rm -f "$test_binary" "$test_source"
                return 0
            fi
        else
            echo "INFO: Compilation failed, testing existing binary..."
            rm -f "$test_source"
        fi
    fi
    
    # Fallback test with existing binary
    if command -v ls >/dev/null 2>&1; then
        cp $(command -v ls) "$test_binary" 2>/dev/null || \
        touch "$test_binary" 2>/dev/null || return 1
        
        if chmod u+s "$test_binary" 2>/dev/null; then
            echo "FAIL: Can set SUID bit on existing file despite nosuid"
            rm -f "$test_binary"
            return 1
        else
            echo "PASS: Cannot set SUID bit - nosuid enforced"
            rm -f "$test_binary"
            return 0
        fi
    fi
    
    echo "INFO: Could not perform comprehensive SUID test"
    return 0
}

# Function to enforce_nosuid_kernel
enforce_nosuid_kernel() {
    echo "Applying kernel-level nosuid enforcement..."
    
    # Method 1: Use bind mount with nosuid option
    echo " - Attempting bind mount with nosuid..."
    mkdir -p /mnt/varlog_temp_nosuid
    if mount --bind /var/log /mnt/varlog_temp_nosuid && \
       mount -o remount,nosuid,bind /mnt/varlog_temp_nosuid; then
        if verify_nosuid_enforcement "/mnt/varlog_temp_nosuid"; then
            echo " - SUCCESS: Bind mount method works"
            # Apply to main mount
            mount -o remount,nosuid,bind /var/log
            umount /mnt/varlog_temp_nosuid
            rmdir /mnt/varlog_temp_nosuid
            return 0
        fi
        umount /mnt/varlog_temp_nosuid
        rmdir /mnt/varlog_temp_nosuid
    fi
    
    return 1
}

# Function to remove_existing_suid_files
remove_existing_suid_files() {
    echo " - Scanning for existing SUID files in /var/log..."
    suid_count=$(find /var/log -type f -perm /4000 2>/dev/null | wc -l)
    if [ "$suid_count" -gt 0 ]; then
        echo " - WARNING: Found $suid_count SUID files in /var/log"
        echo " - Removing SUID bits..."
        find /var/log -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null || true
        
        # Verify removal
        remaining_suid=$(find /var/log -type f -perm /4000 2>/dev/null | wc -l)
        if [ "$remaining_suid" -gt 0 ]; then
            echo " - CRITICAL: $remaining_suid SUID files still remain"
            echo " - Forcing removal with aggressive method..."
            find /var/log -type f -perm /4000 -exec chmod 0755 {} \; 2>/dev/null || true
        fi
    else
        echo " - PASS: No SUID files found in /var/log"
    fi
}

# Function to setup_selinux_nosuid
setup_selinux_nosuid() {
    echo "Setting up SELinux policy to block SUID execution..."
    
    if ! command -v semanage >/dev/null 2>&1; then
        echo " - Installing SELinux policy tools..."
        yum install -y policycoreutils-python-utils selinux-policy-targeted 2>/dev/null || \
        dnf install -y policycoreutils-python-utils selinux-policy-targeted 2>/dev/null || \
        apt-get install -y selinux-utils policycoreutils 2>/dev/null || true
    fi
    
    if command -v semanage >/dev/null 2>&1 && [ "$(getenforce 2>/dev/null)" = "Enforcing" ]; then
        echo " - Configuring SELinux to deny SUID execution in /var/log..."
        
        # Create custom policy
        cat > /tmp/deny_varlog_suid.te << 'EOF'
module deny_varlog_suid 1.0;

require {
    type var_log_t;
    class file { execute noatime };
}

allow var_log_t self:file { execute };
dontaudit var_log_t self:file { execute };
EOF
        
        if command -v checkmodule >/dev/null 2>&1 && command -v semodule_package >/dev/null 2>&1; then
            checkmodule -M -m -o /tmp/deny_varlog_suid.mod /tmp/deny_varlog_suid.te
            semodule_package -o /tmp/deny_varlog_suid.pp -m /tmp/deny_varlog_suid.mod
            semodule -i /tmp/deny_varlog_suid.pp 2>/dev/null || true
            rm -f /tmp/deny_varlog_suid.* 2>/dev/null || true
        fi
    else
        echo " - SELinux not available or not in enforcing mode"
    fi
}

# Function to setup_apparmor_nosuid
setup_apparmor_nosuid() {
    echo "Setting up AppArmor profile to block SUID execution..."
    
    if command -v apparmor_status >/dev/null 2>&1; then
        echo " - Configuring AppArmor for /var/log..."
        
        cat > /etc/apparmor.d/deny_varlog_suid << 'EOF'
# Profile to deny SUID execution in /var/log
/var/log/** r,
deny /var/log/** ux,  # deny execution
deny /var/log/** px,  # deny profile execution
deny /var/log/** cx,  # deny child execution
EOF
        
        apparmor_parser -r /etc/apparmor.d/deny_varlog_suid 2>/dev/null || true
    else
        echo " - AppArmor not available"
    fi
}

# Main remediation function
{
    echo "Checking current /var/log mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /var/log mount information:"
    mount | grep -E '\s/var/log\s' || echo "No separate /var/log mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/log:"
    grep -E '\s/var/log\s' /etc/fstab || echo "No /var/log entry in /etc/fstab"
    echo ""

    # Check if /var/log is a separate partition
    echo "Checking if /var/log is a separate partition:"
    varlog_device=$(df /var/log --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$varlog_device" ] && [ -n "$var_device" ] && [ "$varlog_device" != "$var_device" ]; then
        echo "PASS: /var/log is on separate partition: $varlog_device"
        varlog_is_separate=true
    elif [ -n "$varlog_device" ] && [ -n "$root_device" ] && [ "$varlog_device" != "$root_device" ]; then
        echo "PASS: /var/log is on separate partition: $varlog_device"
        varlog_is_separate=true
    else
        echo "FAIL: /var/log is NOT on separate partition"
        if [ -n "$varlog_device" ]; then
            echo "PROOF: /var/log shares device with $varlog_device"
        else
            echo "PROOF: /var/log is not mounted separately"
        fi
        varlog_is_separate=false
    fi
    echo ""

    # FORCE MODE: Create partition if needed
    if [ "$varlog_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /VAR/LOG PARTITION WITH nosuid OPTION"
        echo "==================================================================="
        echo ""

        # Call the partition creation script first if available
        if [ -f "1.1.2.6.1_v6.sh" ]; then
            /usr/bin/env bash 1.1.2.6.1_v6.sh
        else
            echo "ERROR: 1.1.2.6.1_v6.sh not found. Cannot create partition."
            exit 1
        fi
        varlog_is_separate=true
    fi

    echo "Applying nosuid remediation..."

    # Stop logging services temporarily
    echo " - Stopping logging services for remediation..."
    systemctl stop rsyslog 2>/dev/null || true
    systemctl stop syslog-ng 2>/dev/null || true
    systemctl stop auditd 2>/dev/null || true
    sleep 2

    # Fix fstab first
    fix_fstab_entry

    # Remove existing SUID files
    remove_existing_suid_files

    # Apply kernel-level enforcement
    echo ""
    echo "Applying kernel-level nosuid enforcement..."
    if ! enforce_nosuid_kernel; then
        echo " - Kernel method failed, trying security modules..."
        
        # Apply security module enforcement
        echo ""
        echo "Applying security module enforcement..."
        setup_selinux_nosuid
        setup_apparmor_nosuid
        
        # Try alternative mount methods
        echo ""
        echo "Trying alternative mount methods..."
        umount /var/log 2>/dev/null || true
        sleep 1
        
        # Try different mount option combinations
        if mount | grep -q '/var_log_partition.img'; then
            mount -o loop,nosuid,nodev,noexec,strictatime /var_log_partition.img /var/log 2>/dev/null || \
            mount -o loop,nosuid,nodev,noexec /var_log_partition.img /var/log
        else
            mount -o remount,nosuid /var/log
        fi
    fi

    # Restart services
    echo ""
    echo " - Restarting logging services..."
    systemctl start rsyslog 2>/dev/null || true
    systemctl start syslog-ng 2>/dev/null || true
    systemctl start auditd 2>/dev/null || true
    sleep 2

    echo ""
    echo "Remediation of nosuid option on /var/log partition complete"

    # Final verification with comprehensive testing
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="

    final_status_pass=true

    # PROOF 1: Verify fstab configuration
    echo ""
    echo "1. FSTAB CONFIGURATION:"
    echo "----------------------"
    fstab_entry=$(grep -E '\s/var/log\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        echo "PASS: /var/log entry found in fstab"
        echo "Entry: $fstab_entry"
        if echo "$fstab_entry" | grep -q 'nosuid'; then
            echo "PASS: nosuid option present in fstab"
        else
            echo "FAIL: nosuid option missing from fstab"
            final_status_pass=false
        fi
    else
        echo "FAIL: No /var/log entry in fstab"
        final_status_pass=false
    fi

    # PROOF 2: Verify mount options
    echo ""
    echo "2. MOUNT OPTIONS:"
    echo "----------------"
    mount_output=$(mount | grep -E '\s/var/log\s')
    if [ -n "$mount_output" ]; then
        echo "Mount: $mount_output"
        if echo "$mount_output" | grep -q 'nosuid'; then
            echo "PASS: nosuid option shown in mount output"
        else
            echo "FAIL: nosuid option missing from mount output"
            final_status_pass=false
        fi
    else
        echo "FAIL: /var/log not mounted"
        final_status_pass=false
    fi

    # PROOF 3: Test nosuid enforcement
    echo ""
    echo "3. nosuid ENFORCEMENT TEST:"
    echo "--------------------------"
    if verify_nosuid_enforcement "/var/log"; then
        echo "PASS: nosuid option properly enforced"
    else
        echo "FAIL: nosuid option not enforced"
        final_status_pass=false
    fi

    # PROOF 4: Verify no SUID files remain
    echo ""
    echo "4. SUID FILE CLEANUP VERIFICATION:"
    echo "---------------------------------"
    suid_files=$(find /var/log -type f -perm /4000 2>/dev/null | wc -l)
    if [ "$suid_files" -eq 0 ]; then
        echo "PASS: No SUID files found in /var/log"
    else
        echo "FAIL: Found $suid_files SUID files in /var/log"
        echo " - Forcing removal..."
        find /var/log -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null
        final_status_pass=false
    fi

    # PROOF 5: Test with actual binary execution
    echo ""
    echo "5. BINARY EXECUTION TEST:"
    echo "------------------------"
    if command -v gcc >/dev/null 2>&1; then
        test_binary="/var/log/exec_test_$$"
        test_source="$test_binary.c"
        
        cat > "$test_source" << 'EOF'
#include <stdio.h>
#include <unistd.h>
int main() { 
    printf("Test executed - UID: %d, EUID: %d\n", getuid(), geteuid());
    return 0;
}
EOF
        
        if gcc -o "$test_binary" "$test_source" 2>/dev/null; then
            chmod 755 "$test_binary"
            # Try to execute normally
            if "$test_binary" 2>/dev/null; then
                echo "INFO: Binary executes normally (expected)"
            else
                echo "WARNING: Binary cannot execute (may indicate other issues)"
            fi
            
            # Try to set SUID and execute
            if chmod u+s "$test_binary" 2>/dev/null; then
                echo "FAIL: Can set SUID bit - nosuid not enforced"
                final_status_pass=false
            else
                echo "PASS: Cannot set SUID bit - nosuid enforced"
            fi
            rm -f "$test_binary" "$test_source"
        else
            echo "INFO: Compilation test skipped"
            rm -f "$test_source"
        fi
    else
        echo "INFO: Execution test skipped (gcc not available)"
    fi

    # Final status
    echo ""
    echo "==================================================================="
    if [ "$final_status_pass" = true ]; then
        echo "SUCCESS: nosuid option is properly configured and enforced on /var/log"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        echo "✓ Separate /var/log partition verified"
        echo "✓ nosuid option applied in /etc/fstab"
        echo "✓ nosuid option shown in mount output"
        echo "✓ SUID bit setting blocked"
        echo "✓ No SUID files present in /var/log"
        echo "✓ Logging services restarted and functional"
    else
        echo "WARNING: nosuid enforcement may have limitations"
        echo ""
        echo "CURRENT STATUS:"
        echo "==============="
        echo "- fstab configuration: $(if grep -E '\s/var/log\s' /etc/fstab | grep -q 'nosuid'; then echo 'OK'; else echo 'MISSING'; fi)"
        echo "- Mount options: $(if mount | grep -E '\s/var/log\s' | grep -q 'nosuid'; then echo 'OK'; else echo 'MISSING'; fi)"
        echo "- SUID enforcement: $(if verify_nosuid_enforcement "/var/log" >/dev/null 2>&1; then echo 'OK'; else echo 'WEAK'; fi)"
        echo "- SUID files present: $(find /var/log -type f -perm /4000 2>/dev/null | wc -l)"
        echo ""
        echo "NOTE: Loop devices may have limited nosuid enforcement on some kernels."
    fi

    # Show current protection layers
    echo ""
    echo "PROTECTION LAYERS ACTIVE:"
    echo "========================="
    echo "- Mount options: $(mount | grep -E '\s/var/log\s' | cut -d'(' -f2 | cut -d')' -f1)"
    echo "- SELinux: $(getenforce 2>/dev/null || echo 'Not available')"
    echo "- AppArmor: $(if command -v apparmor_status >/dev/null 2>&1; then echo 'Available'; else echo 'Not available'; fi)"
    echo "- Filesystem type: $(df -T /var/log 2>/dev/null | tail -1 | awk '{print $2}')"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="