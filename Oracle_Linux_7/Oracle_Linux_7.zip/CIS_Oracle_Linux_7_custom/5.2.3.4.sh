#!/usr/bin/env bash
# Script: 5.2.3.4.sh
# Item: 5.2.3.4 Ensure events that modify date and time information are collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.4.sh"
ITEM_NAME="5.2.3.4 Ensure events that modify date and time information are collected (Automated)"
DESCRIPTION="This remediation ensures events that modify date and time information are collected by configuring audit rules."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking date and time modification audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check for time-change audit rules in running configuration
    # Accept both formats: -k time-change and -F key=time-change
    # Also accept different system call orderings
    b64_rule_found=false
    b32_rule_found=false
    localtime_rule_found=false
    
    # Check b64 rule (for 64-bit systems)
    if [[ "$arch" == "x86_64" ]]; then
        if auditctl -l 2>/dev/null | grep -qE '\-a always,exit -F arch=b64.*\-S (adjtimex,settimeofday,clock_settime|clock_settime,settimeofday,adjtimex).*time-change'; then
            b64_rule_found=true
            echo "DEBUG: Found b64 time-change rule"
        else
            echo "DEBUG: b64 time-change rule not found in running config"
        fi
    fi
    
    # Check b32 rule with appropriate system calls
    if [[ "$arch" == "x86_64" ]]; then
        # 64-bit system - check for b32 rule without stime
        if auditctl -l 2>/dev/null | grep -qE '\-a always,exit -F arch=b32.*\-S (adjtimex,settimeofday,clock_settime|clock_settime,settimeofday,adjtimex).*time-change'; then
            b32_rule_found=true
            echo "DEBUG: Found b32 time-change rule"
        else
            echo "DEBUG: b32 time-change rule not found in running config"
        fi
    else
        # 32-bit system - check for b32 rule with stime
        if auditctl -l 2>/dev/null | grep -qE '\-a always,exit -F arch=b32.*\-S (adjtimex,settimeofday,clock_settime,stime|stime,clock_settime,settimeofday,adjtimex).*time-change'; then
            b32_rule_found=true
            echo "DEBUG: Found b32 time-change rule"
        else
            echo "DEBUG: b32 time-change rule not found in running config"
        fi
    fi
    
    # Check /etc/localtime rule (accept both -k and -F key= formats)
    if auditctl -l 2>/dev/null | grep -qE '\-w /etc/localtime -p wa.*time-change'; then
        localtime_rule_found=true
        echo "DEBUG: Found /etc/localtime rule"
    else
        echo "DEBUG: /etc/localtime rule not found in running config"
    fi
    
    # For 64-bit systems, we need both b64 and b32 rules plus localtime
    # For 32-bit systems, we need b32 rule with stime plus localtime
    if [[ "$arch" == "x86_64" ]]; then
        if [ "$b64_rule_found" = true ] && [ "$b32_rule_found" = true ] && [ "$localtime_rule_found" = true ]; then
            echo "PASS: date and time modification audit rules properly configured"
            echo "PROOF: All required time-change audit rules found in running configuration"
            return 0
        else
            echo "FAIL: time-change audit rules not found in running configuration"
            echo "PROOF: Missing one or more required audit rules"
            return 1
        fi
    else
        if [ "$b32_rule_found" = true ] && [ "$localtime_rule_found" = true ]; then
            echo "PASS: date and time modification audit rules properly configured"
            echo "PROOF: All required time-change audit rules found in running configuration"
            return 0
        else
            echo "FAIL: time-change audit rules not found in running configuration"
            echo "PROOF: Missing one or more required audit rules"
            return 1
        fi
    fi
}

# Function to check if rules are functionally equivalent (even if format differs)
check_functional_equivalence() {
    echo "Checking if existing rules are functionally equivalent to CIS requirements..."
    
    arch=$(uname -m)
    functional=true
    
    # Check if we have the right system calls regardless of format
    if [[ "$arch" == "x86_64" ]]; then
        b64_rule=$(auditctl -l 2>/dev/null | grep -E '\-a always,exit -F arch=b64.*time-change' | head -1)
        b32_rule=$(auditctl -l 2>/dev/null | grep -E '\-a always,exit -F arch=b32.*time-change' | head -1)
        
        if [[ -n "$b64_rule" ]]; then
            if echo "$b64_rule" | grep -q adjtimex && echo "$b64_rule" | grep -q settimeofday && echo "$b64_rule" | grep -q clock_settime; then
                echo "DEBUG: b64 rule has correct system calls"
            else
                echo "DEBUG: b64 rule missing required system calls"
                functional=false
            fi
        else
            echo "DEBUG: No b64 rule found"
            functional=false
        fi
        
        if [[ -n "$b32_rule" ]]; then
            if echo "$b32_rule" | grep -q adjtimex && echo "$b32_rule" | grep -q settimeofday && echo "$b32_rule" | grep -q clock_settime; then
                echo "DEBUG: b32 rule has correct system calls"
            else
                echo "DEBUG: b32 rule missing required system calls"
                functional=false
            fi
        else
            echo "DEBUG: No b32 rule found"
            functional=false
        fi
    else
        b32_rule=$(auditctl -l 2>/dev/null | grep -E '\-a always,exit -F arch=b32.*time-change' | head -1)
        if [[ -n "$b32_rule" ]]; then
            if echo "$b32_rule" | grep -q adjtimex && echo "$b32_rule" | grep -q settimeofday && echo "$b32_rule" | grep -q clock_settime && echo "$b32_rule" | grep -q stime; then
                echo "DEBUG: b32 rule has correct system calls (including stime)"
            else
                echo "DEBUG: b32 rule missing required system calls"
                functional=false
            fi
        else
            echo "DEBUG: No b32 rule found"
            functional=false
        fi
    fi
    
    # Check localtime rule
    localtime_rule=$(auditctl -l 2>/dev/null | grep -E '\-w /etc/localtime -p wa.*time-change' | head -1)
    if [[ -n "$localtime_rule" ]]; then
        echo "DEBUG: /etc/localtime rule exists"
    else
        echo "DEBUG: No /etc/localtime rule found"
        functional=false
    fi
    
    if [ "$functional" = true ]; then
        echo "INFO: Existing rules are functionally equivalent to CIS requirements"
        echo "NOTE: Rules use -F key= format instead of -k format, but provide equivalent functionality"
        return 0
    else
        return 1
    fi
}

# Function to fix
fix_time_change_audit_rules() {
    echo "Applying fix..."
    
    # First check if we can work with existing rules
    if check_functional_equivalence; then
        echo " - Existing rules are functionally equivalent to CIS requirements"
        echo " - Creating CIS-compliant rule file for future consistency"
    else
        echo " - Existing rules do not meet CIS requirements, replacing them"
    fi
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
        sleep 2
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    echo " - Creating CIS-compliant time-change audit rules in /etc/audit/rules.d/50-time-change.rules"
    
    # Use the CIS benchmark recommended format with -k
    if [[ "$arch" == "x86_64" ]]; then
        # 64-bit system - create rules for both b64 and b32
        cat > /etc/audit/rules.d/50-time-change.rules << 'EOF'
## Monitor events that modify date and time information
-a always,exit -F arch=b64 -S adjtimex,settimeofday,clock_settime -k time-change
-a always,exit -F arch=b32 -S adjtimex,settimeofday,clock_settime -k time-change
-w /etc/localtime -p wa -k time-change
EOF
    else
        # 32-bit system - create rule for b32 only with stime
        cat > /etc/audit/rules.d/50-time-change.rules << 'EOF'
## Monitor events that modify date and time information
-a always,exit -F arch=b32 -S adjtimex,settimeofday,clock_settime,stime -k time-change
-w /etc/localtime -p wa -k time-change
EOF
    fi
    
    # Set correct permissions on the rules file
    chmod 0640 /etc/audit/rules.d/50-time-change.rules
    chown root:root /etc/audit/rules.d/50-time-change.rules
    
    echo " - Created CIS-compliant audit rules file"
    
    # Try to load the rules (they may not take effect immediately due to auto-reload)
    echo " - Attempting to load CIS-compliant rules"
    augenrules --load
    
    echo " - NOTE: Rules may be automatically reloaded from other sources"
    echo " - CIS-compliant rules have been written to configuration for future consistency"
    echo " - time-change audit rules configuration completed"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        # Check if existing rules are functionally equivalent
        if check_functional_equivalence; then
            echo "INFO: Rules are functionally equivalent but use different format"
            echo "Applying configuration for future consistency..."
            fix_time_change_audit_rules
        else
            echo "Rules do not meet requirements, applying fix..."
            fix_time_change_audit_rules
        fi
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: date and time modification audit rules properly configured"
    elif check_functional_equivalence; then
        echo "COMPLIANT: Rules are functionally equivalent to CIS requirements"
        echo "NOTE: Using -F key= format instead of -k format, but provides equivalent functionality"
        echo "CIS-compliant configuration has been written for future consistency"
    else
        echo "FAIL: Issues remain"
        echo "DEBUG: Current audit rules:"
        auditctl -l 2>/dev/null || echo "No audit rules loaded"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="