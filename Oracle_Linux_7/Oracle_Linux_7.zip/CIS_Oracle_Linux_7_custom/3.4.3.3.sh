#!/usr/bin/env bash
# Script: 3.4.3.3.sh
# Item: 3.4.3.3 Ensure an nftables table exists (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.3.sh"
ITEM_NAME="3.4.3.3 Ensure an nftables table exists (Automated)"
DESCRIPTION="This remediation ensures an nftables table exists for packet filtering."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables table existence..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    # Check if any nftables tables exist
    if ! nft list tables 2>/dev/null | grep -q "table"; then
        echo "FAIL: No nftables tables exist"
        echo "PROOF: nft list tables returned no tables"
        return 1
    fi
    
    # List existing tables for verification
    existing_tables=$(nft list tables 2>/dev/null)
    echo "PASS: nftables table(s) exist"
    echo "PROOF: Found tables: $existing_tables"
    return 0
}
# Function to fix
fix_nftables_table() {
    echo "Applying fix..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package first"
        yum install -y nftables
    fi
    
    # Check if any tables exist
    if ! nft list tables 2>/dev/null | grep -q "table"; then
        echo " - Creating nftables inet filter table"
        nft create table inet filter
        
        # Save the configuration to make it persistent
        if [ -f /etc/nftables.conf ]; then
            # Backup existing config
            cp /etc/nftables.conf /etc/nftables.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
        fi
        
        # Create basic nftables configuration
        cat > /etc/nftables.conf << 'EOF'
#!/usr/sbin/nft -f

flush ruleset

table inet filter {
    chain input {
        type filter hook input priority 0;
    }
    chain forward {
        type filter hook forward priority 0;
    }
    chain output {
        type filter hook output priority 0;
    }
}
EOF
        
        # Apply the configuration
        nft -f /etc/nftables.conf
        
        echo " - Created inet filter table with basic chains"
    else
        echo " - nftables tables already exist"
    fi
    
    echo " - nftables table configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_table
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables table properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="