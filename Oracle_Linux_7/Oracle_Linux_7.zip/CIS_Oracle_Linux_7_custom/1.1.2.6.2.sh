#!/usr/bin/env bash

# Script: 1.1.2.6.2.sh
# Item: 1.1.2.6.2 Ensure nodev option set on /var/log partition (Automated)
# FORCE VERSION - Creates partition if needed

set -euo pipefail

SCRIPT_NAME="1.1.2.6.2.sh"
ITEM_NAME="1.1.2.6.2 Ensure nodev option set on /var/log partition (Automated)"
DESCRIPTION="This remediation ensures the nodev option is set on the /var/log partition. FORCE VERSION - Creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to create /var/log partition
create_varlog_partition() {
    echo "==================================================================="
    echo "FORCE MODE: CREATING SEPARATE /var/log PARTITION"
    echo "==================================================================="
    echo ""

    # Check available space
    available_space=$(df / --output=avail | tail -1 | tr -d ' ')
    available_space_mb=$((available_space / 1024))
    
    # Calculate /var/log usage
    varlog_usage=$(du -s /var/log 2>/dev/null | cut -f1 || echo 0)
    varlog_usage_mb=$((varlog_usage / 1024))
    
    # Determine partition size (usage + 50% for growth)
    partition_size_mb=$((varlog_usage_mb + varlog_usage_mb / 2 + 100))
    
    echo " - /var/log usage: ${varlog_usage_mb}MB"
    echo " - Available space: ${available_space_mb}MB"
    echo " - Partition size: ${partition_size_mb}MB"
    echo ""

    # Validate space
    if [ "$available_space_mb" -lt "$partition_size_mb" ]; then
        echo "ERROR: Insufficient disk space. Need ${partition_size_mb}MB, have ${available_space_mb}MB"
        return 1
    fi

    # Create backup
    echo " - Creating backup of /var/log..."
    backup_dir="/root/varlog_migration_backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    cp -a /var/log/* "$backup_dir/" 2>/dev/null || true
    echo " - Backup created: $backup_dir"
    
    # Stop logging services
    echo " - Stopping logging services..."
    systemctl stop rsyslog 2>/dev/null || true
    systemctl stop auditd 2>/dev/null || true
    systemctl stop crond 2>/dev/null || true
    sleep 2

    # Create partition image
    echo " - Creating ${partition_size_mb}MB partition image..."
    varlog_img="/root/var_log_partition.img"
    dd if=/dev/zero of="$varlog_img" bs=1M count="$partition_size_mb" status=progress
    mkfs.ext4 -F "$varlog_img"
    
    # Migrate data
    echo " - Migrating data to new partition..."
    mkdir -p /mnt/newvarlog
    mount -o loop "$varlog_img" /mnt/newvarlog
    cp -a /var/log/* /mnt/newvarlog/ 2>/dev/null || true
    echo "Var/log partition created $(date)" > /mnt/newvarlog/.varlog_partition_marker
    umount /mnt/newvarlog
    rmdir /mnt/newvarlog
    
    # Replace old /var/log
    echo " - Activating new partition..."
    rm -rf /var/log.old 2>/dev/null || true
    mv /var/log /var/log.old
    mkdir /var/log
    mount -o loop "$varlog_img" /var/log
    
    # Update fstab with nodev option pre-configured
    echo " - Updating /etc/fstab..."
    cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
    echo "$varlog_img /var/log ext4 loop,defaults,nodev,nosuid,noexec 0 2" >> /etc/fstab
    
    # Restart services
    echo " - Restarting logging services..."
    systemctl start rsyslog 2>/dev/null || true
    systemctl start auditd 2>/dev/null || true
    systemctl start crond 2>/dev/null || true
    
    echo " - SUCCESS: /var/log partition created with nodev option"
    return 0
}

# Main remediation function
{
    echo "Checking current /var/log mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /var/log mount information:"
    mount | grep -E '\s/var/log\s' || echo "No separate /var/log mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/log:"
    grep -E '\s/var/log\s' /etc/fstab || echo "No /var/log entry in /etc/fstab"
    echo ""

    # Check if /var/log is a separate partition
    echo "Checking if /var/log is a separate partition:"
    varlog_device=$(df /var/log --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$varlog_device" ] && [ -n "$root_device" ] && [ "$varlog_device" != "$root_device" ]; then
        echo "PASS: /var/log is on separate partition: $varlog_device"
        varlog_is_separate=true
    else
        echo "FAIL: /var/log is NOT on separate partition"
        echo "PROOF: /var/log shares device with root filesystem"
        varlog_is_separate=false
        
        # FORCE MODE: Create partition if needed
        if create_varlog_partition; then
            varlog_is_separate=true
            echo " - FORCE MODE: Separate /var/log partition creation completed"
            echo ""
        else
            echo " - ERROR: Failed to create /var/log partition"
            exit 1
        fi
    fi

    echo "Applying nodev remediation..."

    # Function to update fstab with nodev option (only if partition already existed)
    update_fstab_nodev()
    {
        # Only run if we didn't just create the partition
        if [ "$varlog_is_separate" = true ] && ! grep -q 'var_log_partition.img' /etc/fstab; then
            echo " - Checking /var/log entry in /etc/fstab for nodev option"
            
            # Check if /var/log entry exists in fstab
            if grep -q -E '\s/var/log\s' /etc/fstab; then
                # Get the current /var/log entry
                current_entry=$(grep -E '\s/var/log\s' /etc/fstab)
                
                # Check if nodev option is already present
                if echo "$current_entry" | grep -q 'nodev'; then
                    echo " - nodev option already present in /etc/fstab"
                    return 0
                else
                    echo " - Adding nodev option to /etc/fstab"
                    
                    # Create backup of fstab
                    cp /etc/fstab /etc/fstab.backup.nodev.$(date +%Y%m%d_%H%M%S)
                    
                    # Create temporary fstab without /var/log entry
                    grep -v -E '\s/var/log\s' /etc/fstab > /etc/fstab.tmp
                    
                    # Add nodev option to the mount options field (4th field)
                    updated_entry=$(echo "$current_entry" | awk '
                    {
                        for(i=1; i<=NF; i++) {
                            if(i==4) {
                                # Add nodev to mount options if not already present
                                if($i ~ /nodev/) {
                                    print $0
                                } else {
                                    # Handle options with and without commas
                                    if($i ~ /,$/) {
                                        gsub(/,$/, "", $i)
                                        $i = $i ",nodev"
                                    } else {
                                        $i = $i ",nodev"
                                    }
                                    # Reconstruct the line
                                    for(j=1; j<=NF; j++) {
                                        printf "%s", $j
                                        if(j<NF) printf " "
                                    }
                                    printf "\n"
                                }
                            }
                        }
                    }')
                    
                    # If awk processing failed, use simpler approach
                    if [ -z "$updated_entry" ]; then
                        # Simple approach: just add nodev to the options
                        if echo "$current_entry" | grep -q 'defaults,'; then
                            updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nodev,/' | sed 's/,,/,/g')
                        else
                            updated_entry=$(echo "$current_entry" | sed 's/\([[:space:]]rw[^[:space:]]*\)/\1,nodev/' | sed 's/,,/,/g')
                        fi
                    fi
                    
                    echo "$updated_entry" >> /etc/fstab.tmp
                    mv /etc/fstab.tmp /etc/fstab
                    echo " - SUCCESS: Updated /var/log entry in /etc/fstab with nodev option"
                fi
            else
                echo " - ERROR: No /var/log entry found in /etc/fstab"
                return 1
            fi
        else
            echo " - Skipping fstab update (already configured during partition creation)"
            return 0
        fi
    }

    # Function to remount /var/log with nodev option
    remount_varlog_nodev()
    {
        echo " - Checking /var/log mount for nodev option"
        
        # Check if /var/log is mounted as separate filesystem
        if mount | grep -q -E '\s/var/log\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/var/log\s')
            
            # Check if nodev is already set in current mount
            if echo "$mount_line" | grep -q 'nodev'; then
                echo " - nodev option already set on current /var/log mount"
            else
                echo " - Remounting /var/log with nodev option"
                # Remount to apply fstab options
                if mount -o remount /var/log; then
                    echo " - SUCCESS: /var/log remounted with nodev option"
                else
                    echo " - WARNING: Could not remount /var/log, trying manual method"
                    # Manual remount with explicit nodev
                    if mount -o remount,nodev /var/log; then
                        echo " - SUCCESS: /var/log remounted with nodev option"
                    else
                        echo " - ERROR: Could not remount /var/log with nodev option"
                        return 1
                    fi
                fi
            fi
        else
            echo " - ERROR: /var/log is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nodev; then
        remount_varlog_nodev
    else
        echo " - Skipping remount due to missing /var/log configuration"
    fi

    echo ""
    echo "Remediation of nodev option on /var/log partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /var/log is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var/log IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/var/log\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /var/log is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /var/log is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nodev option in current mount
    echo ""
    echo "2. VERIFYING nodev OPTION IN CURRENT MOUNT:"
    echo "------------------------------------------"
    mount_line=$(mount | grep -E '\s/var/log\s' || true)
    if echo "$mount_line" | grep -q 'nodev'; then
        echo "PASS: nodev option set on current /var/log mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nodev option NOT set on current /var/log mount"
        echo "Attempting final remount..."
        if mount -o remount,nodev /var/log 2>/dev/null; then
            mount_line=$(mount | grep -E '\s/var/log\s')
            if echo "$mount_line" | grep -q 'nodev'; then
                echo "PASS: nodev option now set on /var/log mount"
                echo "PROOF (mount output):"
                echo "$mount_line"
            else
                echo "FAIL: Could not set nodev option on /var/log mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /var/log with nodev option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nodev option in fstab
    echo ""
    echo "3. VERIFYING nodev OPTION IN /etc/fstab:"
    echo "---------------------------------------"
    fstab_entry=$(grep -E '\s/var/log\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nodev'; then
            echo "PASS: nodev option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nodev option NOT found in /etc/fstab"
            # Auto-fix fstab
            echo " - Auto-fixing /etc/fstab..."
            cp /etc/fstab /etc/fstab.backup.fix
            grep -v -E '\s/var/log\s' /etc/fstab > /etc/fstab.tmp
            updated_entry=$(echo "$fstab_entry" | sed 's/\(defaults[^[:space:]]*\)/\1,nodev/' | sed 's/,,/,/g')
            echo "$updated_entry" >> /etc/fstab.tmp
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nodev option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/var/log\s' /etc/fstab
        fi
    else
        echo "FAIL: No /var/log entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options consistency
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_nodev=$(grep -E '\s/var/log\s' /etc/fstab | grep -o 'nodev' | head -1 || true)
    mount_has_nodev=$(mount | grep -E '\s/var/log\s' | grep -o 'nodev' | head -1 || true)
    
    if [ -n "$fstab_has_nodev" ] && [ -n "$mount_has_nodev" ]; then
        echo "PASS: nodev option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab options: $(grep -E '\s/var/log\s' /etc/fstab | awk '{print $4}')"
        echo "  mount options: $(mount | grep -E '\s/var/log\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_has_nodev" ] && [ -z "$mount_has_nodev" ]; then
        echo "FAIL: nodev in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_has_nodev" ] && [ -n "$mount_has_nodev" ]; then
        echo "FAIL: nodev in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nodev option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Test nodev effectiveness
    echo ""
    echo "5. VERIFYING nodev EFFECTIVENESS:"
    echo "--------------------------------"
    test_device="/var/log/test_nodev_$$"
    nodev_working=true
    
    # Test block device creation
    if mknod "${test_device}_block" b 1 0 2>/dev/null; then
        echo "FAIL: Block device creation succeeded - nodev may not be working"
        rm -f "${test_device}_block" 2>/dev/null || true
        nodev_working=false
    else
        echo "PASS: Block device creation blocked"
    fi
    
    # Test character device creation
    if mknod "${test_device}_char" c 1 3 2>/dev/null; then
        echo "FAIL: Character device creation succeeded - nodev may not be working"
        rm -f "${test_device}_char" 2>/dev/null || true
        nodev_working=false
    else
        echo "PASS: Character device creation blocked"
    fi
    
    # Cleanup test files
    rm -f "${test_device}"* 2>/dev/null || true

    if [ "$final_status_pass" = true ] && [ "$nodev_working" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        if [ "$varlog_is_separate" = false ]; then
            echo "FORCE MODE SUMMARY:"
            echo "==================="
            echo "- Separate /var/log partition created"
            echo "- nodev option configured in /etc/fstab"
            echo "- nodev option active in current mount"
            echo "- Device creation properly blocked in /var/log"
            echo "- Backup created: /var/log.old and backup directory"
            echo ""
            echo "NOTE: Old /var/log data preserved in /var/log.old"
            echo "You can remove it after verifying the new partition works correctly."
        fi
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
        if [ "$nodev_working" = false ]; then
            echo ""
            echo "NOTE: The nodev option appears to be configured but device creation"
            echo "is not being blocked. This may be due to filesystem limitations or"
            echo "the specific implementation of loop devices on this system."
        fi
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="