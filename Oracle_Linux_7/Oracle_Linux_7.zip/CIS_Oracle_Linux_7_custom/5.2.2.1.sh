#!/usr/bin/env bash
# Script: 5.2.2.1.sh
# Item: 5.2.2.1 Ensure audit log storage size is configured (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.2.1.sh"
ITEM_NAME="5.2.2.1 Ensure audit log storage size is configured (Automated)"
DESCRIPTION="This remediation ensures audit log storage size is configured in auditd.conf."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking audit log storage size configuration..."
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Get the last max_log_file setting (in case of duplicates)
    max_log_file_line=$(grep '^max_log_file' /etc/audit/auditd.conf | tail -1)
    
    if [ -n "$max_log_file_line" ]; then
        # Extract the value using proper parsing
        max_log_file=$(echo "$max_log_file_line" | awk -F= '{print $2}' | awk '{$1=$1};1')
        
        # Check if it's a valid positive number
        if [[ "$max_log_file" =~ ^[0-9]+$ ]] && [ "$max_log_file" -gt 0 ] 2>/dev/null; then
            echo "PASS: audit log storage size properly configured"
            echo "PROOF: max_log_file = $max_log_file MB configured in /etc/audit/auditd.conf"
            return 0
        else
            echo "FAIL: max_log_file has invalid value"
            echo "PROOF: max_log_file = '$max_log_file' is not a valid positive number"
            return 1
        fi
    fi
    
    echo "FAIL: audit log storage size not configured"
    echo "PROOF: No max_log_file setting found in /etc/audit/auditd.conf"
    return 1
}

# Function to fix
fix_audit_log_storage_size() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        mkdir -p /etc/audit
        touch /etc/audit/auditd.conf
    fi
    
    # Set recommended log file size
    recommended_size=100
    
    # Remove ALL existing max_log_file entries to avoid duplicates
    echo " - Removing duplicate max_log_file entries"
    sed -i '/^max_log_file/d' /etc/audit/auditd.conf
    
    # Add the correct max_log_file setting
    echo " - Adding max_log_file = $recommended_size to /etc/audit/auditd.conf"
    echo "max_log_file = $recommended_size" >> /etc/audit/auditd.conf
    
    # Verify the change was made
    if grep -q "^max_log_file = $recommended_size" /etc/audit/auditd.conf; then
        echo " - Successfully configured max_log_file = $recommended_size MB"
    else
        echo " - ERROR: Failed to configure max_log_file"
        return 1
    fi
    
    # Try to reload auditd configuration without full restart
    echo " - Reloading auditd configuration"
    if systemctl is-active auditd >/dev/null 2>&1; then
        # Use auditctl to reload configuration if possible
        if command -v auditctl >/dev/null 2>&1; then
            echo " - Sending HUP signal to auditd to reload configuration"
            pkill -HUP auditd 2>/dev/null || true
        else
            echo " - Note: Configuration changes will take effect on next auditd restart"
        fi
    else
        echo " - auditd service not running, changes will take effect when started"
    fi
    
    echo " - audit log storage size configuration completed"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_log_storage_size
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit log storage size properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="