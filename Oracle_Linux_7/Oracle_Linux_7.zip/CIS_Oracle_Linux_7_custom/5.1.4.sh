#!/usr/bin/env bash
# Script: 5.1.4.sh
# Item: 5.1.4 Ensure all logfiles have appropriate access configured (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.4.sh"
ITEM_NAME="5.1.4 Ensure all logfiles have appropriate access configured (Automated)"
DESCRIPTION="This remediation ensures all logfiles in /var/log have appropriate permissions and ownership configured."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking logfile permissions and ownership in /var/log..."
    
    local issues_found=0
    local l_uidmin="$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"
    
    # Create a temporary file to store problematic files
    local temp_file
    temp_file=$(mktemp)
    
    # Find files with problematic permissions or ownership
    find -L /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0 > "$temp_file" 2>/dev/null || true
    
    if [ ! -s "$temp_file" ]; then
        echo "PASS: All logfiles have appropriate permissions and ownership"
        rm -f "$temp_file"
        return 0
    fi
    
    echo "PROOF: Found files with issues:"
    while IFS= read -r -d '' l_file; do
        if [ -e "$l_file" ]; then
            local l_mode l_user l_uid l_group l_gid l_bname expected_mode expected_user expected_group
            l_mode=$(stat -Lc '%#a' "$l_file" 2>/dev/null || echo "0000")
            l_user=$(stat -Lc '%U' "$l_file" 2>/dev/null || echo "unknown")
            l_uid=$(stat -Lc '%u' "$l_file" 2>/dev/null || echo "0")
            l_group=$(stat -Lc '%G' "$l_file" 2>/dev/null || echo "unknown")
            l_gid=$(stat -Lc '%g' "$l_file" 2>/dev/null || echo "0")
            l_bname=$(basename "$l_file")
            
            # Determine expected values
            case "$l_bname" in
                lastlog)
                    expected_mode="0644"  # lastlog should be 644 according to CIS
                    expected_user="root"
                    expected_group="root"
                    ;;
                btmp)
                    expected_mode="0600"  # btmp should be 600
                    expected_user="root" 
                    expected_group="utmp"
                    ;;
                wtmp)
                    expected_mode="0664"  # wtmp should be 664
                    expected_user="root"
                    expected_group="utmp"
                    ;;
                *)
                    expected_mode="0640"  # Default for other logs
                    expected_user="root"
                    expected_group="root"
                    ;;
            esac
            
            local file_issue=0
            if [ "$l_mode" != "$expected_mode" ]; then
                file_issue=1
            fi
            if [ "$l_user" != "$expected_user" ]; then
                file_issue=1
            fi
            if [ "$l_group" != "$expected_group" ]; then
                file_issue=1
            fi
            
            if [ $file_issue -eq 1 ]; then
                echo " - File: \"$l_file\""
                echo "   Current: Mode=$l_mode, User=$l_user, Group=$l_group"
                echo "   Expected: Mode=$expected_mode, User=$expected_user, Group=$expected_group"
                issues_found=1
            fi
        fi
    done < "$temp_file"
    
    rm -f "$temp_file"
    
    if [ $issues_found -eq 0 ]; then
        echo "PASS: All logfiles have appropriate permissions and ownership"
        return 0
    else
        echo "FAIL: Found files with incorrect permissions or ownership"
        return 1
    fi
}

# Function to fix logfile permissions
fix_logfile_permissions() {
    echo "Applying fix for logfile permissions and ownership..."
    
    local files_fixed=0
    
    # Process files with issues
    while IFS= read -r -d '' l_file; do
        if [ -e "$l_file" ]; then
            local l_mode l_user l_group l_bname expected_mode expected_user expected_group
            l_mode=$(stat -Lc '%#a' "$l_file" 2>/dev/null || echo "0000")
            l_user=$(stat -Lc '%U' "$l_file" 2>/dev/null || echo "unknown")
            l_group=$(stat -Lc '%G' "$l_file" 2>/dev/null || echo "unknown")
            l_bname=$(basename "$l_file")
            
            # Determine expected values based on filename
            case "$l_bname" in
                lastlog)
                    expected_mode="0644"
                    expected_user="root"
                    expected_group="root"
                    ;;
                btmp)
                    expected_mode="0600"
                    expected_user="root"
                    expected_group="utmp"
                    ;;
                wtmp)
                    expected_mode="0664"
                    expected_user="root"
                    expected_group="utmp"
                    ;;
                *)
                    expected_mode="0640"
                    expected_user="root"
                    expected_group="root"
                    ;;
            esac
            
            local changes=""
            
            # Fix permissions if needed
            if [ "$l_mode" != "$expected_mode" ]; then
                if chmod "$expected_mode" "$l_file" 2>/dev/null; then
                    changes="$changes mode:$l_mode→$expected_mode"
                fi
            fi
            
            # Fix user ownership if needed
            if [ "$l_user" != "$expected_user" ]; then
                if chown "$expected_user" "$l_file" 2>/dev/null; then
                    changes="$changes user:$l_user→$expected_user"
                fi
            fi
            
            # Fix group ownership if needed
            if [ "$l_group" != "$expected_group" ]; then
                if chgrp "$expected_group" "$l_file" 2>/dev/null; then
                    changes="$changes group:$l_group→$expected_group"
                fi
            fi
            
            if [ -n "$changes" ]; then
                echo " - Fixed: $l_file$changes"
                files_fixed=$((files_fixed + 1))
            fi
        fi
    done < <(find -L /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0 2>/dev/null)
    
    # Special handling for the specific files that were identified
    local special_files=("/var/log/lastlog" "/var/log/btmp" "/var/log/wtmp")
    for special_file in "${special_files[@]}"; do
        if [ -e "$special_file" ]; then
            local l_bname=$(basename "$special_file")
            case "$l_bname" in
                lastlog)
                    chmod 0644 "$special_file" 2>/dev/null && echo " - Set lastlog to 0644"
                    chown root:root "$special_file" 2>/dev/null
                    ;;
                btmp)
                    chmod 0600 "$special_file" 2>/dev/null && echo " - Set btmp to 0600"
                    chown root:utmp "$special_file" 2>/dev/null
                    ;;
                wtmp)
                    chmod 0664 "$special_file" 2>/dev/null && echo " - Set wtmp to 0664"
                    chown root:utmp "$special_file" 2>/dev/null
                    ;;
            esac
        fi
    done
    
    echo " - Fixed permissions/ownership for $files_fixed files"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_logfile_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: All logfiles have appropriate access configured"
    else
        echo "FAIL: Some issues may remain - manual review recommended"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="