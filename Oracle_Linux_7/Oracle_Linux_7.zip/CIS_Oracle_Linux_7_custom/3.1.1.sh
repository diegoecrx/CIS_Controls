#!/usr/bin/env bash

# Script: 3.1.1.sh
# Item: 3.1.1 Ensure IPv6 is properly configured and disabled if not used (Automated)

set -euo pipefail

SCRIPT_NAME="3.1.1.sh"
ITEM_NAME="3.1.1 Ensure IPv6 is properly configured and disabled if not used (Automated)"
DESCRIPTION="This remediation ensures IPv6 is either properly secured or completely disabled based on system requirements and network configuration."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_ipv6_status
detect_ipv6_status() {
    echo "Checking IPv6 configuration status..."
    
    ipv6_enabled=false
    ipv6_configured=false
    ipv6_routing=false
    ipv6_listening=false
    
    # Check if IPv6 is enabled in kernel
    if [ -f "/proc/sys/net/ipv6/conf/all/disable_ipv6" ]; then
        if [ "$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6)" -eq 0 ]; then
            ipv6_enabled=true
            echo " - IPv6 is enabled in kernel"
        else
            echo " - IPv6 is disabled in kernel"
        fi
    fi
    
    # Check for IPv6 network interfaces
    if ip -6 addr show | grep -q "inet6"; then
        ipv6_configured=true
        echo " - IPv6 addresses configured on interfaces:"
        ip -6 addr show | grep "inet6" | awk '{print "   - "$2" on "$NF}'
    fi
    
    # Check for IPv6 routing
    if ip -6 route show | grep -q .; then
        ipv6_routing=true
        echo " - IPv6 routing table entries found"
    fi
    
    # Check for IPv6 listening services
    if ss -tulpn6 2>/dev/null | grep -q LISTEN; then
        ipv6_listening=true
        echo " - IPv6 listening services detected:"
        ss -tulpn6 2>/dev/null | grep LISTEN | awk '{print "   - "$5" ("$1")"}'
    fi
    
    # Check sysctl IPv6 configurations
    echo " - Checking sysctl IPv6 configurations:"
    sysctl_params=(
        "net.ipv6.conf.all.accept_ra"
        "net.ipv6.conf.all.accept_redirects" 
        "net.ipv6.conf.all.forwarding"
        "net.ipv6.conf.all.autoconf"
    )
    
    for param in "${sysctl_params[@]}"; do
        if sysctl "$param" 2>/dev/null | grep -q .; then
            value=$(sysctl -n "$param" 2>/dev/null)
            echo "   - $param = $value"
        fi
    done
    
    # Check for IPv6 in GRUB configuration
    if [ -f "/etc/default/grub" ] && grep -q "ipv6.disable" /etc/default/grub; then
        echo " - IPv6 disable setting found in GRUB configuration"
    fi
    
    # Check for IPv6 in modprobe configurations
    if [ -f "/etc/modprobe.d/ipv6.conf" ] || ls /etc/modprobe.d/*.conf 2>/dev/null | xargs grep -l "ipv6" 2>/dev/null; then
        echo " - IPv6 configurations found in modprobe"
    fi
    
    return 0
}

# Function to disable_ipv6_kernel
disable_ipv6_kernel() {
    echo "Disabling IPv6 in kernel..."
    
    # Set runtime disable
    echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6 2>/dev/null && \
    echo " - IPv6 disabled in runtime configuration"
    
    # Configure sysctl for persistent disable
    if [ -f "/etc/sysctl.conf" ]; then
        cp /etc/sysctl.conf "/etc/sysctl.conf.backup.$(date +%Y%m%d_%H%M%S)"
        
        # Add or update IPv6 disable settings
        grep -q "net.ipv6.conf.all.disable_ipv6" /etc/sysctl.conf && \
        sed -i 's/^net.ipv6.conf.all.disable_ipv6.*/net.ipv6.conf.all.disable_ipv6 = 1/' /etc/sysctl.conf || \
        echo "net.ipv6.conf.all.disable_ipv6 = 1" >> /etc/sysctl.conf
        
        grep -q "net.ipv6.conf.default.disable_ipv6" /etc/sysctl.conf && \
        sed -i 's/^net.ipv6.conf.default.disable_ipv6.*/net.ipv6.conf.default.disable_ipv6 = 1/' /etc/sysctl.conf || \
        echo "net.ipv6.conf.default.disable_ipv6 = 1" >> /etc/sysctl.conf
        
        echo " - IPv6 disable added to sysctl.conf"
    fi
    
    # Create sysctl.d configuration for IPv6 disable
    cat > /etc/sysctl.d/60-ipv6-disable.conf << EOF
# Disable IPv6 - Remediated by $SCRIPT_NAME
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
EOF
    echo " - IPv6 disable configuration created in /etc/sysctl.d/"
    
    return 0
}

# Function to secure_ipv6_config
secure_ipv6_config() {
    echo "Securing IPv6 configuration..."
    
    # Backup existing sysctl configurations
    if [ -f "/etc/sysctl.conf" ]; then
        cp /etc/sysctl.conf "/etc/sysctl.conf.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Apply secure IPv6 sysctl settings immediately
    echo " - Applying secure IPv6 sysctl settings..."
    sysctl -w net.ipv6.conf.all.accept_ra=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.default.accept_ra=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.all.accept_redirects=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.default.accept_redirects=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.all.forwarding=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.default.forwarding=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.all.autoconf=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.default.autoconf=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.all.accept_source_route=0 2>/dev/null || true
    sysctl -w net.ipv6.conf.default.accept_source_route=0 2>/dev/null || true
    
    # Create dedicated IPv6 security configuration for persistence
    cat > /etc/sysctl.d/60-ipv6-security.conf << EOF
# IPv6 Security Settings - Remediated by $SCRIPT_NAME
net.ipv6.conf.all.accept_ra = 0
net.ipv6.conf.default.accept_ra = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv6.conf.all.forwarding = 0
net.ipv6.conf.default.forwarding = 0
net.ipv6.conf.all.autoconf = 0
net.ipv6.conf.default.autoconf = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0
net.ipv6.conf.all.rp_filter = 1
net.ipv6.conf.default.rp_filter = 1
EOF
    
    echo " - Secure IPv6 sysctl configuration created in /etc/sysctl.d/"
    
    # Apply settings from the configuration file
    if sysctl -p /etc/sysctl.d/60-ipv6-security.conf 2>/dev/null; then
        echo " - Secure IPv6 settings applied persistently"
    else
        echo " - WARNING: Could not apply all IPv6 security settings persistently"
    fi
    
    return 0
}

# Function to remove_ipv6_addresses
remove_ipv6_addresses() {
    echo "Removing IPv6 addresses from interfaces..."
    
    # Get list of network interfaces (excluding loopback)
    interfaces=$(ip -o link show | awk -F': ' '{print $2}' | grep -v lo)
    
    for interface in $interfaces; do
        # Remove all IPv6 addresses from interface
        if ip -6 addr show dev "$interface" 2>/dev/null | grep -q "inet6"; then
            echo " - Removing IPv6 addresses from $interface"
            # Remove global addresses
            ip -6 addr show dev "$interface" 2>/dev/null | grep "inet6" | grep "global" | awk '{print $2}' | while read -r addr; do
                ip -6 addr del "$addr" dev "$interface" 2>/dev/null && echo "   - Removed: $addr" || echo "   - Failed to remove: $addr"
            done
        fi
    done
    
    return 0
}

# Function to disable_ipv6_grub
disable_ipv6_grub() {
    echo "Configuring GRUB to disable IPv6 at boot..."
    
    if [ -f "/etc/default/grub" ]; then
        cp /etc/default/grub "/etc/default/grub.backup.$(date +%Y%m%d_%H%M%S)"
        
        # Check if ipv6.disable parameter already exists
        if grep -q "ipv6.disable" /etc/default/grub; then
            # Update existing parameter
            sed -i 's/ipv6.disable=[0-1]/ipv6.disable=1/' /etc/default/grub
        else
            # Add parameter to GRUB_CMDLINE_LINUX
            if grep -q "^GRUB_CMDLINE_LINUX=" /etc/default/grub; then
                sed -i 's/^GRUB_CMDLINE_LINUX="\([^"]*\)"/GRUB_CMDLINE_LINUX="\1 ipv6.disable=1"/' /etc/default/grub
            else
                echo 'GRUB_CMDLINE_LINUX="ipv6.disable=1"' >> /etc/default/grub
            fi
        fi
        
        echo " - IPv6 disable added to GRUB configuration"
        
        # Update GRUB configuration
        if command -v update-grub >/dev/null 2>&1; then
            update-grub 2>/dev/null && echo " - GRUB configuration updated"
        elif command -v grub2-mkconfig >/dev/null 2>&1; then
            grub2-mkconfig -o /boot/grub2/grub.cfg 2>/dev/null && echo " - GRUB configuration updated"
        elif command -v grub-mkconfig >/dev/null 2>&1; then
            grub-mkconfig -o /boot/grub/grub.cfg 2>/dev/null && echo " - GRUB configuration updated"
        else
            echo " - WARNING: Could not update GRUB configuration"
        fi
    else
        echo " - WARNING: GRUB configuration file not found"
    fi
    
    return 0
}

# Function to disable_ipv6_modules
disable_ipv6_modules() {
    echo "Disabling IPv6 kernel modules..."
    
    # Create modprobe configuration to disable IPv6
    cat > /etc/modprobe.d/ipv6-disable.conf << EOF
# Disable IPv6 kernel module - Remediated by $SCRIPT_NAME
install ipv6 /bin/true
alias net-pf-10 off
alias ipv6 off
options ipv6 disable=1
EOF
    
    echo " - IPv6 module disable configuration created"
    
    # Unload IPv6 module if loaded
    if lsmod | grep -q ipv6; then
        if modprobe -r ipv6 2>/dev/null; then
            echo " - IPv6 kernel module unloaded"
        else
            echo " - WARNING: Could not unload IPv6 kernel module (may be in use)"
        fi
    fi
    
    return 0
}

# Function to configure_ipv6_firewall
configure_ipv6_firewall() {
    echo "Configuring IPv6 firewall rules..."
    
    # Configure firewalld for IPv6 if available
    if command -v firewall-cmd >/dev/null 2>&1; then
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld for IPv6..."
            
            # Ensure firewalld is running for IPv6
            if systemctl is-active firewalld >/dev/null 2>&1; then
                # Set default zone (if not set)
                firewall-cmd --get-default-zone >/dev/null 2>&1 || firewall-cmd --set-default-zone=public
                
                # Block unnecessary IPv6 services
                firewall-cmd --permanent --remove-service=dhcpv6-client 2>/dev/null || true
                firewall-cmd --reload 2>/dev/null || true
                
                echo " - firewalld IPv6 configuration updated"
            fi
        fi
    fi
    
    # Configure iptables/ip6tables rules
    if command -v ip6tables >/dev/null 2>&1; then
        echo " - Configuring ip6tables rules..."
        
        # Flush existing rules
        ip6tables -F 2>/dev/null || true
        
        # Set default policies
        ip6tables -P INPUT DROP 2>/dev/null || true
        ip6tables -P FORWARD DROP 2>/dev/null || true
        ip6tables -P OUTPUT ACCEPT 2>/dev/null || true
        
        # Allow loopback
        ip6tables -A INPUT -i lo -j ACCEPT 2>/dev/null || true
        ip6tables -A OUTPUT -o lo -j ACCEPT 2>/dev/null || true
        
        # Allow established connections
        ip6tables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null || true
        
        # Allow ICMPv6 (necessary for IPv6 functionality)
        ip6tables -A INPUT -p ipv6-icmp -j ACCEPT 2>/dev/null || true
        
        # Allow SSH (port 22) if it's currently listening
        ip6tables -A INPUT -p tcp --dport 22 -j ACCEPT 2>/dev/null || true
        
        echo " - ip6tables basic rules configured"
        
        # Save rules if possible
        if command -v ip6tables-save >/dev/null 2>&1 && [ -d "/etc/sysconfig" ]; then
            ip6tables-save > /etc/sysconfig/ip6tables 2>/dev/null && echo " - IPv6 firewall rules saved"
        elif command -v ip6tables-save >/dev/null 2>&1; then
            mkdir -p /etc/iptables
            ip6tables-save > /etc/iptables/rules.v6 2>/dev/null && echo " - IPv6 firewall rules saved"
        fi
    else
        echo " - WARNING: ip6tables not available, skipping IPv6 firewall configuration"
    fi
    
    return 0
}

# Function to verify_ipv6_remediation
verify_ipv6_remediation() {
    echo "Verifying IPv6 remediation..."
    
    verification_passed=true
    
    # Check if IPv6 is disabled in kernel (only for complete disable mode)
    if [ "${remediation_method:-}" = "disabled" ]; then
        if [ -f "/proc/sys/net/ipv6/conf/all/disable_ipv6" ]; then
            if [ "$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6)" -eq 1 ]; then
                echo "PASS: IPv6 is disabled in kernel"
            else
                echo "FAIL: IPv6 is still enabled in kernel"
                verification_passed=false
            fi
        fi
    fi
    
    # Check for IPv6 addresses (warning only for secure mode)
    if ip -6 addr show | grep -q "inet6"; then
        if [ "${remediation_method:-}" = "disabled" ]; then
            echo "FAIL: IPv6 addresses still configured"
            verification_passed=false
        else
            echo "INFO: IPv6 addresses still configured (expected for secure mode)"
        fi
    else
        echo "PASS: No IPv6 addresses configured"
    fi
    
    # Check sysctl security settings
    secure_settings=(
        "net.ipv6.conf.all.accept_ra"
        "net.ipv6.conf.all.accept_redirects"
        "net.ipv6.conf.all.forwarding"
    )
    
    for setting in "${secure_settings[@]}"; do
        current_value=$(sysctl -n "$setting" 2>/dev/null || echo "unknown")
        if [ "$current_value" = "0" ]; then
            echo "PASS: $setting = 0"
        elif [ "$current_value" = "unknown" ]; then
            echo "INFO: $setting not available"
        else
            echo "FAIL: $setting = $current_value (expected 0)"
            if [ "${remediation_method:-}" = "secured" ]; then
                verification_passed=false
            fi
        fi
    done
    
    # Check for IPv6 listening services
    if ss -tulpn6 2>/dev/null | grep -q LISTEN; then
        if [ "${remediation_method:-}" = "disabled" ]; then
            echo "FAIL: IPv6 services still listening"
            verification_passed=false
        else
            echo "INFO: IPv6 services still listening (expected for secure mode)"
        fi
        ss -tulpn6 2>/dev/null | grep LISTEN | awk '{print "   - "$5" ("$1")"}'
    else
        echo "PASS: No IPv6 listening services detected"
    fi
    
    # Check GRUB configuration (only for complete disable mode)
    if [ "${remediation_method:-}" = "disabled" ]; then
        if [ -f "/etc/default/grub" ] && grep -q "ipv6.disable=1" /etc/default/grub; then
            echo "PASS: IPv6 disable configured in GRUB"
        else
            echo "INFO: IPv6 disable not in GRUB"
        fi
    fi
    
    # Check modprobe configuration (only for complete disable mode)
    if [ "${remediation_method:-}" = "disabled" ]; then
        if [ -f "/etc/modprobe.d/ipv6-disable.conf" ]; then
            echo "PASS: IPv6 module disable configuration exists"
        else
            echo "INFO: IPv6 module disable not configured"
        fi
    fi
    
    # Check firewall configuration
    if command -v ip6tables >/dev/null 2>&1; then
        if ip6tables -L INPUT 2>/dev/null | grep -q "DROP"; then
            echo "PASS: IPv6 firewall has restrictive policies"
        else
            echo "INFO: IPv6 firewall not configured or has permissive policies"
        fi
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Function to get_user_preference
get_user_preference() {
    echo "==================================================================="
    echo "IPv6 Remediation Options:"
    echo "==================================================================="
    echo "1. COMPLETE DISABLE - Disable IPv6 completely (Recommended for IPv4-only networks)"
    echo "2. SECURE CONFIGURATION - Keep IPv6 enabled but apply security hardening"
    echo "3. SKIP - No changes to IPv6 configuration"
    echo ""
    
    while true; do
        read -p "Select option (1-3) [1]: " choice
        choice=${choice:-1}
        
        case $choice in
            1)
                echo "Selected: COMPLETE DISABLE"
                return 1
                ;;
            2)
                echo "Selected: SECURE CONFIGURATION" 
                return 2
                ;;
            3)
                echo "Selected: SKIP"
                return 3
                ;;
            *)
                echo "Invalid selection. Please choose 1, 2, or 3."
                ;;
        esac
    done
}

# FORCE MODE - Auto-select option 2 (Secure Configuration) and execute all remediation
echo "FORCE MODE: Applying secure IPv6 configuration..."
echo ""

# Check current IPv6 status
detect_ipv6_status
echo ""

# Apply secure configuration (Option 2)
echo "==================================================================="
echo "SECURE CONFIGURATION: Applying IPv6 security hardening"
echo "==================================================================="
echo ""

# Apply secure IPv6 configurations
secure_ipv6_config
echo ""

# Configure IPv6 firewall
configure_ipv6_firewall
echo ""

remediation_method="secured"

# Final verification
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""

if verify_ipv6_remediation; then
    echo ""
    echo "SUCCESS: IPv6 has been successfully secured"
    echo ""
    echo "REMEDIATION SUMMARY:"
    echo "==================="
    echo "✓ IPv6 security configurations applied"
    echo "✓ IPv6 sysctl settings secured"
    echo "✓ IPv6 firewall rules configured"
    echo "✓ IPv6 remains functional but secured"
else
    echo ""
    echo "WARNING: Some IPv6 security settings may not be fully applied"
    echo "Some components may require manual intervention or system reboot."
    echo ""
    echo "RECOMMENDED ACTIONS:"
    echo "===================="
    echo "1. Reboot the system to ensure all settings are fully applied"
    echo "2. Check IPv6 status: ip -6 addr show"
    echo "3. Verify sysctl settings: sysctl -a | grep ipv6"
    echo "4. Test IPv6 connectivity if required for your environment"
fi

# Show current status summary
echo ""
echo "CURRENT STATUS SUMMARY:"
echo "======================"
echo "IPv6 kernel enabled: $(cat /proc/sys/net/ipv6/conf/all/disable_ipv6 2>/dev/null || echo "unknown")"
echo "IPv6 addresses: $(ip -6 addr show 2>/dev/null | grep -c "inet6" || echo "0")"
echo "IPv6 routes: $(ip -6 route show 2>/dev/null | wc -l || echo "0")"
echo "IPv6 listening services: $(ss -tulpn6 2>/dev/null | grep -c LISTEN || echo "0")"
echo "IPv6 accept_ra: $(sysctl -n net.ipv6.conf.all.accept_ra 2>/dev/null || echo "unknown")"
echo "IPv6 accept_redirects: $(sysctl -n net.ipv6.conf.all.accept_redirects 2>/dev/null || echo "unknown")"
echo "IPv6 forwarding: $(sysctl -n net.ipv6.conf.all.forwarding 2>/dev/null || echo "unknown")"

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="