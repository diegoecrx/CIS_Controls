#!/usr/bin/env bash

# Script: 3.4.2.4.sh
# Item: 3.4.2.4 Ensure network interfaces are assigned to appropriate zone (Manual)


set -euo pipefail

SCRIPT_NAME="3.4.2.4.sh"
ITEM_NAME="3.4.2.4 Ensure network interfaces are assigned to appropriate zone (Manual)"
DESCRIPTION="Assign network interfaces to appropriate firewalld zones according to site policy"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current firewalld zone assignments for network interfaces..."
    echo ""

    # Check if firewalld is installed and running
    if ! command -v firewall-cmd >/dev/null 2>&1; then
        echo "firewalld is NOT INSTALLED on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    if ! systemctl is-active firewalld >/dev/null 2>&1; then
        echo "firewalld is NOT ACTIVE on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi

    # Display current firewalld zone configuration
    echo "Current firewalld zone configuration:"
    echo "====================================="
    
    # Get default zone
    echo "Default zone:"
    echo "-------------"
    default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
    echo "$default_zone"
    
    echo ""
    
    # Get all active zones and their interfaces
    echo "Active zones and interface assignments:"
    echo "---------------------------------------"
    firewall-cmd --get-active-zones 2>/dev/null || echo "Unable to get active zones"
    
    echo ""
    
    # Get all available zones
    echo "All available zones:"
    echo "--------------------"
    firewall-cmd --get-zones 2>/dev/null | tr ' ' '\n' | head -10
    
    echo ""
    
    # Get detailed information for each active zone
    echo "Detailed zone configurations:"
    echo "-----------------------------"
    active_zones=$(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^ ' | head -5)
    for zone in $active_zones; do
        echo "Zone: $zone"
        firewall-cmd --list-all --zone="$zone" 2>/dev/null | head -8
        echo ""
    done
    
    echo ""
    
    # Get network interface information
    echo "Network interface information:"
    echo "------------------------------"
    if command -v ip >/dev/null 2>&1; then
        echo "Network interfaces:"
        ip link show | grep -E '^[0-9]+:' | awk -F: '{print $2}' | tr -d ' ' | grep -v lo | head -10
    else
        ifconfig -a | grep -E '^[a-zA-Z]' | awk '{print $1}' | tr -d ':' | grep -v lo | head -10
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_interface_zone_assignments()
    {
        echo " - Checking current interface zone assignments..."
        
        # Get all network interfaces (excluding loopback)
        if command -v ip >/dev/null 2>&1; then
            interfaces=$(ip link show | grep -E '^[0-9]+:' | awk -F: '{print $2}' | tr -d ' ' | grep -v '^lo$' | grep -v '^$')
        else
            interfaces=$(ifconfig -a | grep -E '^[a-zA-Z]' | awk '{print $1}' | tr -d ':' | grep -v '^lo$' | grep -v '^$')
        fi
        
        # Get interfaces in active zones
        zone_interfaces=$(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^ ' | while read zone; do
            firewall-cmd --list-interfaces --zone="$zone" 2>/dev/null | xargs -n1 echo
        done)
        
        unassigned_interfaces=()
        for interface in $interfaces; do
            if ! echo "$zone_interfaces" | grep -q "^$interface$"; then
                unassigned_interfaces+=("$interface")
                echo " - UNASSIGNED: Interface '$interface' is not assigned to any zone"
            fi
        done
        
        if [ ${#unassigned_interfaces[@]} -eq 0 ]; then
            echo " - OK: All interfaces are assigned to zones"
        fi
    }

    check_default_zone_usage()
    {
        echo " - Checking default zone usage..."
        
        default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
        default_zone_interfaces=$(firewall-cmd --list-interfaces --zone="$default_zone" 2>/dev/null)
        
        if [ -n "$default_zone_interfaces" ]; then
            echo " - Interfaces in default zone ($default_zone): $default_zone_interfaces"
            echo " - REVIEW: Ensure these interfaces belong in the default zone"
        else
            echo " - OK: No interfaces in default zone"
        fi
    }

    check_zone_security_levels()
    {
        echo " - Checking zone security levels..."
        
        # Common zones and their typical security levels
        declare -A zone_security=(
            ["drop"]="high"
            ["block"]="high" 
            ["public"]="medium"
            ["external"]="medium"
            ["dmz"]="medium"
            ["work"]="low"
            ["home"]="low"
            ["internal"]="low"
            ["trusted"]="very low"
        )
        
        active_zones=$(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^ ' | head -10)
        for zone in $active_zones; do
            if [ -n "${zone_security[$zone]}" ]; then
                echo " - Zone '$zone': ${zone_security[$zone]} security"
            else
                echo " - Zone '$zone': custom zone (review security level)"
            fi
        done
    }

    provide_remediation_guidance()
    {
        echo " - Providing zone assignment remediation guidance..."
        
        echo ""
        echo "ZONE ASSIGNMENT REMEDIATION GUIDANCE:"
        echo "====================================="
        echo ""
        echo "For each interface identified above:"
        echo ""
        echo "ASSIGN INTERFACE TO APPROPRIATE ZONE:"
        echo "  firewall-cmd --zone=<zone_name> --change-interface=<interface_name>"
        echo "  Example: firewall-cmd --zone=internal --change-interface=eth1"
        echo ""
        echo "MAKE ZONE ASSIGNMENT PERMANENT:"
        echo "  firewall-cmd --zone=<zone_name> --change-interface=<interface_name> --permanent"
        echo "  -OR-"
        echo "  firewall-cmd --runtime-to-permanent"
        echo ""
        echo "CHANGE DEFAULT ZONE (if needed):"
        echo "  firewall-cmd --set-default-zone=<zone_name>"
        echo ""
        echo "COMMON ZONE USAGE:"
        echo "  external   - For external facing interfaces (internet)"
        echo "  internal   - For internal network interfaces"
        echo "  dmz        - For DMZ interfaces"
        echo "  public     - For general public access interfaces"
        echo "  work/home  - For office/home network interfaces"
        echo "  drop/block - For maximum security (blocks all incoming)"
        echo ""
        echo "VERIFY ASSIGNMENTS:"
        echo "  firewall-cmd --get-active-zones"
        echo "  firewall-cmd --list-interfaces --zone=<zone_name>"
        echo "  firewall-cmd --list-all --zone=<zone_name>"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking interface zone assignments..."
    check_interface_zone_assignments
    remediation_applied=true
    
    echo ""
    echo "Checking default zone usage..."
    check_default_zone_usage
    remediation_applied=true
    
    echo ""
    echo "Checking zone security levels..."
    check_zone_security_levels
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No firewalld zone configuration issues detected"
    fi

    echo ""
    echo "Remediation of firewalld zone assignments complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify default zone
    echo ""
    echo "1. VERIFYING DEFAULT ZONE:"
    echo "--------------------------"
    default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
    echo "Default zone: $default_zone"
    echo "PROOF (firewall-cmd --get-default-zone): $default_zone"
    
    # PROOF 2: Verify all active zones and interfaces
    echo ""
    echo "2. VERIFYING ACTIVE ZONES AND INTERFACES:"
    echo "-----------------------------------------"
    active_zones=$(firewall-cmd --get-active-zones 2>/dev/null || echo "none")
    if [ "$active_zones" != "none" ]; then
        echo "Active zones and their interfaces:"
        echo "$active_zones"
        echo ""
        echo "PROOF (detailed zone info):"
        firewall-cmd --get-active-zones 2>/dev/null | while read line; do
            if [[ ! "$line" =~ ^[[:space:]] ]]; then
                zone="$line"
                echo "Zone: $zone"
                interfaces=$(firewall-cmd --list-interfaces --zone="$zone" 2>/dev/null || echo "none")
                echo "  Interfaces: $interfaces"
            fi
        done
    fi
    
    # PROOF 3: Verify all network interfaces are assigned
    echo ""
    echo "3. VERIFYING ALL INTERFACES ARE ASSIGNED:"
    echo "-----------------------------------------"
    # Get all network interfaces (excluding loopback)
    if command -v ip >/dev/null 2>&1; then
        all_interfaces=$(ip link show | grep -E '^[0-9]+:' | awk -F: '{print $2}' | tr -d ' ' | grep -v '^lo$' | grep -v '^$' | sort)
    else
        all_interfaces=$(ifconfig -a | grep -E '^[a-zA-Z]' | awk '{print $1}' | tr -d ':' | grep -v '^lo$' | grep -v '^$' | sort)
    fi
    
    # Get all assigned interfaces
    assigned_interfaces=$(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^ ' | while read zone; do
        firewall-cmd --list-interfaces --zone="$zone" 2>/dev/null
    done | xargs -n1 | sort -u)
    
    unassigned_count=0
    for interface in $all_interfaces; do
        if ! echo "$assigned_interfaces" | grep -q "^$interface$"; then
            echo "UNASSIGNED: Interface '$interface' is not in any zone"
            unassigned_count=$((unassigned_count + 1))
            final_status_pass=false
        fi
    done
    
    if [ $unassigned_count -eq 0 ]; then
        echo "PASS: All network interfaces are assigned to zones"
        echo "PROOF: All interfaces found in active zones"
    fi
    
    # PROOF 4: Verify zone configurations
    echo ""
    echo "4. VERIFYING ZONE CONFIGURATIONS:"
    echo "---------------------------------"
    echo "Zone configurations summary:"
    active_zones_list=$(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^ ' | head -3)
    for zone in $active_zones_list; do
        echo ""
        echo "Zone: $zone"
        firewall-cmd --list-all --zone="$zone" 2>/dev/null | grep -E '(target|services|ports|interfaces)' | head -5
    done
    
    # PROOF 5: Manual verification steps reminder
    echo ""
    echo "5. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review zone assignments against network topology"
    echo "• Ensure external interfaces are in appropriate zones (external, public)"
    echo "• Ensure internal interfaces are in appropriate zones (internal, work, home)"
    echo "• Verify zone target settings (default, ACCEPT, DROP, REJECT)"
    echo "• Document zone assignments for audit purposes"
    echo ""
    echo "ZONE MANAGEMENT COMMANDS:"
    echo "========================="
    echo ""
    echo "VIEW CURRENT ASSIGNMENTS:"
    echo "  firewall-cmd --get-active-zones"
    echo "  firewall-cmd --list-all-zones"
    echo "  firewall-cmd --get-default-zone"
    echo ""
    echo "ASSIGN INTERFACES TO ZONES:"
    echo "  firewall-cmd --zone=<zone> --change-interface=<interface>"
    echo "  firewall-cmd --zone=<zone> --change-interface=<interface> --permanent"
    echo ""
    echo "CHANGE DEFAULT ZONE:"
    echo "  firewall-cmd --set-default-zone=<zone>"
    echo "  firewall-cmd --set-default-zone=<zone> --permanent"
    echo ""
    echo "VIEW ZONE DETAILS:"
    echo "  firewall-cmd --list-all --zone=<zone>"
    echo "  firewall-cmd --list-services --zone=<zone>"
    echo "  firewall-cmd --list-ports --zone=<zone>"
    echo ""
    echo "MAKE CHANGES PERMANENT:"
    echo "  firewall-cmd --runtime-to-permanent"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Firewalld zone assignment verification completed"
        echo "NOTE: Manual review required to ensure zones match network topology"
    else
        echo ""
        echo "WARNING: Zone assignment issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="