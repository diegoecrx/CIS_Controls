#!/usr/bin/env bash

# Script: 1.1.2.3.2.sh
# Item: 1.1.2.3.2 Ensure nodev option set on /home partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.3.2.sh"
ITEM_NAME="1.1.2.3.2 Ensure nodev option set on /home partition (Automated)"
DESCRIPTION="This remediation ensures the nodev option is set on the /home partition to prevent device files."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /home mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /home mount information:"
    mount | grep -E '\s/home\s' || echo "No separate /home mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /home:"
    grep -E '\s/home\s' /etc/fstab || echo "No /home entry in /etc/fstab"
    echo ""

    # Check if /home is a separate partition
    echo "Checking if /home is a separate partition:"
    home_device=$(df /home --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$home_device" ] && [ -n "$root_device" ] && [ "$home_device" != "$root_device" ]; then
        echo "PASS: /home is on separate partition: $home_device"
        home_is_separate=true
    else
        echo "FAIL: /home is NOT on separate partition"
        echo "PROOF: /home shares device with root filesystem"
        home_is_separate=false
    fi
    echo ""

    # Only proceed with remediation if /home is a separate partition
    if [ "$home_is_separate" = false ]; then
        echo "==================================================================="
        echo "REMEDIATION SKIPPED:"
        echo "==================================================================="
        echo "This remediation requires /home to be a separate partition."
        echo "Please ensure 1.1.2.3.1 (separate /home partition) is implemented first."
        echo ""
        echo "To create a separate /home partition:"
        echo "1. Backup home directory data"
        echo "2. Create new partition using fdisk or similar tool"
        echo "3. Format partition: mkfs.ext4 /dev/sdX1"
        echo "4. Update /etc/fstab with appropriate entry"
        echo "5. Mount and restore data"
        echo ""
        exit 0
    fi

    echo "Applying remediation..."

    # Function to update fstab with nodev option
    update_fstab_nodev()
    {
        # Check if /home entry exists in fstab
        if grep -q -E '\s/home\s' /etc/fstab; then
            echo " - Checking /home entry in /etc/fstab for nodev option"
            
            # Get the current /home entry
            current_entry=$(grep -E '\s/home\s' /etc/fstab)
            
            # Check if nodev option is already present
            if echo "$current_entry" | grep -q 'nodev'; then
                echo " - nodev option already present in /etc/fstab"
                return 0
            else
                echo " - Adding nodev option to /etc/fstab"
                
                # Create temporary fstab without /home entry
                grep -v -E '\s/home\s' /etc/fstab > /etc/fstab.tmp
                
                # Add nodev option to the mount options field (4th field)
                updated_entry=$(echo "$current_entry" | awk '
                {
                    for(i=1; i<=NF; i++) {
                        if(i==4) {
                            # Add nodev to mount options if not already present
                            if($i ~ /nodev/) {
                                print $0
                            } else {
                                # Handle options with and without commas
                                if($i ~ /,$/) {
                                    gsub(/,$/, "", $i)
                                    $i = $i ",nodev"
                                } else {
                                    $i = $i ",nodev"
                                }
                                # Reconstruct the line
                                for(j=1; j<=NF; j++) {
                                    printf "%s", $j
                                    if(j<NF) printf " "
                                }
                                printf "\n"
                            }
                        }
                    }
                }')
                
                # If awk processing failed, use simpler approach
                if [ -z "$updated_entry" ]; then
                    # Simple approach: just add nodev to the options
                    updated_entry=$(echo "$current_entry" | sed 's/\(defaults,[^[:space:]]*\)/\1,nodev/' 2>/dev/null || echo "$current_entry")
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                
                # Backup original and replace
                cp /etc/fstab /etc/fstab.bak
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /home entry in /etc/fstab with nodev option"
            fi
        else
            echo " - ERROR: No /home entry found in /etc/fstab"
            return 1
        fi
    }

    # Function to remount /home with nodev option
    remount_home_nodev()
    {
        echo " - Checking /home mount for nodev option"
        
        # Check if /home is mounted as separate filesystem
        if mount | grep -q -E '\s/home\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/home\s')
            
            # Check if nodev is already set in current mount
            if echo "$mount_line" | grep -q 'nodev'; then
                echo " - nodev option already set on current /home mount"
            else
                echo " - Remounting /home with nodev option"
                # Add nodev to current options and remount
                if mount -o remount,nodev /home; then
                    echo " - SUCCESS: /home remounted with nodev option"
                else
                    echo " - WARNING: Could not remount /home with nodev option"
                    return 1
                fi
            fi
        else
            echo " - ERROR: /home is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nodev; then
        remount_home_nodev
    else
        echo " - Skipping remount due to missing /home configuration"
    fi

    echo ""
    echo "Remediation of nodev option on /home partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /home is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /home IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "----------------------------------------------------"
    mount_output=$(mount | grep -E '\s/home\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /home is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /home is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nodev option in current mount
    echo ""
    echo "2. VERIFYING nodev OPTION IN CURRENT MOUNT:"
    echo "------------------------------------------"
    mount_line=$(mount | grep -E '\s/home\s' || true)
    if echo "$mount_line" | grep -q 'nodev'; then
        echo "PASS: nodev option set on current /home mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nodev option NOT set on current /home mount - attempting remount"
        if mount -o remount,nodev /home 2>/dev/null; then
            mount_line=$(mount | grep -E '\s/home\s' || true)
            if echo "$mount_line" | grep -q 'nodev'; then
                echo "PASS: nodev option now set on /home mount"
                echo "PROOF (mount output):"
                echo "$mount_line"
            else
                echo "FAIL: Could not set nodev option on /home mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /home with nodev option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nodev option in fstab
    echo ""
    echo "3. VERIFYING nodev OPTION IN /etc/fstab:"
    echo "---------------------------------------"
    fstab_entry=$(grep -E '\s/home\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nodev'; then
            echo "PASS: nodev option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nodev option NOT found in /etc/fstab - updating now"
            # Remove existing entry
            grep -v -E '\s/home\s' /etc/fstab > /etc/fstab.tmp
            # Add nodev to mount options (4th field)
            if echo "$fstab_entry" | grep -q 'defaults,'; then
                updated_entry=$(echo "$fstab_entry" | sed 's/defaults,/defaults,nodev,/' | sed 's/,,/,/g')
            else
                # If no defaults, add nodev to beginning of options
                updated_entry=$(echo "$fstab_entry" | awk '{$4=$4",nodev"; print}')
            fi
            echo "$updated_entry" >> /etc/fstab.tmp
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nodev option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/home\s' /etc/fstab
        fi
    else
        echo "FAIL: No /home entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_nodev=$(grep -E '\s/home\s' /etc/fstab | grep -o 'nodev' | head -1 || true)
    mount_has_nodev=$(mount | grep -E '\s/home\s' | grep -o 'nodev' | head -1 || true)
    
    if [ -n "$fstab_has_nodev" ] && [ -n "$mount_has_nodev" ]; then
        echo "PASS: nodev option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab options: $(grep -E '\s/home\s' /etc/fstab | awk '{print $4}')"
        echo "  mount options: $(mount | grep -E '\s/home\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_has_nodev" ] && [ -z "$mount_has_nodev" ]; then
        echo "FAIL: nodev in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_has_nodev" ] && [ -n "$mount_has_nodev" ]; then
        echo "FAIL: nodev in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nodev option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Verify no device files in /home
    echo ""
    echo "5. VERIFYING NO DEVICE FILES IN /home:"
    echo "-------------------------------------"
    device_files=$(find /home -type c -o -type b 2>/dev/null | wc -l)
    if [ "$device_files" -eq 0 ]; then
        echo "PASS: No device files found in /home"
        echo "PROOF: find /home -type c -o -type b returned 0 files"
    else
        echo "WARNING: Found $device_files device files in /home"
        echo "PROOF (first 5 device files):"
        find /home -type c -o -type b 2>/dev/null | head -5
        echo " - Note: These may be legitimate device files for applications"
        echo " - Manual review recommended before removal"
    fi

    # PROOF 6: Test device file creation (should fail with nodev)
    echo ""
    echo "6. TESTING DEVICE FILE CREATION BLOCKED:"
    echo "---------------------------------------"
    test_device="/home/test_device_$$"
    if mknod "$test_device" c 1 3 2>/dev/null; then
        echo "FAIL: Device file creation succeeded - nodev may not be working"
        echo "PROOF: mknod command succeeded in /home"
        rm -f "$test_device"
        final_status_pass=false
    else
        echo "PASS: Device file creation blocked - nodev is working"
        echo "PROOF: mknod command failed in /home"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="