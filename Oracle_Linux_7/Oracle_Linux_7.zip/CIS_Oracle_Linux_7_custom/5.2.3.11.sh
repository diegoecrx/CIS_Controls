#!/usr/bin/env bash
# Script: 5.2.3.11.sh
# Item: 5.2.3.11 Ensure session initiation information is collected (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.11.sh"
ITEM_NAME="5.2.3.11 Ensure session initiation information is collected (Automated)"
DESCRIPTION="This remediation ensures session initiation information is collected by configuring audit rules for session tracking files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking session initiation audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Define required session files to monitor
    required_files=(
        "/var/run/utmp"
        "/var/log/wtmp"
        "/var/log/btmp"
    )
    
    # Check for session audit rules in running configuration
    session_rules_found=true
    missing_files=()
    
    for file in "${required_files[@]}"; do
        if ! auditctl -l | grep -q "\-w $file \-p wa \-k session"; then
            session_rules_found=false
            missing_files+=("$file")
        fi
    done
    
    if [ "$session_rules_found" = false ]; then
        echo "FAIL: session audit rules not found in running configuration"
        echo "PROOF: Missing audit rules for files: ${missing_files[*]}"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        config_missing_files=()
        
        for file in "${required_files[@]}"; do
            if ! grep -r "\-w $file \-p wa \-k session" /etc/audit/rules.d/ >/dev/null 2>&1; then
                config_missing_files+=("$file")
            fi
        done
        
        if [ ${#config_missing_files[@]} -eq 0 ]; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: session audit rules not found in configuration files"
        echo "PROOF: Required audit rules not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: session initiation audit rules properly configured"
    echo "PROOF: All required session audit rules found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_session_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Define required session files to monitor
    required_files=(
        "/var/run/utmp"
        "/var/log/wtmp"
        "/var/log/btmp"
    )
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        missing_rules=0
        
        for file in "${required_files[@]}"; do
            if ! grep -r "\-w $file \-p wa \-k session" /etc/audit/rules.d/ >/dev/null 2>&1; then
                ((missing_rules++))
            fi
        done
        
        if [ $missing_rules -eq 0 ]; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Creating session audit rules in /etc/audit/rules.d/50-session.rules"
        cat > /etc/audit/rules.d/50-session.rules << 'EOF'
## Monitor session initiation information
-w /var/run/utmp -p wa -k session
-w /var/log/wtmp -p wa -k session
-w /var/log/btmp -p wa -k session
EOF
    else
        echo " - Session audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - session audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_session_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: session initiation audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="