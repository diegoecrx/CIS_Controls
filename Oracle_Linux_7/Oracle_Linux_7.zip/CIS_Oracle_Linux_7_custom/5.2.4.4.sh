#!/usr/bin/env bash
# Script: 5.2.4.4.sh
# Item: 5.2.4.4 Ensure only authorized groups are assigned ownership of audit log files (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.4.sh"
ITEM_NAME="5.2.4.4 Ensure only authorized groups are assigned ownership of audit log files (Automated)"
DESCRIPTION="This remediation ensures only authorized groups (root or adm) are assigned ownership of audit log files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit log files group ownership..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo "FAIL: /etc/audit/auditd.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | xargs 2>/dev/null)
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
    fi
    
    log_dir=$(dirname "$log_file")
    
    if [ ! -d "$log_dir" ]; then
        echo "FAIL: audit log directory does not exist"
        echo "PROOF: Directory $log_dir not found"
        return 1
    fi
    
    # Check log_group setting in auditd.conf
    log_group_setting=$(grep "^\s*log_group\s*=" /etc/audit/auditd.conf 2>/dev/null | awk -F"=" '{print $2}' | xargs)
    if [ -z "$log_group_setting" ] || [ "$log_group_setting" != "root" ]; then
        echo "FAIL: log_group not set to root in auditd.conf"
        echo "PROOF: log_group = $log_group_setting (should be root)"
        return 1
    fi
    
    # Check audit log directory group ownership
    log_dir_group=$(stat -c "%G" "$log_dir")
    if [ "$log_dir_group" != "root" ] && [ "$log_dir_group" != "adm" ]; then
        echo "FAIL: audit log directory has incorrect group ownership"
        echo "PROOF: Directory $log_dir is owned by group $log_dir_group (should be root or adm)"
        return 1
    fi
    
    # Check for audit log files with incorrect group ownership
    incorrect_group_files=()
    while IFS= read -r -d '' file; do
        incorrect_group_files+=("$file")
    done < <(find "$log_dir" -type f \( ! -group adm -a ! -group root \) -print0 2>/dev/null)
    
    if [ ${#incorrect_group_files[@]} -gt 0 ]; then
        echo "FAIL: audit log files with incorrect group ownership found"
        echo "PROOF: Files not owned by root or adm group:"
        for file in "${incorrect_group_files[@]}"; do
            group=$(stat -c "%G" "$file")
            echo "  $file: owned by group $group"
        done
        return 1
    fi
    
    echo "PASS: audit log files group ownership properly configured"
    echo "PROOF: All audit log files in $log_dir are owned by authorized groups (root or adm) and log_group is set to root"
    return 0
}
# Function to fix
fix_audit_log_files_group_ownership() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd.conf exists
    if [ ! -f /etc/audit/auditd.conf ]; then
        echo " - Creating /etc/audit/auditd.conf"
        touch /etc/audit/auditd.conf
    fi
    
    # Get audit log directory from auditd.conf
    log_file=$(awk -F"=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | xargs 2>/dev/null)
    if [ -z "$log_file" ]; then
        log_file="/var/log/audit/audit.log"  # Default path
        echo " - Using default log file path: $log_file"
    fi
    
    log_dir=$(dirname "$log_file")
    
    # Create audit log directory if it doesn't exist
    if [ ! -d "$log_dir" ]; then
        echo " - Creating audit log directory: $log_dir"
        mkdir -p "$log_dir"
    fi
    
    echo " - Checking audit log files group ownership in: $log_dir"
    
    # Fix group ownership of audit log directory
    echo " - Setting group ownership of $log_dir to root"
    chgrp root "$log_dir"
    
    # Find and fix files with incorrect group ownership
    incorrect_group_files=()
    while IFS= read -r -d '' file; do
        incorrect_group_files+=("$file")
    done < <(find "$log_dir" -type f \( ! -group adm -a ! -group root \) -print0 2>/dev/null)
    
    if [ ${#incorrect_group_files[@]} -gt 0 ]; then
        echo " - Found ${#incorrect_group_files[@]} files with incorrect group ownership"
        
        for file in "${incorrect_group_files[@]}"; do
            old_group=$(stat -c "%G" "$file")
            echo " - Changing group ownership of $file from $old_group to root"
            chgrp root "$file"
        done
    else
        echo " - All audit log files already have correct group ownership"
    fi
    
    # Run comprehensive group ownership fix (command from the benchmark)
    echo " - Running comprehensive group ownership fix"
    find "$log_dir" -type f \( ! -group adm -a ! -group root \) -exec chgrp root {} + 2>/dev/null || true
    
    # Set log_group parameter in auditd.conf
    echo " - Configuring log_group parameter in auditd.conf"
    if grep -q "^\s*log_group\s*=" /etc/audit/auditd.conf; then
        # Update existing log_group setting
        sed -ri 's/^\s*#?\s*log_group\s*=\s*\S+(\s*#.*)?.*$/log_group = root\1/' /etc/audit/auditd.conf
    else
        # Add log_group setting
        echo "log_group = root" >> /etc/audit/auditd.conf
    fi
    
    # Restart auditd service to apply changes
    if systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Restarting auditd service to apply changes"
        systemctl restart auditd
    fi
    
    echo " - audit log files group ownership configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_log_files_group_ownership
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit log files group ownership properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="