#!/usr/bin/env bash

# Script: 2.2.3.sh
# Item: 2.2.3 Ensure dhcp server services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.3.sh"
ITEM_NAME="2.2.3 Ensure dhcp server services are not in use (Automated)"
DESCRIPTION="This remediation ensures DHCP server services are not in use by removing or masking the services. FORCE VERSION - Comprehensive DHCP server removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_dhcp_server_status
check_dhcp_server_status() {
    echo "Checking DHCP server status..."
    
    dhcp_installed=false
    dhcp_services_running=false
    dhcp_services_enabled=false
    dhcp_services_masked=false
    
    # Check for common DHCP server packages
    dhcp_packages=("dhcp" "dhcp-server" "dhcp3-server" "isc-dhcp-server" "dnsmasq" "dhcpd")
    
    for pkg in "${dhcp_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                dhcp_installed=true
                echo " - $pkg package is installed"
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                dhcp_installed=true
                echo " - $pkg package is installed"
            fi
        fi
    done
    
    # Check for DHCP server processes
    if pgrep dhcpd >/dev/null 2>&1 || pgrep dnsmasq >/dev/null 2>&1; then
        dhcp_services_running=true
        echo " - DHCP server processes running:"
        pgrep dhcpd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep dnsmasq 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
    fi
    
    # Check for DHCP server services
    dhcp_services=("dhcpd" "dhcpd6" "isc-dhcp-server" "isc-dhcp-server6" "dnsmasq")
    
    for service in "${dhcp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            # Check if service is running
            if systemctl is-active "$service" >/dev/null 2>&1; then
                dhcp_services_running=true
                echo " - $service.service is running"
            fi
            
            # Check if service is enabled
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                dhcp_services_enabled=true
                echo " - $service.service is enabled"
            fi
            
            # Check if service is masked
            if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                dhcp_services_masked=true
                echo " - $service.service is masked"
            fi
        fi
    done
    
    # Check for DHCP server network services
    if netstat -tulpn 2>/dev/null | grep -E ':67 |:68 ' | grep -v grep; then
        echo " - WARNING: DHCP server ports (67/68) in use:"
        netstat -tulpn 2>/dev/null | grep -E ':67 |:68 ' || true
    fi
    
    # Check for configuration files
    dhcp_configs=("/etc/dhcp" "/etc/dhcp3" "/etc/dnsmasq.conf" "/etc/dnsmasq.d")
    for config in "${dhcp_configs[@]}"; do
        if [ -e "$config" ]; then
            echo " - DHCP configuration found: $config"
        fi
    done
    
    return 0
}

# Function to stop_dhcp_services
stop_dhcp_services() {
    echo "Stopping DHCP server services..."
    
    # List of DHCP services to stop
    dhcp_services=("dhcpd" "dhcpd6" "isc-dhcp-server" "isc-dhcp-server6" "dnsmasq")
    
    # Stop DHCP processes first
    if pgrep dhcpd >/dev/null 2>&1; then
        echo " - Stopping dhcpd processes..."
        pkill -TERM dhcpd 2>/dev/null || true
        sleep 2
        
        # Force kill if still running
        if pgrep dhcpd >/dev/null 2>&1; then
            echo " - Force stopping dhcpd processes..."
            pkill -KILL dhcpd 2>/dev/null || true
            sleep 1
        fi
    fi
    
    if pgrep dnsmasq >/dev/null 2>&1; then
        echo " - Stopping dnsmasq processes..."
        pkill -TERM dnsmasq 2>/dev/null || true
        sleep 2
        
        # Force kill if still running
        if pgrep dnsmasq >/dev/null 2>&1; then
            echo " - Force stopping dnsmasq processes..."
            pkill -KILL dnsmasq 2>/dev/null || true
            sleep 1
        fi
    fi
    
    # Stop services using systemctl
    for service in "${dhcp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service.service..."
            if systemctl stop "$service" 2>&1; then
                echo "   - $service.service stopped"
            else
                echo "   - WARNING: Could not stop $service.service via systemctl"
            fi
        fi
    done
    
    # Additional stop for any DHCP related services
    systemctl list-unit-files | grep -E "(dhcp|dnsmasq)" | awk '{print $1}' | while read -r service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Verify no DHCP server processes are running
    if pgrep dhcpd >/dev/null 2>&1 || pgrep dnsmasq >/dev/null 2>&1; then
        echo " - CRITICAL: DHCP server processes still running after stop attempts"
        return 1
    else
        echo " - No DHCP server processes running"
    fi
    
    # Kill any remaining DHCP processes
    pkill -9 dhcpd 2>/dev/null || true
    pkill -9 dnsmasq 2>/dev/null || true
    
    return 0
}

# Function to remove_dhcp_packages
remove_dhcp_packages() {
    local pkg_mgr="$1"
    
    echo "Removing DHCP server packages..."
    
    # List of DHCP-related packages
    dhcp_packages=("dhcp" "dhcp-server" "dhcp-common" "dhcp-client" "dhcp3-server" 
                   "isc-dhcp-server" "isc-dhcp-client" "dnsmasq" "dnsmasq-utils")
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove DHCP packages..."
            for pkg in "${dhcp_packages[@]}"; do
                if $pkg_mgr list installed "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if $pkg_mgr remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        apt)
            echo " - Using apt to remove DHCP packages..."
            export DEBIAN_FRONTEND=noninteractive
            for pkg in "${dhcp_packages[@]}"; do
                if dpkg -l "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if apt-get remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        zypper)
            echo " - Using zypper to remove DHCP packages..."
            for pkg in "${dhcp_packages[@]}"; do
                if zypper search --installed-only "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if zypper --non-interactive remove "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove DHCP packages"
            return 1
            ;;
    esac
    
    # Clean up package cache and dependencies
    case "$pkg_mgr" in
        yum|dnf)
            $pkg_mgr autoremove -y 2>/dev/null || true
            ;;
        apt)
            apt-get autoremove -y 2>/dev/null || true
            ;;
    esac
    
    echo " - Package removal completed"
    return 0
}

# Function to mask_dhcp_services
mask_dhcp_services() {
    echo "Masking DHCP server services..."
    
    # List of DHCP services to mask
    dhcp_services=("dhcpd" "dhcpd6" "isc-dhcp-server" "isc-dhcp-server6" "dnsmasq")
    
    for service in "${dhcp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                if systemctl mask "$service" 2>&1; then
                    echo " - $service.service masked"
                else
                    echo " - WARNING: Could not mask $service.service"
                fi
            else
                echo " - $service.service already masked"
            fi
        fi
    done
    
    # Mask any other DHCP related services
    systemctl list-unit-files | grep -E "(dhcp|dnsmasq)" | awk '{print $1}' | while read -r service; do
        if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
            systemctl mask "$service" 2>/dev/null && echo " - $service masked" || true
        fi
    done
    
    return 0
}

# Function to disable_dhcp_services
disable_dhcp_services() {
    echo "Disabling DHCP server services..."
    
    # List of DHCP services to disable
    dhcp_services=("dhcpd" "dhcpd6" "isc-dhcp-server" "isc-dhcp-server6" "dnsmasq")
    
    for service in "${dhcp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl disable "$service" 2>&1; then
                    echo " - $service.service disabled"
                else
                    echo " - WARNING: Could not disable $service.service"
                fi
            else
                echo " - $service.service already disabled"
            fi
        fi
    done
    
    # Disable any other DHCP related services
    systemctl list-unit-files | grep -E "(dhcp|dnsmasq)" | awk '{print $1}' | while read -r service; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            systemctl disable "$service" 2>/dev/null && echo " - $service disabled" || true
        fi
    done
    
    return 0
}

# Function to cleanup_dhcp_configs
cleanup_dhcp_configs() {
    echo "Cleaning up DHCP server configuration files..."
    
    # List of DHCP configuration files to remove or disable
    config_files=(
        "/etc/dhcp"
        "/etc/dhcp3"
        "/etc/dnsmasq.conf"
        "/etc/dnsmasq.d"
        "/etc/rc.d/init.d/dhcpd"
        "/etc/sysconfig/dhcpd"
        "/etc/default/isc-dhcp-server"
        "/etc/default/dnsmasq"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -e "$config_file" ]; then
            if [ -f "$config_file" ]; then
                # Create backup and disable
                backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp "$config_file" "$backup_file"
                echo " - Backed up $config_file to $backup_file"
                
                # Comment out all active configurations or remove file
                if [[ "$config_file" == *.conf ]] || [[ "$config_file" == *dnsmasq* ]]; then
                    sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$config_file" 2>/dev/null || true
                    echo " - Disabled configurations in $config_file"
                else
                    # For non-config files, just backup
                    echo " - Backed up $config_file"
                fi
            elif [ -d "$config_file" ]; then
                # For directories, backup and empty them
                backup_dir="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp -r "$config_file" "$backup_dir" 2>/dev/null || true
                echo " - Backed up $config_file to $backup_dir"
                
                # Remove all configuration files from DHCP directories
                if [ "$config_file" = "/etc/dhcp" ] || [ "$config_file" = "/etc/dhcp3" ]; then
                    find "$config_file" -type f -name "*.conf" -exec sh -c 'echo "# REMEDIATED: $(cat {})" > {}' \; 2>/dev/null || true
                    echo " - Disabled configuration files in $config_file"
                fi
            fi
        fi
    done
    
    # Remove DHCP server from network configurations
    if [ -f "/etc/NetworkManager/NetworkManager.conf" ]; then
        sed -i 's/^dhcp=/# REMEDIATED: dhcp=/' /etc/NetworkManager/NetworkManager.conf 2>/dev/null || true
        echo " - Disabled DHCP in NetworkManager"
    fi
    
    # Remove any DHCP related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -E "(dhcp|dnsmasq)" "$cron_file" 2>/dev/null; then
                sed -i '/dhcp\|dnsmasq/d' "$cron_file" 2>/dev/null || true
                echo " - Removed DHCP references from $cron_file"
            fi
        done
    fi
    
    return 0
}

# Function to block_dhcp_ports
block_dhcp_ports() {
    echo "Blocking DHCP server network ports..."
    
    # DHCP uses UDP ports 67 (server) and 68 (client)
    if command -v firewall-cmd >/dev/null 2>&1; then
        # firewalld
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld to block DHCP server ports..."
            firewall-cmd --permanent --remove-service=dhcp 2>/dev/null || true
            firewall-cmd --permanent --remove-service=dhcpv6 2>/dev/null || true
            firewall-cmd --permanent --remove-port=67/udp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=68/udp 2>/dev/null || true
            firewall-cmd --reload 2>/dev/null || true
            echo " - firewalld configured to block DHCP server ports"
        fi
    fi
    
    # Additional iptables rules for non-firewalld systems
    if command -v iptables >/dev/null 2>&1; then
        echo " - Adding iptables rules to block DHCP server..."
        # Block DHCP server port (67)
        iptables -I INPUT -p udp --dport 67 -j DROP 2>/dev/null || true
        # Block DHCP client port (68) for servers
        iptables -I INPUT -p udp --dport 68 -j DROP 2>/dev/null || true
        echo " - iptables rules added (if supported)"
    fi
    
    return 0
}

# Function to verify_dhcp_removal
verify_dhcp_removal() {
    echo "Verifying DHCP server remediation..."
    
    verification_passed=true
    
    # Check if DHCP packages are installed
    dhcp_packages=("dhcp" "dhcp-server" "isc-dhcp-server" "dnsmasq")
    for pkg in "${dhcp_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        fi
    done
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: DHCP server packages are not installed"
    fi
    
    # Check if DHCP services are running
    dhcp_services=("dhcpd" "dhcpd6" "isc-dhcp-server" "dnsmasq")
    for service in "${dhcp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo "FAIL: $service.service is running"
            verification_passed=false
        else
            echo "PASS: $service.service is not running"
        fi
    done
    
    # Check if DHCP services are enabled or masked
    for service in "${dhcp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                    echo "PASS: $service.service is masked"
                else
                    echo "FAIL: $service.service is enabled"
                    verification_passed=false
                fi
            else
                echo "PASS: $service.service is not enabled"
            fi
        fi
    done
    
    # Check for DHCP processes
    if pgrep dhcpd >/dev/null 2>&1 || pgrep dnsmasq >/dev/null 2>&1; then
        echo "FAIL: DHCP server processes are running"
        verification_passed=false
    else
        echo "PASS: No DHCP server processes running"
    fi
    
    # Check for DHCP server network services
    if ss -tulpn 2>/dev/null | grep -E ':67 |:68 '; then
        echo "WARNING: DHCP server ports (67/68) may still be in use"
        # Check if it's actually a DHCP server or just client
        ss -tulpn 2>/dev/null | grep -E ':67 |:68 ' | while read -r line; do
            if echo "$line" | grep -q ':67 '; then
                echo "   - Port 67 (DHCP server) in use"
            elif echo "$line" | grep -q ':68 '; then
                echo "   - Port 68 (DHCP client) in use - this may be normal for client"
            fi
        done
    else
        echo "PASS: No DHCP server network services detected"
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current DHCP server status..."
    echo ""

    # Check current DHCP server status
    check_dhcp_server_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable DHCP servers
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING DHCP SERVER SERVICES"
    echo "==================================================================="
    echo ""

    # Stop DHCP services first
    if ! stop_dhcp_services; then
        echo " - WARNING: Some issues stopping DHCP server services"
    fi
    echo ""

    # Try to remove DHCP packages
    if remove_dhcp_packages "$pkg_mgr"; then
        echo " - Package removal attempted"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking services instead"
        removal_method="masked"
    fi
    echo ""

    # Mask and disable services (especially if package removal failed)
    if [ "$removal_method" = "masked" ]; then
        if mask_dhcp_services; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        if disable_dhcp_services; then
            echo " - Service disabling successful"
        fi
    fi
    echo ""

    # Cleanup configuration files
    cleanup_dhcp_configs
    echo ""

    # Block network ports
    block_dhcp_ports
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_dhcp_removal; then
        echo ""
        echo "SUCCESS: DHCP server services have been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ DHCP server packages removed"
        else
            echo "✓ DHCP server services masked and disabled"
        fi
        echo "✓ DHCP server services stopped"
        echo "✓ DHCP server processes terminated"
        echo "✓ Configuration files disabled"
        echo "✓ Network ports blocked"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: DHCP server remediation may not be complete"
        echo "Some DHCP server components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining DHCP processes: ps aux | grep -E '(dhcp|dnsmasq)'"
        echo "2. Verify DHCP services are masked: systemctl list-unit-files | grep -E '(dhcp|dnsmasq)'"
        echo "3. Manually remove DHCP packages if needed"
        echo "4. Check network ports: ss -tulpn | grep -E ':67|:68'"
        echo "5. Verify no DHCP configuration files remain in /etc/dhcp* or /etc/dnsmasq*"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Packages installed: $(if command -v rpm >/dev/null && (rpm -q dhcp >/dev/null 2>&1 || rpm -q dnsmasq >/dev/null 2>&1); then echo "YES"; elif command -v dpkg >/dev/null && (dpkg -l isc-dhcp-server >/dev/null 2>&1 || dpkg -l dnsmasq >/dev/null 2>&1); then echo "YES"; else echo "NO"; fi)"
    echo "Services running: $(systemctl is-active dhcpd 2>/dev/null || systemctl is-active isc-dhcp-server 2>/dev/null || echo "NO")"
    echo "Services enabled: $(systemctl is-enabled dhcpd 2>/dev/null || systemctl is-enabled isc-dhcp-server 2>/dev/null || echo "NO")"
    echo "Processes running: $( (pgrep dhcpd 2>/dev/null | wc -l; pgrep dnsmasq 2>/dev/null | wc -l) | awk '{sum+=$1} END {print sum}')"
    echo "Network port 67: $(ss -tulpn 2>/dev/null | grep -c ':67 ' || echo "0")"
    echo "Network port 68: $(ss -tulpn 2>/dev/null | grep -c ':68 ' || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="