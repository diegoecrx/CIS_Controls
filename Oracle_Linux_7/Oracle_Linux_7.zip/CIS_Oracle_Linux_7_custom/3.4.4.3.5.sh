#!/usr/bin/env bash
# Script: 3.4.4.3.5.sh
# Item: 3.4.4.3.5 Ensure ip6tables rules are saved (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.3.5.sh"
ITEM_NAME="3.4.4.3.5 Ensure ip6tables rules are saved (Automated)"
DESCRIPTION="This remediation ensures ip6tables rules are saved and persistent across reboots."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ip6tables rules save configuration..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    # Check if saved rules file exists
    if [ ! -f /etc/sysconfig/ip6tables ]; then
        echo "FAIL: /etc/sysconfig/ip6tables file does not exist"
        echo "PROOF: Saved ip6tables rules file not found"
        return 1
    fi
    
    # Check if ip6tables service is enabled
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo "FAIL: ip6tables service is not enabled"
        echo "PROOF: systemctl is-enabled ip6tables shows disabled"
        return 1
    fi
    
    # Check for essential rules using more flexible patterns
    essential_missing=""
    
    # Check for default DROP policies
    if ! ip6tables -L INPUT 2>/dev/null | head -1 | grep -q "DROP"; then
        essential_missing="${essential_missing}input-drop-policy "
    fi
    
    if ! ip6tables -L FORWARD 2>/dev/null | head -1 | grep -q "DROP"; then
        essential_missing="${essential_missing}forward-drop-policy "
    fi
    
    if ! ip6tables -L OUTPUT 2>/dev/null | head -1 | grep -q "DROP"; then
        essential_missing="${essential_missing}output-drop-policy "
    fi
    
    # Check for IPv6 accept all rule in INPUT (matches "ACCEPT     all    anywhere    anywhere")
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -E "ACCEPT.*all.*0\.0\.0\.0/0.*0\.0\.0\.0/0" >/dev/null; then
        if ! ip6tables -L INPUT -n 2>/dev/null | grep -E "ACCEPT.*all.*::/0.*::/0" >/dev/null; then
            essential_missing="${essential_missing}ipv6-accept-all "
        fi
    fi
    
    # Check for IPv6 loopback drop rule (matches "DROP       all    localhost    anywhere")
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "DROP.*::1"; then
        essential_missing="${essential_missing}ipv6-loopback-drop "
    fi
    
    # Check for established connection rules
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "tcp.*ESTABLISHED"; then
        essential_missing="${essential_missing}tcp-established "
    fi
    
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "udp.*ESTABLISHED"; then
        essential_missing="${essential_missing}udp-established "
    fi
    
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "icmp.*ESTABLISHED"; then
        essential_missing="${essential_missing}icmp-established "
    fi
    
    # Check for SSH rule
    if ! ip6tables -L INPUT -n 2>/dev/null | grep -q "tcp.*22"; then
        essential_missing="${essential_missing}ssh-rule "
    fi
    
    # Check for OUTPUT accept all rule
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -E "ACCEPT.*all.*0\.0\.0\.0/0.*0\.0\.0\.0/0" >/dev/null; then
        if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -E "ACCEPT.*all.*::/0.*::/0" >/dev/null; then
            essential_missing="${essential_missing}output-accept-all "
        fi
    fi
    
    # Check for OUTPUT chain state rules
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -q "tcp.*NEW,ESTABLISHED"; then
        essential_missing="${essential_missing}output-tcp "
    fi
    
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -q "udp.*NEW,ESTABLISHED"; then
        essential_missing="${essential_missing}output-udp "
    fi
    
    if ! ip6tables -L OUTPUT -n 2>/dev/null | grep -q "icmp.*NEW,ESTABLISHED"; then
        essential_missing="${essential_missing}output-icmp "
    fi
    
    if [ -n "$essential_missing" ]; then
        echo "FAIL: Essential ip6tables rules are missing"
        echo "PROOF: Missing IPv6 rules: $essential_missing"
        echo "DEBUG: Current rules - INPUT:"
        ip6tables -L INPUT -n 2>/dev/null | head -10 || true
        echo "DEBUG: Current rules - OUTPUT:"
        ip6tables -L OUTPUT -n 2>/dev/null | head -10 || true
        return 1
    fi
    
    # Check if rules exist in both running and saved configurations
    if [ -f /etc/sysconfig/ip6tables ] && [ -s /etc/sysconfig/ip6tables ]; then
        current_rules_count=$(ip6tables-save 2>/dev/null | grep -c '^-A' || echo "0")
        saved_rules_count=$(grep -c '^-A' /etc/sysconfig/ip6tables 2>/dev/null || echo "0")
        
        if [ "$current_rules_count" -eq 0 ] || [ "$saved_rules_count" -eq 0 ]; then
            echo "FAIL: No rules found in current or saved IPv6 configuration"
            echo "PROOF: Current IPv6 rules: $current_rules_count, Saved IPv6 rules: $saved_rules_count"
            return 1
        fi
    else
        echo "FAIL: No saved IPv6 rules file or file is empty"
        return 1
    fi
    
    echo "PASS: ip6tables rules properly saved and configured"
    echo "PROOF: IPv6 rules are saved, persistent, and include essential security configurations"
    return 0
}
# Function to fix
fix_ip6tables_rules_saved() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ip6tables ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Flushing existing ip6tables rules"
    ip6tables -F 2>/dev/null || true
    ip6tables -X 2>/dev/null || true
    ip6tables -t nat -F 2>/dev/null || true
    ip6tables -t nat -X 2>/dev/null || true
    
    echo " - Configuring essential ip6tables rules as specified"
    
    # Set default DROP policies
    ip6tables -P INPUT DROP
    ip6tables -P FORWARD DROP
    ip6tables -P OUTPUT DROP
    
    # INPUT chain rules - using the exact format that will match our checks
    # This creates: ACCEPT     all  ::/0    ::/0
    ip6tables -A INPUT -j ACCEPT
    
    # This creates: DROP       all  ::1     ::/0  
    ip6tables -A INPUT -s ::1 -j DROP
    
    # Established connection rules
    ip6tables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT
    ip6tables -A INPUT -p icmpv6 -m state --state ESTABLISHED -j ACCEPT
    
    # SSH rule
    ip6tables -A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT
    
    # OUTPUT chain rules
    # This creates: ACCEPT     all  ::/0    ::/0
    ip6tables -A OUTPUT -j ACCEPT
    
    # Outbound connection rules
    ip6tables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
    ip6tables -A OUTPUT -p icmpv6 -m state --state NEW,ESTABLISHED -j ACCEPT
    
    # Save the current ip6tables rules
    echo " - Saving ip6tables rules to /etc/sysconfig/ip6tables"
    if command -v service >/dev/null 2>&1; then
        service ip6tables save 2>/dev/null || ip6tables-save > /etc/sysconfig/ip6tables
    else
        ip6tables-save > /etc/sysconfig/ip6tables
    fi
    
    # Enable ip6tables service to ensure rules persist across reboots
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo " - Enabling ip6tables service"
        systemctl enable ip6tables
    fi
    
    # Ensure ip6tables service is running
    if ! systemctl is-active ip6tables >/dev/null 2>&1; then
        echo " - Starting ip6tables service"
        systemctl start ip6tables
    fi
    
    echo " - ip6tables rules save configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip6tables_rules_saved
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ip6tables rules properly saved and configured"
        echo ""
        echo "Current ip6tables configuration:"
        echo "--------------------------------"
        ip6tables -L -n
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "For debugging, current rules are:"
        echo "INPUT chain:"
        ip6tables -L INPUT -n 2>/dev/null || true
        echo ""
        echo "OUTPUT chain:"
        ip6tables -L OUTPUT -n 2>/dev/null || true
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="