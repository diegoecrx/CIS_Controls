#!/usr/bin/env bash
# Script: 1.5.1.4.sh
# Item: 1.5.1.4 Ensure the SELinux mode is not disabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.4.sh"
ITEM_NAME="1.5.1.4 Ensure the SELinux mode is not disabled (Automated)"
DESCRIPTION="This remediation ensures SELinux mode is Enforcing or Permissive by setting to Enforcing."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current SELinux mode..."
    current_mode=$(getenforce 2>/dev/null || echo "Not installed")
    conf_file="/etc/selinux/config"
    conf_mode=$(grep '^SELINUX=' "$conf_file" 2>/dev/null | cut -d= -f2 || echo "Not set")
    if [ "$current_mode" != "Disabled" ] && [ "$conf_mode" != "disabled" ]; then
        echo "PASS: SELinux not disabled"
        echo "PROOF (getenforce): $current_mode"
        echo "PROOF (config): SELINUX=$conf_mode"
        return 0
    else
        echo "FAIL: SELinux disabled"
        echo "PROOF (getenforce): $current_mode"
        echo "PROOF (config): SELINUX=$conf_mode"
        return 1
    fi
}
# Function to fix
fix_selinux_mode() {
    echo "Applying fix..."
    setenforce 1 2>/dev/null || true
    echo " - Set runtime to Enforcing"
    conf_file="/etc/selinux/config"
    sed -i 's/^SELINUX=.*/SELINUX=enforcing/' "$conf_file" || echo "SELINUX=enforcing" >> "$conf_file"
    echo " - Set config to enforcing"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_selinux_mode
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: SELinux mode not disabled"
    else
        echo "FAIL: SELinux still disabled"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="