#!/usr/bin/env bash

# Script: 4.3.2.sh
# Item: 4.3.2 Ensure sudo commands use pty (Automated)

set -euo pipefail

SCRIPT_NAME="4.3.2.sh"
ITEM_NAME="4.3.2 Ensure sudo commands use pty (Automated)"
DESCRIPTION="This remediation ensures sudo commands use pty by adding Defaults use_pty."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

SUDOERS_DIR="/etc/sudoers.d"
FIX_FILE="${SUDOERS_DIR}/00_use_pty"
BACKUP_DIR="/etc/sudoers.d.backup.$(date +%Y%m%d_%H%M%S)"

# Function to check current status
check_current_status() {
    echo "Checking for Defaults use_pty in sudo configuration..."
    echo ""
    
    # Check in main sudoers file
    if grep -E '^Defaults\s+use_pty' /etc/sudoers 2>/dev/null; then
        echo "PASS: Defaults use_pty found in /etc/sudoers"
        return 0
    fi
    
    # Check in sudoers.d files
    local found_includes=false
    if [ -d "$SUDOERS_DIR" ]; then
        for file in "$SUDOERS_DIR"/*; do
            if [ -f "$file" ] && [[ "$file" =~ [0-9][0-9]_ ]]; then
                if grep -E '^Defaults\s+use_pty' "$file" 2>/dev/null; then
                    echo "PASS: Defaults use_pty found in $file"
                    return 0
                fi
            fi
        done
    fi
    
    echo "FAIL: Defaults use_pty not found in sudo configuration"
    return 1
}

# Function to validate sudoers syntax
validate_sudoers() {
    if visudo -c > /dev/null 2>&1; then
        echo "PASS: Sudoers syntax is valid"
        return 0
    else
        echo "FAIL: Sudoers syntax is invalid"
        visudo -c
        return 1
    fi
}

# Function to create backup
create_backup() {
    echo "Creating backup of sudoers.d directory..."
    if [ -d "$SUDOERS_DIR" ]; then
        cp -r "$SUDOERS_DIR" "$BACKUP_DIR"
        echo " - Backup created: $BACKUP_DIR"
    else
        mkdir -p "$BACKUP_DIR"
        echo " - Created backup directory: $BACKUP_DIR"
    fi
    echo ""
}

# Function to apply fix
fix_sudo_pty() {
    echo "Applying remediation..."
    echo ""
    
    create_backup
    
    # Ensure sudoers.d directory exists
    if [ ! -d "$SUDOERS_DIR" ]; then
        mkdir -p "$SUDOERS_DIR"
        echo " - Created directory: $SUDOERS_DIR"
    fi
    
    # Create the fix file with proper syntax
    echo " - Creating file: $FIX_FILE"
    echo "# Ensure sudo commands use pty - Added by 4.3.2.sh" > "$FIX_FILE"
    echo "Defaults use_pty" >> "$FIX_FILE"
    
    # Set proper permissions
    chmod 0440 "$FIX_FILE"
    echo " - Set permissions: 0440"
    
    echo ""
    echo " - SUCCESS: Created sudoers configuration file"
    echo ""
}

# Function to verify fix was applied
verify_fix() {
    echo "Verifying remediation..."
    echo ""
    
    local verification_passed=true
    
    # Check if file exists
    if [ ! -f "$FIX_FILE" ]; then
        echo "FAIL: Configuration file $FIX_FILE does not exist"
        verification_passed=false
    else
        echo "PASS: Configuration file exists: $FIX_FILE"
        echo "PROOF (file content):"
        cat "$FIX_FILE"
        echo ""
    fi
    
    # Check file permissions
    if [ -f "$FIX_FILE" ]; then
        local file_perm=$(stat -c "%a" "$FIX_FILE" 2>/dev/null)
        if [ "$file_perm" = "440" ]; then
            echo "PASS: File has correct permissions: $file_perm"
        else
            echo "FAIL: File has incorrect permissions: $file_perm (expected 440)"
            verification_passed=false
        fi
    fi
    
    # Validate sudoers syntax
    if ! validate_sudoers; then
        verification_passed=false
        echo ""
        echo "WARNING: Sudoers syntax is invalid - restoring from backup"
        restore_backup
    fi
    
    # Check if the setting is active
    if check_current_status; then
        echo "PASS: Defaults use_pty is now configured in sudo"
    else
        echo "FAIL: Defaults use_pty is still not found after remediation"
        verification_passed=false
    fi
    
    echo ""
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Function to restore from backup
restore_backup() {
    echo "Restoring from backup..."
    if [ -d "$BACKUP_DIR" ]; then
        rm -rf "$SUDOERS_DIR"
        cp -r "$BACKUP_DIR" "$SUDOERS_DIR"
        echo " - Restored from: $BACKUP_DIR"
    else
        echo " - No backup found, cannot restore"
    fi
}

# Main remediation
echo "Initial Status Check:"
echo "====================="
if check_current_status; then
    echo ""
    echo "No remediation needed - Defaults use_pty is already configured"
else
    echo ""
    echo "Remediation Required:"
    echo "===================="
    fix_sudo_pty
fi

echo ""
echo "==================================================================="
echo "Final Verification with Proofs:"
echo "==================================================================="
echo ""

if check_current_status; then
    echo "SUCCESS: Defaults use_pty is properly configured"
    echo ""
    echo "Proof of configuration:"
    echo "-----------------------"
    grep -r '^Defaults\s+use_pty' /etc/sudoers /etc/sudoers.d/* 2>/dev/null || true
else
    # If still not found, try to apply the fix and verify
    echo "Applying remediation and verifying..."
    echo ""
    fix_sudo_pty
    
    # Wait a moment for the system to recognize the new file
    sleep 2
    
    if verify_fix; then
        echo "SUCCESS: Remediation applied and verified"
    else
        echo "FAIL: Issues remain after remediation attempt"
        echo ""
        echo "Manual remediation may be required:"
        echo "1. Run: visudo -f /etc/sudoers.d/00_use_pty"
        echo "2. Add the line: Defaults use_pty"
        echo "3. Save and exit"
        echo "4. Verify with: visudo -c"
    fi
fi

echo ""
echo "Final Sudoers Syntax Check:"
echo "==========================="
validate_sudoers

echo ""
echo "Configuration Files Summary:"
echo "============================"
echo "Files in /etc/sudoers.d/:"
if [ -d "$SUDOERS_DIR" ]; then
    ls -la "$SUDOERS_DIR/" 2>/dev/null | grep -v '^total' || echo "No files found"
else
    echo "Directory $SUDOERS_DIR does not exist"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="