#!/usr/bin/env bash

# Script: 1.1.2.2.4.sh
# Item: 1.1.2.2.4 Ensure noexec option set on /dev/shm partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.2.4.sh"
ITEM_NAME="1.1.2.2.4 Ensure noexec option set on /dev/shm partition (Automated)"
DESCRIPTION="This remediation ensures the noexec option is set on the /dev/shm partition to prevent execution of binaries."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /dev/shm mount options..."
    echo ""

    # Display current mount status and options
    echo "Current /dev/shm mount information:"
    mount | grep -E '\s/dev/shm\s' || echo "No separate /dev/shm mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /dev/shm:"
    grep -E '\s/dev/shm\s' /etc/fstab || echo "No /dev/shm entry in /etc/fstab"
    echo ""

    echo "Applying remediation..."

    # Function to update fstab with noexec option
    update_fstab_noexec()
    {
        # Check if /dev/shm entry exists in fstab
        if grep -q -E '\s/dev/shm\s' /etc/fstab; then
            echo " - Checking /dev/shm entry in /etc/fstab for noexec option"
            
            # Get the current /dev/shm entry
            current_entry=$(grep -E '\s/dev/shm\s' /etc/fstab)
            
            # Check if noexec option is already present
            if echo "$current_entry" | grep -q 'noexec'; then
                echo " - noexec option already present in /etc/fstab"
                return 0
            else
                echo " - Adding noexec option to /etc/fstab"
                
                # Create temporary fstab without /dev/shm entry
                grep -v -E '\s/dev/shm\s' /etc/fstab > /etc/fstab.tmp
                
                # Add noexec option to the mount options field (4th field)
                updated_entry=$(echo "$current_entry" | awk '
                {
                    for(i=1; i<=NF; i++) {
                        if(i==4) {
                            # Add noexec to mount options if not already present
                            if($i ~ /noexec/) {
                                print $0
                            } else {
                                # Handle options with and without commas
                                if($i ~ /,$/) {
                                    gsub(/,$/, "", $i)
                                    $i = $i ",noexec"
                                } else {
                                    $i = $i ",noexec"
                                }
                                # Reconstruct the line
                                for(j=1; j<=NF; j++) {
                                    printf "%s", $j
                                    if(j<NF) printf " "
                                }
                                printf "\n"
                            }
                        }
                    }
                }')
                
                # If awk processing failed, use simpler approach
                if [ -z "$updated_entry" ]; then
                    # Simple approach: just add noexec to the options
                    updated_entry=$(echo "$current_entry" | sed 's/\(defaults,[^[:space:]]*\)/\1,noexec/' 2>/dev/null || echo "$current_entry")
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                
                # Backup original and replace
                cp /etc/fstab /etc/fstab.bak
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /dev/shm entry in /etc/fstab with noexec option"
            fi
        else
            echo " - WARNING: No /dev/shm entry found in /etc/fstab. Please ensure /dev/shm is configured as separate partition first."
            return 1
        fi
    }

    # Function to remount /dev/shm with noexec option
    remount_shm_noexec()
    {
        echo " - Checking /dev/shm mount for noexec option"
        
        # Check if /dev/shm is mounted as separate filesystem
        if mount | grep -q -E '\s/dev/shm\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/dev/shm\s')
            
            # Check if noexec is already set in current mount
            if echo "$mount_line" | grep -q 'noexec'; then
                echo " - noexec option already set on current /dev/shm mount"
            else
                echo " - Remounting /dev/shm with noexec option"
                # Add noexec to current options and remount
                if mount -o remount,noexec /dev/shm; then
                    echo " - SUCCESS: /dev/shm remounted with noexec option"
                else
                    echo " - WARNING: Could not remount /dev/shm with noexec option"
                    return 1
                fi
            fi
        else
            echo " - WARNING: /dev/shm is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_noexec; then
        remount_shm_noexec
    else
        echo " - Skipping remount due to missing /dev/shm configuration"
    fi

    echo ""
    echo "Remediation of noexec option on /dev/shm partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /dev/shm is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /dev/shm IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/dev/shm\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /dev/shm is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /dev/shm is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify noexec option in current mount
    echo ""
    echo "2. VERIFYING noexec OPTION IN CURRENT MOUNT:"
    echo "-------------------------------------------"
    mount_line=$(mount | grep -E '\s/dev/shm\s' || true)
    if echo "$mount_line" | grep -q 'noexec'; then
        echo "PASS: noexec option set on current /dev/shm mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: noexec option NOT set on current /dev/shm mount - attempting remount"
        if mount -o remount,noexec /dev/shm 2>/dev/null; then
            mount_line=$(mount | grep -E '\s/dev/shm\s' || true)
            if echo "$mount_line" | grep -q 'noexec'; then
                echo "PASS: noexec option now set on /dev/shm mount"
                echo "PROOF (mount output):"
                echo "$mount_line"
            else
                echo "FAIL: Could not set noexec option on /dev/shm mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /dev/shm with noexec option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify noexec option in fstab
    echo ""
    echo "3. VERIFYING noexec OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/dev/shm\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'noexec'; then
            echo "PASS: noexec option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: noexec option NOT found in /etc/fstab - updating now"
            # Remove existing entry
            grep -v -E '\s/dev/shm\s' /etc/fstab > /etc/fstab.tmp
            # Add noexec to mount options (4th field)
            if echo "$fstab_entry" | grep -q 'defaults,'; then
                updated_entry=$(echo "$fstab_entry" | sed 's/defaults,/defaults,noexec,/' | sed 's/,,/,/g')
            else
                # If no defaults, add noexec to beginning of options
                updated_entry=$(echo "$fstab_entry" | awk '{$4=$4",noexec"; print}')
            fi
            echo "$updated_entry" >> /etc/fstab.tmp
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: noexec option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/dev/shm\s' /etc/fstab
        fi
    else
        echo "FAIL: No /dev/shm entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_noexec=$(grep -E '\s/dev/shm\s' /etc/fstab | grep -o 'noexec' | head -1 || true)
    mount_has_noexec=$(mount | grep -E '\s/dev/shm\s' | grep -o 'noexec' | head -1 || true)
    
    if [ -n "$fstab_has_noexec" ] && [ -n "$mount_has_noexec" ]; then
        echo "PASS: noexec option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab options: $(grep -E '\s/dev/shm\s' /etc/fstab | awk '{print $4}')"
        echo "  mount options: $(mount | grep -E '\s/dev/shm\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_has_noexec" ] && [ -z "$mount_has_noexec" ]; then
        echo "FAIL: noexec in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_has_noexec" ] && [ -n "$mount_has_noexec" ]; then
        echo "FAIL: noexec in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: noexec option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Test noexec effectiveness by attempting to execute a test binary
    echo ""
    echo "5. VERIFYING noexec EFFECTIVENESS:"
    echo "----------------------------------"
    # Create a simple test script in /dev/shm
    test_script="/dev/shm/test_noexec_$$.sh"
    cat > "$test_script" << 'EOF'
#!/bin/bash
echo "Execution test successful - noexec is NOT working"
EOF
    chmod +x "$test_script"
    
    # Attempt to execute the script
    if "$test_script" 2>/dev/null; then
        echo "FAIL: Binary execution succeeded - noexec may not be working"
        echo "PROOF: Test script executed successfully in /dev/shm"
        final_status_pass=false
    else
        if [ $? -eq 126 ]; then
            echo "PASS: Binary execution blocked - noexec is working"
            echo "PROOF: Test script execution was prevented in /dev/shm (Permission denied)"
        else
            echo "PASS: Binary execution blocked - noexec is working" 
            echo "PROOF: Test script execution was prevented in /dev/shm"
        fi
    fi
    
    # Clean up test script
    rm -f "$test_script"

    # PROOF 6: Check for executable files in /dev/shm
    echo ""
    echo "6. CHECKING FOR EXECUTABLE FILES IN /dev/shm:"
    echo "---------------------------------------------"
    exec_files_count=$(find /dev/shm -type f -executable 2>/dev/null | wc -l)
    if [ "$exec_files_count" -eq 0 ]; then
        echo "PASS: No executable files found in /dev/shm"
        echo "PROOF: find /dev/shm -type f -executable returned 0 files"
    else
        echo "INFO: Found $exec_files_count executable files in /dev/shm (may be normal for shared memory operations)"
        echo "PROOF (first 5 executable files):"
        find /dev/shm -type f -executable 2>/dev/null | head -5
    fi

    # PROOF 7: Test shared memory functionality
    echo ""
    echo "7. TESTING SHARED MEMORY FUNCTIONALITY:"
    echo "---------------------------------------"
    if command -v ipcs >/dev/null 2>&1; then
        echo "PASS: Shared memory tools available (ipcs)"
        echo "PROOF (ipcs output - first 5 lines):"
        ipcs -m | head -5
    else
        echo "INFO: ipcs command not available, shared memory functionality test skipped"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="