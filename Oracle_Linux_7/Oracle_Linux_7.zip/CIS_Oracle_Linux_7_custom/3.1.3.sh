#!/usr/bin/env bash
# Script: 3.1.3.sh
# Item: 3.1.3 Ensure bluetooth services are not in use (Automated)
set -euo pipefail
SCRIPT_NAME="3.1.3.sh"
ITEM_NAME="3.1.3 Ensure bluetooth services are not in use (Automated)"
DESCRIPTION="This remediation ensures bluetooth services are not in use by stopping/masking the service or removing the bluez package."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking bluetooth services..."
    
    # Check if bluez package is installed
    if ! rpm -q bluez >/dev/null 2>&1; then
        echo "PASS: bluez package is not installed"
        echo "PROOF: rpm -q bluez returned no package found"
        return 0
    fi
    
    # Check bluetooth.service status
    if systemctl is-active bluetooth.service >/dev/null 2>&1; then
        echo "FAIL: bluetooth.service is active"
        echo "PROOF: systemctl is-active bluetooth.service shows active"
        return 1
    fi
    
    if systemctl is-enabled bluetooth.service >/dev/null 2>&1; then
        # Check if service is masked
        if ! systemctl is-masked bluetooth.service >/dev/null 2>&1; then
            echo "FAIL: bluetooth.service is enabled but not masked"
            echo "PROOF: bluetooth.service is enabled and not masked"
            return 1
        fi
    fi
    
    echo "PASS: bluetooth services properly disabled"
    echo "PROOF: bluetooth.service is inactive and masked/disabled"
    return 0
}
# Function to fix
fix_bluetooth_services() {
    echo "Applying fix..."
    
    # Check if bluez package is installed
    if ! rpm -q bluez >/dev/null 2>&1; then
        echo " - bluez package not installed, no action needed"
        return
    fi
    
    # Stop bluetooth.service if running
    if systemctl is-active bluetooth.service >/dev/null 2>&1; then
        echo " - Stopping bluetooth.service"
        systemctl stop bluetooth.service 2>/dev/null || true
    fi
    
    # Check if bluez package can be removed (not required as dependency)
    echo " - Checking if bluez package can be removed"
    if yum remove bluez -y --assumeno 2>/dev/null | grep -q "Nothing to do" || yum remove bluez -y 2>/dev/null; then
        echo " - Removed bluez package"
    else
        echo " - bluez package required as dependency, masking bluetooth.service instead"
        if ! systemctl is-masked bluetooth.service >/dev/null 2>&1; then
            echo " - Masking bluetooth.service"
            systemctl mask bluetooth.service 2>/dev/null || true
        fi
    fi
    
    echo " - Bluetooth services remediation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_bluetooth_services
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Bluetooth services properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="