#!/usr/bin/env bash
# Script: 1.6.1.sh
# Item: 1.6.1 Ensure message of the day is configured properly (Automated)
set -euo pipefail
SCRIPT_NAME="1.6.1.sh"
ITEM_NAME="1.6.1 Ensure message of the day is configured properly (Automated)"
DESCRIPTION="This remediation ensures /etc/motd is configured properly or removed."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/motd..."
    if [ ! -f /etc/motd ]; then
        echo "PASS: /etc/motd does not exist"
        echo "PROOF: File not found"
        return 0
    fi
    content=$(cat /etc/motd)
    if echo "$content" | grep -qE '(\\m|\\r|\\s|\\v)'; then
        echo "FAIL: Forbidden variables found"
        echo "PROOF: $content"
        return 1
    else
        echo "PASS: No forbidden variables"
        echo "PROOF: $content"
        return 0
    fi
}
# Function to fix
fix_motd() {
    echo "Applying fix..."
    rm -f /etc/motd
    echo " - Removed /etc/motd"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_motd
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: MOTD configured properly"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="