#!/usr/bin/env bash

# Script: 1.2.4.sh
# Item: 1.2.4 Ensure package manager repositories are configured (Manual)
# Description: Configure your package manager repositories according to site policy.
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="1.2.4.sh"
ITEM_NAME="1.2.4 Ensure package manager repositories are configured (Manual)"
DESCRIPTION="Configure your package manager repositories according to site policy."
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current status of package manager repositories..."
    echo ""

    # Display current repository configuration status
    echo "Current repository configuration status:"
    echo "========================================"
    
    # Check for APT (Debian/Ubuntu)
    if command -v apt-get >/dev/null 2>&1; then
        echo "APT package manager detected"
        echo "---------------------------"
        echo "Main sources file (/etc/apt/sources.list):"
        if [ -f /etc/apt/sources.list ]; then
            cat /etc/apt/sources.list | grep -v '^#' | grep -v '^$' | head -10 || echo "No active repositories in main file"
        else
            echo "Main sources file not found"
        fi
        
        echo ""
        echo "Additional sources directories:"
        if [ -d /etc/apt/sources.list.d ]; then
            find /etc/apt/sources.list.d -name "*.list" -type f | head -5
            for file in $(find /etc/apt/sources.list.d -name "*.list" -type f | head -3); do
                echo "Contents of $file:"
                cat "$file" | grep -v '^#' | grep -v '^$' | head -5 || echo "No active repositories in this file"
                echo ""
            done
        else
            echo "No additional sources directories found"
        fi
    else
        echo "APT package manager not detected"
    fi
    
    echo ""
    
    # Check for RPM (RedHat/CentOS/Fedora)
    if command -v rpm >/dev/null 2>&1; then
        echo "RPM package manager detected"
        echo "---------------------------"
        if command -v yum >/dev/null 2>&1; then
            echo "YUM repository configuration:"
            if [ -d /etc/yum.repos.d ]; then
                find /etc/yum.repos.d -name "*.repo" -type f | head -5
                for file in $(find /etc/yum.repos.d -name "*.repo" -type f | head -3); do
                    echo "Active repositories in $file:"
                    grep -E '^\[.+\]' "$file" | head -5 || echo "No active repositories in this file"
                done
            else
                echo "YUM repository directory not found"
            fi
        fi
        
        if command -v dnf >/dev/null 2>&1; then
            echo ""
            echo "DNF repository configuration:"
            dnf repolist enabled 2>/dev/null | head -10 || echo "Unable to list enabled DNF repositories"
        fi
    else
        echo "RPM package manager not detected"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    verify_apt_repositories()
    {
        echo " - Verifying APT repository configuration..."
        if command -v apt-get >/dev/null 2>&1; then
            echo " - Checking repository syntax..."
            if apt-get update >/dev/null 2>&1; then
                echo " - SUCCESS: APT repository syntax is valid"
            else
                echo " - WARNING: APT repository syntax has issues"
                echo " - Checking for common configuration problems..."
                
                # Check for malformed repository entries
                if [ -f /etc/apt/sources.list ]; then
                    malformed_count=$(grep -E '^deb[[:space:]]+' /etc/apt/sources.list | grep -v 'http' | grep -v 'ftp' | wc -l || true)
                    if [ "$malformed_count" -gt 0 ]; then
                        echo " - WARNING: Found $malformed_count potentially malformed repository entries"
                    fi
                fi
            fi
        fi
    }

    verify_rpm_repositories()
    {
        echo " - Verifying RPM repository configuration..."
        if command -v yum >/dev/null 2>&1; then
            echo " - Checking YUM repository configuration..."
            if yum repolist enabled >/dev/null 2>&1; then
                repo_count=$(yum repolist enabled 2>/dev/null | grep -c "repo" || true)
                echo " - SUCCESS: YUM repository configuration valid ($repo_count repositories enabled)"
            else
                echo " - WARNING: YUM repository configuration has issues"
            fi
        fi
        
        if command -v dnf >/dev/null 2>&1; then
            echo " - Checking DNF repository configuration..."
            if dnf repolist enabled >/dev/null 2>&1; then
                repo_count=$(dnf repolist enabled 2>/dev/null | grep -c "repo" || true)
                echo " - SUCCESS: DNF repository configuration valid ($repo_count repositories enabled)"
            else
                echo " - WARNING: DNF repository configuration has issues"
            fi
        fi
    }

    # Apply remediation based on detected package manager
    remediation_applied=false
    
    if command -v apt-get >/dev/null 2>&1; then
        echo ""
        echo "APT-based system detected - applying APT-specific remediation..."
        verify_apt_repositories
        remediation_applied=true
    fi
    
    if command -v rpm >/dev/null 2>&1; then
        echo ""
        echo "RPM-based system detected - applying RPM-specific remediation..."
        verify_rpm_repositories
        remediation_applied=true
    fi

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No supported package manager detected - manual configuration required"
    fi

    echo ""
    echo "Remediation of package manager repositories complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify APT repository configuration
    echo ""
    echo "1. VERIFYING APT REPOSITORY CONFIGURATION:"
    echo "------------------------------------------"
    if command -v apt-get >/dev/null 2>&1; then
        echo "Active APT repositories:"
        if [ -f /etc/apt/sources.list ]; then
            apt_main_count=$(grep -E '^deb[[:space:]]+' /etc/apt/sources.list | wc -l || true)
            echo " - Main sources file: $apt_main_count repositories"
        fi
        
        if [ -d /etc/apt/sources.list.d ]; then
            apt_extra_files=$(find /etc/apt/sources.list.d -name "*.list" -type f | wc -l || true)
            apt_extra_repos=$(find /etc/apt/sources.list.d -name "*.list" -type f -exec grep -E '^deb[[:space:]]+' {} \; | wc -l || true)
            echo " - Additional sources: $apt_extra_repos repositories across $apt_extra_files files"
            
            if [ "$apt_extra_repos" -gt 0 ]; then
                echo "PROOF (sample of additional repositories):"
                find /etc/apt/sources.list.d -name "*.list" -type f -exec grep -E '^deb[[:space:]]+' {} \; | head -5
            fi
        fi
        
        # Test repository access
        echo ""
        echo "Testing repository access..."
        if apt-get update >/dev/null 2>&1; then
            echo "PASS: APT repositories are accessible and properly configured"
        else
            echo "WARNING: APT repository access issues detected"
            final_status_pass=false
        fi
    else
        echo "INFO: APT package manager not available"
    fi
    
    # PROOF 2: Verify RPM repository configuration
    echo ""
    echo "2. VERIFYING RPM REPOSITORY CONFIGURATION:"
    echo "------------------------------------------"
    if command -v rpm >/dev/null 2>&1; then
        if command -v yum >/dev/null 2>&1; then
            echo "YUM repository status:"
            yum repolist enabled 2>/dev/null | head -10 || echo "Unable to list YUM repositories"
            echo ""
        fi
        
        if command -v dnf >/dev/null 2>&1; then
            echo "DNF repository status:"
            dnf repolist enabled 2>/dev/null | head -10 || echo "Unable to list DNF repositories"
            echo ""
        fi
        
        # Count repository files
        if [ -d /etc/yum.repos.d ]; then
            repo_file_count=$(find /etc/yum.repos.d -name "*.repo" -type f | wc -l || true)
            echo "Repository configuration files: $repo_file_count"
            
            if [ "$repo_file_count" -gt 0 ]; then
                echo "PROOF (repository file list):"
                find /etc/yum.repos.d -name "*.repo" -type f | head -5
            fi
        fi
    else
        echo "INFO: RPM package manager not available"
    fi
    
    # PROOF 3: Verify package installation capability
    echo ""
    echo "3. VERIFYING PACKAGE INSTALLATION CAPABILITY:"
    echo "---------------------------------------------"
    if command -v apt-get >/dev/null 2>&1; then
        echo "Testing APT package installation capability..."
        if apt-get install --dry-run coreutils >/dev/null 2>&1; then
            echo "PASS: APT can resolve and access packages"
        else
            echo "WARNING: APT package resolution issues detected"
            final_status_pass=false
        fi
    elif command -v yum >/dev/null 2>&1; then
        echo "Testing YUM package installation capability..."
        if yum install --downloadonly coreutils >/dev/null 2>&1; then
            echo "PASS: YUM can resolve and access packages"
        else
            echo "WARNING: YUM package resolution issues detected"
            final_status_pass=false
        fi
    elif command -v dnf >/dev/null 2>&1; then
        echo "Testing DNF package installation capability..."
        if dnf install --downloadonly coreutils >/dev/null 2>&1; then
            echo "PASS: DNF can resolve and access packages"
        else
            echo "WARNING: DNF package resolution issues detected"
            final_status_pass=false
        fi
    fi
    
    # PROOF 4: Manual verification steps reminder
    echo ""
    echo "4. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Verify all repositories match organizational policy"
    echo "• Ensure no unauthorized or untrusted repositories are configured"
    echo "• Confirm repository URLs point to approved sources"
    echo "• Check for proper repository signing and GPG keys"
    echo "• Validate repository priorities and update schedules"
    echo ""
    echo "MANUAL STEPS:"
    echo "1. Review /etc/apt/sources.list and /etc/apt/sources.list.d/*.list (APT)"
    echo "2. Review /etc/yum.repos.d/*.repo (RPM)"
    echo "3. Verify repository URLs against approved organizational list"
    echo "4. Remove any unauthorized or unnecessary repositories"
    echo "5. Ensure only signed repositories are enabled"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: Automated verification steps completed"
        echo "NOTE: Manual verification required per organizational policy"
    else
        echo ""
        echo "WARNING: Some repository configuration issues detected - manual intervention required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="