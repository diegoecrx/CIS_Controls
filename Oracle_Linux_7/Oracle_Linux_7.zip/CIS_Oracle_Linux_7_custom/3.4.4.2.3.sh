#!/usr/bin/env bash
# Script: 3.4.4.2.3.sh
# Item: 3.4.4.2.3 Ensure iptables rules exist for all open ports (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.2.3.sh"
ITEM_NAME="3.4.4.2.3 Ensure iptables rules exist for all open ports (Automated)"
DESCRIPTION="This remediation ensures iptables rules exist for all open ports."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking iptables rules for open ports..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Get list of listening ports
    listening_ports=$(ss -tuln | awk 'NR>1 && $1~/^tcp|^udp/ {gsub(/.*:/, "", $5); print $1 ":" $5}' | sort -u)
    
    if [ -z "$listening_ports" ]; then
        echo "PASS: No listening ports found"
        echo "PROOF: No open ports detected"
        return 0
    fi
    
    # Check each listening port for corresponding iptables rule
    unprotected_ports=""
    for port_info in $listening_ports; do
        protocol=$(echo "$port_info" | cut -d: -f1)
        port=$(echo "$port_info" | cut -d: -f2)
        
        # Skip if port is 0 or not numeric
        if ! [[ "$port" =~ ^[0-9]+$ ]] || [ "$port" = "0" ]; then
            continue
        fi
        
        # Check if iptables rule exists for this port
        if [ "$protocol" = "tcp" ]; then
            if ! iptables -L INPUT -n | grep -q "tcp dpt:$port"; then
                unprotected_ports="${unprotected_ports}tcp:$port "
            fi
        elif [ "$protocol" = "udp" ]; then
            if ! iptables -L INPUT -n | grep -q "udp dpt:$port"; then
                unprotected_ports="${unprotected_ports}udp:$port "
            fi
        fi
    done
    
    if [ -n "$unprotected_ports" ]; then
        echo "FAIL: Open ports without iptables rules found"
        echo "PROOF: Unprotected ports: $unprotected_ports"
        return 1
    fi
    
    echo "PASS: All open ports have corresponding iptables rules"
    echo "PROOF: All listening ports are protected by firewall rules"
    return 0
}
# Function to fix
fix_iptables_open_ports() {
    echo "Applying fix..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    # Get list of listening ports
    listening_ports=$(ss -tuln | awk 'NR>1 && $1~/^tcp|^udp/ {gsub(/.*:/, "", $5); print $1 ":" $5}' | sort -u)
    
    if [ -z "$listening_ports" ]; then
        echo " - No listening ports found, no rules to add"
        return
    fi
    
    echo " - Analyzing open ports and adding missing iptables rules"
    
    # Add rules for unprotected ports
    for port_info in $listening_ports; do
        protocol=$(echo "$port_info" | cut -d: -f1)
        port=$(echo "$port_info" | cut -d: -f2)
        
        # Skip if port is 0 or not numeric
        if ! [[ "$port" =~ ^[0-9]+$ ]] || [ "$port" = "0" ]; then
            continue
        fi
        
        # Add rule if it doesn't exist
        if [ "$protocol" = "tcp" ]; then
            if ! iptables -L INPUT -n | grep -q "tcp dpt:$port"; then
                echo " - Adding iptables rule for TCP port $port"
                iptables -A INPUT -p tcp --dport "$port" -m state --state NEW -j ACCEPT
            fi
        elif [ "$protocol" = "udp" ]; then
            if ! iptables -L INPUT -n | grep -q "udp dpt:$port"; then
                echo " - Adding iptables rule for UDP port $port"
                iptables -A INPUT -p udp --dport "$port" -m state --state NEW -j ACCEPT
            fi
        fi
    done
    
    # Save iptables rules to make them persistent
    echo " - Saving iptables rules"
    service iptables save 2>/dev/null || iptables-save > /etc/sysconfig/iptables
    
    # Ensure iptables service is enabled
    if ! systemctl is-enabled iptables >/dev/null 2>&1; then
        echo " - Enabling iptables service"
        systemctl enable iptables
    fi
    
    echo " - iptables open ports configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_open_ports
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: All open ports have corresponding iptables rules"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="