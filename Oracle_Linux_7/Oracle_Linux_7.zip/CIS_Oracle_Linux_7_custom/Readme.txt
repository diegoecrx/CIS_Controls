
#1 - transferir os arquivos para diretório /opt ficando: 

/opt/section1
/opt/section2
...



#2 - rodar scripts com a linha de comando abaixo:

for f in ./*.sh; do
  echo "Running $f..."
  bash "$f"
done



#3 - scripts com input

Verificar momento na primerasesap
1.3.1 Ensure bootloader password is set (Automated)
