#!/usr/bin/env bash
# Script: 5.2.3.2.sh
# Item: 5.2.3.2 Ensure actions as another user are always logged (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.2.sh"
ITEM_NAME="5.2.3.2 Ensure actions as another user are always logged (Automated)"
DESCRIPTION="This remediation ensures actions as another user are always logged by configuring audit rules for user emulation."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking user emulation audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    # Check for user emulation audit rules in running configuration
    # Accept either format: -C euid!=uid or -C uid!=euid, and -k user_emulation or -F key=user_emulation
    user_emulation_rules_found=true
    
    # Check b64 rule (for 64-bit systems)
    if [[ "$arch" == "x86_64" ]]; then
        if ! auditctl -l 2>/dev/null | grep -qE '\-a always,exit -F arch=b64.*\-S execve.*user_emulation'; then
            echo "DEBUG: b64 user_emulation rule not found in running config"
            user_emulation_rules_found=false
        else
            echo "DEBUG: Found b64 user_emulation rule"
        fi
    fi
    
    # Check b32 rule (for both 32-bit and 64-bit systems)
    if ! auditctl -l 2>/dev/null | grep -qE '\-a always,exit -F arch=b32.*\-S execve.*user_emulation'; then
        echo "DEBUG: b32 user_emulation rule not found in running config"
        user_emulation_rules_found=false
    else
        echo "DEBUG: Found b32 user_emulation rule"
    fi
    
    if [ "$user_emulation_rules_found" = false ]; then
        echo "FAIL: user emulation audit rules not found in running configuration"
        echo "PROOF: Required audit rules not present in auditctl -l output"
        echo "DEBUG: Current audit rules:"
        auditctl -l 2>/dev/null || echo "No audit rules loaded"
        return 1
    fi
    
    # Verify the rules have the correct condition for user emulation
    correct_condition_found=true
    
    # Check if rules have the euid!=uid condition (either format)
    if [[ "$arch" == "x86_64" ]]; then
        if ! auditctl -l 2>/dev/null | grep -E '\-a always,exit -F arch=b64.*\-S execve.*user_emulation' | grep -qE '\-C (euid!=uid|uid!=euid)'; then
            echo "DEBUG: b64 rule missing euid!=uid condition"
            correct_condition_found=false
        fi
    fi
    
    if ! auditctl -l 2>/dev/null | grep -E '\-a always,exit -F arch=b32.*\-S execve.*user_emulation' | grep -qE '\-C (euid!=uid|uid!=euid)'; then
        echo "DEBUG: b32 rule missing euid!=uid condition"
        correct_condition_found=false
    fi
    
    if [ "$correct_condition_found" = false ]; then
        echo "FAIL: user emulation rules missing correct condition"
        echo "PROOF: Rules exist but missing euid!=uid condition"
        return 1
    fi
    
    echo "PASS: user emulation audit rules properly configured"
    echo "PROOF: All required user emulation audit rules found in running configuration"
    return 0
}

# Function to fix
fix_user_emulation_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
        sleep 2
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Determine system architecture
    arch=$(uname -m)
    
    echo " - Creating user emulation audit rules in /etc/audit/rules.d/50-user_emulation.rules"
    
    # Use the CIS benchmark recommended format
    if [[ "$arch" == "x86_64" ]]; then
        # 64-bit system - create rules for both b64 and b32
        cat > /etc/audit/rules.d/50-user_emulation.rules << 'EOF'
## Monitor actions as another user (user emulation)
-a always,exit -F arch=b64 -C euid!=uid -F auid!=-1 -F auid!=4294967295 -S execve -k user_emulation
-a always,exit -F arch=b32 -C euid!=uid -F auid!=-1 -F auid!=4294967295 -S execve -k user_emulation
EOF
    else
        # 32-bit system - create rule for b32 only
        cat > /etc/audit/rules.d/50-user_emulation.rules << 'EOF'
## Monitor actions as another user (user emulation)
-a always,exit -F arch=b32 -C euid!=uid -F auid!=-1 -F auid!=4294967295 -S execve -k user_emulation
EOF
    fi
    
    # Set correct permissions on the rules file
    chmod 0640 /etc/audit/rules.d/50-user_emulation.rules
    chown root:root /etc/audit/rules.d/50-user_emulation.rules
    
    echo " - Created audit rules file with CIS format"
    
    # Check if we need to remove existing rules first
    echo " - Checking for existing user emulation rules"
    existing_rules=$(auditctl -l 2>/dev/null | grep -E "user_emulation" || true)
    
    if [ -n "$existing_rules" ]; then
        echo " - Removing existing user emulation rules"
        # Delete all rules with user_emulation key
        auditctl -l 2>/dev/null | grep "user_emulation" | while read -r rule; do
            # Convert the rule to a delete command
            delete_rule=$(echo "$rule" | sed 's/^-a/--delete/' | sed 's/-k user_emulation//')
            auditctl $delete_rule 2>/dev/null || true
        done
    fi
    
    # Load the new rules using augenrules
    echo " - Loading audit rules with augenrules"
    augenrules --load
    
    # Also load directly to ensure they're active
    echo " - Directly loading CIS format rules"
    if [[ "$arch" == "x86_64" ]]; then
        auditctl -a always,exit -F arch=b64 -C euid!=uid -F auid!=-1 -F auid!=4294967295 -S execve -k user_emulation 2>/dev/null || echo "Rule may already exist"
        auditctl -a always,exit -F arch=b32 -C euid!=uid -F auid!=-1 -F auid!=4294967295 -S execve -k user_emulation 2>/dev/null || echo "Rule may already exist"
    else
        auditctl -a always,exit -F arch=b32 -C euid!=uid -F auid!=-1 -F auid!=4294967295 -S execve -k user_emulation 2>/dev/null || echo "Rule may already exist"
    fi
    
    # Verify the rules were loaded
    echo " - Current user emulation rules:"
    auditctl -l 2>/dev/null | grep "user_emulation" || echo "No user emulation rules found"
    
    echo " - user emulation audit rules configuration completed"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_user_emulation_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: user emulation audit rules properly configured"
    else
        echo "FAIL: Issues remain"
        echo "DEBUG: Current user emulation rules:"
        auditctl -l 2>/dev/null | grep -E "user_emulation" || echo "No user emulation rules found"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="