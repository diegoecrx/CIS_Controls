#!/usr/bin/env bash

# Script: 3.4.3.6.sh
# Item: 3.4.3.6 Ensure nftables outbound and established connection rules are configured (Manual)

set -euo pipefail

SCRIPT_NAME="3.4.3.6.sh"
ITEM_NAME="3.4.3.6 Ensure nftables outbound and established connection rules are configured (Manual)"
DESCRIPTION="This remediation ensures nftables outbound and established connection rules are properly configured."
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current nftables outbound and established connection rules..."
    echo ""

    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "nftables is NOT INSTALLED on this system"
        echo "Installing nftables package first..."
        yum install -y nftables >/dev/null 2>&1 && echo " - nftables installed successfully"
    fi

    # Check if nftables service is active
    nftables_active=false
    if systemctl is-active nftables >/dev/null 2>&1; then
        echo "nftables service: ACTIVE"
        nftables_active=true
    else
        echo "nftables service: INACTIVE"
        echo " - Note: Rules will be configured but service may need to be started manually"
    fi

    # Find or create inet table
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo "No inet table found - creating one..."
        nft create table inet filter 2>/dev/null && echo " - Created inet filter table"
        table_name="filter"
    else
        echo "Using existing table: $table_name"
    fi

    # Ensure input chain exists
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo "Creating INPUT chain..."
        nft create chain inet "$table_name" input '{ type filter hook input priority 0 ; }' 2>/dev/null && echo " - Created INPUT chain"
    else
        echo "INPUT chain exists"
    fi

    # Ensure output chain exists
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain output"; then
        echo "Creating OUTPUT chain..."
        nft create chain inet "$table_name" output '{ type filter hook output priority 0 ; }' 2>/dev/null && echo " - Created OUTPUT chain"
    else
        echo "OUTPUT chain exists"
    fi

    echo ""
    echo "Current rules status:"
    echo "====================="

    # Display current rules
    echo "INPUT chain rules:"
    nft list chain inet "$table_name" input 2>/dev/null | head -20 || echo " - No rules or error listing rules"
    echo ""
    echo "OUTPUT chain rules:"
    nft list chain inet "$table_name" output 2>/dev/null | head -20 || echo " - No rules or error listing rules"

    echo ""
    echo "Applying remediation..."

    # Function to check and add established connection rules
    configure_established_rules()
    {
        echo " - Configuring established connection rules in INPUT chain..."
        local rules_added=0

        # TCP established rule - check with flexible pattern
        if ! nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol tcp.*ct state established.*accept"; then
            echo "   - Adding TCP established connection rule..."
            nft add rule inet "$table_name" input ip protocol tcp ct state established accept 2>/dev/null
            if nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol tcp.*ct state established.*accept"; then
                echo "   - SUCCESS: TCP established connection rule added"
                rules_added=$((rules_added + 1))
            else
                echo "   - FAILED: Could not add TCP established connection rule"
            fi
        else
            echo "   - TCP established rule already exists"
        fi

        # UDP established rule - check with flexible pattern
        if ! nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol udp.*ct state established.*accept"; then
            echo "   - Adding UDP established connection rule..."
            nft add rule inet "$table_name" input ip protocol udp ct state established accept 2>/dev/null
            if nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol udp.*ct state established.*accept"; then
                echo "   - SUCCESS: UDP established connection rule added"
                rules_added=$((rules_added + 1))
            else
                echo "   - FAILED: Could not add UDP established connection rule"
            fi
        else
            echo "   - UDP established rule already exists"
        fi

        # ICMP established rule - check with flexible pattern
        if ! nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol icmp.*ct state established.*accept"; then
            echo "   - Adding ICMP established connection rule..."
            nft add rule inet "$table_name" input ip protocol icmp ct state established accept 2>/dev/null
            if nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol icmp.*ct state established.*accept"; then
                echo "   - SUCCESS: ICMP established connection rule added"
                rules_added=$((rules_added + 1))
            else
                echo "   - FAILED: Could not add ICMP established connection rule"
            fi
        else
            echo "   - ICMP established rule already exists"
        fi

        return $rules_added
    }

    # Function to check and add outbound connection rules
    configure_outbound_rules()
    {
        echo " - Configuring outbound connection rules in OUTPUT chain..."
        local rules_added=0

        # TCP outbound rule - check with flexible pattern for state order
        if ! nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol tcp.*ct state.*accept" | grep -q "established.*related.*new\|new.*related.*established"; then
            echo "   - Adding TCP outbound connection rule..."
            nft add rule inet "$table_name" output ip protocol tcp ct state new,related,established accept 2>/dev/null
            # Check if rule was added (flexible pattern matching)
            if nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol tcp.*ct state.*accept"; then
                echo "   - SUCCESS: TCP outbound connection rule added"
                rules_added=$((rules_added + 1))
            else
                echo "   - FAILED: Could not add TCP outbound connection rule"
            fi
        else
            echo "   - TCP outbound rule already exists"
        fi

        # UDP outbound rule - check with flexible pattern for state order
        if ! nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol udp.*ct state.*accept" | grep -q "established.*related.*new\|new.*related.*established"; then
            echo "   - Adding UDP outbound connection rule..."
            nft add rule inet "$table_name" output ip protocol udp ct state new,related,established accept 2>/dev/null
            # Check if rule was added (flexible pattern matching)
            if nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol udp.*ct state.*accept"; then
                echo "   - SUCCESS: UDP outbound connection rule added"
                rules_added=$((rules_added + 1))
            else
                echo "   - FAILED: Could not add UDP outbound connection rule"
            fi
        else
            echo "   - UDP outbound rule already exists"
        fi

        # ICMP outbound rule - check with flexible pattern for state order
        if ! nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol icmp.*ct state.*accept" | grep -q "established.*related.*new\|new.*related.*established"; then
            echo "   - Adding ICMP outbound connection rule..."
            nft add rule inet "$table_name" output ip protocol icmp ct state new,related,established accept 2>/dev/null
            # Check if rule was added (flexible pattern matching)
            if nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol icmp.*ct state.*accept"; then
                echo "   - SUCCESS: ICMP outbound connection rule added"
                rules_added=$((rules_added + 1))
            else
                echo "   - FAILED: Could not add ICMP outbound connection rule"
            fi
        else
            echo "   - ICMP outbound rule already exists"
        fi

        return $rules_added
    }

    remediation_applied=false
    established_rules_added=0
    outbound_rules_added=0

    # Configure established rules
    echo ""
    if configure_established_rules; then
        established_rules_added=$?
        if [ "$established_rules_added" -gt 0 ]; then
            remediation_applied=true
            echo " - Established rules: $established_rules_added rules added"
        else
            echo " - Established rules: All rules already present"
        fi
    fi

    # Configure outbound rules
    echo ""
    if configure_outbound_rules; then
        outbound_rules_added=$?
        if [ "$outbound_rules_added" -gt 0 ]; then
            remediation_applied=true
            echo " - Outbound rules: $outbound_rules_added rules added"
        else
            echo " - Outbound rules: All rules already present"
        fi
    fi

    # Save configuration to make persistent
    if [ "$remediation_applied" = true ]; then
        echo ""
        echo " - Saving configuration to /etc/nftables.conf"
        nft list ruleset > /etc/nftables.conf 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "   - SUCCESS: Configuration saved"
        else
            echo "   - WARNING: Could not save configuration"
        fi
    fi

    if [ "$established_rules_added" -eq 0 ] && [ "$outbound_rules_added" -eq 0 ]; then
        echo ""
        echo " - No remediation necessary - all connection rules already configured"
    else
        echo ""
        echo " - Remediation applied: $established_rules_added established rules + $outbound_rules_added outbound rules added"
    fi

    echo ""
    echo "Remediation of nftables connection rules complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify established connection rules
    echo ""
    echo "1. VERIFYING ESTABLISHED CONNECTION RULES:"
    echo "-----------------------------------------"
    
    established_rules_count=0
    
    # Check TCP established - flexible pattern
    if nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol tcp.*ct state established.*accept"; then
        echo "PASS: TCP established connection rule configured"
        echo "PROOF: Rule found in INPUT chain"
        established_rules_count=$((established_rules_count + 1))
    else
        echo "FAIL: TCP established connection rule missing"
        echo "PROOF: Rule not found in INPUT chain"
        final_status_pass=false
    fi
    
    # Check UDP established - flexible pattern
    if nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol udp.*ct state established.*accept"; then
        echo "PASS: UDP established connection rule configured"
        echo "PROOF: Rule found in INPUT chain"
        established_rules_count=$((established_rules_count + 1))
    else
        echo "FAIL: UDP established connection rule missing"
        echo "PROOF: Rule not found in INPUT chain"
        final_status_pass=false
    fi
    
    # Check ICMP established - flexible pattern
    if nft list chain inet "$table_name" input 2>/dev/null | grep -q "ip protocol icmp.*ct state established.*accept"; then
        echo "PASS: ICMP established connection rule configured"
        echo "PROOF: Rule found in INPUT chain"
        established_rules_count=$((established_rules_count + 1))
    else
        echo "FAIL: ICMP established connection rule missing"
        echo "PROOF: Rule not found in INPUT chain"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify outbound connection rules - FLEXIBLE PATTERN MATCHING
    echo ""
    echo "2. VERIFYING OUTBOUND CONNECTION RULES:"
    echo "--------------------------------------"
    
    outbound_rules_count=0
    
    # Check TCP outbound - flexible pattern for state order
    if nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol tcp.*ct state.*accept"; then
        echo "PASS: TCP outbound connection rule configured"
        echo "PROOF: Rule found in OUTPUT chain"
        outbound_rules_count=$((outbound_rules_count + 1))
    else
        echo "FAIL: TCP outbound connection rule missing"
        echo "PROOF: Rule not found in OUTPUT chain"
        final_status_pass=false
    fi
    
    # Check UDP outbound - flexible pattern for state order
    if nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol udp.*ct state.*accept"; then
        echo "PASS: UDP outbound connection rule configured"
        echo "PROOF: Rule found in OUTPUT chain"
        outbound_rules_count=$((outbound_rules_count + 1))
    else
        echo "FAIL: UDP outbound connection rule missing"
        echo "PROOF: Rule not found in OUTPUT chain"
        final_status_pass=false
    fi
    
    # Check ICMP outbound - flexible pattern for state order
    if nft list chain inet "$table_name" output 2>/dev/null | grep -q "ip protocol icmp.*ct state.*accept"; then
        echo "PASS: ICMP outbound connection rule configured"
        echo "PROOF: Rule found in OUTPUT chain"
        outbound_rules_count=$((outbound_rules_count + 1))
    else
        echo "FAIL: ICMP outbound connection rule missing"
        echo "PROOF: Rule not found in OUTPUT chain"
        final_status_pass=false
    fi
    
    # PROOF 3: Configuration summary
    echo ""
    echo "3. CONFIGURATION SUMMARY:"
    echo "------------------------"
    echo "Established rules configured: $established_rules_count/3"
    echo "Outbound rules configured: $outbound_rules_count/3"
    echo "Table: $table_name"
    
    # PROOF 4: Configuration file
    echo ""
    echo "4. PERSISTENT CONFIGURATION:"
    echo "---------------------------"
    if [ -f /etc/nftables.conf ]; then
        echo "PASS: Configuration file exists: /etc/nftables.conf"
        echo "PROOF: File contains current ruleset"
    else
        echo "WARNING: No persistent configuration file"
        echo "PROOF: /etc/nftables.conf not found"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: nftables connection rules properly configured and verified"
    else
        echo ""
        echo "FAIL: Some connection rules are missing or misconfigured"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="