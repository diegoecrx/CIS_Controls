#!/usr/bin/env bash
# Script: 5.2.1.3.sh
# Item: 5.2.1.3 Ensure audit_backlog_limit is sufficient (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.1.3.sh"
ITEM_NAME="5.2.1.3 Ensure audit_backlog_limit is sufficient (Automated)"
DESCRIPTION="This remediation ensures audit_backlog_limit is set to a sufficient value in kernel parameters."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking audit_backlog_limit kernel parameter configuration..."
    
    # Recommended minimum backlog limit
    local min_backlog_limit=8192
    
    # Check current kernel command line
    local current_backlog=""
    if grep -q "audit_backlog_limit=" /proc/cmdline 2>/dev/null; then
        current_backlog=$(grep -o 'audit_backlog_limit=[0-9]*' /proc/cmdline | cut -d= -f2)
        local cmdline_has_backlog=true
    else
        local cmdline_has_backlog=false
    fi
    
    # Check grub configuration
    local grub_has_backlog=false
    local grub_backlog=""
    if [ -f /etc/default/grub ]; then
        if grep -q 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub 2>/dev/null; then
            grub_backlog=$(grep 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub | grep -o 'audit_backlog_limit=[0-9]*' | cut -d= -f2)
            grub_has_backlog=true
        fi
    fi
    
    # Check if grubby has audit_backlog_limit configured for all kernels
    local grubby_has_backlog=true
    local grubby_backlog=""
    if command -v grubby >/dev/null 2>&1; then
        if grubby --info=ALL 2>/dev/null | grep -q "args.*audit_backlog_limit="; then
            grubby_backlog=$(grubby --info=ALL 2>/dev/null | grep "args" | grep -o 'audit_backlog_limit=[0-9]*' | cut -d= -f2 | head -1)
            # Check if all kernels have sufficient value
            if [ -n "$grubby_backlog" ] && [ "$grubby_backlog" -lt "$min_backlog_limit" ]; then
                grubby_has_backlog=false
            fi
        else
            grubby_has_backlog=false
        fi
    fi
    
    # Check if current kernel has sufficient audit_backlog_limit
    if [ "$cmdline_has_backlog" = false ]; then
        echo "FAIL: audit_backlog_limit not found in current kernel command line"
        echo "PROOF: /proc/cmdline does not contain audit_backlog_limit"
        echo "NOTE: A reboot is required for kernel parameter changes to take effect"
        return 1
    fi
    
    if [ -n "$current_backlog" ] && [ "$current_backlog" -lt "$min_backlog_limit" ]; then
        echo "FAIL: audit_backlog_limit is insufficient in current kernel"
        echo "PROOF: Current audit_backlog_limit=$current_backlog is less than recommended minimum $min_backlog_limit"
        return 1
    fi
    
    # Check if grub configuration has sufficient audit_backlog_limit
    if [ "$grub_has_backlog" = false ]; then
        echo "FAIL: audit_backlog_limit not configured in grub"
        echo "PROOF: /etc/default/grub GRUB_CMDLINE_LINUX does not contain audit_backlog_limit"
        return 1
    fi
    
    if [ -n "$grub_backlog" ] && [ "$grub_backlog" -lt "$min_backlog_limit" ]; then
        echo "FAIL: audit_backlog_limit is insufficient in grub configuration"
        echo "PROOF: Grub audit_backlog_limit=$grub_backlog is less than recommended minimum $min_backlog_limit"
        return 1
    fi
    
    # Check if grubby has sufficient audit_backlog_limit
    if [ "$grubby_has_backlog" = false ]; then
        echo "FAIL: audit_backlog_limit not properly configured in grubby"
        echo "PROOF: grubby --info=ALL does not show sufficient audit_backlog_limit for all kernels"
        return 1
    fi
    
    echo "PASS: audit_backlog_limit properly configured"
    echo "PROOF: audit_backlog_limit=$current_backlog found in current kernel, grub configuration, and grubby"
    return 0
}

# Function to check configuration status (without requiring current kernel to have it)
check_configuration_status() {
    echo "Checking audit_backlog_limit configuration status..."
    
    local config_ok=true
    local min_backlog_limit=8192
    
    # Check grub configuration
    if [ -f /etc/default/grub ]; then
        if grep -q 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub 2>/dev/null; then
            local grub_backlog=$(grep 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub | grep -o 'audit_backlog_limit=[0-9]*' | cut -d= -f2)
            if [ -n "$grub_backlog" ] && [ "$grub_backlog" -ge "$min_backlog_limit" ]; then
                echo "PASS: audit_backlog_limit=$grub_backlog configured in /etc/default/grub"
                echo "PROOF: GRUB_CMDLINE_LINUX contains audit_backlog_limit=$grub_backlog"
            else
                echo "FAIL: audit_backlog_limit insufficient or missing in /etc/default/grub"
                echo "PROOF: GRUB_CMDLINE_LINUX has audit_backlog_limit=$grub_backlog (min: $min_backlog_limit)"
                config_ok=false
            fi
        else
            echo "FAIL: audit_backlog_limit not configured in /etc/default/grub"
            echo "PROOF: GRUB_CMDLINE_LINUX does not contain audit_backlog_limit"
            config_ok=false
        fi
    else
        echo "FAIL: /etc/default/grub does not exist"
        config_ok=false
    fi
    
    # Check if grubby has audit_backlog_limit configured for all kernels
    if command -v grubby >/dev/null 2>&1; then
        if grubby --info=ALL 2>/dev/null | grep -q "args.*audit_backlog_limit="; then
            local grubby_backlog=$(grubby --info=ALL 2>/dev/null | grep "args" | grep -o 'audit_backlog_limit=[0-9]*' | cut -d= -f2 | head -1)
            if [ -n "$grubby_backlog" ] && [ "$grubby_backlog" -ge "$min_backlog_limit" ]; then
                echo "PASS: audit_backlog_limit=$grubby_backlog configured in grubby for all kernels"
                echo "PROOF: grubby --info=ALL shows audit_backlog_limit=$grubby_backlog"
            else
                echo "FAIL: audit_backlog_limit insufficient in grubby"
                echo "PROOF: grubby --info=ALL shows audit_backlog_limit=$grubby_backlog (min: $min_backlog_limit)"
                config_ok=false
            fi
        else
            echo "FAIL: audit_backlog_limit not configured in grubby"
            echo "PROOF: grubby --info=ALL does not show audit_backlog_limit for all kernels"
            config_ok=false
        fi
    else
        echo "FAIL: grubby command not available"
        config_ok=false
    fi
    
    # Check current kernel (informational only)
    if grep -q "audit_backlog_limit=" /proc/cmdline 2>/dev/null; then
        local current_backlog=$(grep -o 'audit_backlog_limit=[0-9]*' /proc/cmdline | cut -d= -f2)
        if [ -n "$current_backlog" ] && [ "$current_backlog" -ge "$min_backlog_limit" ]; then
            echo "PASS: audit_backlog_limit=$current_backlog found in current kernel command line"
            echo "PROOF: /proc/cmdline contains audit_backlog_limit=$current_backlog"
        else
            echo "INFO: audit_backlog_limit insufficient or missing in current kernel (reboot required)"
            echo "PROOF: /proc/cmdline has audit_backlog_limit=$current_backlog (min: $min_backlog_limit)"
        fi
    else
        echo "INFO: audit_backlog_limit not in current kernel (reboot required)"
        echo "PROOF: /proc/cmdline does not contain audit_backlog_limit"
    fi
    
    if [ "$config_ok" = true ]; then
        return 0
    else
        return 1
    fi
}

# Function to fix
fix_audit_backlog_limit() {
    echo "Applying fix..."
    
    # Set recommended backlog limit
    local backlog_limit=8192
    
    # Update kernel parameters using grubby
    echo " - Updating kernel parameters with grubby (audit_backlog_limit=$backlog_limit)"
    if command -v grubby >/dev/null 2>&1; then
        grubby --update-kernel ALL --args "audit_backlog_limit=$backlog_limit"
        echo " - Successfully updated kernel parameters with grubby"
    else
        echo " - ERROR: grubby command not found"
        return 1
    fi
    
    # Update /etc/default/grub
    if [ -f /etc/default/grub ]; then
        echo " - Updating /etc/default/grub"
        
        # Check if GRUB_CMDLINE_LINUX exists
        if grep -q '^GRUB_CMDLINE_LINUX=' /etc/default/grub; then
            # Check if audit_backlog_limit is already present
            if grep -q 'GRUB_CMDLINE_LINUX.*audit_backlog_limit=' /etc/default/grub; then
                # Update existing audit_backlog_limit
                sed -i "s/audit_backlog_limit=[0-9]*/audit_backlog_limit=$backlog_limit/g" /etc/default/grub
                echo " - Updated existing audit_backlog_limit to $backlog_limit"
            else
                # Add audit_backlog_limit to existing GRUB_CMDLINE_LINUX
                sed -i "s/\(GRUB_CMDLINE_LINUX=\"[^\"]*\)\"/\1 audit_backlog_limit=$backlog_limit\"/" /etc/default/grub
                echo " - Added audit_backlog_limit=$backlog_limit to GRUB_CMDLINE_LINUX"
            fi
        else
            # Add GRUB_CMDLINE_LINUX with audit_backlog_limit
            echo "GRUB_CMDLINE_LINUX=\"audit_backlog_limit=$backlog_limit\"" >> /etc/default/grub
            echo " - Created GRUB_CMDLINE_LINUX with audit_backlog_limit=$backlog_limit"
        fi
    else
        echo " - Creating /etc/default/grub with audit_backlog_limit=$backlog_limit"
        mkdir -p /etc/default
        cat > /etc/default/grub << EOF
GRUB_TIMEOUT=5
GRUB_DISTRIBUTOR="\$(sed 's, release .*\$,,g' /etc/system-release)"
GRUB_DEFAULT=saved
GRUB_DISABLE_SUBMENU=true
GRUB_TERMINAL_OUTPUT="console"
GRUB_CMDLINE_LINUX="audit_backlog_limit=$backlog_limit"
GRUB_DISABLE_RECOVERY="true"
EOF
        echo " - Created /etc/default/grub with audit_backlog_limit=$backlog_limit"
    fi
    
    # Regenerate grub configuration
    echo " - Regenerating grub configuration"
    if command -v grub2-mkconfig >/dev/null 2>&1; then
        if [ -d /boot/efi/EFI/oracle ]; then
            # UEFI system
            grub2-mkconfig -o /boot/efi/EFI/oracle/grub.cfg
            echo " - Regenerated UEFI grub configuration"
        elif [ -d /boot/grub2 ]; then
            # BIOS system
            grub2-mkconfig -o /boot/grub2/grub.cfg
            echo " - Regenerated BIOS grub configuration"
        else
            echo " - Warning: Could not determine grub configuration location"
        fi
    else
        echo " - Warning: grub2-mkconfig command not found"
    fi
    
    echo " - audit_backlog_limit configuration completed"
    echo ""
    echo "==================================================================="
    echo "IMPORTANT: A REBOOT IS REQUIRED for the audit_backlog_limit parameter to take effect"
    echo "==================================================================="
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_backlog_limit
    fi
    echo ""
    echo "==================================================================="
    echo "Final Configuration Status:"
    echo "==================================================================="
    if check_configuration_status; then
        echo ""
        echo "SUCCESS: Configuration completed successfully"
        if ! grep -q "audit_backlog_limit=" /proc/cmdline 2>/dev/null; then
            echo "NOTE: System requires reboot to activate audit_backlog_limit in running kernel"
        fi
    else
        echo ""
        echo "FAIL: Configuration issues remain"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="