#!/usr/bin/env bash
# Script: 5.2.1.4.sh
# Item: 5.2.1.4 Ensure auditd service is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.1.4.sh"
ITEM_NAME="5.2.1.4 Ensure auditd service is enabled (Automated)"
DESCRIPTION="This remediation ensures auditd service is enabled and running."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking auditd service status..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is enabled
    if ! systemctl is-enabled auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not enabled"
        echo "PROOF: systemctl is-enabled auditd shows disabled"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Check if auditd service is masked
    if systemctl is-masked auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is masked"
        echo "PROOF: systemctl is-masked auditd shows masked"
        return 1
    fi
    
    echo "PASS: auditd service properly enabled and running"
    echo "PROOF: auditd service is enabled and active"
    return 0
}
# Function to fix
fix_auditd_service() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Unmask auditd service if masked
    if systemctl is-masked auditd >/dev/null 2>&1; then
        echo " - Unmasking auditd service"
        systemctl unmask auditd
    fi
    
    # Enable and start auditd service
    if ! systemctl is-enabled auditd >/dev/null 2>&1 || ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Enabling and starting auditd service"
        systemctl --now enable auditd
    fi
    
    echo " - auditd service configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_auditd_service
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: auditd service properly enabled and running"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="