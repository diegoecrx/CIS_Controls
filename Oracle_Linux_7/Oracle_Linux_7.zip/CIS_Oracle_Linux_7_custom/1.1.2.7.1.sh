#!/usr/bin/env bash

# Script: 1.1.2.7.1.sh
# Item: 1.1.2.7.1 Ensure separate partition exists for /var/log/audit (Automated)
# FORCE VERSION - Creates partition if needed

set -euo pipefail

SCRIPT_NAME="1.1.2.7.1.sh"
ITEM_NAME="1.1.2.7.1 Ensure separate partition exists for /var/log/audit (Automated)"
DESCRIPTION="This remediation ensures a separate partition exists for /var/log/audit. FORCE VERSION - Creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to create /var/log/audit partition
create_audit_partition() {
    echo "==================================================================="
    echo "FORCE MODE: CREATING SEPARATE /var/log/audit PARTITION"
    echo "==================================================================="
    echo ""

    # Check available space
    available_space=$(df / --output=avail | tail -1 | tr -d ' ')
    available_space_mb=$((available_space / 1024))
    
    # Calculate /var/log/audit usage
    audit_usage=$(du -s /var/log/audit 2>/dev/null | cut -f1 || echo 0)
    audit_usage_mb=$((audit_usage / 1024))
    
    # Determine partition size (usage + 100% for growth + buffer)
    partition_size_mb=$((audit_usage_mb * 2 + 200))
    
    # Minimum size for new audit directories
    if [ "$partition_size_mb" -lt 500 ]; then
        partition_size_mb=500
    fi
    
    echo " - /var/log/audit usage: ${audit_usage_mb}MB"
    echo " - Available space: ${available_space_mb}MB"
    echo " - Partition size: ${partition_size_mb}MB"
    echo ""

    # Validate space
    if [ "$available_space_mb" -lt "$partition_size_mb" ]; then
        echo "ERROR: Insufficient disk space. Need ${partition_size_mb}MB, have ${available_space_mb}MB"
        return 1
    fi

    # Create backup
    echo " - Creating backup of /var/log/audit..."
    backup_dir="/root/audit_migration_backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    # Backup audit data if it exists
    if [ -d "/var/log/audit" ] && [ "$(ls -A /var/log/audit 2>/dev/null)" ]; then
        cp -a /var/log/audit/* "$backup_dir/" 2>/dev/null || true
        echo " - Backup created: $backup_dir"
    else
        echo " - No existing audit data to backup"
        mkdir -p "$backup_dir/empty"
    fi
    
    # Stop audit services
    echo " - Stopping audit services..."
    systemctl stop auditd 2>/dev/null || true
    systemctl stop rsyslog 2>/dev/null || true
    sleep 2

    # Create partition image
    echo " - Creating ${partition_size_mb}MB partition image..."
    audit_img="/var_log_audit_partition.img"
    if ! dd if=/dev/zero of="$audit_img" bs=1M count="$partition_size_mb" status=progress 2>&1; then
        echo "ERROR: Failed to create disk image"
        return 1
    fi
    
    if ! mkfs.ext4 -F "$audit_img" 2>&1; then
        echo "ERROR: Failed to create filesystem"
        rm -f "$audit_img"
        return 1
    fi
    
    # Create temporary mount point for migration
    echo " - Migrating data to new partition..."
    temp_mount="/mnt/newaudit_$$"
    mkdir -p "$temp_mount"
    
    if ! mount -o loop "$audit_img" "$temp_mount" 2>&1; then
        echo "ERROR: Failed to mount disk image temporarily"
        rm -f "$audit_img"
        rmdir "$temp_mount"
        return 1
    fi
    
    # Copy existing data or create directory structure
    if [ -d "/var/log/audit" ] && [ "$(ls -A /var/log/audit 2>/dev/null)" ]; then
        cp -a /var/log/audit/* "$temp_mount"/ 2>/dev/null || true
    fi
    
    # Set proper permissions
    chmod 750 "$temp_mount"
    chown root:root "$temp_mount"
    
    echo "Audit partition created $(date) - CIS 1.1.2.7.1" > "$temp_mount/.audit_partition_marker"
    
    umount "$temp_mount"
    rmdir "$temp_mount"
    
    # Replace old /var/log/audit
    echo " - Activating new partition..."
    
    # Backup existing directory if it exists and isn't already a mount point
    if [ -d "/var/log/audit" ] && ! mountpoint -q "/var/log/audit"; then
        mv /var/log/audit "/var/log/audit.old.backup.$$"
        echo " - Backed up existing directory to /var/log/audit.old.backup.$$"
    fi
    
    # Ensure directory exists
    mkdir -p /var/log/audit
    chmod 750 /var/log/audit
    chown root:root /var/log/audit
    
    # Mount to final location
    echo " - Mounting to /var/log/audit..."
    if ! mount -o loop "$audit_img" /var/log/audit 2>&1; then
        echo "ERROR: Failed to mount to /var/log/audit"
        # Restore backup
        if [ -d "/var/log/audit.old.backup.$$" ]; then
            rm -rf /var/log/audit
            mv "/var/log/audit.old.backup.$$" /var/log/audit
        fi
        return 1
    fi
    
    # Update fstab with secure options
    echo " - Updating /etc/fstab..."
    cp /etc/fstab "/etc/fstab.backup.audit.$(date +%Y%m%d_%H%M%S)"
    
    # Remove any existing /var/log/audit entries
    grep -v -E '\s/var/log/audit\s' /etc/fstab > /etc/fstab.tmp
    
    # Add new entry with secure options
    echo "$audit_img /var/log/audit ext4 loop,defaults,nodev,nosuid,noexec 0 2" >> /etc/fstab.tmp
    mv /etc/fstab.tmp /etc/fstab
    
    # Restart services
    echo " - Restarting audit services..."
    systemctl start auditd 2>/dev/null || true
    systemctl start rsyslog 2>/dev/null || true
    
    # Set proper permissions on mounted partition
    chmod 750 /var/log/audit
    chown root:root /var/log/audit
    
    echo " - SUCCESS: /var/log/audit partition created and mounted"
    return 0
}

# Function to fix_existing_mount
fix_existing_mount() {
    echo "Fixing existing /var/log/audit mount configuration..."
    
    # Check what's currently mounted at /var/log/audit
    current_source=$(findmnt -n -o SOURCE /var/log/audit 2>/dev/null || true)
    
    if [ -n "$current_source" ]; then
        echo " - Found existing mount: $current_source"
        
        # Ensure fstab entry exists
        if ! grep -q -E '\s/var/log/audit\s' /etc/fstab; then
            echo " - Adding missing fstab entry..."
            cp /etc/fstab "/etc/fstab.backup.audit_fix.$(date +%Y%m%d_%H%M%S)"
            echo "$current_source /var/log/audit auto defaults,nodev,nosuid,noexec 0 2" >> /etc/fstab
            echo " - Added fstab entry for $current_source"
        else
            echo " - fstab entry already exists"
        fi
        
        # Remount with secure options
        echo " - Remounting with secure options..."
        if mount -o remount,nodev,nosuid,noexec /var/log/audit 2>/dev/null; then
            echo " - SUCCESS: Remounted with secure options"
        else
            echo " - WARNING: Could not remount with secure options"
        fi
    else
        echo " - No existing mount found at /var/log/audit"
        return 1
    fi
}

# Main remediation function
{
    echo "Checking current /var/log/audit mount status..."
    echo ""

    # Display current mount status
    echo "Current /var/log/audit mount information:"
    if mountpoint -q /var/log/audit; then
        mount | grep -E '\s/var/log/audit\s' || findmnt /var/log/audit
    else
        echo "No separate /var/log/audit mount found"
        echo "Directory exists: $(if [ -d "/var/log/audit" ]; then echo "Yes"; else echo "No"; fi)"
    fi
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/log/audit:"
    grep -E '\s/var/log/audit\s' /etc/fstab || echo "No /var/log/audit entry in /etc/fstab"
    echo ""

    # Check if /var/log/audit is a separate partition
    echo "Checking if /var/log/audit is a separate partition:"
    
    # Use multiple methods to check
    if mountpoint -q /var/log/audit; then
        audit_device=$(findmnt -n -o SOURCE /var/log/audit 2>/dev/null || true)
        root_device=$(findmnt -n -o SOURCE / 2>/dev/null || true)
        
        if [ -n "$audit_device" ] && [ -n "$root_device" ] && [ "$audit_device" != "$root_device" ]; then
            echo "PASS: /var/log/audit is on separate partition: $audit_device"
            audit_is_separate=true
            partition_created=false
        else
            echo "FAIL: /var/log/audit shares device with root filesystem"
            audit_is_separate=false
        fi
    else
        echo "FAIL: /var/log/audit is NOT a separate mount point"
        audit_is_separate=false
    fi

    # FORCE MODE: Create partition or fix existing configuration
    if [ "$audit_is_separate" = false ]; then
        echo ""
        echo "FORCE MODE: Creating separate /var/log/audit partition..."
        if create_audit_partition; then
            audit_is_separate=true
            partition_created=true
            echo " - FORCE MODE: Separate /var/log/audit partition creation completed"
            echo ""
        else
            echo " - ERROR: Failed to create /var/log/audit partition"
            exit 1
        fi
    else
        # Fix existing mount configuration
        echo ""
        echo "Existing partition found, ensuring proper configuration..."
        if fix_existing_mount; then
            partition_created=false
            echo " - Existing mount configuration fixed"
        else
            echo " - WARNING: Could not fix existing mount configuration"
        fi
    fi

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification
    final_status_pass=true
    
    # PROOF 1: Verify /var/log/audit is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var/log/audit IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------------"
    if mountpoint -q /var/log/audit; then
        mount_output=$(mount | grep -E '\s/var/log/audit\s' || findmnt /var/log/audit)
        echo "PASS: /var/log/audit is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
        
        # Verify it's different from root
        current_audit_device=$(findmnt -n -o SOURCE /var/log/audit 2>/dev/null || true)
        current_root_device=$(findmnt -n -o SOURCE / 2>/dev/null || true)
        if [ "$current_audit_device" != "$current_root_device" ]; then
            echo "PASS: Using different device than root filesystem"
        else
            echo "FAIL: Still sharing device with root filesystem"
            final_status_pass=false
        fi
    else
        echo "FAIL: /var/log/audit is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify /var/log/audit entry in fstab
    echo ""
    echo "2. VERIFYING /var/log/audit ENTRY IN /etc/fstab:"
    echo "-----------------------------------------------"
    fstab_entry=$(grep -E '\s/var/log/audit\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        echo "PASS: /var/log/audit entry found in /etc/fstab"
        echo "PROOF (/etc/fstab entry):"
        echo "$fstab_entry"
    else
        echo "FAIL: No /var/log/audit entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify filesystem type and options
    echo ""
    echo "3. VERIFYING FILESYSTEM TYPE AND MOUNT OPTIONS:"
    echo "----------------------------------------------"
    if mountpoint -q /var/log/audit; then
        mount_options=$(findmnt -n -o OPTIONS /var/log/audit 2>/dev/null || true)
        if [ -n "$mount_options" ]; then
            echo "PASS: Mount options: $mount_options"
        else
            echo "FAIL: Could not determine mount options"
            final_status_pass=false
        fi
    else
        echo "FAIL: /var/log/audit is not mounted"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify audit functionality
    echo ""
    echo "4. VERIFYING AUDIT FUNCTIONALITY:"
    echo "--------------------------------"
    
    # Check if audit directory is accessible
    if [ -d "/var/log/audit" ] && [ -w "/var/log/audit" ]; then
        echo "PASS: /var/log/audit directory is accessible"
        
        # Test basic write functionality
        test_file="/var/log/audit/.cis_test_$$"
        if touch "$test_file" 2>/dev/null; then
            echo "PASS: Write test successful"
            rm -f "$test_file"
        else
            echo "WARNING: Write test failed"
        fi
    else
        echo "FAIL: /var/log/audit directory not accessible"
        final_status_pass=false
    fi
    
    # Check auditd service
    if systemctl is-active auditd &>/dev/null; then
        echo "PASS: auditd service is running"
    else
        echo "WARNING: auditd service is not running"
        echo " - Attempting to start auditd..."
        if systemctl start auditd 2>/dev/null; then
            echo "PASS: auditd service started successfully"
        else
            echo "WARNING: Could not start auditd service"
            echo " - This may be normal if auditd is not installed or configured"
        fi
    fi
    
    # PROOF 5: Verify partition persistence
    echo ""
    echo "5. VERIFYING PARTITION PERSISTENCE:"
    echo "----------------------------------"
    
    if grep -q -E '\s/var/log/audit\s' /etc/fstab; then
        echo "PASS: fstab entry exists for persistence"
        
        # Test remount
        if mountpoint -q /var/log/audit; then
            current_mount=$(findmnt -n -o SOURCE,TARGET /var/log/audit)
            echo "PASS: Currently mounted: $current_mount"
        else
            echo "FAIL: Not currently mounted despite fstab entry"
            final_status_pass=false
        fi
    else
        echo "FAIL: No fstab entry for persistence"
        final_status_pass=false
    fi

    # Final summary
    echo ""
    echo "==================================================================="
    if [ "$final_status_pass" = true ]; then
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        if [ "$partition_created" = true ]; then
            echo "FORCE MODE SUMMARY:"
            echo "==================="
            echo "- ✓ Separate /var/log/audit partition created"
            echo "- ✓ Secure mount options configured"
            echo "- ✓ fstab entry added for persistence"
            echo "- ✓ Directory accessibility verified"
            echo "- ✓ Backup created in backup directory"
            echo ""
            echo "Partition location: /var_log_audit_partition.img"
            echo "Backup location: /root/audit_migration_backup_*"
        else
            echo "EXISTING PARTITION CONFIGURED:"
            echo "=============================="
            echo "- ✓ /var/log/audit was already on separate partition"
            echo "- ✓ Mount configuration verified and secured"
            echo "- ✓ All security verifications passed"
        fi
    else
        echo "WARNING: Some verification steps failed"
        echo "The system may require manual intervention for full compliance."
        echo "Please review the failed verification steps above."
        exit 1
    fi

    echo ""
    echo "Current /var/log/audit status:"
    echo "=============================="
    df -h /var/log/audit 2>/dev/null || echo "Cannot display disk usage for /var/log/audit"
    echo ""
    mount | grep -E '\s/var/log/audit\s' || findmnt /var/log/audit 2>/dev/null || echo "No mount information available"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="