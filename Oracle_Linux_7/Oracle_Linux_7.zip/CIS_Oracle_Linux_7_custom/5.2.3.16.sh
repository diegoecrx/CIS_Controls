#!/usr/bin/env bash
# Script: 5.2.3.16.sh
# Item: 5.2.3.16 Ensure successful and unsuccessful attempts to use the setfacl command are recorded (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.3.16.sh"
ITEM_NAME="5.2.3.16 Ensure successful and unsuccessful attempts to use the setfacl command are recorded (Automated)"
DESCRIPTION="This remediation ensures successful and unsuccessful attempts to use the setfacl command are recorded by configuring audit rules for the setfacl binary."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking setfacl command audit rules configuration..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo "FAIL: auditd service is not running"
        echo "PROOF: systemctl is-active auditd shows inactive"
        return 1
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    # Find setfacl binary path
    setfacl_path=$(which setfacl 2>/dev/null || echo "/usr/bin/setfacl")
    
    # Check if setfacl exists
    if [ ! -x "$setfacl_path" ]; then
        echo "PASS: setfacl command not found on system"
        echo "PROOF: setfacl binary not present at $setfacl_path"
        return 0
    fi
    
    # Check for setfacl audit rules in running configuration
    if ! auditctl -l | grep -q "\-a always,exit \-F path=$setfacl_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng"; then
        echo "FAIL: setfacl audit rules not found in running configuration"
        echo "PROOF: Required audit rule for $setfacl_path not present in auditctl -l output"
        return 1
    fi
    
    # Check for rules in configuration files
    config_rules_found=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "\-a always,exit \-F path=$setfacl_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng" /etc/audit/rules.d/ >/dev/null 2>&1; then
            config_rules_found=true
        fi
    fi
    
    if [ "$config_rules_found" = false ]; then
        echo "FAIL: setfacl audit rules not found in configuration files"
        echo "PROOF: Required audit rule for $setfacl_path not present in /etc/audit/rules.d/"
        return 1
    fi
    
    echo "PASS: setfacl command audit rules properly configured"
    echo "PROOF: Audit rule for setfacl command found in both running configuration and rule files"
    return 0
}
# Function to fix
fix_setfacl_audit_rules() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    fi
    
    # Ensure auditd service is running
    if ! systemctl is-active auditd >/dev/null 2>&1; then
        echo " - Starting auditd service"
        systemctl start auditd
    fi
    
    # Create rules.d directory if it doesn't exist
    if [ ! -d /etc/audit/rules.d ]; then
        echo " - Creating /etc/audit/rules.d directory"
        mkdir -p /etc/audit/rules.d
    fi
    
    # Get UID_MIN value
    UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
    if [ -z "$UID_MIN" ]; then
        UID_MIN=1000
    fi
    
    echo " - Using UID_MIN value: $UID_MIN"
    
    # Find setfacl binary path
    setfacl_path=$(which setfacl 2>/dev/null || echo "/usr/bin/setfacl")
    
    # Check if setfacl exists
    if [ ! -x "$setfacl_path" ]; then
        echo " - setfacl command not found on system, no audit rule needed"
        return
    fi
    
    echo " - Found setfacl command at: $setfacl_path"
    
    # Check if rules already exist in any file
    rules_exist=false
    if [ -d /etc/audit/rules.d ]; then
        if grep -r "\-a always,exit \-F path=$setfacl_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng" /etc/audit/rules.d/ >/dev/null 2>&1; then
            rules_exist=true
        fi
    fi
    
    if [ "$rules_exist" = false ]; then
        echo " - Adding setfacl audit rule to /etc/audit/rules.d/50-perm_chng.rules"
        
        # Check if the file exists and add rule or append to existing file
        if [ -f /etc/audit/rules.d/50-perm_chng.rules ]; then
            # File exists, check if it already has our rule
            if ! grep -q "\-a always,exit \-F path=$setfacl_path \-F perm=x \-F auid>=$UID_MIN \-F auid!=unset \-k perm_chng" /etc/audit/rules.d/50-perm_chng.rules; then
                echo "## Monitor successful and unsuccessful attempts to use the setfacl command" >> /etc/audit/rules.d/50-perm_chng.rules
                echo "-a always,exit -F path=${setfacl_path} -F perm=x -F auid>=${UID_MIN} -F auid!=unset -k perm_chng" >> /etc/audit/rules.d/50-perm_chng.rules
            fi
        else
            # File doesn't exist, create it
            cat > /etc/audit/rules.d/50-perm_chng.rules << EOF
## Monitor successful and unsuccessful attempts to use the setfacl command
-a always,exit -F path=${setfacl_path} -F perm=x -F auid>=${UID_MIN} -F auid!=unset -k perm_chng
EOF
        fi
    else
        echo " - Setfacl audit rules already exist in configuration"
    fi
    
    # Merge and load the rules into active configuration
    echo " - Loading audit rules into active configuration"
    augenrules --load
    
    # Check if reboot is required
    if auditctl -s | grep "enabled" | grep -q "2"; then
        echo " - WARNING: Reboot required to load rules (auditing configuration is locked)"
    fi
    
    echo " - setfacl audit rules configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_setfacl_audit_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: setfacl command audit rules properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="