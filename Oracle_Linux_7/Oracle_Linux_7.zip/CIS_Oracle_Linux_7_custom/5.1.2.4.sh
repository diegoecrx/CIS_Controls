#!/usr/bin/env bash
# Script: 5.1.2.4.sh
# Item: 5.1.2.4 Ensure journald is configured to write logfiles to persistent disk (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.2.4.sh"
ITEM_NAME="5.1.2.4 Ensure journald is configured to write logfiles to persistent disk (Automated)"
DESCRIPTION="This remediation ensures journald is configured to write logfiles to persistent disk."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking journald persistent storage configuration..."
    
    # Check if journald.conf exists
    if [ ! -f /etc/systemd/journald.conf ]; then
        echo "FAIL: /etc/systemd/journald.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Check for Storage setting in main config file
    if grep -q '^Storage=persistent' /etc/systemd/journald.conf 2>/dev/null; then
        echo "PASS: journald persistent storage properly configured"
        echo "PROOF: Storage=persistent found in /etc/systemd/journald.conf"
        return 0
    fi
    
    # Check for Storage setting in journald.conf.d directory
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in /etc/systemd/journald.conf.d/*.conf; do
            if [ -f "$conf_file" ] && grep -q '^Storage=persistent' "$conf_file" 2>/dev/null; then
                echo "PASS: journald persistent storage properly configured"
                echo "PROOF: Storage=persistent found in $conf_file"
                return 0
            fi
        done
    fi
    
    # Check if Storage is set to other values
    storage_setting=$(grep '^Storage=' /etc/systemd/journald.conf 2>/dev/null | head -1 | cut -d= -f2)
    if [ -n "$storage_setting" ] && [ "$storage_setting" != "persistent" ]; then
        echo "FAIL: journald storage is set to $storage_setting instead of persistent"
        echo "PROOF: Storage=$storage_setting found in /etc/systemd/journald.conf"
        return 1
    fi
    
    # Check for conflicting Storage settings in conf.d files
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in /etc/systemd/journald.conf.d/*.conf; do
            if [ -f "$conf_file" ]; then
                storage_setting=$(grep '^Storage=' "$conf_file" 2>/dev/null | head -1 | cut -d= -f2)
                if [ -n "$storage_setting" ] && [ "$storage_setting" != "persistent" ]; then
                    echo "FAIL: journald storage is set to $storage_setting instead of persistent"
                    echo "PROOF: Storage=$storage_setting found in $conf_file"
                    return 1
                fi
            fi
        done
    fi
    
    echo "FAIL: journald persistent storage not configured"
    echo "PROOF: No Storage=persistent setting found in journald configuration"
    return 1
}
# Function to fix
fix_journald_persistent_storage() {
    echo "Applying fix..."
    
    # Ensure journald.conf exists
    if [ ! -f /etc/systemd/journald.conf ]; then
        echo " - Creating /etc/systemd/journald.conf"
        cat > /etc/systemd/journald.conf << 'EOF'
#  This file is part of systemd.
#
#  systemd is free software; you can redistribute it and/or modify it
#  under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation; either version 2.1 of the License, or
#  (at your option) any later version.
#
# Entries in this file show the compile time defaults.
# You can change settings by editing this file.
# Defaults can be restored by simply deleting this file.
#
# See journald.conf(5) for details.

[Journal]
EOF
    fi
    
    # Check if Storage is already configured
    if grep -q '^Storage=' /etc/systemd/journald.conf; then
        # Update existing Storage setting
        echo " - Updating existing Storage setting in /etc/systemd/journald.conf"
        sed -i 's/^Storage=.*/Storage=persistent/' /etc/systemd/journald.conf
    else
        # Add Storage setting to [Journal] section
        echo " - Adding Storage=persistent to /etc/systemd/journald.conf"
        if grep -q '^\[Journal\]' /etc/systemd/journald.conf; then
            # Add after [Journal] section
            sed -i '/^\[Journal\]/a Storage=persistent' /etc/systemd/journald.conf
        else
            # Add [Journal] section and Storage setting
            echo -e "\n[Journal]\nStorage=persistent" >> /etc/systemd/journald.conf
        fi
    fi
    
    # Remove any conflicting Storage settings from conf.d files
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in /etc/systemd/journald.conf.d/*.conf; do
            if [ -f "$conf_file" ]; then
                storage_setting=$(grep '^Storage=' "$conf_file" 2>/dev/null | head -1 | cut -d= -f2)
                if [ -n "$storage_setting" ] && [ "$storage_setting" != "persistent" ]; then
                    echo " - Removing conflicting Storage=$storage_setting from $conf_file"
                    sed -i '/^Storage=/d' "$conf_file"
                fi
            fi
        done
    fi
    
    # Ensure /var/log/journal directory exists for persistent storage
    if [ ! -d /var/log/journal ]; then
        echo " - Creating /var/log/journal directory"
        mkdir -p /var/log/journal
        systemd-tmpfiles --create --prefix /var/log/journal
    fi
    
    # Restart systemd-journald service to apply changes
    echo " - Restarting systemd-journald service"
    systemctl restart systemd-journald.service
    
    echo " - journald persistent storage configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journald_persistent_storage
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: journald persistent storage properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="