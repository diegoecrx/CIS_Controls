#!/usr/bin/env bash
# Script: 2.2.21.sh
# Item: 2.2.21 Ensure mail transfer agents are configured for local-only mode (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation configures the postfix mail server to permit mail only via the local loopback interface. If another MTA is present, consult its documentation. Applies only to local postfix installs.

set -euo pipefail

SCRIPT_NAME="2.2.21.sh"
ITEM_NAME="2.2.21 Ensure mail transfer agents are configured for local-only mode (Automated)"
DESCRIPTION="This remediation configures the postfix mail server to permit mail only via the local loopback interface. If another MTA is present, consult its documentation. Applies only to local postfix installs."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

check_postfix_installed() {
  if ! rpm -q postfix >/dev/null 2>&1; then
    echo "Warning: postfix not installed. Skipping remediation."
    exit 0
  fi
}

edit_postfix_config() {
  local config_file="/etc/postfix/main.cf"
  echo "Editing $config_file..."

  if [ ! -f "$config_file" ]; then
    echo "FAIL: $config_file does not exist."
    exit 1
  fi
  backup_file="${config_file}.bak.$(date +%Y%m%d%H%M%S)"
  cp "$config_file" "$backup_file"

  if grep -q '^inet_interfaces' "$config_file"; then
    sed -i 's/^inet_interfaces.*/inet_interfaces = loopback-only/' "$config_file"
    echo " - Changed existing inet_interfaces configuration to loopback-only."
  else
    echo "inet_interfaces = loopback-only" >> "$config_file"
    echo " - Added inet_interfaces = loopback-only to $config_file."
  fi
}

restart_postfix() {
  echo "Restarting postfix..."
  systemctl restart postfix 2>/dev/null || {
    echo "FAIL: Could not restart postfix.";
    exit 2;
  }
}

verify_local_only() {
  local config_file="/etc/postfix/main.cf"
  if grep -q '^inet_interfaces = loopback-only' "$config_file"; then
    echo "PASS: inet_interfaces is set to loopback-only."
  else
    echo "FAIL: inet_interfaces is not set to loopback-only in $config_file."
    exit 3
  fi
  if systemctl is-active postfix >/dev/null 2>&1; then
    echo "PASS: postfix is running."
  else
    echo "FAIL: postfix is not running."
    exit 4
  fi
}

check_postfix_installed
echo ""
edit_postfix_config
echo ""
restart_postfix
echo ""
verify_local_only
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
