#!/usr/bin/env bash
# Script: 2.2.15.sh
# Item: 2.2.15 Ensure telnet server services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures Telnet server services are not in use by removing or masking the telnet.socket and telnet-server package. FORCE VERSION - Comprehensive telnet server removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.15.sh"
ITEM_NAME="2.2.15 Ensure telnet server services are not in use (Automated)"
DESCRIPTION="This remediation ensures Telnet server services are not in use by removing or masking the telnet.socket and telnet-server package. FORCE VERSION - Comprehensive telnet server removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_telnet_status() {
  echo "Checking Telnet server status..."
  if systemctl is-active telnet.socket >/dev/null 2>&1; then
    echo " - telnet.socket is active."
  fi
  if systemctl is-enabled telnet.socket >/dev/null 2>&1; then
    echo " - telnet.socket is enabled."
  fi
  if rpm -q telnet-server >/dev/null 2>&1; then
    echo " - telnet-server package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':23'; then
    echo " - Telnet port 23 is open."
  fi
}

stop_telnet_service() {
  echo "Stopping telnet.socket..."
  systemctl stop telnet.socket 2>/dev/null || true
  pkill -TERM telnetd 2>/dev/null || true
  pkill -KILL telnetd 2>/dev/null || true
}

remove_telnet_package() {
  local pkg_mgr="$1"
  echo "Removing telnet-server package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y telnet-server 2>/dev/null || echo " - WARNING: Could not remove telnet-server (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_telnet_service() {
  echo "Masking telnet.socket..."
  systemctl mask telnet.socket 2>/dev/null || true
}

verify_telnet_removal() {
  echo "Verifying Telnet server remediation..."
  local failed=false
  if rpm -q telnet-server >/dev/null 2>&1; then
    echo "FAIL: telnet-server package is still installed."
    failed=true
  fi
  if systemctl is-enabled telnet.socket 2>/dev/null | grep -vq masked; then
    echo "FAIL: telnet.socket is not masked."
    failed=true
  fi
  if systemctl is-active telnet.socket 2>/dev/null | grep -vq inactive; then
    echo "FAIL: telnet.socket is still active."
    failed=true
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':23'; then
    echo "FAIL: Telnet port 23 is still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_telnet_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING TELNET SERVER SERVICE"
echo "==================================================================="
echo ""

stop_telnet_service
remove_telnet_package "$PKG_MGR"
mask_telnet_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_telnet_removal; then
  echo "SUCCESS: Telnet server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: Telnet server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q telnet-server"
  echo "2. Ensure service is masked: systemctl status telnet.socket"
  echo "3. Check port: ss -tulpn | grep ':23'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
