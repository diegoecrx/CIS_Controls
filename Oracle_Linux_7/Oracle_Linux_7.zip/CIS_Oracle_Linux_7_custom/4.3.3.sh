#!/usr/bin/env bash
# Script: 4.3.3.sh
# Item: 4.3.3 Ensure sudo log file exists (Automated)
set -euo pipefail
SCRIPT_NAME="4.3.3.sh"
ITEM_NAME="4.3.3 Ensure sudo log file exists (Automated)"
DESCRIPTION="This remediation ensures sudo log file exists by adding Defaults logfile in sudoers.d."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for sudo log file configuration..."
    if grep -r '^Defaults\s*logfile' /etc/sudoers /etc/sudoers.d/* 2>/dev/null; then
        echo "PASS: Defaults logfile found"
        echo "PROOF: $(grep -r '^Defaults\s*logfile' /etc/sudoers /etc/sudoers.d/*)"
        return 0
    else
        echo "FAIL: Defaults logfile not found"
        echo "PROOF: No matches in /etc/sudoers or /etc/sudoers.d/*"
        return 1
    fi
}
# Function to fix
fix_sudo_log() {
    echo "Applying fix..."
    file="/etc/sudoers.d/00_sudo_log"
    echo 'Defaults logfile="/var/log/sudo.log"' > "$file"
    chmod 0440 "$file"
    echo " - Added to $file"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_sudo_log
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: sudo log file exists"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="