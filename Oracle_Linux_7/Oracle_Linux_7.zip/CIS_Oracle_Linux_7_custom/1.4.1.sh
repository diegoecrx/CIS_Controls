#!/usr/bin/env bash
# Script: 1.4.1.sh
# Item: 1.4.1 Ensure address space layout randomization (ASLR) is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.4.1.sh"
ITEM_NAME="1.4.1 Ensure address space layout randomization (ASLR) is enabled (Automated)"
DESCRIPTION="This remediation ensures ASLR is enabled by setting kernel.randomize_va_space=2."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current ASLR status..."
    current_value=$(sysctl kernel.randomize_va_space | awk '{print $3}' || true)
    if [ "$current_value" = "2" ]; then
        echo "PASS: kernel.randomize_va_space is 2"
        echo "PROOF: sysctl output: kernel.randomize_va_space = $current_value"
        return 0
    else
        echo "FAIL: kernel.randomize_va_space is $current_value"
        echo "PROOF: sysctl output: kernel.randomize_va_space = $current_value"
        return 1
    fi
}
# Function to fix
fix_aslr() {
    echo "Applying fix..."
    conf_file="/etc/sysctl.d/60-kernel_sysctl.conf"
    echo "kernel.randomize_va_space = 2" >> "$conf_file"
    echo " - Added to $conf_file"
    sysctl -w kernel.randomize_va_space=2 >/dev/null 2>&1
    echo " - Applied with sysctl -w"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_aslr
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ASLR enabled"
    else
        echo "FAIL: ASLR not enabled"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="