#!/usr/bin/env bash
# Script: 5.2.1.2.sh
# Item: 5.2.1.2 Ensure auditing for processes that start prior to auditd is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.1.2.sh"
ITEM_NAME="5.2.1.2 Ensure auditing for processes that start prior to auditd is enabled (Automated)"
DESCRIPTION="This remediation ensures auditing for processes that start prior to auditd is enabled by adding audit=1 to kernel parameters."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking audit kernel parameter configuration..."
    
    # Check current kernel command line
    if grep -q "audit=1" /proc/cmdline 2>/dev/null; then
        cmdline_has_audit=true
    else
        cmdline_has_audit=false
    fi
    
    # Check grub configuration
    grub_has_audit=false
    if [ -f /etc/default/grub ]; then
        if grep -q 'GRUB_CMDLINE_LINUX.*audit=1' /etc/default/grub 2>/dev/null; then
            grub_has_audit=true
        fi
    fi
    
    # Check if grubby has audit=1 configured for all kernels
    grubby_has_audit=true
    if command -v grubby >/dev/null 2>&1; then
        if ! grubby --info=ALL 2>/dev/null | grep -q "args.*audit=1"; then
            grubby_has_audit=false
        fi
    fi
    
    # Check if current kernel has audit=1
    if [ "$cmdline_has_audit" = false ]; then
        echo "FAIL: audit=1 not found in current kernel command line"
        echo "PROOF: /proc/cmdline does not contain audit=1"
        echo "NOTE: A reboot is required for kernel parameter changes to take effect"
        return 1
    fi
    
    # Check if grub configuration has audit=1
    if [ "$grub_has_audit" = false ]; then
        echo "FAIL: audit=1 not configured in grub"
        echo "PROOF: /etc/default/grub GRUB_CMDLINE_LINUX does not contain audit=1"
        return 1
    fi
    
    # Check if grubby has audit=1 configured
    if [ "$grubby_has_audit" = false ]; then
        echo "FAIL: audit=1 not configured in grubby"
        echo "PROOF: grubby --info=ALL does not show audit=1 for all kernels"
        return 1
    fi
    
    echo "PASS: audit kernel parameter properly configured"
    echo "PROOF: audit=1 found in current kernel, grub configuration, and grubby"
    return 0
}

# Function to check configuration status (without requiring current kernel to have it)
check_configuration_status() {
    echo "Checking audit kernel parameter configuration status..."
    
    local config_ok=true
    
    # Check grub configuration
    if [ -f /etc/default/grub ]; then
        if grep -q 'GRUB_CMDLINE_LINUX.*audit=1' /etc/default/grub 2>/dev/null; then
            echo "PASS: audit=1 configured in /etc/default/grub"
            echo "PROOF: GRUB_CMDLINE_LINUX contains audit=1"
        else
            echo "FAIL: audit=1 not configured in /etc/default/grub"
            echo "PROOF: GRUB_CMDLINE_LINUX does not contain audit=1"
            config_ok=false
        fi
    else
        echo "FAIL: /etc/default/grub does not exist"
        config_ok=false
    fi
    
    # Check if grubby has audit=1 configured for all kernels
    if command -v grubby >/dev/null 2>&1; then
        if grubby --info=ALL 2>/dev/null | grep -q "args.*audit=1"; then
            echo "PASS: audit=1 configured in grubby for all kernels"
            echo "PROOF: grubby --info=ALL shows audit=1"
        else
            echo "FAIL: audit=1 not configured in grubby"
            echo "PROOF: grubby --info=ALL does not show audit=1 for all kernels"
            config_ok=false
        fi
    else
        echo "FAIL: grubby command not available"
        config_ok=false
    fi
    
    # Check current kernel (informational only)
    if grep -q "audit=1" /proc/cmdline 2>/dev/null; then
        echo "PASS: audit=1 found in current kernel command line"
        echo "PROOF: /proc/cmdline contains audit=1"
    else
        echo "INFO: audit=1 not in current kernel (reboot required)"
        echo "PROOF: /proc/cmdline does not contain audit=1"
    fi
    
    if [ "$config_ok" = true ]; then
        return 0
    else
        return 1
    fi
}

# Function to fix
fix_audit_kernel_parameter() {
    echo "Applying fix..."
    
    # Update kernel parameters using grubby
    echo " - Updating kernel parameters with grubby"
    if command -v grubby >/dev/null 2>&1; then
        grubby --update-kernel ALL --args 'audit=1'
        echo " - Successfully updated kernel parameters with grubby"
    else
        echo " - ERROR: grubby command not found"
        return 1
    fi
    
    # Update /etc/default/grub
    if [ -f /etc/default/grub ]; then
        echo " - Updating /etc/default/grub"
        
        # Check if GRUB_CMDLINE_LINUX exists
        if grep -q '^GRUB_CMDLINE_LINUX=' /etc/default/grub; then
            # Check if audit=1 is already present
            if ! grep -q 'GRUB_CMDLINE_LINUX.*audit=1' /etc/default/grub; then
                # Add audit=1 to existing GRUB_CMDLINE_LINUX
                sed -i 's/\(GRUB_CMDLINE_LINUX="[^"]*\)"/\1 audit=1"/' /etc/default/grub
                echo " - Added audit=1 to GRUB_CMDLINE_LINUX"
            else
                echo " - audit=1 already present in GRUB_CMDLINE_LINUX"
            fi
        else
            # Add GRUB_CMDLINE_LINUX with audit=1
            echo 'GRUB_CMDLINE_LINUX="audit=1"' >> /etc/default/grub
            echo " - Created GRUB_CMDLINE_LINUX with audit=1"
        fi
    else
        echo " - Creating /etc/default/grub with audit=1"
        mkdir -p /etc/default
        cat > /etc/default/grub << 'EOF'
GRUB_TIMEOUT=5
GRUB_DISTRIBUTOR="$(sed 's, release .*$,,g' /etc/system-release)"
GRUB_DEFAULT=saved
GRUB_DISABLE_SUBMENU=true
GRUB_TERMINAL_OUTPUT="console"
GRUB_CMDLINE_LINUX="audit=1"
GRUB_DISABLE_RECOVERY="true"
EOF
        echo " - Created /etc/default/grub with audit=1"
    fi
    
    # Regenerate grub configuration
    echo " - Regenerating grub configuration"
    if command -v grub2-mkconfig >/dev/null 2>&1; then
        if [ -d /boot/efi/EFI/oracle ]; then
            # UEFI system
            grub2-mkconfig -o /boot/efi/EFI/oracle/grub.cfg
            echo " - Regenerated UEFI grub configuration"
        elif [ -d /boot/grub2 ]; then
            # BIOS system
            grub2-mkconfig -o /boot/grub2/grub.cfg
            echo " - Regenerated BIOS grub configuration"
        else
            echo " - Warning: Could not determine grub configuration location"
        fi
    else
        echo " - Warning: grub2-mkconfig command not found"
    fi
    
    echo " - audit kernel parameter configuration completed"
    echo ""
    echo "==================================================================="
    echo "IMPORTANT: A REBOOT IS REQUIRED for the audit=1 parameter to take effect"
    echo "==================================================================="
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_kernel_parameter
    fi
    echo ""
    echo "==================================================================="
    echo "Final Configuration Status:"
    echo "==================================================================="
    if check_configuration_status; then
        echo ""
        echo "SUCCESS: Configuration completed successfully"
        if ! grep -q "audit=1" /proc/cmdline 2>/dev/null; then
            echo "NOTE: System requires reboot to activate audit=1 in running kernel"
        fi
    else
        echo ""
        echo "FAIL: Configuration issues remain"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="