#!/usr/bin/env bash
# Script: 3.3.5.sh
# Item: 3.3.5 Ensure icmp redirects are not accepted (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.5.sh"
ITEM_NAME="3.3.5 Ensure icmp redirects are not accepted (Automated)"
DESCRIPTION="This remediation ensures ICMP redirects are not accepted for both IPv4 and IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ICMP redirect configuration..."
    
    verification_passed=true
    
    # Check IPv4 redirect settings
    ipv4_all_accept_redirects=$(sysctl net.ipv4.conf.all.accept_redirects 2>/dev/null | awk '{print $3}')
    ipv4_default_accept_redirects=$(sysctl net.ipv4.conf.default.accept_redirects 2>/dev/null | awk '{print $3}')
    
    if [ "$ipv4_all_accept_redirects" != "0" ]; then
        echo "FAIL: net.ipv4.conf.all.accept_redirects is not disabled (runtime)"
        echo "PROOF: net.ipv4.conf.all.accept_redirects = $ipv4_all_accept_redirects"
        verification_passed=false
    else
        echo "PASS: net.ipv4.conf.all.accept_redirects disabled (runtime)"
    fi
    
    if [ "$ipv4_default_accept_redirects" != "0" ]; then
        echo "FAIL: net.ipv4.conf.default.accept_redirects is not disabled (runtime)"
        echo "PROOF: net.ipv4.conf.default.accept_redirects = $ipv4_default_accept_redirects"
        verification_passed=false
    else
        echo "PASS: net.ipv4.conf.default.accept_redirects disabled (runtime)"
    fi
    
    # Check IPv4 configuration files for conflicting settings
    ipv4_all_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "0" ]; then
            echo "FAIL: net.ipv4.conf.all.accept_redirects enabled in configuration: $line"
            ipv4_all_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.conf\.all\.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$ipv4_all_config_issues" = false ]; then
        echo "PASS: net.ipv4.conf.all.accept_redirects properly configured in files"
    fi
    
    ipv4_default_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "0" ]; then
            echo "FAIL: net.ipv4.conf.default.accept_redirects enabled in configuration: $line"
            ipv4_default_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.conf\.default\.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$ipv4_default_config_issues" = false ]; then
        echo "PASS: net.ipv4.conf.default.accept_redirects properly configured in files"
    fi
    
    # Check IPv6 if enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        ipv6_all_accept_redirects=$(sysctl net.ipv6.conf.all.accept_redirects 2>/dev/null | awk '{print $3}')
        ipv6_default_accept_redirects=$(sysctl net.ipv6.conf.default.accept_redirects 2>/dev/null | awk '{print $3}')
        
        if [ "$ipv6_all_accept_redirects" != "0" ]; then
            echo "FAIL: net.ipv6.conf.all.accept_redirects is not disabled (runtime)"
            echo "PROOF: net.ipv6.conf.all.accept_redirects = $ipv6_all_accept_redirects"
            verification_passed=false
        else
            echo "PASS: net.ipv6.conf.all.accept_redirects disabled (runtime)"
        fi
        
        if [ "$ipv6_default_accept_redirects" != "0" ]; then
            echo "FAIL: net.ipv6.conf.default.accept_redirects is not disabled (runtime)"
            echo "PROOF: net.ipv6.conf.default.accept_redirects = $ipv6_default_accept_redirects"
            verification_passed=false
        else
            echo "PASS: net.ipv6.conf.default.accept_redirects disabled (runtime)"
        fi
        
        # Check IPv6 configuration files for conflicting settings
        ipv6_all_config_issues=false
        while IFS= read -r line; do
            # Extract the value after the equals sign
            value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
            if [ "$value" != "0" ]; then
                echo "FAIL: net.ipv6.conf.all.accept_redirects enabled in configuration: $line"
                ipv6_all_config_issues=true
                verification_passed=false
            fi
        done < <(grep -r '^\s*net\.ipv6\.conf\.all\.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
        
        if [ "$ipv6_all_config_issues" = false ]; then
            echo "PASS: net.ipv6.conf.all.accept_redirects properly configured in files"
        fi
        
        ipv6_default_config_issues=false
        while IFS= read -r line; do
            # Extract the value after the equals sign
            value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
            if [ "$value" != "0" ]; then
                echo "FAIL: net.ipv6.conf.default.accept_redirects enabled in configuration: $line"
                ipv6_default_config_issues=true
                verification_passed=false
            fi
        done < <(grep -r '^\s*net\.ipv6\.conf\.default\.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
        
        if [ "$ipv6_default_config_issues" = false ]; then
            echo "PASS: net.ipv6.conf.default.accept_redirects properly configured in files"
        fi
    else
        echo "INFO: IPv6 not enabled, skipping IPv6 checks"
    fi
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: ICMP redirects properly disabled"
        echo "PROOF: All IPv4 and IPv6 accept_redirects set to 0"
        return 0
    else
        return 1
    fi
}
# Function to fix
fix_icmp_redirects() {
    echo "Applying fix..."
    
    # Configure IPv4 redirect settings
    echo " - Configuring IPv4 ICMP redirects"
    
    # Remove any existing conflicting entries from all configuration files
    for config_file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
        if [ -f "$config_file" ]; then
            # Remove accept_redirects entries (both =0 and =1)
            sed -i '/^\s*net\.ipv4\.conf\.all\.accept_redirects\s*=/d' "$config_file" 2>/dev/null || true
            sed -i '/^\s*net\.ipv4\.conf\.default\.accept_redirects\s*=/d' "$config_file" 2>/dev/null || true
        fi
    done
    
    # Create dedicated configuration file for IPv4
    IPV4_CONFIG_FILE="/etc/sysctl.d/60-netipv4_sysctl.conf"
    echo "# ICMP redirect disable - Remediated by $SCRIPT_NAME" > "$IPV4_CONFIG_FILE"
    echo "# $(date)" >> "$IPV4_CONFIG_FILE"
    echo "net.ipv4.conf.all.accept_redirects = 0" >> "$IPV4_CONFIG_FILE"
    echo "net.ipv4.conf.default.accept_redirects = 0" >> "$IPV4_CONFIG_FILE"
    
    # Set active IPv4 kernel parameters
    sysctl -w net.ipv4.conf.all.accept_redirects=0 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.accept_redirects=0 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    # Configure IPv6 redirect settings if IPv6 is enabled
    if [ -d /proc/sys/net/ipv6 ]; then
        echo " - Configuring IPv6 ICMP redirects"
        
        # Remove any existing conflicting entries from all configuration files
        for config_file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
            if [ -f "$config_file" ]; then
                # Remove accept_redirects entries (both =0 and =1)
                sed -i '/^\s*net\.ipv6\.conf\.all\.accept_redirects\s*=/d' "$config_file" 2>/dev/null || true
                sed -i '/^\s*net\.ipv6\.conf\.default\.accept_redirects\s*=/d' "$config_file" 2>/dev/null || true
            fi
        done
        
        # Create dedicated configuration file for IPv6
        IPV6_CONFIG_FILE="/etc/sysctl.d/60-netipv6_sysctl.conf"
        echo "# IPv6 ICMP redirect disable - Remediated by $SCRIPT_NAME" > "$IPV6_CONFIG_FILE"
        echo "# $(date)" >> "$IPV6_CONFIG_FILE"
        echo "net.ipv6.conf.all.accept_redirects = 0" >> "$IPV6_CONFIG_FILE"
        echo "net.ipv6.conf.default.accept_redirects = 0" >> "$IPV6_CONFIG_FILE"
        
        # Set active IPv6 kernel parameters
        sysctl -w net.ipv6.conf.all.accept_redirects=0 >/dev/null 2>&1
        sysctl -w net.ipv6.conf.default.accept_redirects=0 >/dev/null 2>&1
        sysctl -w net.ipv6.route.flush=1 >/dev/null 2>&1
    fi
    
    # Reload all sysctl configurations
    sysctl -p >/dev/null 2>&1 || true
    if ls /etc/sysctl.d/*.conf >/dev/null 2>&1; then
        sysctl -p /etc/sysctl.d/*.conf >/dev/null 2>&1 || true
    fi
    
    echo " - ICMP redirect configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_icmp_redirects
        # Allow time for changes to take effect
        sleep 2
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ICMP redirects properly disabled"
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Debug information:"
        echo "IPv4 runtime all.accept_redirects: $(sysctl net.ipv4.conf.all.accept_redirects 2>/dev/null || echo 'not set')"
        echo "IPv4 runtime default.accept_redirects: $(sysctl net.ipv4.conf.default.accept_redirects 2>/dev/null || echo 'not set')"
        echo "IPv6 runtime all.accept_redirects: $(sysctl net.ipv6.conf.all.accept_redirects 2>/dev/null || echo 'not set')"
        echo "IPv6 runtime default.accept_redirects: $(sysctl net.ipv6.conf.default.accept_redirects 2>/dev/null || echo 'not set')"
        echo ""
        echo "Configuration files:"
        grep -r 'net.ipv4.conf.all.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No IPv4 all.accept_redirects configurations found"
        grep -r 'net.ipv4.conf.default.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No IPv4 default.accept_redirects configurations found"
        grep -r 'net.ipv6.conf.all.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No IPv6 all.accept_redirects configurations found"
        grep -r 'net.ipv6.conf.default.accept_redirects' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No IPv6 default.accept_redirects configurations found"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="