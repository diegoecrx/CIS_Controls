#!/usr/bin/env bash
# Script: 1.7.1.sh
# Item: 1.7.1 Ensure GNOME Display Manager is removed (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.1.sh"
ITEM_NAME="1.7.1 Ensure GNOME Display Manager is removed (Automated)"
DESCRIPTION="This remediation ensures the gdm package is removed from the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking if gdm package is installed..."
    if rpm -q gdm >/dev/null 2>&1; then
        installed_version=$(rpm -q gdm)
        echo "FAIL: gdm package is installed"
        echo "PROOF: $installed_version"
        return 1
    else
        echo "PASS: gdm package is not installed"
        echo "PROOF: rpm -q gdm returned no package found"
        return 0
    fi
}
# Function to fix
fix_gdm() {
    echo "Applying fix..."
    if rpm -q gdm >/dev/null 2>&1; then
        yum remove -y gdm
        echo " - Removed gdm package"
    else
        echo " - gdm package already not installed"
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GNOME Display Manager removed"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="