#!/usr/bin/env bash
# Script: 3.4.1.2.sh
# Item: 3.4.1.2 Ensure a single firewall configuration utility is in use (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.1.2.sh"
ITEM_NAME="3.4.1.2 Ensure a single firewall configuration utility is in use (Automated)"
DESCRIPTION="This remediation ensures only one firewall configuration utility is active."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to get detailed service status
get_service_details() {
    local service=$1
    local status=""
    
    if systemctl is-active "$service" >/dev/null 2>&1; then
        status="ACTIVE"
    else
        status="INACTIVE"
    fi
    
    if systemctl is-enabled "$service" >/dev/null 2>&1; then
        status="${status}/ENABLED"
    else
        status="${status}/DISABLED"
    fi
    
    if systemctl is-masked "$service" >/dev/null 2>&1; then
        status="${status}/MASKED"
    else
        status="${status}/NOT_MASKED"
    fi
    
    if rpm -q "${service%.service}" >/dev/null 2>&1; then
        status="${status}/INSTALLED"
    else
        status="${status}/NOT_INSTALLED"
    fi
    
    echo "$status"
}

# Function to check current status with detailed output
check_current_status() {
    echo "==================================================================="
    echo "DETAILED FIREWALL STATUS CHECK"
    echo "==================================================================="
    
    # Check all firewall services
    local services=("firewalld" "nftables" "iptables" "ip6tables")
    local active_services=()
    local enabled_services=()
    
    echo ""
    echo "SERVICE STATUS DETAILS:"
    echo "======================="
    
    for service in "${services[@]}"; do
        status=$(get_service_details "$service")
        printf "%-12s: %s\n" "$service" "$status"
        
        # Check if active
        if systemctl is-active "$service" >/dev/null 2>&1; then
            active_services+=("$service")
            
            # Get additional details for active services
            echo "    Process Info:"
            if pgrep -f "$service" >/dev/null; then
                pids=$(pgrep -f "$service" | tr '\n' ' ')
                echo "      PIDs: $pids"
            fi
            
            # Show service unit file location
            unit_file=$(systemctl show "$service" -p FragmentPath --value 2>/dev/null || echo "Not found")
            echo "      Unit File: $unit_file"
            
            # Show main executable
            exec_start=$(systemctl show "$service" -p ExecStart --value 2>/dev/null | head -1 || echo "Unknown")
            echo "      ExecStart: $exec_start"
        fi
        
        # Check if enabled but not active
        if systemctl is-enabled "$service" >/dev/null 2>&1 && ! systemctl is-active "$service" >/dev/null 2>&1; then
            enabled_services+=("$service")
        fi
    done
    
    echo ""
    echo "PACKAGE INFORMATION:"
    echo "===================="
    
    # Check package installation
    for pkg in "firewalld" "nftables" "iptables" "iptables-services"; do
        if rpm -q "$pkg" >/dev/null 2>&1; then
            version=$(rpm -q "$pkg" --queryformat '%{VERSION}-%{RELEASE}')
            echo "INSTALLED: $pkg (version: $version)"
        else
            echo "NOT INSTALLED: $pkg"
        fi
    done
    
    echo ""
    echo "ACTIVE FIREWALL RULES:"
    echo "======================"
    
    # Check current firewall rules for each active service
    for service in "${active_services[@]}"; do
        case "$service" in
            firewalld)
                echo "FirewallD Rules:"
                if command -v firewall-cmd >/dev/null 2>&1; then
                    echo "  Default Zone: $(firewall-cmd --get-default-zone 2>/dev/null || echo 'Unknown')"
                    echo "  Active Zones: $(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^ ' | tr '\n' ' ' || echo 'Unknown')"
                    echo "  Services: $(firewall-cmd --list-services 2>/dev/null | tr '\n' ' ' || echo 'None')"
                    echo "  Ports: $(firewall-cmd --list-ports 2>/dev/null | tr '\n' ' ' || echo 'None')"
                    echo "  Rich Rules: $(firewall-cmd --list-rich-rules 2>/dev/null | wc -l || echo '0')"
                fi
                ;;
            iptables)
                echo "IPTables Rules (IPv4):"
                if command -v iptables >/dev/null 2>&1; then
                    iptables -L -n 2>/dev/null | head -20 | sed 's/^/  /'
                    if [ $(iptables -L -n 2>/dev/null | wc -l) -gt 20 ]; then
                        echo "  ... (output truncated)"
                    fi
                fi
                ;;
            ip6tables)
                echo "IPTables Rules (IPv6):"
                if command -v ip6tables >/dev/null 2>&1; then
                    ip6tables -L -n 2>/dev/null | head -20 | sed 's/^/  /'
                    if [ $(ip6tables -L -n 2>/dev/null | wc -l) -gt 20 ]; then
                        echo "  ... (output truncated)"
                    fi
                fi
                ;;
            nftables)
                echo "NFTables Rules:"
                if command -v nft >/dev/null 2>&1; then
                    nft list ruleset 2>/dev/null | head -30 | sed 's/^/  /'
                    if [ $(nft list ruleset 2>/dev/null | wc -l) -gt 30 ]; then
                        echo "  ... (output truncated)"
                    fi
                fi
                ;;
        esac
        echo ""
    done
    
    echo "COMPLIANCE ASSESSMENT:"
    echo "======================"
    
    # Compliance check
    if [ ${#active_services[@]} -eq 0 ]; then
        echo "FAIL: No firewall service is active"
        echo "PROOF: No active firewall services detected"
        echo "IMPACT: System has no active firewall protection"
        return 1
    elif [ ${#active_services[@]} -gt 1 ]; then
        echo "FAIL: Multiple firewall services are active"
        echo "PROOF: Active services: ${active_services[*]}"
        echo "IMPACT: Conflicting firewall rules may cause network issues"
        return 1
    else
        echo "PASS: Single firewall configuration utility in use"
        echo "PROOF: Active firewall: ${active_services[0]}"
        echo "STATUS: ${active_services[0]} is properly configured as the sole firewall"
        
        # Check for potential conflicts (enabled but inactive services)
        if [ ${#enabled_services[@]} -gt 0 ]; then
            echo "WARNING: Other firewall services are enabled but inactive: ${enabled_services[*]}"
            echo "RECOMMENDATION: Disable or mask these services to prevent accidental activation"
        fi
        
        return 0
    fi
}

# Function to provide remediation options
show_remediation_options() {
    echo ""
    echo "==================================================================="
    echo "REMEDIATION OPTIONS"
    echo "==================================================================="
    echo ""
    echo "Based on the current state, choose one of the following options:"
    echo ""
    echo "OPTION 1 - Use FirewallD (Recommended for Oracle Linux 7):"
    echo "  # yum remove nftables iptables-services"
    echo "  # systemctl stop nftables iptables ip6tables"
    echo "  # systemctl mask nftables iptables ip6tables"
    echo "  # systemctl enable --now firewalld"
    echo ""
    echo "OPTION 2 - Use NFTables:"
    echo "  # yum remove firewalld iptables-services"
    echo "  # systemctl stop firewalld iptables ip6tables"
    echo "  # systemctl mask firewalld iptables ip6tables"
    echo "  # systemctl enable --now nftables"
    echo ""
    echo "OPTION 3 - Use IPTables:"
    echo "  # yum remove firewalld nftables"
    echo "  # systemctl stop firewalld nftables"
    echo "  # systemctl mask firewalld nftables"
    echo "  # systemctl enable --now iptables ip6tables"
    echo ""
    echo "Note: Choose the option that aligns with your organizational policy."
}

# Function to fix (using FirewallD as default for Oracle Linux 7)
fix_single_firewall_utility() {
    echo ""
    echo "==================================================================="
    echo "APPLYING REMEDIATION"
    echo "==================================================================="
    echo ""
    echo "Selected option: Use FirewallD (Oracle Linux 7 default)"
    echo ""
    
    # Stop conflicting services
    echo "Stopping conflicting firewall services..."
    for service in nftables iptables ip6tables; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo "  Stopping $service"
            systemctl stop "$service" 2>/dev/null || echo "    Warning: Could not stop $service"
        fi
    done
    
    # Mask conflicting services
    echo ""
    echo "Masking conflicting firewall services..."
    for service in nftables iptables ip6tables; do
        if ! systemctl is-masked "$service" >/dev/null 2>&1; then
            echo "  Masking $service"
            systemctl mask "$service" 2>/dev/null || echo "    Warning: Could not mask $service"
        fi
    done
    
    # Remove conflicting packages if no dependencies
    echo ""
    echo "Checking for conflicting packages..."
    for pkg in nftables iptables-services; do
        if rpm -q "$pkg" >/dev/null 2>&1; then
            echo "  Removing package: $pkg"
            yum remove -y "$pkg" 2>/dev/null || echo "    Note: $pkg may be required by other packages"
        fi
    done
    
    # Ensure firewalld is installed and running
    echo ""
    echo "Configuring FirewallD..."
    if ! rpm -q firewalld >/dev/null 2>&1; then
        echo "  Installing firewalld"
        yum install -y firewalld
    fi
    
    if ! systemctl is-active firewalld >/dev/null 2>&1; then
        echo "  Starting firewalld"
        systemctl enable --now firewalld 2>/dev/null || echo "    Warning: Could not start firewalld"
    fi
    
    echo ""
    echo "FirewallD configuration completed"
}

# Main execution
{
    echo "INITIAL STATUS CHECK:"
    if check_current_status; then
        echo ""
        echo "SYSTEM IS COMPLIANT - No remediation needed"
    else
        show_remediation_options
        echo ""
        read -p "Apply FirewallD remediation? (y/N): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            fix_single_firewall_utility
        else
            echo "Remediation cancelled by user"
            exit 0
        fi
    fi
    
    echo ""
    echo "==================================================================="
    echo "FINAL VERIFICATION"
    echo "==================================================================="
    
    if check_current_status; then
        echo ""
        echo "SUCCESS: Single firewall configuration utility properly configured"
    else
        echo ""
        echo "FAIL: Compliance issues remain after remediation"
        echo ""
        echo "NEXT STEPS:"
        echo "1. Review the remediation options above"
        echo "2. Manually configure the desired firewall utility"
        echo "3. Ensure only one firewall service is active"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="