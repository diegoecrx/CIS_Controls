#!/usr/bin/env bash
# Script: 3.4.3.1.sh
# Item: 3.4.3.1 Ensure nftables is installed (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.1.sh"
ITEM_NAME="3.4.3.1 Ensure nftables is installed (Automated)"
DESCRIPTION="This remediation ensures nftables is installed on the system."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status with detailed output
check_current_status() {
    echo "==================================================================="
    echo "CHECKING NFTABLES INSTALLATION STATUS"
    echo "==================================================================="
    echo ""
    
    echo "COMMAND: rpm -q nftables"
    # Check if nftables package is installed
    if rpm -q nftables >/dev/null 2>&1; then
        echo "OUTPUT: Package found"
        nftables_version=$(rpm -q nftables --queryformat '%{VERSION}-%{RELEASE}')
        nftables_arch=$(rpm -q nftables --queryformat '%{ARCH}')
        echo "PASS: nftables package is installed"
        echo "PROOF:"
        echo "  Package: nftables"
        echo "  Version: $nftables_version"
        echo "  Architecture: $nftables_arch"
        echo "  Installation Date: $(rpm -q nftables --queryformat '%{INSTALLTIME:date}' 2>/dev/null || echo 'Unknown')"
        
        # Check if nft command is available
        echo "COMMAND: which nft"
        if command -v nft >/dev/null 2>&1; then
            nft_version=$(nft --version 2>/dev/null | head -1 || echo "Unknown")
            echo "OUTPUT: Command found at $(which nft)"
            echo "  Command Available: Yes ($nft_version)"
        else
            echo "OUTPUT: Command not found"
            echo "  Command Available: No"
        fi
        return 0
    else
        echo "OUTPUT: Package not found"
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        
        # Check if package exists in repositories
        echo "REPOSITORY CHECK:"
        echo "COMMAND: yum list available nftables"
        if yum list available nftables >/dev/null 2>&1; then
            echo "OUTPUT: Package available in repositories"
            repo_info=$(yum list available nftables 2>/dev/null | grep nftables | awk '{print $1 " " $2}' || echo "Unknown version")
            echo "  Package available in repositories: Yes"
            echo "  Available package: $repo_info"
        else
            echo "OUTPUT: Package not available or cannot access repositories"
            echo "  Package available in repositories: No or cannot access repositories"
        fi
        return 1
    fi
}

# Function to check for alternative firewall packages
check_alternative_firewalls() {
    echo ""
    echo "ALTERNATIVE FIREWALL PACKAGES:"
    echo "=============================="
    
    local found_alternative=false
    
    # Check iptables
    echo "COMMAND: rpm -q iptables"
    if rpm -q iptables >/dev/null 2>&1; then
        iptables_version=$(rpm -q iptables --queryformat '%{VERSION}-%{RELEASE}')
        echo "OUTPUT: INSTALLED: iptables ($iptables_version)"
        found_alternative=true
    else
        echo "OUTPUT: NOT INSTALLED: iptables"
    fi
    
    # Check firewalld
    echo "COMMAND: rpm -q firewalld"
    if rpm -q firewalld >/dev/null 2>&1; then
        firewalld_version=$(rpm -q firewalld --queryformat '%{VERSION}-%{RELEASE}')
        echo "OUTPUT: INSTALLED: firewalld ($firewalld_version)"
        found_alternative=true
    else
        echo "OUTPUT: NOT INSTALLED: firewalld"
    fi
    
    if [ "$found_alternative" = true ]; then
        echo "NOTE: Alternative firewall packages are installed"
    fi
}

# Function to fix nftables installation
fix_nftables_installation() {
    echo ""
    echo "==================================================================="
    echo "APPLYING REMEDIATION"
    echo "==================================================================="
    echo ""
    
    echo "Installing nftables package as required by CIS benchmark..."
    echo ""
    
    # Clean yum cache to ensure fresh metadata
    echo "STEP 1: Cleaning yum cache"
    echo "COMMAND: yum clean all"
    yum clean all
    echo "OUTPUT: Yum cache cleaned"
    echo ""
    
    # Check repository status
    echo "STEP 2: Checking repository status"
    echo "COMMAND: yum repolist"
    yum repolist
    echo ""
    
    # Try to install nftables with detailed output
    echo "STEP 3: Installing nftables package"
    echo "COMMAND: yum install -y nftables"
    
    # Set a timeout but allow the user to see what's happening
    if timeout 300 yum install -y nftables; then
        echo ""
        echo "OUTPUT: nftables installation completed successfully"
        
        # Verify installation
        echo "STEP 4: Verifying installation"
        echo "COMMAND: rpm -q nftables"
        if rpm -q nftables >/dev/null 2>&1; then
            nftables_version=$(rpm -q nftables --queryformat '%{VERSION}-%{RELEASE}')
            echo "OUTPUT: Package verified - $nftables_version"
            return 0
        else
            echo "OUTPUT: Package verification failed"
            return 1
        fi
    else
        local install_status=$?
        echo ""
        echo "OUTPUT: nftables installation encountered issues (exit code: $install_status)"
        echo ""
        
        # Check if package was installed despite errors
        echo "COMMAND: rpm -q nftables"
        if rpm -q nftables >/dev/null 2>&1; then
            nftables_version=$(rpm -q nftables --queryformat '%{VERSION}-%{RELEASE}')
            echo "OUTPUT: Package appears to be installed despite errors - $nftables_version"
            return 0
        else
            echo "OUTPUT: Package not installed"
            echo ""
            echo "ERROR: nftables installation failed"
            echo ""
            echo "NETWORK DIAGNOSTICS:"
            echo "COMMAND: ping -c 2 8.8.8.8"
            if ping -c 2 -W 3 8.8.8.8 >/dev/null 2>&1; then
                echo "OUTPUT: Basic network connectivity: Available"
            else
                echo "OUTPUT: Basic network connectivity: Unavailable"
            fi
            
            echo "COMMAND: curl -I --connect-timeout 5 https://yum.oracle.com"
            if curl -I --connect-timeout 5 https://yum.oracle.com >/dev/null 2>&1; then
                echo "OUTPUT: Repository server access: Available"
            else
                echo "OUTPUT: Repository server access: Unavailable"
            fi
            return 1
        fi
    fi
}

# Main execution
{
    echo "INITIAL STATUS CHECK:"
    if check_current_status; then
        echo ""
        check_alternative_firewalls
        echo ""
        echo "SYSTEM IS COMPLIANT - No remediation needed"
    else
        check_alternative_firewalls
        echo ""
        
        # Force remediation without user input
        echo "Starting automated remediation as required by CIS benchmark..."
        if fix_nftables_installation; then
            echo ""
            echo "==================================================================="
            echo "FINAL VERIFICATION"
            echo "==================================================================="
            if check_current_status; then
                echo ""
                echo "SUCCESS: nftables properly installed and configured"
            else
                echo ""
                echo "FAIL: nftables installation verification failed"
                exit 1
            fi
        else
            echo ""
            echo "FAIL: nftables installation failed"
            exit 1
        fi
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="