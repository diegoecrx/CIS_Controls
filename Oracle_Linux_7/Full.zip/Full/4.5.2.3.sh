#!/bin/bash

# Enforce CIS 4.5.2.3 - Ensure system accounts are secured
echo "Enforcing CIS 4.5.2.3 - System accounts security configuration..."

# Get UID_MIN value from login.defs
UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
if [ -z "$UID_MIN" ]; then
    UID_MIN=1000
    echo "Using default UID_MIN: 1000"
else
    echo "Found UID_MIN: $UID_MIN"
fi

# Secure system accounts by setting shell to nologin
echo "Securing system accounts with nologin shell..."
awk -F: "(\$1!~/^(root|halt|sync|shutdown|nfsnobody)\$/ && (\$3<'$UID_MIN' || \$3 == 65534)) { print \$1 }" /etc/passwd | while read user; do
    if usermod -s "$(command -v nologin)" "$user" 2>/dev/null; then
        echo "Set nologin shell for system account: $user"
    else
        echo "WARNING: Could not set nologin for system account: $user"
    fi
done

# Lock accounts that have nologin shell
echo "Locking accounts with nologin shell..."
awk -F: '($7 ~ /(\/nologin|\/false)/) {print $1}' /etc/passwd | while read user; do
    if [ "$user" != "root" ]; then
        if usermod -L "$user" 2>/dev/null; then
            echo "Locked account: $user"
        else
            echo "WARNING: Could not lock account: $user"
        fi
    fi
done

# Verify configuration
echo "Verifying system accounts security..."

# Check for system accounts with invalid shells
echo "Checking for system accounts with invalid shells..."
INVALID_SHELLS=false
awk -F: "(\$1!~/^(root|halt|sync|shutdown|nfsnobody)\$/ && (\$3<'$UID_MIN' || \$3 == 65534) && \$7 !~ /(\/nologin|\/false)/) { print \$1 }" /etc/passwd | while read user; do
    echo "ERROR: System account $user has invalid shell"
    INVALID_SHELLS=true
done

if [ "$INVALID_SHELLS" = false ]; then
    echo "SUCCESS: All system accounts have nologin or false shell"
else
    echo "ERROR: Some system accounts have invalid shells"
    exit 1
fi

# Check for unlocked system accounts
echo "Checking for unlocked system accounts..."
UNLOCKED_ACCOUNTS=false
awk -F: "(\$1!~/^(root|halt|sync|shutdown|nfsnobody)\$/ && (\$3<'$UID_MIN' || \$3 == 65534)) { print \$1 }" /etc/passwd | while read user; do
    if passwd -S "$user" 2>/dev/null | grep -q "PS"; then
        echo "ERROR: System account $user is unlocked"
        UNLOCKED_ACCOUNTS=true
    fi
done

if [ "$UNLOCKED_ACCOUNTS" = false ]; then
    echo "SUCCESS: All system accounts are locked"
else
    echo "ERROR: Some system accounts are unlocked"
    exit 1
fi

# Count system accounts for verification
SYSTEM_ACCOUNT_COUNT=$(awk -F: "(\$1!~/^(root|halt|sync|shutdown|nfsnobody)\$/ && (\$3<'$UID_MIN' || \$3 == 65534)) { print \$1 }" /etc/passwd | wc -l)
echo "Processed $SYSTEM_ACCOUNT_COUNT system accounts"

echo "CIS 4.5.2.3 remediation completed successfully"
echo "All system accounts are now secured with nologin shell and locked"