#!/usr/bin/env bash
# Script: 3.4.3.8.sh
# Item: 3.4.3.8 Ensure nftables service is enabled and active (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.8.sh"
ITEM_NAME="3.4.3.8 Ensure nftables service is enabled and active (Automated)"
DESCRIPTION="This remediation ensures nftables service is enabled and active."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables service status..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    # Check if nftables service is masked
    if systemctl is-masked nftables.service >/dev/null 2>&1; then
        echo "FAIL: nftables service is masked"
        echo "PROOF: systemctl is-masked nftables.service shows masked"
        return 1
    fi
    
    # Check if nftables service is enabled
    if ! systemctl is-enabled nftables.service >/dev/null 2>&1; then
        echo "FAIL: nftables service is not enabled"
        echo "PROOF: systemctl is-enabled nftables.service shows disabled"
        return 1
    fi
    
    # Check if nftables service is running
    if ! systemctl is-active nftables.service >/dev/null 2>&1; then
        echo "FAIL: nftables service is not running"
        echo "PROOF: systemctl is-active nftables.service shows inactive"
        return 1
    fi
    
    echo "PASS: nftables service properly enabled and active"
    echo "PROOF: nftables.service is enabled and active"
    return 0
}
# Function to fix
fix_nftables_service() {
    echo "Applying fix..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package"
        yum install -y nftables
    fi
    
    # Unmask nftables service if masked
    if systemctl is-masked nftables.service >/dev/null 2>&1; then
        echo " - Unmasking nftables service"
        systemctl unmask nftables.service
    fi
    
    # Enable and start nftables service
    if ! systemctl is-enabled nftables.service >/dev/null 2>&1 || ! systemctl is-active nftables.service >/dev/null 2>&1; then
        echo " - Enabling and starting nftables service"
        systemctl --now enable nftables.service
    fi
    
    echo " - nftables service configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_service
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables service properly enabled and active"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="