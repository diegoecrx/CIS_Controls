#!/bin/bash

# Enforce CIS 4.4.2.3.2 - Ensure password history remember is configured
echo "Enforcing CIS 4.4.2.3.2 - Password history remember configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure password history remember for both files
for file in system-auth password-auth; do
    echo "Configuring password history in /etc/pam.d/${file}..."
    
    # Remove existing pam_pwhistory entries to avoid duplicates
    sed -i '/pam_pwhistory\.so/d' "/etc/pam.d/${file}"
    
    # Add pam_pwhistory with remember=24 after pam_pwquality in password section
    if grep -q "^password.*pam_pwquality\.so" "/etc/pam.d/${file}"; then
        # Insert pam_pwhistory after pam_pwquality
        sed -i '/^password.*pam_pwquality\.so/a password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' "/etc/pam.d/${file}"
    else
        # If pam_pwquality not found, add as second password entry
        if grep -q "^password" "/etc/pam.d/${file}"; then
            # Insert as second password entry
            sed -i '0,/^password.*/!{0,/^password.*/s/^password.*/password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok\n&/}' "/etc/pam.d/${file}"
        else
            # Add password section if it doesn't exist
            echo "password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok" >> "/etc/pam.d/${file}"
        fi
    fi
    
    # Ensure use_authtok is added to subsequent password lines (except pam_deny.so)
    sed -i '/^password.*pam_pwhistory\.so/!{/^password.*pam_deny\.so/!{/^password.*use_authtok/!s/^\(password.*\)$/\1 use_authtok/}}' "/etc/pam.d/${file}"
done

# Verify configuration
echo "Verifying password history configuration..."

# Check for required configuration in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if pam_pwhistory is configured with remember=24
    if grep -q "^password.*required.*pam_pwhistory\.so.*remember=24" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_pwhistory with remember=24 configured in ${file}"
    else
        echo "ERROR: pam_pwhistory not properly configured in ${file}"
        exit 1
    fi
    
    # Verify remember=24 parameter exists and is correct
    REMEMBER_VALUE=$(grep "pam_pwhistory\.so" "/etc/pam.d/${file}" | grep -o "remember=[0-9]*" | cut -d= -f2)
    if [ "$REMEMBER_VALUE" = "24" ]; then
        echo "SUCCESS: remember=24 correctly configured in ${file}"
    else
        echo "ERROR: remember value is $REMEMBER_VALUE, expected 24 in ${file}"
        exit 1
    fi
    
    # Verify enforce_for_root parameter exists
    if grep -q "pam_pwhistory\.so.*enforce_for_root" "/etc/pam.d/${file}"; then
        echo "SUCCESS: enforce_for_root configured in ${file}"
    else
        echo "ERROR: enforce_for_root not configured in ${file}"
        exit 1
    fi
    
    # Verify complete parameter set
    if grep -q "password.*required.*pam_pwhistory\.so.*remember=24.*enforce_for_root.*try_first_pass.*use_authtok" "/etc/pam.d/${file}"; then
        echo "SUCCESS: Complete pam_pwhistory configuration verified in ${file}"
    else
        echo "ERROR: Incomplete pam_pwhistory configuration in ${file}"
        exit 1
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.3.2 remediation completed successfully"
echo "Password history now remembers last 24 passwords for all users including root"