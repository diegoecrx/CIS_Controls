#!/usr/bin/env bash
# Script: 3.3.7.sh
# Item: 3.3.7 Ensure reverse path filtering is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.7.sh"
ITEM_NAME="3.3.7 Ensure reverse path filtering is enabled (Automated)"
DESCRIPTION="This remediation ensures reverse path filtering is enabled for IPv4."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking reverse path filtering configuration..."
    
    # Check current running values
    all_rp_filter=$(sysctl net.ipv4.conf.all.rp_filter 2>/dev/null | awk '{print $3}')
    default_rp_filter=$(sysctl net.ipv4.conf.default.rp_filter 2>/dev/null | awk '{print $3}')
    
    if [ "$all_rp_filter" != "1" ]; then
        echo "FAIL: net.ipv4.conf.all.rp_filter is not enabled"
        echo "PROOF: net.ipv4.conf.all.rp_filter = $all_rp_filter"
        return 1
    fi
    
    if [ "$default_rp_filter" != "1" ]; then
        echo "FAIL: net.ipv4.conf.default.rp_filter is not enabled"
        echo "PROOF: net.ipv4.conf.default.rp_filter = $default_rp_filter"
        return 1
    fi
    
    # Check configuration files for conflicting settings
    if grep -Pq '^\s*net\.ipv4\.conf\.all\.rp_filter\s*=\s*[^1]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.conf.all.rp_filter disabled in configuration"
        echo "PROOF: net.ipv4.conf.all.rp_filter set to non-1 in config files"
        return 1
    fi
    
    if grep -Pq '^\s*net\.ipv4\.conf\.default\.rp_filter\s*=\s*[^1]' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null; then
        echo "FAIL: net.ipv4.conf.default.rp_filter disabled in configuration"
        echo "PROOF: net.ipv4.conf.default.rp_filter set to non-1 in config files"
        return 1
    fi
    
    echo "PASS: Reverse path filtering properly enabled"
    echo "PROOF: Both all and default rp_filter set to 1"
    return 0
}
# Function to fix
fix_reverse_path_filtering() {
    echo "Applying fix..."
    
    # Remove any existing conflicting entries
    sed -i '/^\s*net\.ipv4\.conf\.all\.rp_filter\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    sed -i '/^\s*net\.ipv4\.conf\.default\.rp_filter\s*=/d' /etc/sysctl.conf 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.conf\.all\.rp_filter\s*=/d' {} \; 2>/dev/null || true
    find /etc/sysctl.d/ -name "*.conf" -exec sed -i '/^\s*net\.ipv4\.conf\.default\.rp_filter\s*=/d' {} \; 2>/dev/null || true
    
    # Add reverse path filtering configuration
    echo " - Configuring reverse path filtering"
    {
        echo "net.ipv4.conf.all.rp_filter = 1"
        echo "net.ipv4.conf.default.rp_filter = 1"
    } >> /etc/sysctl.d/60-netipv4_sysctl.conf
    
    # Set active kernel parameters
    sysctl -w net.ipv4.conf.all.rp_filter=1 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.rp_filter=1 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    echo " - Reverse path filtering configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_reverse_path_filtering
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Reverse path filtering properly enabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="