#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

sed -i '/net.ipv4.conf.all.accept_redirects/d' /etc/sysctl.conf
sed -i '/net.ipv4.conf.default.accept_redirects/d' /etc/sysctl.conf
sed -i '/net.ipv4.conf.all.accept_redirects/d' /etc/sysctl.d/*.conf
sed -i '/net.ipv4.conf.default.accept_redirects/d' /etc/sysctl.d/*.conf

echo "net.ipv4.conf.all.accept_redirects = 0" >> /etc/sysctl.conf
echo "net.ipv4.conf.default.accept_redirects = 0" >> /etc/sysctl.conf

sysctl -w net.ipv4.conf.all.accept_redirects=0
sysctl -w net.ipv4.conf.default.accept_redirects=0
sysctl -w net.ipv4.route.flush=1

if [[ -f /proc/net/if_inet6 ]]; then
    echo "net.ipv6.conf.all.accept_redirects = 0" >> /etc/sysctl.conf
    echo "net.ipv6.conf.default.accept_redirects = 0" >> /etc/sysctl.conf
    sysctl -w net.ipv6.conf.all.accept_redirects=0
    sysctl -w net.ipv6.conf.default.accept_redirects=0
    sysctl -w net.ipv6.route.flush=1
fi

sysctl net.ipv4.conf.all.accept_redirects
sysctl net.ipv4.conf.default.accept_redirects
grep "net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf
grep "net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf

if [[ -f /proc/net/if_inet6 ]]; then
    sysctl net.ipv6.conf.all.accept_redirects
    sysctl net.ipv6.conf.default.accept_redirects
    grep "net.ipv6.conf.all.accept_redirects" /etc/sysctl.conf
    grep "net.ipv6.conf.default.accept_redirects" /etc/sysctl.conf
fi

if sysctl net.ipv4.conf.all.accept_redirects | grep -q "net.ipv4.conf.all.accept_redirects = 0" && \
   sysctl net.ipv4.conf.default.accept_redirects | grep -q "net.ipv4.conf.default.accept_redirects = 0" && \
   grep -q "net.ipv4.conf.all.accept_redirects = 0" /etc/sysctl.conf && \
   grep -q "net.ipv4.conf.default.accept_redirects = 0" /etc/sysctl.conf && \
   (! [[ -f /proc/net/if_inet6 ]] || (sysctl net.ipv6.conf.all.accept_redirects | grep -q "net.ipv6.conf.all.accept_redirects = 0" && \
   sysctl net.ipv6.conf.default.accept_redirects | grep -q "net.ipv6.conf.default.accept_redirects = 0")); then
    echo "pass"
else
    echo "FAIL: ICMP redirects configuration failed"
    exit 1
fi