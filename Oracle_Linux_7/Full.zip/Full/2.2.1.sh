#!/usr/bin/env bash

# Script: 2.2.1.sh
# Item: 2.2.1 Ensure autofs services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.1.sh"
ITEM_NAME="2.2.1 Ensure autofs services are not in use (Automated)"
DESCRIPTION="This remediation ensures autofs services are not in use by removing or masking the service. FORCE VERSION - Comprehensive autofs removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_autofs_status
check_autofs_status() {
    echo "Checking autofs status..."
    
    autofs_installed=false
    autofs_running=false
    autofs_enabled=false
    autofs_masked=false
    
    # Check if autofs package is installed
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q autofs >/dev/null 2>&1; then
            autofs_installed=true
            echo " - autofs package is installed"
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l autofs >/dev/null 2>&1; then
            autofs_installed=true
            echo " - autofs package is installed"
        fi
    else
        # Fallback: check if autofs command exists
        if command -v automount >/dev/null 2>&1 || command -v autofs >/dev/null 2>&1; then
            autofs_installed=true
            echo " - autofs appears to be installed"
        fi
    fi
    
    # Check if autofs service is running
    if systemctl is-active autofs >/dev/null 2>&1; then
        autofs_running=true
        echo " - autofs service is running"
    else
        echo " - autofs service is not running"
    fi
    
    # Check if autofs service is enabled
    if systemctl is-enabled autofs >/dev/null 2>&1; then
        autofs_enabled=true
        echo " - autofs service is enabled"
    else
        echo " - autofs service is not enabled"
    fi
    
    # Check if autofs service is masked
    if systemctl is-enabled autofs 2>/dev/null | grep -q masked; then
        autofs_masked=true
        echo " - autofs service is masked"
    fi
    
    # Check for any active automounts
    if mount | grep -q autofs; then
        echo " - WARNING: Active autofs mounts detected"
        mount | grep autofs
    fi
    
    # Check for automount processes
    if pgrep automount >/dev/null 2>&1; then
        echo " - WARNING: automount processes running"
        pgrep automount
    fi
    
    return 0
}

# Function to stop_autofs_service
stop_autofs_service() {
    echo "Stopping autofs service..."
    
    # Stop automount processes first
    if pgrep automount >/dev/null 2>&1; then
        echo " - Stopping automount processes..."
        pkill -TERM automount 2>/dev/null || true
        sleep 2
        
        # Force kill if still running
        if pgrep automount >/dev/null 2>&1; then
            echo " - Force stopping automount processes..."
            pkill -KILL automount 2>/dev/null || true
            sleep 1
        fi
    fi
    
    # Stop autofs service using systemctl
    if systemctl is-active autofs >/dev/null 2>&1; then
        echo " - Stopping autofs.service..."
        if systemctl stop autofs 2>&1; then
            echo " - autofs.service stopped"
        else
            echo " - WARNING: Could not stop autofs.service via systemctl"
        fi
    fi
    
    # Additional stop methods for different service names
    for service in autofs automount; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service.service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Verify no autofs/automount processes are running
    if pgrep automount >/dev/null 2>&1; then
        echo " - CRITICAL: automount processes still running after stop attempts"
        return 1
    else
        echo " - No automount processes running"
    fi
    
    # Unmount any autofs mounts
    echo " - Unmounting autofs filesystems..."
    if mount | grep -q autofs; then
        mount_points=$(mount | grep autofs | awk '{print $3}')
        for point in $mount_points; do
            echo "   - Unmounting $point"
            umount "$point" 2>/dev/null || true
        done
    fi
    
    return 0
}

# Function to remove_autofs_package
remove_autofs_package() {
    local pkg_mgr="$1"
    
    echo "Removing autofs package..."
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove autofs..."
            if $pkg_mgr remove -y autofs 2>&1; then
                echo " - autofs package removed successfully"
                return 0
            else
                echo " - ERROR: Failed to remove autofs package with $pkg_mgr"
                return 1
            fi
            ;;
        apt)
            echo " - Using apt to remove autofs..."
            export DEBIAN_FRONTEND=noninteractive
            if apt-get remove -y autofs 2>&1; then
                echo " - autofs package removed successfully"
                return 0
            else
                echo " - ERROR: Failed to remove autofs package with apt"
                return 1
            fi
            ;;
        zypper)
            echo " - Using zypper to remove autofs..."
            if zypper --non-interactive remove autofs 2>&1; then
                echo " - autofs package removed successfully"
                return 0
            else
                echo " - ERROR: Failed to remove autofs package with zypper"
                return 1
            fi
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove autofs package"
            return 1
            ;;
    esac
}

# Function to mask_autofs_service
mask_autofs_service() {
    echo "Masking autofs service..."
    
    # Mask the main autofs service
    if systemctl mask autofs 2>&1; then
        echo " - autofs.service masked"
    else
        echo " - WARNING: Could not mask autofs.service"
    fi
    
    # Mask any related services
    for service in autofs automount; do
        if systemctl list-unit-files | grep -q "^$service.service"; then
            if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                systemctl mask "$service" 2>/dev/null || true
                echo " - $service.service masked"
            fi
        fi
    done
    
    return 0
}

# Function to disable_autofs_service
disable_autofs_service() {
    echo "Disabling autofs service..."
    
    # Disable the main autofs service
    if systemctl disable autofs 2>&1; then
        echo " - autofs.service disabled"
    else
        echo " - WARNING: Could not disable autofs.service"
    fi
    
    # Disable any related services
    for service in autofs automount; do
        if systemctl list-unit-files | grep -q "^$service.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                systemctl disable "$service" 2>/dev/null || true
                echo " - $service.service disabled"
            fi
        fi
    done
    
    return 0
}

# Function to cleanup_autofs_configs
cleanup_autofs_configs() {
    echo "Cleaning up autofs configuration files..."
    
    # List of autofs configuration files to remove or disable
    config_files=(
        "/etc/auto.master"
        "/etc/auto.misc"
        "/etc/auto.net"
        "/etc/auto.smb"
        "/etc/autofs.conf"
        "/etc/sysconfig/autofs"
        "/etc/default/autofs"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -f "$config_file" ]; then
            # Create backup and remove/disable
            backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
            cp "$config_file" "$backup_file"
            echo " - Backed up $config_file to $backup_file"
            
            # Comment out all active configurations
            sed -i 's/^/# REMEDIATED: /' "$config_file" 2>/dev/null || true
            echo " - Disabled configurations in $config_file"
        fi
    done
    
    # Remove any autofs related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -q autofs "$cron_file" 2>/dev/null; then
                sed -i '/autofs/d' "$cron_file" 2>/dev/null || true
                echo " - Removed autofs references from $cron_file"
            fi
        done
    fi
    
    return 0
}

# Function to verify_autofs_removal
verify_autofs_removal() {
    echo "Verifying autofs remediation..."
    
    verification_passed=true
    
    # Check if autofs package is installed
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q autofs >/dev/null 2>&1; then
            echo "FAIL: autofs package is still installed"
            verification_passed=false
        else
            echo "PASS: autofs package is not installed"
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l autofs >/dev/null 2>&1; then
            echo "FAIL: autofs package is still installed"
            verification_passed=false
        else
            echo "PASS: autofs package is not installed"
        fi
    else
        echo "INFO: Could not verify package removal (unknown package manager)"
    fi
    
    # Check if autofs service is running
    if systemctl is-active autofs >/dev/null 2>&1; then
        echo "FAIL: autofs service is running"
        verification_passed=false
    else
        echo "PASS: autofs service is not running"
    fi
    
    # Check if autofs service is enabled or masked
    if systemctl is-enabled autofs >/dev/null 2>&1; then
        if systemctl is-enabled autofs 2>/dev/null | grep -q masked; then
            echo "PASS: autofs service is masked"
        else
            echo "FAIL: autofs service is enabled"
            verification_passed=false
        fi
    else
        echo "PASS: autofs service is not enabled"
    fi
    
    # Check for automount processes
    if pgrep automount >/dev/null 2>&1; then
        echo "FAIL: automount processes are running"
        verification_passed=false
    else
        echo "PASS: No automount processes running"
    fi
    
    # Check for autofs mounts
    if mount | grep -q autofs; then
        echo "FAIL: Active autofs mounts detected"
        mount | grep autofs
        verification_passed=false
    else
        echo "PASS: No autofs mounts active"
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current autofs status..."
    echo ""

    # Check current autofs status
    check_autofs_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable autofs
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING AUTOFS"
    echo "==================================================================="
    echo ""

    # Stop autofs service first
    if ! stop_autofs_service; then
        echo " - WARNING: Some issues stopping autofs services"
    fi
    echo ""

    # Try to remove autofs package
    if remove_autofs_package "$pkg_mgr"; then
        echo " - Package removal successful"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking service instead"
        removal_method="masked"
        
        # Mask the service
        if mask_autofs_service; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        # Also disable the service
        disable_autofs_service
    fi
    echo ""

    # Cleanup configuration files
    cleanup_autofs_configs
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_autofs_removal; then
        echo ""
        echo "SUCCESS: autofs has been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ autofs package removed"
        else
            echo "✓ autofs service masked and disabled"
        fi
        echo "✓ autofs services stopped"
        echo "✓ automount processes terminated"
        echo "✓ autofs mounts unmounted"
        echo "✓ Configuration files disabled"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: autofs remediation may not be complete"
        echo "Some autofs components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining autofs processes: ps aux | grep automount"
        echo "2. Verify no autofs mounts: mount | grep autofs"
        echo "3. Ensure autofs is masked: systemctl is-enabled autofs"
        echo "4. Manually remove autofs package if needed"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Package installed: $(if command -v rpm >/dev/null && rpm -q autofs >/dev/null 2>&1; then echo "YES"; elif command -v dpkg >/dev/null && dpkg -l autofs >/dev/null 2>&1; then echo "YES"; else echo "NO"; fi)"
    echo "Service running: $(systemctl is-active autofs 2>/dev/null || echo "NO")"
    echo "Service enabled: $(systemctl is-enabled autofs 2>/dev/null || echo "NO")"
    echo "Processes running: $(pgrep automount 2>/dev/null | wc -l)"
    echo "Active mounts: $(mount | grep -c autofs 2>/dev/null || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="