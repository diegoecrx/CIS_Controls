#!/bin/bash

# Enforce CIS 4.2.10 - Ensure sshd HostbasedAuthentication is disabled
echo "Enforcing CIS 4.2.10 - SSH HostbasedAuthentication disabled..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Check if HostbasedAuthentication is already set
if grep -q "^HostbasedAuthentication" /etc/ssh/sshd_config; then
    # Update existing setting
    sed -i 's/^HostbasedAuthentication.*/HostbasedAuthentication no/' /etc/ssh/sshd_config
    echo "Updated existing HostbasedAuthentication setting to 'no'"
else
    # Add new setting
    echo "HostbasedAuthentication no" >> /etc/ssh/sshd_config
    echo "Added HostbasedAuthentication no to /etc/ssh/sshd_config"
fi

# Restart sshd service to apply changes
echo "Restarting sshd service..."
systemctl restart sshd

# Verify configuration
echo "Verifying HostbasedAuthentication configuration..."

# Check if setting is correctly configured in file
if grep -q "^HostbasedAuthentication no" /etc/ssh/sshd_config; then
    echo "SUCCESS: HostbasedAuthentication set to 'no' in /etc/ssh/sshd_config"
else
    echo "ERROR: HostbasedAuthentication not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.10 remediation completed successfully"