#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-MAC-policy.rules"

{
    echo "-w /etc/selinux -p wa -k MAC-policy"
    echo "-w /usr/share/selinux -p wa -k MAC-policy"
} > "$RULES_FILE"

augenrules --load

if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi