#!/bin/bash

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check if auditd.conf exists
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "auditd.conf not found" >&2
    exit 1
fi

# Get audit log directory from auditd.conf
log_dir=$(awk -F "=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs)
log_dir=$(dirname "$log_dir")

# Check if log directory exists
if [ ! -d "$log_dir" ]; then
    echo "Audit log directory $log_dir not found" >&2
    exit 1
fi

# Find and fix audit log files not owned by root
find "$log_dir" -type f ! -user root -exec chown root {} +

# Verify remediation
result=$(find "$log_dir" -type f ! -user root -exec stat -Lc "%n %U" {} + | awk '{print} END { if(NR==0) print "pass" ; else print "fail"}')

if [ "$result" = "pass" ]; then
    echo "Compliance achieved: All audit log files are owned by root"
else
    echo "Remediation incomplete. The following files are not owned by root:"
    find "$log_dir" -type f ! -user root -exec stat -Lc "%n %U" {} +
    exit 1
fi