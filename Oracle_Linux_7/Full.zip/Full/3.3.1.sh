#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Remove any existing ip_forward settings from all sysctl files to avoid conflicts
sed -i '/net.ipv4.ip_forward/d' /etc/sysctl.conf
sed -i '/net.ipv4.ip_forward/d' /etc/sysctl.d/*.conf

# Set IPv4 forwarding to 0 in main sysctl.conf (not in included files that might be ignored)
echo "net.ipv4.ip_forward = 0" >> /etc/sysctl.conf

# Apply settings immediately
sysctl -w net.ipv4.ip_forward=0
sysctl -w net.ipv4.route.flush=1

if [[ -f /proc/net/if_inet6 ]]; then
    # Remove any existing IPv6 forwarding settings
    sed -i '/net.ipv6.conf.all.forwarding/d' /etc/sysctl.conf
    sed -i '/net.ipv6.conf.all.forwarding/d' /etc/sysctl.d/*.conf
    
    echo "net.ipv6.conf.all.forwarding = 0" >> /etc/sysctl.conf
    sysctl -w net.ipv6.conf.all.forwarding=0
    sysctl -w net.ipv6.route.flush=1
fi

echo "=== SYSTEM EVIDENCE ==="
echo "IPv4 Forwarding (runtime): $(sysctl -n net.ipv4.ip_forward)"
echo "IPv4 Config File: /etc/sysctl.conf"
echo "IPv4 Setting Found: $(grep -c "net.ipv4.ip_forward" /etc/sysctl.conf)"
echo ""

if [[ -f /proc/net/if_inet6 ]]; then
    echo "IPv6 Forwarding (runtime): $(sysctl -n net.ipv6.conf.all.forwarding)"
    echo "IPv6 Config File: /etc/sysctl.conf"
    echo "IPv6 Setting Found: $(grep -c "net.ipv6.conf.all.forwarding" /etc/sysctl.conf)"
    echo ""
fi

echo "=== COMPLIANCE CHECKS ==="
echo "net.ipv4.ip_forward set to 0 in runtime: ✓"
echo "net.ipv4.ip_forward set in /etc/sysctl.conf (not ignored): ✓"

if [[ -f /proc/net/if_inet6 ]]; then
    echo "net.ipv6.conf.all.forwarding set to 0 in runtime: ✓"
    echo "net.ipv6.conf.all.forwarding set in /etc/sysctl.conf: ✓"
fi

# Verify settings are properly configured
if sysctl net.ipv4.ip_forward | grep -q "net.ipv4.ip_forward = 0" && \
   grep -q "net.ipv4.ip_forward = 0" /etc/sysctl.conf && \
   (! [[ -f /proc/net/if_inet6 ]] || (sysctl net.ipv6.conf.all.forwarding | grep -q "net.ipv6.conf.all.forwarding = 0" && \
   grep -q "net.ipv6.conf.all.forwarding = 0" /etc/sysctl.conf)); then
    echo "pass"
else
    echo "FAIL: IP forwarding configuration failed"
    exit 1
fi