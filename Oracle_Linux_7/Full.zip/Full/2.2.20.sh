#!/usr/bin/env bash
# Script: 2.2.20.sh
# Item: 2.2.20 Ensure X window server services are not in use (Automated)
# Profile Applicability: Level 2 - Server
# Description: This remediation ensures X Windows Server is not in use by removing the xorg-x11-server-common package if not required and approved by local policy. FORCE VERSION - Comprehensive X11 server removal.

set -euo pipefail

SCRIPT_NAME="2.2.20.sh"
ITEM_NAME="2.2.20 Ensure X window server services are not in use (Automated)"
DESCRIPTION="This remediation ensures X Windows Server is not in use by removing the xorg-x11-server-common package if not required and approved by local policy. FORCE VERSION - Comprehensive X11 server removal."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="

echo

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_xwin_status() {
  echo "Checking for X11 server packages..."
  if rpm -q xorg-x11-server-common >/dev/null 2>&1; then
    echo " - xorg-x11-server-common package is installed."
  else
    echo " - xorg-x11-server-common package is not installed."
  fi
}

remove_xwin_package() {
  local pkg_mgr="$1"
  echo "Removing xorg-x11-server-common package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y xorg-x11-server-common 2>/dev/null || echo " - WARNING: Could not remove xorg-x11-server-common (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

verify_xwin_removal() {
  echo "Verifying X Windows Server remediation..."
  if rpm -q xorg-x11-server-common >/dev/null 2>&1; then
    echo "FAIL: xorg-x11-server-common package is still installed."
    return 1
  else
    echo "PASS: xorg-x11-server-common package is not installed."
    return 0
  fi
}

check_xwin_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""
remove_xwin_package "$PKG_MGR"
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
verify_xwin_removal
result=$?
if [ $result -eq 0 ]; then
  echo "SUCCESS: X Windows Server package has been successfully removed."
else
  echo "WARNING: X Windows Server remediation may not be complete. Manual review recommended."
  echo "1. Verify package removal: rpm -q xorg-x11-server-common"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
