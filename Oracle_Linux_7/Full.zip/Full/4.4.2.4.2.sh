#!/bin/bash

# Enforce CIS 4.4.2.4.2 - Ensure pam_unix does not include remember
echo "Enforcing CIS 4.4.2.4.2 - Remove remember from pam_unix configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Remove remember from pam_unix lines in both files
for file in system-auth password-auth; do
    echo "Removing remember from pam_unix in /etc/pam.d/${file}..."
    
    # Remove remember from all pam_unix.so lines
    sed -i '/pam_unix\.so/s/\sremember\b//g' "/etc/pam.d/${file}"
    sed -i '/pam_unix\.so/s/\sremember=[^[:space:]]*//g' "/etc/pam.d/${file}"
    
    echo "Removed remember parameters from pam_unix.so lines in ${file}"
done

# Verify configuration
echo "Verifying remember removal..."

# Check that remember is not present in pam_unix lines in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if any pam_unix lines still contain remember
    if grep -q "pam_unix\.so.*remember" "/etc/pam.d/${file}"; then
        echo "ERROR: remember still found in pam_unix lines in ${file}"
        exit 1
    else
        echo "SUCCESS: No remember found in pam_unix lines in ${file}"
    fi
    
    # Verify pam_unix lines still exist and are functional
    if grep -q "^auth.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: auth pam_unix.so line present in ${file}"
    else
        echo "WARNING: auth pam_unix.so line not found in ${file}"
    fi
    
    if grep -q "^account.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: account pam_unix.so line present in ${file}"
    else
        echo "WARNING: account pam_unix.so line not found in ${file}"
    fi
    
    if grep -q "^password.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: password pam_unix.so line present in ${file}"
    else
        echo "WARNING: password pam_unix.so line not found in ${file}"
    fi
    
    if grep -q "^session.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: session pam_unix.so line present in ${file}"
    else
        echo "WARNING: session pam_unix.so line not found in ${file}"
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.4.2 remediation completed successfully"
echo "remember parameter has been removed from all pam_unix.so lines"