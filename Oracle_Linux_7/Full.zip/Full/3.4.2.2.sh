#!/bin/bash

# Enforce CIS 3.4.2.2 - Ensure firewalld service enabled and running
echo "Enforcing CIS 3.4.2.2 - firewalld service enabled and running..."

# Unmask firewalld service first
echo "Unmasking firewalld service..."
systemctl unmask firewalld

# Enable and start firewalld
echo "Enabling and starting firewalld service..."
systemctl enable firewalld
systemctl start firewalld

# Verify configuration
echo "Verifying firewalld configuration..."

# Check if firewalld is enabled
if systemctl is-enabled firewalld > /dev/null 2>&1; then
    echo "SUCCESS: firewalld service is enabled"
else
    echo "ERROR: firewalld service is not enabled"
    exit 1
fi

# Check if firewalld is running
if systemctl is-active firewalld > /dev/null 2>&1; then
    echo "SUCCESS: firewalld service is running"
else
    echo "ERROR: firewalld service is not running"
    exit 1
fi

# Check firewall-cmd state (run as root to avoid authorization issues)
if firewall-cmd --state > /dev/null 2>&1; then
    echo "SUCCESS: firewalld is active and responding"
else
    echo "ERROR: firewalld is not responding properly"
    exit 1
fi

echo "CIS 3.4.2.2 remediation completed successfully"