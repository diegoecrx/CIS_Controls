#!/usr/bin/env bash
# Script: 6.1.12.sh
# Item: 6.1.12 Ensure no unowned or ungrouped files or directories exist (Automated)
set -euo pipefail
SCRIPT_NAME="6.1.12.sh"
ITEM_NAME="6.1.12 Ensure no unowned or ungrouped files or directories exist (Automated)"
DESCRIPTION="This remediation ensures no unowned or ungrouped files or directories exist on the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for unowned or ungrouped files and directories..."
    
    # Search for files with no owner (nouser)
    echo " - Searching for files with no owner..."
    unowned_files=()
    while IFS= read -r -d '' file; do
        unowned_files+=("$file")
    done < <(find / -xdev -nouser -print0 2>/dev/null)
    
    # Search for files with no group (nogroup)
    echo " - Searching for files with no group..."
    ungrouped_files=()
    while IFS= read -r -d '' file; do
        ungrouped_files+=("$file")
    done < <(find / -xdev -nogroup -print0 2>/dev/null)
    
    if [ ${#unowned_files[@]} -gt 0 ] || [ ${#ungrouped_files[@]} -gt 0 ]; then
        echo "FAIL: Unowned or ungrouped files/directories found"
        
        if [ ${#unowned_files[@]} -gt 0 ]; then
            echo "PROOF: Files with no owner (first 10):"
            for i in "${!unowned_files[@]}"; do
                if [ $i -lt 10 ]; then
                    echo "  ${unowned_files[$i]}"
                fi
            done
            if [ ${#unowned_files[@]} -gt 10 ]; then
                echo "  ... and $((${#unowned_files[@]} - 10)) more files"
            fi
        fi
        
        if [ ${#ungrouped_files[@]} -gt 0 ]; then
            echo "PROOF: Files with no group (first 10):"
            for i in "${!ungrouped_files[@]}"; do
                if [ $i -lt 10 ]; then
                    echo "  ${ungrouped_files[$i]}"
                fi
            done
            if [ ${#ungrouped_files[@]} -gt 10 ]; then
                echo "  ... and $((${#ungrouped_files[@]} - 10)) more files"
            fi
        fi
        
        return 1
    fi
    
    echo "PASS: No unowned or ungrouped files or directories found"
    echo "PROOF: System scan completed with no orphaned files detected"
    return 0
}
# Function to fix
fix_unowned_ungrouped_files() {
    echo "Applying fix..."
    
    echo " - Scanning system for unowned and ungrouped files..."
    
    # Find and fix files with no owner
    echo " - Processing files with no owner..."
    unowned_count=0
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            echo " - Setting owner to root for: $file"
            chown root "$file" 2>/dev/null || echo " - Warning: Could not change owner of $file"
            ((unowned_count++))
        fi
    done < <(find / -xdev -nouser -print0 2>/dev/null)
    
    # Find and fix files with no group
    echo " - Processing files with no group..."
    ungrouped_count=0
    while IFS= read -r -d '' file; do
        if [ -e "$file" ]; then
            echo " - Setting group to root for: $file"
            chgrp root "$file" 2>/dev/null || echo " - Warning: Could not change group of $file"
            ((ungrouped_count++))
        fi
    done < <(find / -xdev -nogroup -print0 2>/dev/null)
    
    if [ $unowned_count -eq 0 ] && [ $ungrouped_count -eq 0 ]; then
        echo " - No unowned or ungrouped files found"
    else
        echo " - Fixed ownership for $unowned_count unowned files"
        echo " - Fixed group ownership for $ungrouped_count ungrouped files"
    fi
    
    echo " - Unowned/ungrouped files remediation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_unowned_ungrouped_files
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: No unowned or ungrouped files or directories exist"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="