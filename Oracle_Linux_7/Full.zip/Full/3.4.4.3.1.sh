#!/usr/bin/env bash
# Script: 3.4.4.3.1.sh
# Item: 3.4.4.3.1 Ensure ip6tables loopback traffic is configured (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.3.1.sh"
ITEM_NAME="3.4.4.3.1 Ensure ip6tables loopback traffic is configured (Automated)"
DESCRIPTION="This remediation ensures ip6tables loopback traffic is properly configured for IPv6."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ip6tables loopback traffic configuration..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check for IPv6 loopback input accept rule
    if ! ip6tables -L INPUT -v -n | grep -q "ACCEPT.*lo.*::/0.*::/0"; then
        echo "FAIL: IPv6 loopback input accept rule not found"
        echo "PROOF: No 'INPUT -i lo -j ACCEPT' rule found in ip6tables"
        return 1
    fi
    
    # Check for IPv6 loopback output accept rule
    if ! ip6tables -L OUTPUT -v -n | grep -q "ACCEPT.*lo.*::/0.*::/0"; then
        echo "FAIL: IPv6 loopback output accept rule not found"
        echo "PROOF: No 'OUTPUT -o lo -j ACCEPT' rule found in ip6tables"
        return 1
    fi
    
    # Check for IPv6 loopback source address drop rule
    if ! ip6tables -L INPUT -v -n | grep -q "DROP.*::1"; then
        echo "FAIL: IPv6 loopback source address drop rule not found"
        echo "PROOF: No 'INPUT -s ::1 -j DROP' rule found in ip6tables"
        return 1
    fi
    
    echo "PASS: ip6tables loopback traffic properly configured"
    echo "PROOF: All required IPv6 loopback rules are present"
    return 0
}
# Function to fix
fix_ip6tables_loopback() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Configuring ip6tables loopback rules"
    
    # Add IPv6 loopback input accept rule if not present
    if ! ip6tables -L INPUT -v -n | grep -q "ACCEPT.*lo.*::/0.*::/0"; then
        echo " - Adding IPv6 loopback input accept rule"
        ip6tables -A INPUT -i lo -j ACCEPT
    fi
    
    # Add IPv6 loopback output accept rule if not present
    if ! ip6tables -L OUTPUT -v -n | grep -q "ACCEPT.*lo.*::/0.*::/0"; then
        echo " - Adding IPv6 loopback output accept rule"
        ip6tables -A OUTPUT -o lo -j ACCEPT
    fi
    
    # Add IPv6 loopback source address drop rule if not present
    if ! ip6tables -L INPUT -v -n | grep -q "DROP.*::1"; then
        echo " - Adding IPv6 loopback source address drop rule"
        ip6tables -A INPUT -s ::1 -j DROP
    fi
    
    # Save ip6tables rules to make them persistent
    echo " - Saving ip6tables rules"
    service ip6tables save 2>/dev/null || ip6tables-save > /etc/sysconfig/ip6tables
    
    # Ensure ip6tables service is enabled
    if ! systemctl is-enabled ip6tables >/dev/null 2>&1; then
        echo " - Enabling ip6tables service"
        systemctl enable ip6tables
    fi
    
    echo " - ip6tables loopback configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip6tables_loopback
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ip6tables loopback traffic properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="