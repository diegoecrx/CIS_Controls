#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Get GPG keys with detailed information
echo "Checking configured GPG keys:"
GPG_KEYS_OUTPUT=$(rpm -q gpg-pubkey --queryformat '%{name}-%{version}-%{release} --> %{summary}\n' 2>/dev/null)
GPG_KEY_COUNT=$(echo "$GPG_KEYS_OUTPUT" | grep -c '^gpg-pubkey')

# Display evidence
echo "$GPG_KEYS_OUTPUT"

# Verification and result
if [[ $GPG_KEY_COUNT -eq 0 ]]; then
    echo "FAIL: No GPG keys configured"
    echo "EVIDENCE: rpm -q gpg-pubkey returned no keys"
    exit 1
else
    echo "PASS: $GPG_KEY_COUNT GPG key(s) configured"
    echo "EVIDENCE: Found $GPG_KEY_COUNT GPG key(s) in RPM database"
    exit 0
fi