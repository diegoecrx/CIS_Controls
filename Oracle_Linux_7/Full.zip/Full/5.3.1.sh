#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Force install AIDE and capture output
echo "Installing AIDE package..."
if ! yum install -y aide 2>&1; then
    echo "FAIL: AIDE installation failed - yum command returned error"
    exit 1
fi

# Verify AIDE package is installed
echo "Verifying AIDE installation..."
if ! rpm -q aide 2>&1; then
    echo "FAIL: AIDE package not found after installation"
    exit 1
fi

# Initialize AIDE database
echo "Initializing AIDE database..."
if ! aide --init 2>&1; then
    echo "FAIL: AIDE database initialization failed"
    exit 1
fi

# Move the new database to active database
echo "Activating AIDE database..."
if [ -f /var/lib/aide/aide.db.new.gz ]; then
    if ! mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz 2>&1; then
        echo "FAIL: Failed to activate AIDE database"
        exit 1
    fi
else
    echo "FAIL: AIDE database file not found: /var/lib/aide/aide.db.new.gz"
    exit 1
fi

# Final verification with evidence
echo "Final verification with evidence:"
echo "AIDE package status: $(rpm -q aide)"
echo "AIDE database file: $(ls -la /var/lib/aide/aide.db.gz 2>/dev/null || echo 'NOT FOUND')"
echo "AIDE version: $(aide --version 2>/dev/null || echo 'VERSION CHECK FAILED')"

# Compliance check
if rpm -q aide >/dev/null 2>&1 && [ -f /var/lib/aide/aide.db.gz ]; then
    echo "pass"
else
    echo "FAIL: AIDE installation verification failed"
    exit 1
fi