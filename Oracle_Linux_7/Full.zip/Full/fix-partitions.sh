#!/bin/bash
# fix-audit-overflow.sh - Comprehensive audit system fix

set -euo pipefail

echo "=== Fixing Audit System Overflow Issues ==="
echo "Start time: $(date)"
echo

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Function to check current audit status
check_audit_status() {
    echo "=== Current Audit Status ==="
    echo "Kernel backlog limit: $(cat /proc/sys/kernel/audit_backlog_limit 2>/dev/null || echo 'N/A')"
    echo "Auditd status:"
    systemctl status auditd --no-pager -l | head -20
    echo ""
    echo "Current audit rules count: $(auditctl -l 2>/dev/null | wc -l)"
    echo ""
    
    # Check for recent overflow errors
    echo "Recent audit errors in kernel log:"
    dmesg | tail -50 | grep -i audit | tail -10
    echo ""
}

# Function to tune audit parameters
tune_audit_parameters() {
    echo "=== Tuning Audit Parameters ==="
    
    # Backup current sysctl settings
    cp /etc/sysctl.conf /etc/sysctl.conf.backup.$(date +%s)
    
    # Increase kernel audit backlog limit
    echo "Increasing kernel audit backlog limit to 16384..."
    echo "kernel.audit_backlog_limit = 16384" >> /etc/sysctl.conf
    echo 16384 > /proc/sys/kernel/audit_backlog_limit
    
    # Increase other related kernel parameters
    echo "Increasing other kernel parameters..."
    echo "net.core.rmem_max = 16777216" >> /etc/sysctl.conf
    echo "net.core.wmem_max = 16777216" >> /etc/sysctl.conf
    echo "net.core.rmem_default = 16777216" >> /etc/sysctl.conf
    echo "net.core.wmem_default = 16777216" >> /etc/sysctl.conf
    
    # Apply sysctl changes
    sysctl -p >/dev/null 2>&1
    echo "Kernel parameters tuned"
    echo ""
}

# Function to configure auditd for high load
configure_auditd_high_load() {
    echo "=== Configuring auditd for High Load ==="
    
    # Backup current auditd config
    cp /etc/audit/auditd.conf /etc/audit/auditd.conf.backup.$(date +%s)
    
    # Configure auditd for better performance
    cat > /etc/audit/auditd.conf << 'EOF'
log_file = /var/log/audit/audit.log
log_format = RAW
log_group = root
priority_boost = 4
flush = INCREMENTAL_ASYNC
freq = 50
num_logs = 10
disp_qos = lossy
dispatcher = /sbin/audispd
name_format = NONE
max_log_file = 100
max_log_file_action = ROTATE
space_left = 250
space_left_action = SYSLOG
action_mail_acct = root
admin_space_left = 100
admin_space_left_action = SUSPEND
disk_full_action = SUSPEND
disk_error_action = SUSPEND
tcp_listen_queue = 10
tcp_max_per_addr = 5
tcp_client_max_idle = 600
enable_krb5 = no
EOF
    
    # Set rate limiting in audit rules
    echo "Setting audit rate limiting..."
    
    # Create rate limiting rules
    cat > /etc/audit/rules.d/00-rate-limit.rules << 'EOF'
# Set buffer size and rate limiting
-b 16384
-f 1
-r 2000
EOF
    
    # Load new rules
    augenrules --load >/dev/null 2>&1
    echo "Auditd configured for high load"
    echo ""
}

# Function to optimize audit rules
optimize_audit_rules() {
    echo "=== Optimizing Audit Rules ==="
    
    # Backup current rules
    cp -r /etc/audit/rules.d /etc/audit/rules.d.backup.$(date +%s)
    
    # Remove duplicate rules
    echo "Removing duplicate audit rules..."
    for rule_file in /etc/audit/rules.d/*.rules; do
        if [ -f "$rule_file" ]; then
            # Sort and remove duplicates
            sort "$rule_file" | uniq > "${rule_file}.tmp"
            mv "${rule_file}.tmp" "$rule_file"
        fi
    done
    
    # Combine similar rules where possible
    echo "Combining similar rules..."
    
    # Create optimized rules
    cat > /etc/audit/rules.d/10-optimized.rules << 'EOF'
## First rule - delete all
-D

## Buffer and rate settings
-b 16384
-f 1
-r 2000

## Time changes
-a always,exit -F arch=b64 -S adjtimex,settimeofday,clock_settime -k time-change
-w /etc/localtime -p wa -k time-change

## Identity changes
-w /etc/group -p wa -k identity
-w /etc/passwd -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/security/opasswd -p wa -k identity

## Network configuration
-w /etc/hosts -p wa -k hosts
-w /etc/sysconfig/network -p wa -k network
-w /etc/sysconfig/network-scripts/ -p wa -k network

## Kernel modules
-w /sbin/insmod -p x -k modules
-w /sbin/rmmod -p x -k modules
-w /sbin/modprobe -p x -k modules
-a always,exit -F arch=b64 -S init_module,delete_module -k modules

## System administration
-w /etc/sudoers -p wa -k scope
-w /etc/sudoers.d -p wa -k scope
-w /var/log/sudo.log -p wa -k sudo-log

## Critical binaries
-w /usr/bin/passwd -p x -k passwd-mod
-w /usr/sbin/groupadd -p x -k group-mod
-w /usr/sbin/groupmod -p x -k group-mod
-w /usr/sbin/useradd -p x -k user-mod
-w /usr/sbin/usermod -p x -k user-mod
EOF
    
    # Remove old rule files except our optimized ones
    for rule_file in /etc/audit/rules.d/*.rules; do
        if [ "$rule_file" != "/etc/audit/rules.d/00-rate-limit.rules" ] && \
           [ "$rule_file" != "/etc/audit/rules.d/10-optimized.rules" ]; then
            rm -f "$rule_file"
        fi
    done
    
    # Load optimized rules
    augenrules --load >/dev/null 2>&1
    echo "Audit rules optimized"
    echo ""
}

# Function to monitor and test audit system
test_audit_system() {
    echo "=== Testing Audit System ==="
    
    # Restart auditd
    echo "Restarting auditd service..."
    systemctl restart auditd 2>/dev/null || service auditd restart
    
    # Wait for service to stabilize
    sleep 5
    
    # Check if auditd is running
    if systemctl is-active auditd >/dev/null 2>&1; then
        echo "✓ Auditd is running"
    else
        echo "✗ Auditd failed to start"
        return 1
    fi
    
    # Generate some test audit events
    echo "Generating test audit events..."
    for i in {1..10}; do
        logger "Test audit message $i from audit fix script"
        sleep 0.1
    done
    
    # Check if events are being logged
    echo "Checking audit log..."
    if tail -5 /var/log/audit/audit.log 2>/dev/null | grep -q "Test audit message"; then
        echo "✓ Audit logging is working"
    else
        echo "⚠ Audit logging might have issues"
    fi
    
    # Check current settings
    echo ""
    echo "Current audit settings:"
    auditctl -s 2>/dev/null || echo "Cannot get audit status"
    
    echo ""
}

# Function to create monitoring script
create_monitoring_script() {
    echo "=== Creating Audit Monitoring Script ==="
    
    cat > /usr/local/bin/monitor-audit.sh << 'EOF'
#!/bin/bash
# Audit System Monitor

echo "=== Audit System Monitor ==="
echo "Time: $(date)"
echo

# Check kernel backlog
echo "Kernel backlog limit: $(cat /proc/sys/kernel/audit_backlog_limit 2>/dev/null || echo 'N/A')"

# Check auditd status
echo "Auditd status: $(systemctl is-active auditd 2>/dev/null || echo 'unknown')"

# Check for overflow errors
echo "Recent audit errors:"
dmesg | tail -20 | grep -i "audit\|kauditd" | tail -5

# Check audit queue
echo ""
echo "Audit queue status:"
auditctl -s 2>/dev/null | grep -E "backlog|lost|rate"

# Check log file size
echo ""
echo "Audit log size:"
ls -lh /var/log/audit/audit.log 2>/dev/null || echo "Audit log not found"

# Count recent audit events
echo ""
echo "Audit events in last 5 minutes:"
if [ -f "/var/log/audit/audit.log" ]; then
    grep -c "^type=" /var/log/audit/audit.log 2>/dev/null | \
        awk '{print "Total events: " $1}'
    echo "Events in last 5 min: $(find /var/log/audit -name "audit.log" -mmin -5 -exec grep -c "^type=" {} \; 2>/dev/null || echo "N/A")"
fi

echo ""
EOF
    
    chmod +x /usr/local/bin/monitor-audit.sh
    echo "Monitoring script created: /usr/local/bin/monitor-audit.sh"
    echo "Run it with: monitor-audit.sh"
    echo ""
}

# Main execution
main() {
    echo "Starting comprehensive audit system fix..."
    echo
    
    # Step 1: Check current status
    check_audit_status
    
    # Step 2: Tune kernel parameters
    tune_audit_parameters
    
    # Step 3: Configure auditd
    configure_auditd_high_load
    
    # Step 4: Optimize rules
    optimize_audit_rules
    
    # Step 5: Test the system
    test_audit_system
    
    # Step 6: Create monitoring script
    create_monitoring_script
    
    echo "=== Fix Complete ==="
    echo ""
    echo "Summary of changes:"
    echo "1. Increased kernel audit backlog to 16384"
    echo "2. Configured auditd for high load"
    echo "3. Optimized and deduplicated audit rules"
    echo "4. Set audit rate limit to 2000 events/sec"
    echo "5. Created monitoring script"
    echo ""
    echo "To monitor audit system:"
    echo "  monitor-audit.sh"
    echo ""
    echo "If issues persist, consider:"
    echo "1. Checking disk space in /var/log/audit"
    echo "2. Reducing audit rules further if needed"
    echo "3. Increasing /var/log/audit partition size"
    echo ""
}

# Run main function
main

echo "Script completed at: $(date)"