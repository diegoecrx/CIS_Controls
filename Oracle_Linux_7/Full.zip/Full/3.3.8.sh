#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

sed -i '/net.ipv4.conf.all.accept_source_route/d' /etc/sysctl.conf
sed -i '/net.ipv4.conf.default.accept_source_route/d' /etc/sysctl.conf
sed -i '/net.ipv4.conf.all.accept_source_route/d' /etc/sysctl.d/*.conf
sed -i '/net.ipv4.conf.default.accept_source_route/d' /etc/sysctl.d/*.conf

echo "net.ipv4.conf.all.accept_source_route = 0" >> /etc/sysctl.conf
echo "net.ipv4.conf.default.accept_source_route = 0" >> /etc/sysctl.conf

sysctl -w net.ipv4.conf.all.accept_source_route=0
sysctl -w net.ipv4.conf.default.accept_source_route=0
sysctl -w net.ipv4.route.flush=1

if [[ -f /proc/net/if_inet6 ]]; then
    sed -i '/net.ipv6.conf.all.accept_source_route/d' /etc/sysctl.conf
    sed -i '/net.ipv6.conf.default.accept_source_route/d' /etc/sysctl.conf
    sed -i '/net.ipv6.conf.all.accept_source_route/d' /etc/sysctl.d/*.conf
    sed -i '/net.ipv6.conf.default.accept_source_route/d' /etc/sysctl.d/*.conf

    echo "net.ipv6.conf.all.accept_source_route = 0" >> /etc/sysctl.conf
    echo "net.ipv6.conf.default.accept_source_route = 0" >> /etc/sysctl.conf

    sysctl -w net.ipv6.conf.all.accept_source_route=0
    sysctl -w net.ipv6.conf.default.accept_source_route=0
    sysctl -w net.ipv6.route.flush=1
fi

sysctl net.ipv4.conf.all.accept_source_route
sysctl net.ipv4.conf.default.accept_source_route
grep "net.ipv4.conf.all.accept_source_route" /etc/sysctl.conf
grep "net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf

if [[ -f /proc/net/if_inet6 ]]; then
    sysctl net.ipv6.conf.all.accept_source_route
    sysctl net.ipv6.conf.default.accept_source_route
    grep "net.ipv6.conf.all.accept_source_route" /etc/sysctl.conf
    grep "net.ipv6.conf.default.accept_source_route" /etc/sysctl.conf
fi

if sysctl net.ipv4.conf.all.accept_source_route | grep -q "net.ipv4.conf.all.accept_source_route = 0" && \
   sysctl net.ipv4.conf.default.accept_source_route | grep -q "net.ipv4.conf.default.accept_source_route = 0" && \
   grep -q "net.ipv4.conf.all.accept_source_route = 0" /etc/sysctl.conf && \
   grep -q "net.ipv4.conf.default.accept_source_route = 0" /etc/sysctl.conf && \
   (! [[ -f /proc/net/if_inet6 ]] || (sysctl net.ipv6.conf.all.accept_source_route | grep -q "net.ipv6.conf.all.accept_source_route = 0" && \
   sysctl net.ipv6.conf.default.accept_source_route | grep -q "net.ipv6.conf.default.accept_source_route = 0" && \
   grep -q "net.ipv6.conf.all.accept_source_route = 0" /etc/sysctl.conf && \
   grep -q "net.ipv6.conf.default.accept_source_route = 0" /etc/sysctl.conf)); then
    echo "pass"
else
    echo "FAIL: Source routed packets configuration failed"
    exit 1
fi