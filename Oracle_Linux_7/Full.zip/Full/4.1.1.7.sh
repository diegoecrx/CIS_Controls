#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

echo "Current permissions before changes:"
ls -ld /etc/cron.d
echo ""

echo "Applying ownership and permissions..."
chown root:root /etc/cron.d
chmod og-rwx /etc/cron.d

echo "Permissions after changes:"
ls -ld /etc/cron.d
echo ""

echo "Detailed stat output:"
stat -c "Owner: %U" /etc/cron.d
stat -c "Group: %G" /etc/cron.d  
stat -c "Permissions: %a" /etc/cron.d
echo ""

# Verify with multiple methods
OWNER=$(stat -c "%U" /etc/cron.d)
GROUP=$(stat -c "%G" /etc/cron.d)
PERMS=$(stat -c "%a" /etc/cron.d)
SYMBOLIC_PERMS=$(stat -c "%A" /etc/cron.d)

echo "Verification:"
echo "Owner: $OWNER (required: root)"
echo "Group: $GROUP (required: root)" 
echo "Permissions: $PERMS (required: 700)"
echo "Symbolic: $SYMBOLIC_PERMS (required: drwx------)"
echo ""

if [[ "$OWNER" == "root" && "$GROUP" == "root" && "$PERMS" == "700" ]]; then
    echo "pass"
else
    echo "FAIL: /etc/cron.d permissions configuration failed"
    echo "Expected: root:root 700"
    echo "Actual: $OWNER:$GROUP $PERMS"
    exit 1
fi