#!/usr/bin/env bash
# Script: 3.4.3.4.sh
# Item: 3.4.3.4 Ensure nftables base chains exist (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.4.sh"
ITEM_NAME="3.4.3.4 Ensure nftables base chains exist (Automated)"
DESCRIPTION="This remediation ensures nftables base chains exist for input, forward, and output filtering."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables base chains..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    # Check if any tables exist
    if ! nft list tables 2>/dev/null | grep -q "table"; then
        echo "FAIL: No nftables tables exist"
        echo "PROOF: nft list tables returned no tables"
        return 1
    fi
    
    # Find the first inet table (or create filter if none exist)
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo "FAIL: No inet table found"
        echo "PROOF: No inet table exists"
        return 1
    fi
    
    # Check for required base chains
    missing_chains=""
    
    # Check input chain
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        missing_chains="${missing_chains}input "
    fi
    
    # Check forward chain
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain forward"; then
        missing_chains="${missing_chains}forward "
    fi
    
    # Check output chain
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain output"; then
        missing_chains="${missing_chains}output "
    fi
    
    if [ -n "$missing_chains" ]; then
        echo "FAIL: Missing base chains in table $table_name"
        echo "PROOF: Missing chains: $missing_chains"
        return 1
    fi
    
    echo "PASS: nftables base chains exist"
    echo "PROOF: All required base chains (input, forward, output) exist in table $table_name"
    return 0
}
# Function to fix
fix_nftables_base_chains() {
    echo "Applying fix..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package first"
        yum install -y nftables
    fi
    
    # Find or create an inet table
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo " - Creating inet filter table"
        nft create table inet filter
        table_name="filter"
    fi
    
    echo " - Using table: $table_name"
    
    # Create missing base chains
    
    # Create input chain if missing
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo " - Creating input base chain"
        nft create chain inet "$table_name" input '{ type filter hook input priority 0 ; }'
    fi
    
    # Create forward chain if missing
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain forward"; then
        echo " - Creating forward base chain"
        nft create chain inet "$table_name" forward '{ type filter hook forward priority 0 ; }'
    fi
    
    # Create output chain if missing
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain output"; then
        echo " - Creating output base chain"
        nft create chain inet "$table_name" output '{ type filter hook output priority 0 ; }'
    fi
    
    # Update configuration file to make persistent
    if [ -f /etc/nftables.conf ]; then
        # Backup existing config
        cp /etc/nftables.conf /etc/nftables.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    fi
    
    # Save current ruleset to configuration file
    echo " - Saving configuration to /etc/nftables.conf"
    cat > /etc/nftables.conf << EOF
#!/usr/sbin/nft -f

flush ruleset

$(nft list ruleset)
EOF
    
    echo " - nftables base chains configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_base_chains
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables base chains properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="