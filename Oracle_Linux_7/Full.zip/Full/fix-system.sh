#!/bin/bash
# fix-system.sh - RCU stall, softlockup, IO-wait and scheduler tuning for OL7
# Fully fixed version — safe when sysstat/mpstat/cpupower are missing.

set -euo pipefail

echo "=== Fix-System: Start ==="
echo "Start time: $(date)"
echo

# Ensure root
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: Must run as root" >&2
    exit 1
fi

##############################################
# SECTION 1 — DIAGNOSTICS
##############################################
diagnose_rcu() {
    echo "=== RCU Diagnostics ==="
    echo "Recent kernel RCU messages:"
    dmesg | grep -i rcu | tail -20 || echo "(none)"
    echo
}

##############################################
# SECTION 2 — CHECK COMMON CAUSES
##############################################
check_rcu_causes() {
    echo "=== Checking Common Causes ==="

    echo "1. Softlockups:"
    if dmesg | grep -qi softlockup; then
        echo "   WARNING: Softlockups detected"
        echo 30 > /proc/sys/kernel/watchdog_thresh || true
    else
        echo "   OK"
    fi

    echo
    echo "2. CPU Load:"
    uptime

    echo
    echo "3. Memory:"
    free -h

    echo
    echo "4. Disk I/O Wait:"
    if command -v iostat >/dev/null 2>&1; then
        iostat -x 1 2 | tail -5
    else
        echo "   iostat not installed — install with: yum install -y sysstat"
    fi
    echo

    echo "5. Tasks stuck in D-state:"
    ps -eo pid,user,stat,comm | awk '$3 ~ /^D/' || true
    echo
}

##############################################
# SECTION 3 — KERNEL TUNING
##############################################
tune_kernel_parameters() {
    echo "=== Tuning Kernel Parameters ==="
    cp "/etc/sysctl.conf" "/etc/sysctl.conf.bak.$(date +%Y%m%d_%H%M%S)"

    cat >> /etc/sysctl.conf << 'EOF'

# === RCU Tuning ===
kernel.rcu_cpu_stall_timeout = 300
kernel.rcu_expedited = 0
kernel.rcu_normal = 1

# === VM & Memory ===
vm.swappiness = 10
vm.max_map_count = 262144

# === File handles ===
fs.file-max = 2097152
fs.nr_open = 1048576

# === Network buffers ===
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728

EOF

    sysctl -p || true
    echo
}

##############################################
# SECTION 4 — CPU SCHEDULER
##############################################
tune_cpu_scheduler() {
    echo "=== CPU Scheduler Tuning ==="

    if command -v cpupower >/dev/null; then
        cpupower frequency-set -g performance || true
    fi

    for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        [ -f "$gov" ] && echo performance > "$gov" || true
    done

    echo
}

##############################################
# SECTION 5 — SERVICES OPTIMIZATION
##############################################
optimize_services() {
    echo "=== Optimizing Services ==="

    # Backup auditd config
    cp /etc/audit/auditd.conf /etc/audit/auditd.conf.bak.$(date +%s)

    # Rewrite auditd with safer defaults
    cat > /etc/audit/auditd.conf << 'EOF'
log_file = /var/log/audit/audit.log
log_format = RAW
max_log_file = 50
max_log_file_action = ROTATE
EOF

    systemctl restart auditd || true
    echo
}

##############################################
# SECTION 6 — MONITORING SCRIPTS
##############################################
create_monitor_scripts() {
    echo "=== Creating Monitor Scripts ==="

    cat > /usr/local/bin/monitor-rcu.sh << 'EOF'
#!/bin/bash
echo "--- RCU Monitor ---"
dmesg | grep -i rcu | tail -20
EOF

    chmod +x /usr/local/bin/monitor-rcu.sh
}

##############################################
# SECTION 7 — KERNEL CHECK
##############################################
update_kernel_if_needed() {
    echo "=== Kernel Check ==="
    ver="$(uname -r)"
    echo "Running kernel: $ver"

    if [[ "$ver" =~ ^3\. ]]; then
        echo "This kernel is OLD — update recommended"
    fi
    echo
}

##############################################
# RUN
##############################################
main() {
    diagnose_rcu
    check_rcu_causes
    tune_kernel_parameters
    tune_cpu_scheduler
    optimize_services
    create_monitor_scripts
    update_kernel_if_needed

    echo "=== Fix Complete ==="
    echo "Reboot recommended"
}

main
echo "Finished at: $(date)"
