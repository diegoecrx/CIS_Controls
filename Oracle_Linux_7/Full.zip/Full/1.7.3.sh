#!/usr/bin/env bash
# Script: 1.7.3.sh
# Item: 1.7.3 Ensure GDM disable-user-list option is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.3.sh"
ITEM_NAME="1.7.3 Ensure GDM disable-user-list option is enabled (Automated)"
DESCRIPTION="This remediation ensures GDM disable-user-list option is enabled or GDM is removed."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking GDM disable-user-list configuration..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    l_gdmprofile="gdm"
    
    # Check if profile exists
    if [ ! -f "/etc/dconf/profile/$l_gdmprofile" ]; then
        echo "FAIL: GDM profile not configured"
        echo "PROOF: /etc/dconf/profile/$l_gdmprofile does not exist"
        return 1
    fi
    
    # Check if disable-user-list is set to true
    if ! grep -Piq '^\h*disable-user-list\h*=\h*true\b' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
        echo "FAIL: disable-user-list not enabled"
        echo "PROOF: disable-user-list=true not found in /etc/dconf/db/$l_gdmprofile.d/"
        return 1
    fi
    
    echo "PASS: GDM disable-user-list configured properly"
    echo "PROOF: Profile exists and disable-user-list=true found"
    return 0
}
# Function to fix
fix_gdm_disable_user_list() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    l_gdmprofile="gdm"
    
    # Create profile if it doesn't exist
    if [ ! -f "/etc/dconf/profile/$l_gdmprofile" ]; then
        echo " - Creating profile $l_gdmprofile"
        echo -e "user-db:user\nsystem-db:$l_gdmprofile\nfile-db:/usr/share/$l_gdmprofile/greeter-dconf-defaults" > /etc/dconf/profile/$l_gdmprofile
    fi
    
    # Create dconf database directory
    if [ ! -d "/etc/dconf/db/$l_gdmprofile.d/" ]; then
        echo " - Creating dconf database directory"
        mkdir -p /etc/dconf/db/$l_gdmprofile.d/
    fi
    
    # Configure disable-user-list setting
    if ! grep -Piq '^\h*disable-user-list\h*=\h*true\b' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
        echo " - Creating gdm keyfile for machine-wide settings"
        
        if ! grep -Piq -- '^\h*\[org\/gnome\/login-screen\]' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null; then
            echo -e "\n[org/gnome/login-screen]\n# Do not show the user list\ndisable-user-list=true" >> /etc/dconf/db/$l_gdmprofile.d/00-login-screen
        else
            l_kfile="$(grep -Pil -- '^\h*\[org\/gnome\/login-screen\]' /etc/dconf/db/$l_gdmprofile.d/* 2>/dev/null | head -1)"
            if [ -n "$l_kfile" ]; then
                sed -ri '/^\s*\[org\/gnome\/login-screen\]/ a\# Do not show the user list\ndisable-user-list=true' "$l_kfile"
            fi
        fi
    fi
    
    # Update dconf
    dconf update 2>/dev/null || true
    echo " - Updated dconf database"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm_disable_user_list
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GDM disable-user-list configured properly"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="