#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-scope.rules"

# Create audit rules file
printf -- "-w /etc/sudoers -p wa -k scope\n-w /etc/sudoers.d -p wa -k scope\n" > "$RULES_FILE"

# Load rules
augenrules --load

# Check if reboot required
if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi