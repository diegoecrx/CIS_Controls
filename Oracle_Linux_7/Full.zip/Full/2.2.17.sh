#!/usr/bin/env bash
# Script: 2.2.17.sh
# Item: 2.2.17 Ensure web proxy server services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures web proxy server services are not in use by removing or masking the squid.service and squid package. FORCE VERSION - Comprehensive web proxy server removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.17.sh"
ITEM_NAME="2.2.17 Ensure web proxy server services are not in use (Automated)"
DESCRIPTION="This remediation ensures web proxy server services are not in use by removing or masking the squid.service and squid package. FORCE VERSION - Comprehensive web proxy server removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_squid_status() {
  echo "Checking Squid proxy server status..."
  if systemctl is-active squid.service >/dev/null 2>&1; then
    echo " - squid.service is active."
  fi
  if systemctl is-enabled squid.service >/dev/null 2>&1; then
    echo " - squid.service is enabled."
  fi
  if rpm -q squid >/dev/null 2>&1; then
    echo " - squid package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':3128|:8080'; then
    echo " - Proxy ports 3128 and/or 8080 are open."
  fi
}

stop_squid_service() {
  echo "Stopping squid.service..."
  systemctl stop squid.service 2>/dev/null || true
  pkill -TERM squid 2>/dev/null || true
  pkill -KILL squid 2>/dev/null || true
}

remove_squid_package() {
  local pkg_mgr="$1"
  echo "Removing squid package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y squid 2>/dev/null || echo " - WARNING: Could not remove squid (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_squid_service() {
  echo "Masking squid.service..."
  systemctl mask squid.service 2>/dev/null || true
}

verify_squid_removal() {
  echo "Verifying Squid proxy server remediation..."
  local failed=false
  if rpm -q squid >/dev/null 2>&1; then
    echo "FAIL: squid package is still installed."
    failed=true
  fi
  if systemctl is-enabled squid.service 2>/dev/null | grep -vq masked; then
    echo "FAIL: squid.service is not masked."
    failed=true
  fi
  if systemctl is-active squid.service 2>/dev/null | grep -vq inactive; then
    echo "FAIL: squid.service is still active."
    failed=true
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':3128|:8080'; then
    echo "FAIL: Proxy ports 3128/8080 are still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_squid_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING SQUID PROXY SERVER SERVICE"
echo "==================================================================="
echo ""

stop_squid_service
remove_squid_package "$PKG_MGR"
mask_squid_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_squid_removal; then
  echo "SUCCESS: Squid proxy server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: Squid proxy server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q squid"
  echo "2. Ensure service is masked: systemctl status squid.service"
  echo "3. Check ports: ss -tulpn | grep -E ':3128|:8080'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
