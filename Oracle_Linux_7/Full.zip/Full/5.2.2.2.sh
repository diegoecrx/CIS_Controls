#!/bin/bash

# Enforce CIS 5.2.2.2 - Ensure audit logs are not automatically deleted
echo "Enforcing CIS 5.2.2.2 - Configure audit log retention..."

# Configure auditd.conf
echo "Configuring /etc/audit/auditd.conf..."

# Create directory if it doesn't exist
if [ ! -d /etc/audit ]; then
    mkdir -p /etc/audit
    echo "Created /etc/audit directory"
fi

# Create or update auditd.conf
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "Creating /etc/audit/auditd.conf..."
    touch /etc/audit/auditd.conf
fi

# Backup original file
if [ ! -f /etc/audit/auditd.conf.bak ]; then
    cp /etc/audit/auditd.conf /etc/audit/auditd.conf.bak
    echo "Backed up /etc/audit/auditd.conf to /etc/audit/auditd.conf.bak"
fi

# Check if max_log_file_action is already set
if grep -q "^max_log_file_action" /etc/audit/auditd.conf; then
    # Update existing setting to keep_logs
    sed -i 's/^max_log_file_action.*/max_log_file_action = keep_logs/' /etc/audit/auditd.conf
    echo "Updated existing max_log_file_action setting to 'keep_logs'"
else
    # Add new setting
    echo "max_log_file_action = keep_logs" >> /etc/audit/auditd.conf
    echo "Added max_log_file_action = keep_logs to /etc/audit/auditd.conf"
fi

# Set proper permissions on auditd.conf
chmod 640 /etc/audit/auditd.conf
chown root:root /etc/audit/auditd.conf

# Restart auditd service if it's running
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "Restarting auditd service..."
    systemctl restart auditd
fi

# Verify configuration
echo "Verifying audit log retention configuration..."

# Check if max_log_file_action is correctly configured
if grep -q "^max_log_file_action = keep_logs" /etc/audit/auditd.conf; then
    echo "SUCCESS: max_log_file_action = keep_logs configured in /etc/audit/auditd.conf"
else
    echo "ERROR: max_log_file_action not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Verify file permissions
PERMS=$(stat -c %a /etc/audit/auditd.conf)
OWNER=$(stat -c %U:%G /etc/audit/auditd.conf)
if [ "$PERMS" = "640" ] && [ "$OWNER" = "root:root" ]; then
    echo "SUCCESS: /etc/audit/auditd.conf has correct permissions and ownership"
else
    echo "ERROR: /etc/audit/auditd.conf has incorrect permissions or ownership"
    exit 1
fi

# Check if auditd service is running (if installed)
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "SUCCESS: auditd service is running"
else
    echo "WARNING: auditd service is not running (may not be installed)"
fi

echo "CIS 5.2.2.2 remediation completed successfully"
echo "Audit logs are now configured to be retained (not automatically deleted)"