#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

echo "Removing existing log configuration entries..."
sed -i '/^[\s]*mail\.err/d' /etc/rsyslog.conf
sed -i '/^[\s]*local6,local7\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*auth,authpriv\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*local2,local3\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*\*\.=warning;\*\.=err/d' /etc/rsyslog.conf
sed -i '/^[\s]*mail\.info/d' /etc/rsyslog.conf
sed -i '/^[\s]*\*\.crit/d' /etc/rsyslog.conf
sed -i '/^[\s]*mail\.warning/d' /etc/rsyslog.conf
sed -i '/^[\s]*\*\.\*;mail\.none;news\.none/d' /etc/rsyslog.conf
sed -i '/^[\s]*local4,local5\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*local0,local1\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*mail\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*cron\.\*/d' /etc/rsyslog.conf
sed -i '/^[\s]*\*\.emerg/d' /etc/rsyslog.conf

echo "Adding compliant log configuration..."
echo "*.emerg                                                 :omusrmsg:*" >> /etc/rsyslog.conf
echo "mail.* -/var/log/mail" >> /etc/rsyslog.conf
echo "cron.* /var/log/cron" >> /etc/rsyslog.conf
echo "mail.err /var/log/mail.err" >> /etc/rsyslog.conf
echo "local6,local7.* -/var/log/localmessages" >> /etc/rsyslog.conf
echo "auth,authpriv.* /var/log/secure" >> /etc/rsyslog.conf
echo "local2,local3.* -/var/log/localmessages" >> /etc/rsyslog.conf
echo "*.=warning;*.=err -/var/log/warn" >> /etc/rsyslog.conf
echo "mail.info -/var/log/mail.info" >> /etc/rsyslog.conf
echo "*.crit /var/log/warn" >> /etc/rsyslog.conf
echo "mail.warning -/var/log/mail.warn" >> /etc/rsyslog.conf
echo "*.*;mail.none;news.none -/var/log/messages" >> /etc/rsyslog.conf
echo "local4,local5.* -/var/log/localmessages" >> /etc/rsyslog.conf
echo "local0,local1.* -/var/log/localmessages" >> /etc/rsyslog.conf

echo "Restarting rsyslog service..."
systemctl restart rsyslog

echo ""
echo "Verification of configured entries:"
grep -E "^(mail\.|local|auth|\*\.|cron\.)" /etc/rsyslog.conf | sort

echo ""
echo "Service status:"
systemctl is-active rsyslog.service

# Verify critical entries that were failing
echo ""
echo "Critical compliance checks:"
if grep -q "^[\s]*mail\.err[\s]+/var/log/mail.err[\s]*$" /etc/rsyslog.conf; then
    echo "✓ mail.err: /var/log/mail.err (correct - no dash)"
else
    echo "✗ mail.err configuration incorrect"
    grep "mail.err" /etc/rsyslog.conf
fi

if grep -q "^[\s]*mail\.\*[\s]+-/var/log/mail[\s]*$" /etc/rsyslog.conf; then
    echo "✓ mail.*: -/var/log/mail (correct)"
else
    echo "✗ mail.* configuration incorrect"
    grep "mail\.\*" /etc/rsyslog.conf
fi

if systemctl is-active rsyslog.service | grep -q "active"; then
    echo "✓ rsyslog service is active"
    echo "pass"
else
    echo "✗ rsyslog service is not active"
    echo "FAIL: Logging configuration failed"
    exit 1
fi