#!/bin/bash

# Enforce CIS 4.2.19 - Ensure sshd PermitEmptyPasswords is disabled
echo "Enforcing CIS 4.2.19 - SSH PermitEmptyPasswords disabled..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Check if PermitEmptyPasswords is already set
if grep -q "^PermitEmptyPasswords" /etc/ssh/sshd_config; then
    # Update existing setting to no (CIS required)
    sed -i 's/^PermitEmptyPasswords.*/PermitEmptyPasswords no/' /etc/ssh/sshd_config
    echo "Updated existing PermitEmptyPasswords setting to 'no'"
else
    # Add new setting at the beginning (above any Match entries)
    sed -i '1iPermitEmptyPasswords no' /etc/ssh/sshd_config
    echo "Added PermitEmptyPasswords no to /etc/ssh/sshd_config"
fi

# Restart sshd service to apply changes
echo "Restarting sshd service..."
systemctl restart sshd

# Verify configuration
echo "Verifying PermitEmptyPasswords configuration..."

# Check if setting is correctly configured in file
if grep -q "^PermitEmptyPasswords no" /etc/ssh/sshd_config; then
    echo "SUCCESS: PermitEmptyPasswords set to 'no' in /etc/ssh/sshd_config"
else
    echo "ERROR: PermitEmptyPasswords not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.19 remediation completed successfully"