#!/usr/bin/env bash

# Script: 1.2.2.sh
# Item: 1.2.2 Ensure gpgcheck is globally activated (Automated)
# Description: This remediation ensures gpgcheck is globally activated in yum configuration.

set -euo pipefail

SCRIPT_NAME="1.2.2.sh"
ITEM_NAME="1.2.2 Ensure gpgcheck is globally activated (Automated)"
DESCRIPTION="This remediation ensures gpgcheck is globally activated in yum configuration."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

# Function to print detailed section header
print_section() {
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║ $1"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo ""
}

# Function to print status with color
print_status() {
    local status="$1"
    local message="$2"
    case "$status" in
        "PASS") echo "✓ PASS: $message" ;;
        "FAIL") echo "✗ FAIL: $message" ;;
        "WARN") echo "⚠ WARN: $message" ;;
        "INFO") echo "ℹ INFO: $message" ;;
        *) echo "  $message" ;;
    esac
}

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to perform comprehensive gpgcheck analysis
analyze_gpgcheck_configuration() {
    print_section "COMPREHENSIVE GPGCHECK CONFIGURATION ANALYSIS"
    
    # Analyze yum.conf main section
    echo "1. MAIN YUM CONFIGURATION (/etc/yum.conf):"
    echo "=========================================="
    
    if [ -f "/etc/yum.conf" ]; then
        local main_gpgcheck=$(grep '^gpgcheck' /etc/yum.conf || echo "Not found")
        local main_gpgcheck_value=$(echo "$main_gpgcheck" | grep -o 'gpgcheck=.*' | cut -d'=' -f2 | head -1)
        
        if [ "$main_gpgcheck_value" = "1" ]; then
            print_status "PASS" "gpgcheck=1 in [main] section"
            echo "   Configuration: $main_gpgcheck"
        elif [ -n "$main_gpgcheck_value" ]; then
            print_status "FAIL" "gpgcheck=$main_gpgcheck_value in [main] section (should be 1)"
            echo "   Configuration: $main_gpgcheck"
        else
            print_status "FAIL" "No gpgcheck directive found in [main] section"
        fi
        
        # Check for other security-related settings in main
        echo ""
        echo "   Other security settings in [main]:"
        grep -E '^(localpkg_gpgcheck|repo_gpgcheck)' /etc/yum.conf 2>/dev/null || echo "   No additional security settings found"
    else
        print_status "FAIL" "/etc/yum.conf not found"
    fi
    
    # Analyze all repository files
    echo ""
    echo "2. REPOSITORY CONFIGURATION ANALYSIS:"
    echo "====================================="
    
    local repo_files=$(find /etc/yum.repos.d -name "*.repo" -type f 2>/dev/null | sort)
    local repo_count=0
    local compliant_repos=0
    local non_compliant_repos=0
    local repos_without_gpgcheck=0
    
    if [ -n "$repo_files" ]; then
        for repo_file in $repo_files; do
            repo_count=$((repo_count + 1))
            echo ""
            echo "   Analyzing: $(basename "$repo_file")"
            echo "   ---------------------------------"
            
            # Check each repository section in the file
            while IFS= read -r section; do
                if [[ "$section" =~ ^\[.*\]$ ]]; then
                    repo_section="${section//[\[\]]/}"
                    echo "   Section: $repo_section"
                    
                    # Extract gpgcheck for this section
                    section_gpgcheck=$(sed -n "/^\[$repo_section\]/,/^\[/p" "$repo_file" | grep '^gpgcheck' | head -1)
                    
                    if [ -n "$section_gpgcheck" ]; then
                        gpgcheck_value=$(echo "$section_gpgcheck" | grep -o 'gpgcheck=.*' | cut -d'=' -f2)
                        if [ "$gpgcheck_value" = "1" ]; then
                            print_status "PASS" "   gpgcheck=1"
                            compliant_repos=$((compliant_repos + 1))
                        else
                            print_status "FAIL" "   gpgcheck=$gpgcheck_value (should be 1)"
                            non_compliant_repos=$((non_compliant_repos + 1))
                        fi
                        echo "      Setting: $section_gpgcheck"
                    else
                        print_status "FAIL" "   No gpgcheck directive found"
                        repos_without_gpgcheck=$((repos_without_gpgcheck + 1))
                    fi
                    
                    # Check for other security settings in this section
                    local repo_gpgkey=$(sed -n "/^\[$repo_section\]/,/^\[/p" "$repo_file" | grep '^gpgkey' | head -1)
                    if [ -n "$repo_gpgkey" ]; then
                        echo "      GPG Key: Configured"
                    else
                        print_status "WARN" "   No gpgkey configured"
                    fi
                fi
            done < "$repo_file"
        done
        
        echo ""
        echo "   REPOSITORY SUMMARY:"
        echo "   =================="
        print_status "INFO" "   Total repository files: $repo_count"
        print_status "INFO" "   Compliant repositories: $compliant_repos"
        print_status "INFO" "   Non-compliant repositories: $non_compliant_repos"
        print_status "INFO" "   Repositories without gpgcheck: $repos_without_gpgcheck"
        
    else
        print_status "WARN" "No repository files found in /etc/yum.repos.d/"
    fi
    
    # Check DNF configuration if available
    if [ -f "/etc/dnf/dnf.conf" ]; then
        echo ""
        echo "3. DNF CONFIGURATION (/etc/dnf/dnf.conf):"
        echo "========================================"
        local dnf_gpgcheck=$(grep '^gpgcheck' /etc/dnf/dnf.conf || echo "Not found")
        if echo "$dnf_gpgcheck" | grep -q 'gpgcheck=1'; then
            print_status "PASS" "gpgcheck=1 in DNF configuration"
        else
            print_status "INFO" "DNF gpgcheck: $dnf_gpgcheck"
        fi
    fi
}

# Function to fix yum.conf with comprehensive approach
fix_yum_conf() {
    print_section "REMEDIATING MAIN YUM CONFIGURATION"
    
    echo "Fixing /etc/yum.conf..."
    
    if [ ! -f "/etc/yum.conf" ]; then
        print_status "FAIL" "/etc/yum.conf does not exist"
        return 1
    fi
    
    # Create backup
    cp /etc/yum.conf "/etc/yum.conf.backup.$(date +%Y%m%d_%H%M%S)"
    print_status "INFO" "Backup created: /etc/yum.conf.backup.*"
    
    # Check current state
    local current_gpgcheck=$(grep '^gpgcheck' /etc/yum.conf || true)
    
    if echo "$current_gpgcheck" | grep -q '^gpgcheck=1'; then
        print_status "PASS" "gpgcheck already set to 1 in [main] section"
        echo "   Current setting: $current_gpgcheck"
    else
        if [ -n "$current_gpgcheck" ]; then
            # Replace existing gpgcheck
            sed -i 's/^gpgcheck\s*=\s*.*/gpgcheck=1/' /etc/yum.conf
            print_status "INFO" "Updated existing gpgcheck to 1"
            echo "   Previous setting: $current_gpgcheck"
            echo "   New setting: gpgcheck=1"
        else
            # Add gpgcheck to [main] section
            if grep -q '^\[main\]' /etc/yum.conf; then
                sed -i '/^\[main\]/a gpgcheck=1' /etc/yum.conf
                print_status "INFO" "Added gpgcheck=1 to [main] section"
            else
                # Create [main] section if it doesn't exist
                echo -e "[main]\ngpgcheck=1" >> /etc/yum.conf
                print_status "INFO" "Created [main] section with gpgcheck=1"
            fi
        fi
    fi
    
    # Ensure other security settings
    if ! grep -q '^localpkg_gpgcheck' /etc/yum.conf; then
        echo "localpkg_gpgcheck=1" >> /etc/yum.conf
        print_status "INFO" "Added localpkg_gpgcheck=1 for additional security"
    fi
}

# Function to fix repo files comprehensively
fix_repo_files() {
    print_section "REMEDIATING REPOSITORY CONFIGURATIONS"
    
    echo "Fixing repository files in /etc/yum.repos.d/..."
    
    local repo_files=$(find /etc/yum.repos.d -name "*.repo" -type f 2>/dev/null)
    local files_modified=0
    local total_files=0
    
    if [ -n "$repo_files" ]; then
        for repo_file in $repo_files; do
            total_files=$((total_files + 1))
            local file_modified=false
            
            # Create backup of each file
            cp "$repo_file" "${repo_file}.backup.$(date +%Y%m%d_%H%M%S)"
            
            # Process each repository section in the file
            while IFS= read -r section; do
                if [[ "$section" =~ ^\[.*\]$ ]]; then
                    repo_section="${section//[\[\]]/}"
                    
                    # Check and fix gpgcheck for this section
                    section_content=$(sed -n "/^\[$repo_section\]/,/^\[/p" "$repo_file")
                    current_gpgcheck=$(echo "$section_content" | grep '^gpgcheck' | head -1)
                    
                    if [ -n "$current_gpgcheck" ]; then
                        # Update existing gpgcheck if not 1
                        if ! echo "$current_gpgcheck" | grep -q 'gpgcheck=1'; then
                            sed -i "/^\[$repo_section\]/,/^\[/ s/^gpgcheck\s*=\s*.*/gpgcheck=1/" "$repo_file"
                            print_status "INFO" "Updated $repo_section in $(basename "$repo_file"): gpgcheck=1"
                            file_modified=true
                            files_modified=$((files_modified + 1))
                        fi
                    else
                        # Add gpgcheck if missing
                        sed -i "/^\[$repo_section\]/a gpgcheck=1" "$repo_file"
                        print_status "INFO" "Added gpgcheck=1 to $repo_section in $(basename "$repo_file")"
                        file_modified=true
                        files_modified=$((files_modified + 1))
                    fi
                fi
            done < "$repo_file"
            
            if [ "$file_modified" = false ]; then
                echo "   No changes needed for $(basename "$repo_file")"
            fi
        done
        
        print_status "INFO" "Modified $files_modified out of $total_files repository files"
    else
        print_status "WARN" "No repository files found in /etc/yum.repos.d/"
    fi
}

# Function to verify remediation comprehensively
verify_remediation() {
    print_section "COMPREHENSIVE REMEDIATION VERIFICATION"
    
    local verification_passed=true
    local issues_found=0
    
    echo "1. MAIN CONFIGURATION VERIFICATION:"
    echo "==================================="
    
    # Verify yum.conf
    local main_gpgcheck=$(grep '^gpgcheck' /etc/yum.conf 2>/dev/null || true)
    if echo "$main_gpgcheck" | grep -q 'gpgcheck=1'; then
        print_status "PASS" "gpgcheck=1 in /etc/yum.conf [main] section"
        echo "   Proof: $main_gpgcheck"
    else
        print_status "FAIL" "gpgcheck not set to 1 in /etc/yum.conf"
        echo "   Current: $main_gpgcheck"
        verification_passed=false
        issues_found=$((issues_found + 1))
    fi
    
    echo ""
    echo "2. REPOSITORY VERIFICATION:"
    echo "==========================="
    
    local repo_files=$(find /etc/yum.repos.d -name "*.repo" -type f 2>/dev/null)
    local non_compliant_count=0
    local total_repos=0
    
    if [ -n "$repo_files" ]; then
        for repo_file in $repo_files; do
            # Check each repository section
            while IFS= read -r section; do
                if [[ "$section" =~ ^\[.*\]$ ]]; then
                    repo_section="${section//[\[\]]/}"
                    total_repos=$((total_repos + 1))
                    
                    section_gpgcheck=$(sed -n "/^\[$repo_section\]/,/^\[/p" "$repo_file" | grep '^gpgcheck' | head -1)
                    
                    if [ -n "$section_gpgcheck" ]; then
                        if echo "$section_gpgcheck" | grep -q 'gpgcheck=1'; then
                            echo "   ✓ $(basename "$repo_file"): $repo_section - gpgcheck=1"
                        else
                            print_status "FAIL" "$(basename "$repo_file"): $repo_section - $section_gpgcheck"
                            non_compliant_count=$((non_compliant_count + 1))
                            verification_passed=false
                        fi
                    else
                        print_status "FAIL" "$(basename "$repo_file"): $repo_section - No gpgcheck directive"
                        non_compliant_count=$((non_compliant_count + 1))
                        verification_passed=false
                    fi
                fi
            done < "$repo_file"
        done
        
        echo ""
        print_status "INFO" "Repository compliance: $(($total_repos - $non_compliant_count))/$total_repos compliant"
        
        if [ "$non_compliant_count" -gt 0 ]; then
            issues_found=$((issues_found + non_compliant_count))
        fi
    else
        print_status "WARN" "No repository files found for verification"
    fi
    
    echo ""
    echo "3. FUNCTIONAL TEST:"
    echo "==================="
    
    # Test that yum still works with the new configuration
    if command -v yum >/dev/null 2>&1; then
        if yum check-update >/dev/null 2>&1; then
            print_status "PASS" "YUM functionality verified - can check for updates"
        else
            print_status "WARN" "YUM check-update returned non-zero (may be normal if updates available)"
            # This is often normal - many systems have updates available
        fi
    fi
    
    # Final assessment
    echo ""
    echo "VERIFICATION SUMMARY:"
    echo "===================="
    print_status "INFO" "Total issues identified: $issues_found"
    
    if [ "$verification_passed" = true ] && [ "$issues_found" -eq 0 ]; then
        print_status "PASS" "All gpgcheck configurations are compliant"
        return 0
    else
        print_status "FAIL" "Found $issues_found configuration issues"
        return 1
    fi
}

# Main remediation function
{
    print_section "INITIAL CONFIGURATION ANALYSIS"
    analyze_gpgcheck_configuration
    
    print_section "APPLYING REMEDIATION"
    fix_yum_conf
    fix_repo_files
    
    print_section "POST-REMEDIATION ANALYSIS"
    analyze_gpgcheck_configuration
    
    print_section "FINAL VERIFICATION"
    if verify_remediation; then
        print_section "REMEDIATION SUCCESS"
        echo "✓ gpgcheck is globally activated and verified"
        echo ""
        echo "SECURITY STATUS:"
        echo "================"
        echo "• All package installations will require GPG signature verification"
        echo "• Protection against tampered package installation is enabled"
        echo "• Compliance with CIS Benchmark 1.2.2 achieved"
    else
        print_section "REMEDIATION INCOMPLETE"
        echo "⚠ Some configuration issues remain"
        echo ""
        echo "RECOMMENDED ACTIONS:"
        echo "===================="
        echo "• Manually review /etc/yum.repos.d/*.repo files"
        echo "• Ensure all repository sections have gpgcheck=1"
        echo "• Verify repository GPG keys are properly configured"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="