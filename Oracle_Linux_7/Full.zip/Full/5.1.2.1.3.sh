#!/usr/bin/env bash
# Script: 5.1.2.1.3.sh
# Item: 5.1.2.1.3 Ensure systemd-journal-remote is enabled (Manual)
set -euo pipefail
SCRIPT_NAME="5.1.2.1.3.sh"
ITEM_NAME="5.1.2.1.3 Ensure systemd-journal-remote is enabled (Manual)"
DESCRIPTION="This remediation ensures systemd-journal-upload.service is enabled."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking systemd-journal-upload.service status..."
    
    enabled=$(systemctl is-enabled systemd-journal-upload.service 2>/dev/null || echo "disabled")
    active=$(systemctl is-active systemd-journal-upload.service 2>/dev/null || echo "inactive")
    
    if [ "$enabled" = "enabled" ] && [ "$active" = "active" ]; then
        echo "PASS: Service is enabled and active"
        echo "PROOF (is-enabled): $enabled"
        echo "PROOF (is-active): $active"
        return 0
    else
        echo "FAIL: Service is not fully enabled/active"
        echo "PROOF (is-enabled): $enabled"
        echo "PROOF (is-active): $active"
        return 1
    fi
}
# Function to fix
fix_journal_remote() {
    echo "Applying fix..."
    systemctl --now enable systemd-journal-upload.service 2>&1
    echo " - Enabled and started systemd-journal-upload.service"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journal_remote
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: systemd-journal-remote enabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="