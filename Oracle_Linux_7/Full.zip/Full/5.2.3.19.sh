#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-kernel_modules.rules"
UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)

if [ -n "${UID_MIN}" ]; then
    {
        echo "-a always,exit -F arch=b64 -S init_module,finit_module,delete_module,create_module,query_module -F auid>=${UID_MIN} -F auid!=unset -k kernel_modules"
        echo "-a always,exit -F path=/usr/bin/kmod -F perm=x -F auid>=${UID_MIN} -F auid!=unset -k kernel_modules"
    } > "$RULES_FILE"
    
    augenrules --load
    
    if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
        echo "Reboot required to load rules"
    fi
else
    echo "ERROR: Variable 'UID_MIN' is unset."
    exit 1
fi