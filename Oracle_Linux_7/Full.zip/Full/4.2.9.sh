#!/bin/bash

# Enforce CIS 4.2.9 - Ensure sshd GSSAPIAuthentication is disabled
echo "Enforcing CIS 4.2.9 - SSH GSSAPIAuthentication disabled..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Check if GSSAPIAuthentication is already set
if grep -q "^GSSAPIAuthentication" /etc/ssh/sshd_config; then
    # Update existing setting to no (CIS required)
    sed -i 's/^GSSAPIAuthentication.*/GSSAPIAuthentication no/' /etc/ssh/sshd_config
    echo "Updated existing GSSAPIAuthentication setting to 'no'"
else
    # Add new setting at the beginning (above any Match entries)
    sed -i '1iGSSAPIAuthentication no' /etc/ssh/sshd_config
    echo "Added GSSAPIAuthentication no to /etc/ssh/sshd_config"
fi

# Restart sshd service to apply changes
echo "Restarting sshd service..."
systemctl restart sshd

# Verify configuration
echo "Verifying GSSAPIAuthentication configuration..."

# Check if setting is correctly configured in file
if grep -q "^GSSAPIAuthentication no" /etc/ssh/sshd_config; then
    echo "SUCCESS: GSSAPIAuthentication set to 'no' in /etc/ssh/sshd_config"
else
    echo "ERROR: GSSAPIAuthentication not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.9 remediation completed successfully"