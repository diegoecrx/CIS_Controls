#!/usr/bin/env bash
# Script: 2.2.12.sh
# Item: 2.2.12 Ensure rpcbind services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures rpcbind services are not in use by removing or masking the rpcbind.socket and rpcbind.service and rpcbind package. FORCE VERSION - Comprehensive rpcbind removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.12.sh"
ITEM_NAME="2.2.12 Ensure rpcbind services are not in use (Automated)"
DESCRIPTION="This remediation ensures rpcbind services are not in use by removing or masking the rpcbind.socket and rpcbind.service and rpcbind package. FORCE VERSION - Comprehensive rpcbind removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_rpcbind_status() {
  echo "Checking rpcbind server status..."
  if systemctl is-active rpcbind.service >/dev/null 2>&1; then
    echo " - rpcbind.service is active."
  fi
  if systemctl is-active rpcbind.socket >/dev/null 2>&1; then
    echo " - rpcbind.socket is active."
  fi
  if systemctl is-enabled rpcbind.service >/dev/null 2>&1; then
    echo " - rpcbind.service is enabled."
  fi
  if systemctl is-enabled rpcbind.socket >/dev/null 2>&1; then
    echo " - rpcbind.socket is enabled."
  fi
  if rpm -q rpcbind >/dev/null 2>&1; then
    echo " - rpcbind package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':111'; then
    echo " - rpcbind port 111 is open."
  fi
}

stop_rpcbind_service() {
  echo "Stopping rpcbind.socket and rpcbind.service..."
  systemctl stop rpcbind.socket rpcbind.service 2>/dev/null || true
  pkill -TERM rpcbind 2>/dev/null || true
  pkill -KILL rpcbind 2>/dev/null || true
}

remove_rpcbind_package() {
  local pkg_mgr="$1"
  echo "Removing rpcbind package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y rpcbind 2>/dev/null || echo " - WARNING: Could not remove rpcbind (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_rpcbind_service() {
  echo "Masking rpcbind.socket and rpcbind.service..."
  systemctl mask rpcbind.socket rpcbind.service 2>/dev/null || true
}

verify_rpcbind_removal() {
  echo "Verifying rpcbind server remediation..."
  local failed=false
  if rpm -q rpcbind >/dev/null 2>&1; then
    echo "FAIL: rpcbind package is still installed."
    failed=true
  fi
  for svc in rpcbind.socket rpcbind.service; do
    if systemctl is-enabled $svc 2>/dev/null | grep -vq masked; then
      echo "FAIL: $svc is not masked."
      failed=true
    fi
    if systemctl is-active $svc 2>/dev/null | grep -vq inactive; then
      echo "FAIL: $svc is still active."
      failed=true
    fi
  done
  if ss -tulpn 2>/dev/null | grep -Eq ':111'; then
    echo "FAIL: rpcbind port 111 is still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_rpcbind_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING RPCBIND SERVER SERVICE"
echo "==================================================================="
echo ""

stop_rpcbind_service
remove_rpcbind_package "$PKG_MGR"
mask_rpcbind_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_rpcbind_removal; then
  echo "SUCCESS: rpcbind server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: rpcbind server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q rpcbind"
  echo "2. Ensure services are masked: systemctl status rpcbind.service rpcbind.socket"
  echo "3. Check port: ss -tulpn | grep ':111'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
