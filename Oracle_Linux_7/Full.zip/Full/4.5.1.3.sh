#!/bin/bash

# Enforce CIS 4.5.1.3 - Ensure password expiration warning days is 7 or more
echo "Enforcing CIS 4.5.1.3 - Password expiration warning configuration..."

# Configure PASS_WARN_AGE in login.defs
echo "Configuring PASS_WARN_AGE in /etc/login.defs..."

# Backup original file
if [ ! -f /etc/login.defs.bak ]; then
    cp /etc/login.defs /etc/login.defs.bak
    echo "Backed up /etc/login.defs to /etc/login.defs.bak"
fi

# Set PASS_WARN_AGE to 7 in login.defs
if grep -q "^PASS_WARN_AGE" /etc/login.defs; then
    # Update existing setting
    sed -i 's/^PASS_WARN_AGE.*/PASS_WARN_AGE 7/' /etc/login.defs
    echo "Updated PASS_WARN_AGE to 7 in /etc/login.defs"
else
    # Add new setting
    echo "PASS_WARN_AGE 7" >> /etc/login.defs
    echo "Added PASS_WARN_AGE 7 to /etc/login.defs"
fi

# Apply password warning to all existing users with passwords
echo "Applying password warning to all users..."
for user in $(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow); do
    chage --warndays 7 "$user"
    echo "Set warndays=7 for user: $user"
done

# Verify configuration
echo "Verifying password warning configuration..."

# Check PASS_WARN_AGE in login.defs
if grep -q "^PASS_WARN_AGE 7" /etc/login.defs; then
    echo "SUCCESS: PASS_WARN_AGE = 7 configured in /etc/login.defs"
else
    echo "ERROR: PASS_WARN_AGE not properly configured in /etc/login.defs"
    exit 1
fi

# Verify all users have warndays >= 7
echo "Verifying user password warning settings..."
ALL_USERS_VALID=true
for user in $(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow); do
    WARN_DAYS=$(chage -l "$user" 2>/dev/null | grep "Number of days of warning" | awk -F: '{print $2}' | tr -d ' ')
    if [ -n "$WARN_DAYS" ] && [ "$WARN_DAYS" -ge 7 ]; then
        echo "SUCCESS: User $user has warndays=$WARN_DAYS"
    elif [ -n "$WARN_DAYS" ]; then
        echo "ERROR: User $user has warndays=$WARN_DAYS (should be >= 7)"
        ALL_USERS_VALID=false
    fi
done

if [ "$ALL_USERS_VALID" = true ]; then
    echo "SUCCESS: All users have password warning >= 7 days"
else
    echo "ERROR: Some users have password warning < 7 days"
    exit 1
fi

# Verify at least some users were processed
USER_COUNT=$(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow | wc -l)
if [ "$USER_COUNT" -gt 0 ]; then
    echo "SUCCESS: Processed $USER_COUNT users with passwords"
else
    echo "WARNING: No users with passwords found to process"
fi

echo "CIS 4.5.1.3 remediation completed successfully"
echo "Password expiration warning is now set to 7 days or more for all users"