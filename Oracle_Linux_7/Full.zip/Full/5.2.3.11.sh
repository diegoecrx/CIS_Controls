#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-session.rules"

[ "$EUID" -eq 0 ] || exit 1

# Create rules file
{
    echo "-w /var/run/utmp -p wa -k session"
    echo "-w /var/log/wtmp -p wa -k session" 
    echo "-w /var/log/btmp -p wa -k session"
} > "$RULES_FILE"

echo "Created rules file:"
cat "$RULES_FILE"

# Load rules
echo "---"
echo "Loading rules:"
augenrules --load
auditctl -R "$RULES_FILE"

# Show proof
echo "---"
echo "Current loaded rules:"
auditctl -l | grep -E "(utmp|wtmp|btmp).*session"