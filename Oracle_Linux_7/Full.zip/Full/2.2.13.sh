#!/usr/bin/env bash
# Script: 2.2.13.sh
# Item: 2.2.13 Ensure rsync services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures rsync services are not in use by removing or masking the rsyncd.socket, rsyncd.service, and rsync package. FORCE VERSION - Comprehensive rsync removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.13.sh"
ITEM_NAME="2.2.13 Ensure rsync services are not in use (Automated)"
DESCRIPTION="This remediation ensures rsync services are not in use by removing or masking the rsyncd.socket, rsyncd.service, and rsync package. FORCE VERSION - Comprehensive rsync removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_rsync_status() {
  echo "Checking rsync server status..."
  if systemctl is-active rsyncd.service >/dev/null 2>&1; then
    echo " - rsyncd.service is active."
  fi
  if systemctl is-active rsyncd.socket >/dev/null 2>&1; then
    echo " - rsyncd.socket is active."
  fi
  if systemctl is-enabled rsyncd.service >/dev/null 2>&1; then
    echo " - rsyncd.service is enabled."
  fi
  if systemctl is-enabled rsyncd.socket >/dev/null 2>&1; then
    echo " - rsyncd.socket is enabled."
  fi
  if rpm -q rsync >/dev/null 2>&1; then
    echo " - rsync package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':873'; then
    echo " - rsync port 873 is open."
  fi
}

stop_rsync_service() {
  echo "Stopping rsyncd.socket and rsyncd.service..."
  systemctl stop rsyncd.socket rsyncd.service 2>/dev/null || true
  pkill -TERM rsync 2>/dev/null || true
  pkill -KILL rsync 2>/dev/null || true
}

remove_rsync_package() {
  local pkg_mgr="$1"
  echo "Removing rsync package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y rsync 2>/dev/null || echo " - WARNING: Could not remove rsync (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_rsync_service() {
  echo "Masking rsyncd.socket and rsyncd.service..."
  systemctl mask rsyncd.socket rsyncd.service 2>/dev/null || true
}

verify_rsync_removal() {
  echo "Verifying rsync server remediation..."
  local failed=false
  if rpm -q rsync >/dev/null 2>&1; then
    echo "FAIL: rsync package is still installed."
    failed=true
  fi
  for svc in rsyncd.socket rsyncd.service; do
    if systemctl is-enabled $svc 2>/dev/null | grep -vq masked; then
      echo "FAIL: $svc is not masked."
      failed=true
    fi
    if systemctl is-active $svc 2>/dev/null | grep -vq inactive; then
      echo "FAIL: $svc is still active."
      failed=true
    fi
  done
  if ss -tulpn 2>/dev/null | grep -Eq ':873'; then
    echo "FAIL: rsync port 873 is still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_rsync_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING RSYNCD SERVER SERVICE"
echo "==================================================================="
echo ""

stop_rsync_service
remove_rsync_package "$PKG_MGR"
mask_rsync_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_rsync_removal; then
  echo "SUCCESS: rsync server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: rsync server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q rsync"
  echo "2. Ensure services are masked: systemctl status rsyncd.service rsyncd.socket"
  echo "3. Check port: ss -tulpn | grep ':873'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
