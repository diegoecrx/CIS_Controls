#!/usr/bin/env bash
# Script: 4.3.1.sh
# Item: 4.3.1 Ensure sudo is installed (Automated)
set -euo pipefail
SCRIPT_NAME="4.3.1.sh"
ITEM_NAME="4.3.1 Ensure sudo is installed (Automated)"
DESCRIPTION="This remediation ensures sudo is installed using yum."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking if sudo is installed..."
    if rpm -q sudo >/dev/null 2>&1; then
        echo "PASS: sudo is installed"
        echo "PROOF: $(rpm -q sudo)"
        return 0
    else
        echo "FAIL: sudo is not installed"
        echo "PROOF: rpm -q sudo returned not installed"
        return 1
    fi
}
# Function to install
install_sudo() {
    echo "Installing sudo..."
    yum install -y sudo >/dev/null 2>&1
    echo " - Installed sudo"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        install_sudo
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: sudo installed"
    else
        echo "FAIL: sudo not installed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="