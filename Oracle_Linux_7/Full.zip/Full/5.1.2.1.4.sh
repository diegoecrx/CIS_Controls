#!/usr/bin/env bash
# Script: 5.1.2.1.4.sh
# Item: 5.1.2.1.4 Ensure journald is not configured to receive logs from a remote client (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.2.1.4.sh"
ITEM_NAME="5.1.2.1.4 Ensure journald is not configured to receive logs from a remote client (Automated)"
DESCRIPTION="This remediation ensures journald is not configured to receive logs from remote clients by masking systemd-journal-remote.socket."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to force remediation
force_remediate_journald_remote() {
    echo "Forcing remediation for journald remote client configuration..."
    
    # Stop the socket if it's running
    if systemctl is-active systemd-journal-remote.socket >/dev/null 2>&1; then
        echo " - Stopping systemd-journal-remote.socket"
        systemctl stop systemd-journal-remote.socket || true
    fi
    
    # Disable the socket if it's enabled
    if systemctl is-enabled systemd-journal-remote.socket >/dev/null 2>&1; then
        echo " - Disabling systemd-journal-remote.socket"
        systemctl disable systemd-journal-remote.socket || true
    fi
    
    # Force mask the socket (this creates the symlink to /dev/null)
    echo " - Masking systemd-journal-remote.socket"
    systemctl mask systemd-journal-remote.socket || true
    
    # Ensure the symlink exists directly as backup method
    if [ ! -L "/etc/systemd/system/systemd-journal-remote.socket" ]; then
        echo " - Creating direct symlink to /dev/null"
        ln -sf /dev/null /etc/systemd/system/systemd-journal-remote.socket || true
    fi
    
    # Reload systemd to recognize changes
    echo " - Reloading systemd daemon"
    systemctl daemon-reload
    
    # Additional verification method - check if socket file exists and is a symlink to /dev/null
    if [ -L "/etc/systemd/system/systemd-journal-remote.socket" ] && \
       [ "$(readlink -f /etc/systemd/system/systemd-journal-remote.socket)" = "/dev/null" ]; then
        echo " - Verified: systemd-journal-remote.socket is properly masked"
    fi
    
    echo " - Remediation completed"
}

# Function to verify remediation
verify_remediation() {
    echo "Verifying remediation..."
    local success=true
    
    # Check 1: Verify masked via systemctl
    if ! systemctl is-masked systemd-journal-remote.socket >/dev/null 2>&1; then
        echo "WARNING: systemctl reports socket is not masked"
        # Continue verification - this might be a systemd timing issue
    else
        echo "PASS: systemctl confirms socket is masked"
    fi
    
    # Check 2: Verify not active
    if systemctl is-active systemd-journal-remote.socket >/dev/null 2>&1; then
        echo "FAIL: Socket is still active"
        success=false
    else
        echo "PASS: Socket is not active"
    fi
    
    # Check 3: Verify symlink exists and points to /dev/null
    if [ -L "/etc/systemd/system/systemd-journal-remote.socket" ] && \
       [ "$(readlink -f /etc/systemd/system/systemd-journal-remote.socket)" = "/dev/null" ]; then
        echo "PASS: Symlink properly configured to /dev/null"
    else
        echo "FAIL: Symlink not properly configured"
        success=false
    fi
    
    # Final determination
    if $success; then
        echo "SUCCESS: journald is not configured to receive logs from remote clients"
        return 0
    else
        echo "FAIL: Some issues remain after remediation"
        return 1
    fi
}

# Main remediation - always force the remediation
{
    echo "Starting automatic remediation..."
    force_remediate_journald_remote
    echo ""
    
    # Wait a moment for systemd to settle
    sleep 2
    
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    if verify_remediation; then
        echo "Remediation completed successfully"
    else
        echo "Remediation applied but verification shows issues - manual review recommended"
        # Exit with error code to indicate partial success
        exit 1
    fi
}

echo ""
echo "==================================================================="
echo "Remediation process completed for: $ITEM_NAME"
echo "==================================================================="