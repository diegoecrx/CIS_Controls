#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

echo "Current permissions before changes:"
ls -ld /etc/cron.monthly
echo ""

echo "Applying ownership and permissions..."
chown root:root /etc/cron.monthly
chmod og-rwx /etc/cron.monthly

echo "Permissions after changes:"
ls -ld /etc/cron.monthly
echo ""

echo "Detailed stat output:"
stat -c "Owner: %U" /etc/cron.monthly
stat -c "Group: %G" /etc/cron.monthly  
stat -c "Permissions: %a" /etc/cron.monthly
echo ""

# Verify with multiple methods
OWNER=$(stat -c "%U" /etc/cron.monthly)
GROUP=$(stat -c "%G" /etc/cron.monthly)
PERMS=$(stat -c "%a" /etc/cron.monthly)
SYMBOLIC_PERMS=$(stat -c "%A" /etc/cron.monthly)

echo "Verification:"
echo "Owner: $OWNER (required: root)"
echo "Group: $GROUP (required: root)" 
echo "Permissions: $PERMS (required: 700)"
echo "Symbolic: $SYMBOLIC_PERMS (required: drwx------)"
echo ""

if [[ "$OWNER" == "root" && "$GROUP" == "root" && "$PERMS" == "700" ]]; then
    echo "pass"
else
    echo "FAIL: /etc/cron.monthly permissions configuration failed"
    echo "Expected: root:root 700"
    echo "Actual: $OWNER:$GROUP $PERMS"
    exit 1
fi