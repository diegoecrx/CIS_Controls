#!/usr/bin/env bash
# Script: 6.1.11.sh
# Item: 6.1.11 Ensure world writable files and directories are secured (Automated)
set -euo pipefail
SCRIPT_NAME="6.1.11.sh"
ITEM_NAME="6.1.11 Ensure world writable files and directories are secured (Automated)"
DESCRIPTION="This remediation removes write permissions from world writable files and adds sticky bit to world writable directories."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check world writable files and directories
check_world_writable() {
    echo "Checking for world writable files and directories..."
    l_smask='01000'
    a_arr=()
    
    # Build exclusion paths
    a_path=(
        ! -path "/run/user/*"
        ! -path "/proc/*"
        ! -path "*/containerd/*"
        ! -path "*/kubelet/pods/*"
        ! -path "/sys/kernel/security/apparmor/*"
        ! -path "/snap/*"
        ! -path "/sys/fs/cgroup/memory/*"
        ! -path "/sys/fs/selinux/*"
    )
    
    # Find NFS, proc, smb mount points and add to exclusions
    while IFS= read -r l_bfs; do
        a_path+=( ! -path "$l_bfs/*" )
    done < <(findmnt -Dkerno fstype,target 2>/dev/null | awk '$1 ~ /^[[:space:]]*(nfs|proc|smb)/ {print $2}' || true)
    
    # Collect world writable files and directories
    local ww_count=0
    while IFS= read -r -d $'\0' l_file; do
        if [ -e "$l_file" ]; then
            if [ -f "$l_file" ]; then
                echo "FAIL: World writable file found: $l_file"
                ww_count=$((ww_count + 1))
            elif [ -d "$l_file" ]; then
                l_mode=$(stat -Lc '%#a' "$l_file")
                if [ ! $(( ${l_mode#0o} & 0o1000 )) -gt 0 ]; then
                    echo "FAIL: World writable directory without sticky bit: $l_file"
                    ww_count=$((ww_count + 1))
                fi
            fi
        fi
    done < <(find / "${a_path[@]}" \( -type f -o -type d \) -perm -0002 -print0 2>/dev/null || true)
    
    if [ "$ww_count" -eq 0 ]; then
        echo "PASS: No unsecured world writable files or directories found"
        return 0
    else
        echo "PROOF: Found $ww_count world writable files/directories that need fixing"
        return 1
    fi
}
# Function to fix world writable files and directories
fix_world_writable() {
    echo "Fixing world writable files and directories..."
    l_smask='01000'
    a_arr=()
    
    # Build exclusion paths
    a_path=(
        ! -path "/run/user/*"
        ! -path "/proc/*"
        ! -path "*/containerd/*"
        ! -path "*/kubelet/pods/*"
        ! -path "/sys/kernel/security/apparmor/*"
        ! -path "/snap/*"
        ! -path "/sys/fs/cgroup/memory/*"
        ! -path "/sys/fs/selinux/*"
    )
    
    # Find NFS, proc, smb mount points and add to exclusions
    while IFS= read -r l_bfs; do
        a_path+=( ! -path "$l_bfs/*" )
    done < <(findmnt -Dkerno fstype,target 2>/dev/null | awk '$1 ~ /^[[:space:]]*(nfs|proc|smb)/ {print $2}' || true)
    
    # Populate array with files and directories
    while IFS= read -r -d $'\0' l_file; do
        [ -e "$l_file" ] && a_arr+=("$(stat -Lc '%n^%#a' "$l_file")")
    done < <(find / "${a_path[@]}" \( -type f -o -type d \) -perm -0002 -print0 2>/dev/null || true)
    
    # Process each entry
    while IFS="^" read -r l_fname l_mode; do
        if [ -f "$l_fname" ]; then
            echo " - File: \"$l_fname\" is mode: \"$l_mode\" - removing write permission from other"
            chmod o-w "$l_fname"
        fi
        if [ -d "$l_fname" ]; then
            l_mode_dec=$((${l_mode#0o} & 0o1000))
            if [ "$l_mode_dec" -eq 0 ]; then
                echo " - Directory: \"$l_fname\" is mode: \"$l_mode\" - adding sticky bit"
                chmod a+t "$l_fname"
            fi
        fi
    done < <(printf '%s\n' "${a_arr[@]}")
}
# Main remediation
{
    ww_ok=true
    if ! check_world_writable; then
        ww_ok=false
    fi
    if [ "$ww_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_world_writable
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_world_writable; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: World writable files and directories are secured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
