#!/bin/bash

# Enforce CIS 4.4.2.3.1 - Ensure pam_pwhistory module is enabled
echo "Enforcing CIS 4.4.2.3.1 - pam_pwhistory module configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure pam_pwhistory for both files
for file in system-auth password-auth; do
    echo "Configuring pam_pwhistory in /etc/pam.d/${file}..."
    
    # Remove existing pam_pwhistory entries to avoid duplicates
    sed -i '/pam_pwhistory\.so/d' "/etc/pam.d/${file}"
    
    # Add pam_pwhistory after pam_pwquality in password section
    if grep -q "^password.*pam_pwquality\.so" "/etc/pam.d/${file}"; then
        # Insert pam_pwhistory after pam_pwquality
        sed -i '/^password.*pam_pwquality\.so/a password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' "/etc/pam.d/${file}"
    else
        # If pam_pwquality not found, add as second password entry
        if grep -q "^password" "/etc/pam.d/${file}"; then
            # Insert as second password entry
            sed -i '0,/^password.*/!{0,/^password.*/s/^password.*/password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok\n&/}' "/etc/pam.d/${file}"
        else
            # Add password section if it doesn't exist
            echo "password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok" >> "/etc/pam.d/${file}"
        fi
    fi
    
    # Ensure use_authtok is added to subsequent password lines (except pam_deny.so)
    sed -i '/^password.*pam_pwhistory\.so/!{/^password.*pam_deny\.so/!{/^password.*use_authtok/!s/^\(password.*\)$/\1 use_authtok/}}' "/etc/pam.d/${file}"
done

# Verify configuration
echo "Verifying pam_pwhistory configuration..."

# Check for required configuration in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if pam_pwhistory is configured with required parameters
    if grep -q "^password.*required.*pam_pwhistory\.so.*remember=24.*enforce_for_root.*try_first_pass.*use_authtok" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_pwhistory configured with required parameters in ${file}"
    else
        echo "ERROR: pam_pwhistory not properly configured in ${file}"
        exit 1
    fi
    
    # Verify remember=24 parameter exists
    if grep -q "pam_pwhistory\.so.*remember=24" "/etc/pam.d/${file}"; then
        echo "SUCCESS: remember=24 configured in ${file}"
    else
        echo "ERROR: remember=24 not configured in ${file}"
        exit 1
    fi
    
    # Verify enforce_for_root parameter exists
    if grep -q "pam_pwhistory\.so.*enforce_for_root" "/etc/pam.d/${file}"; then
        echo "SUCCESS: enforce_for_root configured in ${file}"
    else
        echo "ERROR: enforce_for_root not configured in ${file}"
        exit 1
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.3.1 remediation completed successfully"
echo "Password history is now enforced - remembers last 24 passwords including for root"