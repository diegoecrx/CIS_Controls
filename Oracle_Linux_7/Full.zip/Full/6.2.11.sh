#!/usr/bin/env bash
# Script: 6.2.11.sh
# Item: 6.2.11 Ensure local interactive user dot files access is configured (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.11.sh"
ITEM_NAME="6.2.11 Ensure local interactive user dot files access is configured (Automated)"
DESCRIPTION="This remediation secures dot files in interactive users' home directories."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Build regex for valid shells (not nologin)
l_valid_shells="^($( awk -F/ '$NF != "nologin" {print $NF}' /etc/shells | sed 's/^/\//; s/$/\\$/' | tr '\n' '|' | sed 's/|$//' ))$"

# Function to get interactive users and home directories
get_interactive_users() {
    awk -v pat="$l_valid_shells" -F: '$NF ~ pat {print $1 " " $(NF-1)}' /etc/passwd
}

# Function to check dot file access
check_dot_file_access() {
    echo "Checking dot file access in user home directories..."
    dotfile_issues=""
    dangerous_files=""
    
    while read -r l_user l_home; do
        if [ -d "$l_home" ]; then
            while IFS= read -r -d $'\0' l_hdfile; do
                if [ -f "$l_hdfile" ]; then
                    l_mode=$(stat -Lc '%#a' "$l_hdfile")
                    l_owner=$(stat -Lc '%U' "$l_hdfile")
                    l_gowner=$(stat -Lc '%G' "$l_hdfile")
                    
                    case "$(basename "$l_hdfile")" in
                        .forward|.rhost )
                            dangerous_files="$dangerous_files\n - User: $l_user, File: $l_hdfile (exists - should be manually deleted)"
                            ;;
                        .netrc )
                            # .netrc should be mode 0600 (owner read/write only)
                            if [ "$((${l_mode#0o} & 0o177))" -ne 0 ]; then
                                dotfile_issues="$dotfile_issues\n - User: $l_user, File: $l_hdfile, Mode: $l_mode (should be 0600)"
                            fi
                            ;;
                        .bash_history|.history )
                            # History files should be mode 0600
                            if [ "$((${l_mode#0o} & 0o177))" -ne 0 ]; then
                                dotfile_issues="$dotfile_issues\n - User: $l_user, File: $l_hdfile, Mode: $l_mode (should be 0600)"
                            fi
                            ;;
                        * )
                            # Other dot files should be mode 0600 or more restrictive
                            if [ "$((${l_mode#0o} & 0o133))" -ne 0 ]; then
                                dotfile_issues="$dotfile_issues\n - User: $l_user, File: $l_hdfile, Mode: $l_mode (should be 0600 or similar)"
                            fi
                            ;;
                    esac
                    
                    # Check ownership
                    if [ "$l_owner" != "$l_user" ]; then
                        dotfile_issues="$dotfile_issues\n - User: $l_user, File: $l_hdfile, Owner: $l_owner (should be $l_user)"
                    fi
                fi
            done < <(find "$l_home" -xdev -type f -name '.*' -print0 2>/dev/null)
        fi
    done < <(get_interactive_users)
    
    if [ -z "$dotfile_issues" ] && [ -z "$dangerous_files" ]; then
        echo "PASS: All user dot files have correct permissions"
        echo "PROOF: No permission or ownership issues found"
        return 0
    else
        if [ -n "$dotfile_issues" ]; then
            echo "FAIL: Found dot files with incorrect permissions/ownership:"
            echo -e "$dotfile_issues"
        fi
        if [ -n "$dangerous_files" ]; then
            echo "FAIL: Found dangerous dot files that should be deleted:"
            echo -e "$dangerous_files"
        fi
        return 1
    fi
}
# Function to fix dot file access
fix_dot_file_access() {
    echo "Fixing dot file access..."
    
    while read -r l_user l_home; do
        if [ -d "$l_home" ]; then
            echo " - Processing user: $l_user (home: $l_home)"
            l_uid=$(id -u "$l_user")
            l_gid=$(id -g "$l_user")
            
            while IFS= read -r -d $'\0' l_hdfile; do
                if [ -f "$l_hdfile" ]; then
                    case "$(basename "$l_hdfile")" in
                        .forward|.rhost )
                            echo "   - WARNING: File $l_hdfile exists - please investigate and manually delete"
                            ;;
                        .netrc )
                            chmod 0600 "$l_hdfile"
                            chown "$l_user:$l_uid" "$l_hdfile"
                            ;;
                        .bash_history|.history )
                            chmod 0600 "$l_hdfile"
                            chown "$l_user:$l_uid" "$l_hdfile"
                            ;;
                        * )
                            chmod 0600 "$l_hdfile"
                            chown "$l_user:$l_uid" "$l_hdfile"
                            ;;
                    esac
                fi
            done < <(find "$l_home" -xdev -type f -name '.*' -print0 2>/dev/null)
        fi
    done < <(get_interactive_users)
}
# Main remediation
{
    dotfile_ok=true
    if ! check_dot_file_access; then
        dotfile_ok=false
    fi
    if [ "$dotfile_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_dot_file_access
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_dot_file_access; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: All user dot files have correct access permissions"
    else
        echo "FAIL: Issues remain - please review warnings above"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
