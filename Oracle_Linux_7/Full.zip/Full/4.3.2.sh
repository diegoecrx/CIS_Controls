#!/bin/bash

# Enforce CIS 4.3.2 - Ensure sudo commands use pty
echo "Enforcing CIS 4.3.2 - sudo commands use pty..."

# Check if use_pty is already configured in sudoers
if ! grep -rq "^Defaults.*use_pty" /etc/sudoers /etc/sudoers.d/ 2>/dev/null; then
    echo "Adding Defaults use_pty to sudo configuration..."
    
    # Create a new file in sudoers.d with proper syntax
    if [ ! -f /etc/sudoers.d/cis_use_pty ]; then
        echo "Defaults use_pty" > /etc/sudoers.d/cis_use_pty
        chmod 440 /etc/sudoers.d/cis_use_pty
        echo "Created /etc/sudoers.d/cis_use_pty with use_pty setting"
    else
        # Update existing file if it exists
        if grep -q "^Defaults" /etc/sudoers.d/cis_use_pty; then
            sed -i 's/^Defaults.*/Defaults use_pty/' /etc/sudoers.d/cis_use_pty
        else
            echo "Defaults use_pty" >> /etc/sudoers.d/cis_use_pty
        fi
        echo "Updated /etc/sudoers.d/cis_use_pty with use_pty setting"
    fi
else
    echo "use_pty is already configured in sudoers"
fi

# Verify configuration
echo "Verifying use_pty configuration..."

# Check if use_pty is now configured
if grep -rq "^Defaults.*use_pty" /etc/sudoers /etc/sudoers.d/ 2>/dev/null; then
    echo "SUCCESS: use_pty is configured in sudoers"
else
    echo "ERROR: use_pty is not configured in sudoers"
    exit 1
fi

# Validate sudoers syntax
if visudo -c > /dev/null 2>&1; then
    echo "SUCCESS: sudoers configuration syntax is valid"
else
    echo "ERROR: sudoers configuration syntax is invalid"
    # Attempt to restore from backup if available
    if [ -f /etc/sudoers.d/cis_use_pty ]; then
        rm -f /etc/sudoers.d/cis_use_pty
        echo "Removed problematic configuration file"
    fi
    exit 1
fi

# Check file permissions
if [ -f /etc/sudoers.d/cis_use_pty ]; then
    PERMS=$(stat -c %a /etc/sudoers.d/cis_use_pty)
    if [ "$PERMS" = "440" ]; then
        echo "SUCCESS: sudoers.d file has correct permissions (440)"
    else
        echo "WARNING: sudoers.d file has incorrect permissions, correcting..."
        chmod 440 /etc/sudoers.d/cis_use_pty
    fi
fi

echo "CIS 4.3.2 remediation completed successfully"