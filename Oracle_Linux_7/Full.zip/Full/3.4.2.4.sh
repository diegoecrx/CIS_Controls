#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check if firewalld is active
if ! systemctl is-active firewalld >/dev/null 2>&1; then
    echo "FAIL: firewalld is not active"
    echo "EVIDENCE: systemctl is-active firewalld returned inactive"
    exit 1
fi

# Get network interfaces and their zone assignments using the exact compliance check method
echo "Checking network interface zone assignments:"
echo ""

# Run the exact compliance check command
COMPLIANCE_OUTPUT=$(/bin/find /sys/class/net/* -maxdepth 1 | /bin/awk -F"/" '{print $NF}' | while read -r netint; do [ "$netint" != "lo" ] && /bin/firewall-cmd --get-active-zones | /bin/grep -B1 "$netint"; done)

echo "Compliance check output:"
echo "$COMPLIANCE_OUTPUT"

# Get additional evidence for manual review
echo ""
echo "Additional evidence for manual review:"
echo "======================================"

# List all network interfaces
echo "1. All network interfaces:"
ip -o link show | awk -F': ' '{print $2}' | grep -v lo
echo ""

# Show active zones with interfaces
echo "2. Active zones and interface assignments:"
firewall-cmd --get-active-zones
echo ""

# Show default zone
echo "3. Default zone:"
firewall-cmd --get-default-zone
echo ""

# Show detailed zone information
echo "4. Detailed zone configurations:"
ACTIVE_ZONES=$(firewall-cmd --get-active-zones | grep -v '^ ' | head -5)
for zone in $ACTIVE_ZONES; do
    echo "Zone: $zone"
    firewall-cmd --list-all --zone="$zone" | head -10
    echo ""
done

# Verification result
echo "MANUAL REVIEW REQUIRED: Network interface zone assignments need manual verification"
echo "EVIDENCE: Interface zone assignments found - review if zones match network topology"
echo ""
echo "Current assignments:"
echo "$COMPLIANCE_OUTPUT"
echo ""
echo "Required action: Verify each interface is in the appropriate zone for its network role"
exit 1