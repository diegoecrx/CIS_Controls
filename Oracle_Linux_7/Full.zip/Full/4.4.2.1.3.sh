#!/bin/bash

# Enforce CIS 4.4.2.1.3 - Ensure password unlock time is configured
echo "Enforcing CIS 4.4.2.1.3 - Password unlock time configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure password unlock time for both files
for file in system-auth password-auth; do
    echo "Configuring unlock time in /etc/pam.d/${file}..."
    
    # Remove existing pam_faillock entries to avoid duplicates
    sed -i '/pam_faillock\.so/d' "/etc/pam.d/${file}"
    
    # Add preauth line with unlock_time=900 after pam_env.so
    if grep -q "auth.*required.*pam_env\.so" "/etc/pam.d/${file}"; then
        sed -i '/auth.*required.*pam_env\.so/a auth        required      pam_faillock.so preauth silent audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
    else
        # If pam_env.so not found, add at beginning of auth section
        sed -i '/^auth/iauth        required      pam_faillock.so preauth silent audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
    fi
    
    # Add authfail line with unlock_time=900 as last auth entry
    if grep -q "auth.*requisite.*pam_succeed_if\.so" "/etc/pam.d/${file}"; then
        sed -i '/auth.*requisite.*pam_succeed_if\.so/iauth        [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
    else
        # If pam_succeed_if.so not found, look for pam_deny.so
        if grep -q "auth.*required.*pam_deny\.so" "/etc/pam.d/${file}"; then
            sed -i '/auth.*required.*pam_deny\.so/iauth        [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
        else
            # Add at the end of auth section as fallback
            sed -i '/^auth.*/aauth        [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
        fi
    fi
    
    # Add account required pam_faillock.so
    if grep -q "^account" "/etc/pam.d/${file}"; then
        # Insert at beginning of account section
        sed -i '0,/^account.*/s/^account.*/account     required      pam_faillock.so\n&/' "/etc/pam.d/${file}"
    else
        # Add after last auth section
        sed -i '$a account     required      pam_faillock.so' "/etc/pam.d/${file}"
    fi
done

# Verify configuration
echo "Verifying password unlock time configuration..."

# Check for required unlock_time configuration in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check preauth line with unlock_time=900
    if grep -q "auth.*required.*pam_faillock\.so.*preauth.*unlock_time=900" "/etc/pam.d/${file}"; then
        echo "SUCCESS: preauth with unlock_time=900 configured in ${file}"
    else
        echo "ERROR: preauth unlock_time configuration incorrect or missing in ${file}"
        exit 1
    fi
    
    # Check authfail line with unlock_time=900
    if grep -q "auth.*\[default=die\].*pam_faillock\.so.*authfail.*unlock_time=900" "/etc/pam.d/${file}"; then
        echo "SUCCESS: authfail with unlock_time=900 configured in ${file}"
    else
        echo "ERROR: authfail unlock_time configuration incorrect or missing in ${file}"
        exit 1
    fi
    
    # Verify unlock_time=900 parameter exists in both preauth and authfail
    PREAUTH_UNLOCK=$(grep "pam_faillock.*preauth" "/etc/pam.d/${file}" | grep -o "unlock_time=900")
    AUTHFAIL_UNLOCK=$(grep "pam_faillock.*authfail" "/etc/pam.d/${file}" | grep -o "unlock_time=900")
    
    if [ "$PREAUTH_UNLOCK" = "unlock_time=900" ] && [ "$AUTHFAIL_UNLOCK" = "unlock_time=900" ]; then
        echo "SUCCESS: unlock_time=900 configured in both preauth and authfail in ${file}"
    else
        echo "ERROR: unlock_time=900 not properly configured in ${file}"
        exit 1
    fi
    
    # Verify both entries have the full required parameter set
    FULL_CONFIG_PREAUTH=$(grep "pam_faillock.*preauth.*silent.*audit.*deny=5.*unlock_time=900.*even_deny_root" "/etc/pam.d/${file}")
    FULL_CONFIG_AUTHFAIL=$(grep "pam_faillock.*authfail.*audit.*deny=5.*unlock_time=900.*even_deny_root" "/etc/pam.d/${file}")
    
    if [ -n "$FULL_CONFIG_PREAUTH" ] && [ -n "$FULL_CONFIG_AUTHFAIL" ]; then
        echo "SUCCESS: Complete pam_faillock configuration verified in ${file}"
    else
        echo "ERROR: Incomplete pam_faillock configuration in ${file}"
        exit 1
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.1.3 remediation completed successfully"
echo "WARNING: Accounts will be locked for 900 seconds (15 minutes) after 5 failed attempts"
echo "Test authentication carefully to ensure proper functionality"