#!/usr/bin/env bash
# Script: 6.2.4.sh
# Item: 6.2.4 Ensure no duplicate UIDs exist (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.4.sh"
ITEM_NAME="6.2.4 Ensure no duplicate UIDs exist (Automated)"
DESCRIPTION="This remediation ensures no duplicate UIDs exist in /etc/passwd."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for duplicate UIDs in /etc/passwd..."
    
    # Check if /etc/passwd exists
    if [ ! -f /etc/passwd ]; then
        echo "FAIL: /etc/passwd does not exist"
        echo "PROOF: File /etc/passwd not found"
        return 1
    fi
    
    # Find duplicate UIDs
    duplicate_uids=()
    while read -r uid; do
        # Get usernames for this UID
        usernames=$(awk -F: -v uid="$uid" '$3==uid {print $1}' /etc/passwd | sort)
        username_count=$(echo "$usernames" | wc -l)
        
        if [ "$username_count" -gt 1 ]; then
            duplicate_uids+=("$uid:$(echo "$usernames" | tr '\n' ',')")
        fi
    done < <(awk -F: '{print $3}' /etc/passwd | sort -n | uniq -d)
    
    if [ ${#duplicate_uids[@]} -gt 0 ]; then
        echo "FAIL: Duplicate UIDs found"
        echo "PROOF: UIDs with multiple usernames:"
        for entry in "${duplicate_uids[@]}"; do
            uid=$(echo "$entry" | cut -d: -f1)
            usernames=$(echo "$entry" | cut -d: -f2 | sed 's/,$//')
            echo "  UID $uid: $usernames"
        done
        return 1
    fi
    
    echo "PASS: No duplicate UIDs found"
    echo "PROOF: All UIDs in /etc/passwd are unique"
    return 0
}
# Function to fix
fix_duplicate_uids() {
    echo "Applying fix..."
    
    # Check if /etc/passwd exists
    if [ ! -f /etc/passwd ]; then
        echo " - ERROR: /etc/passwd does not exist - cannot proceed"
        return 1
    fi
    
    echo " - Scanning /etc/passwd for duplicate UIDs..."
    
    # Find duplicate UIDs and collect information
    declare -A uid_users
    duplicate_found=false
    
    while IFS=: read -r username password uid gid gecos home shell; do
        if [ -n "$uid" ]; then
            if [ -n "${uid_users[$uid]:-}" ]; then
                uid_users[$uid]="${uid_users[$uid]},$username"
                duplicate_found=true
            else
                uid_users[$uid]="$username"
            fi
        fi
    done < /etc/passwd
    
    if [ "$duplicate_found" = false ]; then
        echo " - No duplicate UIDs found"
        return 0
    fi
    
    echo " - Found duplicate UIDs, analyzing..."
    
    # Process duplicates
    for uid in "${!uid_users[@]}"; do
        users="${uid_users[$uid]}"
        if [[ "$users" == *","* ]]; then
            echo " - Duplicate UID $uid found for users: $users"
            
            # Convert comma-separated users to array
            IFS=',' read -ra user_array <<< "$users"
            
            # Keep the first user with the original UID, assign new UIDs to others
            first_user="${user_array[0]}"
            echo " - Keeping UID $uid for user: $first_user"
            
            for ((i=1; i<${#user_array[@]}; i++)); do
                duplicate_user="${user_array[$i]}"
                
                # Find the next available UID starting from 1000
                new_uid=1000
                while grep -q ":$new_uid:" /etc/passwd; do
                    ((new_uid++))
                done
                
                echo " - Assigning new UID $new_uid to user: $duplicate_user"
                
                # Update /etc/passwd
                sed -i "s/^\($duplicate_user:[^:]*:\)$uid:/\1$new_uid:/" /etc/passwd
                
                # Update file ownership for the user's files
                echo " - Updating file ownership for user $duplicate_user (UID $uid -> $new_uid)"
                find / -xdev -user "$uid" -exec chown "$new_uid" {} \; 2>/dev/null || true
                
                # Update /etc/shadow if it exists
                if [ -f /etc/shadow ]; then
                    # Shadow file doesn't contain UIDs, so no changes needed
                    :
                fi
                
                # Update /etc/group if user has a private group
                if grep -q "^$duplicate_user:" /etc/group; then
                    sed -i "s/^\($duplicate_user:[^:]*:\)$uid:/\1$new_uid:/" /etc/group
                fi
            done
        fi
    done
    
    echo " - Duplicate UIDs remediation completed"
    echo " - NOTE: File ownership has been updated for affected users"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_duplicate_uids
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: No duplicate UIDs found"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="