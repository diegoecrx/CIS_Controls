#!/bin/bash
set -euo pipefail

DEFAULT_PASSWORD="@Real2014NewYeah_"

[ "$EUID" -eq 0 ] || { echo "Must be run as root" >&2; exit 1; }

echo "=== Fixing Password Change Dates ==="
echo "Users with 'never changed' or future-dated passwords will be updated automatically."
echo ""

today_days=$(( $(date +%s) / 86400 ))
users_changed=0

for user in $(awk -F: '$2 !~ /^[!*]/ && $2 != "" {print $1}' /etc/shadow); do
    echo "--- Checking: $user ---"
    
    # Get password info
    shadow_entry=$(grep "^$user:" /etc/shadow)
    IFS=: read -r _ _ last_change_days _ _ _ _ _ _ <<< "$shadow_entry"
    
    # Get readable date
    last_change_str=$(chage -l "$user" 2>/dev/null | grep "Last password change" | awk -F: '{print $2}' | xargs)
    
    # Check if password needs attention
    needs_change=0
    
    if [[ -z "$last_change_days" || "$last_change_days" -eq 0 ]]; then
        echo "STATUS: Password has NEVER been changed"
        needs_change=1
    elif [[ "$last_change_days" -gt "$today_days" ]]; then
        echo "STATUS: Password change date is in FUTURE: $last_change_str"
        needs_change=1
    else
        echo "STATUS: OK - Last changed: $last_change_str"
    fi
    
    if [[ $needs_change -eq 1 ]]; then
        echo "Setting password for $user..."
        if echo "$user:$DEFAULT_PASSWORD" | chpasswd; then
            echo "✓ Password changed successfully"
            chage -d "$(date +%Y-%m-%d)" "$user"
            ((users_changed++))
        else
            echo "✗ Password change failed"
        fi
    fi
    
    echo ""
done

echo "=== Verification ==="
echo "Password change dates:"
echo "---------------------"
for user in $(awk -F: '$2 !~ /^[!*]/ && $2 != "" {print $1}' /etc/shadow); do
    last_change=$(chage -l "$user" 2>/dev/null | grep "Last password change" | awk -F: '{print $2}' | xargs)
    printf "%-20s: %s\n" "$user" "$last_change"
done

echo ""
echo "Summary: Changed passwords for $users_changed user(s)"