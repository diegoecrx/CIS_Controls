#!/bin/bash
set -euo pipefail

# Must be root
[[ $EUID -eq 0 ]] || exit 1

# Force fix: configure all repos to skip if unavailable
find /etc/yum.repos.d -name "*.repo" -type f | while read -r repo_file; do
    awk -F'[=\[]' '/^\[.*\]$/ {gsub(/[[:space:]]|]/, "", $2); print $2}' "$repo_file" | \
    while read -r repo_id; do
        yum-config-manager --save --setopt="${repo_id}.skip_if_unavailable=1" >/dev/null 2>&1
    done
done

# Force disable problematic repos
for repo in ol7_UEKR6 ol7_latest ol7_optional_latest; do
    yum-config-manager --disable "$repo" >/dev/null 2>&1
done

# Force yum configuration resilience
{
    grep -q "^skip_if_unavailable=" /etc/yum.conf || echo "skip_if_unavailable=1"
    grep -q "^tolerant=" /etc/yum.conf || echo "tolerant=1"
    grep -q "^retries=" /etc/yum.conf || echo "retries=5"
    grep -q "^timeout=" /etc/yum.conf || echo "timeout=60"
} >> /etc/yum.conf

# Force clean all caches
yum clean all --disablerepo="*" >/dev/null 2>&1
rm -rf /var/cache/yum/* 2>/dev/null || true

# Force makecache with only base repo
yum makecache --disablerepo="*" --enablerepo="ol7_base_latest" >/dev/null 2>&1 || true

# Force install function - tries everything
force_install() {
    local pkg="$1"
    
    # Check if already installed
    rpm -q "$pkg" >/dev/null 2>&1 && return 0
    
    # Method 1: Try with disabled problematic repos
    yum install -y --disablerepo="ol7_UEKR6,ol7_latest,ol7_optional_latest" "$pkg" --skip-broken >/dev/null 2>&1 && return 0
    
    # Method 2: Try with only base repo
    yum install -y --disablerepo="*" --enablerepo="ol7_base_latest" "$pkg" --skip-broken >/dev/null 2>&1 && return 0
    
    # Method 3: Force with nodeps
    yum install -y "$pkg" --nogpgcheck --skip-broken --noplugins >/dev/null 2>&1 && return 0
    
    # Method 4: Download and force install
    yumdownloader "$pkg" --disablerepo="*" --enablerepo="ol7_base_latest" >/dev/null 2>&1
    local rpm_file=$(find . -name "${pkg}*.rpm" -type f | head -1)
    [[ -f "$rpm_file" ]] && rpm -Uvh --nodeps --force "$rpm_file" >/dev/null 2>&1 && return 0
    
    return 1
}

# Force install iptables-services if not present
if ! rpm -q iptables-services >/dev/null 2>&1; then
    force_install "iptables-services"
    
    # Verify and enable if installed
    if rpm -q iptables-services >/dev/null 2>&1; then
        systemctl enable iptables >/dev/null 2>&1
        systemctl enable ip6tables >/dev/null 2>&1
        systemctl start iptables >/dev/null 2>&1
        systemctl start ip6tables >/dev/null 2>&1
    fi
fi

# Force verify
rpm -q iptables-services
systemctl is-active iptables 2>/dev/null || echo "iptables:inactive"
systemctl is-active ip6tables 2>/dev/null || echo "ip6tables:inactive"