#!/bin/bash
set -euo pipefail

# Must be root
[[ $EUID -eq 0 ]] && exit 1

echo "Starting repository repair..."

# Ensure yum-utils is present for yum-config-manager
rpm -q yum-utils >/dev/null 2>&1 || yum install -y yum-utils

# Force fix: configure all repos to skip if unavailable
# FIX: Replaced buggy awk with sed to safely extract repo IDs
find /etc/yum.repos.d -name "*.repo" -type f | while read -r repo_file; do
    grep "^\[.*\]$" "$repo_file" | sed 's/^\[//; s/\]$//' | while read -r repo_id; do
        yum-config-manager --save --setopt="${repo_id}.skip_if_unavailable=1" >/dev/null 2>&1
    done
done

# Force disable problematic repos
for repo in ol7_UEKR6 ol7_latest ol7_optional_latest; do
    yum-config-manager --disable "$repo" >/dev/null 2>&1 || true
done

# Force yum configuration resilience
# FIX: Added explicit block grouping for the append operation
{
    grep -q "^skip_if_unavailable=" /etc/yum.conf || echo "skip_if_unavailable=1"
    grep -q "^tolerant=" /etc/yum.conf || echo "tolerant=1"
    grep -q "^retries=" /etc/yum.conf || echo "retries=5"
    grep -q "^timeout=" /etc/yum.conf || echo "timeout=60"
} >> /etc/yum.conf

# Force clean all caches
yum clean all >/dev/null 2>&1
rm -rf /var/cache/yum/* 2>/dev/null || true

echo "Repository repair complete."
