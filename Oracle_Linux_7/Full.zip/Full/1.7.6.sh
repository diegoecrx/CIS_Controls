#!/usr/bin/env bash
# Script: 1.7.6.sh
# Item: 1.7.6 Ensure GDM automatic mounting of removable media is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.6.sh"
ITEM_NAME="1.7.6 Ensure GDM automatic mounting of removable media is disabled (Automated)"
DESCRIPTION="This remediation ensures GDM automatic mounting of removable media is disabled."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking GDM automatic mounting configuration..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    # Look for existing automount settings
    l_kfile="$(grep -Prils -- '^\h*automount\b' /etc/dconf/db/*.d 2>/dev/null | head -1)"
    l_kfile2="$(grep -Prils -- '^\h*automount-open\b' /etc/dconf/db/*.d 2>/dev/null | head -1)"
    
    # Check if automount is set to false
    if [ -n "$l_kfile" ]; then
        if ! grep -Pqs -- '^\h*automount\h*=\h*false\b' "$l_kfile"; then
            echo "FAIL: automount is not set to false"
            echo "PROOF: automount setting not disabled in $l_kfile"
            return 1
        fi
    else
        echo "FAIL: automount setting not configured"
        echo "PROOF: No automount configuration found"
        return 1
    fi
    
    # Check if automount-open is set to false
    if [ -n "$l_kfile2" ]; then
        if ! grep -Pqs -- '^\h*automount-open\h*=\h*false\b' "$l_kfile2"; then
            echo "FAIL: automount-open is not set to false"
            echo "PROOF: automount-open setting not disabled in $l_kfile2"
            return 1
        fi
    else
        echo "FAIL: automount-open setting not configured"
        echo "PROOF: No automount-open configuration found"
        return 1
    fi
    
    echo "PASS: GDM automatic mounting properly disabled"
    echo "PROOF: Both automount and automount-open set to false"
    return 0
}
# Function to fix
fix_gdm_automount() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    l_gpname="local"  # Set to desired dconf profile name
    
    # Look for existing settings and set variables if they exist
    l_kfile="$(grep -Prils -- '^\h*automount\b' /etc/dconf/db/*.d 2>/dev/null | head -1)"
    l_kfile2="$(grep -Prils -- '^\h*automount-open\b' /etc/dconf/db/*.d 2>/dev/null | head -1)"
    
    # Set profile name based on dconf db directory
    if [ -f "$l_kfile" ]; then
        l_gpname="$(awk -F\/ '{split($(NF-1),a,".");print a[1]}' <<< "$l_kfile")"
        echo " - Updating dconf profile name to $l_gpname"
    elif [ -f "$l_kfile2" ]; then
        l_gpname="$(awk -F\/ '{split($(NF-1),a,".");print a[1]}' <<< "$l_kfile2")"
        echo " - Updating dconf profile name to $l_gpname"
    fi
    
    # Check for consistency and clean up if needed
    if [ -f "$l_kfile" ] && [ "$(awk -F\/ '{split($(NF-1),a,".");print a[1]}' <<< "$l_kfile")" != "$l_gpname" ]; then
        sed -ri "/^\s*automount\s*=/s/^/# /" "$l_kfile"
        l_kfile="/etc/dconf/db/$l_gpname.d/00-media-automount"
    fi
    if [ -f "$l_kfile2" ] && [ "$(awk -F\/ '{split($(NF-1),a,".");print a[1]}' <<< "$l_kfile2")" != "$l_gpname" ]; then
        sed -ri "/^\s*automount-open\s*=/s/^/# /" "$l_kfile2"
    fi
    
    [ -z "$l_kfile" ] && l_kfile="/etc/dconf/db/$l_gpname.d/00-media-automount"
    
    # Check if profile file exists
    if ! grep -Pq -- "^\h*system-db:$l_gpname\b" /etc/dconf/profile/* 2>/dev/null; then
        echo " - Creating dconf database profile"
        if [ ! -f "/etc/dconf/profile/user" ]; then
            l_gpfile="/etc/dconf/profile/user"
        else
            l_gpfile="/etc/dconf/profile/user2"
        fi
        {
            echo -e "\nuser-db:user"
            echo "system-db:$l_gpname"
        } >> "$l_gpfile"
    fi
    
    # Create dconf directory if it doesn't exist
    l_gpdir="/etc/dconf/db/$l_gpname.d"
    if [ ! -d "$l_gpdir" ]; then
        echo " - Creating dconf database directory $l_gpdir"
        mkdir -p "$l_gpdir"
    fi
    
    # Check and set automount-open setting
    if ! grep -Pqs -- '^\h*automount-open\h*=\h*false\b' "$l_kfile" 2>/dev/null; then
        echo " - Creating automount-open entry in $l_kfile"
        ! grep -Psq -- '^\h*\[org\/gnome\/desktop\/media-handling\]\b' "$l_kfile" 2>/dev/null && echo '[org/gnome/desktop/media-handling]' >> "$l_kfile"
        sed -ri '/^\s*\[org\/gnome\/desktop\/media-handling\]/a \\nautomount-open=false' "$l_kfile"
    fi
    
    # Check and set automount setting
    if ! grep -Pqs -- '^\h*automount\h*=\h*false\b' "$l_kfile" 2>/dev/null; then
        echo " - Creating automount entry in $l_kfile"
        ! grep -Psq -- '^\h*\[org\/gnome\/desktop\/media-handling\]\b' "$l_kfile" 2>/dev/null && echo '[org/gnome/desktop/media-handling]' >> "$l_kfile"
        sed -ri '/^\s*\[org\/gnome\/desktop\/media-handling\]/a \\nautomount=false' "$l_kfile"
    fi
    
    # Update dconf
    dconf update 2>/dev/null || true
    echo " - Updated dconf database"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm_automount
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GDM automatic mounting disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="