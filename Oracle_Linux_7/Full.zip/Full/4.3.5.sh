#!/usr/bin/env bash
# Script: 4.3.5.sh
# Item: 4.3.5 Ensure re-authentication for privilege escalation is not disabled globally (Automated)
set -euo pipefail
SCRIPT_NAME="4.3.5.sh"
ITEM_NAME="4.3.5 Ensure re-authentication for privilege escalation is not disabled globally (Automated)"
DESCRIPTION="This remediation ensures re-authentication for privilege escalation by removing !authenticate tags."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for !authenticate tags..."
    authenticate=$(grep -r '!authenticate' /etc/sudoers /etc/sudoers.d/* 2>/dev/null || true)
    if [ -z "$authenticate" ]; then
        echo "PASS: No !authenticate tags found"
        echo "PROOF: grep returned empty"
        return 0
    else
        echo "FAIL: !authenticate tags found"
        echo "PROOF: $authenticate"
        return 1
    fi
}
# Function to fix
fix_authenticate() {
    echo "Applying fix..."
    for file in /etc/sudoers /etc/sudoers.d/*; do
        if [ -f "$file" ]; then
            sed -i '/!authenticate/d' "$file"
            echo " - Removed !authenticate from $file"
        fi
    done
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_authenticate
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Re-authentication ensured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="