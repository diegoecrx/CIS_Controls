#!/bin/bash

set -euo pipefail

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check if auditd.conf exists
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "/etc/audit/auditd.conf not found"
    exit 1
fi

# Get audit log directory from auditd.conf
log_dir=$(awk -F "=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs)
log_dir=$(dirname "$log_dir")

echo "Audit log directory: $log_dir"

# Check if log directory exists
if [ ! -d "$log_dir" ]; then
    echo "Audit log directory $log_dir not found"
    exit 1
fi

# Show current permissions before remediation (using same format as CIS test)
echo "Current audit log file permissions (CIS format):"
find "$log_dir" -type f -exec stat -Lc "%n %#a" {} +

echo ""
echo "=== Remediating files ==="

# Find all files that don't match allowed permissions and fix them
# The CIS check looks for files that are NOT any of these permissions:
# 600, 0400, 0200, 0000, 0640, 0440, 0040
# Note: 04644 has special bits (setuid) which makes it NOT match 0640

find "$log_dir" -type f 2>/dev/null | while read file; do
    # Get current permissions in octal
    current_perm=$(stat -Lc "%#a" "$file" 2>/dev/null || echo "0")
    
    # Check if it matches any allowed pattern
    # We need to check both with and without special bits
    case "$current_perm" in
        "0600"|"0400"|"0200"|"0000"|"0640"|"0440"|"0040")
            # Already compliant
            ;;
        *)
            # Not compliant - need to fix
            echo "Fixing: $file ($current_perm -> 0640)"
            
            # First, remove any special bits (setuid, setgid, sticky)
            chmod u-s,g-s "$file" 2>/dev/null || true
            
            # Then set to 0640
            chmod 0640 "$file" 2>/dev/null || true
            
            # Verify
            new_perm=$(stat -Lc "%#a" "$file" 2>/dev/null || echo "failed")
            if [[ "$new_perm" == "0640" ]] || [[ "$new_perm" == "0600" ]] || [[ "$new_perm" == "0400" ]] || [[ "$new_perm" == "0200" ]] || [[ "$new_perm" == "0000" ]] || [[ "$new_perm" == "0440" ]] || [[ "$new_perm" == "0040" ]]; then
                echo "  Success: $new_perm"
            else
                echo "  Warning: Still $new_perm"
            fi
            ;;
    esac
done

echo ""
echo "=== Post-remediation verification ==="

# Show permissions after remediation (using same format as CIS test)
echo "Audit log file permissions after remediation (CIS format):"
find "$log_dir" -type f -exec stat -Lc "%n %#a" {} +

echo ""
echo "=== Running CIS compliance test ==="

# Run the exact CIS test command
result=$(find "$log_dir" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -exec stat -Lc "%n %#a" {} + | awk '{print} END { if(NR==0) print "pass"; else print "fail"}')

echo "Result: $result"

# If still failing, identify the problematic files
if [ "$result" = "fail" ]; then
    echo ""
    echo "Problematic files:"
    find "$log_dir" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -exec stat -Lc "%n %#a" {} +
    
    echo ""
    echo "=== Additional remediation for stubborn files ==="
    
    # Force fix all files regardless of current permissions
    find "$log_dir" -type f 2>/dev/null | while read file; do
        echo "Forcing fix: $file"
        # Remove all special bits
        chmod u-s,g-s,o-t "$file" 2>/dev/null || true
        # Set to 0640
        chmod 0640 "$file" 2>/dev/null || true
    done
    
    echo ""
    echo "=== Final verification ==="
    final_result=$(find "$log_dir" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -exec stat -Lc "%n %#a" {} + | awk '{print} END { if(NR==0) print "pass"; else print "fail"}')
    echo "Final result: $final_result"
    
    if [ "$final_result" = "pass" ]; then
        echo "pass"
    else
        echo "fail"
        exit 1
    fi
else
    echo "pass"
fi

echo ""
echo "=== Creating persistent fix ==="

# Create a systemd service to maintain permissions
cat > /etc/systemd/system/audit-log-permissions.service << 'EOF'
[Unit]
Description=Maintain audit log file permissions
After=auditd.service
Before=syslog.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'find /var/log/audit -type f -exec chmod u-s,g-s {} \; 2>/dev/null || true'
ExecStart=/bin/sh -c 'find /var/log/audit -type f ! -perm 0640 -exec chmod 0640 {} \; 2>/dev/null || true'
ExecStartPost=/bin/sh -c 'logger -t audit-permissions "Fixed audit log permissions"'

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable audit-log-permissions.service
systemctl start audit-log-permissions.service

echo "Created persistent service: audit-log-permissions.service"