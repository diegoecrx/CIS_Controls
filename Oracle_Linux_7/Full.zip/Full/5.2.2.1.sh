#!/bin/bash

# Enforce CIS 5.2.2.1 - Ensure audit log storage size is configured
echo "Enforcing CIS 5.2.2.1 - Configure audit log storage size..."

# Set log file size (using CIS recommended value of 32MB)
LOG_SIZE="32"

# Configure auditd.conf
echo "Configuring /etc/audit/auditd.conf..."

# Create directory if it doesn't exist
if [ ! -d /etc/audit ]; then
    mkdir -p /etc/audit
    echo "Created /etc/audit directory"
fi

# Create or update auditd.conf
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "Creating /etc/audit/auditd.conf..."
    touch /etc/audit/auditd.conf
fi

# Backup original file
if [ ! -f /etc/audit/auditd.conf.bak ]; then
    cp /etc/audit/auditd.conf /etc/audit/auditd.conf.bak
    echo "Backed up /etc/audit/auditd.conf to /etc/audit/auditd.conf.bak"
fi

# Check if max_log_file is already set
if grep -q "^max_log_file" /etc/audit/auditd.conf; then
    # Update existing setting
    sed -i "s/^max_log_file.*/max_log_file = $LOG_SIZE/" /etc/audit/auditd.conf
    echo "Updated existing max_log_file setting to $LOG_SIZE MB"
else
    # Add new setting
    echo "max_log_file = $LOG_SIZE" >> /etc/audit/auditd.conf
    echo "Added max_log_file = $LOG_SIZE to /etc/audit/auditd.conf"
fi

# Ensure other essential auditd settings are configured
AUDIT_SETTINGS=(
    "max_log_file_action = keep_logs"
    "space_left_action = email"
    "action_mail_acct = root"
    "admin_space_left_action = halt"
)

for setting in "${AUDIT_SETTINGS[@]}"; do
    key=$(echo "$setting" | cut -d'=' -f1 | tr -d ' ')
    if grep -q "^$key" /etc/audit/auditd.conf; then
        # Update existing setting
        sed -i "s/^$key.*/$setting/" /etc/audit/auditd.conf
        echo "Updated existing $key setting"
    else
        # Add new setting
        echo "$setting" >> /etc/audit/auditd.conf
        echo "Added $setting to /etc/audit/auditd.conf"
    fi
done

# Set proper permissions on auditd.conf
chmod 640 /etc/audit/auditd.conf
chown root:root /etc/audit/auditd.conf

# Restart auditd service if it's running
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "Restarting auditd service..."
    systemctl restart auditd
fi

# Verify configuration
echo "Verifying audit log storage configuration..."

# Check if max_log_file is correctly configured
if grep -q "^max_log_file = $LOG_SIZE" /etc/audit/auditd.conf; then
    echo "SUCCESS: max_log_file = $LOG_SIZE MB configured in /etc/audit/auditd.conf"
else
    echo "ERROR: max_log_file not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Verify file permissions
PERMS=$(stat -c %a /etc/audit/auditd.conf)
OWNER=$(stat -c %U:%G /etc/audit/auditd.conf)
if [ "$PERMS" = "640" ] && [ "$OWNER" = "root:root" ]; then
    echo "SUCCESS: /etc/audit/auditd.conf has correct permissions and ownership"
else
    echo "ERROR: /etc/audit/auditd.conf has incorrect permissions or ownership"
    exit 1
fi

# Check if auditd service is running (if installed)
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "SUCCESS: auditd service is running"
else
    echo "WARNING: auditd service is not running (may not be installed)"
fi

echo "CIS 5.2.2.1 remediation completed successfully"
echo "Audit log storage size is now configured to $LOG_SIZE MB"