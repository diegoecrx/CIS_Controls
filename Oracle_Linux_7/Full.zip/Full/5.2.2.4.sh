#!/bin/bash

# Enforce CIS 5.2.2.4 - Ensure system warns when audit logs are low on space
echo "Enforcing CIS 5.2.2.4 - Configure audit log space warnings..."

# Configure auditd.conf
echo "Configuring /etc/audit/auditd.conf..."

# Create directory if it doesn't exist
if [ ! -d /etc/audit ]; then
    mkdir -p /etc/audit
    echo "Created /etc/audit directory"
fi

# Create or update auditd.conf
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "Creating /etc/audit/auditd.conf..."
    touch /etc/audit/auditd.conf
fi

# Backup original file
if [ ! -f /etc/audit/auditd.conf.bak ]; then
    cp /etc/audit/auditd.conf /etc/audit/auditd.conf.bak
    echo "Backed up /etc/audit/auditd.conf to /etc/audit/auditd.conf.bak"
fi

# Configure space_left_action (warn when space is low)
if grep -q "^space_left_action" /etc/audit/auditd.conf; then
    # Update existing setting to email
    sed -i 's/^space_left_action.*/space_left_action = email/' /etc/audit/auditd.conf
    echo "Updated existing space_left_action setting to 'email'"
else
    # Add new setting
    echo "space_left_action = email" >> /etc/audit/auditd.conf
    echo "Added space_left_action = email to /etc/audit/auditd.conf"
fi

# Configure admin_space_left_action (take action when space is critically low)
if grep -q "^admin_space_left_action" /etc/audit/auditd.conf; then
    # Update existing setting to single
    sed -i 's/^admin_space_left_action.*/admin_space_left_action = single/' /etc/audit/auditd.conf
    echo "Updated existing admin_space_left_action setting to 'single'"
else
    # Add new setting
    echo "admin_space_left_action = single" >> /etc/audit/auditd.conf
    echo "Added admin_space_left_action = single to /etc/audit/auditd.conf"
fi

# Configure action_mail_acct (who to email for warnings)
if grep -q "^action_mail_acct" /etc/audit/auditd.conf; then
    # Update existing setting to root
    sed -i 's/^action_mail_acct.*/action_mail_acct = root/' /etc/audit/auditd.conf
    echo "Updated existing action_mail_acct setting to 'root'"
else
    # Add new setting
    echo "action_mail_acct = root" >> /etc/audit/auditd.conf
    echo "Added action_mail_acct = root to /etc/audit/auditd.conf"
fi

# Set proper permissions on auditd.conf
chmod 640 /etc/audit/auditd.conf
chown root:root /etc/audit/auditd.conf

# Restart auditd service if it's running
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "Restarting auditd service..."
    systemctl restart auditd
fi

# Verify configuration
echo "Verifying audit log space warning configuration..."

# Check if space_left_action is correctly configured
if grep -q "^space_left_action = email" /etc/audit/auditd.conf; then
    echo "SUCCESS: space_left_action = email configured in /etc/audit/auditd.conf"
else
    echo "ERROR: space_left_action not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Check if admin_space_left_action is correctly configured
if grep -q "^admin_space_left_action = single" /etc/audit/auditd.conf; then
    echo "SUCCESS: admin_space_left_action = single configured in /etc/audit/auditd.conf"
else
    echo "ERROR: admin_space_left_action not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Check if action_mail_acct is correctly configured
if grep -q "^action_mail_acct = root" /etc/audit/auditd.conf; then
    echo "SUCCESS: action_mail_acct = root configured in /etc/audit/auditd.conf"
else
    echo "ERROR: action_mail_acct not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Verify file permissions
PERMS=$(stat -c %a /etc/audit/auditd.conf)
OWNER=$(stat -c %U:%G /etc/audit/auditd.conf)
if [ "$PERMS" = "640" ] && [ "$OWNER" = "root:root" ]; then
    echo "SUCCESS: /etc/audit/auditd.conf has correct permissions and ownership"
else
    echo "ERROR: /etc/audit/auditd.conf has incorrect permissions or ownership"
    exit 1
fi

# Check if auditd service is running (if installed)
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "SUCCESS: auditd service is running"
else
    echo "WARNING: auditd service is not running (may not be installed)"
fi

echo "CIS 5.2.2.4 remediation completed successfully"
echo "System will now warn via email when audit log space is low"
echo "System will enter single user mode when audit log space is critically low"
echo "NOTE: Ensure mail system is properly configured for email notifications"