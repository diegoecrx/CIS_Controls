#!/usr/bin/env bash
# Script: 4.3.6.sh
# Item: 4.3.6 Ensure sudo authentication timeout is configured correctly (Automated)
set -euo pipefail
SCRIPT_NAME="4.3.6.sh"
ITEM_NAME="4.3.6 Ensure sudo authentication timeout is configured correctly (Automated)"
DESCRIPTION="This remediation ensures sudo authentication timeout is 15 minutes or less."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking sudo timestamp_timeout..."
    timeout_lines=$(grep -r 'timestamp_timeout' /etc/sudoers /etc/sudoers.d/* 2>/dev/null || true)
    if [ -z "$timeout_lines" ]; then
        echo "FAIL: No timestamp_timeout set"
        echo "PROOF: No matches found"
        return 1
    fi
    fail=false
    while IFS= read -r line; do
        value=$(echo "$line" | sed 's/.*timestamp_timeout\s*=\s*//' | awk '{print $1}')
        if [ "$value" -gt 15 ] 2>/dev/null; then
            echo "FAIL: Timeout $value >15"
            echo "PROOF: $line"
            fail=true
        fi
    done <<< "$timeout_lines"
    if [ "$fail" = true ]; then
        return 1
    else
        echo "PASS: All timeouts <=15"
        echo "PROOF: $timeout_lines"
        return 0
    fi
}
# Function to fix
fix_timeout() {
    echo "Applying fix..."
    file="/etc/sudoers.d/00_sudo_timeout"
    echo "Defaults timestamp_timeout=15" > "$file"
    chmod 0440 "$file"
    echo " - Set in $file"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_timeout
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Timeout configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="