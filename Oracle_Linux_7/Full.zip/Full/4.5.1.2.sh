#!/bin/bash
set -euo pipefail

LOGIN_DEFS="/etc/login.defs"
REQUIRED_MAX_DAYS=365
DEFAULT_PASSWORD="@Real2014NewYeah_"

[ "$EUID" -eq 0 ] || { echo "Must be run as root" >&2; exit 1; }

echo "=== Setting Password Max Days to $REQUIRED_MAX_DAYS ==="

# Set global setting
if grep -q "^PASS_MAX_DAYS" "$LOGIN_DEFS"; then
    sed -i "s/^PASS_MAX_DAYS\s\+[0-9]\+/PASS_MAX_DAYS $REQUIRED_MAX_DAYS/" "$LOGIN_DEFS"
else
    echo "PASS_MAX_DAYS $REQUIRED_MAX_DAYS" >> "$LOGIN_DEFS"
fi
echo "Global PASS_MAX_DAYS set to $REQUIRED_MAX_DAYS"
echo ""

# Process users
users_changed=0
for user in $(awk -F: '$2 !~ /^[!*]/ && $2 != "" {print $1}' /etc/shadow); do
    echo "--- Processing: $user ---"
    
    current_max=$(chage -l "$user" 2>/dev/null | grep "Maximum number of days" | awk -F: '{print $2}' | tr -d ' ')
    
    if [[ -z "$current_max" ]] || [[ "$current_max" != "$REQUIRED_MAX_DAYS" ]]; then
        echo "Current max days: ${current_max:-not set}"
        echo "Setting to: $REQUIRED_MAX_DAYS days"
        
        # Set password automatically
        echo "Setting password for $user..."
        if echo "$user:$DEFAULT_PASSWORD" | chpasswd; then
            echo "✓ Password changed successfully"
            chage --maxdays "$REQUIRED_MAX_DAYS" "$user"
            echo "✓ Max days set to $REQUIRED_MAX_DAYS"
            ((users_changed++))
        else
            echo "✗ Password change failed. Max days NOT updated."
        fi
    else
        echo "Already compliant: $REQUIRED_MAX_DAYS days"
    fi
    
    echo ""
done

echo "=== Verification ==="
echo "Password expiration settings:"
echo "---------------------------"
for user in $(awk -F: '$2 !~ /^[!*]/ && $2 != "" {print $1}' /etc/shadow); do
    max_days=$(chage -l "$user" 2>/dev/null | grep "Maximum number of days" | awk -F: '{print $2}' | tr -d ' ')
    printf "%-20s: %s days\n" "$user" "${max_days:-not set}"
done

echo ""
echo "Summary: Changed passwords for $users_changed user(s)"