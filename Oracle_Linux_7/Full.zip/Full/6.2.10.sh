#!/bin/bash

if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

echo "=== Starting home directory validation and repair ==="
echo ""

# Build valid shells pattern without problematic escape sequences
l_valid_shells="^($(awk -F/ '$NF != "nologin" {print $0}' /etc/shells | grep '^/' | sed 's|/|\\/|g' | paste -s -d '|' -))$"

echo "Valid shells pattern: $l_valid_shells"
echo ""

# Get users with valid shells
echo "Users with valid login shells:"
awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " -> " $(NF-1) }' /etc/passwd
echo ""

# First pass: ensure home directories exist with correct permissions
echo "=== Phase 1: Ensuring home directories exist ==="
while read -r l_user l_home; do
    echo "Processing user: $l_user, home: $l_home"
    
    if [ ! -d "$l_home" ]; then
        echo "  Creating home directory: $l_home"
        mkdir -p "$l_home"
        echo "  Setting ownership to $l_user"
        chown "$l_user" "$l_home"
        echo "  Setting permissions to 750"
        chmod 750 "$l_home"
        echo "  ✓ Created and configured $l_home"
    else
        echo "  Home directory exists"
        echo "  Setting ownership to $l_user"
        chown "$l_user" "$l_home"
        echo "  Removing group write and other permissions"
        chmod g-w,o-rwx "$l_home"
        echo "  ✓ Updated permissions for $l_home"
    fi
    echo ""
done <<< "$(awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " " $(NF-1) }' /etc/passwd)"

echo "=== Phase 2: Validating home directory configuration ==="
echo ""

# Second pass: validate all home directories
validation_failed=false
awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " " $(NF-1) }' /etc/passwd | while read -r l_user l_home; do
    echo "Validating user: $l_user, home: $l_home"
    
    if [ ! -d "$l_home" ]; then
        echo "  ✗ ERROR: Home directory doesn't exist"
        validation_failed=true
        continue
    fi
    
    l_owner=$(stat -c '%U' "$l_home" 2>/dev/null)
    l_mode=$(stat -c '%a' "$l_home" 2>/dev/null)
    
    echo "  Current owner: $l_owner, Expected: $l_user"
    echo "  Current permissions: $l_mode, Maximum allowed: 750"
    
    if [ "$l_owner" != "$l_user" ]; then
        echo "  ✗ ERROR: Incorrect ownership"
        validation_failed=true
    fi
    
    if [ "$l_mode" -gt 750 ]; then
        echo "  ✗ ERROR: Permissions too permissive ($l_mode > 750)"
        validation_failed=true
    fi
    
    if [ "$l_owner" = "$l_user" ] && [ "$l_mode" -le 750 ]; then
        echo "  ✓ Configuration correct"
    fi
    
    echo ""
    
    # If validation failed, exit with error
    if [ "$validation_failed" = true ]; then
        exit 1
    fi
done

validation_exit_code=$?

echo "=== Summary ==="
echo ""

if [ $validation_exit_code -eq 0 ]; then
    echo "✓ All home directories are properly configured"
    echo "PASS"
else
    echo "✗ Home directory configuration validation failed"
    echo "FAIL: Home directory configuration failed"
    exit 1
fi