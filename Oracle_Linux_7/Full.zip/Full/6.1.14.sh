#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Display current issues before remediation
echo "Current file permission issues:"
RPM_ISSUES=$(rpm -Va --nomtime --nosize --nomd5 --nolinkto --noconfig --noghost 2>&1)
echo "$RPM_ISSUES"

# Apply fixes based on the specific issues found
echo ""
echo "Applying remediation:"

# Fix /var/log/audit permissions (mode issue)
if echo "$RPM_ISSUES" | grep -q "/var/log/audit"; then
    echo " - Fixing /var/log/audit permissions"
    chmod 750 /var/log/audit
    chown root:root /var/log/audit
fi

# Fix /var/log/chrony (missing file)
if echo "$RPM_ISSUES" | grep -q "/var/log/chrony"; then
    echo " - Creating /var/log/chrony directory"
    mkdir -p /var/log/chrony
    chmod 755 /var/log/chrony
    chown root:root /var/log/chrony
fi

# Fix /etc/sysctl.d/99-sysctl.conf permissions (mode issue)
if echo "$RPM_ISSUES" | grep -q "/etc/sysctl.d/99-sysctl.conf"; then
    echo " - Fixing /etc/sysctl.d/99-sysctl.conf permissions"
    chmod 644 /etc/sysctl.d/99-sysctl.conf
    chown root:root /etc/sysctl.d/99-sysctl.conf
fi

# Apply standard package permission resets for common packages
echo " - Resetting package file permissions"
rpm --setperms audit >/dev/null 2>&1
rpm --setperms chrony >/dev/null 2>&1
rpm --setperms procps-ng >/dev/null 2>&1

# Verify remediation
echo ""
echo "Verification after remediation:"
FINAL_ISSUES=$(rpm -Va --nomtime --nosize --nomd5 --nolinkto --noconfig --noghost 2>&1)
ISSUE_COUNT=$(echo "$FINAL_ISSUES" | grep -c '^[A-Z]')

if [[ $ISSUE_COUNT -eq 0 ]]; then
    echo "PASS: All system file permissions are correct"
    echo "EVIDENCE: rpm -Va returned no permission issues"
    exit 0
else
    echo "FAIL: $ISSUE_COUNT file permission issues remain after remediation"
    echo "EVIDENCE: Remaining issues:"
    echo "$FINAL_ISSUES"
    exit 1
fi