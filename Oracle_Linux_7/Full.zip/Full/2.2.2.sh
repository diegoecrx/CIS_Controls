#!/usr/bin/env bash

# Script: 2.2.2.sh
# Item: 2.2.2 Ensure avahi daemon services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.2_v2.sh"
ITEM_NAME="2.2.2 Ensure avahi daemon services are not in use (Automated)"
DESCRIPTION="This remediation ensures avahi daemon services are not in use by removing or masking the services. FORCE VERSION - Comprehensive avahi removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_avahi_status
check_avahi_status() {
    echo "Checking avahi status..."
    
    avahi_installed=false
    avahi_services_running=false
    avahi_services_enabled=false
    avahi_services_masked=false
    
    # Check if avahi package is installed
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q avahi >/dev/null 2>&1 || rpm -q avahi-autoipd >/dev/null 2>&1; then
            avahi_installed=true
            echo " - avahi package(s) are installed"
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l avahi-daemon >/dev/null 2>&1 || dpkg -l avahi-autoipd >/dev/null 2>&1; then
            avahi_installed=true
            echo " - avahi package(s) are installed"
        fi
    else
        # Fallback: check if avahi commands or services exist
        if command -v avahi-daemon >/dev/null 2>&1 || systemctl list-unit-files | grep -q avahi; then
            avahi_installed=true
            echo " - avahi appears to be installed"
        fi
    fi
    
    # Check avahi services
    avahi_services=("avahi-daemon.service" "avahi-daemon.socket" "avahi-autoipd.service")
    
    for service in "${avahi_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service"; then
            # Check if service is running
            if systemctl is-active "$service" >/dev/null 2>&1; then
                avahi_services_running=true
                echo " - $service is running"
            fi
            
            # Check if service is enabled
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                avahi_services_enabled=true
                echo " - $service is enabled"
            fi
            
            # Check if service is masked
            if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                avahi_services_masked=true
                echo " - $service is masked"
            fi
        fi
    done
    
    # Check for avahi processes
    if pgrep avahi >/dev/null 2>&1; then
        echo " - WARNING: avahi processes running:"
        pgrep avahi | xargs ps -o pid,user,command -p 2>/dev/null || true
    fi
    
    # Check for avahi network services
    if netstat -tulpn 2>/dev/null | grep -q avahi; then
        echo " - WARNING: avahi network services detected:"
        netstat -tulpn 2>/dev/null | grep avahi || true
    fi
    
    # Check for avahi DNS-SD/mDNS
    if ss -tulpn 2>/dev/null | grep -q 5353; then
        echo " - WARNING: mDNS/DNS-SD service (port 5353) may be active"
    fi
    
    return 0
}

# Function to stop_avahi_services
stop_avahi_services() {
    echo "Stopping avahi services..."
    
    # List of avahi services to stop
    avahi_services=("avahi-daemon.service" "avahi-daemon.socket" "avahi-autoipd.service")
    
    # Stop avahi processes first
    if pgrep avahi >/dev/null 2>&1; then
        echo " - Stopping avahi processes..."
        pkill -TERM avahi 2>/dev/null || true
        sleep 2
        
        # Force kill if still running
        if pgrep avahi >/dev/null 2>&1; then
            echo " - Force stopping avahi processes..."
            pkill -KILL avahi 2>/dev/null || true
            sleep 1
        fi
    fi
    
    # Stop services using systemctl
    for service in "${avahi_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            if systemctl stop "$service" 2>&1; then
                echo "   - $service stopped"
            else
                echo "   - WARNING: Could not stop $service via systemctl"
            fi
        fi
    done
    
    # Additional stop for any avahi related services
    systemctl list-unit-files | grep avahi | awk '{print $1}' | while read -r service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Verify no avahi processes are running
    if pgrep avahi >/dev/null 2>&1; then
        echo " - CRITICAL: avahi processes still running after stop attempts"
        return 1
    else
        echo " - No avahi processes running"
    fi
    
    # Kill any remaining avahi processes
    pkill -9 avahi 2>/dev/null || true
    
    return 0
}

# Function to remove_avahi_packages
remove_avahi_packages() {
    local pkg_mgr="$1"
    
    echo "Removing avahi packages..."
    
    # List of avahi-related packages
    avahi_packages=("avahi" "avahi-autoipd" "avahi-daemon" "avahi-ui-utils" "avahi-dnsconfd")
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove avahi packages..."
            for pkg in "${avahi_packages[@]}"; do
                if $pkg_mgr list installed "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if $pkg_mgr remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        apt)
            echo " - Using apt to remove avahi packages..."
            export DEBIAN_FRONTEND=noninteractive
            for pkg in "${avahi_packages[@]}"; do
                if dpkg -l "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if apt-get remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        zypper)
            echo " - Using zypper to remove avahi packages..."
            for pkg in "${avahi_packages[@]}"; do
                if zypper search --installed-only "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if zypper --non-interactive remove "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove avahi packages"
            return 1
            ;;
    esac
    
    # Clean up package cache and dependencies
    case "$pkg_mgr" in
        yum|dnf)
            $pkg_mgr autoremove -y 2>/dev/null || true
            ;;
        apt)
            apt-get autoremove -y 2>/dev/null || true
            ;;
    esac
    
    echo " - Package removal completed"
    return 0
}

# Function to mask_avahi_services
mask_avahi_services() {
    echo "Masking avahi services..."
    
    # List of avahi services to mask
    avahi_services=("avahi-daemon.service" "avahi-daemon.socket" "avahi-autoipd.service")
    
    for service in "${avahi_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service"; then
            if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                if systemctl mask "$service" 2>&1; then
                    echo " - $service masked"
                else
                    echo " - WARNING: Could not mask $service"
                fi
            else
                echo " - $service already masked"
            fi
        fi
    done
    
    # Mask any other avahi related services
    systemctl list-unit-files | grep avahi | awk '{print $1}' | while read -r service; do
        if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
            systemctl mask "$service" 2>/dev/null && echo " - $service masked" || true
        fi
    done
    
    return 0
}

# Function to disable_avahi_services
disable_avahi_services() {
    echo "Disabling avahi services..."
    
    # List of avahi services to disable
    avahi_services=("avahi-daemon.service" "avahi-daemon.socket" "avahi-autoipd.service")
    
    for service in "${avahi_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl disable "$service" 2>&1; then
                    echo " - $service disabled"
                else
                    echo " - WARNING: Could not disable $service"
                fi
            else
                echo " - $service already disabled"
            fi
        fi
    done
    
    # Disable any other avahi related services
    systemctl list-unit-files | grep avahi | awk '{print $1}' | while read -r service; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            systemctl disable "$service" 2>/dev/null && echo " - $service disabled" || true
        fi
    done
    
    return 0
}

# Function to cleanup_avahi_configs
cleanup_avahi_configs() {
    echo "Cleaning up avahi configuration files..."
    
    # List of avahi configuration files to remove or disable
    config_files=(
        "/etc/avahi/avahi-daemon.conf"
        "/etc/avahi/avahi-autoipd.action"
        "/etc/avahi/avahi-dnsconfd.action"
        "/etc/avahi/hosts"
        "/etc/avahi/services/"
        "/etc/dbus-1/system.d/avahi-dbus.conf"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -e "$config_file" ]; then
            if [ -f "$config_file" ]; then
                # Create backup and disable
                backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp "$config_file" "$backup_file"
                echo " - Backed up $config_file to $backup_file"
                
                # Comment out all active configurations or remove file
                if [[ "$config_file" == *.conf ]]; then
                    sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$config_file" 2>/dev/null || true
                    echo " - Disabled configurations in $config_file"
                fi
            elif [ -d "$config_file" ]; then
                # For directories, backup and empty them
                backup_dir="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp -r "$config_file" "$backup_dir" 2>/dev/null || true
                echo " - Backed up $config_file to $backup_dir"
                
                # Remove all service files from avahi services directory
                if [ "$config_file" = "/etc/avahi/services/" ] && [ -d "$config_file" ]; then
                    rm -f "${config_file}"* 2>/dev/null || true
                    echo " - Removed service files from $config_file"
                fi
            fi
        fi
    done
    
    # Remove avahi from startup programs (if applicable)
    if [ -d "/etc/xdg/autostart" ]; then
        find /etc/xdg/autostart -name "*avahi*" -exec rm -f {} \; 2>/dev/null || true
        echo " - Removed avahi autostart entries"
    fi
    
    # Remove any avahi related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -q avahi "$cron_file" 2>/dev/null; then
                sed -i '/avahi/d' "$cron_file" 2>/dev/null || true
                echo " - Removed avahi references from $cron_file"
            fi
        done
    fi
    
    return 0
}

# Function to block_avahi_ports
block_avahi_ports() {
    echo "Blocking avahi network ports..."
    
    # Avahi uses UDP port 5353 for mDNS
    if command -v firewall-cmd >/dev/null 2>&1; then
        # firewalld
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld to block avahi ports..."
            firewall-cmd --permanent --remove-service=mdns 2>/dev/null || true
            firewall-cmd --permanent --remove-service=ipp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=5353/udp 2>/dev/null || true
            firewall-cmd --reload 2>/dev/null || true
            echo " - firewalld configured to block avahi ports"
        fi
    fi
    
    # Additional iptables rules for non-firewalld systems
    if command -v iptables >/dev/null 2>&1; then
        echo " - Adding iptables rules to block avahi..."
        iptables -I INPUT -p udp --dport 5353 -j DROP 2>/dev/null || true
        iptables -I INPUT -p tcp --dport 5353 -j DROP 2>/dev/null || true
        echo " - iptables rules added (if supported)"
    fi
    
    return 0
}

# Function to verify_avahi_removal
verify_avahi_removal() {
    echo "Verifying avahi remediation..."
    
    verification_passed=true
    
    # Check if avahi packages are installed
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q avahi >/dev/null 2>&1 || rpm -q avahi-autoipd >/dev/null 2>&1; then
            echo "FAIL: avahi package(s) are still installed"
            verification_passed=false
        else
            echo "PASS: avahi packages are not installed"
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l avahi-daemon >/dev/null 2>&1 || dpkg -l avahi-autoipd >/dev/null 2>&1; then
            echo "FAIL: avahi package(s) are still installed"
            verification_passed=false
        else
            echo "PASS: avahi packages are not installed"
        fi
    else
        echo "INFO: Could not verify package removal (unknown package manager)"
    fi
    
    # Check if avahi services are running
    avahi_services=("avahi-daemon.service" "avahi-daemon.socket" "avahi-autoipd.service")
    for service in "${avahi_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo "FAIL: $service is running"
            verification_passed=false
        else
            echo "PASS: $service is not running"
        fi
    done
    
    # Check if avahi services are enabled or masked
    for service in "${avahi_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                    echo "PASS: $service is masked"
                else
                    echo "FAIL: $service is enabled"
                    verification_passed=false
                fi
            else
                echo "PASS: $service is not enabled"
            fi
        fi
    done
    
    # Check for avahi processes
    if pgrep avahi >/dev/null 2>&1; then
        echo "FAIL: avahi processes are running"
        verification_passed=false
    else
        echo "PASS: No avahi processes running"
    fi
    
    # Check for avahi network services
    if ss -tulpn 2>/dev/null | grep -q 5353; then
        echo "WARNING: mDNS/DNS-SD service (port 5353) may still be active"
        # Not necessarily a failure, as other services might use this port
    else
        echo "PASS: No avahi network services detected"
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current avahi status..."
    echo ""

    # Check current avahi status
    check_avahi_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable avahi
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING AVAHI"
    echo "==================================================================="
    echo ""

    # Stop avahi services first
    if ! stop_avahi_services; then
        echo " - WARNING: Some issues stopping avahi services"
    fi
    echo ""

    # Try to remove avahi packages
    if remove_avahi_packages "$pkg_mgr"; then
        echo " - Package removal attempted"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking services instead"
        removal_method="masked"
    fi
    echo ""

    # Mask and disable services (especially if package removal failed)
    if [ "$removal_method" = "masked" ]; then
        if mask_avahi_services; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        if disable_avahi_services; then
            echo " - Service disabling successful"
        fi
    fi
    echo ""

    # Cleanup configuration files
    cleanup_avahi_configs
    echo ""

    # Block network ports
    block_avahi_ports
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_avahi_removal; then
        echo ""
        echo "SUCCESS: avahi has been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ avahi packages removed"
        else
            echo "✓ avahi services masked and disabled"
        fi
        echo "✓ avahi services stopped"
        echo "✓ avahi processes terminated"
        echo "✓ Configuration files disabled"
        echo "✓ Network ports blocked"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: avahi remediation may not be complete"
        echo "Some avahi components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining avahi processes: ps aux | grep avahi"
        echo "2. Verify avahi services are masked: systemctl list-unit-files | grep avahi"
        echo "3. Manually remove avahi packages if needed"
        echo "4. Check network ports: ss -tulpn | grep 5353"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Packages installed: $(if command -v rpm >/dev/null && (rpm -q avahi >/dev/null 2>&1 || rpm -q avahi-autoipd >/dev/null 2>&1); then echo "YES"; elif command -v dpkg >/dev/null && (dpkg -l avahi-daemon >/dev/null 2>&1 || dpkg -l avahi-autoipd >/dev/null 2>&1); then echo "YES"; else echo "NO"; fi)"
    echo "Services running: $(systemctl is-active avahi-daemon 2>/dev/null || echo "NO")"
    echo "Services enabled: $(systemctl is-enabled avahi-daemon 2>/dev/null || echo "NO")"
    echo "Processes running: $(pgrep avahi 2>/dev/null | wc -l)"
    echo "Network port 5353: $(ss -tulpn 2>/dev/null | grep -c 5353 || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="