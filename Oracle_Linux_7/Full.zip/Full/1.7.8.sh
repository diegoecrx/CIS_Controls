#!/usr/bin/env bash
# Script: 1.7.8.sh
# Item: 1.7.8 Ensure GDM autorun-never is enabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.8.sh"
ITEM_NAME="1.7.8 Ensure GDM autorun-never is enabled (Automated)"
DESCRIPTION="This remediation ensures GDM autorun-never is enabled to prevent automatic execution of removable media."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking GDM autorun-never configuration..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    # Look for existing autorun-never settings
    l_kfile="$(grep -Prils -- '^\h*autorun-never\b' /etc/dconf/db/*.d 2>/dev/null | head -1)"
    
    # Check if autorun-never is set to true
    if [ -n "$l_kfile" ]; then
        if ! grep -Pqs -- '^\h*autorun-never\h*=\h*true\b' "$l_kfile"; then
            echo "FAIL: autorun-never is not set to true"
            echo "PROOF: autorun-never setting not enabled in $l_kfile"
            return 1
        fi
    else
        echo "FAIL: autorun-never setting not configured"
        echo "PROOF: No autorun-never configuration found"
        return 1
    fi
    
    echo "PASS: GDM autorun-never properly enabled"
    echo "PROOF: autorun-never set to true in $l_kfile"
    return 0
}
# Function to fix
fix_gdm_autorun_never() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    l_gpname="local"  # Set to desired dconf profile name
    
    # Look for existing settings and set variables if they exist
    l_kfile="$(grep -Prils -- '^\h*autorun-never\b' /etc/dconf/db/*.d 2>/dev/null | head -1)"
    
    # Set profile name based on dconf db directory
    if [ -f "$l_kfile" ]; then
        l_gpname="$(awk -F\/ '{split($(NF-1),a,".");print a[1]}' <<< "$l_kfile")"
        echo " - Updating dconf profile name to $l_gpname"
    fi
    
    [ ! -f "$l_kfile" ] && l_kfile="/etc/dconf/db/$l_gpname.d/00-media-autorun"
    
    # Check if profile file exists
    if ! grep -Pq -- "^\h*system-db:$l_gpname\b" /etc/dconf/profile/* 2>/dev/null; then
        echo " - Creating dconf database profile"
        if [ ! -f "/etc/dconf/profile/user" ]; then
            l_gpfile="/etc/dconf/profile/user"
        else
            l_gpfile="/etc/dconf/profile/user2"
        fi
        {
            echo -e "\nuser-db:user"
            echo "system-db:$l_gpname"
        } >> "$l_gpfile"
    fi
    
    # Create dconf directory if it doesn't exist
    l_gpdir="/etc/dconf/db/$l_gpname.d"
    if [ ! -d "$l_gpdir" ]; then
        echo " - Creating dconf database directory $l_gpdir"
        mkdir -p "$l_gpdir"
    fi
    
    # Check and set autorun-never setting
    if ! grep -Pqs -- '^\h*autorun-never\h*=\h*true\b' "$l_kfile" 2>/dev/null; then
        echo " - Creating or updating autorun-never entry in $l_kfile"
        if grep -Psq -- '^\h*autorun-never' "$l_kfile" 2>/dev/null; then
            sed -ri 's/(^\s*autorun-never\s*=\s*)(\S+)(\s*.*)$/\1true \3/' "$l_kfile"
        else
            ! grep -Psq -- '^\h*\[org\/gnome\/desktop\/media-handling\]\b' "$l_kfile" 2>/dev/null && echo '[org/gnome/desktop/media-handling]' >> "$l_kfile"
            sed -ri '/^\s*\[org\/gnome\/desktop\/media-handling\]/a \\nautorun-never=true' "$l_kfile"
        fi
    fi
    
    # Update dconf
    dconf update 2>/dev/null || true
    echo " - Updated dconf database"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm_autorun_never
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GDM autorun-never enabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="