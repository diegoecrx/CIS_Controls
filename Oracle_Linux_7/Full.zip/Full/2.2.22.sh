#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Get listening services with full details
echo "Checking listening network services:"
LISTENING_OUTPUT=$(ss -plntu 2>&1)
echo "$LISTENING_OUTPUT"

# Count listening TCP/UDP services (excluding headers)
LISTENING_COUNT=$(echo "$LISTENING_OUTPUT" | grep -E "^(tcp|udp).*LISTEN" | wc -l)

# Extract service details for evidence
echo ""
echo "Listening services details:"
echo "$LISTENING_OUTPUT" | grep -E "^(tcp|udp).*LISTEN" | while read line; do
    echo "  $line"
done

# Verification and result
if [[ $LISTENING_COUNT -eq 0 ]]; then
    echo "PASS: No network services listening"
    echo "EVIDENCE: ss -plntu shows 0 listening services"
    exit 0
else
    echo "FAIL: $LISTENING_COUNT network service(s) listening - manual review required"
    echo "EVIDENCE: Found $LISTENING_COUNT listening service(s) that need approval verification"
    echo ""
    echo "Services found:"
    echo "$LISTENING_OUTPUT" | grep -E "^(tcp|udp).*LISTEN" | awk '{print "  - " $1 " " $5 " (" $7 ")"}'
    exit 1
fi