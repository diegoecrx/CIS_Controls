#!/usr/bin/env bash
# Script: 1.4.4.sh
# Item: 1.4.4 Ensure core dump storage is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.4.4.sh"
ITEM_NAME="1.4.4 Ensure core dump storage is disabled (Automated)"
DESCRIPTION="This remediation ensures core dump storage is disabled by setting Storage=none."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current status..."
    conf_file="/etc/systemd/coredump.conf"
    if [ -f "$conf_file" ] && grep -q '^Storage=none' "$conf_file"; then
        echo "PASS: Storage=none set"
        echo "PROOF: $(grep '^Storage' "$conf_file")"
        return 0
    else
        echo "FAIL: Storage not none"
        echo "PROOF: $(grep '^Storage' "$conf_file" || echo "No entry")"
        return 1
    fi
}
# Function to fix
fix_core_dump() {
    echo "Applying fix..."
    conf_file="/etc/systemd/coredump.conf"
    mkdir -p /etc/systemd
    if grep -q '^Storage' "$conf_file"; then
        sed -i 's/^Storage.*/Storage=none/' "$conf_file"
    else
        echo "Storage=none" >> "$conf_file"
    fi
    echo " - Set Storage=none"
}
# Main remediation
{
    if check_current_status; then
        echo "No fix needed"
    else
        fix_core_dump
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Core dump storage disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="