#!/usr/bin/env bash
# Script: 1.4.3.sh
# Item: 1.4.3 Ensure core dump backtraces are disabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.4.3.sh"
ITEM_NAME="1.4.3 Ensure core dump backtraces are disabled (Automated)"
DESCRIPTION="This remediation ensures core dump backtraces are disabled by setting ProcessSizeMax=0."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current status..."
    conf_file="/etc/systemd/coredump.conf"
    if [ -f "$conf_file" ] && grep -q '^ProcessSizeMax=0' "$conf_file"; then
        echo "PASS: ProcessSizeMax=0 set"
        echo "PROOF: $(grep '^ProcessSizeMax' "$conf_file")"
        return 0
    else
        echo "FAIL: ProcessSizeMax not 0"
        echo "PROOF: $(grep '^ProcessSizeMax' "$conf_file" || echo "No entry")"
        return 1
    fi
}
# Function to fix
fix_core_dump() {
    echo "Applying fix..."
    conf_file="/etc/systemd/coredump.conf"
    mkdir -p /etc/systemd
    if grep -q '^ProcessSizeMax' "$conf_file"; then
        sed -i 's/^ProcessSizeMax.*/ProcessSizeMax=0/' "$conf_file"
    else
        echo "ProcessSizeMax=0" >> "$conf_file"
    fi
    echo " - Set ProcessSizeMax=0"
}
# Main remediation
{
    if check_current_status; then
        echo "No fix needed"
    else
        fix_core_dump
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Core dump backtraces disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="