#!/bin/bash

# Enforce CIS 2.1.2 - chrony configuration
echo "Enforcing CIS 2.1.2 - chrony configuration..."

# Define the NTP server (replace with your actual NTP server)
NTP_SERVER="10.0.0.2"

# Check if chrony is installed
if ! rpm -q chrony > /dev/null 2>&1; then
    echo "Installing chrony..."
    yum install -y chrony
fi

# Backup original chrony.conf
if [ ! -f /etc/chrony.conf.bak ]; then
    cp /etc/chrony.conf /etc/chrony.conf.bak
    echo "Backed up /etc/chrony.conf to /etc/chrony.conf.bak"
fi

# Remove any existing server/pool entries for our target server
sed -i "/^[\s]*\(server\|pool\)[\s]\+${NTP_SERVER}/d" /etc/chrony.conf

# Remove any conflicting server/pool entries (keep only our configured one)
# First, check if we have any server/pool entries
if grep -q "^[\s]*\(server\|pool\)" /etc/chrony.conf; then
    echo "Found existing NTP servers, replacing with configured server..."
    # Comment out all existing server/pool lines
    sed -i 's/^[\s]*\(server\|pool\)/# &/' /etc/chrony.conf
fi

# Add our configured NTP server
echo "server $NTP_SERVER" >> /etc/chrony.conf

# Ensure chrony service is enabled and started
systemctl enable chronyd
systemctl restart chronyd

# Verify configuration
echo "Verifying chrony configuration..."

# Check if our server entry exists
if grep -q "^[\s]*server[\s]\+$NTP_SERVER" /etc/chrony.conf; then
    echo "SUCCESS: NTP server $NTP_SERVER configured in /etc/chrony.conf"
else
    echo "ERROR: Failed to configure NTP server in /etc/chrony.conf"
    exit 1
fi

# Check if chrony is running
if systemctl is-active chronyd > /dev/null 2>&1; then
    echo "SUCCESS: chronyd service is running"
else
    echo "ERROR: chronyd service is not running"
    exit 1
fi

# Check if chrony is enabled
if systemctl is-enabled chronyd > /dev/null 2>&1; then
    echo "SUCCESS: chronyd service is enabled"
else
    echo "ERROR: chronyd service is not enabled"
    exit 1
fi

# Show current chrony sources
echo "Current chrony sources:"
chronyc sources

echo "CIS 2.1.2 remediation completed successfully"