#!/usr/bin/env bash
# Script: 1.7.10.sh
# Item: 1.7.10 Ensure XDMCP is not enabled (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.10.sh"
ITEM_NAME="1.7.10 Ensure XDMCP is not enabled (Automated)"
DESCRIPTION="This remediation ensures XDMCP is not enabled in GDM configuration."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking XDMCP configuration..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    # Check if /etc/gdm/custom.conf exists
    if [ ! -f "/etc/gdm/custom.conf" ]; then
        echo "PASS: GDM custom.conf does not exist"
        echo "PROOF: /etc/gdm/custom.conf file not found"
        return 0
    fi
    
    # Check for XDMCP Enable=true setting
    if grep -Piq '^\s*\[xdmcp\]' /etc/gdm/custom.conf; then
        if grep -A10 -Piq '^\s*\[xdmcp\]' /etc/gdm/custom.conf | grep -Piq '^\s*Enable\s*=\s*true\b'; then
            echo "FAIL: XDMCP is enabled"
            echo "PROOF: Enable=true found in [xdmcp] section of /etc/gdm/custom.conf"
            return 1
        fi
    fi
    
    echo "PASS: XDMCP is not enabled"
    echo "PROOF: No Enable=true setting found in XDMCP section"
    return 0
}
# Function to fix
fix_xdmcp() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    # Check if /etc/gdm/custom.conf exists
    if [ ! -f "/etc/gdm/custom.conf" ]; then
        echo " - /etc/gdm/custom.conf does not exist, no changes needed"
        return
    fi
    
    # Remove Enable=true from [xdmcp] section
    if grep -Piq '^\s*\[xdmcp\]' /etc/gdm/custom.conf; then
        if grep -A10 -Piq '^\s*\[xdmcp\]' /etc/gdm/custom.conf | grep -Piq '^\s*Enable\s*=\s*true\b'; then
            echo " - Removing Enable=true from XDMCP section"
            # Create backup
            cp /etc/gdm/custom.conf /etc/gdm/custom.conf.backup.$(date +%Y%m%d_%H%M%S)
            # Remove the Enable=true line from xdmcp section
            sed -ri '/^\s*\[xdmcp\]/,/^\s*\[/ { /^\s*Enable\s*=\s*true\b/d; }' /etc/gdm/custom.conf
        fi
    fi
    
    echo " - XDMCP configuration updated"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_xdmcp
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: XDMCP properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="