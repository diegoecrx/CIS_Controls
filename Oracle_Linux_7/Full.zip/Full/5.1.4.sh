#!/bin/bash
# 5.1.4 Ensure all logfiles have appropriate access configured
set -u

# 1. Remediation: Fix permissions and ownership for /var/log files
# Find files with permissions wider than 640 (skip if already safe)
# Using -perm /0137 finds files with any exec, group-write, or other-rwx bits set
find /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0 | while IFS= read -r -d '' file; do
    # Skip if it's a special file (like wtmp/lastlog which allow other groups)
    case "$file" in
        */wtmp*|*/btmp*|*/lastlog*) 
            chmod u-x,g-wx,o-wx "$file" ;; # Special handling
        */journal/*)
            chmod 640 "$file" ;; # Systemd journal files
        *)
            chmod 640 "$file" ;;
    esac

    # Fix ownership (root:root is standard, though root:adm is common for syslog)
    # We stick to strict root:root unless it's a known exception
    case "$file" in
        */wtmp*|*/btmp*|*/lastlog*) chgrp utmp "$file" ;;
        */journal/*) chgrp systemd-journal "$file" ;;
        *) chown root:root "$file" ;;
    esac
done

# 2. Evidence: Verify the specific files that failed the audit
# The audit failed on dmesg and dmesg.old
for target in /var/log/dmesg /var/log/dmesg.old; do
    if [[ -f "$target" ]]; then
        stat -c "%n: %a %U:%G" "$target"
    fi
done
