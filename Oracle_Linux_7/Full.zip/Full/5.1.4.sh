#!/bin/bash
# 5.1.4 Ensure all logfiles have appropriate access configured
set -u

echo "=== Starting Remediation for /var/log Permissions ==="

# 1. Remediation: Fix permissions and ownership for /var/log files
# Find files with permissions wider than 640 or incorrect ownership
# -perm /0137 finds files with any exec, group-write, or other-rwx bits set
find /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0 | while IFS= read -r -d '' file; do
    
    # Skip special handling files if needed, but generally apply fixes
    case "$file" in
        */wtmp*|*/btmp*|*/lastlog*) 
            # Special files: remove exec/world-write, allow group read/write if needed
            chmod u-x,g-wx,o-wx "$file" 
            chgrp utmp "$file"
            ;;
        */journal/*)
            # Journal files: 640 and systemd-journal group
            chmod 640 "$file" 
            chgrp systemd-journal "$file"
            ;;
        *)
            # Standard logs: 640 and root:root
            chmod 640 "$file" 
            chown root:root "$file"
            ;;
    esac
done

# 2. System Evidence & Verification
echo ""
echo "=== Verification: Audit Specific Failures ==="
# Explicitly check the files that caused the failure in your report
for target in /var/log/dmesg /var/log/dmesg.old; do
    if [[ -f "$target" ]]; then
        stat -c "%n: Mode=%a Owner=%U Group=%G" "$target"
    else
        echo "$target: File not found (Compliant)"
    fi
done

echo ""
echo "=== Verification: Remaining Insecure Files ==="
# Re-run the find command to prove no files remain non-compliant
# If this output is empty, the system is fully compliant.
find /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -exec ls -l {} \; 

echo ""
echo "=== Compliance Summary ==="
# If the find command found nothing, print PASS
if [[ -z $(find /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \)) ]]; then
    echo "✓ PASS - All /var/log files have appropriate access configured."
else
    echo "✗ FAIL - Some files still have excessive permissions (see above)."
    exit 1
fi
