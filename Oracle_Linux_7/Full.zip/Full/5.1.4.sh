#!/usr/bin/env bash
{
  l_op2=""
  l_output2=""
  l_uidmin="$(awk '/^s*UID_MIN/{print $2}' /etc/login.defs)"
  
  # Function to fix file permissions
  file_test_fix() {
    l_op2=""
    l_fuser="root"
    l_fgroup="root"
    
    if [ $(( $l_mode & $perm_mask )) -gt 0 ]; then
      l_op2="$l_op2
- Mode: \"$l_mode\" should be \"$maxperm\" or more restrictive
- Removing excess permissions"
      chmod "$l_rperms" "$l_fname"
    fi
    
    if [[ ! "$l_user" =~ $l_auser ]]; then
      l_op2="$l_op2
- Owned by: \"$l_user\" and should be owned by \"${l_auser//|/ or }\"
- Changing ownership to: \"$l_fuser\""
      chown "$l_fuser" "$l_fname"
    fi
    
    if [[ ! "$l_group" =~ $l_agroup ]]; then
      l_op2="$l_op2
- Group owned by: \"$l_group\" and should be group owned by \"${l_agroup//|/ or }\"
- Changing group ownership to: \"$l_fgroup\""
      chgrp "$l_fgroup" "$l_fname"
    fi
    
    [ -n "$l_op2" ] && l_output2="$l_output2
- File: \"$l_fname\" is:$l_op2 "
  }
  
  # NEW: Function to make permissions persistent for specific files
  make_persistent() {
    local file="$1"
    local mode="$2"
    local owner="$3"
    local group="$4"
    
    # Create a systemd service to fix permissions at boot
    cat > /etc/systemd/system/fix-$(basename "$file" | tr '/' '-').service << EOF
[Unit]
Description=Fix permissions for $file
After=local-fs.target
Before=syslog.service rsyslog.service systemd-journald.service

[Service]
Type=oneshot
ExecStart=/bin/chmod $mode "$file"
ExecStart=/bin/chown $owner:$group "$file"
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
    
    # Enable the service
    systemctl enable fix-$(basename "$file" | tr '/' '-').service
    
    # Also set up logrotate configuration if applicable
    if [[ "$file" == *.log || "$file" == *log/* ]]; then
      # Check if logrotate config exists for this file
      if [ -d /etc/logrotate.d ]; then
        # Create a logrotate postrotate script to maintain permissions
        local conf_file="/etc/logrotate.d/$(basename "$file")"
        if [ ! -f "$conf_file" ]; then
          echo "$file {
    create $mode $owner $group
    postrotate
        /bin/chmod $mode $file
        /bin/chown $owner:$group $file
    endscript
}" > /tmp/logrotate_tmp
          # Only add if not already configured
          if ! grep -q "create $mode $owner $group" /etc/logrotate.conf /etc/logrotate.d/* 2>/dev/null; then
            mv /tmp/logrotate_tmp "$conf_file"
          fi
        fi
      fi
    fi
  }
  
  unset a_file && a_file=()
  
  # Loop to create array with stat of files that could possibly fail one of the audits
  while IFS= read -r -d $'\0' l_file; do
    [ -e "$l_file" ] && a_file+=("$(stat -Lc '%n^%#a^%U^%u^%G^%g' "$l_file")")
  done < <(find -L /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -print0)
  
  # Track which files we fix for persistent setup
  declare -A fixed_files
  
  while IFS="^" read -r l_fname l_mode l_user l_uid l_group l_gid; do
    l_bname="$(basename "$l_fname")"
    case "$l_bname" in
      lastlog | lastlog.* | wtmp | wtmp.* | wtmp-* | btmp | btmp.* | btmp-*)
        perm_mask='0113'
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_rperms="ug-x,o-wx"
        l_auser="root"
        l_agroup="(root|utmp)"
        file_test_fix
        fixed_files["$l_fname"]="0640 root utmp"
        ;;
      secure | auth.log | syslog | messages)
        perm_mask='0137'
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_rperms="u-x,g-wx,o-rwx"
        l_auser="(root|syslog)"
        l_agroup="(root|adm)"
        file_test_fix
        fixed_files["$l_fname"]="0640 root adm"
        ;;
      SSSD | sssd)
        perm_mask='0117'
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_rperms="ug-x,o-rwx"
        l_auser="(root|SSSD)"
        l_agroup="(root|SSSD)"
        file_test_fix
        fixed_files["$l_fname"]="0640 root SSSD"
        ;;
      gdm | gdm3)
        perm_mask='0117'
        l_rperms="ug-x,o-rwx"
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_auser="root"
        l_agroup="(root|gdm|gdm3)"
        file_test_fix
        fixed_files["$l_fname"]="0640 root gdm"
        ;;
      *.journal | *.journal~)
        perm_mask='0137'
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_rperms="u-x,g-wx,o-rwx"
        l_auser="root"
        l_agroup="(root|systemd-journal)"
        file_test_fix
        fixed_files["$l_fname"]="0640 root systemd-journal"
        ;;
      dmesg | dmesg.*)  # NEW: Specific handling for dmesg
        perm_mask='0137'
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_rperms="u-x,g-wx,o-rwx"
        l_auser="root"
        l_agroup="(root|adm)"
        file_test_fix
        fixed_files["$l_fname"]="0640 root adm"
        ;;
      *)
        perm_mask='0137'
        maxperm="$( printf '%o' $(( 0777 & ~$perm_mask)) )"
        l_rperms="u-x,g-wx,o-rwx"
        l_auser="(root|syslog)"
        l_agroup="(root|adm)"
        if [ "$l_uid" -lt "$l_uidmin" ] && [ -z "$(awk -v grp="$l_group" -F: '$1==grp {print $4}' /etc/group)" ]; then
          if [[ ! "$l_user" =~ $l_auser ]]; then
            l_auser="(root|syslog|$l_user)"
          fi
          if [[ ! "$l_group" =~ $l_agroup ]]; then
            l_tst=""
            while l_out3="" read -r l_duid; do
              [ "$l_duid" -ge "$l_uidmin" ] && l_tst=failed
            done <<< "$(awk -F: '$4=='"$l_gid"' {print $3}' /etc/passwd)"
            [ "$l_tst" != "failed" ] && l_agroup="(root|adm|$l_group)"
          fi
        fi
        file_test_fix
        # Store for potential persistent fix
        if [ -n "$l_op2" ]; then
          fixed_files["$l_fname"]="$maxperm $l_fuser $l_fgroup"
        fi
        ;;
    esac
  done <<< "$(printf '%s\n' "${a_file[@]}")"
  
  unset a_file
  
  # NEW: Make permissions persistent for problematic files
  echo "Setting up persistent permissions for frequently recreated files..."
  for file in "${!fixed_files[@]}"; do
    if [[ "$file" =~ dmesg ]] || [[ "$file" =~ \.journal ]] || [[ "$file" =~ (wtmp|btmp|lastlog) ]]; then
      read mode owner group <<< "${fixed_files[$file]}"
      echo "Making permissions persistent for: $file (mode: $mode, owner: $owner:$group)"
      make_persistent "$file" "$mode" "$owner" "$group"
    fi
  done
  
  # Also create a cron job to run this script daily
  if ! crontab -l 2>/dev/null | grep -q "5\.1\.4\.sh"; then
    (crontab -l 2>/dev/null; echo "@daily /usr/local/bin/5.1.4.sh 2>&1 | logger -t 5.1.4-audit") | crontab -
    echo "Added daily cron job to maintain permissions"
  fi
  
  # Create a systemd service to run at boot
  cat > /etc/systemd/system/log-permissions.service << EOF
[Unit]
Description=Apply log file permissions
After=local-fs.target
Before=syslog.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/5.1.4.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
  
  systemctl daemon-reload
  systemctl enable log-permissions.service
  
  # If all files passed, then we report no changes
  if [ -z "$l_output2" ]; then
    echo -e "- All files in \"/var/log/\" have appropriate permissions and ownership
- No changes required "
  else
    # print report of changes
    echo -e " $l_output2"
    echo -e "\nNote: Persistent permissions have been configured for critical files."
    echo "A daily cron job has been set up to maintain permissions."
    echo "A systemd service (log-permissions.service) will run at boot to fix permissions."
  fi
}