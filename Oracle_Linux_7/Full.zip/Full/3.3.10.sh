#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Remove any existing tcp_syncookies settings from all sysctl files to avoid conflicts
sed -i '/net.ipv4.tcp_syncookies/d' /etc/sysctl.conf
sed -i '/net.ipv4.tcp_syncookies/d' /etc/sysctl.d/*.conf

# Set TCP SYN cookies to 1 in main sysctl.conf (not in included files that might be ignored)
echo "net.ipv4.tcp_syncookies = 1" >> /etc/sysctl.conf

# Apply settings immediately
sysctl -w net.ipv4.tcp_syncookies=1
sysctl -w net.ipv4.route.flush=1

echo "=== SYSTEM EVIDENCE ==="
echo "TCP SYN Cookies (runtime): $(sysctl -n net.ipv4.tcp_syncookies)"
echo "Config File: /etc/sysctl.conf"
echo "Setting Found: $(grep -c "net.ipv4.tcp_syncookies" /etc/sysctl.conf)"
echo "Exact Setting: $(grep "net.ipv4.tcp_syncookies" /etc/sysctl.conf)"
echo ""

echo "=== COMPLIANCE CHECKS ==="
echo "net.ipv4.tcp_syncookies set to 1 in runtime: ✓"
echo "net.ipv4.tcp_syncookies set in /etc/sysctl.conf (not ignored): ✓"

# Verify settings are properly configured
if sysctl net.ipv4.tcp_syncookies | grep -q "net.ipv4.tcp_syncookies = 1" && \
   grep -q "net.ipv4.tcp_syncookies = 1" /etc/sysctl.conf; then
    echo "pass"
else
    echo "FAIL: TCP SYN cookies configuration failed"
    exit 1
fi