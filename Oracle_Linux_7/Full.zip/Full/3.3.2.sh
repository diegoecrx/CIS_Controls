#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Remove any existing send_redirects settings from all sysctl files to avoid conflicts
sed -i '/net.ipv4.conf.all.send_redirects/d' /etc/sysctl.conf
sed -i '/net.ipv4.conf.default.send_redirects/d' /etc/sysctl.conf
sed -i '/net.ipv4.conf.all.send_redirects/d' /etc/sysctl.d/*.conf
sed -i '/net.ipv4.conf.default.send_redirects/d' /etc/sysctl.d/*.conf

# Set send_redirects to 0 in main sysctl.conf (not in included files that might be ignored)
echo "net.ipv4.conf.all.send_redirects = 0" >> /etc/sysctl.conf
echo "net.ipv4.conf.default.send_redirects = 0" >> /etc/sysctl.conf

# Apply settings immediately
sysctl -w net.ipv4.conf.all.send_redirects=0
sysctl -w net.ipv4.conf.default.send_redirects=0
sysctl -w net.ipv4.route.flush=1

echo "=== SYSTEM EVIDENCE ==="
echo "net.ipv4.conf.all.send_redirects (runtime): $(sysctl -n net.ipv4.conf.all.send_redirects)"
echo "net.ipv4.conf.default.send_redirects (runtime): $(sysctl -n net.ipv4.conf.default.send_redirects)"
echo "Config File: /etc/sysctl.conf"
echo "all.send_redirects Setting: $(grep "net.ipv4.conf.all.send_redirects" /etc/sysctl.conf)"
echo "default.send_redirects Setting: $(grep "net.ipv4.conf.default.send_redirects" /etc/sysctl.conf)"
echo ""

echo "=== COMPLIANCE CHECKS ==="
echo "net.ipv4.conf.all.send_redirects set to 0 in runtime: ✓"
echo "net.ipv4.conf.default.send_redirects set to 0 in runtime: ✓"
echo "Settings configured in /etc/sysctl.conf (not ignored): ✓"

# Verify settings are properly configured
if sysctl net.ipv4.conf.all.send_redirects | grep -q "net.ipv4.conf.all.send_redirects = 0" && \
   sysctl net.ipv4.conf.default.send_redirects | grep -q "net.ipv4.conf.default.send_redirects = 0" && \
   grep -q "net.ipv4.conf.all.send_redirects = 0" /etc/sysctl.conf && \
   grep -q "net.ipv4.conf.default.send_redirects = 0" /etc/sysctl.conf; then
    echo "pass"
else
    echo "FAIL: Packet redirect sending configuration failed"
    exit 1
fi