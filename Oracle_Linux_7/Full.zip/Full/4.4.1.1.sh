#!/usr/bin/env bash
# Script: 4.4.1.1.sh
# Item: 4.4.1.1 Ensure latest version of pam is installed (Automated)
set -euo pipefail
SCRIPT_NAME="4.4.1.1.sh"
ITEM_NAME="4.4.1.1 Ensure latest version of pam is installed (Automated)"
DESCRIPTION="This remediation ensures the latest version of pam is installed using yum upgrade."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking pam version..."
    pam_version=$(rpm -q --queryformat '%{VERSION}-%{RELEASE}' pam 2>/dev/null || echo "Not installed")
    if [ "$pam_version" = "Not installed" ]; then
        echo "FAIL: pam not installed"
        echo "PROOF: rpm -q pam returned not installed"
        return 1
    elif [[ "$pam_version" > "1.1.8-23" ]] || [[ "$pam_version" == "1.1.8-23" ]]; then
        echo "PASS: pam version >=1.1.8-23"
        echo "PROOF: $pam_version"
        return 0
    else
        echo "FAIL: pam version <$pam_version 1.1.8-23"
        echo "PROOF: $pam_version"
        return 1
    fi
}
# Function to upgrade
upgrade_pam() {
    echo "Upgrading pam..."
    yum upgrade -y pam >/dev/null 2>&1
    echo " - Upgraded pam"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        upgrade_pam
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: pam latest"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="