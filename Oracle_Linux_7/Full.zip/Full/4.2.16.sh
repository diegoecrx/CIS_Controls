#!/bin/bash

# Enforce CIS 4.2.16 - Ensure sshd MaxAuthTries is configured
echo "Enforcing CIS 4.2.16 - SSH MaxAuthTries configuration..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Check if MaxAuthTries is already set
if grep -q "^MaxAuthTries" /etc/ssh/sshd_config; then
    # Update existing setting to 4 (CIS recommended)
    sed -i 's/^MaxAuthTries.*/MaxAuthTries 4/' /etc/ssh/sshd_config
    echo "Updated existing MaxAuthTries setting to '4'"
else
    # Add new setting at the beginning (above any Match entries)
    sed -i '1iMaxAuthTries 4' /etc/ssh/sshd_config
    echo "Added MaxAuthTries 4 to /etc/ssh/sshd_config"
fi

# Restart sshd service to apply changes
echo "Restarting sshd service..."
systemctl restart sshd

# Verify configuration
echo "Verifying MaxAuthTries configuration..."

# Check if setting is correctly configured in file
if grep -q "^MaxAuthTries 4" /etc/ssh/sshd_config; then
    echo "SUCCESS: MaxAuthTries set to '4' in /etc/ssh/sshd_config"
else
    echo "ERROR: MaxAuthTries not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.16 remediation completed successfully"