#!/usr/bin/env bash
# Script: 6.2.9.sh
# Item: 6.2.9 Ensure root is the only UID 0 account (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.9.sh"
ITEM_NAME="6.2.9 Ensure root is the only UID 0 account (Automated)"
DESCRIPTION="This remediation ensures root is the only account with UID 0."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check for non-root UID 0 accounts
check_uid_zero_accounts() {
    echo "Checking for non-root UID 0 accounts..."
    non_root_uid_zero=""
    
    # Find all users with UID 0 that are not root
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -eq 0 ] && [ "$user" != "root" ]; then
            non_root_uid_zero="$non_root_uid_zero\n - User: $user (UID: 0)"
        fi
    done < /etc/passwd
    
    if [ -z "$non_root_uid_zero" ]; then
        echo "PASS: root is the only UID 0 account"
        echo "PROOF: No non-root accounts with UID 0 found"
        return 0
    else
        echo "FAIL: Found non-root accounts with UID 0:"
        echo -e "$non_root_uid_zero"
        return 1
    fi
}
# Function to fix non-root UID 0 accounts
fix_uid_zero_accounts() {
    echo "Fixing non-root UID 0 accounts..."
    
    # Get the next available UID starting from 1000
    next_uid=1000
    while grep -q "^[^:]*:[^:]*:$next_uid:" /etc/passwd; do
        next_uid=$((next_uid + 1))
    done
    
    # Find and fix all non-root users with UID 0
    while IFS=: read -r user _ uid _ _ _ _; do
        if [ "$uid" -eq 0 ] && [ "$user" != "root" ]; then
            echo " - Reassigning user \"$user\" from UID 0 to UID $next_uid"
            usermod -u "$next_uid" "$user"
            
            # Find files owned by the old UID 0 (except root's) and reassign
            find / -owner 0 -type f 2>/dev/null | while read -r file; do
                if [ ! -u "$file" ]; then  # Skip files that are not SUID
                    chown "$user" "$file" 2>/dev/null || true
                fi
            done
            
            next_uid=$((next_uid + 1))
        fi
    done < /etc/passwd
}
# Main remediation
{
    uid_ok=true
    if ! check_uid_zero_accounts; then
        uid_ok=false
    fi
    if [ "$uid_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_uid_zero_accounts
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_uid_zero_accounts; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: root is the only UID 0 account"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
