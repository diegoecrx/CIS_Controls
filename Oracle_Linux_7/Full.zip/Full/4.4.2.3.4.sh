#!/bin/bash

# Enforce CIS 4.4.2.3.4 - Ensure pam_pwhistory includes use_authtok
echo "Enforcing CIS 4.4.2.3.4 - pam_pwhistory use_authtok configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure pam_pwhistory with use_authtok for both files
for file in system-auth password-auth; do
    echo "Configuring pam_pwhistory with use_authtok in /etc/pam.d/${file}..."
    
    # Remove existing pam_pwhistory entries to avoid duplicates
    sed -i '/pam_pwhistory\.so/d' "/etc/pam.d/${file}"
    
    # Add pam_pwhistory with use_authtok after pam_pwquality in password section
    if grep -q "^password.*pam_pwquality\.so" "/etc/pam.d/${file}"; then
        # Insert pam_pwhistory after pam_pwquality
        sed -i '/^password.*pam_pwquality\.so/a password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' "/etc/pam.d/${file}"
    else
        # If pam_pwquality not found, add as second password entry
        if grep -q "^password" "/etc/pam.d/${file}"; then
            # Insert as second password entry
            sed -i '0,/^password.*/!{0,/^password.*/s/^password.*/password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok\n&/}' "/etc/pam.d/${file}"
        else
            # Add password section if it doesn't exist
            echo "password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok" >> "/etc/pam.d/${file}"
        fi
    fi
    
    # Ensure use_authtok is added to subsequent password lines (except pam_deny.so)
    sed -i '/^password.*pam_pwhistory\.so/!{/^password.*pam_deny\.so/!{/^password.*use_authtok/!s/^\(password.*\)$/\1 use_authtok/}}' "/etc/pam.d/${file}"
done

# Verify configuration
echo "Verifying use_authtok configuration..."

# Check for required configuration in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if pam_pwhistory is configured with use_authtok
    if grep -q "^password.*required.*pam_pwhistory\.so.*use_authtok" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_pwhistory with use_authtok configured in ${file}"
    else
        echo "ERROR: use_authtok not properly configured in ${file}"
        exit 1
    fi
    
    # Verify use_authtok parameter exists in pam_pwhistory line
    if grep -q "pam_pwhistory\.so.*use_authtok" "/etc/pam.d/${file}"; then
        echo "SUCCESS: use_authtok configured in pam_pwhistory in ${file}"
    else
        echo "ERROR: use_authtok not found in pam_pwhistory in ${file}"
        exit 1
    fi
    
    # Verify complete parameter set including use_authtok
    if grep -q "password.*required.*pam_pwhistory\.so.*remember=24.*enforce_for_root.*try_first_pass.*use_authtok" "/etc/pam.d/${file}"; then
        echo "SUCCESS: Complete pam_pwhistory configuration with use_authtok verified in ${file}"
    else
        echo "ERROR: Incomplete pam_pwhistory configuration in ${file}"
        exit 1
    fi
    
    # Verify subsequent password modules (except pam_deny) have use_authtok
    PASSWORD_LINES=$(grep -n "^password" "/etc/pam.d/${file}" | grep -v "pam_deny\.so" | tail -n +2)
    while IFS= read -r line; do
        if echo "$line" | grep -q "use_authtok"; then
            echo "SUCCESS: use_authtok found in subsequent password module"
        else
            echo "ERROR: use_authtok missing in subsequent password module: $line"
            exit 1
        fi
    done <<< "$PASSWORD_LINES"
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.3.4 remediation completed successfully"
echo "pam_pwhistory now properly configured with use_authtok parameter"