#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-time-change.rules"

{
    echo "-a always,exit -F arch=b64 -S adjtimex,settimeofday,clock_settime -k time-change"
    echo "-a always,exit -F arch=b32 -S adjtimex,settimeofday,clock_settime -k time-change"
    echo "-w /etc/localtime -p wa -k time-change"
} > "$RULES_FILE"

augenrules --load

if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi