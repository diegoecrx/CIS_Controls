#!/bin/bash

# Enforce CIS 4.5.2.4 - Ensure root password is set
echo "Enforcing CIS 4.5.2.4 - Root password configuration..."

# Check if root password is currently set
if grep -q '^root:[*!]' /etc/shadow; then
    echo "ERROR: Root password is not set (locked or invalid)"
    echo "Please set the root password manually using: passwd root"
    echo "This script cannot set the root password automatically for security reasons."
    exit 1
elif grep -q '^root::' /etc/shadow; then
    echo "ERROR: Root password is empty (no password set)"
    echo "Please set the root password manually using: passwd root"
    echo "This script cannot set the root password automatically for security reasons."
    exit 1
elif grep -q '^root:\$' /etc/shadow; then
    echo "SUCCESS: Root password is already set"
else
    echo "ERROR: Unable to determine root password status"
    echo "Please set the root password manually using: passwd root"
    exit 1
fi

# Verify configuration
echo "Verifying root password configuration..."

# Final verification using the original compliance check pattern
if grep -Eq '^root:\$[0-9]' /etc/shadow; then
    echo "SUCCESS: Root password is properly set"
    echo "CIS 4.5.2.4 remediation completed successfully"
else
    echo "ERROR: Root password is not set"
    echo "Please run 'passwd root' to set the root password manually"
    exit 1
fi