#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check IPv6 status with evidence
echo "Checking IPv6 status:"

# Check if IPv6 module parameter exists
if [[ ! -f /sys/module/ipv6/parameters/disable ]]; then
    echo "FAIL: Cannot determine IPv6 status - /sys/module/ipv6/parameters/disable not found"
    echo "EVIDENCE: IPv6 module parameter file does not exist"
    exit 1
fi

# Get the actual IPv6 disable parameter value
IPV6_DISABLE_VALUE=$(cat /sys/module/ipv6/parameters/disable 2>/dev/null)
echo "IPv6 disable parameter value: $IPV6_DISABLE_VALUE"

# Additional IPv6 status checks for comprehensive evidence
echo "Additional IPv6 status checks:"
ip -6 route show 2>/dev/null | head -5
IPV6_ROUTE_COUNT=$(ip -6 route show 2>/dev/null | wc -l)

# Check if any IPv6 addresses are configured
IPV6_ADDR_COUNT=$(ip -6 addr show 2>/dev/null | grep -c "inet6")
echo "IPv6 addresses configured: $IPV6_ADDR_COUNT"
echo "IPv6 routes configured: $IPV6_ROUTE_COUNT"

# Verification and result
if [[ "$IPV6_DISABLE_VALUE" == "0" ]]; then
    echo "FAIL: IPv6 is enabled - manual review required"
    echo "EVIDENCE: /sys/module/ipv6/parameters/disable = 0 (IPv6 enabled)"
    echo "EVIDENCE: $IPV6_ADDR_COUNT IPv6 addresses configured"
    echo "EVIDENCE: $IPV6_ROUTE_COUNT IPv6 routes configured"
    exit 1
else
    echo "PASS: IPv6 is disabled or not fully active"
    echo "EVIDENCE: /sys/module/ipv6/parameters/disable = $IPV6_DISABLE_VALUE"
    echo "EVIDENCE: $IPV6_ADDR_COUNT IPv6 addresses configured"
    echo "EVIDENCE: $IPV6_ROUTE_COUNT IPv6 routes configured"
    exit 0
fi