#!/usr/bin/env bash
# Script: 4.5.2.1.sh
# Item: 4.5.2.1 Ensure default group for the root account is GID 0 (Automated)
set -euo pipefail
SCRIPT_NAME="4.5.2.1.sh"
ITEM_NAME="4.5.2.1 Ensure default group for the root account is GID 0 (Automated)"
DESCRIPTION="This remediation ensures the root account has GID 0 as its default group."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check root account default group
check_root_group() {
    echo "Checking root account default group..."
    root_gid=$(grep '^root:' /etc/passwd | awk -F: '{print $4}')
    if [ "$root_gid" = "0" ]; then
        echo "PASS: root account default GID is 0"
        echo "PROOF: grep '^root:' /etc/passwd shows GID=$root_gid"
        return 0
    else
        echo "FAIL: root account default GID is $root_gid (should be 0)"
        echo "PROOF: grep '^root:' /etc/passwd shows GID=$root_gid"
        return 1
    fi
}
# Function to fix root account default group
fix_root_group() {
    echo "Fixing root account default group..."
    usermod -g 0 root
    echo " - Set root account default group to GID 0"
}
# Main remediation
{
    root_ok=true
    if ! check_root_group; then
        root_ok=false
    fi
    if [ "$root_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_root_group
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_root_group; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: root account default group is GID 0"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
