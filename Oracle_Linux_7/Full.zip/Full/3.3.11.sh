#!/usr/bin/env bash
# Script: 3.3.11.sh
# Item: 3.3.11 Ensure ipv6 router advertisements are not accepted (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.11.sh"
ITEM_NAME="3.3.11 Ensure ipv6 router advertisements are not accepted (Automated)"
DESCRIPTION="This remediation ensures IPv6 router advertisements are not accepted when IPv6 is enabled."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking IPv6 router advertisement configuration..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check current running values
    ipv6_all_accept_ra=$(sysctl -n net.ipv6.conf.all.accept_ra 2>/dev/null || echo "1")
    ipv6_default_accept_ra=$(sysctl -n net.ipv6.conf.default.accept_ra 2>/dev/null || echo "1")
    
    if [ "$ipv6_all_accept_ra" != "0" ]; then
        echo "FAIL: net.ipv6.conf.all.accept_ra is not disabled (current value: $ipv6_all_accept_ra)"
        return 1
    fi
    
    if [ "$ipv6_default_accept_ra" != "0" ]; then
        echo "FAIL: net.ipv6.conf.default.accept_ra is not disabled (current value: $ipv6_default_accept_ra)"
        return 1
    fi
    
    echo "PASS: IPv6 router advertisements properly disabled"
    echo "PROOF: Both all and default accept_ra set to 0 in running configuration"
    return 0
}

# Function to fix
fix_ipv6_router_advertisements() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Remove any existing conflicting entries from ALL configuration files
    echo " - Removing existing IPv6 accept_ra configurations"
    
    # Clean main sysctl file
    for file in /etc/sysctl.conf; do
        if [ -f "$file" ]; then
            sed -i '/^\s*net\.ipv6\.conf\.all\.accept_ra\s*=/d' "$file" 2>/dev/null || true
            sed -i '/^\s*net\.ipv6\.conf\.default\.accept_ra\s*=/d' "$file" 2>/dev/null || true
        fi
    done
    
    # Clean sysctl.d directory files
    if [ -d /etc/sysctl.d ]; then
        for file in /etc/sysctl.d/*.conf; do
            if [ -f "$file" ]; then
                sed -i '/^\s*net\.ipv6\.conf\.all\.accept_ra\s*=/d' "$file" 2>/dev/null || true
                sed -i '/^\s*net\.ipv6\.conf\.default\.accept_ra\s*=/d' "$file" 2>/dev/null || true
            fi
        done
    fi
    
    # Add IPv6 router advertisement configuration to dedicated file
    echo " - Configuring IPv6 router advertisements"
    CONFIG_FILE="/etc/sysctl.d/60-netipv6_sysctl.conf"
    
    # Ensure the file exists and remove any existing entries
    touch "$CONFIG_FILE"
    sed -i '/^\s*net\.ipv6\.conf\.all\.accept_ra\s*=/d' "$CONFIG_FILE" 2>/dev/null || true
    sed -i '/^\s*net\.ipv6\.conf\.default\.accept_ra\s*=/d' "$CONFIG_FILE" 2>/dev/null || true
    
    # Add the correct configuration
    {
        echo "# Disable IPv6 router advertisements - CIS Hardening"
        echo "net.ipv6.conf.all.accept_ra = 0"
        echo "net.ipv6.conf.default.accept_ra = 0"
    } >> "$CONFIG_FILE"
    
    # Set active kernel parameters
    echo " - Applying runtime settings"
    sysctl -w net.ipv6.conf.all.accept_ra=0 >/dev/null 2>&1 || true
    sysctl -w net.ipv6.conf.default.accept_ra=0 >/dev/null 2>&1 || true
    
    # Reload all sysctl settings
    echo " - Reloading sysctl configuration"
    sysctl --system >/dev/null 2>&1 || sysctl -p >/dev/null 2>&1
    
    echo " - IPv6 router advertisement configuration completed"
}

# Function to check configuration files
check_config_files() {
    echo "Checking configuration files for conflicts..."
    local found_conflict=0
    
    # Check all configuration files
    for file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
        if [ -f "$file" ] && [ "$file" != "/etc/sysctl.d/60-netipv6_sysctl.conf" ]; then
            if grep -Pq '^\s*net\.ipv6\.conf\.all\.accept_ra\s*=\s*[^0]' "$file" 2>/dev/null; then
                echo "CONFLICT: net.ipv6.conf.all.accept_ra enabled in $file"
                found_conflict=1
            fi
            if grep -Pq '^\s*net\.ipv6\.conf\.default\.accept_ra\s*=\s*[^0]' "$file" 2>/dev/null; then
                echo "CONFLICT: net.ipv6.conf.default.accept_ra enabled in $file"
                found_conflict=1
            fi
        fi
    done
    
    return $found_conflict
}

# Main remediation
{
    echo "Initial Status:"
    if check_current_status; then
        echo "No remediation needed"
    else
        echo ""
        check_config_files
        echo ""
        fix_ipv6_router_advertisements
        echo ""
        echo "Waiting for configuration to take effect..."
        sleep 2
    fi
    
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    
    # Final check
    if check_current_status; then
        echo "SUCCESS: IPv6 router advertisements properly disabled"
        echo ""
        echo "Final configuration check:"
        check_config_files && echo "No configuration conflicts found" || echo "Configuration conflicts detected"
    else
        echo "FAIL: Issues remain after remediation"
        echo ""
        echo "Current runtime values:"
        sysctl net.ipv6.conf.all.accept_ra net.ipv6.conf.default.accept_ra 2>/dev/null || true
        echo ""
        echo "Configuration file conflicts:"
        check_config_files
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="