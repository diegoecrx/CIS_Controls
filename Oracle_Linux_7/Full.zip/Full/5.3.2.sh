#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

cat > /etc/systemd/system/aidecheck.service << 'EOF'
[Unit]
Description=Aide Check

[Service]
Type=simple
ExecStart=/usr/sbin/aide --check

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/aidecheck.timer << 'EOF'
[Unit]
Description=Aide check every day at 5AM

[Timer]
OnCalendar=*-*-* 05:00:00
Unit=aidecheck.service

[Install]
WantedBy=multi-user.target
EOF

chown root:root /etc/systemd/system/aidecheck.*
chmod 0644 /etc/systemd/system/aidecheck.*

systemctl daemon-reload
systemctl enable aidecheck.service
systemctl --now enable aidecheck.timer

if systemctl is-enabled aidecheck.service | grep -q "enabled" && \
   systemctl is-enabled aidecheck.timer | grep -q "enabled" && \
   systemctl is-active aidecheck.timer | grep -q "active"; then
    echo "pass"
else
    echo "FAIL: AIDE scheduled check configuration failed"
    exit 1
fi