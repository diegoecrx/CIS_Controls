#!/bin/bash

# Enforce CIS 4.4.2.4.4 - Ensure pam_unix includes use_authtok
echo "Enforcing CIS 4.4.2.4.4 - Configure use_authtok for pam_unix..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure use_authtok for pam_unix in both files
for file in system-auth password-auth; do
    echo "Configuring use_authtok in /etc/pam.d/${file}..."
    
    # Process password pam_unix.so lines to ensure use_authtok is present
    if grep -q "^password.*pam_unix\.so" "/etc/pam.d/${file}"; then
        # Add use_authtok if not present
        sed -i '/^password.*pam_unix\.so/{
            /use_authtok/! s/pam_unix\.so.*$/& use_authtok/
        }' "/etc/pam.d/${file}"
        echo "Configured use_authtok in password pam_unix.so line in ${file}"
    else
        echo "WARNING: No password pam_unix.so line found in ${file}"
    fi
done

# Verify configuration
echo "Verifying use_authtok configuration..."

# Check for use_authtok in password pam_unix lines in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if password pam_unix line exists and has use_authtok
    if grep -q "^password.*pam_unix\.so.*use_authtok" "/etc/pam.d/${file}"; then
        echo "SUCCESS: use_authtok configured in password pam_unix.so line in ${file}"
    else
        echo "ERROR: use_authtok not found in password pam_unix.so line in ${file}"
        exit 1
    fi
    
    # Verify the complete password line structure
    PASSWORD_LINE=$(grep "^password.*pam_unix\.so" "/etc/pam.d/${file}")
    if echo "$PASSWORD_LINE" | grep -q "sha512.*shadow.*try_first_pass.*use_authtok"; then
        echo "SUCCESS: Complete password pam_unix.so configuration verified in ${file}"
    else
        echo "WARNING: Incomplete password pam_unix.so configuration in ${file}"
        # Show current configuration for debugging
        echo "Current password line: $PASSWORD_LINE"
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.4.4 remediation completed successfully"
echo "use_authtok parameter is now configured for pam_unix password module"