#!/bin/bash

# Enforce CIS 4.2.7 - Ensure sshd ClientAliveInterval and ClientAliveCountMax are configured
echo "Enforcing CIS 4.2.7 - SSH ClientAliveInterval and ClientAliveCountMax configuration..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Configure ClientAliveInterval
if grep -q "^ClientAliveInterval" /etc/ssh/sshd_config; then
    # Update existing setting to 15 (CIS recommended)
    sed -i 's/^ClientAliveInterval.*/ClientAliveInterval 15/' /etc/ssh/sshd_config
    echo "Updated existing ClientAliveInterval setting to '15'"
else
    # Add new setting at the beginning (above any Match entries)
    sed -i '1iClientAliveInterval 15' /etc/ssh/sshd_config
    echo "Added ClientAliveInterval 15 to /etc/ssh/sshd_config"
fi

# Configure ClientAliveCountMax
if grep -q "^ClientAliveCountMax" /etc/ssh/sshd_config; then
    # Update existing setting to 3 (CIS recommended)
    sed -i 's/^ClientAliveCountMax.*/ClientAliveCountMax 3/' /etc/ssh/sshd_config
    echo "Updated existing ClientAliveCountMax setting to '3'"
else
    # Add new setting at the beginning (above any Match entries)
    sed -i '1iClientAliveCountMax 3' /etc/ssh/sshd_config
    echo "Added ClientAliveCountMax 3 to /etc/ssh/sshd_config"
fi

# Restart sshd service to apply changes
echo "Restarting sshd service..."
systemctl restart sshd

# Verify configuration
echo "Verifying ClientAliveInterval and ClientAliveCountMax configuration..."

# Check if ClientAliveInterval is correctly configured
if grep -q "^ClientAliveInterval 15" /etc/ssh/sshd_config; then
    echo "SUCCESS: ClientAliveInterval set to '15' in /etc/ssh/sshd_config"
else
    echo "ERROR: ClientAliveInterval not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Check if ClientAliveCountMax is correctly configured
if grep -q "^ClientAliveCountMax 3" /etc/ssh/sshd_config; then
    echo "SUCCESS: ClientAliveCountMax set to '3' in /etc/ssh/sshd_config"
else
    echo "ERROR: ClientAliveCountMax not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Verify both settings are greater than 0
CLIENT_ALIVE_INTERVAL=$(grep "^ClientAliveInterval" /etc/ssh/sshd_config | awk '{print $2}')
CLIENT_ALIVE_COUNTMAX=$(grep "^ClientAliveCountMax" /etc/ssh/sshd_config | awk '{print $2}')

if [ "$CLIENT_ALIVE_INTERVAL" -gt 0 ]; then
    echo "SUCCESS: ClientAliveInterval is greater than 0"
else
    echo "ERROR: ClientAliveInterval is not greater than 0"
    exit 1
fi

if [ "$CLIENT_ALIVE_COUNTMAX" -gt 0 ]; then
    echo "SUCCESS: ClientAliveCountMax is greater than 0"
else
    echo "ERROR: ClientAliveCountMax is not greater than 0"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.7 remediation completed successfully"