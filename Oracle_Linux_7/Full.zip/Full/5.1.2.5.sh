#!/usr/bin/env bash
# Script: 5.1.2.5.sh
# Item: 5.1.2.5 Ensure journald is not configured to send logs to rsyslog (Manual)
set -euo pipefail
SCRIPT_NAME="5.1.2.5.sh"
ITEM_NAME="5.1.2.5 Ensure journald is not configured to send logs to rsyslog (Manual)"
DESCRIPTION="This remediation ensures journald is not configured to send logs to rsyslog by removing ForwardToSyslog=yes from /etc/systemd/journald.conf."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking journald rsyslog forwarding configuration..."
    
    # Check if ForwardToSyslog=yes exists in journald.conf
    if grep -qE '^\s*ForwardToSyslog\s*=\s*yes' /etc/systemd/journald.conf 2>/dev/null; then
        echo "FAIL: ForwardToSyslog=yes is configured in /etc/systemd/journald.conf"
        echo "PROOF: grep shows ForwardToSyslog=yes is present"
        return 1
    fi
    
    # Check if ForwardToSyslog is commented out or set to no
    if grep -qE '^\s*#\s*ForwardToSyslog' /etc/systemd/journald.conf 2>/dev/null || \
       grep -qE '^\s*ForwardToSyslog\s*=\s*no' /etc/systemd/journald.conf 2>/dev/null; then
        echo "PASS: journald is not configured to send logs to rsyslog"
        echo "PROOF: ForwardToSyslog is either commented out or set to no"
        return 0
    fi
    
    # If ForwardToSyslog is not found at all, that's also acceptable (default behavior)
    if ! grep -qE '^\s*ForwardToSyslog' /etc/systemd/journald.conf 2>/dev/null; then
        echo "PASS: ForwardToSyslog directive not found in configuration (using defaults)"
        echo "PROOF: No ForwardToSyslog directive present"
        return 0
    fi
    
    echo "FAIL: Unexpected ForwardToSyslog configuration"
    echo "PROOF: ForwardToSyslog is configured but not in expected state"
    return 1
}

# Function to fix
fix_journald_syslog_config() {
    echo "Applying fix..."
    
    # Create backup of original file
    if [ ! -f "/etc/systemd/journald.conf.bak" ]; then
        echo " - Creating backup of /etc/systemd/journald.conf"
        cp /etc/systemd/journald.conf /etc/systemd/journald.conf.bak
    fi
    
    # Remove or comment out ForwardToSyslog=yes
    echo " - Removing ForwardToSyslog=yes from /etc/systemd/journald.conf"
    
    # Use sed to comment out any ForwardToSyslog=yes lines
    sed -i 's/^\s*ForwardToSyslog\s*=\s*yes/#ForwardToSyslog=yes/g' /etc/systemd/journald.conf
    
    # Also ensure there's at least one commented example for documentation
    if ! grep -qE '^\s*#\s*ForwardToSyslog' /etc/systemd/journald.conf 2>/dev/null; then
        echo "#ForwardToSyslog=no" >> /etc/systemd/journald.conf
    fi
    
    # Restart journald service to apply changes
    echo " - Restarting systemd-journald service"
    systemctl reload-or-try-restart systemd-journald.service
    
    echo " - journald rsyslog forwarding configuration completed"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journald_syslog_config
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: journald is not configured to send logs to rsyslog"
    else
        echo "FAIL: Issues remain"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="