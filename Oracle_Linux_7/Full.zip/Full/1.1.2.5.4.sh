#!/usr/bin/env bash

# Script: 1.1.2.5.4.sh
# Item: 1.1.2.5.4 Ensure noexec option set on /var/tmp partition (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.1.2.5.4.sh"
ITEM_NAME="1.1.2.5.4 Ensure noexec option set on /var/tmp partition (Automated)"
DESCRIPTION="This remediation ensures the noexec option is set on the /var/tmp partition. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /var/tmp mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /var/tmp mount information:"
    mount | grep -E '\s/var/tmp\s' || echo "No separate /var/tmp mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /var/tmp:"
    grep -E '\s/var/tmp\s' /etc/fstab || echo "No /var/tmp entry in /etc/fstab"
    echo ""

    # Check if /var/tmp is a separate partition
    echo "Checking if /var/tmp is a separate partition:"
    vartmp_device=$(df /var/tmp --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    var_device=$(df /var --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$vartmp_device" ] && [ -n "$var_device" ] && [ "$vartmp_device" != "$var_device" ]; then
        echo "PASS: /var/tmp is on separate partition: $vartmp_device"
        vartmp_is_separate=true
    elif [ -n "$vartmp_device" ] && [ -n "$root_device" ] && [ "$vartmp_device" != "$root_device" ]; then
        echo "PASS: /var/tmp is on separate partition: $vartmp_device"
        vartmp_is_separate=true
    else
        echo "FAIL: /var/tmp is NOT on separate partition"
        if [ -n "$vartmp_device" ]; then
            echo "PROOF: /var/tmp shares device with $vartmp_device"
        else
            echo "PROOF: /var/tmp is not mounted separately"
        fi
        vartmp_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /var/tmp partition if needed
    if [ "$vartmp_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /VAR/TMP PARTITION WITH noexec OPTION"
        echo "==================================================================="
        echo ""

        # Call the partition creation script first if available
        if [ -f "1.1.2.5.1_v2.sh" ]; then
            /usr/bin/env bash 1.1.2.5.1_v2.sh
        else
            echo " - WARNING: 1.1.2.5.1_v2.sh not found. Creating partition manually with enforced noexec option..."
            
            # Manual partition creation as fallback
            echo " - Creating backup of /var/tmp to /var_tmp_backup_$(date +%Y%m%d_%H%M%S)..."
            backup_dir="/var_tmp_backup_$(date +%Y%m%d_%H%M%S)"
            mkdir -p "/$backup_dir"
            
            # Backup existing data
            if [ -d "/var/tmp" ] && [ "$(ls -A /var/tmp 2>/dev/null)" ]; then
                echo " - Backing up existing /var/tmp contents..."
                cp -a "/var/tmp"/* "/$backup_dir/" 2>/dev/null || true
            fi
            
            # Create loop device partition
            echo " - Creating 1GB disk image at /var_tmp_partition.img..."
            dd if=/dev/zero of=/var_tmp_partition.img bs=1M count=1024 status=progress
            mkfs.ext4 -F /var_tmp_partition.img
            
            # Mount and setup
            mkdir -p /mnt/newvartmp
            mount -o loop /var_tmp_partition.img /mnt/newvartmp
            chmod 1777 /mnt/newvartmp
            
            # Restore data
            if [ -d "/$backup_dir" ] && [ "$(ls -A /$backup_dir)" ]; then
                echo " - Restoring data to new partition..."
                cp -a "/$backup_dir"/* /mnt/newvartmp/ 2>/dev/null || true
            fi
            
            # Replace /var/tmp
            if [ -d "/var/tmp" ]; then
                mv /var/tmp /var/tmp.old
            fi
            mkdir -p /var/tmp
            umount /mnt/newvartmp
            
            # Mount with STRICT noexec option
            echo " - Mounting with strict noexec enforcement..."
            mount -o loop /var_tmp_partition.img /var/tmp
            mount -o remount,noexec,nosuid,nodev /var/tmp
            chmod 1777 /var/tmp
            
            # Update fstab with noexec option
            cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
            echo "/var_tmp_partition.img /var/tmp ext4 loop,noexec,nosuid,nodev 0 0" >> /etc/fstab
            
            rmdir /mnt/newvartmp
            echo " - SUCCESS: Manual /var/tmp partition creation with enforced noexec option completed"
        fi
        vartmp_is_separate=true
    fi

    echo "Applying noexec remediation..."

    # Function to update fstab with noexec option
    update_fstab_noexec()
    {
        # Check if /var/tmp entry exists in fstab
        if grep -q -E '\s/var/tmp\s' /etc/fstab; then
            echo " - Checking /var/tmp entry in /etc/fstab for noexec option"
            
            # Get the current /var/tmp entry
            current_entry=$(grep -E '\s/var/tmp\s' /etc/fstab)
            
            # Check if noexec option is already present
            if echo "$current_entry" | grep -q 'noexec'; then
                echo " - noexec option already present in /etc/fstab"
                return 0
            else
                echo " - Adding noexec option to /etc/fstab"
                
                # Create backup of fstab
                cp /etc/fstab /etc/fstab.backup.noexec.$(date +%Y%m%d_%H%M%S)
                echo " - Backup created: /etc/fstab.backup.noexec.$(date +%Y%m%d_%H%M%S)"
                
                # Create temporary fstab without /var/tmp entry
                grep -v -E '\s/var/tmp\s' /etc/fstab > /etc/fstab.tmp
                
                # Add noexec option to the mount options field (4th field)
                if echo "$current_entry" | grep -q 'defaults,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,noexec,/' | sed 's/,,/,/g')
                elif echo "$current_entry" | grep -q 'loop,'; then
                    updated_entry=$(echo "$current_entry" | sed 's/loop,/loop,noexec,/' | sed 's/,,/,/g')
                else
                    # If no specific options, add noexec to beginning
                    updated_entry=$(echo "$current_entry" | awk '{$4=$4",noexec"; print}')
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /var/tmp entry in /etc/fstab with noexec option"
            fi
        else
            echo " - ERROR: No /var/tmp entry found in /etc/fstab"
            return 1
        fi
    }

    # Function to remount /var/tmp with noexec option
    remount_vartmp_noexec()
    {
        echo " - Checking /var/tmp mount for noexec option"
        
        # Check if /var/tmp is mounted as separate filesystem
        if mount | grep -q -E '\s/var/tmp\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/var/tmp\s')
            
            # Check if noexec is already set in current mount
            if echo "$mount_line" | grep -q 'noexec'; then
                echo " - noexec option shown in mount output"
                
                # Test if noexec is actually working
                echo " - Testing if noexec is actually enforced..."
                test_script="/var/tmp/test_exec_$$.sh"
                
                # Create a simple test script
                cat > "$test_script" << 'EOF'
#!/bin/bash
echo "Script executed successfully - noexec is NOT working"
exit 0
EOF
                
                # Make it executable
                if chmod +x "$test_script" 2>/dev/null; then
                    # Try to execute it
                    if "$test_script" 2>/dev/null; then
                        echo " - WARNING: noexec option shown but script execution still works"
                        rm -f "$test_script"
                        
                        # Try forceful remount
                        echo " - Attempting forceful remount to enforce noexec..."
                        if mount -o remount,noexec,nosuid,nodev /var/tmp; then
                            echo " - SUCCESS: Forceful remount completed"
                            
                            # Test again after remount
                            cat > "$test_script" << 'EOF'
#!/bin/bash
echo "Script executed after remount"
exit 0
EOF
                            chmod +x "$test_script" 2>/dev/null
                            if "$test_script" 2>/dev/null; then
                                echo " - FAIL: Script still executes after forceful remount"
                                rm -f "$test_script"
                                return 1
                            else
                                echo " - SUCCESS: noexec now properly enforced after forceful remount"
                                rm -f "$test_script"
                                return 0
                            fi
                        else
                            echo " - ERROR: Could not perform forceful remount"
                            rm -f "$test_script"
                            return 1
                        fi
                    else
                        echo " - SUCCESS: noexec properly enforced - script execution blocked"
                        rm -f "$test_script"
                        return 0
                    fi
                else
                    echo " - INFO: Could not make test script executable"
                    return 0
                fi
            else
                echo " - noexec option NOT set on current /var/tmp mount"
                echo " - Remounting /var/tmp with noexec option"
                # Add noexec to current options and remount
                if mount -o remount,noexec /var/tmp; then
                    echo " - SUCCESS: /var/tmp remounted with noexec option"
                else
                    echo " - WARNING: Could not remount /var/tmp with noexec option"
                    return 1
                fi
            fi
        else
            echo " - ERROR: /var/tmp is not mounted as separate filesystem"
            return 1
        fi
    }

    # Function to remove existing executable files from /var/tmp
    remove_executable_files()
    {
        echo " - Scanning for executable files in /var/tmp..."
        exec_files=$(find /var/tmp -type f -executable 2>/dev/null | wc -l)
        if [ "$exec_files" -gt 0 ]; then
            echo " - WARNING: Found $exec_files executable files in /var/tmp"
            echo " - Removing execute permissions for security..."
            find /var/tmp -type f -executable -exec chmod -x {} \; 2>/dev/null || true
            echo " - SUCCESS: Execute permissions removed from files in /var/tmp"
            
            # Verify removal
            remaining_exec=$(find /var/tmp -type f -executable 2>/dev/null | wc -l)
            if [ "$remaining_exec" -gt 0 ]; then
                echo " - WARNING: $remaining_exec executable files still remain after removal attempt"
                echo " - Forcing removal with more aggressive method..."
                find /var/tmp -type f -executable -exec chmod 0644 {} \; 2>/dev/null || true
            fi
        else
            echo " - PASS: No executable files found in /var/tmp"
        fi
    }

    # Apply remediation steps
    if update_fstab_noexec; then
        remount_vartmp_noexec
        remove_executable_files
    else
        echo " - Skipping remount due to missing /var/tmp configuration"
    fi

    echo ""
    echo "Remediation of noexec option on /var/tmp partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /var/tmp is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /var/tmp IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/var/tmp\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /var/tmp is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /var/tmp is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify noexec option in current mount AND test enforcement
    echo ""
    echo "2. VERIFYING noexec OPTION ENFORCEMENT:"
    echo "--------------------------------------"
    mount_line=$(mount | grep -E '\s/var/tmp\s' || true)
    if echo "$mount_line" | grep -q 'noexec'; then
        echo "PASS: noexec option shown in mount output"
        echo "PROOF (mount output):"
        echo "$mount_line"
        
        # ACTUALLY TEST if noexec is working
        echo " - Testing actual noexec enforcement..."
        test_script="/var/tmp/verify_noexec_$$.sh"
        
        # Create test script
        cat > "$test_script" << 'EOF'
#!/bin/bash
echo "If you see this, noexec is NOT working"
exit 1
EOF
        
        # Make it executable
        if chmod +x "$test_script" 2>/dev/null; then
            # Try to execute it
            if "$test_script" 2>/dev/null; then
                echo "FAIL: noexec option shown BUT script execution still works"
                echo "PROOF: Script executed successfully despite noexec option"
                rm -f "$test_script"
                final_status_pass=false
                
                # Try emergency fix
                echo " - Applying emergency fix: unmount and remount..."
                umount /var/tmp 2>/dev/null || true
                mount -o loop,noexec,nosuid,nodev /var_tmp_partition.img /var/tmp
                chmod 1777 /var/tmp
                
                # Test again
                cat > "$test_script" << 'EOF'
#!/bin/bash
echo "Test after emergency fix"
exit 1
EOF
                chmod +x "$test_script" 2>/dev/null
                if "$test_script" 2>/dev/null; then
                    echo " - EMERGENCY FIX FAILED: Script execution still works"
                    rm -f "$test_script"
                else
                    echo " - EMERGENCY FIX SUCCESS: noexec now properly enforced"
                    rm -f "$test_script"
                    final_status_pass=true
                fi
            else
                echo "PASS: noexec option properly enforced - script execution blocked"
                echo "PROOF: Script execution failed as expected with noexec"
                rm -f "$test_script"
            fi
        else
            echo "PASS: noexec option properly enforced - cannot make script executable"
            echo "PROOF: chmod +x failed as expected with noexec"
            rm -f "$test_script"
        fi
    else
        echo "FAIL: noexec option NOT shown in mount output"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify noexec option in fstab
    echo ""
    echo "3. VERIFYING noexec OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/var/tmp\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'noexec'; then
            echo "PASS: noexec option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: noexec option NOT found in /etc/fstab"
            final_status_pass=false
        fi
    else
        echo "FAIL: No /var/tmp entry found in /etc/fstab"
        final_status_pass=false
    fi

    # PROOF 4: Verify no executable files remain in /var/tmp
    echo ""
    echo "4. VERIFYING NO EXECUTABLE FILES IN /var/tmp:"
    echo "--------------------------------------------"
    exec_files=$(find /var/tmp -type f -executable 2>/dev/null | wc -l)
    if [ "$exec_files" -eq 0 ]; then
        echo "PASS: No executable files found in /var/tmp"
        echo "PROOF: find /var/tmp -type f -executable returned 0 files"
    else
        echo "WARNING: Found $exec_files executable files in /var/tmp"
        echo " - Forcing removal of execute permissions..."
        find /var/tmp -type f -executable -exec chmod -x {} \; 2>/dev/null
        final_status_pass=false
    fi

    # PROOF 5: Test with compiled binary if gcc available
    echo ""
    echo "5. COMPREHENSIVE BINARY EXECUTION TEST:"
    echo "--------------------------------------"
    if command -v gcc >/dev/null 2>&1; then
        test_binary="/var/tmp/comprehensive_test_$$"
        cat > "${test_binary}.c" << 'EOF'
#include <stdio.h>
int main() { 
    printf("Binary executed successfully - noexec is NOT working\n");
    return 0;
}
EOF
        
        if gcc -o "$test_binary" "${test_binary}.c" 2>/dev/null; then
            chmod +x "$test_binary"
            # Try to execute
            if "$test_binary" 2>/dev/null; then
                echo "FAIL: Comprehensive test - compiled binary can execute"
                final_status_pass=false
            else
                echo "PASS: Comprehensive test - compiled binary cannot execute"
            fi
            rm -f "$test_binary" "${test_binary}.c"
        else
            echo "INFO: Comprehensive test skipped - compilation failed"
            rm -f "${test_binary}.c"
        fi
    else
        echo "INFO: Comprehensive test skipped - gcc not available"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo "noexec option is properly configured and enforced on /var/tmp"
        echo ""
        echo "FORCE MODE SUMMARY:"
        echo "==================="
        echo "✓ Separate /var/tmp partition created (if needed)"
        echo "✓ noexec option applied to /var/tmp partition"
        echo "✓ Configuration persisted in /etc/fstab"
        echo "✓ Executable files removed from /var/tmp"
        echo "✓ noexec enforcement verified through testing"
        echo "✓ Backups created for safety"
    else
        echo ""
        echo "CRITICAL: noexec option is not being properly enforced"
        echo "The mount shows noexec but executable files can still run."
        echo "This may require manual investigation of the filesystem configuration."
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="