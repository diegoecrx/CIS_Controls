#!/bin/bash
# 5.1.1.3 Ensure journald is configured to send logs to rsyslog
set -u

JOURNALD_CONF="/etc/systemd/journald.conf"
SETTING="ForwardToSyslog=yes"

# 1. Configure journald.conf
# Check if setting exists. If not, add/update it.
if ! grep -q "^$SETTING" "$JOURNALD_CONF"; then
    # Backup
    cp "$JOURNALD_CONF" "${JOURNALD_CONF}.bak"
    
    # If ForwardToSyslog exists but is wrong (e.g. =no), replace it
    if grep -q "^ForwardToSyslog=" "$JOURNALD_CONF"; then
        sed -i 's/^ForwardToSyslog=.*/ForwardToSyslog=yes/' "$JOURNALD_CONF"
    else
        # If [Journal] exists, append after it; otherwise append to file
        if grep -q "^\[Journal\]" "$JOURNALD_CONF"; then
            sed -i '/^\[Journal\]/a ForwardToSyslog=yes' "$JOURNALD_CONF"
        else
            echo -e "[Journal]\nForwardToSyslog=yes" >> "$JOURNALD_CONF"
        fi
    fi
    
    # Reload service
    systemctl reload-or-try-restart systemd-journald.service
fi

# 2. Verification & Evidence
# Output the line from the file to prove compliance
grep "^ForwardToSyslog" "$JOURNALD_CONF"

# Verify services are active
systemctl is-active systemd-journald rsyslog | sed 's/^/Service status: /'
