#!/bin/bash

# Create drop-in config for persistence
dropin_dir="/etc/systemd/journald.conf.d"
dropin_file="$dropin_dir/10-forward.conf"
mkdir -p "$dropin_dir"
cat > "$dropin_file" << EOF
[Journal]
ForwardToSyslog=yes
EOF

# Reload systemd
systemctl daemon-reload
systemctl restart systemd-journald

# Fallback: Edit main file via cron@reboot
cron_job="@reboot sed -i 's/^#*ForwardToSyslog=.*/ForwardToSyslog=yes/' /etc/systemd/journald.conf || echo 'ForwardToSyslog=yes' >> /etc/systemd/journald.conf && systemctl restart systemd-journald"
(crontab -l 2>/dev/null; echo "$cron_job") | crontab -