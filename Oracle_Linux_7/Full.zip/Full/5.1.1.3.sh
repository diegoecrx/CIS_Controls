#!/bin/bash
# 5.1.1.3 Ensure journald is configured to send logs to rsyslog
set -u

JOURNALD_CONF="/etc/systemd/journald.conf"
SETTING="ForwardToSyslog=yes"

# 1. Remediation (Configure journald.conf)
# Check if setting exists. If not, add/update it.
if ! grep -q "^$SETTING" "$JOURNALD_CONF"; then
    # Backup existing configuration
    cp "$JOURNALD_CONF" "${JOURNALD_CONF}.bak"
    
    # If ForwardToSyslog exists but is wrong (e.g. =no), replace it
    if grep -q "^ForwardToSyslog=" "$JOURNALD_CONF"; then
        sed -i 's/^ForwardToSyslog=.*/ForwardToSyslog=yes/' "$JOURNALD_CONF"
    else
        # If [Journal] exists, append after it; otherwise append to file
        if grep -q "^\[Journal\]" "$JOURNALD_CONF"; then
            sed -i '/^\[Journal\]/a ForwardToSyslog=yes' "$JOURNALD_CONF"
        else
            echo -e "[Journal]\nForwardToSyslog=yes" >> "$JOURNALD_CONF"
        fi
    fi
    
    # Reload service to apply changes
    systemctl reload-or-try-restart systemd-journald.service
fi

# 2. Detailed System Evidence
echo "=== Configuration Verification ==="
# Show file permissions and the specific line with filename context
ls -l "$JOURNALD_CONF"
grep -H "^ForwardToSyslog" "$JOURNALD_CONF"

echo ""
echo "=== Service Status Verification ==="
# Display full service status line to confirm 'loaded active running'
systemctl list-units --type service --no-pager | grep -E '(systemd-journald|rsyslog)\.service'
