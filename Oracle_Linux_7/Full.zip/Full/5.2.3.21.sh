#!/bin/bash

# Enforce CIS 5.2.3.21 - Ensure the running and on disk configuration is the same
echo "Enforcing CIS 5.2.3.21 - Synchronize running and on-disk audit configuration..."

# Create audit rules directory if it doesn't exist
if [ ! -d /etc/audit/rules.d ]; then
    mkdir -p /etc/audit/rules.d
    echo "Created /etc/audit/rules.d directory"
fi

# Load and synchronize audit rules
echo "Loading and synchronizing audit rules..."

# Check if augenrules is available
if command -v augenrules >/dev/null 2>&1; then
    # Load all rules to synchronize running and on-disk configuration
    augenrules --load
    echo "Loaded audit rules using augenrules to synchronize configurations"
    
    # Check if configurations are synchronized
    if augenrules --check 2>/dev/null | grep -q "No change"; then
        echo "SUCCESS: Running and on-disk audit configurations are synchronized"
    else
        echo "WARNING: Running and on-disk audit configurations may not be fully synchronized"
    fi
else
    echo "WARNING: augenrules command not found"
fi

# Restart auditd service to ensure rules are applied
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "Restarting auditd service..."
    systemctl restart auditd
fi

# Verify configuration
echo "Verifying audit configuration synchronization..."

# Check if audit rules directory exists and has files
if [ -d /etc/audit/rules.d ]; then
    RULE_COUNT=$(find /etc/audit/rules.d -name "*.rules" -type f | wc -l)
    if [ "$RULE_COUNT" -gt 0 ]; then
        echo "SUCCESS: Found $RULE_COUNT audit rule files in /etc/audit/rules.d/"
    else
        echo "WARNING: No audit rule files found in /etc/audit/rules.d/"
    fi
else
    echo "ERROR: /etc/audit/rules.d directory does not exist"
    exit 1
fi

# Check if auditd service is running
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "SUCCESS: auditd service is running"
else
    echo "WARNING: auditd service is not running"
fi

# Check if reboot is required (if auditctl is available and we're root)
if command -v auditctl >/dev/null 2>&1 && [ "$EUID" -eq 0 ]; then
    AUDIT_STATUS=$(auditctl -s | grep "enabled")
    if [[ "$AUDIT_STATUS" =~ "2" ]]; then
        echo "WARNING: Reboot required to load audit rules"
    else
        echo "SUCCESS: Audit rules should be active without reboot"
    fi
fi

# Final verification attempt with augenrules --check
if command -v augenrules >/dev/null 2>&1; then
    echo "Running final configuration check..."
    if augenrules --check 2>/dev/null | grep -q "No change"; then
        echo "SUCCESS: Audit configurations are properly synchronized"
    else
        echo "WARNING: Some configuration differences may still exist"
        echo "Note: This may be normal if rules were just loaded"
    fi
fi

echo "CIS 5.2.3.21 remediation completed successfully"
echo "Audit configuration synchronization process completed"