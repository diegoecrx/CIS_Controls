#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-user_emulation.rules"

{
    echo "-a always,exit -F arch=b64 -C euid!=uid -F auid!=unset -S execve -k user_emulation"
    echo "-a always,exit -F arch=b32 -C euid!=uid -F auid!=unset -S execve -k user_emulation"
} > "$RULES_FILE"

augenrules --load

if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi