#!/bin/bash
# 4.5.1.4 Ensure inactive password lock is 30 days or less
# + Interactive password reset (Smart Skip if updated today)
set -u

# 1. Set default for future users
useradd -D -f 30 >/dev/null
useradd -D | grep "INACTIVE"

echo "----------------------------------------------------------------"
echo "Checking for accounts requiring password updates..."

# 2. Process existing users
# Filter for valid users (skips locked '!' or invalid '*' password fields)
valid_users=$(awk -F: '$2 !~ /^[*!]/ && $2 != "" {print $1}' /etc/shadow)

# Calculate today's date in days since epoch (same format as shadow file)
current_day=$(($(date +%s) / 86400))

for user in $valid_users; do
    # Apply 30-day inactive limit (Remediation)
    chage --inactive 30 "$user"
    
    # Get shadow entry for evidence and timestamp check
    current_status=$(grep "^$user:" /etc/shadow)
    echo "Evidence: $current_status"
    
    # Extract last password change date (3rd field)
    last_change=$(echo "$current_status" | cut -d: -f3)
    
    # FIX: Skip prompt if password was changed today
    if [[ -n "$last_change" ]] && [[ "$last_change" -ge "$current_day" ]]; then
        echo "✓ Password was already updated today. Skipping interactive reset."
    else
        echo ""
        echo "User '$user' has been identified as an irregular/target account."
        read -p "Do you want to set a NEW password for '$user'? (y/n): " choice
        
        if [[ "$choice" =~ ^[Yy]$ ]]; then
            # Prompt for new password securely (input hidden)
            read -s -p "Enter new password for $user: " new_pass
            echo ""
            read -s -p "Retype new password: " new_pass_confirm
            echo ""

            if [[ "$new_pass" == "$new_pass_confirm" ]]; then
                # Securely pipe password to chpasswd
                echo "$user:$new_pass" | chpasswd
                if [[ $? -eq 0 ]]; then
                    echo "✓ Password for '$user' successfully updated."
                else
                    echo "✗ Failed to update password for '$user'." >&2
                fi
            else
                echo "✗ Passwords did not match. No change made." >&2
            fi
        else
            echo "Skipping password change for '$user'."
        fi
    fi
    echo "----------------------------------------------------------------"
done
