#!/bin/bash

# Enforce CIS 5.2.2.3 - Ensure system is disabled when audit logs are full
echo "Enforcing CIS 5.2.2.3 - Configure system behavior for full audit logs..."

# Configure auditd.conf
echo "Configuring /etc/audit/auditd.conf..."

# Create directory if it doesn't exist
if [ ! -d /etc/audit ]; then
    mkdir -p /etc/audit
    echo "Created /etc/audit directory"
fi

# Create or update auditd.conf
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "Creating /etc/audit/auditd.conf..."
    touch /etc/audit/auditd.conf
fi

# Backup original file
if [ ! -f /etc/audit/auditd.conf.bak ]; then
    cp /etc/audit/auditd.conf /etc/audit/auditd.conf.bak
    echo "Backed up /etc/audit/auditd.conf to /etc/audit/auditd.conf.bak"
fi

# Configure disk_full_action (halt the system when disk is full)
if grep -q "^disk_full_action" /etc/audit/auditd.conf; then
    # Update existing setting to halt
    sed -i 's/^disk_full_action.*/disk_full_action = halt/' /etc/audit/auditd.conf
    echo "Updated existing disk_full_action setting to 'halt'"
else
    # Add new setting
    echo "disk_full_action = halt" >> /etc/audit/auditd.conf
    echo "Added disk_full_action = halt to /etc/audit/auditd.conf"
fi

# Configure disk_error_action (halt the system on disk errors)
if grep -q "^disk_error_action" /etc/audit/auditd.conf; then
    # Update existing setting to halt
    sed -i 's/^disk_error_action.*/disk_error_action = halt/' /etc/audit/auditd.conf
    echo "Updated existing disk_error_action setting to 'halt'"
else
    # Add new setting
    echo "disk_error_action = halt" >> /etc/audit/auditd.conf
    echo "Added disk_error_action = halt to /etc/audit/auditd.conf"
fi

# Ensure other essential auditd settings are configured
AUDIT_SETTINGS=(
    "space_left_action = email"
    "action_mail_acct = root"
    "admin_space_left_action = halt"
)

for setting in "${AUDIT_SETTINGS[@]}"; do
    key=$(echo "$setting" | cut -d'=' -f1 | tr -d ' ')
    if grep -q "^$key" /etc/audit/auditd.conf; then
        # Update existing setting
        sed -i "s/^$key.*/$setting/" /etc/audit/auditd.conf
        echo "Updated existing $key setting"
    else
        # Add new setting
        echo "$setting" >> /etc/audit/auditd.conf
        echo "Added $setting to /etc/audit/auditd.conf"
    fi
done

# Set proper permissions on auditd.conf
chmod 640 /etc/audit/auditd.conf
chown root:root /etc/audit/auditd.conf

# Restart auditd service if it's running
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "Restarting auditd service..."
    systemctl restart auditd
fi

# Verify configuration
echo "Verifying audit log full action configuration..."

# Check if disk_full_action is correctly configured
if grep -q "^disk_full_action = halt" /etc/audit/auditd.conf; then
    echo "SUCCESS: disk_full_action = halt configured in /etc/audit/auditd.conf"
else
    echo "ERROR: disk_full_action not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Check if disk_error_action is correctly configured
if grep -q "^disk_error_action = halt" /etc/audit/auditd.conf; then
    echo "SUCCESS: disk_error_action = halt configured in /etc/audit/auditd.conf"
else
    echo "ERROR: disk_error_action not properly configured in /etc/audit/auditd.conf"
    exit 1
fi

# Verify file permissions
PERMS=$(stat -c %a /etc/audit/auditd.conf)
OWNER=$(stat -c %U:%G /etc/audit/auditd.conf)
if [ "$PERMS" = "640" ] && [ "$OWNER" = "root:root" ]; then
    echo "SUCCESS: /etc/audit/auditd.conf has correct permissions and ownership"
else
    echo "ERROR: /etc/audit/auditd.conf has incorrect permissions or ownership"
    exit 1
fi

# Check if auditd service is running (if installed)
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "SUCCESS: auditd service is running"
else
    echo "WARNING: auditd service is not running (may not be installed)"
fi

echo "CIS 5.2.2.3 remediation completed successfully"
echo "System will now halt when audit logs are full or disk errors occur"
echo "WARNING: This configuration will cause system shutdown on audit log issues"