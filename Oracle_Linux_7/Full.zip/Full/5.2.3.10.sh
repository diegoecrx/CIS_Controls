#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-mounts.rules"
UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)

[ "$EUID" -eq 0 ] || exit 1

# Create rules file
{
    echo "-a always,exit -F arch=b64 -S mount -F auid>=$UID_MIN -F auid!=unset -k mounts"
    echo "-a always,exit -F arch=b32 -S mount -F auid>=$UID_MIN -F auid!=unset -k mounts"
} > "$RULES_FILE"

echo "Created rules file:"
cat "$RULES_FILE"

# Load rules
echo "---"
echo "Loading rules:"
augenrules --load
auditctl -R "$RULES_FILE"

# Show proof
echo "---"
echo "Current loaded rules:"
auditctl -l | grep -E "arch=(b64|b32).*mount.*auid>=$UID_MIN"