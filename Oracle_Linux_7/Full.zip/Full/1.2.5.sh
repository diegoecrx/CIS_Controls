#!/bin/bash

[[ $EUID -ne 0 ]] && exit 1

# FIX 1: Disable repo_gpgcheck to prevent "404 Not Found" on .asc files (Critical Fix)
# This solves the "HTTPS Error 404" that caused your repos to disable themselves
sed -i 's/repo_gpgcheck=1/repo_gpgcheck=0/g' /etc/yum.repos.d/*.repo 2>/dev/null
yum clean all &>/dev/null

# FIX 2: Ensure default repositories are actually enabled
if ! yum repolist enabled 2>/dev/null | grep -q "repolist: [1-9]"; then
    yum install -y yum-utils &>/dev/null
    yum-config-manager --enable ol7_latest ol7_UEKR6 ol7_optional_latest &>/dev/null
fi

# EVIDENCE: Run check-update with standard system verbosity
# This output proves the check is actually running against valid repos
yum check-update
status=$?

# HANDLE RESULTS
if [[ $status -eq 100 ]]; then
    # Updates found: Install them (System output provides evidence)
    yum update -y --skip-broken
    
    # Verify clean state after update
    yum check-update
    if [[ $? -eq 0 ]]; then
        echo "pass"
    else
        exit 1
    fi
elif [[ $status -eq 0 ]]; then
    # No updates: Verify we didn't just "pass" because of 0 repos
    if yum repolist enabled 2>/dev/null | grep -q "repolist: 0"; then
        # Still no repos enabled - Force Fail
        exit 1
    fi
    echo "pass"
else
    # General yum error
    exit 1
fi

# Reboot check
needs-restarting -r 2>/dev/null || true
