#!/bin/bash
# 1.2.5 Ensure updates, patches, and additional security software are installed
set -u

echo "=== Starting System Update Verification (CIS 1.2.5) ==="

# 1. Repository Configuration
echo "[INFO] Step 1/3: Configuring and cleaning repositories..."
# Disable repo_gpgcheck to prevent metadata errors
sed -i 's/repo_gpgcheck=1/repo_gpgcheck=0/g' /etc/yum.repos.d/*.repo 2>/dev/null

# Run 'clean all' visibly so you see the cache being cleared
yum clean all

# Verify repositories are enabled
echo "[INFO] Checking repository status..."
if ! yum repolist enabled | grep -q "repolist: [1-9]"; then
    echo "[WARN] No active repositories found. Enabling defaults..."
    yum install -y yum-utils
    yum-config-manager --enable ol7_latest ol7_UEKR6 ol7_optional_latest
fi

# 2. Check for Updates
echo ""
echo "[INFO] Step 2/3: Checking for available updates..."
echo "       (This checks package metadata and may take a moment)"
# Run check-update directly to stdout so progress bars are visible
yum check-update
status=$?

# 3. Remediation Logic
if [[ $status -eq 100 ]]; then
    echo ""
    echo "[INFO] Step 3/3: Updates found. Installing now..."
    echo "======================================================="
    
    # Run update visibly with --skip-broken to ensure it doesn't abort entirely on minor deps
    yum update -y --skip-broken
    
    echo "======================================================="
    echo "[INFO] Installation complete. Verifying state..."
    
    # Final check
    yum check-update >/dev/null
    final_status=$?
    
    if [[ $final_status -eq 0 ]]; then
        echo "PASS - System is fully updated."
    else
        echo "WARNING: Some updates pending (Exit Code: $final_status). A reboot may be required."
    fi

elif [[ $status -eq 0 ]]; then
    echo ""
    echo "PASS - No updates available. System is already up to date."

else
    echo ""
    echo "FAIL - Yum encountered an error (Exit Code: $status)."
    exit 1
fi

# 4. Reboot Notification
if command -v needs-restarting >/dev/null; then
    needs-restarting -r >/dev/null || echo "NOTE: System requires a reboot to apply kernel/library updates."
fi
