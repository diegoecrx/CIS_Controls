#!/bin/bash
# 1.2.5 Ensure updates, patches, and additional security software are installed

# Ensure we are root
[[ $EUID -ne 0 ]] && exit 1

# 1. Auto-Fix: Repair Repositories to prevent 404 errors
# This allows the update process to actually run instead of failing
sed -i 's/repo_gpgcheck=1/repo_gpgcheck=0/g' /etc/yum.repos.d/*.repo 2>/dev/null
yum clean all &>/dev/null

# Ensure at least the default repos are enabled
if ! yum repolist enabled 2>/dev/null | grep -q "repolist: [1-9]"; then
    yum install -y yum-utils &>/dev/null
    yum-config-manager --enable ol7_latest ol7_UEKR6 ol7_optional_latest &>/dev/null
fi

# 2. Check for Updates
# yum check-update returns 100 if updates are available, 0 if none, 1 on error
check_out=$(yum check-update 2>&1)
status=$?

if [[ $status -eq 100 ]]; then
    # 3. Remediation: Install Updates
    echo "Updates available. Installing..."
    yum update -y --skip-broken
    
    # Re-verify
    if yum check-update &>/dev/null; then
        echo "pass"
    else
        echo "Update verification failed" >&2
        exit 1
    fi
elif [[ $status -eq 0 ]]; then
    # No updates needed
    # Verify we have valid repos enabled (avoid false pass on empty repolist)
    if yum repolist enabled 2>/dev/null | grep -q "repolist: 0"; then
        echo "Fail: No repositories enabled" >&2
        exit 1
    fi
    echo "pass"
else
    # Yum error (exit code 1)
    echo "Error checking updates" >&2
    exit 1
fi

# 4. Reboot Check
needs-restarting -r 2>/dev/null || true
