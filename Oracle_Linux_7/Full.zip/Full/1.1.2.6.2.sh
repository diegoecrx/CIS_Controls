#!/bin/bash

# Script: 1.1.2.6.2.sh
# Title: Ensure nodev option set on /var/log partition (Automated)
# Description: This remediation ensures the nodev option is set on the /var/log partition

set -euo pipefail

ITEM_NAME="1.1.2.6.2 Ensure nodev option set on /var/log partition (Automated)"
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: This remediation ensures the nodev option is set on the /var/log partition"
echo "Script: $(basename "$0")"
echo "==================================================================="
echo

LOG_MOUNT_POINT="/var/log"
FSTAB_FILE="/etc/fstab"
MOUNT_INFO="/proc/self/mountinfo"

# Function to log messages
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# Function to check if /var/log is a separate partition
check_separate_partition() {
    log "Checking if $LOG_MOUNT_POINT is a separate partition..."
    
    if grep -q "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$MOUNT_INFO"; then
        log "PASS: $LOG_MOUNT_POINT is on a separate partition"
        return 0
    else
        log "INFO: $LOG_MOUNT_POINT is not mounted as a separate filesystem"
        return 1
    fi
}

# Function to check current mount options
check_current_mount_options() {
    log "Checking current mount options for $LOG_MOUNT_POINT..."
    
    if mountpoint -q "$LOG_MOUNT_POINT"; then
        local mount_options
        mount_options=$(grep "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$MOUNT_INFO" | \
                       awk '{for(i=6;i<=NF;i++) if($i~/-/) break; for(j=5;j<i;j++) printf "%s ",$j}' | \
                       sed 's/.*- //' | tr -d '\n')
        
        if [[ -n "$mount_options" ]]; then
            log "Current mount options: $mount_options"
            if [[ "$mount_options" == *"nodev"* ]]; then
                log "PASS: nodev option is already set in current mount"
                return 0
            else
                log "WARNING: nodev option is NOT set in current mount"
                return 1
            fi
        fi
    fi
    return 1
}

# Function to check and fix fstab entry
check_and_fix_fstab() {
    log "Checking $FSTAB_FILE for $LOG_MOUNT_POINT entries..."
    
    local fstab_entries
    fstab_entries=$(grep "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$FSTAB_FILE" 2>/dev/null || true)
    
    if [[ -z "$fstab_entries" ]]; then
        log "INFO: No fstab entry found for $LOG_MOUNT_POINT"
        return 1
    fi
    
    log "Current fstab entries for $LOG_MOUNT_POINT:"
    echo "$fstab_entries"
    
    # Check if any entry needs fixing
    local needs_fix=0
    while IFS= read -r entry; do
        if [[ -n "$entry" && ! "$entry" =~ ^# ]]; then
            local options_field
            options_field=$(echo "$entry" | awk '{print $4}')
            
            if [[ "$options_field" != *"nodev"* ]]; then
                log "WARNING: fstab entry missing nodev option: $entry"
                needs_fix=1
            else
                log "PASS: fstab entry already has nodev option"
            fi
        fi
    done <<< "$fstab_entries"
    
    return $needs_fix
}

# Function to update fstab entry
update_fstab() {
    log "Updating $FSTAB_FILE to add nodev option..."
    
    # Create backup
    local backup_file="${FSTAB_FILE}.backup.$(date +%Y%m%d_%H%M%S)"
    cp "$FSTAB_FILE" "$backup_file"
    log "Created backup: $backup_file"
    
    # Process fstab file
    local temp_file
    temp_file=$(mktemp)
    
    while IFS= read -r line; do
        if [[ -n "$line" && ! "$line" =~ ^# ]] && echo "$line" | grep -q "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]"; then
            local device mount_point fstype options dump pass
            read -r device mount_point fstype options dump pass <<< "$line"
            
            # Add nodev if not present
            if [[ "$options" != *"nodev"* ]]; then
                log "Adding nodev to options: $options"
                # Handle default options properly
                if [[ "$options" == *"defaults"* ]]; then
                    options="${options},nodev"
                else
                    options="${options},nodev"
                fi
                line="$device $mount_point $fstype $options $dump $pass"
                log "Updated line: $line"
            fi
        fi
        echo "$line" >> "$temp_file"
    done < "$FSTAB_FILE"
    
    # Replace fstab file
    mv "$temp_file" "$FSTAB_FILE"
    chmod 644 "$FSTAB_FILE"
    
    log "Successfully updated $FSTAB_FILE"
}

# Function to remount partition
remount_partition() {
    log "Remounting $LOG_MOUNT_POINT with updated options..."
    
    if mountpoint -q "$LOG_MOUNT_POINT"; then
        if mount -o remount "$LOG_MOUNT_POINT"; then
            log "SUCCESS: $LOG_MOUNT_POINT remounted successfully"
            return 0
        else
            log "ERROR: Failed to remount $LOG_MOUNT_POINT"
            return 1
        fi
    else
        log "WARNING: $LOG_MOUNT_POINT is not currently mounted"
        return 1
    fi
}

# Function to verify remediation
verify_remediation() {
    log "Verifying remediation..."
    
    # Check mount options
    if check_current_mount_options; then
        log "SUCCESS: Verification passed - nodev option is set on $LOG_MOUNT_POINT"
        return 0
    else
        log "WARNING: Verification failed - nodev option may not be active"
        return 1
    fi
}

# Main execution
main() {
    log "Starting remediation for $ITEM_NAME"
    
    # Check if /var/log is a separate partition
    if ! check_separate_partition; then
        log "INFO: No separate partition found for $LOG_MOUNT_POINT. No remediation needed."
        exit 0
    fi
    
    local needs_remediation=0
    
    # Check current mount options
    if ! check_current_mount_options; then
        needs_remediation=1
    fi
    
    # Check fstab entries
    if ! check_and_fix_fstab; then
        needs_remediation=1
    fi
    
    # Apply remediation if needed
    if [[ $needs_remediation -eq 1 ]]; then
        log "Applying remediation..."
        
        # Update fstab
        update_fstab
        
        # Remount partition
        remount_partition
        
        # Verify remediation
        if verify_remediation; then
            log "REMEDIATION COMPLETE: Successfully enforced nodev option on $LOG_MOUNT_POINT"
        else
            log "REMEDIATION WARNING: Changes made but verification failed"
            exit 1
        fi
    else
        log "NO ACTION NEEDED: nodev option is already properly configured"
    fi
}

# Error handling
trap 'log "ERROR: Script execution failed at line $LINENO"; exit 1' ERR

# Run main function
main "$@"