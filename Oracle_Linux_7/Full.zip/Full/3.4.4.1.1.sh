#!/usr/bin/env bash
# Script: 3.4.4.1.1.sh
# Item: 3.4.4.1.1 Ensure iptables packages are installed (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.1.1.sh"
ITEM_NAME="3.4.4.1.1 Ensure iptables packages are installed (Automated)"
DESCRIPTION="This remediation ensures iptables and iptables-services packages are installed on the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking iptables packages installation..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    echo "PASS: iptables packages properly installed"
    echo "PROOF: Both iptables and iptables-services packages are installed"
    return 0
}
# Function to fix
fix_iptables_packages() {
    echo "Applying fix..."
    
    # Install iptables package
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    else
        echo " - iptables package already installed"
    fi
    
    # Install iptables-services package
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    else
        echo " - iptables-services package already installed"
    fi
    
    echo " - iptables packages installation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_packages
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: iptables packages properly installed"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="