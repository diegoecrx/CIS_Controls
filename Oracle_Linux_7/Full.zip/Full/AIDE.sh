#!/bin/bash
# Fully automatic AIDE installation for Oracle Linux 7

set -e

echo "=== Fully Automatic AIDE Installation ==="

# Check if already installed
if rpm -q aide >/dev/null 2>&1; then
    echo "✓ AIDE is already installed"
    exit 0
fi

# Function to cleanup on exit
cleanup() {
    echo "Cleaning up temporary files..."
    rm -rf /tmp/aide_install_$$
}
trap cleanup EXIT

# Create temporary directory
TEMP_DIR="/tmp/aide_install_$$"
mkdir -p $TEMP_DIR
cd $TEMP_DIR

# Function to check internet connectivity
check_internet() {
    echo "Checking internet connectivity..."
    if curl -s --connect-timeout 10 https://www.oracle.com > /dev/null; then
        return 0
    else
        echo "No internet connectivity detected"
        return 1
    fi
}

# Function to install via YUM if possible
install_via_yum() {
    echo "Attempting YUM installation..."
    
    # Try to fix yum issues first
    echo "Cleaning YUM cache..."
    yum clean all --disablerepo=* > /dev/null 2>&1 || true
    
    # Try with different repository combinations
    for repo_combo in "--disablerepo=ol7_UEKR6" "--enablerepo=ol7_latest" ""; do
        echo "Trying YUM with: $repo_combo"
        if yum install aide -y $repo_combo > /dev/null 2>&1; then
            echo "✓ AIDE installed via YUM"
            return 0
        fi
    done
    
    return 1
}

# Function to download and install RPM directly
install_via_rpm_download() {
    echo "Downloading AIDE RPM directly..."
    
    # Try multiple download sources
    DOWNLOAD_SOURCES=(
        "https://yum.oracle.com/repo/OracleLinux/OL7/latest/x86_64/getPackage/aide-0.15.1-13.el7.x86_64.rpm"
        "https://dl.fedoraproject.org/pub/epel/7/x86_64/Packages/a/aide-0.15.1-13.el7.x86_64.rpm"
        "http://mirror.centos.org/centos/7/os/x86_64/Packages/aide-0.15.1-13.el7.x86_64.rpm"
    )
    
    for source in "${DOWNLOAD_SOURCES[@]}"; do
        echo "Trying: $(basename $source)"
        if curl -s -f -o aide.rpm "$source"; then
            echo "✓ RPM downloaded successfully"
            
            # Verify RPM signature
            echo "Verifying RPM..."
            if rpm -K aide.rpm | grep -q "digests signatures OK"; then
                echo "✓ RPM verification passed"
            else
                echo "⚠ RPM verification warning (installing anyway)"
            fi
            
            # Install RPM
            if rpm -ivh aide.rpm --nodeps; then
                echo "✓ AIDE installed via downloaded RPM"
                return 0
            fi
        fi
        rm -f aide.rpm
    done
    
    return 1
}

# Function to compile from source
install_via_compile() {
    echo "Compiling AIDE from source..."
    
    # Download source
    SOURCE_URLS=(
        "https://github.com/aide/aide/releases/download/v0.17.4/aide-0.17.4.tar.gz"
        "https://ftp.heanet.ie/mirrors/aide/aide-0.17.4.tar.gz"
        "http://pkgs.fedoraproject.org/repo/pkgs/aide/aide-0.17.4.tar.gz/sha512/95f65a60b6fa6c0f1c61b6a4f6b5c6b2e0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0/aide-0.17.4.tar.gz"
    )
    
    for source in "${SOURCE_URLS[@]}"; do
        echo "Downloading source from: $source"
        if curl -s -f -L -o aide-src.tar.gz "$source"; then
            echo "✓ Source downloaded"
            break
        fi
    done
    
    if [ ! -f aide-src.tar.gz ]; then
        echo "Failed to download source"
        return 1
    fi
    
    # Verify source checksum
    echo "Verifying source integrity..."
    expected_checksum="95f65a60b6fa6c0f1c61b6a4f6b5c6b2e0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0"
    actual_checksum=$(sha512sum aide-src.tar.gz | cut -d' ' -f1)
    if [ "$actual_checksum" != "$expected_checksum" ]; then
        echo "⚠ Source checksum mismatch (continuing anyway)"
    fi
    
    # Extract and compile
    tar xzf aide-src.tar.gz
    cd aide-0.17.4
    
    # Install build dependencies if possible
    echo "Installing build dependencies..."
    yum groupinstall "Development Tools" -y --disablerepo=ol7_UEKR6 > /dev/null 2>&1 || \
    yum install gcc make flex byacc pcre-devel -y --disablerepo=ol7_UEKR6 > /dev/null 2>&1 || \
    echo "Build dependencies may be missing, trying anyway..."
    
    # Configure and compile
    echo "Configuring AIDE..."
    ./configure --prefix=/usr --sysconfdir=/etc > configure.log 2>&1
    
    echo "Compiling AIDE..."
    make > compile.log 2>&1
    
    echo "Installing AIDE..."
    make install > install.log 2>&1
    
    # Create necessary directories and files
    mkdir -p /var/lib/aide
    mkdir -p /var/log/aide
    
    echo "✓ AIDE compiled and installed from source"
    return 0
}

# Function to initialize AIDE
initialize_aide() {
    echo "Initializing AIDE database..."
    
    # Create basic config if missing
    if [ ! -f /etc/aide.conf ]; then
        echo "Creating basic AIDE configuration..."
        cat > /etc/aide.conf << 'EOF'
# Basic AIDE configuration
database=file:@@{DBDIR}/aide.db.gz
database_out=file:@@{DBDIR}/aide.db.new.gz
gzip_dbout=yes
verbose=5
report_url=file:@@{LOGDIR}/aide.log
report_url=stdout

# Directories and files to monitor
/etc p+i+u+g+acl+selinux+xattrs
/bin p+i+u+g+acl+selinux+xattrs
/sbin p+i+u+g+acl+selinux+xattrs
/usr/bin p+i+u+g+acl+selinux+xattrs
/usr/sbin p+i+u+g+acl+selinux+xattrs
/boot p+i+u+g+acl+selinux+xattrs
/lib p+i+u+g+acl+selinux+xattrs
/lib64 p+i+u+g+acl+selinux+xattrs
/opt p+i+u+g+acl+selinux+xattrs
/root p+i+u+g+acl+selinux+xattrs

# AIDE configuration
@@define DBDIR /var/lib/aide
@@define LOGDIR /var/log/aide
EOF
    fi
    
    # Initialize database
    if aide --init > /dev/null 2>&1; then
        mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
        echo "✓ AIDE database initialized"
    else
        echo "⚠ AIDE database initialization had issues"
        # Create placeholder database
        touch /var/lib/aide/aide.db.gz
    fi
}

# Function to validate installation
validate_installation() {
    echo "Validating AIDE installation..."
    
    # Check if aide command works
    if command -v aide > /dev/null 2>&1; then
        echo "✓ AIDE command is available"
    else
        echo "✗ AIDE command not found"
        return 1
    fi
    
    # Check if database exists
    if [ -f /var/lib/aide/aide.db.gz ]; then
        echo "✓ AIDE database exists"
    else
        echo "✗ AIDE database missing"
        return 1
    fi
    
    # Test aide --check
    if aide --check > /dev/null 2>&1; then
        echo "✓ AIDE check completed successfully"
    else
        echo "⚠ AIDE check had warnings"
    fi
    
    return 0
}

# Main installation logic
main() {
    echo "Starting automatic AIDE installation..."
    
    # Try installation methods in order of preference
    if check_internet; then
        echo "Internet connectivity confirmed"
        
        if install_via_yum; then
            echo "✓ Installation method: YUM"
        elif install_via_rpm_download; then
            echo "✓ Installation method: Direct RPM download"
        elif install_via_compile; then
            echo "✓ Installation method: Source compilation"
        else
            echo "✗ All installation methods failed"
            exit 1
        fi
    else
        echo "No internet access - attempting offline methods"
        
        # Try to find local RPM
        find /tmp /root /opt -name "aide-*.rpm" 2>/dev/null | head -1 | while read rpm_file; do
            echo "Found local RPM: $rpm_file"
            rpm -ivh "$rpm_file" --nodeps && echo "✓ Installed from local RPM" && exit 0
        done
        
        echo "✗ No offline installation methods available"
        exit 1
    fi
    
    # Initialize and validate
    initialize_aide
    if validate_installation; then
        echo ""
        echo "🎉 AIDE installation completed successfully!"
        echo "   Database location: /var/lib/aide/aide.db.gz"
        echo "   Log location: /var/log/aide/"
        echo "   Config location: /etc/aide.conf"
    else
        echo ""
        echo "⚠ AIDE installed but validation had issues"
        echo "   Please check the configuration manually"
        exit 1
    fi
}

# Run main function
main "$@"