#!/bin/bash

# Enforce CIS 4.4.2.4.3 - Ensure pam_unix includes a strong password hashing algorithm
echo "Enforcing CIS 4.4.2.4.3 - Configure strong password hashing algorithm (sha512)..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure strong password hashing algorithm in both files
for file in system-auth password-auth; do
    echo "Configuring strong password hashing in /etc/pam.d/${file}..."
    
    # Process password pam_unix.so lines to ensure sha512 and remove weak algorithms
    if grep -q "^password.*pam_unix\.so" "/etc/pam.d/${file}"; then
        # Remove weak hashing algorithms and ensure sha512 is present
        sed -i '/^password.*pam_unix\.so/{
            s/\s\(md5\|bigcrypt\|sha256\|blowfish\)\b//g
            /sha512/! s/pam_unix\.so/& sha512/
        }' "/etc/pam.d/${file}"
        echo "Configured strong password hashing algorithm in ${file}"
    else
        echo "WARNING: No password pam_unix.so line found in ${file}"
    fi
done

# Verify configuration
echo "Verifying strong password hashing configuration..."

# Check for sha512 algorithm in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if password pam_unix line exists and has sha512
    if grep -q "^password.*pam_unix\.so.*sha512" "/etc/pam.d/${file}"; then
        echo "SUCCESS: sha512 configured in password pam_unix.so line in ${file}"
    else
        echo "ERROR: sha512 not found in password pam_unix.so line in ${file}"
        exit 1
    fi
    
    # Check that weak algorithms are not present
    for weak_alg in md5 bigcrypt sha256 blowfish; do
        if grep -q "pam_unix\.so.*${weak_alg}" "/etc/pam.d/${file}"; then
            echo "ERROR: Weak algorithm ${weak_alg} still present in ${file}"
            exit 1
        else
            echo "SUCCESS: Weak algorithm ${weak_alg} not found in ${file}"
        fi
    done
    
    # Verify the complete password line structure
    PASSWORD_LINE=$(grep "^password.*pam_unix\.so" "/etc/pam.d/${file}")
    if echo "$PASSWORD_LINE" | grep -q "sha512.*shadow.*try_first_pass.*use_authtok"; then
        echo "SUCCESS: Complete password pam_unix.so configuration verified in ${file}"
    else
        echo "WARNING: Incomplete password pam_unix.so configuration in ${file}"
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.4.3 remediation completed successfully"
echo "Strong password hashing algorithm (sha512) is now configured"
echo "NOTE: Existing passwords will not be re-hashed until users change them"
echo "Consider expiring all user passwords to force immediate password changes"