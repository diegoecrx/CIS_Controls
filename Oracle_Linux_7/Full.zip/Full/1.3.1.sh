#!/usr/bin/env bash
# Script: 1.3.1.sh
# Item: 1.3.1 Ensure bootloader password is set (Automated)
set -euo pipefail
SCRIPT_NAME="1.3.1.sh"
ITEM_NAME="1.3.1 Ensure bootloader password is set (Automated)"
DESCRIPTION="This remediation ensures bootloader password is set using grub2-setpassword."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current bootloader password status..."
    if [ -f /boot/grub2/user.cfg ] && grep -q '^GRUB2_PASSWORD=' /boot/grub2/user.cfg; then
        echo "PASS: Bootloader password is set"
        echo "PROOF: /boot/grub2/user.cfg exists and contains GRUB2_PASSWORD"
        return 0
    elif [ -f /boot/efi/EFI/redhat/user.cfg ] && grep -q '^GRUB2_PASSWORD=' /boot/efi/EFI/redhat/user.cfg; then
        echo "PASS: Bootloader password is set (EFI)"
        echo "PROOF: /boot/efi/EFI/redhat/user.cfg exists and contains GRUB2_PASSWORD"
        return 0
    else
        echo "FAIL: Bootloader password is NOT set"
        echo "PROOF: No GRUB2_PASSWORD found in user.cfg"
        return 1
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        echo ""
        echo "Applying remediation..."
        echo "Note: Requires GRUB2 version 7.2 or later"
        grub2-setpassword
        echo " - Bootloader password set"
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Bootloader password is set"
    else
        echo "FAIL: Bootloader password not set"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="