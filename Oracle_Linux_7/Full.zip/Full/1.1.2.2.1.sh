#!/usr/bin/env bash

# Script: 1.1.2.2.1.sh
# Item: 1.1.2.2.1 Ensure /dev/shm is a separate partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.2.1.sh"
ITEM_NAME="1.1.2.2.1 Ensure /dev/shm is a separate partition (Automated)"
DESCRIPTION="This remediation ensures /dev/shm is mounted as a separate partition with appropriate security options."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /dev/shm mount status..."
    echo ""

    # Display current mount status
    echo "Current /dev/shm mount information:"
    mount | grep -E '\s/dev/shm\s' || echo "No separate /dev/shm mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /dev/shm:"
    grep -E '\s/dev/shm\s' /etc/fstab || echo "No /dev/shm entry in /etc/fstab"
    echo ""

    echo "Applying remediation..."

    # Function to add or update fstab entry
    update_fstab()
    {
        local shm_entry="tmpfs /dev/shm tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0"
        
        # Check if /dev/shm entry already exists in fstab
        if grep -q -E '\s/dev/shm\s' /etc/fstab; then
            echo " - Updating existing /dev/shm entry in /etc/fstab"
            # Create temporary fstab without /dev/shm entry
            grep -v -E '\s/dev/shm\s' /etc/fstab > /etc/fstab.tmp
            # Add the correct /dev/shm entry
            echo "$shm_entry" >> /etc/fstab.tmp
            # Backup original and replace
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo " - SUCCESS: Updated /dev/shm entry in /etc/fstab"
        else
            echo " - Adding new /dev/shm entry to /etc/fstab"
            echo "$shm_entry" >> /etc/fstab
            echo " - SUCCESS: Added /dev/shm entry to /etc/fstab"
        fi
    }

    # Function to mount /dev/shm with correct options
    mount_shm()
    {
        echo " - Mounting /dev/shm with security options"
        
        # Check if /dev/shm is already mounted as separate filesystem
        if mount | grep -q -E '\s/dev/shm\s'; then
            echo " - Remounting /dev/shm with security options"
            if mount -o remount,nosuid,nodev,noexec /dev/shm; then
                echo " - SUCCESS: /dev/shm remounted with security options"
            else
                echo " - WARNING: Could not remount /dev/shm, attempting full mount"
                umount /dev/shm 2>/dev/null || true
                mount /dev/shm
            fi
        else
            echo " - Mounting /dev/shm as new filesystem"
            # Ensure /dev/shm directory exists
            mkdir -p /dev/shm
            if mount /dev/shm; then
                echo " - SUCCESS: /dev/shm mounted"
            else
                echo " - Creating tmpfs mount for /dev/shm"
                mount -t tmpfs -o defaults,rw,nosuid,nodev,noexec,relatime tmpfs /dev/shm
                echo " - SUCCESS: /dev/shm mounted as tmpfs"
            fi
        fi
    }

    # Apply remediation steps
    update_fstab
    mount_shm

    echo ""
    echo "Remediation of /dev/shm partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /dev/shm is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /dev/shm IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/dev/shm\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /dev/shm is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /dev/shm is NOT mounted as separate filesystem - attempting to mount"
        mkdir -p /dev/shm
        mount /dev/shm
        mount_output=$(mount | grep -E '\s/dev/shm\s' || true)
        if [ -n "$mount_output" ]; then
            echo "PASS: /dev/shm is now mounted as separate filesystem"
            echo "PROOF (mount output):"
            echo "$mount_output"
        else
            echo "FAIL: Could not mount /dev/shm as separate filesystem"
            final_status_pass=false
        fi
    fi
    
    # PROOF 2: Verify /dev/shm entry exists in fstab
    echo ""
    echo "2. VERIFYING /dev/shm ENTRY IN /etc/fstab:"
    echo "------------------------------------------"
    fstab_entry=$(grep -E '\s/dev/shm\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        echo "PASS: /dev/shm entry found in /etc/fstab"
        echo "PROOF (/etc/fstab entry):"
        echo "$fstab_entry"
    else
        echo "FAIL: /dev/shm entry NOT found in /etc/fstab - adding now"
        echo "tmpfs /dev/shm tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0" >> /etc/fstab
        fstab_entry=$(grep -E '\s/dev/shm\s' /etc/fstab || true)
        if [ -n "$fstab_entry" ]; then
            echo "PASS: /dev/shm entry added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: Could not add /dev/shm entry to /etc/fstab"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify mount options
    echo ""
    echo "3. VERIFYING MOUNT OPTIONS:"
    echo "---------------------------"
    mount_options=$(mount | grep -E '\s/dev/shm\s' | grep -o -E 'nosuid|nodev|noexec' | tr '\n' ',' | sed 's/,$//')
    if echo "$mount_options" | grep -q "nosuid" && \
       echo "$mount_options" | grep -q "nodev" && \
       echo "$mount_options" | grep -q "noexec"; then
        echo "PASS: /dev/shm mounted with nosuid,nodev,noexec options"
        echo "PROOF (mount options):"
        mount | grep -E '\s/dev/shm\s'
    else
        echo "FAIL: /dev/shm NOT mounted with required security options - remounting"
        mount -o remount,nosuid,nodev,noexec /dev/shm
        mount_options=$(mount | grep -E '\s/dev/shm\s' | grep -o -E 'nosuid|nodev|noexec' | tr '\n' ',' | sed 's/,$//')
        if echo "$mount_options" | grep -q "nosuid" && \
           echo "$mount_options" | grep -q "nodev" && \
           echo "$mount_options" | grep -q "noexec"; then
            echo "PASS: /dev/shm remounted with security options"
            echo "PROOF (mount options):"
            mount | grep -E '\s/dev/shm\s'
        else
            echo "FAIL: Could not set required security options on /dev/shm"
            final_status_pass=false
        fi
    fi
    
    # PROOF 4: Verify filesystem type
    echo ""
    echo "4. VERIFYING FILESYSTEM TYPE:"
    echo "----------------------------"
    fs_type=$(mount | grep -E '\s/dev/shm\s' | grep -o 'tmpfs' || true)
    if [ "$fs_type" = "tmpfs" ]; then
        echo "PASS: /dev/shm mounted as tmpfs"
        echo "PROOF (filesystem type):"
        mount | grep -E '\s/dev/shm\s'
    else
        echo "WARNING: /dev/shm mounted as $fs_type (expected tmpfs)"
        echo "PROOF (filesystem type):"
        mount | grep -E '\s/dev/shm\s'
    fi
    
    # PROOF 5: Verify mount persistence after reboot
    echo ""
    echo "5. VERIFYING FSTAB ENTRY CORRECTNESS:"
    echo "-------------------------------------"
    expected_entry="tmpfs /dev/shm tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0"
    current_entry=$(grep -E '\s/dev/shm\s' /etc/fstab || true)
    if [ "$current_entry" = "$expected_entry" ]; then
        echo "PASS: /etc/fstab entry is correct"
        echo "PROOF (fstab entry):"
        echo "$current_entry"
    else
        echo "FAIL: /etc/fstab entry is incorrect - correcting"
        # Remove existing entry and add correct one
        grep -v -E '\s/dev/shm\s' /etc/fstab > /etc/fstab.tmp
        echo "$expected_entry" >> /etc/fstab.tmp
        cp /etc/fstab /etc/fstab.bak
        mv /etc/fstab.tmp /etc/fstab
        echo "PASS: /etc/fstab entry corrected"
        echo "PROOF (fstab entry):"
        grep -E '\s/dev/shm\s' /etc/fstab
    fi

    # PROOF 6: Test shared memory functionality
    echo ""
    echo "6. TESTING SHARED MEMORY FUNCTIONALITY:"
    echo "---------------------------------------"
    # Test basic shared memory operations
    if command -v ipcs >/dev/null 2>&1; then
        echo "PASS: Shared memory tools available (ipcs)"
        echo "PROOF (ipcs output):"
        ipcs -m | head -5
    else
        echo "INFO: ipcs command not available, shared memory functionality test skipped"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="