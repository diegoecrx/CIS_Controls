#!/usr/bin/env bash

# Script: 1.1.2.3.3.sh
# Item: 1.1.2.3.3 Ensure nosuid option set on /home partition (Automated)
# FORCE VERSION - Automatically creates partition if needed

set -euo pipefail

SCRIPT_NAME="1.1.2.3.3.sh"
ITEM_NAME="1.1.2.3.3 Ensure nosuid option set on /home partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /home partition. FORCE VERSION - Automatically creates partition if needed."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to create minimal home partition
create_minimal_home_partition() {
    echo "CREATING MINIMAL /HOME PARTITION..."
    echo "=================================="
    
    # Check available space
    available_space=$(df / --output=avail | tail -1 | tr -d ' ')
    available_space_mb=$((available_space / 1024))
    
    # Calculate home usage
    home_usage=$(du -s /home 2>/dev/null | cut -f1 || echo 0)
    home_usage_mb=$((home_usage / 1024))
    
    # Determine partition size
    if [ "$available_space_mb" -gt "$((home_usage_mb + 500))" ]; then
        partition_size_mb=$((home_usage_mb + 500))
    else
        partition_size_mb=$((home_usage_mb + 100))
    fi
    
    echo " - Home usage: ${home_usage_mb}MB"
    echo " - Available space: ${available_space_mb}MB" 
    echo " - Partition size: ${partition_size_mb}MB"
    echo ""
    
    # Create backup
    echo " - Creating backup of /home..."
    backup_dir="/root/home_migration_backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    cp -a /home/* "$backup_dir/" 2>/dev/null || true
    echo " - Backup created: $backup_dir"
    
    # Create partition image
    echo " - Creating ${partition_size_mb}MB partition image..."
    home_img="/root/home_partition.img"
    dd if=/dev/zero of="$home_img" bs=1M count="$partition_size_mb" status=progress
    mkfs.ext4 -F "$home_img"
    
    # Migrate data
    echo " - Migrating data to new partition..."
    mkdir -p /mnt/newhome
    mount -o loop "$home_img" /mnt/newhome
    cp -a /home/* /mnt/newhome/ 2>/dev/null || true
    echo "Home partition created $(date)" > /mnt/newhome/.home_partition_marker
    umount /mnt/newhome
    rmdir /mnt/newhome
    
    # Replace old home
    echo " - Activating new partition..."
    rm -rf /home.old 2>/dev/null || true
    mv /home /home.old
    mkdir /home
    mount -o loop "$home_img" /home
    
    # Update fstab with nosuid option already included
    echo " - Updating /etc/fstab..."
    cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
    echo "$home_img /home ext4 loop,defaults,nosuid 0 2" >> /etc/fstab
    
    echo " - SUCCESS: Minimal /home partition created with nosuid option"
    return 0
}

# Main remediation function
{
    echo "Checking current /home mount status and options..."
    echo ""

    # Display current mount status and options
    echo "Current /home mount information:"
    mount | grep -E '\s/home\s' || echo "No separate /home mount found"
    echo ""

    # Check if /home is a separate partition
    echo "Checking if /home is a separate partition:"
    home_device=$(df /home --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    root_device=$(df / --output=source 2>/dev/null | tail -1 | tr -d ' ' || true)
    
    if [ -n "$home_device" ] && [ -n "$root_device" ] && [ "$home_device" != "$root_device" ]; then
        echo "PASS: /home is on separate partition: $home_device"
        home_is_separate=true
    else
        echo "FAIL: /home is NOT on separate partition"
        echo "PROOF: /home shares device with root filesystem"
        home_is_separate=false
    fi
    echo ""

    # FORCE MODE: Automatically create separate /home partition if needed
    if [ "$home_is_separate" = false ]; then
        echo "==================================================================="
        echo "FORCE MODE: CREATING SEPARATE /HOME PARTITION WITH nosuid OPTION"
        echo "==================================================================="
        echo ""

        # Create partition with nosuid option pre-configured
        if create_minimal_home_partition; then
            home_is_separate=true
            echo " - FORCE MODE: Separate /home partition creation completed"
            echo ""
        else
            echo " - ERROR: Failed to create /home partition"
            exit 1
        fi
    fi

    echo "Applying nosuid remediation..."

    # Function to update fstab with nosuid option (only if partition already existed)
    update_fstab_nosuid()
    {
        # Only run if we didn't just create the partition
        if [ "$home_is_separate" = true ] && ! grep -q 'home_partition.img' /etc/fstab; then
            echo " - Checking /home entry in /etc/fstab for nosuid option"
            
            # Check if /home entry exists in fstab
            if grep -q -E '\s/home\s' /etc/fstab; then
                # Get the current /home entry
                current_entry=$(grep -E '\s/home\s' /etc/fstab)
                
                # Check if nosuid option is already present
                if echo "$current_entry" | grep -q 'nosuid'; then
                    echo " - nosuid option already present in /etc/fstab"
                    return 0
                else
                    echo " - Adding nosuid option to /etc/fstab"
                    
                    # Create backup of fstab
                    cp /etc/fstab /etc/fstab.backup.nosuid.$(date +%Y%m%d_%H%M%S)
                    
                    # Create temporary fstab without /home entry
                    grep -v -E '\s/home\s' /etc/fstab > /etc/fstab.tmp
                    
                    # Add nosuid option to the mount options field (4th field)
                    updated_entry=$(echo "$current_entry" | awk '
                    {
                        for(i=1; i<=NF; i++) {
                            if(i==4) {
                                if($i ~ /nosuid/) {
                                    print $0
                                } else {
                                    if($i ~ /,$/) {
                                        $i = $i "nosuid,"
                                    } else {
                                        $i = $i ",nosuid"
                                    }
                                    for(j=1; j<=NF; j++) {
                                        printf "%s", $j
                                        if(j<NF) printf " "
                                    }
                                    printf "\n"
                                }
                            }
                        }
                    }')
                    
                    # Fallback to sed if awk fails
                    if [ -z "$updated_entry" ]; then
                        if echo "$current_entry" | grep -q 'defaults,'; then
                            updated_entry=$(echo "$current_entry" | sed 's/defaults,/defaults,nosuid,/' | sed 's/,,/,/g')
                        else
                            updated_entry=$(echo "$current_entry" | sed 's/\(rw[^[:space:]]*\)/\1,nosuid/' | sed 's/,,/,/g')
                        fi
                    fi
                    
                    echo "$updated_entry" >> /etc/fstab.tmp
                    mv /etc/fstab.tmp /etc/fstab
                    echo " - SUCCESS: Updated /home entry in /etc/fstab with nosuid option"
                fi
            else
                echo " - ERROR: No /home entry found in /etc/fstab"
                return 1
            fi
        else
            echo " - Skipping fstab update (already configured during partition creation)"
            return 0
        fi
    }

    # Function to remount /home with nosuid option
    remount_home_nosuid()
    {
        echo " - Checking /home mount for nosuid option"
        
        # Check if /home is mounted as separate filesystem
        if mount | grep -q -E '\s/home\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/home\s')
            
            # Check if nosuid is already set in current mount
            if echo "$mount_line" | grep -q 'nosuid'; then
                echo " - nosuid option already set on current /home mount"
            else
                echo " - Remounting /home with nosuid option"
                # Remount to apply fstab options
                if mount -o remount /home; then
                    echo " - SUCCESS: /home remounted with nosuid option"
                else
                    echo " - WARNING: Could not remount /home, trying manual method"
                    # Manual remount with explicit nosuid
                    if mount -o remount,nosuid /home; then
                        echo " - SUCCESS: /home remounted with nosuid option"
                    else
                        echo " - ERROR: Could not remount /home with nosuid option"
                        return 1
                    fi
                fi
            fi
        else
            echo " - ERROR: /home is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nosuid; then
        remount_home_nosuid
    else
        echo " - Skipping remount due to missing /home configuration"
    fi

    echo ""
    echo "Remediation of nosuid option on /home partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /home is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /home IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "----------------------------------------------------"
    mount_output=$(mount | grep -E '\s/home\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /home is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /home is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nosuid option in current mount
    echo ""
    echo "2. VERIFYING nosuid OPTION IN CURRENT MOUNT:"
    echo "-------------------------------------------"
    mount_line=$(mount | grep -E '\s/home\s' || true)
    if echo "$mount_line" | grep -q 'nosuid'; then
        echo "PASS: nosuid option set on current /home mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nosuid option NOT set on current /home mount"
        echo "Attempting final remount..."
        if mount -o remount,nosuid /home 2>/dev/null; then
            mount_line=$(mount | grep -E '\s/home\s')
            if echo "$mount_line" | grep -q 'nosuid'; then
                echo "PASS: nosuid option now set on /home mount"
                echo "PROOF (mount output):"
                echo "$mount_line"
            else
                echo "FAIL: Could not set nosuid option on /home mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /home with nosuid option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nosuid option in fstab
    echo ""
    echo "3. VERIFYING nosuid OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/home\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nosuid'; then
            echo "PASS: nosuid option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nosuid option NOT found in /etc/fstab"
            # Auto-fix fstab
            echo " - Auto-fixing /etc/fstab..."
            cp /etc/fstab /etc/fstab.backup.fix
            grep -v -E '\s/home\s' /etc/fstab > /etc/fstab.tmp
            updated_entry=$(echo "$fstab_entry" | sed 's/\(defaults[^[:space:]]*\)/\1,nosuid/' | sed 's/,,/,/g')
            echo "$updated_entry" >> /etc/fstab.tmp
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nosuid option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/home\s' /etc/fstab
        fi
    else
        echo "FAIL: No /home entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options consistency
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_nosuid=$(grep -E '\s/home\s' /etc/fstab | grep -o 'nosuid' | head -1 || true)
    mount_has_nosuid=$(mount | grep -E '\s/home\s' | grep -o 'nosuid' | head -1 || true)
    
    if [ -n "$fstab_has_nosuid" ] && [ -n "$mount_has_nosuid" ]; then
        echo "PASS: nosuid option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab: $(grep -E '\s/home\s' /etc/fstab | awk '{print $4}')"
        echo "  mount: $(mount | grep -E '\s/home\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_has_nosuid" ] && [ -z "$mount_has_nosuid" ]; then
        echo "FAIL: nosuid in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_has_nosuid" ] && [ -n "$mount_has_nosuid" ]; then
        echo "FAIL: nosuid in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nosuid option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Verify data integrity
    echo ""
    echo "5. VERIFYING DATA INTEGRITY:"
    echo "---------------------------"
    if [ -d "/home" ] && [ -f "/home/.home_partition_marker" ]; then
        echo "PASS: New /home partition is active and verified"
    fi
    
    user_count=$(find /home -maxdepth 1 -type d -not -name "lost+found" -not -name "." | wc -l)
    if [ "$user_count" -gt 0 ]; then
        echo "PASS: /home contains $user_count user directories"
        echo "PROOF (user directories):"
        ls -la /home/ | grep -E '^d' | grep -v lost+found | head -5
    else
        echo "WARNING: No user directories found in /home"
        echo "Backup available in /home.old and /root/home_migration_backup_*"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
        echo ""
        if [ "$home_is_separate" = false ]; then
            echo "FORCE MODE SUMMARY:"
            echo "==================="
            echo "✓ Separate /home partition created"
            echo "✓ nosuid option applied to /home partition"
            echo "✓ Configuration persisted in /etc/fstab"
            echo "✓ User data preserved and migrated"
            echo "✓ Backups created for safety"
            echo ""
            echo "NOTE: Old /home data preserved in /home.old"
            echo "You can remove it after verifying the new partition works correctly."
        fi
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="