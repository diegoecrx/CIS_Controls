#!/bin/bash

# Enforce CIS 4.2.4 - Ensure sshd access is configured
echo "Enforcing CIS 4.2.4 - SSH access control configuration..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Get current user (to avoid locking ourselves out)
CURRENT_USER=$(whoami)

# Configure AllowUsers with current user to maintain access
# This is a basic configuration - adjust user list according to your environment
if grep -q "^AllowUsers" /etc/ssh/sshd_config; then
    # Update existing AllowUsers setting to include current user
    if ! grep -q "$CURRENT_USER" /etc/ssh/sshd_config; then
        sed -i "/^AllowUsers/s/$/ $CURRENT_USER/" /etc/ssh/sshd_config
        echo "Added $CURRENT_USER to existing AllowUsers list"
    else
        echo "Current user $CURRENT_USER already in AllowUsers list"
    fi
else
    # Add new AllowUsers setting at the beginning (above any Match entries)
    sed -i "1iAllowUsers $CURRENT_USER" /etc/ssh/sshd_config
    echo "Added AllowUsers $CURRENT_USER to /etc/ssh/sshd_config"
fi

# Remove any DenyUsers/DenyGroups that might block the current user if they exist
if grep -q "^DenyUsers.*$CURRENT_USER" /etc/ssh/sshd_config; then
    sed -i "/^DenyUsers.*$CURRENT_USER/d" /etc/ssh/sshd_config
    echo "Removed $CURRENT_USER from DenyUsers list"
fi

# Reload sshd service to apply changes
echo "Reloading sshd service..."
systemctl reload sshd

# Verify configuration
echo "Verifying SSH access control configuration..."

# Check if AllowUsers is configured
if grep -q "^AllowUsers" /etc/ssh/sshd_config; then
    echo "SUCCESS: AllowUsers is configured in /etc/ssh/sshd_config"
else
    echo "ERROR: AllowUsers not configured in /etc/ssh/sshd_config"
    exit 1
fi

# Check if current user is in AllowUsers list
if grep -q "^AllowUsers.*$CURRENT_USER" /etc/ssh/sshd_config; then
    echo "SUCCESS: Current user $CURRENT_USER is in AllowUsers list"
else
    echo "ERROR: Current user $CURRENT_USER not in AllowUsers list"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.4 remediation completed successfully"
echo "Note: Review and adjust AllowUsers/AllowGroups/DenyUsers/DenyGroups as needed for your environment"