#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Find SUID/SGID files with detailed information
echo "Checking for SUID and SGID files:"
SUID_SGID_FILES=$(find / -xdev -type f \( -perm -4000 -o -perm -2000 \) 2>/dev/null)

# Count files
FILE_COUNT=$(echo "$SUID_SGID_FILES" | grep -c '^/')

# Display detailed information about found files
if [[ $FILE_COUNT -gt 0 ]]; then
    echo "MANUAL REVIEW REQUIRED: $FILE_COUNT SUID/SGID files found"
    echo ""
    echo "Detailed file information:"
    echo "=========================="
    
    for file in $SUID_SGID_FILES; do
        if [ -f "$file" ]; then
            perms=$(stat -c "%a" "$file")
            owner=$(stat -c "%U" "$file")
            group=$(stat -c "%G" "$file")
            echo "  $file"
            echo "    permissions: $perms, owner: $owner, group: $group"
        fi
    done
    
    echo ""
    echo "EVIDENCE: Found $FILE_COUNT SUID/SGID files that require manual review"
    echo "ACTION: Review each file above to ensure they are legitimate and authorized"
    exit 1
else
    echo "PASS: No SUID/SGID files found"
    echo "EVIDENCE: find command returned 0 SUID/SGID files"
    exit 0
fi