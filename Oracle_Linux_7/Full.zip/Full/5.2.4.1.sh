#!/bin/bash

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check if auditd.conf exists
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "auditd.conf not found" >&2
    exit 1
fi

# Get audit log directory from auditd.conf
log_dir=$(awk -F "=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | xargs)
log_dir=$(dirname "$log_dir")

# Check if log directory exists
if [ ! -d "$log_dir" ]; then
    echo "Audit log directory $log_dir not found" >&2
    exit 1
fi

# Fix audit log directory permissions
chmod g-w,o-rwx "$log_dir"

# Verify remediation
result=$(stat -Lc "%n %a" "$log_dir" | grep -Pv -- '^\h*\H+\h+([0-7][0,1,4,5]0)' | awk '{print} END { if(NR==0) print "pass" ; else print "fail"}')

if [ "$result" = "pass" ]; then
    echo "Compliance achieved: Audit log directory $log_dir has permissions 0750 or more restrictive"
    echo "PROOF: $(stat -Lc "%n %a" "$log_dir")"
else
    echo "Remediation failed. Current permissions: $(stat -Lc "%a" "$log_dir")"
    exit 1
fi