#!/bin/bash

# Enforce CIS 4.4.2.2.1 - Ensure pam_pwquality module is enabled
echo "Enforcing CIS 4.4.2.2.1 - pam_pwquality module configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure pam_pwquality for both files
for file in system-auth password-auth; do
    echo "Configuring pam_pwquality in /etc/pam.d/${file}..."
    
    # Remove existing pam_pwquality entries to avoid duplicates
    sed -i '/pam_pwquality\.so/d' "/etc/pam.d/${file}"
    
    # Add pam_pwquality as the first line in password section
    if grep -q "^password" "/etc/pam.d/${file}"; then
        # Insert pam_pwquality as first password entry
        sed -i '0,/^password.*/s/^password.*/password    requisite     pam_pwquality.so try_first_pass local_users_only\n&/' "/etc/pam.d/${file}"
    else
        # Add password section if it doesn't exist
        echo "password    requisite     pam_pwquality.so try_first_pass local_users_only" >> "/etc/pam.d/${file}"
    fi
    
    # Ensure use_authtok is added to subsequent password lines (except pam_deny.so)
    sed -i '/^password.*pam_pwquality\.so/!{/^password.*pam_deny\.so/!{/^password.*use_authtok/!s/^\(password.*\)$/\1 use_authtok/}}' "/etc/pam.d/${file}"
done

# Verify configuration
echo "Verifying pam_pwquality configuration..."

# Check for required configuration in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if pam_pwquality is configured as first password entry
    if grep -q "^password.*requisite.*pam_pwquality\.so.*try_first_pass.*local_users_only" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_pwquality configured as first password entry in ${file}"
    else
        echo "ERROR: pam_pwquality not properly configured in ${file}"
        exit 1
    fi
    
    # Verify it's the first password entry
    FIRST_PASSWORD_LINE=$(grep -n "^password" "/etc/pam.d/${file}" | head -1 | cut -d: -f2)
    if echo "$FIRST_PASSWORD_LINE" | grep -q "pam_pwquality\.so"; then
        echo "SUCCESS: pam_pwquality is the first password module in ${file}"
    else
        echo "ERROR: pam_pwquality is not the first password module in ${file}"
        exit 1
    fi
    
    # Check for required parameters
    if grep -q "pam_pwquality\.so.*try_first_pass" "/etc/pam.d/${file}" && \
       grep -q "pam_pwquality\.so.*local_users_only" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_pwquality has required parameters in ${file}"
    else
        echo "ERROR: pam_pwquality missing required parameters in ${file}"
        exit 1
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.2.1 remediation completed successfully"