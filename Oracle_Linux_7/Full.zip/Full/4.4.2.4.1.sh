#!/bin/bash

# Enforce CIS 4.4.2.4.1 - Ensure pam_unix does not include nullok
echo "Enforcing CIS 4.4.2.4.1 - Remove nullok from pam_unix configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Remove nullok from pam_unix lines in both files
for file in system-auth password-auth; do
    echo "Removing nullok from pam_unix in /etc/pam.d/${file}..."
    
    # Remove nullok from all pam_unix.so lines
    sed -i '/pam_unix\.so/s/\snullok\b//g' "/etc/pam.d/${file}"
    sed -i '/pam_unix\.so/s/\snullok=.*\b//g' "/etc/pam.d/${file}"
    
    echo "Removed nullok parameters from pam_unix.so lines in ${file}"
done

# Verify configuration
echo "Verifying nullok removal..."

# Check that nullok is not present in pam_unix lines in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check if any pam_unix lines still contain nullok
    if grep -q "pam_unix\.so.*nullok" "/etc/pam.d/${file}"; then
        echo "ERROR: nullok still found in pam_unix lines in ${file}"
        exit 1
    else
        echo "SUCCESS: No nullok found in pam_unix lines in ${file}"
    fi
    
    # Verify pam_unix lines still exist and are functional
    if grep -q "^auth.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: auth pam_unix.so line present in ${file}"
    else
        echo "WARNING: auth pam_unix.so line not found in ${file}"
    fi
    
    if grep -q "^account.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: account pam_unix.so line present in ${file}"
    else
        echo "WARNING: account pam_unix.so line not found in ${file}"
    fi
    
    if grep -q "^password.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: password pam_unix.so line present in ${file}"
    else
        echo "WARNING: password pam_unix.so line not found in ${file}"
    fi
    
    if grep -q "^session.*pam_unix\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: session pam_unix.so line present in ${file}"
    else
        echo "WARNING: session pam_unix.so line not found in ${file}"
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: PAM configuration files are readable and configured"
    else
        echo "ERROR: PAM configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.4.1 remediation completed successfully"
echo "nullok parameter has been removed from all pam_unix.so lines"