#!/usr/bin/env bash
# Script: 2.2.16.sh
# Item: 2.2.16 Ensure tftp server services are not in use (Automated)
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures TFTP server services are not in use by removing or masking the tftp.socket, tftp.service, and tftp-server package. FORCE VERSION - Comprehensive TFTP server removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.16.sh"
ITEM_NAME="2.2.16 Ensure tftp server services are not in use (Automated)"
DESCRIPTION="This remediation ensures TFTP server services are not in use by removing or masking the tftp.socket, tftp.service, and tftp-server package. FORCE VERSION - Comprehensive TFTP server removal/masking."

if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

detect_package_manager() {
  if command -v yum >/dev/null 2>&1; then echo "yum";
  elif command -v dnf >/dev/null 2>&1; then echo "dnf";
  elif command -v apt-get >/dev/null 2>&1; then echo "apt";
  elif command -v zypper >/dev/null 2>&1; then echo "zypper";
  else echo "unknown"; fi
}

check_tftp_status() {
  echo "Checking TFTP server status..."
  if systemctl is-active tftp.service >/dev/null 2>&1; then
    echo " - tftp.service is active."
  fi
  if systemctl is-active tftp.socket >/dev/null 2>&1; then
    echo " - tftp.socket is active."
  fi
  if systemctl is-enabled tftp.service >/dev/null 2>&1; then
    echo " - tftp.service is enabled."
  fi
  if systemctl is-enabled tftp.socket >/dev/null 2>&1; then
    echo " - tftp.socket is enabled."
  fi
  if rpm -q tftp-server >/dev/null 2>&1; then
    echo " - tftp-server package is installed."
  fi
  if ss -tulpn 2>/dev/null | grep -Eq ':69'; then
    echo " - TFTP port 69 is open."
  fi
}

stop_tftp_service() {
  echo "Stopping tftp.socket and tftp.service..."
  systemctl stop tftp.socket tftp.service 2>/dev/null || true
  pkill -TERM in.tftpd 2>/dev/null || true
  pkill -KILL in.tftpd 2>/dev/null || true
}

remove_tftp_package() {
  local pkg_mgr="$1"
  echo "Removing tftp-server package if possible..."
  if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
    $pkg_mgr remove -y tftp-server 2>/dev/null || echo " - WARNING: Could not remove tftp-server (may be a dependency)."
    $pkg_mgr autoremove -y 2>/dev/null || true
  else
    echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
  fi
}

mask_tftp_service() {
  echo "Masking tftp.socket and tftp.service..."
  systemctl mask tftp.socket tftp.service 2>/dev/null || true
}

verify_tftp_removal() {
  echo "Verifying TFTP server remediation..."
  local failed=false
  if rpm -q tftp-server >/dev/null 2>&1; then
    echo "FAIL: tftp-server package is still installed."
    failed=true
  fi
  for svc in tftp.socket tftp.service; do
    if systemctl is-enabled $svc 2>/dev/null | grep -vq masked; then
      echo "FAIL: $svc is not masked."
      failed=true
    fi
    if systemctl is-active $svc 2>/dev/null | grep -vq inactive; then
      echo "FAIL: $svc is still active."
      failed=true
    fi
  done
  if ss -tulpn 2>/dev/null | grep -Eq ':69'; then
    echo "FAIL: TFTP port 69 is still open."
    failed=true
  fi
  if [ "$failed" = true ]; then
    return 1
  else
    return 0
  fi
}

check_tftp_status
echo ""
PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING TFTP SERVER SERVICE"
echo "==================================================================="
echo ""

stop_tftp_service
remove_tftp_package "$PKG_MGR"
mask_tftp_service
echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""
if verify_tftp_removal; then
  echo "SUCCESS: TFTP server service has been successfully remediated."
  echo ""
  echo "REMEDIATION SUMMARY:"
  echo "==================="
  echo "✓ Service stopped and processes terminated."
  echo "✓ Package removed or service masked."
  echo "✓ Service will not start at boot."
else
  echo "WARNING: TFTP server remediation may not be complete."
  echo "Please perform a manual review."
  echo ""
  echo "RECOMMENDED MANUAL ACTIONS:"
  echo "==========================="
  echo "1. Verify package removal: rpm -q tftp-server"
  echo "2. Ensure services are masked: systemctl status tftp.service tftp.socket"
  echo "3. Check port: ss -tulpn | grep ':69'"
fi
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
