#!/bin/bash

# Enforce CIS 4.4.2.2.4 - Ensure password complexity is configured
echo "Enforcing CIS 4.4.2.2.4 - Password complexity configuration..."

# Configure complexity settings in pwquality.conf
echo "Configuring password complexity in /etc/security/pwquality.conf..."

# Backup original file
if [ ! -f /etc/security/pwquality.conf.bak ]; then
    cp /etc/security/pwquality.conf /etc/security/pwquality.conf.bak
    echo "Backed up /etc/security/pwquality.conf to /etc/security/pwquality.conf.bak"
fi

# Remove existing complexity settings and add new ones
sed -ri 's/^(\s*)(minclass|lcredit|ucredit|dcredit|ocredit)\s*=.*/# &/' /etc/security/pwquality.conf

# Add complexity settings - using credit-based method as shown in example
echo "lcredit = -1" >> /etc/security/pwquality.conf
echo "ucredit = -1" >> /etc/security/pwquality.conf
echo "dcredit = -1" >> /etc/security/pwquality.conf
echo "ocredit = -1" >> /etc/security/pwquality.conf

# Remove complexity parameters from pam_pwquality.so lines in PAM files
echo "Removing complexity parameters from PAM files..."
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        # Backup PAM file
        if [ ! -f "/etc/pam.d/${pam_file}.bak" ]; then
            cp "/etc/pam.d/${pam_file}" "/etc/pam.d/${pam_file}.bak"
        fi
        
        # Remove complexity parameters from pam_pwquality.so lines
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+minclass\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+dcredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+ucredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+lcredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+ocredit\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        echo "Cleaned complexity parameters from /etc/pam.d/${pam_file}"
    fi
done

# Verify configuration
echo "Verifying password complexity configuration..."

# Check complexity settings in pwquality.conf
COMPLEXITY_SETTINGS=("lcredit" "ucredit" "dcredit" "ocredit")
for setting in "${COMPLEXITY_SETTINGS[@]}"; do
    if grep -q "^${setting}\s*=\s*-1" /etc/security/pwquality.conf; then
        echo "SUCCESS: ${setting} = -1 configured in /etc/security/pwquality.conf"
    else
        echo "ERROR: ${setting} not properly configured in /etc/security/pwquality.conf"
        exit 1
    fi
done

# Verify complexity parameters are not in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        for setting in minclass dcredit ucredit lcredit ocredit; do
            if ! grep -q "pam_pwquality\.so.*${setting}" "/etc/pam.d/${pam_file}"; then
                echo "SUCCESS: ${setting} parameter removed from /etc/pam.d/${pam_file}"
            else
                echo "ERROR: ${setting} parameter still present in /etc/pam.d/${pam_file}"
                exit 1
            fi
        done
    fi
done

# Verify pam_pwquality is still properly configured in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if grep -q "^password.*requisite.*pam_pwquality\.so.*try_first_pass.*local_users_only" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: pam_pwquality properly configured in /etc/pam.d/${pam_file}"
        else
            echo "ERROR: pam_pwquality configuration broken in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/security/pwquality.conf ] && [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: Configuration files are readable and properly configured"
    else
        echo "ERROR: Configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.2.4 remediation completed successfully"
echo "Password policy now requires: lowercase, uppercase, digit, and special character"