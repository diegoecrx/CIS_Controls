#!/usr/bin/env bash

# Script: 1.2.3.sh
# Item: 1.2.3 Ensure repo_gpgcheck is globally activated (Manual) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="1.2.3.sh"
ITEM_NAME="1.2.3 Ensure repo_gpgcheck is globally activated (Manual)"
DESCRIPTION="This remediation ensures repo_gpgcheck is globally activated in yum configuration. FORCE VERSION - Configures global and per-repository GPG checking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check_yum_config
check_yum_config() {
    echo "Checking current yum configuration..."
    
    # Check if yum is available
    if ! command -v yum >/dev/null 2>&1 && ! command -v dnf >/dev/null 2>&1; then
        echo "ERROR: Neither yum nor dnf package manager found"
        return 1
    fi
    
    # Check global yum configuration
    if [ -f "/etc/yum.conf" ]; then
        echo " - Checking /etc/yum.conf..."
        if grep -q "^repo_gpgcheck=1" /etc/yum.conf; then
            echo "   - PASS: repo_gpgcheck=1 found in /etc/yum.conf"
            global_gpgcheck=true
        else
            echo "   - FAIL: repo_gpgcheck=1 not found in /etc/yum.conf"
            global_gpgcheck=false
        fi
        
        # Check if repo_gpgcheck is commented or set to 0
        if grep -q "^#repo_gpgcheck" /etc/yum.conf || grep -q "^repo_gpgcheck=0" /etc/yum.conf; then
            echo "   - WARNING: repo_gpgcheck is disabled or commented in /etc/yum.conf"
            global_gpgcheck=false
        fi
    else
        echo "   - WARNING: /etc/yum.conf not found"
        global_gpgcheck=false
    fi
    
    # Check dnf configuration if available
    if [ -f "/etc/dnf/dnf.conf" ]; then
        echo " - Checking /etc/dnf/dnf.conf..."
        if grep -q "^repo_gpgcheck=1" /etc/dnf/dnf.conf; then
            echo "   - PASS: repo_gpgcheck=1 found in /etc/dnf/dnf.conf"
            dnf_gpgcheck=true
        else
            echo "   - FAIL: repo_gpgcheck=1 not found in /etc/dnf/dnf.conf"
            dnf_gpgcheck=false
        fi
    fi
    
    # Check repository configurations
    echo " - Checking repository configurations in /etc/yum.repos.d/..."
    repo_files_found=0
    repos_with_gpgcheck=0
    repos_without_gpgcheck=0
    repos_with_disabled_gpgcheck=0
    
    if [ -d "/etc/yum.repos.d" ]; then
        for repo_file in /etc/yum.repos.d/*.repo; do
            if [ -f "$repo_file" ]; then
                repo_files_found=$((repo_files_found + 1))
                echo "   - Checking: $(basename "$repo_file")"
                
                # Count repositories in file
                repo_count=$(grep -c "^\[" "$repo_file")
                echo "     - Contains $repo_count repository sections"
                
                # Check for repo_gpgcheck settings
                if grep -q "^repo_gpgcheck=1" "$repo_file"; then
                    repos_with_gpgcheck=$((repos_with_gpgcheck + 1))
                    echo "     - PASS: repo_gpgcheck=1 found"
                elif grep -q "^repo_gpgcheck=0" "$repo_file" || grep -q "^#repo_gpgcheck" "$repo_file"; then
                    repos_with_disabled_gpgcheck=$((repos_with_disabled_gpgcheck + 1))
                    echo "     - FAIL: repo_gpgcheck disabled or commented"
                else
                    repos_without_gpgcheck=$((repos_without_gpgcheck + 1))
                    echo "     - FAIL: No repo_gpgcheck setting found"
                fi
                
                # Show repository names for debugging
                grep "^\[" "$repo_file" | sed 's/\[//g' | sed 's/\]//g' | while read -r repo; do
                    echo "       - Repository: $repo"
                done
            fi
        done
    else
        echo "   - WARNING: /etc/yum.repos.d directory not found"
    fi
    
    echo ""
    echo "SUMMARY:"
    echo "========="
    echo "Global yum.conf repo_gpgcheck: $([ "$global_gpgcheck" = true ] && echo "ENABLED" || echo "DISABLED/MISSING")"
    if [ -f "/etc/dnf/dnf.conf" ]; then
        echo "Global dnf.conf repo_gpgcheck: $([ "$dnf_gpgcheck" = true ] && echo "ENABLED" || echo "DISABLED/MISSING")"
    fi
    echo "Repository files found: $repo_files_found"
    echo "Repositories with repo_gpgcheck=1: $repos_with_gpgcheck"
    echo "Repositories with disabled/commented repo_gpgcheck: $repos_with_disabled_gpgcheck"
    echo "Repositories without repo_gpgcheck setting: $repos_without_gpgcheck"
    
    return 0
}

# Function to configure_global_gpgcheck
configure_global_gpgcheck() {
    echo "Configuring global repo_gpgcheck settings..."
    
    # Configure /etc/yum.conf
    if [ -f "/etc/yum.conf" ]; then
        echo " - Configuring /etc/yum.conf..."
        backup_file="/etc/yum.conf.backup.$(date +%Y%m%d_%H%M%S)"
        cp /etc/yum.conf "$backup_file"
        echo "   - Backup created: $backup_file"
        
        # Remove any existing repo_gpgcheck lines
        grep -v "^repo_gpgcheck" /etc/yum.conf > /etc/yum.conf.tmp
        
        # Check if [main] section exists
        if grep -q "^\[main\]" /etc/yum.conf.tmp; then
            # Add repo_gpgcheck after [main] section
            sed -i '/^\[main\]/a repo_gpgcheck=1' /etc/yum.conf.tmp
            echo "   - Added repo_gpgcheck=1 to [main] section"
        else
            # Create [main] section and add repo_gpgcheck
            echo -e "[main]\nrepo_gpgcheck=1" > /etc/yum.conf.tmp
            # Append the rest of the original file (excluding any existing repo_gpgcheck)
            grep -v "^repo_gpgcheck" /etc/yum.conf | grep -v "^\[main\]" >> /etc/yum.conf.tmp
            echo "   - Created [main] section with repo_gpgcheck=1"
        fi
        
        mv /etc/yum.conf.tmp /etc/yum.conf
        chmod 644 /etc/yum.conf
        echo "   - /etc/yum.conf updated successfully"
    else
        echo "   - WARNING: /etc/yum.conf not found, creating new configuration..."
        cat > /etc/yum.conf << 'EOF'
[main]
cachedir=/var/cache/yum/$basearch/$releasever
keepcache=0
debuglevel=2
logfile=/var/log/yum.log
exactarch=1
obsoletes=1
gpgcheck=1
plugins=1
installonly_limit=3
clean_requirements_on_remove=True
repo_gpgcheck=1
EOF
        chmod 644 /etc/yum.conf
        echo "   - Created /etc/yum.conf with repo_gpgcheck=1"
    fi
    
    # Configure /etc/dnf/dnf.conf if DNF is available
    if command -v dnf >/dev/null 2>&1 && [ ! -f "/etc/dnf/dnf.conf" ]; then
        echo " - Creating /etc/dnf/dnf.conf..."
        mkdir -p /etc/dnf
        cat > /etc/dnf/dnf.conf << 'EOF'
[main]
gpgcheck=True
installonly_limit=3
clean_requirements_on_remove=True
best=True
skip_if_unavailable=False
repo_gpgcheck=1
EOF
        chmod 644 /etc/dnf/dnf.conf
        echo "   - Created /etc/dnf/dnf.conf with repo_gpgcheck=1"
    elif [ -f "/etc/dnf/dnf.conf" ]; then
        echo " - Configuring /etc/dnf/dnf.conf..."
        backup_file="/etc/dnf/dnf.conf.backup.$(date +%Y%m%d_%H%M%S)"
        cp /etc/dnf/dnf.conf "$backup_file"
        echo "   - Backup created: $backup_file"
        
        # Remove any existing repo_gpgcheck lines
        grep -v "^repo_gpgcheck" /etc/dnf/dnf.conf > /etc/dnf/dnf.conf.tmp
        
        # Check if [main] section exists
        if grep -q "^\[main\]" /etc/dnf/dnf.conf.tmp; then
            # Add repo_gpgcheck after [main] section
            sed -i '/^\[main\]/a repo_gpgcheck=1' /etc/dnf/dnf.conf.tmp
            echo "   - Added repo_gpgcheck=1 to [main] section"
        else
            # Create [main] section and add repo_gpgcheck
            echo -e "[main]\nrepo_gpgcheck=1" > /etc/dnf/dnf.conf.tmp
            # Append the rest of the original file
            grep -v "^repo_gpgcheck" /etc/dnf/dnf.conf | grep -v "^\[main\]" >> /etc/dnf/dnf.conf.tmp
            echo "   - Created [main] section with repo_gpgcheck=1"
        fi
        
        mv /etc/dnf/dnf.conf.tmp /etc/dnf/dnf.conf
        chmod 644 /etc/dnf/dnf.conf
        echo "   - /etc/dnf/dnf.conf updated successfully"
    fi
    
    return 0
}

# Function to configure_repository_gpgcheck
configure_repository_gpgcheck() {
    echo "Configuring repository-level repo_gpgcheck settings..."
    
    if [ ! -d "/etc/yum.repos.d" ]; then
        echo " - WARNING: /etc/yum.repos.d directory not found"
        return 1
    fi
    
    repo_files_processed=0
    repo_files_updated=0
    
    for repo_file in /etc/yum.repos.d/*.repo; do
        if [ -f "$repo_file" ]; then
            repo_files_processed=$((repo_files_processed + 1))
            echo " - Processing: $(basename "$repo_file")"
            
            # Create backup
            backup_file="${repo_file}.backup.$(date +%Y%m%d_%H%M%S)"
            cp "$repo_file" "$backup_file"
            
            # Create temporary file for processing
            temp_file="${repo_file}.tmp"
            > "$temp_file"
            
            current_section=""
            file_updated=false
            in_section=false
            
            # Read the file line by line
            while IFS= read -r line; do
                # Check for section header
                if [[ "$line" =~ ^\[.*\]$ ]]; then
                    # If we were in a previous section and repo_gpgcheck wasn't set, add it
                    if [ "$in_section" = true ] && [ "$section_has_gpgcheck" = false ]; then
                        echo "repo_gpgcheck=1" >> "$temp_file"
                        file_updated=true
                        echo "     - Added repo_gpgcheck=1 to section: $current_section"
                    fi
                    
                    # Start new section
                    current_section="$line"
                    in_section=true
                    section_has_gpgcheck=false
                    echo "$line" >> "$temp_file"
                    continue
                
                # Check for repo_gpgcheck in current section
                elif [[ "$line" =~ ^repo_gpgcheck= ]]; then
                    section_has_gpgcheck=true
                    if [[ "$line" =~ ^repo_gpgcheck=1 ]]; then
                        # Already correctly set
                        echo "$line" >> "$temp_file"
                    else
                        # Set to 1
                        echo "repo_gpgcheck=1" >> "$temp_file"
                        file_updated=true
                        echo "     - Updated repo_gpgcheck to 1 in section: $current_section"
                    fi
                    continue
                
                # Skip commented repo_gpgcheck lines (we'll add our own)
                elif [[ "$line" =~ ^#repo_gpgcheck ]]; then
                    # Don't write the commented line, we'll add the active one later
                    continue
                
                else
                    # Regular line, just copy it
                    echo "$line" >> "$temp_file"
                fi
            done < "$repo_file"
            
            # Handle the last section
            if [ "$in_section" = true ] && [ "$section_has_gpgcheck" = false ]; then
                echo "repo_gpgcheck=1" >> "$temp_file"
                file_updated=true
                echo "     - Added repo_gpgcheck=1 to final section: $current_section"
            fi
            
            # Replace original file if updates were made
            if [ "$file_updated" = true ]; then
                mv "$temp_file" "$repo_file"
                chmod 644 "$repo_file"
                repo_files_updated=$((repo_files_updated + 1))
                echo "   - SUCCESS: $(basename "$repo_file") updated"
            else
                rm -f "$temp_file"
                echo "   - SKIP: $(basename "$repo_file") already properly configured"
            fi
            
            # Clean up backup if no changes were needed
            if [ "$file_updated" = false ]; then
                rm -f "$backup_file"
            fi
        fi
    done
    
    echo ""
    echo "Repository configuration summary:"
    echo "================================="
    echo "Repository files processed: $repo_files_processed"
    echo "Repository files updated: $repo_files_updated"
    
    return 0
}

# Function to verify_gpgcheck_configuration
verify_gpgcheck_configuration() {
    echo "Verifying repo_gpgcheck configuration..."
    
    verification_passed=true
    
    # Check global configuration
    echo " - Checking global configuration..."
    if [ -f "/etc/yum.conf" ]; then
        if grep -q "^repo_gpgcheck=1" /etc/yum.conf; then
            echo "   - PASS: /etc/yum.conf has repo_gpgcheck=1"
        else
            echo "   - FAIL: /etc/yum.conf missing repo_gpgcheck=1"
            verification_passed=false
        fi
    else
        echo "   - FAIL: /etc/yum.conf not found"
        verification_passed=false
    fi
    
    if command -v dnf >/dev/null 2>&1 && [ -f "/etc/dnf/dnf.conf" ]; then
        if grep -q "^repo_gpgcheck=1" /etc/dnf/dnf.conf; then
            echo "   - PASS: /etc/dnf/dnf.conf has repo_gpgcheck=1"
        else
            echo "   - FAIL: /etc/dnf/dnf.conf missing repo_gpgcheck=1"
            verification_passed=false
        fi
    fi
    
    # Check repository configurations
    echo " - Checking repository configurations..."
    if [ -d "/etc/yum.repos.d" ]; then
        all_repos_correct=true
        repo_count=0
        incorrect_repos=0
        
        for repo_file in /etc/yum.repos.d/*.repo; do
            if [ -f "$repo_file" ]; then
                echo "   - Checking: $(basename "$repo_file")"
                
                # Check each repository section in the file
                while IFS= read -r section; do
                    repo_count=$((repo_count + 1))
                    section_name=$(echo "$section" | sed 's/\[//g' | sed 's/\]//g')
                    
                    # Extract the repo_gpgcheck value for this section
                    # This is a simplified check - in real implementation would need to parse sections properly
                    section_gpgcheck=$(awk -v section="$section" '
                        $0 == section { in_section=1; next }
                        /^\[/ { in_section=0; next }
                        in_section && /^repo_gpgcheck=/ { print $0; exit }
                    ' "$repo_file")
                    
                    if echo "$section_gpgcheck" | grep -q "repo_gpgcheck=1"; then
                        echo "     - PASS: [$section_name] has repo_gpgcheck=1"
                    else
                        echo "     - FAIL: [$section_name] missing or incorrect repo_gpgcheck"
                        all_repos_correct=false
                        incorrect_repos=$((incorrect_repos + 1))
                    fi
                done < <(grep "^\[" "$repo_file")
            fi
        done
        
        if [ "$all_repos_correct" = true ]; then
            echo "   - PASS: All $repo_count repositories have repo_gpgcheck=1"
        else
            echo "   - FAIL: $incorrect_repos out of $repo_count repositories have incorrect repo_gpgcheck settings"
            verification_passed=false
        fi
    else
        echo "   - WARNING: /etc/yum.repos.d directory not found"
    fi
    
    # Test yum/dnf behavior
    echo " - Testing package manager behavior..."
    if command -v yum >/dev/null 2>&1; then
        if yum repolist --quiet >/dev/null 2>&1; then
            echo "   - PASS: yum repolist command successful"
        else
            echo "   - WARNING: yum repolist command failed (may be due to GPG checks)"
        fi
    fi
    
    if command -v dnf >/dev/null 2>&1; then
        if dnf repolist --quiet >/dev/null 2>&1; then
            echo "   - PASS: dnf repolist command successful"
        else
            echo "   - WARNING: dnf repolist command failed (may be due to GPG checks)"
        fi
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current repo_gpgcheck configuration..."
    echo ""

    # Check current configuration
    check_yum_config
    echo ""

    # FORCE MODE: Configure repo_gpgcheck
    echo "==================================================================="
    echo "FORCE MODE: CONFIGURING REPO_GPGCHECK GLOBALLY AND PER-REPOSITORY"
    echo "==================================================================="
    echo ""

    # Configure global settings
    if configure_global_gpgcheck; then
        echo " - Global configuration completed successfully"
    else
        echo " - WARNING: Global configuration had issues"
    fi
    echo ""

    # Configure repository settings
    if configure_repository_gpgcheck; then
        echo " - Repository configuration completed successfully"
    else
        echo " - WARNING: Repository configuration had issues"
    fi
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_gpgcheck_configuration; then
        echo ""
        echo "SUCCESS: repo_gpgcheck has been successfully configured"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        echo "✓ Global yum.conf configured with repo_gpgcheck=1"
        if command -v dnf >/dev/null 2>&1; then
            echo "✓ Global dnf.conf configured with repo_gpgcheck=1"
        fi
        echo "✓ All repository files updated with repo_gpgcheck=1"
        echo "✓ Package manager repository verification enabled"
        echo "✓ Repository metadata GPG signature checking activated"
    else
        echo ""
        echo "WARNING: repo_gpgcheck configuration may not be complete"
        echo "Some repositories may still have incorrect GPG check settings."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check individual repository files in /etc/yum.repos.d/"
        echo "2. Verify each repository section has 'repo_gpgcheck=1'"
        echo "3. Test package manager operations: yum repolist or dnf repolist"
        echo "4. Ensure all repositories have valid GPG keys configured"
        echo "5. Check for any repository errors in system logs"
    fi

    # Show configuration summary
    echo ""
    echo "CONFIGURATION SUMMARY:"
    echo "======================"
    echo "Global yum.conf repo_gpgcheck: $(grep -c "^repo_gpgcheck=1" /etc/yum.conf 2>/dev/null || echo "0")"
    if [ -f "/etc/dnf/dnf.conf" ]; then
        echo "Global dnf.conf repo_gpgcheck: $(grep -c "^repo_gpgcheck=1" /etc/dnf/dnf.conf 2>/dev/null || echo "0")"
    fi
    echo "Repository files in /etc/yum.repos.d: $(ls -1 /etc/yum.repos.d/*.repo 2>/dev/null | wc -l || echo "0")"
    echo "Repository sections with repo_gpgcheck=1: $(grep -c "^repo_gpgcheck=1" /etc/yum.repos.d/*.repo 2>/dev/null || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="