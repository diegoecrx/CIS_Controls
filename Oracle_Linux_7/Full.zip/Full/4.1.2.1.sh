#!/usr/bin/env bash

# Script: 4.1.2.1.sh
# Item: 4.1.2.1 Ensure at is restricted to authorized users (Automated)

set -euo pipefail

SCRIPT_NAME="4.1.2.1.sh"
ITEM_NAME="4.1.2.1 Ensure at is restricted to authorized users (Automated)"
DESCRIPTION="This remediation ensures at access is restricted to authorized users via /etc/at.allow and /etc/at.deny."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current at access control status..."
echo ""

# Determine appropriate group
if grep -Pq -- '^daemon\b' /etc/group; then
  l_group="daemon"
  echo "Group 'daemon' exists - will use root:daemon for ownership"
else
  l_group="root"
  echo "Group 'daemon' does not exist - will use root:root for ownership"
fi
echo ""

# Display current status
echo "Current status:"
echo "- /etc/at.allow exists: $([ -e /etc/at.allow ] && echo 'YES' || echo 'NO')"
echo "- /etc/at.deny exists: $([ -e /etc/at.deny ] && echo 'YES' || echo 'NO')"
echo "- Target group: $l_group"
echo ""

if [ -e /etc/at.allow ]; then
  echo "Current /etc/at.allow permissions:"
  ls -l /etc/at.allow
  stat /etc/at.allow
fi

if [ -e /etc/at.deny ]; then
  echo ""
  echo "Current /etc/at.deny permissions:"
  ls -l /etc/at.deny
  stat /etc/at.deny
fi

echo ""
echo "Applying remediation..."
echo ""

# Create /etc/at.allow if it doesn't exist
if [ ! -e "/etc/at.allow" ]; then
  echo " - Creating /etc/at.allow"
  touch /etc/at.allow
else
  echo " - /etc/at.allow already exists"
fi

# Set ownership and permissions on /etc/at.allow
echo " - Setting ownership to root:$l_group on /etc/at.allow"
chown root:"$l_group" /etc/at.allow

echo " - Setting permissions to 640 (u-x,g-wx,o-rwx) on /etc/at.allow"
chmod u-x,g-wx,o-rwx /etc/at.allow

# Handle /etc/at.deny if it exists
if [ -e "/etc/at.deny" ]; then
  echo " - Setting ownership to root:$l_group on /etc/at.deny"
  chown root:"$l_group" /etc/at.deny
  
  echo " - Setting permissions to 640 (u-x,g-wx,o-rwx) on /etc/at.deny"
  chmod u-x,g-wx,o-rwx /etc/at.deny
else
  echo " - /etc/at.deny does not exist (no action needed)"
fi

echo ""
echo " - SUCCESS: Applied ownership and permissions"
echo ""

echo "Remediation of at access control complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

# Final verification and enforcement
final_status_pass=true

# PROOF 1: Verify /etc/at.allow exists
echo ""
echo "1. VERIFYING /etc/at.allow EXISTS:"
echo "---------------------------------"

if [ -e "/etc/at.allow" ]; then
  echo "PASS: /etc/at.allow exists"
  echo "PROOF (ls output):"
  ls -l /etc/at.allow
else
  echo "FAIL: /etc/at.allow does NOT exist - creating now"
  touch /etc/at.allow
  
  if [ -e "/etc/at.allow" ]; then
    echo "PASS: /etc/at.allow created successfully"
    echo "PROOF (ls output):"
    ls -l /etc/at.allow
  else
    echo "FAIL: Could not create /etc/at.allow"
    final_status_pass=false
  fi
fi

# PROOF 2: Verify /etc/at.allow ownership is root:$l_group
echo ""
echo "2. VERIFYING /etc/at.allow OWNERSHIP IS root:$l_group:"
echo "-----------------------------------------------------"
current_owner=$(stat -c '%U' /etc/at.allow)
current_group=$(stat -c '%G' /etc/at.allow)

if [ "$current_owner" = "root" ] && [ "$current_group" = "$l_group" ]; then
  echo "PASS: /etc/at.allow is owned by root:$l_group"
  echo "PROOF (stat output):"
  stat /etc/at.allow | grep -E '(Uid|Gid)'
else
  echo "FAIL: /etc/at.allow ownership is NOT root:$l_group - fixing now"
  chown root:"$l_group" /etc/at.allow
  
  current_owner=$(stat -c '%U' /etc/at.allow)
  current_group=$(stat -c '%G' /etc/at.allow)
  
  if [ "$current_owner" = "root" ] && [ "$current_group" = "$l_group" ]; then
    echo "PASS: /etc/at.allow ownership corrected to root:$l_group"
    echo "PROOF (stat output):"
    stat /etc/at.allow | grep -E '(Uid|Gid)'
  else
    echo "FAIL: Could not set ownership to root:$l_group"
    final_status_pass=false
  fi
fi

# PROOF 3: Verify /etc/at.allow permissions are 640 or more restrictive
echo ""
echo "3. VERIFYING /etc/at.allow PERMISSIONS ARE 640 OR MORE RESTRICTIVE:"
echo "------------------------------------------------------------------"
current_perms=$(stat -c '%a' /etc/at.allow)

if [ "$current_perms" = "640" ] || [ "$current_perms" = "600" ] || [ "$current_perms" = "400" ]; then
  echo "PASS: /etc/at.allow has permissions $current_perms (640 or more restrictive)"
  echo "PROOF (stat output):"
  stat -c 'Access: (%a/%A)' /etc/at.allow
else
  echo "FAIL: /etc/at.allow permissions are $current_perms (expected 640 or more restrictive) - fixing now"
  chmod 640 /etc/at.allow
  
  current_perms=$(stat -c '%a' /etc/at.allow)
  
  if [ "$current_perms" = "640" ]; then
    echo "PASS: /etc/at.allow permissions corrected to 640"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/at.allow
  else
    echo "FAIL: Could not set permissions to 640"
    final_status_pass=false
  fi
fi

# PROOF 4: Verify /etc/at.deny (if exists) ownership is root:$l_group
if [ -e "/etc/at.deny" ]; then
  echo ""
  echo "4. VERIFYING /etc/at.deny OWNERSHIP IS root:$l_group:"
  echo "----------------------------------------------------"
  current_owner=$(stat -c '%U' /etc/at.deny)
  current_group=$(stat -c '%G' /etc/at.deny)

  if [ "$current_owner" = "root" ] && [ "$current_group" = "$l_group" ]; then
    echo "PASS: /etc/at.deny is owned by root:$l_group"
    echo "PROOF (stat output):"
    stat /etc/at.deny | grep -E '(Uid|Gid)'
  else
    echo "FAIL: /etc/at.deny ownership is NOT root:$l_group - fixing now"
    chown root:"$l_group" /etc/at.deny
    
    current_owner=$(stat -c '%U' /etc/at.deny)
    current_group=$(stat -c '%G' /etc/at.deny)
    
    if [ "$current_owner" = "root" ] && [ "$current_group" = "$l_group" ]; then
      echo "PASS: /etc/at.deny ownership corrected to root:$l_group"
      echo "PROOF (stat output):"
      stat /etc/at.deny | grep -E '(Uid|Gid)'
    else
      echo "FAIL: Could not set ownership to root:$l_group"
      final_status_pass=false
    fi
  fi

  # PROOF 5: Verify /etc/at.deny permissions are 640 or more restrictive
  echo ""
  echo "5. VERIFYING /etc/at.deny PERMISSIONS ARE 640 OR MORE RESTRICTIVE:"
  echo "-----------------------------------------------------------------"
  current_perms=$(stat -c '%a' /etc/at.deny)

  if [ "$current_perms" = "640" ] || [ "$current_perms" = "600" ] || [ "$current_perms" = "400" ]; then
    echo "PASS: /etc/at.deny has permissions $current_perms (640 or more restrictive)"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/at.deny
  else
    echo "FAIL: /etc/at.deny permissions are $current_perms (expected 640 or more restrictive) - fixing now"
    chmod 640 /etc/at.deny
    
    current_perms=$(stat -c '%a' /etc/at.deny)
    
    if [ "$current_perms" = "640" ]; then
      echo "PASS: /etc/at.deny permissions corrected to 640"
      echo "PROOF (stat output):"
      stat -c 'Access: (%a/%A)' /etc/at.deny
    else
      echo "FAIL: Could not set permissions to 640"
      final_status_pass=false
    fi
  fi
else
  echo ""
  echo "4. /etc/at.deny does not exist - no additional verification needed"
fi

# PROOF 6: Verify complete stat output for both files
echo ""
echo "6. VERIFYING COMPLETE FILE STATUS:"
echo "---------------------------------"
echo "PROOF (full stat output for /etc/at.allow):"
stat /etc/at.allow

if [ -e "/etc/at.deny" ]; then
  echo ""
  echo "PROOF (full stat output for /etc/at.deny):"
  stat /etc/at.deny
fi

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
