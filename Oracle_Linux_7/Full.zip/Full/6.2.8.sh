#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

IFS=':' read -ra path_dirs <<< "$PATH"
issues_found=0

for dir in "${path_dirs[@]}"; do
    if [[ -z "$dir" ]]; then
        issues_found=1
    elif [[ ! -d "$dir" ]]; then
        if [[ "$dir" == "/root/bin" ]]; then
            mkdir -p "$dir"
            chown root:root "$dir"
            chmod 755 "$dir"
        else
            issues_found=1
        fi
    elif [[ "$(stat -c %U "$dir")" != "root" ]]; then
        chown root:root "$dir"
    fi
    if [[ -d "$dir" ]]; then
        perms=$(stat -c %a "$dir")
        if [[ $perms -gt 755 ]]; then
            chmod 755 "$dir"
        fi
    fi
done

if [[ "$PATH" == *: ]]; then
    issues_found=1
fi

if [[ ":$PATH:" == *"::"* ]] || [[ ":$PATH:" == *":.:"* ]]; then
    issues_found=1
fi

if [[ $issues_found -eq 0 ]]; then
    echo "pass"
else
    echo "FAIL: Root PATH integrity issues found"
    exit 1
fi