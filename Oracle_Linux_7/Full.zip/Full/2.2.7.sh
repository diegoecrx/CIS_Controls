#!/usr/bin/env bash

# Script: 2.2.7.sh
# Item: 2.2.7 Ensure ftp server services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.7.sh"
ITEM_NAME="2.2.7 Ensure ftp server services are not in use (Automated)"
DESCRIPTION="This remediation ensures FTP server services are not in use by removing or masking all FTP server services. FORCE VERSION - Comprehensive FTP server removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_ftp_status
check_ftp_status() {
    echo "Checking FTP server status..."
    
    ftp_installed=false
    ftp_running=false
    ftp_enabled=false
    ftp_masked=false
    
    # Check for common FTP server packages
    ftp_packages=("vsftpd" "proftpd" "pure-ftpd" "ftpd" "wu-ftpd" "gssftpd" "oftpd"
                  "ftp" "ftpd-base" "pure-ftpd-common" "proftpd-basic" "proftpd-mod")
    
    for pkg in "${ftp_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                ftp_installed=true
                echo " - $pkg package is installed"
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                ftp_installed=true
                echo " - $pkg package is installed"
            fi
        fi
    done
    
    # Check for FTP server processes
    if pgrep vsftpd >/dev/null 2>&1 || pgrep proftpd >/dev/null 2>&1 || \
       pgrep pure-ftpd >/dev/null 2>&1 || pgrep ftpd >/dev/null 2>&1 || \
       pgrep in.ftpd >/dev/null 2>&1; then
        ftp_running=true
        echo " - FTP server processes running:"
        pgrep vsftpd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep proftpd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep pure-ftpd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep ftpd 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
    fi
    
    # Check for FTP server services
    ftp_services=("vsftpd" "proftpd" "pure-ftpd" "ftpd" "wu-ftpd" "gssftpd" "oftpd")
    
    for service in "${ftp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            # Check if service is running
            if systemctl is-active "$service" >/dev/null 2>&1; then
                ftp_running=true
                echo " - $service.service is running"
            fi
            
            # Check if service is enabled
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                ftp_enabled=true
                echo " - $service.service is enabled"
            fi
            
            # Check if service is masked
            if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                ftp_masked=true
                echo " - $service.service is masked"
            fi
        fi
    done
    
    # Check for FTP network services
    if netstat -tulpn 2>/dev/null | grep -E ':21 |:20 ' | grep -v grep; then
        echo " - WARNING: FTP server ports detected:"
        netstat -tulpn 2>/dev/null | grep -E ':21 |:20 '
    fi
    
    # Check for FTP configuration files
    ftp_configs=("/etc/vsftpd" "/etc/proftpd" "/etc/pure-ftpd" "/etc/ftpd" 
                 "/etc/wu-ftpd" "/etc/ftpusers" "/etc/vsftpd.conf" 
                 "/etc/proftpd/proftpd.conf" "/etc/pure-ftpd/pure-ftpd.conf")
    for config in "${ftp_configs[@]}"; do
        if [ -e "$config" ]; then
            echo " - FTP configuration found: $config"
        fi
    done
    
    # Check for FTP in inetd/xinetd
    if [ -f "/etc/inetd.conf" ] && grep -q "ftp" /etc/inetd.conf 2>/dev/null; then
        echo " - WARNING: FTP service configured in /etc/inetd.conf"
    fi
    
    if [ -d "/etc/xinetd.d" ]; then
        for xinetd_file in /etc/xinetd.d/*; do
            if [ -f "$xinetd_file" ] && grep -q "ftp" "$xinetd_file" 2>/dev/null; then
                echo " - WARNING: FTP service configured in $xinetd_file"
            fi
        done
    fi
    
    # Check for FTP in super server configurations
    if command -v ss >/dev/null 2>&1; then
        if ss -tulpn 2>/dev/null | grep -q ':21'; then
            echo " - FTP port 21 is listening"
        fi
    fi
    
    return 0
}

# Function to stop_ftp_services
stop_ftp_services() {
    echo "Stopping FTP server services..."
    
    # Stop FTP processes first
    for process in vsftpd proftpd pure-ftpd ftpd in.ftpd wu-ftpd; do
        if pgrep "$process" >/dev/null 2>&1; then
            echo " - Stopping $process processes..."
            pkill -TERM "$process" 2>/dev/null || true
            sleep 2
            
            # Force kill if still running
            if pgrep "$process" >/dev/null 2>&1; then
                echo " - Force stopping $process processes..."
                pkill -KILL "$process" 2>/dev/null || true
                sleep 1
            fi
        fi
    done
    
    # Stop services using systemctl
    ftp_services=("vsftpd" "proftpd" "pure-ftpd" "ftpd" "wu-ftpd" "gssftpd" "oftpd")
    
    for service in "${ftp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service.service..."
            if systemctl stop "$service" 2>&1; then
                echo "   - $service.service stopped"
            else
                echo "   - WARNING: Could not stop $service.service via systemctl"
            fi
        fi
    done
    
    # Additional stop for any FTP related services
    systemctl list-unit-files | grep -E "(ftp|vsftpd|proftpd)" | awk '{print $1}' | while read -r service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Stop inetd/xinetd if running and configured for FTP
    if pgrep inetd >/dev/null 2>&1 && [ -f "/etc/inetd.conf" ] && grep -q "ftp" /etc/inetd.conf 2>/dev/null; then
        echo " - Restarting inetd to disable FTP..."
        pkill -HUP inetd 2>/dev/null || true
    fi
    
    if pgrep xinetd >/dev/null 2>&1 && [ -d "/etc/xinetd.d" ]; then
        for xinetd_file in /etc/xinetd.d/*; do
            if [ -f "$xinetd_file" ] && grep -q "ftp" "$xinetd_file" 2>/dev/null; then
                echo " - Restarting xinetd to disable FTP..."
                pkill -HUP xinetd 2>/dev/null || true
                break
            fi
        done
    fi
    
    # Verify no FTP server processes are running
    running_processes=0
    for process in vsftpd proftpd pure-ftpd ftpd in.ftpd wu-ftpd; do
        if pgrep "$process" >/dev/null 2>&1; then
            running_processes=$((running_processes + 1))
        fi
    done
    
    if [ "$running_processes" -gt 0 ]; then
        echo " - CRITICAL: FTP server processes still running after stop attempts"
        return 1
    else
        echo " - No FTP server processes running"
    fi
    
    # Kill any remaining FTP processes
    for process in vsftpd proftpd pure-ftpd ftpd in.ftpd wu-ftpd; do
        pkill -9 "$process" 2>/dev/null || true
    done
    
    return 0
}

# Function to remove_ftp_packages
remove_ftp_packages() {
    local pkg_mgr="$1"
    
    echo "Removing FTP server packages..."
    
    # List of FTP-related packages
    ftp_packages=("vsftpd" "proftpd" "proftpd-basic" "proftpd-mod" 
                  "pure-ftpd" "pure-ftpd-common" "ftpd" "wu-ftpd" 
                  "gssftpd" "oftpd" "ftp" "ftpd-base")
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove FTP packages..."
            for pkg in "${ftp_packages[@]}"; do
                if $pkg_mgr list installed "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if $pkg_mgr remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        apt)
            echo " - Using apt to remove FTP packages..."
            export DEBIAN_FRONTEND=noninteractive
            for pkg in "${ftp_packages[@]}"; do
                if dpkg -l "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if apt-get remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        zypper)
            echo " - Using zypper to remove FTP packages..."
            for pkg in "${ftp_packages[@]}"; do
                if zypper search --installed-only "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if zypper --non-interactive remove "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove FTP packages"
            return 1
            ;;
    esac
    
    # Clean up package cache and dependencies
    case "$pkg_mgr" in
        yum|dnf)
            $pkg_mgr autoremove -y 2>/dev/null || true
            ;;
        apt)
            apt-get autoremove -y 2>/dev/null || true
            ;;
    esac
    
    echo " - Package removal completed"
    return 0
}

# Function to mask_ftp_services
mask_ftp_services() {
    echo "Masking FTP server services..."
    
    # List of FTP services to mask
    ftp_services=("vsftpd" "proftpd" "pure-ftpd" "ftpd" "wu-ftpd" "gssftpd" "oftpd")
    
    for service in "${ftp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                if systemctl mask "$service" 2>&1; then
                    echo " - $service.service masked"
                else
                    echo " - WARNING: Could not mask $service.service"
                fi
            else
                echo " - $service.service already masked"
            fi
        fi
    done
    
    # Mask any other FTP related services
    systemctl list-unit-files | grep -E "(ftp|vsftpd|proftpd)" | awk '{print $1}' | while read -r service; do
        if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
            systemctl mask "$service" 2>/dev/null && echo " - $service masked" || true
        fi
    done
    
    return 0
}

# Function to disable_ftp_services
disable_ftp_services() {
    echo "Disabling FTP server services..."
    
    # List of FTP services to disable
    ftp_services=("vsftpd" "proftpd" "pure-ftpd" "ftpd" "wu-ftpd" "gssftpd" "oftpd")
    
    for service in "${ftp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl disable "$service" 2>&1; then
                    echo " - $service.service disabled"
                else
                    echo " - WARNING: Could not disable $service.service"
                fi
            else
                echo " - $service.service already disabled"
            fi
        fi
    done
    
    # Disable any other FTP related services
    systemctl list-unit-files | grep -E "(ftp|vsftpd|proftpd)" | awk '{print $1}' | while read -r service; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            systemctl disable "$service" 2>/dev/null && echo " - $service disabled" || true
        fi
    done
    
    return 0
}

# Function to cleanup_ftp_configs
cleanup_ftp_configs() {
    echo "Cleaning up FTP server configuration files..."
    
    # List of FTP configuration files to remove or disable
    config_files=(
        "/etc/vsftpd"
        "/etc/vsftpd.conf"
        "/etc/proftpd"
        "/etc/proftpd/proftpd.conf"
        "/etc/pure-ftpd"
        "/etc/pure-ftpd/pure-ftpd.conf"
        "/etc/ftpd"
        "/etc/wu-ftpd"
        "/etc/ftpusers"
        "/etc/vsftpd.user_list"
        "/etc/vsftpd.chroot_list"
        "/var/ftp"
        "/var/lib/ftp"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -e "$config_file" ]; then
            if [ -f "$config_file" ]; then
                # Create backup and disable
                backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp "$config_file" "$backup_file"
                echo " - Backed up $config_file to $backup_file"
                
                # Comment out all active configurations
                sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$config_file" 2>/dev/null || true
                echo " - Disabled configurations in $config_file"
            elif [ -d "$config_file" ]; then
                # For directories, backup and disable contents
                backup_dir="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp -r "$config_file" "$backup_dir" 2>/dev/null || true
                echo " - Backed up $config_file to $backup_dir"
                
                # Disable all configuration files in directory
                find "$config_file" -type f -name "*.conf" -exec sh -c 'echo "# REMEDIATED: $(cat {})" > {}' \; 2>/dev/null || true
                echo " - Disabled configuration files in $config_file"
            fi
        fi
    done
    
    # Disable FTP in inetd/xinetd configurations
    if [ -f "/etc/inetd.conf" ]; then
        if grep -q "ftp" /etc/inetd.conf 2>/dev/null; then
            cp /etc/inetd.conf "/etc/inetd.conf.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i '/ftp/d' /etc/inetd.conf 2>/dev/null || true
            echo " - Removed FTP from /etc/inetd.conf"
        fi
    fi
    
    if [ -d "/etc/xinetd.d" ]; then
        for xinetd_file in /etc/xinetd.d/*; do
            if [ -f "$xinetd_file" ] && grep -q "ftp" "$xinetd_file" 2>/dev/null; then
                cp "$xinetd_file" "${xinetd_file}.backup.$(date +%Y%m%d_%H%M%S)"
                sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$xinetd_file" 2>/dev/null || true
                echo " - Disabled FTP in $xinetd_file"
            fi
        done
    fi
    
    # Remove FTP from PAM configurations if present
    if [ -d "/etc/pam.d" ]; then
        for pam_file in /etc/pam.d/vsftpd /etc/pam.d/ftp /etc/pam.d/proftpd; do
            if [ -f "$pam_file" ]; then
                cp "$pam_file" "${pam_file}.backup.$(date +%Y%m%d_%H%M%S)"
                echo " - Backed up PAM configuration: $pam_file"
            fi
        done
    fi
    
    # Clean up FTP runtime files
    if [ -d "/var/run/vsftpd" ]; then
        rm -rf /var/run/vsftpd/* 2>/dev/null || true
        echo " - Cleaned up vsftpd runtime files"
    fi
    
    if [ -d "/var/run/proftpd" ]; then
        rm -rf /var/run/proftpd/* 2>/dev/null || true
        echo " - Cleaned up proftpd runtime files"
    fi
    
    # Remove any FTP related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -E "(ftp|vsftpd|proftpd)" "$cron_file" 2>/dev/null; then
                sed -i '/ftp\|vsftpd\|proftpd/d' "$cron_file" 2>/dev/null || true
                echo " - Removed FTP references from $cron_file"
            fi
        done
    fi
    
    return 0
}

# Function to block_ftp_ports
block_ftp_ports() {
    echo "Blocking FTP server network ports..."
    
    # FTP uses ports 21 (control) and 20 (data)
    if command -v firewall-cmd >/dev/null 2>&1; then
        # firewalld
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld to block FTP ports..."
            firewall-cmd --permanent --remove-service=ftp 2>/dev/null || true
            firewall-cmd --permanent --remove-service=ftps 2>/dev/null || true
            firewall-cmd --permanent --remove-port=21/tcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=20/tcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=989/tcp 2>/dev/null || true  # FTPS
            firewall-cmd --permanent --remove-port=990/tcp 2>/dev/null || true  # FTPS
            firewall-cmd --reload 2>/dev/null || true
            echo " - firewalld configured to block FTP ports"
        fi
    fi
    
    # Additional iptables rules for non-firewalld systems
    if command -v iptables >/dev/null 2>&1; then
        echo " - Adding iptables rules to block FTP..."
        # Block FTP control port
        iptables -I INPUT -p tcp --dport 21 -j DROP 2>/dev/null || true
        # Block FTP data port
        iptables -I INPUT -p tcp --dport 20 -j DROP 2>/dev/null || true
        # Block FTPS ports
        iptables -I INPUT -p tcp --dport 989 -j DROP 2>/dev/null || true
        iptables -I INPUT -p tcp --dport 990 -j DROP 2>/dev/null || true
        echo " - iptables rules added (if supported)"
    fi
    
    return 0
}

# Function to verify_ftp_removal
verify_ftp_removal() {
    echo "Verifying FTP server remediation..."
    
    verification_passed=true
    
    # Check if FTP packages are installed
    ftp_packages=("vsftpd" "proftpd" "pure-ftpd")
    for pkg in "${ftp_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        fi
    done
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: FTP server packages are not installed"
    fi
    
    # Check if FTP services are running
    ftp_services=("vsftpd" "proftpd" "pure-ftpd")
    for service in "${ftp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo "FAIL: $service.service is running"
            verification_passed=false
        else
            echo "PASS: $service.service is not running"
        fi
    done
    
    # Check if FTP services are enabled or masked
    for service in "${ftp_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                    echo "PASS: $service.service is masked"
                else
                    echo "FAIL: $service.service is enabled"
                    verification_passed=false
                fi
            else
                echo "PASS: $service.service is not enabled"
            fi
        fi
    done
    
    # Check for FTP processes
    running_processes=0
    for process in vsftpd proftpd pure-ftpd ftpd in.ftpd; do
        if pgrep "$process" >/dev/null 2>&1; then
            running_processes=$((running_processes + 1))
            echo "FAIL: $process process is running"
            verification_passed=false
        fi
    done
    
    if [ "$running_processes" -eq 0 ]; then
        echo "PASS: No FTP server processes running"
    fi
    
    # Check for FTP network services
    if ss -tulpn 2>/dev/null | grep -E ':21 |:20 ' | grep -E '(vsftpd|proftpd|pure-ftpd|ftpd)'; then
        echo "FAIL: FTP server network services detected"
        verification_passed=false
    else
        echo "PASS: No FTP server network services detected"
    fi
    
    # Check for FTP in super servers
    if [ -f "/etc/inetd.conf" ] && grep -q "ftp" /etc/inetd.conf 2>/dev/null; then
        echo "WARNING: FTP still configured in /etc/inetd.conf"
        # Not necessarily a failure if service is disabled
    fi
    
    if [ -d "/etc/xinetd.d" ]; then
        for xinetd_file in /etc/xinetd.d/*; do
            if [ -f "$xinetd_file" ] && grep -q "ftp" "$xinetd_file" 2>/dev/null && \
               ! grep -q "disable.*yes" "$xinetd_file" 2>/dev/null; then
                echo "WARNING: FTP service enabled in $xinetd_file"
                verification_passed=false
            fi
        done
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current FTP server status..."
    echo ""

    # Check current FTP server status
    check_ftp_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable FTP servers
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING FTP SERVER SERVICES"
    echo "==================================================================="
    echo ""

    # Stop FTP services first
    if ! stop_ftp_services; then
        echo " - WARNING: Some issues stopping FTP server services"
    fi
    echo ""

    # Try to remove FTP packages
    if remove_ftp_packages "$pkg_mgr"; then
        echo " - Package removal attempted"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking services instead"
        removal_method="masked"
    fi
    echo ""

    # Mask and disable services (especially if package removal failed)
    if [ "$removal_method" = "masked" ]; then
        if mask_ftp_services; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        if disable_ftp_services; then
            echo " - Service disabling successful"
        fi
    fi
    echo ""

    # Cleanup configuration files
    cleanup_ftp_configs
    echo ""

    # Block network ports
    block_ftp_ports
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_ftp_removal; then
        echo ""
        echo "SUCCESS: FTP server services have been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ FTP server packages removed"
        else
            echo "✓ FTP server services masked and disabled"
        fi
        echo "✓ FTP server services stopped"
        echo "✓ FTP server processes terminated"
        echo "✓ Configuration files disabled"
        echo "✓ Super server configurations cleaned"
        echo "✓ Network ports blocked"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: FTP server remediation may not be complete"
        echo "Some FTP server components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining FTP processes: ps aux | grep -E '(vsftpd|proftpd|pure-ftpd|ftpd)'"
        echo "2. Verify FTP services are masked: systemctl list-unit-files | grep -E '(vsftpd|proftpd|pure-ftpd)'"
        echo "3. Manually remove FTP packages if needed"
        echo "4. Check network ports: ss -tulpn | grep -E ':21|:20'"
        echo "5. Verify no FTP configuration files remain"
        echo "6. Check /etc/inetd.conf and /etc/xinetd.d/ for FTP configurations"
        echo "7. Ensure FTP ports are blocked in firewall"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Packages installed: $(if command -v rpm >/dev/null && rpm -q vsftpd >/dev/null 2>&1; then echo "YES"; elif command -v dpkg >/dev/null && dpkg -l vsftpd >/dev/null 2>&1; then echo "YES"; else echo "NO"; fi)"
    echo "Services running: $(systemctl is-active vsftpd 2>/dev/null || systemctl is-active proftpd 2>/dev/null || echo "NO")"
    echo "Services enabled: $(systemctl is-enabled vsftpd 2>/dev/null || systemctl is-enabled proftpd 2>/dev/null || echo "NO")"
    echo "Processes running: $( (pgrep vsftpd 2>/dev/null | wc -l; pgrep proftpd 2>/dev/null | wc -l; pgrep pure-ftpd 2>/dev/null | wc -l) | awk '{sum+=$1} END {print sum}')"
    echo "Network port 21: $(ss -tulpn 2>/dev/null | grep -c ':21 ' || echo "0")"
    echo "Network port 20: $(ss -tulpn 2>/dev/null | grep -c ':20 ' || echo "0")"
    echo "inetd FTP: $(grep -c ftp /etc/inetd.conf 2>/dev/null || echo "0")"
    echo "xinetd FTP: $(find /etc/xinetd.d -name '*' -exec grep -l ftp {} \; 2>/dev/null | wc -l || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="