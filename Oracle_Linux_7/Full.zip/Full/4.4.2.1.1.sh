#!/bin/bash

# Enforce CIS 4.4.2.1.1 - Ensure pam_faillock module is enabled
echo "Enforcing CIS 4.4.2.1.1 - pam_faillock module configuration..."

# Backup original files
for file in system-auth password-auth; do
    if [ ! -f "/etc/pam.d/${file}.bak" ]; then
        cp "/etc/pam.d/${file}" "/etc/pam.d/${file}.bak"
        echo "Backed up /etc/pam.d/${file} to /etc/pam.d/${file}.bak"
    fi
done

# Configure pam_faillock for both system-auth and password-auth
for file in system-auth password-auth; do
    echo "Configuring /etc/pam.d/${file}..."
    
    # Remove existing pam_faillock entries to avoid duplicates
    sed -i '/pam_faillock\.so/d' "/etc/pam.d/${file}"
    
    # Add preauth line after pam_env.so in auth section
    if grep -q "auth.*required.*pam_env\.so" "/etc/pam.d/${file}"; then
        sed -i '/auth.*required.*pam_env\.so/a auth        required      pam_faillock.so preauth silent audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
    else
        # If pam_env.so not found, add at beginning of auth section
        sed -i '/^auth/iauth        required      pam_faillock.so preauth silent audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
    fi
    
    # Add authfail line as the last auth entry before pam_succeed_if.so
    if grep -q "auth.*requisite.*pam_succeed_if\.so" "/etc/pam.d/${file}"; then
        sed -i '/auth.*requisite.*pam_succeed_if\.so/iauth        [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
    else
        # If pam_succeed_if.so not found, add before pam_deny.so
        if grep -q "auth.*required.*pam_deny\.so" "/etc/pam.d/${file}"; then
            sed -i '/auth.*required.*pam_deny\.so/iauth        [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
        else
            # Add at the end of auth section as fallback
            sed -i '/^auth.*/aauth        [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' "/etc/pam.d/${file}"
        fi
    fi
    
    # Add account required pam_faillock.so at the beginning of account section
    if grep -q "^account" "/etc/pam.d/${file}"; then
        sed -i '/^account/iaccount     required      pam_faillock.so' "/etc/pam.d/${file}"
    else
        # Add after last auth section if no account section exists
        sed -i '/^auth.*/aaccount     required      pam_faillock.so' "/etc/pam.d/${file}"
    fi
done

# Verify configuration
echo "Verifying pam_faillock configuration..."

# Check for required lines in both files
for file in system-auth password-auth; do
    echo "Checking /etc/pam.d/${file}:"
    
    # Check preauth line
    if grep -q "auth.*required.*pam_faillock\.so.*preauth" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_faillock preauth configured in ${file}"
    else
        echo "ERROR: pam_faillock preauth missing in ${file}"
        exit 1
    fi
    
    # Check authfail line
    if grep -q "auth.*\[default=die\].*pam_faillock\.so.*authfail" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_faillock authfail configured in ${file}"
    else
        echo "ERROR: pam_faillock authfail missing in ${file}"
        exit 1
    fi
    
    # Check account line
    if grep -q "account.*required.*pam_faillock\.so" "/etc/pam.d/${file}"; then
        echo "SUCCESS: pam_faillock account configured in ${file}"
    else
        echo "ERROR: pam_faillock account missing in ${file}"
        exit 1
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config, checking manually..."
    # Basic syntax check - look for obvious errors
    if grep -q "pam_faillock" /etc/pam.d/system-auth && grep -q "pam_faillock" /etc/pam.d/password-auth; then
        echo "SUCCESS: pam_faillock entries found in both files"
    else
        echo "ERROR: pam_faillock configuration incomplete"
        exit 1
    fi
fi

echo "CIS 4.4.2.1.1 remediation completed successfully"
echo "WARNING: Test authentication carefully to ensure you are not locked out of the system"