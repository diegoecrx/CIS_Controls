#!/usr/bin/env bash
# Script: 4.2.12.sh
# Item: 4.2.12 Ensure sshd KexAlgorithms is configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.12.sh"
ITEM_NAME="4.2.12 Ensure sshd KexAlgorithms is configured (Automated)"
DESCRIPTION="This remediation ensures sshd KexAlgorithms is configured properly in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    desired="curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256"
    conf_line=$(grep -i '^KexAlgorithms' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -q "$desired"; then
        echo "PASS: Correct KexAlgorithms set"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: Incorrect or missing KexAlgorithms"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_kexalgorithms() {
    echo "Applying fix..."
    sed -i '/^KexAlgorithms/d' /etc/ssh/sshd_config
    echo "KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256" >> /etc/ssh/sshd_config
    echo " - Set KexAlgorithms"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_kexalgorithms
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: KexAlgorithms configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="