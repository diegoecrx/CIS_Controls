#!/usr/bin/env bash
# Script: 3.1.2.sh
# Item: 3.1.2 Ensure wireless interfaces are disabled (Automated)
set -euo pipefail
SCRIPT_NAME="3.1.2.sh"
ITEM_NAME="3.1.2 Ensure wireless interfaces are disabled (Automated)"
DESCRIPTION="This remediation ensures wireless interfaces are disabled by blacklisting and unloading wireless modules."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking wireless interfaces..."
    
    # Check if any wireless interfaces exist
    if [ -z "$(find /sys/class/net/*/ -type d -name wireless 2>/dev/null)" ]; then
        echo "PASS: No wireless interfaces found"
        echo "PROOF: No wireless directories in /sys/class/net/"
        return 0
    fi
    
    # Get wireless driver modules
    l_dname=$(for driverdir in $(find /sys/class/net/*/ -type d -name wireless 2>/dev/null | xargs dirname); do basename "$(readlink -f "$driverdir"/device/driver/module 2>/dev/null)"; done 2>/dev/null | sort -u)
    
    if [ -z "$l_dname" ]; then
        echo "PASS: No wireless driver modules loaded"
        echo "PROOF: No wireless driver modules found"
        return 0
    fi
    
    # Check each wireless module
    for l_mname in $l_dname; do
        if [ -n "$l_mname" ]; then
            # Check if module is blacklisted
            if ! grep -Pq -- "^\h*blacklist\h+$l_mname\b" /etc/modprobe.d/* 2>/dev/null; then
                echo "FAIL: Wireless module $l_mname is not blacklisted"
                echo "PROOF: blacklist entry not found for $l_mname"
                return 1
            fi
            
            # Check if module is set to be un-loadable
            if ! modprobe -n -v "$l_mname" 2>/dev/null | grep -P -- '^\h*install\h+/bin/(true|false)'; then
                echo "FAIL: Wireless module $l_mname is not set to be un-loadable"
                echo "PROOF: install /bin/false not set for $l_mname"
                return 1
            fi
            
            # Check if module is currently loaded
            if lsmod | grep -q "^$l_mname\b" 2>/dev/null; then
                echo "FAIL: Wireless module $l_mname is currently loaded"
                echo "PROOF: $l_mname found in lsmod output"
                return 1
            fi
        fi
    done
    
    echo "PASS: All wireless interfaces properly disabled"
    echo "PROOF: All wireless modules blacklisted and unloaded"
    return 0
}
# Function to fix wireless modules
module_fix() {
    local l_mname="$1"
    
    # Set module to be un-loadable
    if ! modprobe -n -v "$l_mname" 2>/dev/null | grep -P -- '^\h*install\h+/bin/(true|false)'; then
        echo " - Setting module: $l_mname to be un-loadable"
        echo "install $l_mname /bin/false" >> /etc/modprobe.d/"$l_mname".conf
    fi
    
    # Unload module if currently loaded
    if lsmod | grep -q "^$l_mname\b" 2>/dev/null; then
        echo " - Unloading module $l_mname"
        modprobe -r "$l_mname" 2>/dev/null || true
    fi
    
    # Blacklist module
    if ! grep -Pq -- "^\h*blacklist\h+$l_mname\b" /etc/modprobe.d/* 2>/dev/null; then
        echo " - Blacklisting $l_mname"
        echo "blacklist $l_mname" >> /etc/modprobe.d/"$l_mname".conf
    fi
}
# Function to fix
fix_wireless_interfaces() {
    echo "Applying fix..."
    
    # Check if any wireless interfaces exist
    if [ -z "$(find /sys/class/net/*/ -type d -name wireless 2>/dev/null)" ]; then
        echo " - No wireless interfaces found, no action needed"
        return
    fi
    
    # Get wireless driver modules
    l_dname=$(for driverdir in $(find /sys/class/net/*/ -type d -name wireless 2>/dev/null | xargs dirname); do basename "$(readlink -f "$driverdir"/device/driver/module 2>/dev/null)"; done 2>/dev/null | sort -u)
    
    if [ -z "$l_dname" ]; then
        echo " - No wireless driver modules found"
        return
    fi
    
    # Fix each wireless module
    for l_mname in $l_dname; do
        if [ -n "$l_mname" ]; then
            echo " - Processing wireless module: $l_mname"
            module_fix "$l_mname"
        fi
    done
    
    echo " - Wireless interface disabling completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_wireless_interfaces
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Wireless interfaces properly disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="