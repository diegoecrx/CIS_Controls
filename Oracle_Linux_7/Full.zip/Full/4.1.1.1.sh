#!/usr/bin/env bash
# Script: 4.1.1.1.sh
# Item: 4.1.1.1 Ensure cron daemon is enabled and active (Automated)
set -euo pipefail
SCRIPT_NAME="4.1.1.1.sh"
ITEM_NAME="4.1.1.1 Ensure cron daemon is enabled and active (Automated)"
DESCRIPTION="This remediation ensures the cron daemon is unmasked, enabled, and active."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking cron daemon configuration..."
    
    # Check if crond service exists
    if ! systemctl list-unit-files | grep -q crond.service; then
        echo "FAIL: crond service is not available on the system"
        echo "PROOF: systemctl list-unit-files shows no crond.service"
        return 1
    fi
    
    # Check if crond is masked
    if systemctl is-enabled crond 2>/dev/null | grep -q masked; then
        echo "FAIL: crond service is masked"
        echo "PROOF: systemctl is-enabled crond shows masked"
        return 1
    fi
    
    # Check if crond is enabled
    if ! systemctl is-enabled crond >/dev/null 2>&1; then
        echo "FAIL: crond service is not enabled"
        echo "PROOF: systemctl is-enabled crond shows disabled"
        return 1
    fi
    
    # Check if crond is active
    if ! systemctl is-active crond >/dev/null 2>&1; then
        echo "FAIL: crond service is not active"
        echo "PROOF: systemctl is-active crond shows inactive"
        return 1
    fi
    
    echo "PASS: cron daemon properly configured"
    echo "PROOF: crond service is unmasked, enabled, and active"
    return 0
}
# Function to fix
fix_cron_daemon() {
    echo "Applying fix..."
    
    # Force remediation - always apply the required steps
    
    # Unmask crond service if it's masked
    if systemctl is-enabled crond 2>/dev/null | grep -q masked; then
        echo " - Unmasking crond service"
        systemctl unmask crond
    fi
    
    # Enable crond service
    if ! systemctl is-enabled crond >/dev/null 2>&1; then
        echo " - Enabling crond service"
        systemctl enable crond
    else
        echo " - crond service already enabled"
    fi
    
    # Start crond service
    if ! systemctl is-active crond >/dev/null 2>&1; then
        echo " - Starting crond service"
        systemctl start crond
    else
        echo " - crond service already active"
    fi
    
    # Verify the service is properly configured
    echo " - Verifying cron daemon configuration"
    
    # Additional verification - check if cron packages are installed
    if ! rpm -q cronie >/dev/null 2>&1 && ! rpm -q vixie-cron >/dev/null 2>&1; then
        echo " - Installing cron package (cronie)"
        yum install -y cronie
    fi
    
    echo " - cron daemon configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_cron_daemon
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: cron daemon properly configured"
        echo ""
        echo "Service status:"
        echo "---------------"
        systemctl status crond --no-pager -l | head -5
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Manual configuration required. Run these commands:"
        echo "systemctl unmask crond"
        echo "systemctl --now enable crond"
        echo ""
        echo "Current service status:"
        echo "----------------------"
        systemctl status crond --no-pager -l | head -10 || true
        echo ""
        echo "Service enabled status:"
        echo "----------------------"
        systemctl is-enabled crond || true
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="