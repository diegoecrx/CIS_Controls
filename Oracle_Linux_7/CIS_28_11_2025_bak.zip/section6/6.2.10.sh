#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

l_valid_shells="^($(awk -F/ '$NF != "nologin" {print}' /etc/shells | sed -rn '/^\//{s,/,\\/,g;p}' | paste -s -d '|' - ))$"
while read -r l_user l_home; do
    if [ ! -d "$l_home" ]; then
        mkdir -p "$l_home"
        chown "$l_user" "$l_home"
        chmod 750 "$l_home"
    fi
    chown "$l_user" "$l_home"
    chmod g-w,o-rwx "$l_home"
done <<< "$(awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " " $(NF-1) }' /etc/passwd)"

if awk -v pat="$l_valid_shells" -F: '$(NF) ~ pat { print $1 " " $(NF-1) }' /etc/passwd | while read -r l_user l_home; do
    if [ ! -d "$l_home" ]; then
        echo "FAIL: Home directory for $l_user doesn't exist"
        exit 1
    fi
    l_owner=$(stat -c '%U' "$l_home")
    l_mode=$(stat -c '%a' "$l_home")
    if [ "$l_owner" != "$l_user" ] || [ "$l_mode" -gt 750 ]; then
        echo "FAIL: Home directory for $l_user has incorrect permissions/ownership"
        exit 1
    fi
done; then
    echo "pass"
else
    echo "FAIL: Home directory configuration failed"
    exit 1
fi