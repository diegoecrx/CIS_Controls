#!/usr/bin/env bash

# Script: 6.1.13.sh
# Item: 6.1.13 Ensure SUID and SGID files are reviewed (Manual)
# Description: "Ensure that no rogue SUID or SGID programs have been introduced into the system.
# Review the files returned by the action in the Audit section and confirm the integrity of
# these binaries."
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="6.1.13.sh"
ITEM_NAME="6.1.13 Ensure SUID and SGID files are reviewed (Manual)"
DESCRIPTION="Ensure no rogue SUID or SGID programs have been introduced into the system"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current SUID and SGID files on the system..."
    echo ""

    # Display current SUID/SGID file status
    echo "Current SUID and SGID file analysis:"
    echo "===================================="
    
    # Find all SUID files
    echo "SUID (Set User ID) files:"
    echo "-------------------------"
    suid_files=$(find / -type f -perm -4000 2>/dev/null | sort || echo "")
    suid_count=$(echo "$suid_files" | grep -c '^/' || echo "0")
    echo "Total SUID files found: $suid_count"
    
    if [ "$suid_count" -gt 0 ]; then
        echo ""
        echo "Sample SUID files (first 10):"
        echo "$suid_files" | head -10
    fi
    
    echo ""
    
    # Find all SGID files
    echo "SGID (Set Group ID) files:"
    echo "-------------------------"
    sgid_files=$(find / -type f -perm -2000 2>/dev/null | sort || echo "")
    sgid_count=$(echo "$sgid_files" | grep -c '^/' || echo "0")
    echo "Total SGID files found: $sgid_count"
    
    if [ "$sgid_count" -gt 0 ]; then
        echo ""
        echo "Sample SGID files (first 10):"
        echo "$sgid_files" | head -10
    fi
    
    echo ""
    
    # Find files with both SUID and SGID
    echo "Files with both SUID and SGID:"
    echo "------------------------------"
    both_files=$(find / -type f -perm -6000 2>/dev/null | sort || echo "")
    both_count=$(echo "$both_files" | grep -c '^/' || echo "0")
    echo "Total files with both SUID and SGID: $both_count"
    
    if [ "$both_count" -gt 0 ]; then
        echo ""
        echo "Sample files with both SUID and SGID (first 5):"
        echo "$both_files" | head -5
    fi
    
    echo ""
    
    # Check for unusual directories
    echo "SUID/SGID files in unusual directories:"
    echo "---------------------------------------"
    unusual_dirs=("/tmp" "/var/tmp" "/dev" "/home" "/opt")
    unusual_found=false
    
    for dir in "${unusual_dirs[@]}"; do
        if [ -d "$dir" ]; then
            dir_suid=$(find "$dir" -type f -perm -4000 2>/dev/null | wc -l || echo "0")
            dir_sgid=$(find "$dir" -type f -perm -2000 2>/dev/null | wc -l || echo "0")
            if [ "$dir_suid" -gt 0 ] || [ "$dir_sgid" -gt 0 ]; then
                echo "WARNING: $dir contains $dir_suid SUID and $dir_sgid SGID files"
                unusual_found=true
                find "$dir" -type f -perm -4000 -o -perm -2000 2>/dev/null | head -3
            fi
        fi
    done
    
    if [ "$unusual_found" = false ]; then
        echo "No SUID/SGID files found in unusual directories"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_common_suid_binaries()
    {
        echo " - Checking common SUID binaries..."
        
        common_suid_binaries=(
            "/bin/su" "/bin/mount" "/bin/umount" "/bin/ping" "/bin/ping6"
            "/usr/bin/passwd" "/usr/bin/chsh" "/usr/bin/chfn" "/usr/bin/gpasswd"
            "/usr/bin/newgrp" "/usr/bin/sudo" "/usr/bin/crontab"
        )
        
        suspicious_suid=()
        
        for binary in "${common_suid_binaries[@]}"; do
            if [ -f "$binary" ]; then
                if [ -u "$binary" ]; then
                    echo " ✓ $binary: SUID set (expected)"
                else
                    echo " ✗ $binary: SUID not set (unexpected)"
                    suspicious_suid+=("$binary")
                fi
            fi
        done
        
        if [ ${#suspicious_suid[@]} -gt 0 ]; then
            echo " - WARNING: ${#suspicious_suid[@]} common binaries missing SUID bit"
        fi
    }

    check_file_integrity_indicators()
    {
        echo " - Checking file integrity indicators..."
        
        echo " - Package manager verification:"
        
        # Check RPM verification if available
        if command -v rpm >/dev/null 2>&1; then
            echo " - RPM verification available"
            rpm_verified=0
            rpm_problems=0
            
            # Check a sample of SUID files
            for file in $(echo "$suid_files" | head -5); do
                if rpm -Vf "$file" >/dev/null 2>&1; then
                    ((rpm_verified++))
                else
                    ((rpm_problems++))
                    echo "   - $file: Not verified by RPM or modified"
                fi
            done
            echo "   - RPM verified: $rpm_verified, Potential issues: $rpm_problems"
        fi
        
        # Check DEB verification if available
        if command -v dpkg >/dev/null 2>&1; then
            echo " - DEB verification available"
            # Could implement debsums check here if available
        fi
        
        echo " - Note: Consider using AIDE or other FIM tools for comprehensive integrity checking"
    }

    check_recent_suid_changes()
    {
        echo " - Checking for recently modified SUID/SGID files..."
        
        recent_files=$(find / -type f \( -perm -4000 -o -perm -2000 \) -mtime -7 2>/dev/null | head -10 || echo "")
        recent_count=$(echo "$recent_files" | grep -c '^/' || echo "0")
        
        if [ "$recent_count" -gt 0 ]; then
            echo " - WARNING: $recent_count SUID/SGID files modified in last 7 days:"
            echo "$recent_files" | while read -r file; do
                if [ -n "$file" ]; then
                    mod_time=$(stat -c %y "$file" 2>/dev/null | cut -d' ' -f1 || echo "unknown")
                    echo "   - $file (modified: $mod_time)"
                fi
            done
        else
            echo " - OK: No recently modified SUID/SGID files found"
        fi
    }

    check_world_writable_suid()
    {
        echo " - Checking for world-writable SUID/SGID files (high risk)..."
        
        world_writable_suid=$(find / -type f -perm -4002 2>/dev/null | wc -l || echo "0")
        world_writable_sgid=$(find / -type f -perm -2002 2>/dev/null | wc -l || echo "0")
        
        if [ "$world_writable_suid" -gt 0 ]; then
            echo " - CRITICAL: $world_writable_suid world-writable SUID files found"
            find / -type f -perm -4002 2>/dev/null | head -5
        else
            echo " - OK: No world-writable SUID files found"
        fi
        
        if [ "$world_writable_sgid" -gt 0 ]; then
            echo " - CRITICAL: $world_writable_sgid world-writable SGID files found"
            find / -type f -perm -2002 2>/dev/null | head -5
        else
            echo " - OK: No world-writable SGID files found"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing SUID/SGID remediation guidance..."
        
        echo ""
        echo "SUID/SGID REMEDIATION GUIDANCE:"
        echo "==============================="
        echo ""
        echo "MANUAL REVIEW REQUIRED:"
        echo "----------------------"
        echo "1. Review all SUID/SGID files listed above"
        echo "2. Verify each file is legitimate and required"
        echo "3. Check file integrity using package managers or FIM tools"
        echo "4. Remove SUID/SGID bits from unnecessary files"
        echo ""
        echo "COMMANDS FOR MANUAL REVIEW:"
        echo "--------------------------"
        echo "Find all SUID files:"
        echo "  find / -type f -perm -4000 2>/dev/null"
        echo ""
        echo "Find all SGID files:"
        echo "  find / -type f -perm -2000 2>/dev/null"
        echo ""
        echo "Remove SUID bit from a file:"
        echo "  chmod u-s /path/to/file"
        echo ""
        echo "Remove SGID bit from a file:"
        echo "  chmod g-s /path/to/file"
        echo ""
        echo "Verify file with package manager (RPM):"
        echo "  rpm -Vf /path/to/binary"
        echo ""
        echo "Check file properties:"
        echo "  ls -la /path/to/file"
        echo "  file /path/to/file"
        echo "  stat /path/to/file"
        echo ""
        echo "INVESTIGATION STEPS:"
        echo "-------------------"
        echo "• Compare against known good baseline"
        echo "• Check file hashes against package databases"
        echo "• Verify file ownership and permissions"
        echo "• Review file locations and timestamps"
        echo "• Check for files in temporary or unusual directories"
        echo ""
        echo "SECURITY CONSIDERATIONS:"
        echo "-----------------------"
        echo "• World-writable SUID/SGID files are extremely dangerous"
        echo "• SUID/SGID files in /tmp, /var/tmp should be investigated immediately"
        echo "• Recently modified SUID/SGID binaries may indicate compromise"
        echo "• Use principle of least privilege - remove unnecessary SUID/SGID bits"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking common SUID binaries..."
    check_common_suid_binaries
    remediation_applied=true
    
    echo ""
    echo "Checking file integrity indicators..."
    check_file_integrity_indicators
    remediation_applied=true
    
    echo ""
    echo "Checking recent SUID/SGID changes..."
    check_recent_suid_changes
    remediation_applied=true
    
    echo ""
    echo "Checking world-writable SUID/SGID files..."
    check_world_writable_suid
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No file system analysis performed"
    fi

    echo ""
    echo "Remediation of SUID/SGID file review complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: SUID file summary
    echo ""
    echo "1. SUID FILE SUMMARY:"
    echo "--------------------"
    echo "Total SUID files: $suid_count"
    if [ "$suid_count" -gt 0 ]; then
        echo "PROOF (sample SUID files):"
        echo "$suid_files" | head -5
        echo "... (and $(($suid_count - 5)) more)"
    else
        echo "PROOF: No SUID files found"
    fi
    
    # PROOF 2: SGID file summary
    echo ""
    echo "2. SGID FILE SUMMARY:"
    echo "--------------------"
    echo "Total SGID files: $sgid_count"
    if [ "$sgid_count" -gt 0 ]; then
        echo "PROOF (sample SGID files):"
        echo "$sgid_files" | head -5
        echo "... (and $(($sgid_count - 5)) more)"
    else
        echo "PROOF: No SGID files found"
    fi
    
    # PROOF 3: High-risk file check
    echo ""
    echo "3. HIGH-RISK FILE CHECK:"
    echo "-----------------------"
    world_writable_count=$(find / -type f \( -perm -4002 -o -perm -2002 \) 2>/dev/null | wc -l || echo "0")
    if [ "$world_writable_count" -eq 0 ]; then
        echo "PASS: No world-writable SUID/SGID files found"
        echo "PROOF: find / -type f \\( -perm -4002 -o -perm -2002 \\) returned no results"
    else
        echo "FAIL: $world_writable_count world-writable SUID/SGID files found"
        echo "PROOF (first 3 files):"
        find / -type f \( -perm -4002 -o -perm -2002 \) 2>/dev/null | head -3
        final_status_pass=false
    fi
    
    # PROOF 4: Unusual directory check
    echo ""
    echo "4. UNUSUAL DIRECTORY CHECK:"
    echo "--------------------------"
    unusual_count=0
    for dir in "${unusual_dirs[@]}"; do
        if [ -d "$dir" ]; then
            count=$(find "$dir" -type f \( -perm -4000 -o -perm -2000 \) 2>/dev/null | wc -l || echo "0")
            if [ "$count" -gt 0 ]; then
                echo "WARNING: $dir contains $count SUID/SGID files"
                unusual_count=$((unusual_count + count))
            fi
        fi
    done
    
    if [ "$unusual_count" -eq 0 ]; then
        echo "PASS: No SUID/SGID files in unusual directories"
        echo "PROOF: Checked ${#unusual_dirs[@]} directories: ${unusual_dirs[*]}"
    else
        echo "WARNING: $unusual_count SUID/SGID files in unusual directories"
        final_status_pass=false
    fi
    
    # PROOF 5: Recent changes check
    echo ""
    echo "5. RECENT CHANGES CHECK:"
    echo "-----------------------"
    recent_count=$(find / -type f \( -perm -4000 -o -perm -2000 \) -mtime -7 2>/dev/null | wc -l || echo "0")
    if [ "$recent_count" -eq 0 ]; then
        echo "PASS: No recently modified SUID/SGID files"
        echo "PROOF: No files modified in last 7 days"
    else
        echo "INFO: $recent_count SUID/SGID files modified in last 7 days"
        echo "PROOF (first 3 files):"
        find / -type f \( -perm -4000 -o -perm -2000 \) -mtime -7 2>/dev/null | head -3
        echo "NOTE: This may be normal for system updates"
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Review the complete list of $suid_count SUID and $sgid_count SGID files"
    echo "• Verify each file is legitimate and necessary for system operation"
    echo "• Check file integrity against known good baselines"
    echo "• Investigate any files in unusual locations"
    echo "• Remove SUID/SGID bits from unnecessary files"
    echo "• Document findings for audit purposes"
    echo ""
    echo "COMPREHENSIVE REVIEW COMMANDS:"
    echo "=============================="
    echo ""
    echo "FULL SUID/SGID LIST:"
    echo "  find / -type f -perm -4000 -ls 2>/dev/null > suid_files.txt"
    echo "  find / -type f -perm -2000 -ls 2>/dev/null > sgid_files.txt"
    echo ""
    echo "DETAILED FILE INFORMATION:"
    echo "  for file in \$(cat suid_files.txt | awk '{print \$11}'); do"
    echo "    echo \"=== \$file ===\""
    echo "    ls -la \"\$file\""
    echo "    file \"\$file\""
    echo "    rpm -Vf \"\$file\" 2>/dev/null || echo \"Not in RPM database\""
    echo "  done"
    echo ""
    echo "REMOVE UNNECESSARY PERMISSIONS:"
    echo "  chmod u-s /path/to/unnecessary_suid_file"
    echo "  chmod g-s /path/to/unnecessary_sgid_file"
    echo ""
    echo "MONITORING:"
    echo "  # Set up regular monitoring with AIDE or similar FIM tool"
    echo "  aide --check"
    echo "  # Or use inotify to monitor for new SUID/SGID files"
    echo "  inotifywait -m -r -e create --format '%w%f' / | while read file; do"
    echo "    if [ -u \"\$file\" ] || [ -g \"\$file\" ]; then"
    echo "      echo \"WARNING: New SUID/SGID file: \$file\""
    echo "    fi"
    echo "  done"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: SUID/SGID file verification completed"
        echo "NOTE: Manual review of all $suid_count SUID and $sgid_count SGID files required"
    else
        echo ""
        echo "WARNING: Potential SUID/SGID security issues detected - manual investigation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="