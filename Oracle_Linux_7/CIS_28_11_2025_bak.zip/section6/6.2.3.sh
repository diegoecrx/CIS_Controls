#!/usr/bin/env bash
# Script: 6.2.3.sh
# Item: 6.2.3 Ensure all groups in /etc/passwd exist in /etc/group (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.3.sh"
ITEM_NAME="6.2.3 Ensure all groups in /etc/passwd exist in /etc/group (Automated)"
DESCRIPTION="This remediation ensures all groups referenced in /etc/passwd exist in /etc/group."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check for invalid group IDs
check_group_validity() {
    echo "Checking for invalid group IDs in /etc/passwd..."
    invalid_groups=""
    
    # Extract all unique GIDs from /etc/passwd
    while IFS=: read -r user _ uid gid _ _ shell; do
        # Skip if GID field is empty
        if [ -z "$gid" ]; then
            continue
        fi
        
        # Check if this GID exists in /etc/group
        if ! grep -q "^[^:]*:[^:]*:$gid:" /etc/group 2>/dev/null; then
            invalid_groups="$invalid_groups\n - User: $user (UID: $uid, GID: $gid) - group does not exist"
        fi
    done < /etc/passwd
    
    if [ -z "$invalid_groups" ]; then
        echo "PASS: All groups in /etc/passwd exist in /etc/group"
        echo "PROOF: No invalid group IDs found"
        return 0
    else
        echo "FAIL: Found invalid group IDs:"
        echo -e "$invalid_groups"
        return 1
    fi
}
# Function to fix invalid group IDs
fix_group_validity() {
    echo "Fixing invalid group IDs..."
    
    # Collect all invalid GIDs
    declare -A invalid_gids
    while IFS=: read -r user _ uid gid _ _ shell; do
        if [ -z "$gid" ]; then
            continue
        fi
        
        if ! grep -q "^[^:]*:[^:]*:$gid:" /etc/group 2>/dev/null; then
            invalid_gids[$gid]="$user"
        fi
    done < /etc/passwd
    
    # For each invalid GID, create a matching group or reassign to valid group
    for gid in "${!invalid_gids[@]}"; do
        user="${invalid_gids[$gid]}"
        echo "Processing user: $user with missing GID: $gid"
        
        # Try to create a group with that GID if it doesn't exist
        # First check if this GID is available
        if ! grep -q "^[^:]*:[^:]*:$gid:" /etc/group; then
            # Create a group named after the GID or use a default
            groupadd -g "$gid" "group_$gid" 2>/dev/null || {
                # If GID is taken, reassign user to a valid group (like 'users' if available, else 'root')
                valid_gid=$(getent group users | cut -d: -f3 2>/dev/null || echo "0")
                echo " - Creating group_$gid for GID $gid"
                usermod -g "$valid_gid" "$user"
                echo " - Reassigned user $user to GID $valid_gid"
                continue
            }
        fi
        echo " - Created group for GID $gid"
    done
}
# Main remediation
{
    groups_ok=true
    if ! check_group_validity; then
        groups_ok=false
    fi
    if [ "$groups_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_group_validity
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_group_validity; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: All groups in /etc/passwd exist in /etc/group"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
