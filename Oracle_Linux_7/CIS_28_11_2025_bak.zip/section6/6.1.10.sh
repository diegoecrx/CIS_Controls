#!/usr/bin/env bash
# Script: 6.1.10.sh
# Item: 6.1.10 Ensure permissions on /etc/security/opasswd are configured (Automated)
set -euo pipefail
SCRIPT_NAME="6.1.10.sh"
ITEM_NAME="6.1.10 Ensure permissions on /etc/security/opasswd are configured (Automated)"
DESCRIPTION="This remediation ensures permissions on /etc/security/opasswd files are configured correctly (0600 root:root)."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/security/opasswd files permissions and ownership..."
    
    # Files to check
    opasswd_files=(
        "/etc/security/opasswd"
        "/etc/security/opasswd.old"
    )
    
    all_configured=true
    files_exist=false
    
    for file in "${opasswd_files[@]}"; do
        if [ -e "$file" ]; then
            files_exist=true
            echo " - Checking $file"
            
            # Get current permissions, owner, and group
            current_perms=$(stat -c "%a" "$file")
            current_owner=$(stat -c "%U" "$file")
            current_group=$(stat -c "%G" "$file")
            
            # Check permissions (should be 0600)
            if [ "$current_perms" != "600" ]; then
                echo "FAIL: $file has incorrect permissions"
                echo "PROOF: Current permissions are $current_perms (should be 600)"
                all_configured=false
            fi
            
            # Check owner (should be root)
            if [ "$current_owner" != "root" ]; then
                echo "FAIL: $file has incorrect owner"
                echo "PROOF: Current owner is $current_owner (should be root)"
                all_configured=false
            fi
            
            # Check group (should be root)
            if [ "$current_group" != "root" ]; then
                echo "FAIL: $file has incorrect group"
                echo "PROOF: Current group is $current_group (should be root)"
                all_configured=false
            fi
        fi
    done
    
    if [ "$files_exist" = false ]; then
        echo "PASS: /etc/security/opasswd files do not exist"
        echo "PROOF: Neither /etc/security/opasswd nor /etc/security/opasswd.old exist (acceptable)"
        return 0
    fi
    
    if [ "$all_configured" = true ]; then
        echo "PASS: /etc/security/opasswd files permissions and ownership properly configured"
        echo "PROOF: Access: (0600/-rw-------) Uid: (0/root) Gid: (0/root)"
        return 0
    fi
    
    return 1
}
# Function to fix
fix_opasswd_permissions() {
    echo "Applying fix..."
    
    # Files to fix
    opasswd_files=(
        "/etc/security/opasswd"
        "/etc/security/opasswd.old"
    )
    
    # Ensure /etc/security directory exists
    if [ ! -d /etc/security ]; then
        echo " - Creating /etc/security directory"
        mkdir -p /etc/security
        chown root:root /etc/security
        chmod 755 /etc/security
    fi
    
    files_processed=0
    
    for file in "${opasswd_files[@]}"; do
        if [ -e "$file" ]; then
            echo " - Processing $file"
            
            # Get current status for reporting
            current_perms=$(stat -c "%a" "$file")
            current_owner=$(stat -c "%U" "$file")
            current_group=$(stat -c "%G" "$file")
            
            echo " - Current status: permissions=$current_perms owner=$current_owner group=$current_group"
            
            # Fix permissions (remove execute for user, all permissions for group and other)
            echo " - Setting correct permissions on $file"
            chmod u-x,go-rwx "$file"
            
            # Fix ownership
            echo " - Setting correct ownership on $file"
            chown root:root "$file"
            
            # Verify changes
            new_perms=$(stat -c "%a" "$file")
            new_owner=$(stat -c "%U" "$file")
            new_group=$(stat -c "%G" "$file")
            
            echo " - New status: permissions=$new_perms owner=$new_owner group=$new_group"
            ((files_processed++))
        fi
    done
    
    if [ $files_processed -eq 0 ]; then
        echo " - No /etc/security/opasswd files found - no action needed"
    else
        echo " - Processed $files_processed opasswd files"
    fi
    
    echo " - /etc/security/opasswd permissions and ownership configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_opasswd_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: /etc/security/opasswd files permissions and ownership properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="