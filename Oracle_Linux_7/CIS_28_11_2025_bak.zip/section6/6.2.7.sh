#!/usr/bin/env bash
# Script: 6.2.7.sh
# Item: 6.2.7 Ensure no duplicate group names exist (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.7.sh"
ITEM_NAME="6.2.7 Ensure no duplicate group names exist (Automated)"
DESCRIPTION="This remediation ensures no duplicate group names exist in /etc/group."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check for duplicate group names
check_duplicate_group_names() {
    echo "Checking for duplicate group names in /etc/group..."
    duplicate_names=""
    
    # Extract all group names and find duplicates
    name_list=$(cut -d: -f1 /etc/group | sort)
    while read -r name; do
        # Count occurrences of this group name
        count=$(cut -d: -f1 /etc/group | grep -c "^$name$" || true)
        if [ "$count" -gt 1 ]; then
            # Get all GIDs with this group name
            gids_with_name=$(awk -F: -v n="$name" '$1 == n {print $3}' /etc/group | tr '\n' ',')
            duplicate_names="$duplicate_names\n - Group name: $name appears with GIDs: $gids_with_name"
        fi
    done <<< "$name_list"
    
    if [ -z "$duplicate_names" ]; then
        echo "PASS: No duplicate group names found"
        echo "PROOF: All group names are unique in /etc/group"
        return 0
    else
        echo "FAIL: Found duplicate group names:"
        echo -e "$duplicate_names"
        return 1
    fi
}
# Function to fix duplicate group names
fix_duplicate_group_names() {
    echo "Fixing duplicate group names..."
    
    # Find all duplicate group names
    name_list=$(cut -d: -f1 /etc/group | sort -u)
    while read -r name; do
        count=$(cut -d: -f1 /etc/group | grep -c "^$name$" || true)
        if [ "$count" -gt 1 ]; then
            # Get all GIDs with this duplicate group name
            duplicate_entries=$(awk -F: -v n="$name" '$1 == n {print $1":"$3}' /etc/group)
            
            # Keep the first entry, rename others
            counter=1
            while read -r entry; do
                group_name=$(echo "$entry" | cut -d: -f1)
                gid=$(echo "$entry" | cut -d: -f2)
                
                if [ "$counter" -eq 1 ]; then
                    echo " - Keeping group \"$group_name\" (GID: $gid)"
                    counter=$((counter + 1))
                else
                    new_name="${group_name}_${gid}"
                    echo " - Renaming group \"$group_name\" (GID: $gid) to \"$new_name\""
                    groupmod -n "$new_name" "$group_name" 2>/dev/null || {
                        echo "   WARNING: Failed to rename group $group_name - may already exist"
                    }
                fi
            done <<< "$duplicate_entries"
        fi
    done <<< "$name_list"
}
# Main remediation
{
    groupname_ok=true
    if ! check_duplicate_group_names; then
        groupname_ok=false
    fi
    if [ "$groupname_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_duplicate_group_names
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_duplicate_group_names; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: No duplicate group names exist"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
