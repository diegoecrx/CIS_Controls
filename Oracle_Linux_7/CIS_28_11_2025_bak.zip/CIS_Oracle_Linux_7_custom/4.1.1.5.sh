#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

echo "Current permissions before changes:"
ls -ld /etc/cron.weekly
echo ""

echo "Applying ownership and permissions..."
chown root:root /etc/cron.weekly
chmod og-rwx /etc/cron.weekly

echo "Permissions after changes:"
ls -ld /etc/cron.weekly
echo ""

echo "Detailed stat output:"
stat -c "Owner: %U" /etc/cron.weekly
stat -c "Group: %G" /etc/cron.weekly  
stat -c "Permissions: %a" /etc/cron.weekly
echo ""

# Verify with multiple methods
OWNER=$(stat -c "%U" /etc/cron.weekly)
GROUP=$(stat -c "%G" /etc/cron.weekly)
PERMS=$(stat -c "%a" /etc/cron.weekly)
SYMBOLIC_PERMS=$(stat -c "%A" /etc/cron.weekly)

echo "Verification:"
echo "Owner: $OWNER (required: root)"
echo "Group: $GROUP (required: root)" 
echo "Permissions: $PERMS (required: 700)"
echo "Symbolic: $SYMBOLIC_PERMS (required: drwx------)"
echo ""

if [[ "$OWNER" == "root" && "$GROUP" == "root" && "$PERMS" == "700" ]]; then
    echo "pass"
else
    echo "FAIL: /etc/cron.weekly permissions configuration failed"
    echo "Expected: root:root 700"
    echo "Actual: $OWNER:$GROUP $PERMS"
    exit 1
fi