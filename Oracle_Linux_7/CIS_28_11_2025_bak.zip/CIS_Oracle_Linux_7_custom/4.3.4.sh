#!/usr/bin/env bash
# Script: 4.3.4.sh
# Item: 4.3.4 Ensure users must provide password for escalation (Automated)
set -euo pipefail
SCRIPT_NAME="4.3.4.sh"
ITEM_NAME="4.3.4 Ensure users must provide password for escalation (Automated)"
DESCRIPTION="This remediation ensures users must provide password for escalation by removing NOPASSWD tags."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking for NOPASSWD tags..."
    nopasswd=$(grep -r 'NOPASSWD' /etc/sudoers /etc/sudoers.d/* 2>/dev/null || true)
    if [ -z "$nopasswd" ]; then
        echo "PASS: No NOPASSWD tags found"
        echo "PROOF: grep returned empty"
        return 0
    else
        echo "FAIL: NOPASSWD tags found"
        echo "PROOF: $nopasswd"
        return 1
    fi
}
# Function to fix
fix_nopasswd() {
    echo "Applying fix..."
    for file in /etc/sudoers /etc/sudoers.d/*; do
        if [ -f "$file" ]; then
            sed -i '/NOPASSWD/d' "$file"
            echo " - Removed NOPASSWD lines from $file"
        fi
    done
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nopasswd
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: No NOPASSWD tags"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="