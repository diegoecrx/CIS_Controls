#!/usr/bin/env bash
# Script: 5.1.2.3.sh
# Item: 5.1.2.3 Ensure journald is configured to compress large log files (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.2.3.sh"
ITEM_NAME="5.1.2.3 Ensure journald is configured to compress large log files (Automated)"
DESCRIPTION="This remediation ensures journald is configured to compress large log files."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking journald compression configuration..."
    
    # Check if journald.conf exists
    if [ ! -f /etc/systemd/journald.conf ]; then
        echo "FAIL: /etc/systemd/journald.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Check for Compress setting in main config file
    if grep -q '^Compress=yes' /etc/systemd/journald.conf 2>/dev/null; then
        echo "PASS: journald compression properly configured"
        echo "PROOF: Compress=yes found in /etc/systemd/journald.conf"
        return 0
    fi
    
    # Check for Compress setting in journald.conf.d directory
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in /etc/systemd/journald.conf.d/*.conf; do
            if [ -f "$conf_file" ] && grep -q '^Compress=yes' "$conf_file" 2>/dev/null; then
                echo "PASS: journald compression properly configured"
                echo "PROOF: Compress=yes found in $conf_file"
                return 0
            fi
        done
    fi
    
    # Check if Compress is explicitly disabled
    if grep -q '^Compress=no' /etc/systemd/journald.conf 2>/dev/null; then
        echo "FAIL: journald compression is explicitly disabled"
        echo "PROOF: Compress=no found in /etc/systemd/journald.conf"
        return 1
    fi
    
    # Check for disabled compression in conf.d files
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in /etc/systemd/journald.conf.d/*.conf; do
            if [ -f "$conf_file" ] && grep -q '^Compress=no' "$conf_file" 2>/dev/null; then
                echo "FAIL: journald compression is explicitly disabled"
                echo "PROOF: Compress=no found in $conf_file"
                return 1
            fi
        done
    fi
    
    echo "FAIL: journald compression not configured"
    echo "PROOF: No Compress=yes setting found in journald configuration"
    return 1
}
# Function to fix
fix_journald_compression() {
    echo "Applying fix..."
    
    # Ensure journald.conf exists
    if [ ! -f /etc/systemd/journald.conf ]; then
        echo " - Creating /etc/systemd/journald.conf"
        cat > /etc/systemd/journald.conf << 'EOF'
#  This file is part of systemd.
#
#  systemd is free software; you can redistribute it and/or modify it
#  under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation; either version 2.1 of the License, or
#  (at your option) any later version.
#
# Entries in this file show the compile time defaults.
# You can change settings by editing this file.
# Defaults can be restored by simply deleting this file.
#
# See journald.conf(5) for details.

[Journal]
EOF
    fi
    
    # Check if Compress is already configured
    if grep -q '^Compress=' /etc/systemd/journald.conf; then
        # Update existing Compress setting
        echo " - Updating existing Compress setting in /etc/systemd/journald.conf"
        sed -i 's/^Compress=.*/Compress=yes/' /etc/systemd/journald.conf
    else
        # Add Compress setting to [Journal] section
        echo " - Adding Compress=yes to /etc/systemd/journald.conf"
        if grep -q '^\[Journal\]' /etc/systemd/journald.conf; then
            # Add after [Journal] section
            sed -i '/^\[Journal\]/a Compress=yes' /etc/systemd/journald.conf
        else
            # Add [Journal] section and Compress setting
            echo -e "\n[Journal]\nCompress=yes" >> /etc/systemd/journald.conf
        fi
    fi
    
    # Remove any conflicting Compress=no settings from conf.d files
    if [ -d /etc/systemd/journald.conf.d ]; then
        for conf_file in /etc/systemd/journald.conf.d/*.conf; do
            if [ -f "$conf_file" ] && grep -q '^Compress=no' "$conf_file"; then
                echo " - Removing conflicting Compress=no from $conf_file"
                sed -i '/^Compress=no/d' "$conf_file"
            fi
        done
    fi
    
    # Restart systemd-journald service to apply changes
    echo " - Restarting systemd-journald service"
    systemctl restart systemd-journald.service
    
    echo " - journald compression configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_journald_compression
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: journald compression properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="