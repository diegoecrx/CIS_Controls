#!/bin/bash

set -euo pipefail

echo "=== 5.1.4 Ensure all logfiles have appropriate access configured ==="
echo "Starting audit at: $(date)"
echo

# Check log directory permissions
LOG_DIRS="/var/log /var/log/audit /var/log/messages /var/log/secure /var/log/cron /var/log/maillog /var/log/spooler /var/log/boot.log /var/log/dmesg"

for log_dir in $LOG_DIRS; do
    if [ -d "$log_dir" ] || [ -f "$log_dir" ]; then
        echo "Checking: $log_dir"
        echo "Current permissions: $(ls -ld "$log_dir" 2>/dev/null || ls -l "$log_dir")"
        
        # Check if permissions are too permissive
        perms=$(stat -c "%a" "$log_dir" 2>/dev/null || echo "N/A")
        if [[ "$perms" =~ ^[0-9]+$ ]]; then
            if [ "$perms" -gt 640 ] && [ "$perms" -ne 750 ]; then
                echo "** FAIL **: $log_dir has permissions $perms (should be 640 or more restrictive)"
            else
                echo "** PASS **: $log_dir has appropriate permissions: $perms"
            fi
        fi
        echo
    fi
done

# Check specific log files
echo "=== Checking specific log files ==="
find /var/log -type f -name "*.log" -o -name "dmesg" -o -name "messages" -o -name "secure" -o -name "cron" -o -name "maillog" -o -name "spooler" -o -name "boot.log" 2>/dev/null | head -20 | while read logfile; do
    if [ -f "$logfile" ]; then
        perms=$(stat -c "%a" "$logfile" 2>/dev/null || echo "N/A")
        if [[ "$perms" =~ ^[0-9]+$ ]]; then
            if [ "$perms" -gt 640 ]; then
                echo "** FAIL **: $logfile has permissions $perms (should be 640 or more restrictive)"
                echo "  Details: $(ls -l "$logfile")"
            else
                echo "** PASS **: $logfile permissions: $perms"
            fi
        fi
    fi
done

echo
echo "=== Summary ==="
echo "Audit completed at: $(date)"
echo "Check the output above for any FAIL results"