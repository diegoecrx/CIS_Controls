#!/usr/bin/env bash
# Script: 3.4.4.2.2.sh
# Item: 3.4.4.2.2 Ensure iptables outbound and established connections are configured (Manual)
set -euo pipefail
SCRIPT_NAME="3.4.4.2.2.sh"
ITEM_NAME="3.4.4.2.2 Ensure iptables outbound and established connections are configured (Manual)"
DESCRIPTION="Configure iptables to allow outbound and established connections according to site policy"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking iptables outbound and established connection rules..."
    
    # Check if iptables is available
    if ! command -v iptables >/dev/null 2>&1; then
        echo "FAIL: iptables is not available on this system"
        echo "PROOF: 'command -v iptables' returned no iptables command found"
        return 1
    fi

    local missing_rules=0
    local found_rules=0
    
    # Check for established connection rules in INPUT chain
    echo "Checking established connection rules (INPUT chain)..."
    if ! iptables -L INPUT -n 2>/dev/null | grep -q 'tcp.*state ESTABLISHED'; then
        echo " - MISSING: TCP established rule in INPUT chain"
        ((missing_rules++))
    else
        echo " - FOUND: TCP established rule in INPUT chain"
        ((found_rules++))
    fi
    
    if ! iptables -L INPUT -n 2>/dev/null | grep -q 'udp.*state ESTABLISHED'; then
        echo " - MISSING: UDP established rule in INPUT chain"
        ((missing_rules++))
    else
        echo " - FOUND: UDP established rule in INPUT chain"
        ((found_rules++))
    fi
    
    if ! iptables -L INPUT -n 2>/dev/null | grep -q 'icmp.*state ESTABLISHED'; then
        echo " - MISSING: ICMP established rule in INPUT chain"
        ((missing_rules++))
    else
        echo " - FOUND: ICMP established rule in INPUT chain"
        ((found_rules++))
    fi
    
    # Check for outbound connection rules in OUTPUT chain
    echo "Checking outbound connection rules (OUTPUT chain)..."
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q 'tcp.*state NEW,ESTABLISHED'; then
        echo " - MISSING: TCP outbound rule in OUTPUT chain"
        ((missing_rules++))
    else
        echo " - FOUND: TCP outbound rule in OUTPUT chain"
        ((found_rules++))
    fi
    
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q 'udp.*state NEW,ESTABLISHED'; then
        echo " - MISSING: UDP outbound rule in OUTPUT chain"
        ((missing_rules++))
    else
        echo " - FOUND: UDP outbound rule in OUTPUT chain"
        ((found_rules++))
    fi
    
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q 'icmp.*state NEW,ESTABLISHED'; then
        echo " - MISSING: ICMP outbound rule in OUTPUT chain"
        ((missing_rules++))
    else
        echo " - FOUND: ICMP outbound rule in OUTPUT chain"
        ((found_rules++))
    fi
    
    # Summary
    if [ $missing_rules -eq 0 ]; then
        echo "PASS: All required iptables connection rules are configured"
        echo "PROOF: Found $found_rules required connection state rules"
        return 0
    else
        echo "FAIL: Missing $missing_rules required connection rules"
        echo "PROOF: Found $found_rules out of 6 required connection state rules"
        return 1
    fi
}

# Function to fix
fix_iptables_rules() {
    echo "Applying fix for iptables connection rules..."
    
    # Add established connection rules to INPUT chain
    echo " - Adding established connection rules to INPUT chain"
    iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT 2>/dev/null || echo "   Warning: Failed to add TCP established rule"
    iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT 2>/dev/null || echo "   Warning: Failed to add UDP established rule"
    iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT 2>/dev/null || echo "   Warning: Failed to add ICMP established rule"
    
    # Add outbound connection rules to OUTPUT chain
    echo " - Adding outbound connection rules to OUTPUT chain"
    iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT 2>/dev/null || echo "   Warning: Failed to add TCP outbound rule"
    iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT 2>/dev/null || echo "   Warning: Failed to add UDP outbound rule"
    iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT 2>/dev/null || echo "   Warning: Failed to add ICMP outbound rule"
    
    echo " - iptables connection rules configuration completed"
    echo " - NOTE: Rules may not be persistent. Use 'service iptables save' to make permanent"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_rules
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: iptables connection rules properly configured"
    else
        echo "FAIL: Issues remain - manual configuration may be required"
        echo ""
        echo "MANUAL CONFIGURATION COMMANDS:"
        echo "=============================="
        echo "iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT"
        echo "iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT"
        echo "iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT"
        echo "iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo "iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT"
        echo ""
        echo "To make rules permanent:"
        echo "service iptables save"
        echo "-OR-"
        echo "iptables-save > /etc/sysconfig/iptables"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="