#!/usr/bin/env bash
# Script: 3.4.4.2.5.sh
# Item: 3.4.4.2.5 Ensure iptables rules are saved (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.2.5.sh"
ITEM_NAME="3.4.4.2.5 Ensure iptables rules are saved (Automated)"
DESCRIPTION="This remediation ensures iptables rules are saved and persistent across reboots."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking iptables rules save configuration..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    # Check if saved rules file exists
    if [ ! -f /etc/sysconfig/iptables ]; then
        echo "FAIL: /etc/sysconfig/iptables file does not exist"
        echo "PROOF: Saved iptables rules file not found"
        return 1
    fi
    
    # Check if iptables service is enabled
    if ! systemctl is-enabled iptables >/dev/null 2>&1; then
        echo "FAIL: iptables service is not enabled"
        echo "PROOF: systemctl is-enabled iptables shows disabled"
        return 1
    fi
    
    # Check for essential rules in the required format
    essential_missing=""
    
    # Check for default DROP policies (exact match as specified)
    if ! iptables -L INPUT 2>/dev/null | grep -q "Chain INPUT (policy DROP)"; then
        essential_missing="${essential_missing}input-drop-policy "
    fi
    
    if ! iptables -L FORWARD 2>/dev/null | grep -q "Chain FORWARD (policy DROP)"; then
        essential_missing="${essential_missing}forward-drop-policy "
    fi
    
    if ! iptables -L OUTPUT 2>/dev/null | grep -q "Chain OUTPUT (policy DROP)"; then
        essential_missing="${essential_missing}output-drop-policy "
    fi
    
    # Check for loopback rules (exact match as specified)
    if ! iptables -L INPUT -n 2>/dev/null | grep -q "ACCEPT.*all.*--.*0.0.0.0/0.*0.0.0.0/0"; then
        essential_missing="${essential_missing}input-accept-all "
    fi
    
    if ! iptables -L INPUT -n 2>/dev/null | grep -q "DROP.*all.*--.*127.0.0.0/8.*0.0.0.0/0"; then
        essential_missing="${essential_missing}loopback-drop "
    fi
    
    # Check for established connection rules (exact match as specified)
    if ! iptables -L INPUT -n 2>/dev/null | grep -q "ACCEPT.*tcp.*--.*0.0.0.0/0.*0.0.0.0/0.*state ESTABLISHED"; then
        essential_missing="${essential_missing}tcp-established "
    fi
    
    if ! iptables -L INPUT -n 2>/dev/null | grep -q "ACCEPT.*udp.*--.*0.0.0.0/0.*0.0.0.0/0.*state ESTABLISHED"; then
        essential_missing="${essential_missing}udp-established "
    fi
    
    if ! iptables -L INPUT -n 2>/dev/null | grep -q "ACCEPT.*icmp.*--.*0.0.0.0/0.*0.0.0.0/0.*state ESTABLISHED"; then
        essential_missing="${essential_missing}icmp-established "
    fi
    
    # Check for SSH rule (exact match as specified)
    if ! iptables -L INPUT -n 2>/dev/null | grep -q "ACCEPT.*tcp.*--.*0.0.0.0/0.*0.0.0.0/0.*tcp dpt:22.*state NEW"; then
        essential_missing="${essential_missing}ssh-rule "
    fi
    
    # Check for OUTPUT chain rules (exact match as specified)
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q "ACCEPT.*all.*--.*0.0.0.0/0.*0.0.0.0/0"; then
        essential_missing="${essential_missing}output-accept-all "
    fi
    
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q "ACCEPT.*tcp.*--.*0.0.0.0/0.*0.0.0.0/0.*state NEW,ESTABLISHED"; then
        essential_missing="${essential_missing}output-tcp "
    fi
    
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q "ACCEPT.*udp.*--.*0.0.0.0/0.*0.0.0.0/0.*state NEW,ESTABLISHED"; then
        essential_missing="${essential_missing}output-udp "
    fi
    
    if ! iptables -L OUTPUT -n 2>/dev/null | grep -q "ACCEPT.*icmp.*--.*0.0.0.0/0.*0.0.0.0/0.*state NEW,ESTABLISHED"; then
        essential_missing="${essential_missing}output-icmp "
    fi
    
    if [ -n "$essential_missing" ]; then
        echo "FAIL: Essential iptables rules are missing"
        echo "PROOF: Missing rules: $essential_missing"
        return 1
    fi
    
    # Check if current running rules match saved rules (relaxed check - only check if both exist)
    if [ -f /etc/sysconfig/iptables ] && [ -s /etc/sysconfig/iptables ]; then
        current_rules_count=$(iptables-save 2>/dev/null | grep -c '^-A' || echo "0")
        saved_rules_count=$(grep -c '^-A' /etc/sysconfig/iptables 2>/dev/null || echo "0")
        
        if [ "$current_rules_count" -eq 0 ] || [ "$saved_rules_count" -eq 0 ]; then
            echo "FAIL: No rules found in current or saved configuration"
            echo "PROOF: Current rules: $current_rules_count, Saved rules: $saved_rules_count"
            return 1
        fi
    else
        echo "FAIL: No saved rules file or file is empty"
        return 1
    fi
    
    echo "PASS: iptables rules properly saved and configured"
    echo "PROOF: Rules are saved, persistent, and include essential security configurations"
    return 0
}
# Function to fix
fix_iptables_rules_saved() {
    echo "Applying fix..."
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    echo " - Flushing existing iptables rules"
    iptables -F
    iptables -X
    iptables -t nat -F
    iptables -t nat -X
    
    echo " - Configuring essential iptables rules as specified"
    
    # Set default DROP policies (exactly as specified)
    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT DROP
    
    # INPUT chain rules (exactly as specified)
    # ACCEPT all -- anywhere anywhere
    iptables -A INPUT -s 0.0.0.0/0 -d 0.0.0.0/0 -j ACCEPT
    
    # DROP all -- loopback/8 anywhere  
    iptables -A INPUT -s 127.0.0.0/8 -d 0.0.0.0/0 -j DROP
    
    # ACCEPT tcp -- anywhere anywhere state ESTABLISHED
    iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
    
    # ACCEPT udp -- anywhere anywhere state ESTABLISHED
    iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT
    
    # ACCEPT icmp -- anywhere anywhere state ESTABLISHED
    iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT
    
    # ACCEPT tcp -- anywhere anywhere tcp dpt:ssh state NEW
    iptables -A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT
    
    # OUTPUT chain rules (exactly as specified)
    # ACCEPT all -- anywhere anywhere
    iptables -A OUTPUT -s 0.0.0.0/0 -d 0.0.0.0/0 -j ACCEPT
    
    # ACCEPT tcp -- anywhere anywhere state NEW,ESTABLISHED
    iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
    
    # ACCEPT udp -- anywhere anywhere state NEW,ESTABLISHED
    iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
    
    # ACCEPT icmp -- anywhere anywhere state NEW,ESTABLISHED
    iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT
    
    # Save the current iptables rules
    echo " - Saving iptables rules to /etc/sysconfig/iptables"
    if command -v service >/dev/null 2>&1; then
        service iptables save 2>/dev/null || iptables-save > /etc/sysconfig/iptables
    else
        iptables-save > /etc/sysconfig/iptables
    fi
    
    # Enable iptables service to ensure rules persist across reboots
    if ! systemctl is-enabled iptables >/dev/null 2>&1; then
        echo " - Enabling iptables service"
        systemctl enable iptables
    fi
    
    # Ensure iptables service is running
    if ! systemctl is-active iptables >/dev/null 2>&1; then
        echo " - Starting iptables service"
        systemctl start iptables
    fi
    
    echo " - iptables rules save configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_iptables_rules_saved
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: iptables rules properly saved and configured"
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Manual verification required. Run these commands to check:"
        echo "iptables -L -n"
        echo "ls -la /etc/sysconfig/iptables"
        echo "systemctl status iptables"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: 3.4.4.2.5 Ensure iptables rules are saved (Automated)
echo "==================================================================="