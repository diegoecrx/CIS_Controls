#!/bin/bash

# 5.1.1.3 Ensure journald is configured to send logs to rsyslog
# Remediation script

set -euo pipefail

JOURNALD_CONF="/etc/systemd/journald.conf"
REQUIRED_SETTING="ForwardToSyslog=yes"

# Function to check current status
check_status() {
    echo "Checking current journald configuration..."
    echo "-------------------------"
    
    # Check /etc/systemd/journald.conf
    if [[ -f "$JOURNALD_CONF" ]]; then
        if grep -Pq '^\s*ForwardToSyslog\s*=' "$JOURNALD_CONF" 2>/dev/null; then
            current_setting=$(grep -P '^\s*ForwardToSyslog\s*=' "$JOURNALD_CONF" | tail -1)
            if [[ "$current_setting" == "$REQUIRED_SETTING" ]]; then
                echo "PASSED - $JOURNALD_CONF"
                echo "Compliant file(s):"
                echo "      $JOURNALD_CONF - contains '$REQUIRED_SETTING'"
                echo "      Current setting: $current_setting"
            else
                echo "FAILED - $JOURNALD_CONF"
                echo "Non-compliant file(s):"
                echo "      $JOURNALD_CONF - contains incorrect setting"
                echo "      Current: $current_setting"
                echo "      Required: $REQUIRED_SETTING"
            fi
        else
            echo "FAILED - $JOURNALD_CONF"
            echo "The following file(s) do not contain \"^[\\s]*ForwardToSyslog[\\s]*=\":"
            echo "      $JOURNALD_CONF"
        fi
    else
        echo "FAILED - $JOURNALD_CONF"
        echo "Configuration file does not exist:"
        echo "      $JOURNALD_CONF"
    fi
    
    echo ""
    
    # Check systemd-journald.service status
    if systemctl is-active systemd-journald.service >/dev/null 2>&1; then
        echo "PASSED - systemd-journald.service"
        echo "The command 'systemctl is-active systemd-journald.service' returned:"
        echo "      $(systemctl is-active systemd-journald.service)"
    else
        echo "FAILED - systemd-journald.service"
        echo "Service is not active:"
        echo "      systemd-journald.service"
    fi
    
    echo ""
    
    # Check rsyslog.service status
    if systemctl is-active rsyslog.service >/dev/null 2>&1; then
        echo "PASSED - rsyslog.service"
        echo "The command 'systemctl is-active rsyslog.service' returned:"
        echo "      $(systemctl is-active rsyslog.service)"
    else
        echo "FAILED - rsyslog.service"
        echo "Service is not active:"
        echo "      rsyslog.service"
    fi
    
    echo "-------------------------"
}

# Function to remediate journald configuration
remediate_journald_conf() {
    echo "Remediating $JOURNALD_CONF..."
    
    # Create directory if it doesn't exist
    mkdir -p "$(dirname "$JOURNALD_CONF")"
    
    # Backup original file if it exists
    if [[ -f "$JOURNALD_CONF" ]]; then
        cp "$JOURNALD_CONF" "${JOURNALD_CONF}.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Check if ForwardToSyslog setting already exists
    if grep -Pq '^\s*ForwardToSyslog\s*=' "$JOURNALD_CONF" 2>/dev/null; then
        # Update existing entry
        sed -i "s/^\s*ForwardToSyslog\s*=.*/$REQUIRED_SETTING/" "$JOURNALD_CONF"
    else
        # Add new entry
        echo "$REQUIRED_SETTING" >> "$JOURNALD_CONF"
    fi
    
    # Verify the change
    if grep -Pq "^\s*ForwardToSyslog\s*=\s*yes\s*$" "$JOURNALD_CONF" 2>/dev/null; then
        echo "SUCCESS: $JOURNALD_CONF updated with '$REQUIRED_SETTING'"
        return 0
    else
        echo "ERROR: Failed to update $JOURNALD_CONF"
        return 1
    fi
}

# Function to reload systemd-journald service
reload_journald_service() {
    echo "Reloading systemd-journald service..."
    
    if systemctl reload-or-try-restart systemd-journald.service >/dev/null 2>&1; then
        echo "SUCCESS: systemd-journald.service reloaded"
        return 0
    else
        echo "WARNING: Could not reload systemd-journald.service, trying restart..."
        if systemctl restart systemd-journald.service >/dev/null 2>&1; then
            echo "SUCCESS: systemd-journald.service restarted"
            return 0
        else
            echo "ERROR: Failed to reload/restart systemd-journald.service"
            return 1
        fi
    fi
}

# Function to verify rsyslog service
verify_rsyslog_service() {
    echo "Verifying rsyslog service..."
    
    if ! systemctl is-active rsyslog.service >/dev/null 2>&1; then
        echo "WARNING: rsyslog.service is not active"
        echo "Do you want to start and enable rsyslog.service? (yes/no)"
        read -r response
        
        if [[ "$response" =~ ^[Yy]([Ee][Ss])?$ ]]; then
            if systemctl start rsyslog.service >/dev/null 2>&1 && \
               systemctl enable rsyslog.service >/dev/null 2>&1; then
                echo "SUCCESS: rsyslog.service started and enabled"
            else
                echo "ERROR: Failed to start rsyslog.service"
                return 1
            fi
        else
            echo "INFO: rsyslog.service remains inactive - journald forwarding may not work"
        fi
    else
        echo "SUCCESS: rsyslog.service is active"
    fi
    return 0
}

# Function to test journald to rsyslog forwarding
test_forwarding() {
    echo "Testing journald to rsyslog forwarding..."
    
    # Create a test log message
    TEST_MESSAGE="journald_rsyslog_forward_test_$(date +%s)"
    logger "$TEST_MESSAGE"
    
    # Wait a moment for the message to be processed
    sleep 2
    
    # Check if message appears in journald
    if journalctl -q --since "1 minute ago" | grep -q "$TEST_MESSAGE"; then
        echo "SUCCESS: Test message found in journald"
        
        # Check if message appears in syslog
        if grep -q "$TEST_MESSAGE" /var/log/syslog 2>/dev/null || \
           grep -q "$TEST_MESSAGE" /var/log/messages 2>/dev/null; then
            echo "SUCCESS: Test message forwarded to rsyslog"
            return 0
        else
            echo "WARNING: Test message not found in syslog files"
            echo "This may be normal if rsyslog is configured to use different log files"
            return 0
        fi
    else
        echo "ERROR: Test message not found in journald"
        return 1
    fi
}

# Main execution
main() {
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        echo "ERROR: This script must be run as root" >&2
        exit 1
    fi
    
    echo "=== 5.1.1.3 Ensure journald is configured to send logs to rsyslog ==="
    echo "Required setting: $REQUIRED_SETTING"
    echo ""
    
    # Show current status
    check_status
    
    echo ""
    echo "This script will:"
    echo "1. Set $REQUIRED_SETTING in $JOURNALD_CONF"
    echo "2. Reload systemd-journald.service"
    echo "3. Verify rsyslog.service is active"
    echo "4. Test log forwarding functionality"
    echo "5. Create backup of configuration file"
    echo ""
    echo "Do you want to proceed with remediation? (yes/no)"
    read -r response
    
    if ! [[ "$response" =~ ^[Yy]([Ee][Ss])?$ ]]; then
        echo "Remediation cancelled."
        exit 0
    fi
    
    # Remediate journald configuration
    if ! remediate_journald_conf; then
        echo "ERROR: Failed to remediate $JOURNALD_CONF"
        exit 1
    fi
    
    # Reload journald service
    if ! reload_journald_service; then
        echo "ERROR: Failed to reload systemd-journald.service"
        exit 1
    fi
    
    # Verify rsyslog service
    if ! verify_rsyslog_service; then
        echo "WARNING: Issues with rsyslog.service configuration"
    fi
    
    # Test forwarding
    echo ""
    echo "Do you want to test journald to rsyslog forwarding? (yes/no)"
    read -r test_response
    if [[ "$test_response" =~ ^[Yy]([Ee][Ss])?$ ]]; then
        test_forwarding
    fi
    
    echo ""
    echo "=== Remediation Complete ==="
    echo ""
    
    # Show final status
    check_status
    
    echo ""
    echo "NOTE: Journald configuration updated. Logs should now be forwarded to rsyslog."
    echo "Backup created at: ${JOURNALD_CONF}.backup.*"
}

# Execute main function
main "$@"