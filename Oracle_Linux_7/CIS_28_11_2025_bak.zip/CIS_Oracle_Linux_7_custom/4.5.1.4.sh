#!/bin/bash

# Enforce CIS 4.5.1.4 - Ensure inactive password lock is 30 days or less

# Set default inactive period for new users
useradd -D -f 30

# Predefined password - CHANGE THIS to your desired password
AUTO_PASSWORD="@Real2014NewYeah_"

echo "Automatically configuring inactive password lock..."

# Check current password status
echo "Checking user password status:"
users_need_password=()
for user in $(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow); do
    if passwd -S "$user" 2>/dev/null | grep -q " PS "; then
        last_change=$(chage -l "$user" 2>/dev/null | grep "Last password change" | awk -F: '{print $2}' | tr -d ' ')
        echo "User: $user, Last password change: $last_change"
        
        if [ "$last_change" = "never" ]; then
            users_need_password+=("$user")
        fi
    fi
done

# Automatically set passwords for users that need them
if [ ${#users_need_password[@]} -gt 0 ]; then
    echo ""
    echo "Automatically setting passwords for users: ${users_need_password[*]}"
    
    for user in "${users_need_password[@]}"; do
        echo "Setting password for $user..."
        
        # Use chpasswd to set password non-interactively
        echo "$user:$AUTO_PASSWORD" | chpasswd
        
        if [ $? -eq 0 ]; then
            echo "✓ Password set successfully for $user"
        else
            echo "✗ Failed to set password for $user"
            echo "Forcing password change on next login..."
            chage -d 0 "$user" 2>/dev/null
        fi
    done
fi

# Apply secure password aging configuration
echo ""
echo "Applying secure password aging configuration..."
for user in $(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow); do
    if passwd -S "$user" 2>/dev/null | grep -q " PS "; then
        echo "Configuring secure password aging for: $user"
        
        # Get current epoch day
        today_epoch=$(( $(date +%s) / 86400 ))
        
        # Get current shadow entry
        current_shadow=$(grep "^$user:" /etc/shadow)
        
        # Parse and update shadow fields
        password=$(echo "$current_shadow" | cut -d: -f2)
        expire_days=$(echo "$current_shadow" | cut -d: -f8)
        reserved=$(echo "$current_shadow" | cut -d: -f9)
        
        # Create new shadow entry with inactive=30
        new_shadow="$user:$password:$today_epoch:0:99999:7:30:$expire_days:$reserved"
        
        # Update shadow file
        sed -i "s|^$user:.*|$new_shadow|" /etc/shadow
        
        # Also use chage to ensure consistency
        chage -d $today_epoch "$user" 2>/dev/null
        chage -m 0 "$user" 2>/dev/null
        chage -M 99999 "$user" 2>/dev/null
        chage -W 7 "$user" 2>/dev/null
        chage -I 30 "$user" 2>/dev/null
        chage -E -1 "$user" 2>/dev/null
    fi
done

# Verify the changes
echo ""
echo "Verifying configuration:"
for user in $(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow); do
    if passwd -S "$user" 2>/dev/null | grep -q " PS "; then
        shadow_inactive=$(grep "^$user:" /etc/shadow | cut -d: -f7 | tr -d '[:space:]')
        echo "User: $user, Inactive days: $shadow_inactive"
    fi
done

# Final compliance check
echo ""
echo "Compliance check:"
non_compliant=false
for user in $(awk -F: '($2 != "" && $2 !~ /^[!*]/) {print $1}' /etc/shadow); do
    if passwd -S "$user" 2>/dev/null | grep -q " PS "; then
        shadow_inactive=$(grep "^$user:" /etc/shadow | cut -d: -f7 | tr -d '[:space:]')
        if [[ "$shadow_inactive" =~ ^[0-9]+$ ]] && [ "$shadow_inactive" -gt 30 ]; then
            echo "FAIL: $user has inactive=$shadow_inactive"
            non_compliant=true
        fi
    fi
done

if ! $non_compliant; then
    echo "pass"
else
    echo "fail"
fi