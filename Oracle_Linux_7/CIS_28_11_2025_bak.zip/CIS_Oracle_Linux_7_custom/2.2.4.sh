#!/usr/bin/env bash

# Script: 2.2.4.sh
# Item: 2.2.4 Ensure dns server services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.4.sh"
ITEM_NAME="2.2.4 Ensure dns server services are not in use (Automated)"
DESCRIPTION="This remediation ensures DNS server services are not in use by removing or masking the services. FORCE VERSION - Comprehensive DNS server removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_dns_server_status
check_dns_server_status() {
    echo "Checking DNS server status..."
    
    dns_installed=false
    dns_services_running=false
    dns_services_enabled=false
    dns_services_masked=false
    
    # Check for common DNS server packages
    dns_packages=("bind" "bind9" "bind-chroot" "bind-utils" "dnsmasq" "unbound" "powerdns" "maradns")
    
    for pkg in "${dns_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                dns_installed=true
                echo " - $pkg package is installed"
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                dns_installed=true
                echo " - $pkg package is installed"
            fi
        fi
    done
    
    # Check for DNS server processes
    if pgrep named >/dev/null 2>&1 || pgrep dnsmasq >/dev/null 2>&1 || pgrep unbound >/dev/null 2>&1; then
        dns_services_running=true
        echo " - DNS server processes running:"
        pgrep named 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep dnsmasq 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
        pgrep unbound 2>/dev/null | xargs ps -o pid,user,command -p 2>/dev/null || true
    fi
    
    # Check for DNS server services
    dns_services=("named" "bind9" "dnsmasq" "unbound" "pdns" "maradns")
    
    for service in "${dns_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            # Check if service is running
            if systemctl is-active "$service" >/dev/null 2>&1; then
                dns_services_running=true
                echo " - $service.service is running"
            fi
            
            # Check if service is enabled
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                dns_services_enabled=true
                echo " - $service.service is enabled"
            fi
            
            # Check if service is masked
            if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                dns_services_masked=true
                echo " - $service.service is masked"
            fi
        fi
    done
    
    # Check for DNS server network services
    if netstat -tulpn 2>/dev/null | grep -E ':53 ' | grep -v grep; then
        echo " - WARNING: DNS server port (53) in use:"
        netstat -tulpn 2>/dev/null | grep -E ':53 ' | head -10
    fi
    
    # Check for configuration files
    dns_configs=("/etc/named" "/etc/bind" "/etc/dnsmasq.conf" "/etc/dnsmasq.d" "/etc/unbound")
    for config in "${dns_configs[@]}"; do
        if [ -e "$config" ]; then
            echo " - DNS configuration found: $config"
        fi
    done
    
    # Check for running DNS resolver
    if grep -q "nameserver 127.0.0.1" /etc/resolv.conf 2>/dev/null || \
       grep -q "nameserver ::1" /etc/resolv.conf 2>/dev/null; then
        echo " - WARNING: Localhost is configured as DNS resolver in /etc/resolv.conf"
    fi
    
    return 0
}

# Function to stop_dns_services
stop_dns_services() {
    echo "Stopping DNS server services..."
    
    # List of DNS services to stop
    dns_services=("named" "bind9" "dnsmasq" "unbound" "pdns" "maradns")
    
    # Stop DNS processes first
    for process in named dnsmasq unbound pdns_server maradns; do
        if pgrep "$process" >/dev/null 2>&1; then
            echo " - Stopping $process processes..."
            pkill -TERM "$process" 2>/dev/null || true
            sleep 2
            
            # Force kill if still running
            if pgrep "$process" >/dev/null 2>&1; then
                echo " - Force stopping $process processes..."
                pkill -KILL "$process" 2>/dev/null || true
                sleep 1
            fi
        fi
    done
    
    # Stop services using systemctl
    for service in "${dns_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service.service..."
            if systemctl stop "$service" 2>&1; then
                echo "   - $service.service stopped"
            else
                echo "   - WARNING: Could not stop $service.service via systemctl"
            fi
        fi
    done
    
    # Additional stop for any DNS related services
    systemctl list-unit-files | grep -E "(named|bind|dnsmasq|unbound|dns)" | awk '{print $1}' | while read -r service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Verify no DNS server processes are running
    running_processes=0
    for process in named dnsmasq unbound pdns_server maradns; do
        if pgrep "$process" >/dev/null 2>&1; then
            running_processes=$((running_processes + 1))
        fi
    done
    
    if [ "$running_processes" -gt 0 ]; then
        echo " - CRITICAL: DNS server processes still running after stop attempts"
        return 1
    else
        echo " - No DNS server processes running"
    fi
    
    # Kill any remaining DNS processes
    for process in named dnsmasq unbound pdns_server maradns; do
        pkill -9 "$process" 2>/dev/null || true
    done
    
    return 0
}

# Function to remove_dns_packages
remove_dns_packages() {
    local pkg_mgr="$1"
    
    echo "Removing DNS server packages..."
    
    # List of DNS-related packages
    dns_packages=("bind" "bind9" "bind-chroot" "bind-utils" "bind-libs" "bind9utils" 
                   "dnsmasq" "dnsmasq-utils" "unbound" "unbound-libs" "powerdns" 
                   "pdns" "maradns")
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove DNS packages..."
            for pkg in "${dns_packages[@]}"; do
                if $pkg_mgr list installed "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if $pkg_mgr remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        apt)
            echo " - Using apt to remove DNS packages..."
            export DEBIAN_FRONTEND=noninteractive
            for pkg in "${dns_packages[@]}"; do
                if dpkg -l "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if apt-get remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        zypper)
            echo " - Using zypper to remove DNS packages..."
            for pkg in "${dns_packages[@]}"; do
                if zypper search --installed-only "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if zypper --non-interactive remove "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove DNS packages"
            return 1
            ;;
    esac
    
    # Clean up package cache and dependencies
    case "$pkg_mgr" in
        yum|dnf)
            $pkg_mgr autoremove -y 2>/dev/null || true
            ;;
        apt)
            apt-get autoremove -y 2>/dev/null || true
            ;;
    esac
    
    echo " - Package removal completed"
    return 0
}

# Function to mask_dns_services
mask_dns_services() {
    echo "Masking DNS server services..."
    
    # List of DNS services to mask
    dns_services=("named" "bind9" "dnsmasq" "unbound" "pdns" "maradns")
    
    for service in "${dns_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                if systemctl mask "$service" 2>&1; then
                    echo " - $service.service masked"
                else
                    echo " - WARNING: Could not mask $service.service"
                fi
            else
                echo " - $service.service already masked"
            fi
        fi
    done
    
    # Mask any other DNS related services
    systemctl list-unit-files | grep -E "(named|bind|dnsmasq|unbound|dns)" | awk '{print $1}' | while read -r service; do
        if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
            systemctl mask "$service" 2>/dev/null && echo " - $service masked" || true
        fi
    done
    
    return 0
}

# Function to disable_dns_services
disable_dns_services() {
    echo "Disabling DNS server services..."
    
    # List of DNS services to disable
    dns_services=("named" "bind9" "dnsmasq" "unbound" "pdns" "maradns")
    
    for service in "${dns_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl disable "$service" 2>&1; then
                    echo " - $service.service disabled"
                else
                    echo " - WARNING: Could not disable $service.service"
                fi
            else
                echo " - $service.service already disabled"
            fi
        fi
    done
    
    # Disable any other DNS related services
    systemctl list-unit-files | grep -E "(named|bind|dnsmasq|unbound|dns)" | awk '{print $1}' | while read -r service; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            systemctl disable "$service" 2>/dev/null && echo " - $service disabled" || true
        fi
    done
    
    return 0
}

# Function to cleanup_dns_configs
cleanup_dns_configs() {
    echo "Cleaning up DNS server configuration files..."
    
    # List of DNS configuration files to remove or disable
    config_files=(
        "/etc/named"
        "/etc/named.conf"
        "/etc/bind"
        "/etc/bind/named.conf"
        "/etc/dnsmasq.conf"
        "/etc/dnsmasq.d"
        "/etc/unbound"
        "/etc/unbound/unbound.conf"
        "/etc/powerdns"
        "/etc/maradns"
        "/var/named"
        "/var/bind"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -e "$config_file" ]; then
            if [ -f "$config_file" ]; then
                # Create backup and disable
                backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp "$config_file" "$backup_file"
                echo " - Backed up $config_file to $backup_file"
                
                # Comment out all active configurations
                if [[ "$config_file" == *.conf ]]; then
                    sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$config_file" 2>/dev/null || true
                    echo " - Disabled configurations in $config_file"
                fi
            elif [ -d "$config_file" ]; then
                # For directories, backup and disable contents
                backup_dir="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp -r "$config_file" "$backup_dir" 2>/dev/null || true
                echo " - Backed up $config_file to $backup_dir"
                
                # Disable all configuration files in directory
                find "$config_file" -type f -name "*.conf" -exec sh -c 'echo "# REMEDIATED: $(cat {})" > {}' \; 2>/dev/null || true
                find "$config_file" -type f -name "*.zone" -exec sh -c 'echo "; REMEDIATED: $(cat {})" > {}' \; 2>/dev/null || true
                echo " - Disabled configuration files in $config_file"
            fi
        fi
    done
    
    # Remove DNS server from resolver configuration if it points to localhost
    if [ -f "/etc/resolv.conf" ]; then
        if grep -q "nameserver 127.0.0.1" /etc/resolv.conf || grep -q "nameserver ::1" /etc/resolv.conf; then
            cp /etc/resolv.conf "/etc/resolv.conf.backup.$(date +%Y%m%d_%H%M%S)"
            echo " - Backed up /etc/resolv.conf"
            # Comment out localhost nameservers
            sed -i 's/^nameserver 127.0.0.1/# REMEDIATED: nameserver 127.0.0.1/' /etc/resolv.conf 2>/dev/null || true
            sed -i 's/^nameserver ::1/# REMEDIATED: nameserver ::1/' /etc/resolv.conf 2>/dev/null || true
            echo " - Disabled localhost DNS servers in /etc/resolv.conf"
        fi
    fi
    
    # Remove DNS server from NetworkManager configurations
    if [ -f "/etc/NetworkManager/NetworkManager.conf" ]; then
        if grep -q "dns" /etc/NetworkManager/NetworkManager.conf; then
            cp /etc/NetworkManager/NetworkManager.conf "/etc/NetworkManager/NetworkManager.conf.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i 's/^dns=/# REMEDIATED: dns=/' /etc/NetworkManager/NetworkManager.conf 2>/dev/null || true
            echo " - Disabled DNS configuration in NetworkManager"
        fi
    fi
    
    # Remove any DNS related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -E "(named|bind|dnsmasq|unbound|dns)" "$cron_file" 2>/dev/null; then
                sed -i '/named\|bind\|dnsmasq\|unbound\|dns/d' "$cron_file" 2>/dev/null || true
                echo " - Removed DNS references from $cron_file"
            fi
        done
    fi
    
    return 0
}

# Function to block_dns_ports
block_dns_ports() {
    echo "Blocking DNS server network ports..."
    
    # DNS uses TCP/UDP port 53
    if command -v firewall-cmd >/dev/null 2>&1; then
        # firewalld
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld to block DNS server ports..."
            firewall-cmd --permanent --remove-service=dns 2>/dev/null || true
            firewall-cmd --permanent --remove-port=53/tcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=53/udp 2>/dev/null || true
            firewall-cmd --reload 2>/dev/null || true
            echo " - firewalld configured to block DNS server ports"
        fi
    fi
    
    # Additional iptables rules for non-firewalld systems
    if command -v iptables >/dev/null 2>&1; then
        echo " - Adding iptables rules to block DNS server..."
        # Block DNS server ports (53/tcp and 53/udp)
        iptables -I INPUT -p tcp --dport 53 -j DROP 2>/dev/null || true
        iptables -I INPUT -p udp --dport 53 -j DROP 2>/dev/null || true
        echo " - iptables rules added (if supported)"
    fi
    
    return 0
}

# Function to verify_dns_removal
verify_dns_removal() {
    echo "Verifying DNS server remediation..."
    
    verification_passed=true
    
    # Check if DNS packages are installed
    dns_packages=("bind" "bind9" "dnsmasq" "unbound")
    for pkg in "${dns_packages[@]}"; do
        if command -v rpm >/dev/null 2>&1; then
            if rpm -q "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        elif command -v dpkg >/dev/null 2>&1; then
            if dpkg -l "$pkg" >/dev/null 2>&1; then
                echo "FAIL: $pkg package is still installed"
                verification_passed=false
            fi
        fi
    done
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: DNS server packages are not installed"
    fi
    
    # Check if DNS services are running
    dns_services=("named" "bind9" "dnsmasq" "unbound")
    for service in "${dns_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service" && systemctl is-active "$service" >/dev/null 2>&1; then
            echo "FAIL: $service.service is running"
            verification_passed=false
        else
            echo "PASS: $service.service is not running"
        fi
    done
    
    # Check if DNS services are enabled or masked
    for service in "${dns_services[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            if systemctl is-enabled "$service" >/dev/null 2>&1; then
                if systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
                    echo "PASS: $service.service is masked"
                else
                    echo "FAIL: $service.service is enabled"
                    verification_passed=false
                fi
            else
                echo "PASS: $service.service is not enabled"
            fi
        fi
    done
    
    # Check for DNS processes
    running_processes=0
    for process in named dnsmasq unbound pdns_server maradns; do
        if pgrep "$process" >/dev/null 2>&1; then
            running_processes=$((running_processes + 1))
            echo "FAIL: $process process is running"
            verification_passed=false
        fi
    done
    
    if [ "$running_processes" -eq 0 ]; then
        echo "PASS: No DNS server processes running"
    fi
    
    # Check for DNS server network services
    if ss -tulpn 2>/dev/null | grep ':53 '; then
        echo "WARNING: DNS server port (53) may still be in use"
        ss -tulpn 2>/dev/null | grep ':53 ' | while read -r line; do
            if echo "$line" | grep -q 'named\|bind\|dnsmasq\|unbound'; then
                echo "   - DNS server process using port 53"
                verification_passed=false
            else
                echo "   - Other service using port 53 (may be DNS client)"
            fi
        done
    else
        echo "PASS: No DNS server network services detected"
    fi
    
    # Check if localhost is still configured as DNS resolver
    if grep -q "nameserver 127.0.0.1" /etc/resolv.conf 2>/dev/null || \
       grep -q "nameserver ::1" /etc/resolv.conf 2>/dev/null; then
        echo "WARNING: Localhost still configured as DNS resolver in /etc/resolv.conf"
        # This might be acceptable if other DNS servers are also configured
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current DNS server status..."
    echo ""

    # Check current DNS server status
    check_dns_server_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable DNS servers
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING DNS SERVER SERVICES"
    echo "==================================================================="
    echo ""

    # Stop DNS services first
    if ! stop_dns_services; then
        echo " - WARNING: Some issues stopping DNS server services"
    fi
    echo ""

    # Try to remove DNS packages
    if remove_dns_packages "$pkg_mgr"; then
        echo " - Package removal attempted"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking services instead"
        removal_method="masked"
    fi
    echo ""

    # Mask and disable services (especially if package removal failed)
    if [ "$removal_method" = "masked" ]; then
        if mask_dns_services; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        if disable_dns_services; then
            echo " - Service disabling successful"
        fi
    fi
    echo ""

    # Cleanup configuration files
    cleanup_dns_configs
    echo ""

    # Block network ports
    block_dns_ports
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_dns_removal; then
        echo ""
        echo "SUCCESS: DNS server services have been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ DNS server packages removed"
        else
            echo "✓ DNS server services masked and disabled"
        fi
        echo "✓ DNS server services stopped"
        echo "✓ DNS server processes terminated"
        echo "✓ Configuration files disabled"
        echo "✓ Network ports blocked"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: DNS server remediation may not be complete"
        echo "Some DNS server components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining DNS processes: ps aux | grep -E '(named|dnsmasq|unbound)'"
        echo "2. Verify DNS services are masked: systemctl list-unit-files | grep -E '(named|bind|dnsmasq|unbound)'"
        echo "3. Manually remove DNS packages if needed"
        echo "4. Check network ports: ss -tulpn | grep ':53'"
        echo "5. Verify no DNS configuration files remain in /etc/named*, /etc/bind*, /etc/dnsmasq*"
        echo "6. Update /etc/resolv.conf to use external DNS servers if needed"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Packages installed: $(if command -v rpm >/dev/null && (rpm -q bind >/dev/null 2>&1 || rpm -q dnsmasq >/dev/null 2>&1); then echo "YES"; elif command -v dpkg >/dev/null && (dpkg -l bind9 >/dev/null 2>&1 || dpkg -l dnsmasq >/dev/null 2>&1); then echo "YES"; else echo "NO"; fi)"
    echo "Services running: $(systemctl is-active named 2>/dev/null || systemctl is-active bind9 2>/dev/null || echo "NO")"
    echo "Services enabled: $(systemctl is-enabled named 2>/dev/null || systemctl is-enabled bind9 2>/dev/null || echo "NO")"
    echo "Processes running: $( (pgrep named 2>/dev/null | wc -l; pgrep dnsmasq 2>/dev/null | wc -l; pgrep unbound 2>/dev/null | wc -l) | awk '{sum+=$1} END {print sum}')"
    echo "Network port 53: $(ss -tulpn 2>/dev/null | grep -c ':53 ' || echo "0")"
    echo "Localhost DNS: $(grep -c "nameserver 127.0.0.1" /etc/resolv.conf 2>/dev/null || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="