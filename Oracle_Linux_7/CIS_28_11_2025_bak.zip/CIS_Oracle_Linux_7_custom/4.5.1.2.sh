#!/bin/bash
set -euo pipefail

LOGIN_DEFS="/etc/login.defs"
SHADOW_FILE="/etc/shadow"
REQUIRED_MAX_DAYS=365

[ "$EUID" -eq 0 ] || exit 1

# Fix login.defs
echo "Fixing /etc/login.defs:"
sed -i 's/^PASS_MAX_DAYS\s\+[0-9]\+/PASS_MAX_DAYS '"$REQUIRED_MAX_DAYS"'/' "$LOGIN_DEFS"
grep "PASS_MAX_DAYS" "$LOGIN_DEFS"

# Fix shadow entries for users with passwords
echo "---"
echo "Fixing user password max days:"
awk -F: '$2 !~ /^[!*]/ && $5 > '"$REQUIRED_MAX_DAYS"' {print "chage --maxdays '"$REQUIRED_MAX_DAYS"' " $1}' "$SHADOW_FILE" | sh

# Show proof
echo "---"
echo "Verification - /etc/login.defs:"
grep "PASS_MAX_DAYS" "$LOGIN_DEFS"

echo "---"
echo "Verification - users with max days > $REQUIRED_MAX_DAYS:"
awk -F: '$2 !~ /^[!*]/ && $5 > '"$REQUIRED_MAX_DAYS"' {print "FAIL: " $1 " = " $5}' "$SHADOW_FILE"