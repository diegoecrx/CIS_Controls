#!/usr/bin/env bash
# Script: 5.1.1.4.sh
# Item: 5.1.1.4 Ensure rsyslog default file permissions are configured (Automated)
set -euo pipefail
SCRIPT_NAME="5.1.1.4.sh"
ITEM_NAME="5.1.1.4 Ensure rsyslog default file permissions are configured (Automated)"
DESCRIPTION="This remediation ensures rsyslog default file permissions are configured to 0640 or more restrictive."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking rsyslog default file permissions configuration..."
    
    # Check if rsyslog package is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo "FAIL: rsyslog package is not installed"
        echo "PROOF: rpm -q rsyslog returned no package found"
        return 1
    fi
    
    # Check for FileCreateMode in rsyslog.conf
    if grep -q '^\$FileCreateMode' /etc/rsyslog.conf 2>/dev/null; then
        file_mode=$(grep '^\$FileCreateMode' /etc/rsyslog.conf | awk '{print $2}')
        # Convert octal to decimal for comparison
        if [ -n "$file_mode" ]; then
            # Remove leading 0 if present and convert to decimal
            decimal_mode=$(echo "$file_mode" | sed 's/^0*//' | xargs -I {} printf "%d" "0{}")
            # 0640 in decimal is 416, check if mode is 416 or more restrictive (lower number)
            if [ "$decimal_mode" -le 416 ]; then
                echo "PASS: rsyslog FileCreateMode properly configured"
                echo "PROOF: \$FileCreateMode $file_mode found in /etc/rsyslog.conf"
                return 0
            else
                echo "FAIL: rsyslog FileCreateMode is too permissive"
                echo "PROOF: \$FileCreateMode $file_mode is more permissive than 0640"
                return 1
            fi
        fi
    fi
    
    # Check for FileCreateMode in rsyslog.d directory
    if [ -d /etc/rsyslog.d ]; then
        for conf_file in /etc/rsyslog.d/*.conf; do
            if [ -f "$conf_file" ] && grep -q '^\$FileCreateMode' "$conf_file" 2>/dev/null; then
                file_mode=$(grep '^\$FileCreateMode' "$conf_file" | awk '{print $2}')
                if [ -n "$file_mode" ]; then
                    decimal_mode=$(echo "$file_mode" | sed 's/^0*//' | xargs -I {} printf "%d" "0{}")
                    if [ "$decimal_mode" -le 416 ]; then
                        echo "PASS: rsyslog FileCreateMode properly configured"
                        echo "PROOF: \$FileCreateMode $file_mode found in $conf_file"
                        return 0
                    else
                        echo "FAIL: rsyslog FileCreateMode is too permissive"
                        echo "PROOF: \$FileCreateMode $file_mode in $conf_file is more permissive than 0640"
                        return 1
                    fi
                fi
            fi
        done
    fi
    
    echo "FAIL: rsyslog FileCreateMode not configured"
    echo "PROOF: No \$FileCreateMode directive found in rsyslog configuration"
    return 1
}
# Function to fix
fix_rsyslog_file_permissions() {
    echo "Applying fix..."
    
    # Check if rsyslog package is installed
    if ! rpm -q rsyslog >/dev/null 2>&1; then
        echo " - Installing rsyslog package"
        yum install -y rsyslog
    fi
    
    # Check if FileCreateMode is already configured in any file
    file_mode_configured=false
    
    # Check rsyslog.conf
    if grep -q '^\$FileCreateMode' /etc/rsyslog.conf 2>/dev/null; then
        current_mode=$(grep '^\$FileCreateMode' /etc/rsyslog.conf | awk '{print $2}')
        decimal_mode=$(echo "$current_mode" | sed 's/^0*//' | xargs -I {} printf "%d" "0$current_mode")
        if [ "$decimal_mode" -gt 416 ]; then
            echo " - Updating existing FileCreateMode in /etc/rsyslog.conf"
            sed -i 's/^\$FileCreateMode.*/$FileCreateMode 0640/' /etc/rsyslog.conf
        fi
        file_mode_configured=true
    fi
    
    # Check rsyslog.d directory
    if [ -d /etc/rsyslog.d ]; then
        for conf_file in /etc/rsyslog.d/*.conf; do
            if [ -f "$conf_file" ] && grep -q '^\$FileCreateMode' "$conf_file" 2>/dev/null; then
                current_mode=$(grep '^\$FileCreateMode' "$conf_file" | awk '{print $2}')
                decimal_mode=$(echo "$current_mode" | sed 's/^0*//' | xargs -I {} printf "%d" "0$current_mode")
                if [ "$decimal_mode" -gt 416 ]; then
                    echo " - Updating existing FileCreateMode in $conf_file"
                    sed -i 's/^\$FileCreateMode.*/$FileCreateMode 0640/' "$conf_file"
                fi
                file_mode_configured=true
            fi
        done
    fi
    
    # If no FileCreateMode is configured, add it to rsyslog.conf
    if [ "$file_mode_configured" = false ]; then
        echo " - Adding FileCreateMode directive to /etc/rsyslog.conf"
        
        # Add FileCreateMode after the first comment block
        if grep -q '^#' /etc/rsyslog.conf; then
            # Find the line after the last comment at the top
            last_comment_line=$(grep -n '^#' /etc/rsyslog.conf | tail -1 | cut -d: -f1)
            sed -i "${last_comment_line}a\\n# Set default file permissions for log files\n\$FileCreateMode 0640" /etc/rsyslog.conf
        else
            # If no comments, add at the beginning
            sed -i '1i# Set default file permissions for log files\n$FileCreateMode 0640\n' /etc/rsyslog.conf
        fi
    fi
    
    # Restart rsyslog service to apply changes
    echo " - Restarting rsyslog service"
    systemctl restart rsyslog
    
    echo " - rsyslog file permissions configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_rsyslog_file_permissions
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: rsyslog default file permissions properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="