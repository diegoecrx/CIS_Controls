#!/usr/bin/env bash
# Script: 3.3.9.sh
# Item: 3.3.9 Ensure suspicious packets are logged (Automated)
set -euo pipefail
SCRIPT_NAME="3.3.9.sh"
ITEM_NAME="3.3.9 Ensure suspicious packets are logged (Automated)"
DESCRIPTION="This remediation ensures suspicious packets are logged for IPv4."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking suspicious packet logging configuration..."
    
    verification_passed=true
    
    # Check current running values
    all_log_martians=$(sysctl net.ipv4.conf.all.log_martians 2>/dev/null | awk '{print $3}')
    default_log_martians=$(sysctl net.ipv4.conf.default.log_martians 2>/dev/null | awk '{print $3}')
    
    if [ "$all_log_martians" != "1" ]; then
        echo "FAIL: net.ipv4.conf.all.log_martians is not enabled (runtime)"
        echo "PROOF: net.ipv4.conf.all.log_martians = $all_log_martians"
        verification_passed=false
    else
        echo "PASS: net.ipv4.conf.all.log_martians enabled (runtime)"
    fi
    
    if [ "$default_log_martians" != "1" ]; then
        echo "FAIL: net.ipv4.conf.default.log_martians is not enabled (runtime)"
        echo "PROOF: net.ipv4.conf.default.log_martians = $default_log_martians"
        verification_passed=false
    else
        echo "PASS: net.ipv4.conf.default.log_martians enabled (runtime)"
    fi
    
    # Check configuration files for conflicting settings
    all_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "1" ]; then
            echo "FAIL: net.ipv4.conf.all.log_martians disabled in configuration: $line"
            all_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.conf\.all\.log_martians' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$all_config_issues" = false ]; then
        echo "PASS: net.ipv4.conf.all.log_martians properly configured in files"
    fi
    
    default_config_issues=false
    while IFS= read -r line; do
        # Extract the value after the equals sign
        value=$(echo "$line" | sed -n 's/.*=\s*\([^[:space:]]*\).*/\1/p')
        if [ "$value" != "1" ]; then
            echo "FAIL: net.ipv4.conf.default.log_martians disabled in configuration: $line"
            default_config_issues=true
            verification_passed=false
        fi
    done < <(grep -r '^\s*net\.ipv4\.conf\.default\.log_martians' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || true)
    
    if [ "$default_config_issues" = false ]; then
        echo "PASS: net.ipv4.conf.default.log_martians properly configured in files"
    fi
    
    if [ "$verification_passed" = true ]; then
        echo "PASS: Suspicious packet logging properly enabled"
        echo "PROOF: Both all and default log_martians set to 1"
        return 0
    else
        return 1
    fi
}
# Function to fix
fix_suspicious_packet_logging() {
    echo "Applying fix..."
    
    # Remove any existing conflicting entries from all configuration files
    for config_file in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
        if [ -f "$config_file" ]; then
            # Remove log_martians entries (both =0 and =1)
            sed -i '/^\s*net\.ipv4\.conf\.all\.log_martians\s*=/d' "$config_file" 2>/dev/null || true
            sed -i '/^\s*net\.ipv4\.conf\.default\.log_martians\s*=/d' "$config_file" 2>/dev/null || true
        fi
    done
    
    # Create dedicated configuration file
    CONFIG_FILE="/etc/sysctl.d/60-netipv4_sysctl.conf"
    # Add suspicious packet logging configuration
    echo " - Configuring suspicious packet logging"
    echo "# Suspicious packet logging enable - Remediated by $SCRIPT_NAME" > "$CONFIG_FILE"
    echo "# $(date)" >> "$CONFIG_FILE"
    echo "net.ipv4.conf.all.log_martians = 1" >> "$CONFIG_FILE"
    echo "net.ipv4.conf.default.log_martians = 1" >> "$CONFIG_FILE"
    
    # Set active kernel parameters
    sysctl -w net.ipv4.conf.all.log_martians=1 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.log_martians=1 >/dev/null 2>&1
    sysctl -w net.ipv4.route.flush=1 >/dev/null 2>&1
    
    # Reload all sysctl configurations
    sysctl -p >/dev/null 2>&1 || true
    if ls /etc/sysctl.d/*.conf >/dev/null 2>&1; then
        sysctl -p /etc/sysctl.d/*.conf >/dev/null 2>&1 || true
    fi
    
    echo " - Suspicious packet logging configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_suspicious_packet_logging
        # Allow time for changes to take effect
        sleep 2
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Suspicious packet logging properly enabled"
    else
        echo "FAIL: Issues remain"
        echo ""
        echo "Debug information:"
        echo "Runtime all.log_martians: $(sysctl net.ipv4.conf.all.log_martians 2>/dev/null || echo 'not set')"
        echo "Runtime default.log_martians: $(sysctl net.ipv4.conf.default.log_martians 2>/dev/null || echo 'not set')"
        echo ""
        echo "Configuration files:"
        grep -r 'net.ipv4.conf.all.log_martians' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No all.log_martians configurations found"
        grep -r 'net.ipv4.conf.default.log_martians' /etc/sysctl.conf /etc/sysctl.d/*.conf 2>/dev/null || echo "No default.log_martians configurations found"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="