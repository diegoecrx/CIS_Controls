#!/bin/bash

# Enforce CIS 5.2.3.20 - Ensure the audit configuration is immutable
echo "Enforcing CIS 5.2.3.20 - Configure audit configuration as immutable..."

# Create audit rules directory if it doesn't exist
if [ ! -d /etc/audit/rules.d ]; then
    mkdir -p /etc/audit/rules.d
    echo "Created /etc/audit/rules.d directory"
fi

# Configure audit configuration as immutable
echo "Creating immutable audit configuration..."

# Create or update the finalize rules file
RULES_FILE="/etc/audit/rules.d/99-finalize.rules"

# Backup existing file if it exists
if [ -f "$RULES_FILE" ]; then
    cp "$RULES_FILE" "$RULES_FILE.bak"
    echo "Backed up $RULES_FILE to $RULES_FILE.bak"
fi

# Remove existing -e 2 line to avoid duplicates
sed -i '/^-e 2/d' "$RULES_FILE" 2>/dev/null

# Add the immutable configuration line
echo "-e 2" > "$RULES_FILE"
echo "Added immutable configuration (-e 2) to $RULES_FILE"

# Set proper permissions on the rules file
chmod 640 "$RULES_FILE"
chown root:root "$RULES_FILE"

# Load the audit rules
echo "Loading audit rules..."
if command -v augenrules >/dev/null 2>&1; then
    augenrules --load
    echo "Loaded audit rules using augenrules"
else
    echo "WARNING: augenrules command not found"
fi

# Restart auditd service to apply rules
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "Restarting auditd service..."
    systemctl restart auditd
fi

# Verify configuration
echo "Verifying immutable audit configuration..."

# Check if -e 2 is in the rules file
if grep -q "^-e 2" "$RULES_FILE"; then
    echo "SUCCESS: Immutable configuration (-e 2) configured in $RULES_FILE"
else
    echo "ERROR: Immutable configuration not found in $RULES_FILE"
    exit 1
fi

# Check if -e 2 is the last line in the file (as it should be)
LAST_LINE=$(tail -1 "$RULES_FILE")
if [ "$LAST_LINE" = "-e 2" ]; then
    echo "SUCCESS: -e 2 is the last line in the rules file"
else
    echo "ERROR: -e 2 is not the last line in the rules file"
    exit 1
fi

# Check if rules are loaded in active configuration (if auditctl is available and we're root)
if command -v auditctl >/dev/null 2>&1 && [ "$EUID" -eq 0 ]; then
    if auditctl -l | grep -q "^-e 2"; then
        echo "SUCCESS: Immutable configuration loaded in active configuration"
    else
        echo "WARNING: Immutable configuration not loaded in active configuration"
    fi
else
    echo "INFO: Skipping active configuration check (auditctl not available or not root)"
fi

# Check if auditd service is running
if systemctl is-active auditd >/dev/null 2>&1; then
    echo "SUCCESS: auditd service is running"
else
    echo "WARNING: auditd service is not running"
fi

# Check if reboot is required
if command -v auditctl >/dev/null 2>&1 && [ "$EUID" -eq 0 ]; then
    AUDIT_STATUS=$(auditctl -s | grep "enabled")
    if [[ "$AUDIT_STATUS" =~ "2" ]]; then
        echo "WARNING: Reboot required to load audit rules"
    else
        echo "SUCCESS: Audit rules should be active without reboot"
    fi
fi

echo "CIS 5.2.3.20 remediation completed successfully"
echo "Audit configuration is now immutable - no changes can be made to audit rules while system is running"
echo "WARNING: To modify audit rules, you must reboot the system into single user mode"