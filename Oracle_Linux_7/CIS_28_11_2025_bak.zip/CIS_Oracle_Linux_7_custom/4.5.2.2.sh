#!/bin/bash

# Enforce CIS 4.5.2.2 - Ensure root user umask is configured
echo "Enforcing CIS 4.5.2.2 - Root user umask configuration..."

# Backup system files before any changes
backup_timestamp=$(date +%Y%m%d_%H%M%S)
echo "Creating backups with timestamp: $backup_timestamp"

# Backup system-wide files that might be affected
for sysfile in /etc/bashrc /etc/profile; do
    if [ -f "$sysfile" ]; then
        cp "$sysfile" "${sysfile}.backup_${backup_timestamp}"
        echo "Backed up $sysfile to ${sysfile}.backup_${backup_timestamp}"
    fi
done

# Configure umask in root's shell configuration files ONLY
for file in .bash_profile .bashrc; do
    file_path="/root/${file}"
    echo "Configuring umask in ${file_path}..."
    
    # Create file if it doesn't exist
    if [ ! -f "$file_path" ]; then
        touch "$file_path"
        chmod 600 "$file_path"
        chown root:root "$file_path"
        echo "Created ${file_path}"
    fi
    
    # Remove existing umask settings
    sed -i '/^[[:space:]]*umask[[:space:]]/d' "$file_path"
    
    # Add secure umask setting at the end
    echo "# CIS 4.5.2.2 - Root user umask configuration" >> "$file_path"
    echo "umask 0027" >> "$file_path"
    echo "Added umask 0027 to ${file_path}"
done

# FIX: Ensure system-wide files are not broken
# Check and fix /etc/bashrc if it has the commented umask issue
if [ -f "/etc/bashrc" ]; then
    echo "Checking /etc/bashrc for syntax issues..."
    
    # Fix the specific issue with commented umask lines in if-else blocks
    if grep -q "#  # Fixed by 4.5.3.3.sh -        umask" /etc/bashrc; then
        echo "Fixing broken if-else structure in /etc/bashrc..."
        
        # Use a more precise sed command to fix the issue
        sed -i '
            /if \[ \$UID -gt 199 \] && \[ "\`\/usr\/bin\/id -gn\`" = "\`\/usr\/bin\/id -un\`" \]; then/,/fi/ {
                s/^#  # Fixed by 4\.5\.3\.3\.sh -        umask 002$/        umask 002/
                s/^#  # Fixed by 4\.5\.3\.3\.sh -        umask 022$/        umask 022/
            }
        ' /etc/bashrc
        
        echo "Fixed umask commands in /etc/bashrc"
    fi
fi

# VERIFICATION SECTION - IMPROVED
echo "=== VERIFICATION PHASE ==="

# Check umask settings in both files with better validation
for file in .bash_profile .bashrc; do
    file_path="/root/${file}"
    echo "Verifying ${file_path}..."
    
    if [ ! -f "$file_path" ]; then
        echo "ERROR: ${file_path} does not exist"
        exit 1
    fi
    
    # Show file contents for debugging
    echo "Contents of ${file_path}:"
    cat "$file_path"
    echo "---"
    
    # Check if umask 0027 exists in the file (case insensitive, allows whitespace)
    if grep -E -i "^[[:space:]]*umask[[:space:]]+0027" "$file_path" > /dev/null; then
        echo "✓ SUCCESS: umask 0027 found in ${file_path}"
    else
        echo "✗ ERROR: umask 0027 NOT found in ${file_path}"
        echo "Searching for any umask settings:"
        grep -i "umask" "$file_path" || echo "No umask settings found"
        exit 1
    fi
    
    # Verify file permissions and ownership
    PERMS=$(stat -c %a "$file_path" 2>/dev/null)
    OWNER=$(stat -c %U:%G "$file_path" 2>/dev/null)
    
    if [ "$PERMS" = "600" ]; then
        echo "✓ SUCCESS: ${file_path} has correct permissions (600)"
    else
        echo "✗ ERROR: ${file_path} has incorrect permissions ($PERMS), expected 600"
        chmod 600 "$file_path"
    fi
    
    if [ "$OWNER" = "root:root" ]; then
        echo "✓ SUCCESS: ${file_path} has correct ownership (root:root)"
    else
        echo "✗ ERROR: ${file_path} has incorrect ownership ($OWNER), expected root:root"
        chown root:root "$file_path"
    fi
done

# Test the actual umask setting by sourcing the files
echo "Testing umask setting in current shell..."
# Create a temporary test script to verify the umask takes effect
TEST_SCRIPT="/tmp/test_umask_$$.sh"
cat > "$TEST_SCRIPT" << 'EOF'
#!/bin/bash
source /root/.bash_profile 2>/dev/null
source /root/.bashrc 2>/dev/null
echo "Current umask after sourcing configs: $(umask)"
EOF

chmod +x "$TEST_SCRIPT"
CURRENT_UMASK=$(bash "$TEST_SCRIPT" | grep "Current umask" | awk '{print $NF}')
rm -f "$TEST_SCRIPT"

if [ "$CURRENT_UMASK" = "0027" ]; then
    echo "✓ SUCCESS: Effective umask is 0027"
else
    echo "✗ WARNING: Effective umask is $CURRENT_UMASK (expected 0027)"
    echo "This might be due to other shell configuration files overriding the setting"
fi

# Verify system files are syntactically correct
echo "Verifying system file syntax..."
for sysfile in /etc/bashrc /etc/profile; do
    if [ -f "$sysfile" ]; then
        if bash -n "$sysfile" 2>/dev/null; then
            echo "✓ SUCCESS: $sysfile has valid syntax"
        else
            echo "✗ ERROR: $sysfile has syntax errors - restoring from backup"
            if [ -f "${sysfile}.backup_${backup_timestamp}" ]; then
                cp "${sysfile}.backup_${backup_timestamp}" "$sysfile"
                echo "Restored $sysfile from backup"
            else
                echo "No backup found for $sysfile"
            fi
            exit 1
        fi
    fi
done

echo ""
echo "=== FINAL RESULTS ==="
echo "CIS 4.5.2.2 remediation completed"
echo "Root user umask is set to 0027 in both .bash_profile and .bashrc"
echo "All system files verified and syntax checked"
echo "Backups created with timestamp: $backup_timestamp"