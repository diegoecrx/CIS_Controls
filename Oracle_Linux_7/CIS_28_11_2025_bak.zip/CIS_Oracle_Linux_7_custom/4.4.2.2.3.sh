#!/bin/bash

# Enforce CIS 4.4.2.2.3 - Ensure password length is configured
echo "Enforcing CIS 4.4.2.2.3 - Password length configuration..."

# Configure minlen in pwquality.conf
echo "Configuring minlen in /etc/security/pwquality.conf..."

# Backup original file
if [ ! -f /etc/security/pwquality.conf.bak ]; then
    cp /etc/security/pwquality.conf /etc/security/pwquality.conf.bak
    echo "Backed up /etc/security/pwquality.conf to /etc/security/pwquality.conf.bak"
fi

# Remove existing minlen setting and add new one
sed -ri 's/^(\s*)minlen\s*=.*/# &/' /etc/security/pwquality.conf
echo "minlen = 14" >> /etc/security/pwquality.conf

# Remove minlen parameter from pam_pwquality.so lines in PAM files
echo "Removing minlen parameter from PAM files..."
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        # Backup PAM file
        if [ ! -f "/etc/pam.d/${pam_file}.bak" ]; then
            cp "/etc/pam.d/${pam_file}" "/etc/pam.d/${pam_file}.bak"
        fi
        
        # Remove minlen parameter from pam_pwquality.so lines
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+minlen\s*=\s*[0-9]+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        echo "Cleaned minlen parameter from /etc/pam.d/${pam_file}"
    fi
done

# Verify configuration
echo "Verifying password length configuration..."

# Check minlen setting in pwquality.conf
if grep -q "^minlen\s*=\s*14" /etc/security/pwquality.conf; then
    echo "SUCCESS: minlen = 14 configured in /etc/security/pwquality.conf"
else
    echo "ERROR: minlen not properly configured in /etc/security/pwquality.conf"
    exit 1
fi

# Verify minlen parameter is not in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if ! grep -q "pam_pwquality\.so.*minlen" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: minlen parameter removed from /etc/pam.d/${pam_file}"
        else
            echo "ERROR: minlen parameter still present in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Verify pam_pwquality is still properly configured in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if grep -q "^password.*requisite.*pam_pwquality\.so.*try_first_pass.*local_users_only" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: pam_pwquality properly configured in /etc/pam.d/${pam_file}"
        else
            echo "ERROR: pam_pwquality configuration broken in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/security/pwquality.conf ] && [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: Configuration files are readable and properly configured"
    else
        echo "ERROR: Configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.2.3 remediation completed successfully"
echo "Password policy requires minimum length of 14 characters"