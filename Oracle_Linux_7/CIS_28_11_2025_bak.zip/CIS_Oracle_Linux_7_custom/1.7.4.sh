#!/usr/bin/env bash
# Script: 1.7.4.sh
# Item: 1.7.4 Ensure GDM screen locks when the user is idle (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.4.sh"
ITEM_NAME="1.7.4 Ensure GDM screen locks when the user is idle (Automated)"
DESCRIPTION="This remediation ensures GDM screen locks when the user is idle or GDM is removed."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking GDM screen lock configuration..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    l_dconf_db="local"
    l_profile_file="/etc/dconf/profile/user"
    l_key_file="/etc/dconf/db/$l_dconf_db.d/00-screensaver"
    
    # Check if user profile exists and contains required entries
    if [ ! -f "$l_profile_file" ]; then
        echo "FAIL: dconf user profile not configured"
        echo "PROOF: $l_profile_file does not exist"
        return 1
    fi
    
    if ! grep -q "user-db:user" "$l_profile_file" || ! grep -q "system-db:$l_dconf_db" "$l_profile_file"; then
        echo "FAIL: dconf user profile incomplete"
        echo "PROOF: Missing required entries in $l_profile_file"
        return 1
    fi
    
    # Check if screensaver key file exists
    if [ ! -f "$l_key_file" ]; then
        echo "FAIL: Screensaver configuration not found"
        echo "PROOF: $l_key_file does not exist"
        return 1
    fi
    
    # Check for idle-delay setting
    if ! grep -Pq '^\s*idle-delay\s*=\s*uint32\s+[1-9][0-9]*' "$l_key_file"; then
        echo "FAIL: idle-delay not properly configured"
        echo "PROOF: idle-delay setting not found or invalid in $l_key_file"
        return 1
    fi
    
    # Check for lock-delay setting
    if ! grep -Pq '^\s*lock-delay\s*=\s*uint32\s+[0-5]' "$l_key_file"; then
        echo "FAIL: lock-delay not properly configured"
        echo "PROOF: lock-delay setting not found or invalid in $l_key_file"
        return 1
    fi
    
    echo "PASS: GDM screen lock configured properly"
    echo "PROOF: Profile and screensaver settings found and valid"
    return 0
}
# Function to fix
fix_gdm_screen_lock() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    l_dconf_db="local"
    l_profile_file="/etc/dconf/profile/user"
    l_key_file="/etc/dconf/db/$l_dconf_db.d/00-screensaver"
    l_idmv="900"  # Set max value for idle-delay in seconds (between 1 and 900)
    l_ldmv="5"    # Set max value for lock-delay in seconds (between 0 and 5)
    
    # Create or update user profile
    if [ ! -f "$l_profile_file" ] || ! grep -q "user-db:user" "$l_profile_file" || ! grep -q "system-db:$l_dconf_db" "$l_profile_file"; then
        echo " - Creating/updating dconf user profile"
        echo -e "user-db:user\nsystem-db:$l_dconf_db" > "$l_profile_file"
    fi
    
    # Create dconf database directory
    if [ ! -d "/etc/dconf/db/$l_dconf_db.d/" ]; then
        echo " - Creating dconf database directory"
        mkdir -p "/etc/dconf/db/$l_dconf_db.d/"
    fi
    
    # Create screensaver key file
    echo " - Creating screensaver configuration"
    {
        echo '# Specify the dconf path'
        echo '[org/gnome/desktop/session]'
        echo ''
        echo '# Number of seconds of inactivity before the screen goes blank'
        echo '# Set to 0 seconds if you want to deactivate the screensaver.'
        echo "idle-delay=uint32 $l_idmv"
        echo ''
        echo '# Specify the dconf path'
        echo '[org/gnome/desktop/screensaver]'
        echo ''
        echo '# Number of seconds after the screen is blank before locking the screen'
        echo "lock-delay=uint32 $l_ldmv"
    } > "$l_key_file"
    
    # Update dconf
    dconf update 2>/dev/null || true
    echo " - Updated dconf database"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm_screen_lock
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GDM screen lock configured properly"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="