#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

chown root:root /etc/cron.hourly
chmod 700 /etc/cron.hourly

ls -ld /etc/cron.hourly
stat -c "%U %G %a" /etc/cron.hourly

if [[ $(stat -c "%U" /etc/cron.hourly) == "root" && \
      $(stat -c "%G" /etc/cron.hourly) == "root" && \
      $(stat -c "%a" /etc/cron.hourly) == "700" ]]; then
    echo "pass"
else
    echo "FAIL: /etc/cron.hourly permissions configuration failed"
    exit 1
fi