#!/usr/bin/env bash
# Script: 5.2.1.1.sh
# Item: 5.2.1.1 Ensure audit is installed (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.1.1.sh"
ITEM_NAME="5.2.1.1 Ensure audit is installed (Automated)"
DESCRIPTION="This remediation ensures audit and audit-libs packages are installed on the system."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking audit packages installation..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo "FAIL: audit package is not installed"
        echo "PROOF: rpm -q audit returned no package found"
        return 1
    fi
    
    # Check if audit-libs package is installed
    if ! rpm -q audit-libs >/dev/null 2>&1; then
        echo "FAIL: audit-libs package is not installed"
        echo "PROOF: rpm -q audit-libs returned no package found"
        return 1
    fi
    
    echo "PASS: audit packages properly installed"
    echo "PROOF: Both audit and audit-libs packages are installed"
    return 0
}
# Function to fix
fix_audit_installation() {
    echo "Applying fix..."
    
    # Install audit package
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit
    else
        echo " - audit package already installed"
    fi
    
    # Install audit-libs package
    if ! rpm -q audit-libs >/dev/null 2>&1; then
        echo " - Installing audit-libs package"
        yum install -y audit-libs
    else
        echo " - audit-libs package already installed"
    fi
    
    echo " - audit packages installation completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_audit_installation
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: audit packages properly installed"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="