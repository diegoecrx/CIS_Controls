#!/usr/bin/env bash

# Script: 3.4.3.2.sh
# Item: 3.4.3.2 Ensure iptables are flushed with nftables (Manual)
# Description: "Run the following commands to flush iptables:
# For iptables:
# # iptables -F
# For ip6tables:
# # ip6tables -F"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="3.4.3.2.sh"
ITEM_NAME="3.4.3.2 Ensure iptables are flushed with nftables (Manual)"
DESCRIPTION="Flush iptables rules when using nftables to prevent rule conflicts"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to get rule count safely
get_iptables_rule_count() {
    local rules
    rules=$(iptables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l 2>/dev/null || echo "0")
    echo "$rules" | tr -d '[:space:]'
}

get_ip6tables_rule_count() {
    local rules
    rules=$(ip6tables -L -n 2>/dev/null | grep -v '^Chain' | grep -v '^target' | grep -v '^$' | wc -l 2>/dev/null || echo "0")
    echo "$rules" | tr -d '[:space:]'
}

# Function to get service status safely
get_service_status() {
    local service="$1"
    local status
    status=$(systemctl is-active "$service" 2>/dev/null || echo "inactive")
    echo "$status" | head -1 | tr -d '[:space:]'
}

# Function to check current status
check_current_status() {
    echo "Checking current iptables and nftables status..."
    echo ""

    # Display current firewall status
    echo "Current firewall status:"
    echo "========================"
    
    # Check if nftables is installed and active
    echo "nftables status:"
    echo "----------------"
    if command -v nft >/dev/null 2>&1; then
        echo "nftables: INSTALLED"
        nftables_status=$(get_service_status "nftables")
        echo "nftables service: ${nftables_status^^}"
        
        if systemctl is-enabled nftables >/dev/null 2>&1; then
            echo "nftables service: ENABLED at boot"
        else
            echo "nftables service: DISABLED at boot"
        fi
        
        echo ""
        echo "Current nftables rules:"
        nft list ruleset 2>/dev/null | head -10 || echo "No nftables rules or error listing rules"
    else
        echo "nftables: NOT INSTALLED"
    fi
    
    echo ""
    
    # Check iptables status and rules
    echo "iptables status:"
    echo "----------------"
    if command -v iptables >/dev/null 2>&1; then
        echo "iptables: INSTALLED"
        echo ""
        echo "Current iptables rules (IPv4):"
        iptables -L -n 2>/dev/null | head -15 || echo "No iptables rules or error listing rules"
        
        # Check if iptables has any non-default rules
        iptables_rules=$(get_iptables_rule_count)
        if [ "$iptables_rules" -gt 0 ]; then
            echo ""
            echo "WARNING: iptables has $iptables_rules active rules"
        fi
    else
        echo "iptables: NOT INSTALLED"
    fi
    
    echo ""
    
    # Check ip6tables status and rules
    echo "ip6tables status:"
    echo "-----------------"
    if command -v ip6tables >/dev/null 2>&1; then
        echo "ip6tables: INSTALLED"
        echo ""
        echo "Current ip6tables rules (IPv6):"
        ip6tables -L -n 2>/dev/null | head -15 || echo "No ip6tables rules or error listing rules"
        
        # Check if ip6tables has any non-default rules
        ip6tables_rules=$(get_ip6tables_rule_count)
        if [ "$ip6tables_rules" -gt 0 ]; then
            echo ""
            echo "WARNING: ip6tables has $ip6tables_rules active rules"
        fi
    else
        echo "ip6tables: NOT INSTALLED"
    fi
    
    echo ""
    
    # Check for iptables services
    echo "iptables service status:"
    echo "------------------------"
    iptables_svc_status=$(get_service_status "iptables")
    ip6tables_svc_status=$(get_service_status "ip6tables")
    
    echo "iptables service: ${iptables_svc_status^^}"
    echo "ip6tables service: ${ip6tables_svc_status^^}"
}

# Function to execute and show commands with real-time output
execute_command() {
    local cmd="$1"
    local description="$2"
    
    echo "COMMAND: $cmd"
    echo "DESCRIPTION: $description"
    echo "OUTPUT:"
    eval "$cmd"
    local exit_code=$?
    echo "EXIT CODE: $exit_code"
    echo ""
    return $exit_code
}

# Function to apply remediation
apply_remediation() {
    echo "Applying remediation..."
    echo ""

    # Get initial rule counts
    initial_iptables_rules=$(get_iptables_rule_count)
    initial_ip6tables_rules=$(get_ip6tables_rule_count)

    # Flush iptables rules if they exist
    if [ "$initial_iptables_rules" -gt 0 ]; then
        echo "Flushing iptables rules (IPv4)..."
        execute_command "iptables -F" "Flush all iptables rules"
        execute_command "iptables -X" "Delete all user-defined chains"
        execute_command "iptables -Z" "Zero all packet and byte counters"
        execute_command "iptables -t nat -F" "Flush NAT table rules"
        execute_command "iptables -t mangle -F" "Flush mangle table rules"
        execute_command "iptables -P INPUT ACCEPT" "Set default INPUT policy to ACCEPT"
        execute_command "iptables -P FORWARD ACCEPT" "Set default FORWARD policy to ACCEPT"
        execute_command "iptables -P OUTPUT ACCEPT" "Set default OUTPUT policy to ACCEPT"
    else
        echo "No iptables rules to flush"
        echo ""
    fi

    # Flush ip6tables rules if they exist
    if [ "$initial_ip6tables_rules" -gt 0 ]; then
        echo "Flushing ip6tables rules (IPv6)..."
        execute_command "ip6tables -F" "Flush all ip6tables rules"
        execute_command "ip6tables -X" "Delete all user-defined chains"
        execute_command "ip6tables -Z" "Zero all packet and byte counters"
        execute_command "ip6tables -t nat -F" "Flush NAT table rules"
        execute_command "ip6tables -t mangle -F" "Flush mangle table rules"
        execute_command "ip6tables -P INPUT ACCEPT" "Set default INPUT policy to ACCEPT"
        execute_command "ip6tables -P FORWARD ACCEPT" "Set default FORWARD policy to ACCEPT"
        execute_command "ip6tables -P OUTPUT ACCEPT" "Set default OUTPUT policy to ACCEPT"
    else
        echo "No ip6tables rules to flush"
        echo ""
    fi

    # Stop and disable services
    echo "Stopping and disabling iptables services..."
    execute_command "systemctl stop iptables" "Stop iptables service"
    execute_command "systemctl stop ip6tables" "Stop ip6tables service"
    execute_command "systemctl disable iptables" "Disable iptables service"
    execute_command "systemctl disable ip6tables" "Disable ip6tables service"
    execute_command "systemctl mask iptables" "Mask iptables service"
    execute_command "systemctl mask ip6tables" "Mask ip6tables service"

    echo "Remediation of iptables flush complete"
}

# Main remediation
{
    check_current_status
    
    # Get rule counts for decision
    iptables_rules=$(get_iptables_rule_count)
    ip6tables_rules=$(get_ip6tables_rule_count)
    
    if [ "$iptables_rules" -gt 0 ] || [ "$ip6tables_rules" -gt 0 ]; then
        apply_remediation
    else
        echo "No remediation needed - no iptables rules found"
    fi

    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification
    final_status_pass=true
    
    # Check iptables rules
    echo ""
    echo "1. VERIFYING IPTABLES RULES (IPv4):"
    final_iptables_rules=$(get_iptables_rule_count)
    if [ "$final_iptables_rules" -eq 0 ]; then
        echo "PASS: iptables rules are flushed"
        echo "PROOF: iptables -L -n shows no active rules"
        echo "COMMAND OUTPUT:"
        iptables -L -n 2>/dev/null | head -5
    else
        echo "FAIL: iptables has $final_iptables_rules active rules"
        echo "PROOF: iptables -L -n shows active rules"
        echo "COMMAND OUTPUT:"
        iptables -L -n 2>/dev/null | head -10
        final_status_pass=false
    fi
    
    # Check ip6tables rules
    echo ""
    echo "2. VERIFYING IP6TABLES RULES (IPv6):"
    final_ip6tables_rules=$(get_ip6tables_rule_count)
    if [ "$final_ip6tables_rules" -eq 0 ]; then
        echo "PASS: ip6tables rules are flushed"
        echo "PROOF: ip6tables -L -n shows no active rules"
        echo "COMMAND OUTPUT:"
        ip6tables -L -n 2>/dev/null | head -5
    else
        echo "FAIL: ip6tables has $final_ip6tables_rules active rules"
        echo "PROOF: ip6tables -L -n shows active rules"
        echo "COMMAND OUTPUT:"
        ip6tables -L -n 2>/dev/null | head -10
        final_status_pass=false
    fi
    
    # Check service status
    echo ""
    echo "3. VERIFYING IPTABLES SERVICES:"
    iptables_service_status=$(get_service_status "iptables")
    ip6tables_service_status=$(get_service_status "ip6tables")
    
    if [ "$iptables_service_status" = "inactive" ]; then
        echo "PASS: iptables service is INACTIVE"
        echo "PROOF: systemctl is-active iptables returns 'inactive'"
    else
        echo "FAIL: iptables service is ACTIVE"
        echo "PROOF: systemctl is-active iptables returns '$iptables_service_status'"
        final_status_pass=false
    fi
    
    if [ "$ip6tables_service_status" = "inactive" ]; then
        echo "PASS: ip6tables service is INACTIVE"
        echo "PROOF: systemctl is-active ip6tables returns 'inactive'"
    else
        echo "FAIL: ip6tables service is ACTIVE"
        echo "PROOF: systemctl is-active ip6tables returns '$ip6tables_service_status'"
        final_status_pass=false
    fi
    
    # Final status
    echo ""
    if [ "$final_status_pass" = true ]; then
        echo "SUCCESS: iptables properly flushed"
    else
        echo "FAIL: Issues remain with iptables configuration"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="