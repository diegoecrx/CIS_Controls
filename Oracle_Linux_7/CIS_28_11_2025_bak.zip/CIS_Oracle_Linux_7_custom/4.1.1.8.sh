#!/usr/bin/env bash

# Script: 4.1.1.8.sh
# Item: 4.1.1.8 Ensure crontab is restricted to authorized users (Automated)

set -euo pipefail

SCRIPT_NAME="4.1.1.8.sh"
ITEM_NAME="4.1.1.8 Ensure crontab is restricted to authorized users (Automated)"
DESCRIPTION="This remediation ensures crontab access is restricted to authorized users via /etc/cron.allow and /etc/cron.deny."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current cron access control status..."
echo ""

# Display current status
echo "Current status:"
echo "- /etc/cron.allow exists: $([ -e /etc/cron.allow ] && echo 'YES' || echo 'NO')"
echo "- /etc/cron.deny exists: $([ -e /etc/cron.deny ] && echo 'YES' || echo 'NO')"
echo ""

if [ -e /etc/cron.allow ]; then
  echo "Current /etc/cron.allow permissions:"
  ls -l /etc/cron.allow
  stat /etc/cron.allow
fi

if [ -e /etc/cron.deny ]; then
  echo ""
  echo "Current /etc/cron.deny permissions:"
  ls -l /etc/cron.deny
  stat /etc/cron.deny
fi

echo ""
echo "Applying remediation..."
echo ""

# Create /etc/cron.allow if it doesn't exist
if [ ! -e "/etc/cron.allow" ]; then
  echo " - Creating /etc/cron.allow"
  touch /etc/cron.allow
else
  echo " - /etc/cron.allow already exists"
fi

# Set ownership and permissions on /etc/cron.allow
echo " - Setting ownership to root:root on /etc/cron.allow"
chown root:root /etc/cron.allow

echo " - Setting permissions to 640 (u-x,g-wx,o-rwx) on /etc/cron.allow"
chmod u-x,g-wx,o-rwx /etc/cron.allow

# Handle /etc/cron.deny if it exists
if [ -e "/etc/cron.deny" ]; then
  echo " - Setting ownership to root:root on /etc/cron.deny"
  chown root:root /etc/cron.deny
  
  echo " - Setting permissions to 640 (u-x,g-wx,o-rwx) on /etc/cron.deny"
  chmod u-x,g-wx,o-rwx /etc/cron.deny
else
  echo " - /etc/cron.deny does not exist (no action needed)"
fi

echo ""
echo " - SUCCESS: Applied ownership and permissions"
echo ""

echo "Remediation of crontab access control complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

# Final verification and enforcement
final_status_pass=true

# PROOF 1: Verify /etc/cron.allow exists
echo ""
echo "1. VERIFYING /etc/cron.allow EXISTS:"
echo "-----------------------------------"

if [ -e "/etc/cron.allow" ]; then
  echo "PASS: /etc/cron.allow exists"
  echo "PROOF (ls output):"
  ls -l /etc/cron.allow
else
  echo "FAIL: /etc/cron.allow does NOT exist - creating now"
  touch /etc/cron.allow
  
  if [ -e "/etc/cron.allow" ]; then
    echo "PASS: /etc/cron.allow created successfully"
    echo "PROOF (ls output):"
    ls -l /etc/cron.allow
  else
    echo "FAIL: Could not create /etc/cron.allow"
    final_status_pass=false
  fi
fi

# PROOF 2: Verify /etc/cron.allow ownership is root:root
echo ""
echo "2. VERIFYING /etc/cron.allow OWNERSHIP IS root:root:"
echo "---------------------------------------------------"
current_owner=$(stat -c '%U' /etc/cron.allow)
current_group=$(stat -c '%G' /etc/cron.allow)

if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
  echo "PASS: /etc/cron.allow is owned by root:root"
  echo "PROOF (stat output):"
  stat /etc/cron.allow | grep -E '(Uid|Gid)'
else
  echo "FAIL: /etc/cron.allow ownership is NOT root:root - fixing now"
  chown root:root /etc/cron.allow
  
  current_owner=$(stat -c '%U' /etc/cron.allow)
  current_group=$(stat -c '%G' /etc/cron.allow)
  
  if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
    echo "PASS: /etc/cron.allow ownership corrected to root:root"
    echo "PROOF (stat output):"
    stat /etc/cron.allow | grep -E '(Uid|Gid)'
  else
    echo "FAIL: Could not set ownership to root:root"
    final_status_pass=false
  fi
fi

# PROOF 3: Verify /etc/cron.allow permissions are 640 or more restrictive
echo ""
echo "3. VERIFYING /etc/cron.allow PERMISSIONS ARE 640 OR MORE RESTRICTIVE:"
echo "--------------------------------------------------------------------"
current_perms=$(stat -c '%a' /etc/cron.allow)

if [ "$current_perms" = "640" ] || [ "$current_perms" = "600" ] || [ "$current_perms" = "400" ]; then
  echo "PASS: /etc/cron.allow has permissions $current_perms (640 or more restrictive)"
  echo "PROOF (stat output):"
  stat -c 'Access: (%a/%A)' /etc/cron.allow
else
  echo "FAIL: /etc/cron.allow permissions are $current_perms (expected 640 or more restrictive) - fixing now"
  chmod 640 /etc/cron.allow
  
  current_perms=$(stat -c '%a' /etc/cron.allow)
  
  if [ "$current_perms" = "640" ]; then
    echo "PASS: /etc/cron.allow permissions corrected to 640"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/cron.allow
  else
    echo "FAIL: Could not set permissions to 640"
    final_status_pass=false
  fi
fi

# PROOF 4: Verify /etc/cron.deny (if exists) ownership is root:root
if [ -e "/etc/cron.deny" ]; then
  echo ""
  echo "4. VERIFYING /etc/cron.deny OWNERSHIP IS root:root:"
  echo "--------------------------------------------------"
  current_owner=$(stat -c '%U' /etc/cron.deny)
  current_group=$(stat -c '%G' /etc/cron.deny)

  if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
    echo "PASS: /etc/cron.deny is owned by root:root"
    echo "PROOF (stat output):"
    stat /etc/cron.deny | grep -E '(Uid|Gid)'
  else
    echo "FAIL: /etc/cron.deny ownership is NOT root:root - fixing now"
    chown root:root /etc/cron.deny
    
    current_owner=$(stat -c '%U' /etc/cron.deny)
    current_group=$(stat -c '%G' /etc/cron.deny)
    
    if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
      echo "PASS: /etc/cron.deny ownership corrected to root:root"
      echo "PROOF (stat output):"
      stat /etc/cron.deny | grep -E '(Uid|Gid)'
    else
      echo "FAIL: Could not set ownership to root:root"
      final_status_pass=false
    fi
  fi

  # PROOF 5: Verify /etc/cron.deny permissions are 640 or more restrictive
  echo ""
  echo "5. VERIFYING /etc/cron.deny PERMISSIONS ARE 640 OR MORE RESTRICTIVE:"
  echo "-------------------------------------------------------------------"
  current_perms=$(stat -c '%a' /etc/cron.deny)

  if [ "$current_perms" = "640" ] || [ "$current_perms" = "600" ] || [ "$current_perms" = "400" ]; then
    echo "PASS: /etc/cron.deny has permissions $current_perms (640 or more restrictive)"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/cron.deny
  else
    echo "FAIL: /etc/cron.deny permissions are $current_perms (expected 640 or more restrictive) - fixing now"
    chmod 640 /etc/cron.deny
    
    current_perms=$(stat -c '%a' /etc/cron.deny)
    
    if [ "$current_perms" = "640" ]; then
      echo "PASS: /etc/cron.deny permissions corrected to 640"
      echo "PROOF (stat output):"
      stat -c 'Access: (%a/%A)' /etc/cron.deny
    else
      echo "FAIL: Could not set permissions to 640"
      final_status_pass=false
    fi
  fi
else
  echo ""
  echo "4. /etc/cron.deny does not exist - no additional verification needed"
fi

# PROOF 6: Verify complete stat output for both files
echo ""
echo "6. VERIFYING COMPLETE FILE STATUS:"
echo "---------------------------------"
echo "PROOF (full stat output for /etc/cron.allow):"
stat /etc/cron.allow

if [ -e "/etc/cron.deny" ]; then
  echo ""
  echo "PROOF (full stat output for /etc/cron.deny):"
  stat /etc/cron.deny
fi

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
