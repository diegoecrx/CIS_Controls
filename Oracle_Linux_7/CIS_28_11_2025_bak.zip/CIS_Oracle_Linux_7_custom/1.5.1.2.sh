#!/usr/bin/env bash
# Script: 1.5.1.2.sh
# Item: 1.5.1.2 Ensure SELinux is not disabled in bootloader configuration (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.2.sh"
ITEM_NAME="1.5.1.2 Ensure SELinux is not disabled in bootloader configuration (Automated)"
DESCRIPTION="This remediation ensures SELinux is not disabled in bootloader configuration."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current bootloader configuration..."
    echo ""
    echo "Current kernel cmdline:"
    cmdline=$(cat /proc/cmdline)
    echo "$cmdline"
    if echo "$cmdline" | grep -q 'selinux=0' || echo "$cmdline" | grep -q 'enforcing=0'; then
        echo "FAIL: Disabling parameters found in current cmdline"
        return 1
    fi
    echo ""
    echo "/etc/default/grub:"
    grub_content=$(grep '^GRUB_CMDLINE_LINUX' /etc/default/grub || true)
    echo "$grub_content"
    if echo "$grub_content" | grep -q 'selinux=0' || echo "$grub_content" | grep -q 'enforcing=0'; then
        echo "FAIL: Disabling parameters found in /etc/default/grub"
        return 1
    fi
    return 0
}
# Function to fix
fix_bootloader() {
    echo "Applying fix..."
    grubby --update-kernel ALL --remove-args "selinux=0 enforcing=0" 2>/dev/null || true
    echo " - Removed params with grubby"
    sed -ri 's/\s*(selinux|enforcing)=0\s*//g' /etc/default/grub
    echo " - Edited /etc/default/grub"
    grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1
    echo " - Regenerated grub config"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_bootloader
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: SELinux not disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="