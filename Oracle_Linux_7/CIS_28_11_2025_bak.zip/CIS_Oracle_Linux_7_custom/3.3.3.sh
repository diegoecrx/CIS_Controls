#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

sed -i '/net.ipv4.icmp_ignore_bogus_error_responses/d' /etc/sysctl.conf
sed -i '/net.ipv4.icmp_ignore_bogus_error_responses/d' /etc/sysctl.d/*.conf

echo "net.ipv4.icmp_ignore_bogus_error_responses = 1" >> /etc/sysctl.conf

sysctl -w net.ipv4.icmp_ignore_bogus_error_responses=1
sysctl -w net.ipv4.route.flush=1

sysctl net.ipv4.icmp_ignore_bogus_error_responses
grep "net.ipv4.icmp_ignore_bogus_error_responses" /etc/sysctl.conf
stat /etc/sysctl.conf

if sysctl net.ipv4.icmp_ignore_bogus_error_responses | grep -q "net.ipv4.icmp_ignore_bogus_error_responses = 1" && \
   grep -q "net.ipv4.icmp_ignore_bogus_error_responses = 1" /etc/sysctl.conf; then
    echo "pass"
else
    echo "FAIL: Bogus ICMP responses configuration failed"
    exit 1
fi