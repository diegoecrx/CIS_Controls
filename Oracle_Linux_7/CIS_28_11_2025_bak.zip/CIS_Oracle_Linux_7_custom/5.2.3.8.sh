#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-identity.rules"

{
    echo "-w /etc/group -p wa -k identity"
    echo "-w /etc/passwd -p wa -k identity"
    echo "-w /etc/gshadow -p wa -k identity"
    echo "-w /etc/shadow -p wa -k identity"
    echo "-w /etc/security/opasswd -p wa -k identity"
} > "$RULES_FILE"

augenrules --load

if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi