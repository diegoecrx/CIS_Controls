#!/usr/bin/env bash
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "Error: Root privileges required" >&2
    exit 1
fi

CONFIG_FILE="/etc/systemd/journald.conf"
BACKUP_FILE="$CONFIG_FILE.bak.$(date +%Y%m%d_%H%M%S)"

check_current_config() {
    echo "Current journald.conf configuration:"
    grep -E '^(SystemMaxUse|SystemKeepFree|RuntimeMaxUse|RuntimeKeepFree|MaxFileSec)=' "$CONFIG_FILE" 2>/dev/null || echo "No rotation parameters configured"
}

apply_rotation_config() {
    if [ -f "$CONFIG_FILE" ]; then
        cp "$CONFIG_FILE" "$BACKUP_FILE"
        echo "Backup created: $BACKUP_FILE"
    fi

    PARAMS=(
        "SystemMaxUse=1G"
        "SystemKeepFree=2G" 
        "RuntimeMaxUse=100M"
        "RuntimeKeepFree=200M"
        "MaxFileSec=1month"
    )

    for param in "${PARAMS[@]}"; do
        key="${param%=*}"
        if grep -q "^$key=" "$CONFIG_FILE" 2>/dev/null; then
            sed -i "s/^$key=.*/$param/" "$CONFIG_FILE"
        else
            echo "$param" >> "$CONFIG_FILE"
        fi
        echo "Configured: $param"
    done

    systemctl restart systemd-journald.service
    echo "Journald service restarted"
}

verify_config() {
    echo "Final configuration verification:"
    grep -E '^(SystemMaxUse|SystemKeepFree|RuntimeMaxUse|RuntimeKeepFree|MaxFileSec)=' "$CONFIG_FILE"
}

check_current_config
apply_rotation_config
verify_config