#!/usr/bin/env bash

# Script: 2.1.1_v2.sh
# Item: 2.1.1 Ensure time synchronization is in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.1.1_v2.sh"
ITEM_NAME="2.1.1 Ensure time synchronization is in use (Automated)"
DESCRIPTION="This remediation ensures time synchronization is in use by installing and configuring chrony. FORCE VERSION - Installs, configures, and enables time synchronization."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect package manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to install_chrony
install_chrony() {
    local pkg_mgr="$1"
    
    echo "Installing chrony time synchronization..."
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr package manager..."
            if ! $pkg_mgr install -y chrony 2>&1; then
                echo "ERROR: Failed to install chrony with $pkg_mgr"
                return 1
            fi
            ;;
        apt)
            echo " - Using apt package manager..."
            export DEBIAN_FRONTEND=noninteractive
            if ! apt-get update && apt-get install -y chrony 2>&1; then
                echo "ERROR: Failed to install chrony with apt"
                return 1
            fi
            ;;
        zypper)
            echo " - Using zypper package manager..."
            if ! zypper --non-interactive install chrony 2>&1; then
                echo "ERROR: Failed to install chrony with zypper"
                return 1
            fi
            ;;
        *)
            echo "ERROR: Unsupported package manager: $pkg_mgr"
            return 1
            ;;
    esac
    
    echo " - SUCCESS: chrony installed successfully"
    return 0
}

# Function to install_ntp
install_ntp() {
    local pkg_mgr="$1"
    
    echo "Installing ntp (alternative time synchronization)..."
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr package manager..."
            if ! $pkg_mgr install -y ntp 2>&1; then
                echo "ERROR: Failed to install ntp with $pkg_mgr"
                return 1
            fi
            ;;
        apt)
            echo " - Using apt package manager..."
            export DEBIAN_FRONTEND=noninteractive
            if ! apt-get update && apt-get install -y ntp 2>&1; then
                echo "ERROR: Failed to install ntp with apt"
                return 1
            fi
            ;;
        zypper)
            echo " - Using zypper package manager..."
            if ! zypper --non-interactive install ntp 2>&1; then
                echo "ERROR: Failed to install ntp with zypper"
                return 1
            fi
            ;;
        *)
            echo "ERROR: Unsupported package manager: $pkg_mgr"
            return 1
            ;;
    esac
    
    echo " - SUCCESS: ntp installed successfully"
    return 0
}

# Function to configure_chrony
configure_chrony() {
    echo "Configuring chrony..."
    
    # Backup existing configuration
    if [ -f "/etc/chrony.conf" ]; then
        cp /etc/chrony.conf "/etc/chrony.conf.backup.$(date +%Y%m%d_%H%M%S)"
        echo " - Backup created: /etc/chrony.conf.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Create secure chrony configuration
    cat > /etc/chrony.conf << 'EOF'
# Chrony configuration for security compliance
# Server configurations
pool 2.rhel.pool.ntp.org iburst
pool 0.rhel.pool.ntp.org iburst
pool 1.rhel.pool.ntp.org iburst
pool 3.rhel.pool.ntp.org iburst

# Use the local system clock as a backup if no servers are available
#local stratum 10

# Record the rate at which the system clock gains/losses time.
driftfile /var/lib/chrony/drift

# Allow the system clock to be stepped in the first three updates
# if its offset is larger than 1 second.
makestep 1.0 3

# Enable kernel synchronization of the real-time clock (RTC).
rtcsync

# Specify directory for log files.
logdir /var/log/chrony

# Select which information is logged.
#log measurements statistics tracking

# Security settings
# Allow NTP client access from local network.
#allow 192.168.1.0/24

# Serve time even if not synchronized to a time source.
#local stratum 10

# Specify the key file containing the keys for NTP authentication.
keyfile /etc/chrony.keys

# Specify the key number used for authenticating NTP packets.
#commandkey 1

# Generate a new key file if it doesn't exist.
generatecommandkey

# Disable chronyd listening on the command port (0).
cmdport 0

# Disable chronyd listening on the network for NTP packets (port 123).
#port 0

# Listen for commands only on the local loopback interface.
bindcmdaddress 127.0.0.1
bindcmdaddress ::1

# Listen for NTP packets only on the local loopback interface.
#bindaddress 127.0.0.1
#bindaddress ::1
EOF

    echo " - Chrony configuration applied"
    
    # Set proper permissions
    chmod 644 /etc/chrony.conf
    chown root:root /etc/chrony.conf
    
    # Ensure chrony keys file exists and has proper permissions
    if [ ! -f "/etc/chrony.keys" ]; then
        chronyc -a makestep >/dev/null 2>&1 || true
    fi
    if [ -f "/etc/chrony.keys" ]; then
        chmod 640 /etc/chrony.keys
        chown root:chrony /etc/chrony.keys 2>/dev/null || chown root:root /etc/chrony.keys
    fi
}

# Function to configure_ntp
configure_ntp() {
    echo "Configuring ntp..."
    
    # Backup existing configuration
    if [ -f "/etc/ntp.conf" ]; then
        cp /etc/ntp.conf "/etc/ntp.conf.backup.$(date +%Y%m%d_%H%M%S)"
        echo " - Backup created: /etc/ntp.conf.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Create secure ntp configuration
    cat > /etc/ntp.conf << 'EOF'
# NTP configuration for security compliance
# Server configurations
server 0.rhel.pool.ntp.org iburst
server 1.rhel.pool.ntp.org iburst
server 2.rhel.pool.ntp.org iburst
server 3.rhel.pool.ntp.org iburst

# Drift file
driftfile /var/lib/ntp/drift

# Statistics file
statistics loopstats peerstats clockstats
filegen loopstats file loopstats type day enable
filegen peerstats file peerstats type day enable
filegen clockstats file clockstats type day enable

# Restrict default access
restrict default kod nomodify notrap nopeer noquery
restrict -6 default kod nomodify notrap nopeer noquery

# Allow localhost full access
restrict 127.0.0.1
restrict -6 ::1

# Enable NTP pool servers
restrict 0.rhel.pool.ntp.org mask 255.255.255.255 nomodify notrap nopeer noquery
restrict 1.rhel.pool.ntp.org mask 255.255.255.255 nomodify notrap nopeer noquery
restrict 2.rhel.pool.ntp.org mask 255.255.255.255 nomodify notrap nopeer noquery
restrict 3.rhel.pool.ntp.org mask 255.255.255.255 nomodify notrap nopeer noquery

# Disable NTP server functionality (client only)
#disable server

# Enable NTP client functionality
#disable client
EOF

    echo " - NTP configuration applied"
    
    # Set proper permissions
    chmod 644 /etc/ntp.conf
    chown root:root /etc/ntp.conf
}

# Function to enable_and_start_service
enable_and_start_service() {
    local service_name="$1"
    
    echo "Enabling and starting $service_name service..."
    
    # Enable service to start at boot
    if systemctl enable "$service_name" 2>&1; then
        echo " - Service enabled to start at boot"
    else
        echo " - WARNING: Could not enable $service_name service"
    fi
    
    # Start service
    if systemctl start "$service_name" 2>&1; then
        echo " - Service started successfully"
        
        # Wait a moment for service to initialize
        sleep 3
        
        # Check service status
        if systemctl is-active "$service_name" >/dev/null 2>&1; then
            echo " - Service is running"
            return 0
        else
            echo " - WARNING: Service started but not running"
            return 1
        fi
    else
        echo " - ERROR: Failed to start $service_name service"
        return 1
    fi
}

# Function to verify_time_sync
verify_time_sync() {
    local service_name="$1"
    
    echo "Verifying time synchronization..."
    
    # Check service status
    if systemctl is-active "$service_name" >/dev/null 2>&1; then
        echo " - PASS: $service_name service is running"
    else
        echo " - FAIL: $service_name service is not running"
        return 1
    fi
    
    # Check service enabled status
    if systemctl is-enabled "$service_name" >/dev/null 2>&1; then
        echo " - PASS: $service_name service is enabled"
    else
        echo " - FAIL: $service_name service is not enabled"
        return 1
    fi
    
    # Verify time synchronization based on service
    case "$service_name" in
        chronyd)
            if command -v chronyc >/dev/null 2>&1; then
                echo " - Checking chrony synchronization..."
                if chronyc tracking 2>/dev/null | grep -q "Leap status\s*:\s*Normal"; then
                    echo " - PASS: chrony is synchronized"
                    # Show tracking information
                    echo " - Chrony tracking information:"
                    chronyc tracking | head -5
                    return 0
                else
                    echo " - WARNING: chrony may not be fully synchronized"
                    chronyc tracking 2>/dev/null | head -5 || true
                    return 0  # Still return success as service is running
                fi
            fi
            ;;
        ntpd)
            if command -v ntpq >/dev/null 2>&1; then
                echo " - Checking ntp synchronization..."
                if ntpq -p 2>/dev/null | grep -q "*"; then
                    echo " - PASS: ntp is synchronized"
                    # Show peer information
                    echo " - NTP peers:"
                    ntpq -p | head -5
                    return 0
                else
                    echo " - WARNING: ntp may not be fully synchronized"
                    ntpq -p 2>/dev/null | head -5 || true
                    return 0  # Still return success as service is running
                fi
            fi
            ;;
    esac
    
    # Fallback verification
    echo " - Time synchronization service $service_name is installed and running"
    return 0
}

# Main remediation function
{
    echo "Checking current time synchronization status..."
    echo ""

    # Check if any time synchronization service is running
    chrony_active=false
    ntp_active=false
    systemd_timesyncd_active=false
    
    if systemctl is-active chronyd >/dev/null 2>&1; then
        chrony_active=true
        echo "PASS: chronyd service is active"
    fi
    
    if systemctl is-active ntpd >/dev/null 2>&1; then
        ntp_active=true
        echo "PASS: ntpd service is active"
    fi
    
    if systemctl is-active systemd-timesyncd >/dev/null 2>&1; then
        systemd_timesyncd_active=true
        echo "PASS: systemd-timesyncd service is active"
    fi
    
    if [ "$chrony_active" = false ] && [ "$ntp_active" = false ] && [ "$systemd_timesyncd_active" = false ]; then
        echo "FAIL: No time synchronization service is active"
        echo ""
        
        # Check if services are installed but not running
        if systemctl list-unit-files | grep -q chronyd; then
            echo "INFO: chronyd is installed but not running"
        fi
        if systemctl list-unit-files | grep -q ntpd; then
            echo "INFO: ntpd is installed but not running"
        fi
        if systemctl list-unit-files | grep -q systemd-timesyncd; then
            echo "INFO: systemd-timesyncd is installed but not running"
        fi
    fi
    
    echo ""

    # FORCE MODE: Install and configure time synchronization
    echo "==================================================================="
    echo "FORCE MODE: INSTALLING AND CONFIGURING TIME SYNCHRONIZATION"
    echo "==================================================================="
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # Try to install chrony first (preferred on modern systems)
    time_sync_service=""
    
    if install_chrony "$pkg_mgr"; then
        time_sync_service="chronyd"
        configure_chrony
    else
        echo " - chrony installation failed, trying ntp..."
        if install_ntp "$pkg_mgr"; then
            time_sync_service="ntpd"
            configure_ntp
        else
            echo "ERROR: Failed to install any time synchronization service"
            echo "This system may not have access to package repositories."
            exit 1
        fi
    fi

    echo ""

    # Enable and start the service
    if [ -n "$time_sync_service" ]; then
        if enable_and_start_service "$time_sync_service"; then
            echo " - SUCCESS: $time_sync_service configured and started"
        else
            echo " - WARNING: $time_sync_service installed but may have startup issues"
        fi
    fi

    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if [ -n "$time_sync_service" ]; then
        if verify_time_sync "$time_sync_service"; then
            echo ""
            echo "SUCCESS: Time synchronization is now properly configured"
            echo ""
            echo "REMEDIATION SUMMARY:"
            echo "==================="
            echo "✓ $time_sync_service installed"
            echo "✓ Service configured securely"
            echo "✓ Service enabled at boot"
            echo "✓ Service running"
            echo "✓ Time synchronization active"
        else
            echo ""
            echo "WARNING: Time synchronization installed but verification failed"
            echo "Please check the service status manually:"
            echo "  systemctl status $time_sync_service"
        fi
    else
        echo "ERROR: No time synchronization service was configured"
        exit 1
    fi

    # Show current time status
    echo ""
    echo "CURRENT TIME STATUS:"
    echo "==================="
    echo "System time: $(date)"
    echo "UTC time: $(date -u)"
    if command -v timedatectl >/dev/null 2>&1; then
        echo "Time synchronization: $(timedatectl status | grep -i "synchronized" | cut -d: -f2 | tr -d ' ' || echo "unknown")"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="