#!/bin/bash

# Enforce CIS 5.2.1.3 - Ensure audit_backlog_limit is sufficient
echo "Enforcing CIS 5.2.1.3 - Configure audit_backlog_limit..."

# Set backlog limit (using CIS recommended value of 8192)
BACKLOG_SIZE="8192"

# Update GRUB configuration with audit_backlog_limit
echo "Updating GRUB configuration with audit_backlog_limit=$BACKLOG_SIZE..."

# Update kernel command line using grubby
if command -v grubby >/dev/null 2>&1; then
    grubby --update-kernel ALL --args "audit_backlog_limit=$BACKLOG_SIZE"
    echo "Updated kernel command line with audit_backlog_limit=$BACKLOG_SIZE using grubby"
else
    echo "WARNING: grubby command not found, updating /etc/default/grub directly"
fi

# Ensure audit_backlog_limit is in /etc/default/grub
echo "Configuring /etc/default/grub..."

# Backup original file
if [ ! -f /etc/default/grub.bak ]; then
    cp /etc/default/grub /etc/default/grub.bak
    echo "Backed up /etc/default/grub to /etc/default/grub.bak"
fi

# Check if GRUB_CMDLINE_LINUX exists and add/update audit_backlog_limit
if grep -q '^GRUB_CMDLINE_LINUX=' /etc/default/grub; then
    # Remove existing audit_backlog_limit parameter if present
    sed -i 's/GRUB_CMDLINE_LINUX="\([^"]*\)"/GRUB_CMDLINE_LINUX="\1"/' /etc/default/grub
    sed -i '/^GRUB_CMDLINE_LINUX=/s/audit_backlog_limit=[0-9]*//g' /etc/default/grub
    
    # Add audit_backlog_limit to the existing parameters
    sed -i "/^GRUB_CMDLINE_LINUX=/s/\"\(.*\)\"/\"\1 audit_backlog_limit=$BACKLOG_SIZE\"/" /etc/default/grub
    echo "Added audit_backlog_limit=$BACKLOG_SIZE to existing GRUB_CMDLINE_LINUX in /etc/default/grub"
else
    # Add GRUB_CMDLINE_LINUX line if it doesn't exist
    echo "GRUB_CMDLINE_LINUX=\"audit_backlog_limit=$BACKLOG_SIZE\"" >> /etc/default/grub
    echo "Added GRUB_CMDLINE_LINUX with audit_backlog_limit=$BACKLOG_SIZE to /etc/default/grub"
fi

# Clean up any duplicate spaces that may have been introduced
sed -i '/^GRUB_CMDLINE_LINUX=/s/  / /g' /etc/default/grub

# Rebuild GRUB configuration
echo "Rebuilding GRUB configuration..."
if command -v grub2-mkconfig >/dev/null 2>&1; then
    grub2-mkconfig -o /boot/grub2/grub.cfg
    echo "Rebuilt GRUB configuration using grub2-mkconfig"
elif command -v grub-mkconfig >/dev/null 2>&1; then
    grub-mkconfig -o /boot/grub/grub.cfg
    echo "Rebuilt GRUB configuration using grub-mkconfig"
else
    echo "WARNING: Could not find grub-mkconfig command"
fi

# Verify configuration
echo "Verifying audit_backlog_limit configuration..."

# Check /etc/default/grub
if grep -q "^GRUB_CMDLINE_LINUX=.*audit_backlog_limit=$BACKLOG_SIZE" /etc/default/grub; then
    echo "SUCCESS: audit_backlog_limit=$BACKLOG_SIZE configured in /etc/default/grub"
    echo "Current GRUB_CMDLINE_LINUX: $(grep '^GRUB_CMDLINE_LINUX=' /etc/default/grub)"
else
    echo "ERROR: audit_backlog_limit=$BACKLOG_SIZE not found in /etc/default/grub"
    exit 1
fi

# Check current kernel command line using grubby if available
if command -v grubby >/dev/null 2>&1; then
    if grubby --info=ALL | grep -q "audit_backlog_limit=$BACKLOG_SIZE"; then
        echo "SUCCESS: audit_backlog_limit=$BACKLOG_SIZE found in kernel command line via grubby"
    else
        echo "ERROR: audit_backlog_limit=$BACKLOG_SIZE not found in kernel command line via grubby"
        exit 1
    fi
fi

# Check /proc/cmdline for current boot (will only show audit_backlog_limit after reboot)
if grep -q "audit_backlog_limit=$BACKLOG_SIZE" /proc/cmdline; then
    echo "SUCCESS: audit_backlog_limit=$BACKLOG_SIZE is active in current kernel command line"
else
    echo "WARNING: audit_backlog_limit=$BACKLOG_SIZE is not active in current kernel command line (requires reboot)"
    echo "Current kernel command line: $(cat /proc/cmdline)"
fi

echo "CIS 5.2.1.3 remediation completed successfully"
echo "NOTE: A system reboot is required for audit_backlog_limit=$BACKLOG_SIZE to take effect"