#!/usr/bin/env bash

# Script: 5.1.1.6.sh
# Item: 5.1.1.6 Ensure rsyslog is configured to send logs to a remote log host (Automated)
# Description: Configure rsyslog to forward logs to a remote log host for centralized logging

set -euo pipefail

SCRIPT_NAME="5.1.1.6.sh"
ITEM_NAME="5.1.1.6 Ensure rsyslog is configured to send logs to a remote log host (Automated)"
DESCRIPTION="Configure rsyslog to forward logs to a remote log host for centralized logging"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Default remote log host configuration
REMOTE_HOST="192.168.2.100"
REMOTE_PORT="514"
PROTOCOL="tcp"

# Function to check if rsyslog is available
check_rsyslog_available() {
    if ! command -v rsyslogd >/dev/null 2>&1; then
        echo "rsyslog is not available on this system"
        echo "This control does not apply - no remediation required"
        exit 0
    fi
    echo "rsyslog is available"
}

# Function to create backup of configuration
create_backup() {
    local backup_dir="/etc/rsyslog.backup.$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    if [ -f "/etc/rsyslog.conf" ]; then
        cp "/etc/rsyslog.conf" "$backup_dir/"
    fi
    
    if [ -d "/etc/rsyslog.d" ]; then
        cp -r "/etc/rsyslog.d" "$backup_dir/"
    fi
    
    echo "Configuration backed up to: $backup_dir"
}

# Function to ensure required modules are loaded
ensure_modules_loaded() {
    echo "Ensuring required rsyslog modules are loaded..."
    
    local main_config="/etc/rsyslog.conf"
    local temp_file=$(mktemp)
    
    # Check if modules are already loaded
    local imuxsock_loaded=$(grep -c 'module(load="imuxsock")' "$main_config" 2>/dev/null || echo "0")
    local imjournal_loaded=$(grep -c 'module(load="imjournal")' "$main_config" 2>/dev/null || echo "0")
    local omfwd_loaded=$(grep -c 'module(load="omfwd")' "$main_config" 2>/dev/null || echo "0")
    
    if [ "$imuxsock_loaded" -eq 0 ] || [ "$imjournal_loaded" -eq 0 ] || [ "$omfwd_loaded" -eq 0 ]; then
        echo "Adding required module configurations to $main_config"
        
        # Add module loads at the beginning of file
        cat > "$temp_file" << 'EOF'
# Load essential modules - Added by 5.1.1.6.sh
module(load="imuxsock")    # provides support for local system logging
module(load="imjournal")   # provides access to the systemd journal  
module(load="omfwd")       # provides forwarding support

EOF
        
        # Append original content
        cat "$main_config" >> "$temp_file" 2>/dev/null || true
        
        # Replace original file
        mv "$temp_file" "$main_config"
        echo "Required modules configured"
    else
        echo "Required modules already loaded"
    fi
}

# Function to remove existing remote logging configurations
remove_existing_remote_configs() {
    echo "Removing existing remote logging configurations..."
    
    # Remove from main config file
    if [ -f "/etc/rsyslog.conf" ]; then
        sed -i '/action(type="omfwd"/d' /etc/rsyslog.conf 2>/dev/null || true
        sed -i '/^[^#].*@/d' /etc/rsyslog.conf 2>/dev/null || true
    fi
    
    # Remove from all config files in rsyslog.d
    if [ -d "/etc/rsyslog.d" ]; then
        for config_file in /etc/rsyslog.d/*.conf; do
            if [ -f "$config_file" ]; then
                sed -i '/action(type="omfwd"/d' "$config_file" 2>/dev/null || true
                sed -i '/^[^#].*@/d' "$config_file" 2>/dev/null || true
            fi
        done
    fi
    
    echo "Existing remote configurations removed"
}

# Function to apply remote logging configuration
apply_remote_logging_config() {
    echo "Applying remote logging configuration..."
    
    local remote_conf="/etc/rsyslog.d/50-remote-logging.conf"
    
    # Create the configuration file with exact specification from CIS benchmark
    cat > "$remote_conf" << EOF
# Remote logging configuration - Added by 5.1.1.6.sh
# CIS Benchmark 5.1.1.6 - Ensure rsyslog is configured to send logs to a remote log host

*.* action(type="omfwd" target="$REMOTE_HOST" port="$REMOTE_PORT" protocol="$PROTOCOL"
action.resumeRetryCount="100"
queue.type="LinkedList" queue.size="1000")
EOF

    # Set proper permissions
    chmod 644 "$remote_conf"
    chown root:root "$remote_conf"
    
    echo "Remote logging configuration applied to: $remote_conf"
    echo "Remote host: $REMOTE_HOST"
    echo "Port: $REMOTE_PORT" 
    echo "Protocol: $PROTOCOL"
}

# Function to validate configuration syntax
validate_configuration() {
    echo "Validating rsyslog configuration syntax..."
    
    if rsyslogd -N 1 >/dev/null 2>&1; then
        echo "rsyslog configuration syntax is valid"
        return 0
    else
        echo "rsyslog configuration syntax validation failed"
        rsyslogd -N 1
        return 1
    fi
}

# Function to restart rsyslog service
restart_rsyslog_service() {
    echo "Restarting rsyslog service..."
    
    if systemctl restart rsyslog; then
        echo "rsyslog service restarted successfully"
        
        # Wait for service to stabilize
        sleep 2
        
        if systemctl is-active rsyslog >/dev/null 2>&1; then
            echo "rsyslog service is running"
            return 0
        else
            echo "rsyslog service failed to start after restart"
            return 1
        fi
    else
        echo "Failed to restart rsyslog service"
        return 1
    fi
}

# Function for final verification with proofs
final_verification() {
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    echo ""
    
    local verification_passed=true
    
    echo "1. VERIFYING REMOTE LOGGING CONFIGURATION FILE:"
    echo "-----------------------------------------------"
    local remote_conf="/etc/rsyslog.d/50-remote-logging.conf"
    
    if [ -f "$remote_conf" ]; then
        echo "PASS: Remote logging configuration file exists: $remote_conf"
        echo "PROOF:"
        ls -la "$remote_conf"
        echo ""
        echo "File content:"
        cat "$remote_conf"
    else
        echo "FAIL: Remote logging configuration file not found: $remote_conf"
        verification_passed=false
    fi
    echo ""
    
    echo "2. VERIFYING CONFIGURATION CONTENT:"
    echo "-----------------------------------"
    if [ -f "$remote_conf" ]; then
        if grep -q 'action(type="omfwd"' "$remote_conf"; then
            echo "PASS: Remote forwarding action is configured"
            echo "PROOF:"
            grep 'action(type="omfwd"' "$remote_conf"
        else
            echo "FAIL: Remote forwarding action not found in configuration"
            verification_passed=false
        fi
        
        echo ""
        echo "Checking for required parameters:"
        if grep -q 'action.resumeRetryCount="100"' "$remote_conf"; then
            echo "PASS: action.resumeRetryCount is set to 100"
        else
            echo "FAIL: action.resumeRetryCount is not set to 100"
            verification_passed=false
        fi
        
        if grep -q 'queue.type="LinkedList"' "$remote_conf"; then
            echo "PASS: queue.type is set to LinkedList"
        else
            echo "FAIL: queue.type is not set to LinkedList"
            verification_passed=false
        fi
        
        if grep -q 'queue.size="1000"' "$remote_conf"; then
            echo "PASS: queue.size is set to 1000"
        else
            echo "FAIL: queue.size is not set to 1000"
            verification_passed=false
        fi
    fi
    echo ""
    
    echo "3. VERIFYING RSYSLOG SERVICE STATUS:"
    echo "------------------------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "PASS: rsyslog service is active"
        echo "PROOF:"
        systemctl status rsyslog --no-pager | head -3
    else
        echo "FAIL: rsyslog service is not active"
        verification_passed=false
    fi
    echo ""
    
    echo "4. VERIFYING CONFIGURATION SYNTAX:"
    echo "----------------------------------"
    if rsyslogd -N 1 >/dev/null 2>&1; then
        echo "PASS: rsyslog configuration syntax is valid"
        echo "PROOF: rsyslogd -N 1 command returned success"
    else
        echo "FAIL: rsyslog configuration syntax validation failed"
        echo "PROOF:"
        rsyslogd -N 1
        verification_passed=false
    fi
    echo ""
    
    echo "5. VERIFYING REQUIRED MODULES ARE LOADED:"
    echo "-----------------------------------------"
    local modules=("imuxsock" "imjournal" "omfwd")
    local all_modules_loaded=true
    
    for module in "${modules[@]}"; do
        if grep -r "module(load=\"$module\")" /etc/rsyslog.conf /etc/rsyslog.d/ 2>/dev/null | grep -v '^#' | grep -q .; then
            echo "PASS: Module $module is loaded"
        else
            echo "FAIL: Module $module is not loaded"
            all_modules_loaded=false
            verification_passed=false
        fi
    done
    
    if [ "$all_modules_loaded" = true ]; then
        echo "PROOF: All required modules (imuxsock, imjournal, omfwd) are loaded in configuration"
    fi
    echo ""
    
    echo "6. VERIFYING FILE PERMISSIONS:"
    echo "------------------------------"
    if [ -f "$remote_conf" ]; then
        local permissions=$(stat -c "%a" "$remote_conf" 2>/dev/null)
        local owner=$(stat -c "%U:%G" "$remote_conf" 2>/dev/null)
        
        if [ "$permissions" = "644" ]; then
            echo "PASS: Configuration file has correct permissions (644)"
        else
            echo "FAIL: Configuration file has incorrect permissions ($permissions), expected 644"
            verification_passed=false
        fi
        
        if [ "$owner" = "root:root" ]; then
            echo "PASS: Configuration file has correct ownership (root:root)"
        else
            echo "FAIL: Configuration file has incorrect ownership ($owner), expected root:root"
            verification_passed=false
        fi
        echo "PROOF: $remote_conf permissions: $permissions, owner: $owner"
    fi
    echo ""
    
    echo "7. TESTING LOGGING FUNCTIONALITY:"
    echo "---------------------------------"
    local test_id="REMOTE-LOG-TEST-$(date +%Y%m%d-%H%M%S)"
    local test_message="CIS Remote Logging Test - $test_id"
    
    if logger "$test_message"; then
        echo "PASS: Test message sent successfully via logger"
        echo "PROOF: Test message ID: $test_id"
        echo "Note: Verify message reception on remote log host $REMOTE_HOST"
    else
        echo "FAIL: Failed to send test message via logger"
        verification_passed=false
    fi
    echo ""
    
    if [ "$verification_passed" = true ]; then
        echo "SUCCESS: Remote logging is properly configured"
        echo "PROOF: All verification checks passed - rsyslog is configured to forward logs to $REMOTE_HOST:$REMOTE_PORT using TCP with reliable queueing"
    else
        echo "FAIL: Some verification checks failed - review the configuration"
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main execution
main() {
    echo "Starting automated remediation for remote logging configuration..."
    echo ""
    
    # Check if rsyslog is available
    check_rsyslog_available
    echo ""
    
    # Create backup
    create_backup
    echo ""
    
    # Ensure required modules are loaded
    ensure_modules_loaded
    echo ""
    
    # Remove any existing remote configurations
    remove_existing_remote_configs
    echo ""
    
    # Apply the remote logging configuration
    apply_remote_logging_config
    echo ""
    
    # Validate configuration syntax
    if validate_configuration; then
        echo "Configuration syntax validation passed"
    else
        echo "Configuration syntax validation failed - attempting to continue"
    fi
    echo ""
    
    # Restart rsyslog service
    if restart_rsyslog_service; then
        echo "Service restart completed successfully"
    else
        echo "Service restart encountered issues"
    fi
    echo ""
    
    # Perform final verification
    final_verification
}

# Execute main function
main

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="