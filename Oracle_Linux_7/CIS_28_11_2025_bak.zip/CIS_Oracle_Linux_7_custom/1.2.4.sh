#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Get repository list with full output
echo "Checking configured repositories:"
REPO_OUTPUT=$(yum repolist 2>&1)
echo "$REPO_OUTPUT"

# Extract repository count from the actual repolist line
REPO_COUNT=$(echo "$REPO_OUTPUT" | grep "^repolist:" | awk '{print $2}' | tr -d ',')

# Check if we got a valid number
if [[ ! "$REPO_COUNT" =~ ^[0-9]+$ ]]; then
    echo "FAIL: Could not determine repository count"
    echo "EVIDENCE: 'repolist' line not found or invalid format"
    exit 1
fi

# Verification and result
if [[ $REPO_COUNT -eq 0 ]]; then
    echo "FAIL: No repositories configured or all repositories have 0 packages"
    echo "EVIDENCE: repolist shows $REPO_COUNT repositories"
    exit 1
else
    echo "PASS: $REPO_COUNT repositories configured"
    echo "EVIDENCE: repolist shows $REPO_COUNT repositories"
    exit 0
fi