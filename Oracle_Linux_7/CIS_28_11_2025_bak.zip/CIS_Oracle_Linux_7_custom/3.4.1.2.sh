#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Remove conflicting firewall services
echo "Removing conflicting firewall services:"
yum remove -y iptables-services nftables 2>&1

# Stop and mask conflicting services
echo "Stopping and masking conflicting firewall services:"
systemctl stop iptables.service ip6tables.service nftables.service 2>&1
systemctl mask iptables.service ip6tables.service nftables.service 2>&1

# Check current firewall status for evidence
echo ""
echo "Current firewall configuration status:"

# Check FirewallD status
FIREWALLD_ACTIVE=$(systemctl is-active firewalld.service 2>/dev/null || echo "inactive")
FIREWALLD_ENABLED=$(systemctl is-enabled firewalld.service 2>/dev/null || echo "disabled")
echo "FirewallD: active=$FIREWALLD_ACTIVE, enabled=$FIREWALLD_ENABLED"

# Check iptables-services package status
IPTABLES_INSTALLED=$(rpm -q iptables-services 2>&1)
echo "iptables-services: $IPTABLES_INSTALLED"

# Check nftables package status  
NFTABLES_INSTALLED=$(rpm -q nftables 2>&1)
echo "nftables: $NFTABLES_INSTALLED"

# Check if conflicting services are masked
IPTABLES_MASKED=$(systemctl is-enabled iptables.service 2>/dev/null | grep -q masked && echo "masked" || echo "not masked")
IP6TABLES_MASKED=$(systemctl is-enabled ip6tables.service 2>/dev/null | grep -q masked && echo "masked" || echo "not masked")
NFTABLES_MASKED=$(systemctl is-enabled nftables.service 2>/dev/null | grep -q masked && echo "masked" || echo "not masked")
echo "iptables.service: $IPTABLES_MASKED"
echo "ip6tables.service: $IP6TABLES_MASKED"
echo "nftables.service: $NFTABLES_MASKED"

# Verification and result
echo ""
if [[ "$FIREWALLD_ACTIVE" == "active" && "$FIREWALLD_ENABLED" == "enabled" ]] && \
   [[ "$IPTABLES_INSTALLED" == "package iptables-services is not installed" ]] && \
   [[ "$NFTABLES_INSTALLED" == "package nftables is not installed" ]]; then
    echo "PASS: Single firewall configuration utility confirmed (FirewallD)"
    echo "EVIDENCE: FirewallD is active and enabled, conflicting packages removed"
    exit 0
else
    echo "FAIL: Multiple firewall utilities detected or configuration incomplete"
    echo "EVIDENCE:"
    echo "  - FirewallD: active=$FIREWALLD_ACTIVE, enabled=$FIREWALLD_ENABLED"
    echo "  - iptables-services: $IPTABLES_INSTALLED"
    echo "  - nftables: $NFTABLES_INSTALLED"
    echo "  - iptables.service: $IPTABLES_MASKED"
    echo "  - ip6tables.service: $IP6TABLES_MASKED"
    echo "  - nftables.service: $NFTABLES_MASKED"
    exit 1
fi