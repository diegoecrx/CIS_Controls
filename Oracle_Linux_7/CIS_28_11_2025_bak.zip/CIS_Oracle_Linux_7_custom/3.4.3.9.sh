#!/usr/bin/env bash
# Script: 3.4.3.9.sh
# Item: 3.4.3.9 Ensure nftables rules are permanent (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.9.sh"
ITEM_NAME="3.4.3.9 Ensure nftables rules are permanent (Automated)"
DESCRIPTION="This remediation ensures nftables rules are permanent by configuring proper include statements."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables rules permanence configuration..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    # Check if nftables configuration file exists
    if [ ! -f /etc/sysconfig/nftables.conf ]; then
        echo "FAIL: /etc/sysconfig/nftables.conf does not exist"
        echo "PROOF: Configuration file not found"
        return 1
    fi
    
    # Check if there are any include statements for rules files
    if ! grep -E '^\s*include\s+.*\.rules"?\s*$|^\s*include\s+.*\.conf"?\s*$' /etc/sysconfig/nftables.conf >/dev/null 2>&1; then
        echo "FAIL: No include statements found in nftables configuration"
        echo "PROOF: No include statements in /etc/sysconfig/nftables.conf"
        return 1
    fi
    
    # Check if the main nftables.conf exists and has rules
    if [ ! -f /etc/nftables.conf ]; then
        echo "FAIL: /etc/nftables.conf rules file does not exist"
        echo "PROOF: Main rules file not found"
        return 1
    fi
    
    # Verify the include statement points to an existing file
    included_files=$(grep -E '^\s*include\s+' /etc/sysconfig/nftables.conf | sed 's/.*include\s*["\047]\([^"\047]*\)["\047].*/\1/' | tr -d '"')
    missing_files=""
    for file in $included_files; do
        if [ ! -f "$file" ]; then
            missing_files="${missing_files}$file "
        fi
    done
    
    if [ -n "$missing_files" ]; then
        echo "FAIL: Some included files do not exist"
        echo "PROOF: Missing files: $missing_files"
        return 1
    fi
    
    echo "PASS: nftables rules permanence properly configured"
    echo "PROOF: Include statements exist and reference valid files"
    return 0
}
# Function to fix
fix_nftables_rules_permanent() {
    echo "Applying fix..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package"
        yum install -y nftables
    fi
    
    # Create nftables configuration directory if it doesn't exist
    if [ ! -d /etc/nftables ]; then
        echo " - Creating /etc/nftables directory"
        mkdir -p /etc/nftables
    fi
    
    # Ensure main rules file exists
    if [ ! -f /etc/nftables.conf ]; then
        echo " - Creating /etc/nftables.conf with current ruleset"
        cat > /etc/nftables.conf << 'EOF'
#!/usr/sbin/nft -f

flush ruleset

table inet filter {
    chain input {
        type filter hook input priority 0;
        policy drop;
        
        # Allow loopback traffic
        iif lo accept
        
        # Drop invalid loopback traffic
        ip saddr 127.0.0.0/8 counter drop
        ip6 saddr ::1 counter drop
        
        # Allow established and related connections
        ct state established,related accept
        
        # Allow SSH (customize as needed)
        tcp dport ssh accept
    }
    
    chain forward {
        type filter hook forward priority 0;
        policy drop;
    }
    
    chain output {
        type filter hook output priority 0;
        policy drop;
        
        # Allow outbound traffic
        accept
    }
}
EOF
    fi
    
    # Create or update /etc/sysconfig/nftables.conf
    if [ ! -f /etc/sysconfig/nftables.conf ]; then
        echo " - Creating /etc/sysconfig/nftables.conf"
        cat > /etc/sysconfig/nftables.conf << 'EOF'
# Uncomment the include statement to load nftables rules on boot
include "/etc/nftables.conf"
EOF
    else
        # Check if include statement already exists
        if ! grep -q 'include.*nftables.conf' /etc/sysconfig/nftables.conf; then
            echo " - Adding include statement to /etc/sysconfig/nftables.conf"
            echo 'include "/etc/nftables.conf"' >> /etc/sysconfig/nftables.conf
        else
            # Uncomment existing include statements
            echo " - Ensuring include statements are uncommented"
            sed -i 's/^#\s*include\s*"\([^"]*\)"/include "\1"/' /etc/sysconfig/nftables.conf
        fi
    fi
    
    # Apply the current rules
    echo " - Loading nftables rules"
    nft -f /etc/nftables.conf 2>/dev/null || true
    
    # Ensure nftables service will load the configuration
    if systemctl is-enabled nftables.service >/dev/null 2>&1; then
        echo " - Restarting nftables service to load configuration"
        systemctl restart nftables.service
    fi
    
    echo " - nftables rules permanence configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_rules_permanent
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables rules permanence properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="