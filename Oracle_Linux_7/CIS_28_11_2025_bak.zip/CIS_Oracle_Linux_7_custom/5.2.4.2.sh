#!/bin/bash

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check if auditd.conf exists
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "/etc/audit/auditd.conf not found"
    exit 1
fi

# Get audit log directory from auditd.conf
log_dir=$(awk -F "=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs)
log_dir=$(dirname "$log_dir")

echo "Audit log directory: $log_dir"

# Check if log directory exists
if [ ! -d "$log_dir" ]; then
    echo "Audit log directory $log_dir not found"
    exit 1
fi

# Show current permissions before remediation
echo "Current audit log file permissions:"
find "$log_dir" -type f -exec stat -Lc "%a %n" {} +

# Find and fix audit log files with permissive modes
find "$log_dir" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -exec chmod 0640 {} +

# Show permissions after remediation
echo "Audit log file permissions after remediation:"
find "$log_dir" -type f -exec stat -Lc "%a %n" {} +

# Verify remediation
result=$(find "$log_dir" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -exec stat -Lc "%a %n" {} + | awk '{print} END { if(NR==0) print "pass"; else print "fail"}')

if [ "$result" = "pass" ]; then
    echo "pass"
else
    find "$log_dir" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 -a ! -perm 0640 -a ! -perm 0440 -a ! -perm 0040 \) -exec stat -Lc "%a %n" {} +
    echo "fail"
fi