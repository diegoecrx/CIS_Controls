#!/usr/bin/env bash

# Script: 4.2.3.sh
# Item: 4.2.3 Ensure permissions on SSH public host key files are configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.3.sh"
ITEM_NAME="4.2.3 Ensure permissions on SSH public host key files are configured (Automated)"
DESCRIPTION="This remediation ensures SSH public host key files have correct ownership and permissions configured."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH public host key file permissions..."
echo ""

l_output="" l_output2=""

# Determine the appropriate group for SSH keys
l_skgn="$(grep -Po -- '^(ssh_keys|_?ssh)\b' /etc/group 2>/dev/null || true)"
l_skgid="$(awk -F: "(\$1 == \"$l_skgn\"){print \$3}" /etc/group 2>/dev/null || true)"
l_mfix="u-x,go-wx"

if [ -n "$l_skgid" ]; then
  echo "Group '$l_skgn' exists (GID: $l_skgid)"
else
  echo "No ssh_keys or _ssh group found"
fi
echo ""

if ! command -v ssh-keygen &>/dev/null; then
  echo "ERROR: ssh-keygen command not found - cannot proceed"
  echo "Manual remediation may be required"
  exit 1
fi

if [ ! -d /etc/ssh ]; then
  echo "WARNING: /etc/ssh directory not found on the system"
  exit 1
fi

echo "Scanning for SSH public host key files in /etc/ssh..."
echo ""

# Find and process SSH public keys
unset a_skarr
a_skarr=()

while IFS= read -r -d $'\0' l_file; do
  if grep -Pq -- '\h+no\h+comment\b' <<< "$(ssh-keygen -l -f "$l_file" 2>/dev/null)"; then
    a_skarr+=("$(stat -Lc '%n^%#a^%U^%G^%g' "$l_file")")
    echo "Found public key: $l_file"
  fi
done < <(find -L /etc/ssh -xdev -type f -print0 2>/dev/null)

echo ""

if (( ${#a_skarr[@]} == 0 )); then
  echo "No public SSH host keys found in /etc/ssh"
  echo ""
  echo "==================================================================="
  echo "Remediation completed for: $ITEM_NAME"
  echo "==================================================================="
  exit 0
fi

echo "Found ${#a_skarr[@]} public key file(s)"
echo ""
echo "Applying remediation..."
echo ""

# Process each public key file
while IFS="^" read -r l_file l_mode l_owner l_group l_gid; do
  l_out2=""
  echo "Processing: $l_file"
  
  # Determine max permissions (644 or more restrictive)
  l_pmask="0133"
  l_maxperm="$( printf '%o' $(( 0777 & ~$l_pmask )) )"
  
  # Check and fix mode
  if [ $(( $l_mode & $l_pmask )) -gt 0 ]; then
    l_out2="$l_out2\n - Mode: \"$l_mode\" should be mode: \"$l_maxperm\" or more restrictive"
    l_out2="$l_out2\n - Revoking excess permissions"
    echo " - Setting permissions to: $l_mfix"
    chmod "$l_mfix" "$l_file"
  else
    echo " - Permissions OK: $l_mode"
  fi
  
  # Check and fix owner
  if [ "$l_owner" != "root" ]; then
    l_out2="$l_out2\n - Owned by: \"$l_owner\" should be owned by \"root\""
    l_out2="$l_out2\n - Changing ownership to \"root\""
    echo " - Setting owner to: root"
    chown root "$l_file"
  else
    echo " - Owner OK: $l_owner"
  fi
  
  # Check and fix group (public keys should be root:root)
  if [ "$l_group" != "root" ]; then
    l_out2="$l_out2\n - Owned by group \"$l_group\" should be group owned by \"root\""
    l_out2="$l_out2\n - Changing group ownership to \"root\""
    echo " - Setting group to: root"
    chgrp root "$l_file"
  else
    echo " - Group OK: $l_group"
  fi
  
  [ -n "$l_out2" ] && l_output2="$l_output2\n - File: \"$l_file\"$l_out2"
  echo ""
done <<< "$(printf '%s\n' "${a_skarr[@]}")"

echo " - SUCCESS: Applied ownership and permissions"
echo ""

echo "Remediation of SSH public host key permissions complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

# Final verification and enforcement
final_status_pass=true

# Re-scan and verify all public keys
echo ""
echo "VERIFYING ALL SSH PUBLIC HOST KEY FILES:"
echo "----------------------------------------"

unset a_skarr
a_skarr=()

while IFS= read -r -d $'\0' l_file; do
  if grep -Pq -- '\h+no\h+comment\b' <<< "$(ssh-keygen -l -f "$l_file" 2>/dev/null)"; then
    a_skarr+=("$(stat -Lc '%n^%#a^%U^%G^%g' "$l_file")")
  fi
done < <(find -L /etc/ssh -xdev -type f -print0 2>/dev/null)

key_num=1
while IFS="^" read -r l_file l_mode l_owner l_group l_gid; do
  echo ""
  echo "$key_num. Verifying: $l_file"
  echo "--------------------------------------------"
  
  file_ok=true
  
  # Verify owner
  if [ "$l_owner" = "root" ]; then
    echo "PASS: Owner is root"
  else
    echo "FAIL: Owner is $l_owner (expected root) - fixing now"
    chown root "$l_file"
    file_ok=false
  fi
  
  # Verify group
  if [ "$l_group" = "root" ]; then
    echo "PASS: Group is root"
  else
    echo "FAIL: Group is $l_group (expected root) - fixing now"
    chgrp root "$l_file"
    file_ok=false
  fi
  
  # Verify permissions (644 or more restrictive)
  l_pmask="0133"
  l_maxperm="$( printf '%o' $(( 0777 & ~$l_pmask )) )"
  
  if [ $(( $l_mode & $l_pmask )) -eq 0 ]; then
    echo "PASS: Permissions are $l_mode ($l_maxperm or more restrictive)"
  else
    echo "FAIL: Permissions are $l_mode (expected $l_maxperm or more restrictive) - fixing now"
    chmod "$l_mfix" "$l_file"
    file_ok=false
  fi
  
  # Display proof
  echo "PROOF (full stat output):"
  stat "$l_file"
  
  if [ "$file_ok" = false ]; then
    final_status_pass=false
  fi
  
  ((key_num++))
done <<< "$(printf '%s\n' "${a_skarr[@]}")"

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues required correction during verification"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
