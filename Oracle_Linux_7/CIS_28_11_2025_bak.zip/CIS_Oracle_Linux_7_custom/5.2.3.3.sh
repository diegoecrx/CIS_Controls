#!/bin/bash

# Check if sudo log audit rule exists and fix if missing
echo "=== Checking sudo log audit configuration ==="

# Check current sudo log audit rules
auditctl -l | grep -E "/var/log/secure.*sudo_log_file" > /dev/null

if [ $? -eq 0 ]; then
    echo "PASS: Sudo log audit rule is active"
    auditctl -l | grep "/var/log/secure.*sudo_log_file"
else
    echo "FAIL: Sudo log audit rule is missing"
    echo "=== Applying fix ==="
    echo "-w /var/log/secure -p wa -k sudo_log_file" >> /etc/audit/rules.d/50-sudo-log.rules
    augenrules --load
    echo "=== Verification ==="
    auditctl -l | grep "/var/log/secure.*sudo_log_file" && echo "Fix applied successfully" || echo "Fix failed"
fi