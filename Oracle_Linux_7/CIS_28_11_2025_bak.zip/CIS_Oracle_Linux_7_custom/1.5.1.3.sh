#!/usr/bin/env bash
# Script: 1.5.1.3.sh
# Item: 1.5.1.3 Ensure SELinux policy is configured (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.3.sh"
ITEM_NAME="1.5.1.3 Ensure SELinux policy is configured (Automated)"
DESCRIPTION="This remediation ensures SELinux policy is configured to targeted."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current SELinux policy..."
    conf_file="/etc/selinux/config"
    if [ -f "$conf_file" ] && grep -q '^SELINUXTYPE=targeted' "$conf_file"; then
        echo "PASS: SELINUXTYPE=targeted set"
        echo "PROOF: $(grep '^SELINUXTYPE' "$conf_file")"
        return 0
    else
        echo "FAIL: SELINUXTYPE not targeted"
        echo "PROOF: $(grep '^SELINUXTYPE' "$conf_file" || echo "No entry")"
        return 1
    fi
}
# Function to fix
fix_selinux_policy() {
    echo "Applying fix..."
    conf_file="/etc/selinux/config"
    if grep -q '^SELINUXTYPE' "$conf_file"; then
        sed -i 's/^SELINUXTYPE=.*/SELINUXTYPE=targeted/' "$conf_file"
    else
        echo "SELINUXTYPE=targeted" >> "$conf_file"
    fi
    echo " - Set SELINUXTYPE=targeted"
}
# Main remediation
{
    if check_current_status; then
        echo "No fix needed"
    else
        fix_selinux_policy
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: SELinux policy configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="