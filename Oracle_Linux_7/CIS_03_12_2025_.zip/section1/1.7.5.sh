#!/usr/bin/env bash
# Script: 1.7.5.sh
# Item: 1.7.5 Ensure GDM screen locks cannot be overridden (Automated)
set -euo pipefail
SCRIPT_NAME="1.7.5.sh"
ITEM_NAME="1.7.5 Ensure GDM screen locks cannot be overridden (Automated)"
DESCRIPTION="This remediation ensures GDM screen lock settings cannot be overridden by users."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking GDM screen lock override protection..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo "PASS: GDM package is not installed"
        echo "PROOF: Neither gdm nor gdm3 packages found"
        return 0
    fi
    
    # Look for idle-delay to determine profile in use
    l_kfd=""
    if [ -d /etc/dconf/db/ ]; then
        l_kfd="/etc/dconf/db/$(grep -Psril '^\h*idle-delay\h*=\h*uint32\h+\d+\b' /etc/dconf/db/*/ 2>/dev/null | awk -F'/' '{split($(NF-1),a,".");print a[1]}' | head -1).d"
    fi
    
    # Look for lock-delay to determine profile in use
    l_kfd2=""
    if [ -d /etc/dconf/db/ ]; then
        l_kfd2="/etc/dconf/db/$(grep -Psril '^\h*lock-delay\h*=\h*uint32\h+\d+\b' /etc/dconf/db/*/ 2>/dev/null | awk -F'/' '{split($(NF-1),a,".");print a[1]}' | head -1).d"
    fi
    
    # Check if idle-delay is locked
    if [ -n "$l_kfd" ] && [ -d "$l_kfd" ]; then
        if ! grep -Prilq '^\h*\/org\/gnome\/desktop\/session\/idle-delay\b' "$l_kfd"/locks/* 2>/dev/null; then
            echo "FAIL: idle-delay setting is not locked"
            echo "PROOF: Lock file for idle-delay not found in $l_kfd/locks/"
            return 1
        fi
    else
        echo "FAIL: idle-delay setting not configured or directory not found"
        echo "PROOF: $l_kfd does not exist or idle-delay not set"
        return 1
    fi
    
    # Check if lock-delay is locked
    if [ -n "$l_kfd2" ] && [ -d "$l_kfd2" ]; then
        if ! grep -Prilq '^\h*\/org\/gnome\/desktop\/screensaver\/lock-delay\b' "$l_kfd2"/locks/* 2>/dev/null; then
            echo "FAIL: lock-delay setting is not locked"
            echo "PROOF: Lock file for lock-delay not found in $l_kfd2/locks/"
            return 1
        fi
    else
        echo "FAIL: lock-delay setting not configured or directory not found"
        echo "PROOF: $l_kfd2 does not exist or lock-delay not set"
        return 1
    fi
    
    echo "PASS: GDM screen lock settings are properly locked"
    echo "PROOF: Both idle-delay and lock-delay settings are locked"
    return 0
}
# Function to fix
fix_gdm_screen_lock_override() {
    echo "Applying fix..."
    
    # Check if GDM is installed
    if ! rpm -q gdm >/dev/null 2>&1 && ! rpm -q gdm3 >/dev/null 2>&1; then
        echo " - GDM not installed, no configuration needed"
        return
    fi
    
    # Look for idle-delay to determine profile in use
    l_kfd=""
    if [ -d /etc/dconf/db/ ]; then
        l_kfd="/etc/dconf/db/$(grep -Psril '^\h*idle-delay\h*=\h*uint32\h+\d+\b' /etc/dconf/db/*/ 2>/dev/null | awk -F'/' '{split($(NF-1),a,".");print a[1]}' | head -1).d"
    fi
    
    # Look for lock-delay to determine profile in use
    l_kfd2=""
    if [ -d /etc/dconf/db/ ]; then
        l_kfd2="/etc/dconf/db/$(grep -Psril '^\h*lock-delay\h*=\h*uint32\h+\d+\b' /etc/dconf/db/*/ 2>/dev/null | awk -F'/' '{split($(NF-1),a,".");print a[1]}' | head -1).d"
    fi
    
    # Lock idle-delay setting
    if [ -n "$l_kfd" ] && [ -d "$l_kfd" ]; then
        if ! grep -Prilq '^\h*\/org\/gnome\/desktop\/session\/idle-delay\b' "$l_kfd"/locks/* 2>/dev/null; then
            echo " - Creating entry to lock idle-delay"
            [ ! -d "$l_kfd/locks" ] && mkdir -p "$l_kfd/locks"
            {
                echo -e '\n# Lock desktop screensaver idle-delay setting'
                echo '/org/gnome/desktop/session/idle-delay'
            } >> "$l_kfd/locks/00-screensaver"
        fi
    else
        echo " - idle-delay is not set, cannot be locked"
        echo " - Please configure screen locks first (item 1.7.4)"
    fi
    
    # Lock lock-delay setting
    if [ -n "$l_kfd2" ] && [ -d "$l_kfd2" ]; then
        if ! grep -Prilq '^\h*\/org\/gnome\/desktop\/screensaver\/lock-delay\b' "$l_kfd2"/locks/* 2>/dev/null; then
            echo " - Creating entry to lock lock-delay"
            [ ! -d "$l_kfd2/locks" ] && mkdir -p "$l_kfd2/locks"
            {
                echo -e '\n# Lock desktop screensaver lock-delay setting'
                echo '/org/gnome/desktop/screensaver/lock-delay'
            } >> "$l_kfd2/locks/00-screensaver"
        fi
    else
        echo " - lock-delay is not set, cannot be locked"
        echo " - Please configure screen locks first (item 1.7.4)"
    fi
    
    # Update dconf
    dconf update 2>/dev/null || true
    echo " - Updated dconf database"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_gdm_screen_lock_override
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: GDM screen lock override protection configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="