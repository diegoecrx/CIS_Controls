#!/usr/bin/env bash

# Script: 1.1.1.7.sh
# Item: 1.1.1.7 Ensure udf kernel module is not available (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.1.7.sh"
ITEM_NAME="1.1.1.7 Ensure udf kernel module is not available (Automated)"
DESCRIPTION="This remediation ensures the udf kernel module is disabled and unavailable on the system."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    l_mname="udf" # set module name
    l_mtype="fs" # set module type
    l_mpath="/lib/modules/**/kernel/$l_mtype"
    l_mpname="$(tr '-' '_' <<< "$l_mname")"
    l_mndir="$(tr '-' '/' <<< "$l_mname")"

    echo "Checking current status of udf module..."
    echo "Module path: $l_mpath"
    echo ""

    # Display current module status
    if lsmod | grep "$l_mname" > /dev/null 2>&1; then
        echo "Current status: udf module is LOADED in running kernel"
    else
        echo "Current status: udf module is NOT LOADED in running kernel"
    fi

    # Check if module files exist
    module_exists=false
    for l_mdir in $l_mpath; do
        if [ -d "$l_mdir/$l_mndir" ] && [ -n "$(ls -A $l_mdir/$l_mndir 2>/dev/null)" ]; then
            module_exists=true
            echo "Module files found in: $l_mdir/$l_mndir"
        fi
    done

    echo ""
    echo "Applying remediation..."

    module_loadable_fix()
    {
        # If the module is currently loadable, add "install {MODULE_NAME} /bin/false" to a file in "/etc/modprobe.d"
        l_loadable="$(modprobe -n -v "$l_mname" 2>/dev/null || true)"
        [ "$(wc -l <<< "$l_loadable")" -gt "1" ] && l_loadable="$(grep -P -- "(^\h*install|\b$l_mname)\b" <<< "$l_loadable" || true)"
        if ! grep -Pq -- '^\h*install \/bin\/(true|false)' <<< "$l_loadable"; then
            echo " - Setting module: \"$l_mname\" to be not loadable"
            echo " - Creating/updating: /etc/modprobe.d/$l_mpname.conf"
            echo "install $l_mname /bin/false" >> /etc/modprobe.d/"$l_mpname".conf
            echo " - SUCCESS: Module configured as not loadable"
        else
            echo " - Module already configured as not loadable"
        fi
    }

    module_loaded_fix()
    {
        # If the module is currently loaded, unload the module
        if lsmod | grep "$l_mname" > /dev/null 2>&1; then
            echo " - Unloading module \"$l_mname\" from running kernel"
            if modprobe -r "$l_mname" 2>/dev/null; then
                echo " - SUCCESS: Module unloaded from running kernel"
            else
                echo " - WARNING: Could not unload module (may be in use)"
            fi
        else
            echo " - Module not loaded in running kernel"
        fi
    }

    module_deny_fix()
    {
        # If the module isn't deny listed, denylist the module
        if ! modprobe --showconfig | grep -Pq -- "^\h*blacklist\h+$l_mpname\b"; then
            echo " - Adding deny list for \"$l_mname\""
            echo " - Creating/updating: /etc/modprobe.d/$l_mpname.conf"
            echo "blacklist $l_mname" >> /etc/modprobe.d/"$l_mpname".conf
            echo " - SUCCESS: Module added to deny list"
        else
            echo " - Module already in deny list"
        fi
    }

    # Ensure modprobe.d directory exists
    mkdir -p /etc/modprobe.d

    # Check if the module exists on the system
    remediation_applied=false
    for l_mdir in $l_mpath; do
        if [ -d "$l_mdir/$l_mndir" ] && [ -n "$(ls -A $l_mdir/$l_mndir 2>/dev/null)" ]; then
            echo ""
            echo "Module: \"$l_mname\" exists in \"$l_mdir\""
            echo "Applying remediation measures..."
            
            # Always apply deny fix for any installed kernel
            module_deny_fix
            
            # Apply additional fixes for running kernel
            if [ "$l_mdir" = "/lib/modules/$(uname -r)/kernel/$l_mtype" ] || [ "$l_mdir" = "/lib/modules/$(uname -r)/kernel/$l_mtype/" ]; then
                module_loadable_fix
                module_loaded_fix
            fi
            remediation_applied=true
        else
            echo ""
            echo "Module: \"$l_mname\" doesn't exist in \"$l_mdir\""
        fi
    done

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No remediation necessary - udf module not found on system or pre-compiled into kernel"
        # Still ensure deny list is present as preventive measure
        module_deny_fix
    fi

    echo ""
    echo "Remediation of module: \"$l_mname\" complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Force reload of modprobe configuration
    if command -v update-initramfs >/dev/null 2>&1; then
        echo "Updating initramfs to ensure changes persist..."
        update-initramfs -u >/dev/null 2>&1
    fi
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify module is NOT LOADED
    echo ""
    echo "1. VERIFYING MODULE IS NOT LOADED:"
    echo "----------------------------------"
    lsmod_output=$(lsmod | grep "$l_mname" || true)
    if [ -n "$lsmod_output" ]; then
        echo "FAIL: udf module is STILL LOADED"
        echo "PROOF (lsmod output):"
        echo "$lsmod_output"
        echo " - Forcing unload..."
        modprobe -r "$l_mname" 2>/dev/null || true
        # Verify again after forced unload
        lsmod_output=$(lsmod | grep "$l_mname" || true)
        if [ -n "$lsmod_output" ]; then
            echo "WARNING: Could not unload udf module (may be in use)"
            echo "PROOF (lsmod output):"
            echo "$lsmod_output"
            final_status_pass=false
        else
            echo "PASS: udf module is NOT LOADED (forced unload successful)"
            echo "PROOF (lsmod shows no udf):"
            lsmod | head -10
        fi
    else
        echo "PASS: udf module is NOT LOADED"
        echo "PROOF (lsmod shows no udf):"
        lsmod | head -10
    fi
    
    # PROOF 2: Verify module is in DENY LIST
    echo ""
    echo "2. VERIFYING MODULE IS IN DENY LIST:"
    echo "------------------------------------"
    deny_list_check=$(modprobe --showconfig | grep -P -- "^\h*blacklist\h+$l_mpname\b" || true)
    if [ -n "$deny_list_check" ]; then
        echo "PASS: udf module is in deny list"
        echo "PROOF (modprobe --showconfig):"
        echo "$deny_list_check"
    else
        echo "FAIL: udf module is NOT in deny list - adding now"
        echo "blacklist $l_mname" >> /etc/modprobe.d/"$l_mpname".conf
        # Verify after adding
        deny_list_check=$(modprobe --showconfig | grep -P -- "^\h*blacklist\h+$l_mpname\b" || true)
        if [ -n "$deny_list_check" ]; then
            echo "PASS: udf module is in deny list (added)"
            echo "PROOF (modprobe --showconfig):"
            echo "$deny_list_check"
        else
            echo "FAIL: Still not in deny list after attempt"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify file exists in /etc/modprobe.d/
    echo ""
    echo "3. VERIFYING CONFIGURATION FILE EXISTS:"
    echo "---------------------------------------"
    config_file="/etc/modprobe.d/$l_mpname.conf"
    if [ -f "$config_file" ]; then
        echo "PASS: Configuration file exists: $config_file"
        echo "PROOF (file contents):"
        cat "$config_file"
    else
        echo "FAIL: Configuration file missing: $config_file"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify module is configured as NOT LOADABLE
    echo ""
    echo "4. VERIFYING MODULE IS CONFIGURED AS NOT LOADABLE:"
    echo "--------------------------------------------------"
    loadable_check=$(modprobe -n -v "$l_mname" 2>/dev/null || true)
    if echo "$loadable_check" | grep -q "/bin/false"; then
        echo "PASS: udf module configured as not loadable"
        echo "PROOF (modprobe -n -v output):"
        echo "$loadable_check"
    else
        echo "FAIL: udf module NOT configured as not loadable - fixing now"
        # Remove any existing configuration
        grep -v "install $l_mname" /etc/modprobe.d/"$l_mpname".conf > /tmp/modprobe_temp.conf 2>/dev/null || true
        [ -f /tmp/modprobe_temp.conf ] && mv /tmp/modprobe_temp.conf /etc/modprobe.d/"$l_mpname".conf 2>/dev/null || true
        # Add correct configuration
        echo "install $l_mname /bin/false" >> /etc/modprobe.d/"$l_mpname".conf
        # Verify after fixing
        loadable_check=$(modprobe -n -v "$l_mname" 2>/dev/null || true)
        if echo "$loadable_check" | grep -q "/bin/false"; then
            echo "PASS: udf module configured as not loadable (fixed)"
            echo "PROOF (modprobe -n -v output):"
            echo "$loadable_check"
        else
            echo "FAIL: Still not configured as not loadable after attempt"
            final_status_pass=false
        fi
    fi
    
    # PROOF 5: Attempt to load module (should fail)
    echo ""
    echo "5. VERIFYING MODULE CANNOT BE LOADED:"
    echo "-------------------------------------"
    if modprobe "$l_mname" 2>&1 | grep -q -E "(cannot find module|invalid parameter|not found|Operation not permitted)"; then
        echo "PASS: Module loading correctly blocked"
        echo "PROOF (modprobe attempt output):"
        modprobe "$l_mname" 2>&1 || true
    else
        echo "WARNING: Module might still be loadable"
        modprobe_output=$(modprobe "$l_mname" 2>&1 || true)
        echo "PROOF (modprobe attempt output):"
        echo "$modprobe_output"
        # Unload if it somehow loaded
        modprobe -r "$l_mname" 2>/dev/null || true
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="