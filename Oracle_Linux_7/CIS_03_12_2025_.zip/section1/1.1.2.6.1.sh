#!/bin/bash

set -euo pipefail

LOG_MOUNT_POINT="/var/log"
FSTAB_FILE="/etc/fstab"
MOUNT_INFO="/proc/self/mountinfo"
LOOP_DEVICE_IMAGE="/var_log_partition.img"

echo "==================================================================="
echo "Item: 1.1.2.6.1 Ensure separate partition exists for /var/log"
echo "==================================================================="
echo

check_partition() {
    echo "=== Checking partition status ==="
    if grep -q "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$MOUNT_INFO" 2>/dev/null; then
        echo "PASS: $LOG_MOUNT_POINT is a separate partition"
        grep "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$MOUNT_INFO"
        exit 0
    else
        echo "FAIL: $LOG_MOUNT_POINT is not a separate partition"
        return 1
    fi
}

show_disk_space() {
    echo "=== Disk space analysis ==="
    echo "Overall disk usage:"
    df -h
    echo
    echo "Root space:"
    df -h /
    echo
    echo "Available in root:"
    df -m / | awk 'NR==2 {print $4 " MB available"}'
}

cleanup_space() {
    echo "=== Cleaning disk space ==="
    if command -v yum >/dev/null 2>&1; then
        yum clean all >/dev/null 2>&1
        echo "Cleaned yum cache"
    fi
    
    find /tmp -type f -atime +1 -delete 2>/dev/null || true
    find /var/tmp -type f -atime +1 -delete 2>/dev/null || true
    echo "Cleaned temp files"
    
    if command -v journalctl >/dev/null 2>&1; then
        journalctl --vacuum-size=100M >/dev/null 2>&1 || true
        echo "Reduced journal size"
    fi
}

create_partition() {
    echo "=== Creating partition ==="
    
    local available_mb
    available_mb=$(df -m / | awk 'NR==2 {print $4}')
    local size_mb=512
    
    if [[ $available_mb -gt 2048 ]]; then
        size_mb=1024
    elif [[ $available_mb -gt 1024 ]]; then
        size_mb=768
    elif [[ $available_mb -lt 512 ]]; then
        cleanup_space
        available_mb=$(df -m / | awk 'NR==2 {print $4}')
        if [[ $available_mb -lt 512 ]]; then
            echo "ERROR: Insufficient disk space after cleanup"
            exit 1
        fi
        size_mb=512
    fi
    
    echo "Creating ${size_mb}MB partition"
    
    mkdir -p "$LOG_MOUNT_POINT"
    
    if [[ -f "$LOOP_DEVICE_IMAGE" ]]; then
        rm -f "$LOOP_DEVICE_IMAGE"
    fi
    
    dd if=/dev/zero of="$LOOP_DEVICE_IMAGE" bs=1M count=$size_mb status=progress
    mkfs.ext4 -F "$LOOP_DEVICE_IMAGE"
    
    grep -v "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$FSTAB_FILE" > "${FSTAB_FILE}.tmp" 2>/dev/null || true
    [[ -f "${FSTAB_FILE}.tmp" ]] && mv "${FSTAB_FILE}.tmp" "$FSTAB_FILE"
    
    echo "$LOOP_DEVICE_IMAGE $LOG_MOUNT_POINT auto loop,defaults,nosuid,nodev,noexec 0 2" >> "$FSTAB_FILE"
    
    mount "$LOG_MOUNT_POINT"
    
    echo "Partition created and mounted"
}

verify_fix() {
    echo "=== Verifying fix ==="
    if grep -q "[[:space:]]${LOG_MOUNT_POINT}[[:space:]]" "$MOUNT_INFO" 2>/dev/null; then
        echo "SUCCESS: $LOG_MOUNT_POINT is now a separate partition"
        mount | grep "$LOG_MOUNT_POINT"
    else
        echo "FAILED: Partition creation unsuccessful"
        exit 1
    fi
}

if [[ $EUID -ne 0 ]]; then
    echo "ERROR: Root required"
    exit 1
fi

if check_partition; then
    exit 0
fi

show_disk_space
create_partition
verify_fix