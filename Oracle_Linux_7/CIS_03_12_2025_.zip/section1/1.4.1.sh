#!/bin/bash

# Check current ASLR status
echo "Current runtime ASLR value:"
sysctl -n kernel.randomize_va_space

# Check persistent configuration
echo "Persistent ASLR configuration:"
grep -r "kernel.randomize_va_space" /etc/sysctl.conf /etc/sysctl.d/ 2>/dev/null || echo "No persistent configuration found"

# Enable ASLR immediately
sysctl -w kernel.randomize_va_space=2

# Configure persistent ASLR
echo "kernel.randomize_va_space = 2" > /etc/sysctl.d/60-aslr.conf
sysctl -p /etc/sysctl.d/60-aslr.conf

# Verify remediation
echo "Post-remediation runtime ASLR value:"
sysctl -n kernel.randomize_va_space

echo "Post-remediation persistent configuration:"
grep -r "kernel.randomize_va_space" /etc/sysctl.conf /etc/sysctl.d/ 2>/dev/null