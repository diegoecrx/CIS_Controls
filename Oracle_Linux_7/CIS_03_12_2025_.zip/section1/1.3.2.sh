#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

[ -f /boot/grub2/grub.cfg ] && chown root:root /boot/grub2/grub.cfg
[ -f /boot/grub2/grub.cfg ] && chmod u-x,go-rwx /boot/grub2/grub.cfg

[ -f /boot/grub2/grubenv ] && chown root:root /boot/grub2/grubenv
[ -f /boot/grub2/grubenv ] && chmod u-x,go-rwx /boot/grub2/grubenv

[ -f /boot/grub2/user.cfg ] && chown root:root /boot/grub2/user.cfg
[ -f /boot/grub2/user.cfg ] && chmod u-x,go-rwx /boot/grub2/user.cfg

[ -f /boot/grub2/grub.cfg.*.rpmsave ] && chown root:root /boot/grub2/grub.cfg.*.rpmsave
[ -f /boot/grub2/grub.cfg.*.rpmsave ] && chmod u-x,go-rwx /boot/grub2/grub.cfg.*.rpmsave

find /boot/grub2/ -name "*.cfg" -o -name "*.rpmsave" -o -name "grubenv" | xargs -I {} stat -c "%n %a %U %G" {} | while read file perms owner group; do
    if [[ "$perms" -le 600 ]] && [[ "$owner" == "root" ]] && [[ "$group" == "root" ]]; then
        echo "PASS: $file permissions correctly set"
    else
        echo "FAIL: $file has incorrect permissions/ownership"
        exit 1
    fi
done

echo "pass"