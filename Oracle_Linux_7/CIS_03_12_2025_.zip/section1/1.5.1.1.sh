#!/usr/bin/env bash
# Script: 1.5.1.1.sh
# Item: 1.5.1.1 Ensure SELinux is installed (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.1.sh"
ITEM_NAME="1.5.1.1 Ensure SELinux is installed (Automated)"
DESCRIPTION="This remediation ensures SELinux is installed using yum."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking if SELinux is installed..."
    if rpm -q libselinux >/dev/null 2>&1; then
        echo "PASS: libselinux is installed"
        echo "PROOF: $(rpm -q libselinux)"
        return 0
    else
        echo "FAIL: libselinux is not installed"
        echo "PROOF: rpm -q libselinux returned not installed"
        return 1
    fi
}
# Function to install
install_selinux() {
    echo "Installing SELinux..."
    yum install -y libselinux >/dev/null 2>&1
    echo " - Installed libselinux"
}
# Main remediation
{
    if check_current_status; then
        echo "No installation needed"
    else
        install_selinux
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: SELinux installed"
    else
        echo "FAIL: SELinux not installed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="