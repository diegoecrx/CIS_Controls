#!/usr/bin/env bash
# Script: 1.6.6.sh
# Item: 1.6.6 Ensure access to /etc/issue.net is configured (Automated)
set -euo pipefail
SCRIPT_NAME="1.6.6.sh"
ITEM_NAME="1.6.6 Ensure access to /etc/issue.net is configured (Automated)"
DESCRIPTION="This remediation ensures access to /etc/issue.net is configured by setting permissions or removing the file."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/issue.net access..."
    issue_net_file=$(readlink -e /etc/issue.net 2>/dev/null || true)
    if [ -z "$issue_net_file" ]; then
        echo "PASS: /etc/issue.net does not exist"
        echo "PROOF: readlink -e /etc/issue.net returned empty"
        return 0
    fi
    owner=$(stat -c '%U:%G' "$issue_net_file")
    perm=$(stat -c '%a' "$issue_net_file")
    if [ "$owner" = "root:root" ] && [ "$perm" = "644" ] || [ "$perm" = "444" ]; then
        echo "PASS: Correct permissions and ownership"
        echo "PROOF: Owner $owner, Perm $perm"
        return 0
    else
        echo "FAIL: Incorrect permissions or ownership"
        echo "PROOF: Owner $owner, Perm $perm"
        return 1
    fi
}
# Function to fix
fix_issue_net() {
    echo "Applying fix..."
    issue_net_file=$(readlink -e /etc/issue.net 2>/dev/null || true)
    if [ -n "$issue_net_file" ]; then
        chown root:root "$issue_net_file"
        chmod u-x,go-wx "$issue_net_file"
        echo " - Set permissions on $issue_net_file"
    else
        echo " - No file to fix"
    fi
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_issue_net
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Access configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="