#!/usr/bin/env bash

# Script: 1.1.2.1.3.sh
# Item: 1.1.2.1.3 Ensure nosuid option set on /tmp partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.1.3.sh"
ITEM_NAME="1.1.2.1.3 Ensure nosuid option set on /tmp partition (Automated)"
DESCRIPTION="This remediation ensures the nosuid option is set on the /tmp partition to prevent execution of setuid programs."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /tmp mount options..."
    echo ""

    # Display current mount status and options
    echo "Current /tmp mount information:"
    mount | grep -E '\s/tmp\s' || echo "No separate /tmp mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /tmp:"
    grep -E '\s/tmp\s' /etc/fstab || echo "No /tmp entry in /etc/fstab"
    echo ""

    echo "Applying remediation..."

    # Function to check if nosuid is set in mount options
    check_nosuid_mount() {
        local mount_output="$1"
        # Extract options between parentheses and check for nosuid
        if echo "$mount_output" | grep -q -E '\([^)]*nosuid[^)]*\)'; then
            return 0
        else
            return 1
        fi
    }

    # Function to check if nosuid is set in fstab options
    check_nosuid_fstab() {
        local fstab_entry="$1"
        # Check if nosuid is in the 4th field (mount options)
        if echo "$fstab_entry" | awk '$4 ~ /nosuid/ {exit 0} {exit 1}'; then
            return 0
        else
            return 1
        fi
    }

    # Function to update fstab with nosuid option
    update_fstab_nosuid()
    {
        # Check if /tmp entry exists in fstab
        if grep -q -E '\s/tmp\s' /etc/fstab; then
            echo " - Checking /tmp entry in /etc/fstab for nosuid option"
            
            # Get the current /tmp entry
            current_entry=$(grep -E '\s/tmp\s' /etc/fstab)
            
            # Check if nosuid option is already present
            if check_nosuid_fstab "$current_entry"; then
                echo " - nosuid option already present in /etc/fstab"
                return 0
            fi
            
            echo " - Updating /tmp entry in /etc/fstab to include nosuid option"
            
            # Create temporary fstab without /tmp entry
            grep -v -E '\s/tmp\s' /etc/fstab > /etc/fstab.tmp
            
            # Add nosuid to the mount options field (4th field)
            updated_entry=$(echo "$current_entry" | awk '
            {
                for(i=1; i<=NF; i++) {
                    if(i==4) {
                        # Add nosuid to mount options
                        if($i ~ /nosuid/) {
                            # Already has nosuid, just print
                            print $0
                        } else {
                            # Handle options with and without commas
                            if($i ~ /,$/) {
                                $i = $i "nosuid,"
                            } else if($i ~ /defaults/) {
                                # Replace defaults with defaults,nosuid
                                $i = $i ",nosuid"
                            } else {
                                $i = $i ",nosuid"
                            }
                            # Reconstruct the line
                            for(j=1; j<=NF; j++) {
                                printf "%s", $j
                                if(j<NF) printf " "
                            }
                            printf "\n"
                        }
                    }
                }
            }')
            
            # If awk processing failed, use a simpler approach
            if [ -z "$updated_entry" ]; then
                # Simple sed approach - add nosuid to options
                updated_entry=$(echo "$current_entry" | sed 's/\(defaults[^[:space:]]*\)/\1,nosuid/' | sed 's/,,/,/g')
            fi
            
            echo "$updated_entry" >> /etc/fstab.tmp
            
            # Backup original and replace
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo " - SUCCESS: Updated /tmp entry in /etc/fstab with nosuid option"
            return 0
        else
            echo " - WARNING: No /tmp entry found in /etc/fstab. Please ensure /tmp is configured as separate partition first."
            return 1
        fi
    }

    # Function to remount /tmp with nosuid option
    remount_tmp_nosuid()
    {
        echo " - Remounting /tmp with current options"
        
        # Check if /tmp is mounted as separate filesystem
        if mount | grep -q -E '\s/tmp\s'; then
            # Get current mount info
            mount_output=$(mount | grep -E '\s/tmp\s')
            
            # Check if nosuid is already set in current mount
            if check_nosuid_mount "$mount_output"; then
                echo " - nosuid option already set on current /tmp mount"
            else
                # Remount with options from fstab
                if mount -o remount /tmp; then
                    echo " - SUCCESS: /tmp remounted with fstab options"
                else
                    echo " - WARNING: Could not remount /tmp"
                    return 1
                fi
            fi
        else
            echo " - WARNING: /tmp is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    update_fstab_nosuid
    remount_tmp_nosuid

    echo ""
    echo "Remediation of nosuid option on /tmp partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /tmp is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /tmp IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "---------------------------------------------------"
    mount_output=$(mount | grep -E '\s/tmp\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /tmp is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /tmp is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nosuid option in current mount
    echo ""
    echo "2. VERIFYING nosuid OPTION IN CURRENT MOUNT:"
    echo "-------------------------------------------"
    mount_output=$(mount | grep -E '\s/tmp\s' || true)
    if check_nosuid_mount "$mount_output"; then
        echo "PASS: nosuid option set on current /tmp mount"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: nosuid option NOT set on current /tmp mount"
        final_status_pass=false
    fi
    
    # PROOF 3: Verify nosuid option in fstab
    echo ""
    echo "3. VERIFYING nosuid OPTION IN /etc/fstab:"
    echo "----------------------------------------"
    fstab_entry=$(grep -E '\s/tmp\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if check_nosuid_fstab "$fstab_entry"; then
            echo "PASS: nosuid option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nosuid option NOT found in /etc/fstab"
            final_status_pass=false
        fi
    else
        echo "FAIL: No /tmp entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_nosuid=false
    mount_has_nosuid=false
    
    fstab_entry=$(grep -E '\s/tmp\s' /etc/fstab || true)
    mount_output=$(mount | grep -E '\s/tmp\s' || true)
    
    if [ -n "$fstab_entry" ] && check_nosuid_fstab "$fstab_entry"; then
        fstab_has_nosuid=true
    fi
    
    if [ -n "$mount_output" ] && check_nosuid_mount "$mount_output"; then
        mount_has_nosuid=true
    fi
    
    if $fstab_has_nosuid && $mount_has_nosuid; then
        echo "PASS: nosuid option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab: $(echo "$fstab_entry" | awk '{print $4}')"
        echo "  mount: $(echo "$mount_output" | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif $fstab_has_nosuid && ! $mount_has_nosuid; then
        echo "FAIL: nosuid in fstab but not in current mount"
        final_status_pass=false
    elif ! $fstab_has_nosuid && $mount_has_nosuid; then
        echo "FAIL: nosuid in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nosuid option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Verify nosuid effectiveness by checking for setuid files
    echo ""
    echo "5. VERIFYING NO SETUID FILES IN /tmp:"
    echo "------------------------------------"
    setuid_files=$(find /tmp -type f -perm /4000 2>/dev/null | wc -l)
    if [ "$setuid_files" -eq 0 ]; then
        echo "PASS: No setuid files found in /tmp"
        echo "PROOF: find /tmp -type f -perm /4000 returned 0 files"
    else
        echo "WARNING: Found $setuid_files setuid files in /tmp"
        echo "PROOF (first 5 setuid files):"
        find /tmp -type f -perm /4000 2>/dev/null | head -5
        echo " - Removing setuid bits from files in /tmp"
        find /tmp -type f -perm /4000 -exec chmod u-s {} \; 2>/dev/null || true
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="