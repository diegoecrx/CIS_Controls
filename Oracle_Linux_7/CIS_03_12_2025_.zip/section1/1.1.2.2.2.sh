#!/usr/bin/env bash

# Script: 1.1.2.2.2.sh
# Item: 1.1.2.2.2 Ensure nodev option set on /dev/shm partition (Automated)

set -euo pipefail

SCRIPT_NAME="1.1.2.2.2.sh"
ITEM_NAME="1.1.2.2.2 Ensure nodev option set on /dev/shm partition (Automated)"
DESCRIPTION="This remediation ensures the nodev option is set on the /dev/shm partition to prevent device files."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current /dev/shm mount options..."
    echo ""

    # Display current mount status and options
    echo "Current /dev/shm mount information:"
    mount | grep -E '\s/dev/shm\s' || echo "No separate /dev/shm mount found"
    echo ""

    # Check current fstab entry
    echo "Current /etc/fstab entries for /dev/shm:"
    grep -E '\s/dev/shm\s' /etc/fstab || echo "No /dev/shm entry in /etc/fstab"
    echo ""

    echo "Applying remediation..."

    # Function to update fstab with nodev option
    update_fstab_nodev()
    {
        # Check if /dev/shm entry exists in fstab
        if grep -q -E '\s/dev/shm\s' /etc/fstab; then
            echo " - Checking /dev/shm entry in /etc/fstab for nodev option"
            
            # Get the current /dev/shm entry
            current_entry=$(grep -E '\s/dev/shm\s' /etc/fstab)
            
            # Check if nodev option is already present
            if echo "$current_entry" | grep -q 'nodev'; then
                echo " - nodev option already present in /etc/fstab"
                return 0
            else
                echo " - Adding nodev option to /etc/fstab"
                
                # Create temporary fstab without /dev/shm entry
                grep -v -E '\s/dev/shm\s' /etc/fstab > /etc/fstab.tmp
                
                # Add nodev option to the mount options field (4th field)
                updated_entry=$(echo "$current_entry" | awk '
                {
                    for(i=1; i<=NF; i++) {
                        if(i==4) {
                            # Add nodev to mount options if not already present
                            if($i ~ /nodev/) {
                                print $0
                            } else {
                                # Handle options with and without commas
                                if($i ~ /,$/) {
                                    gsub(/,$/, "", $i)
                                    $i = $i ",nodev"
                                } else {
                                    $i = $i ",nodev"
                                }
                                # Reconstruct the line
                                for(j=1; j<=NF; j++) {
                                    printf "%s", $j
                                    if(j<NF) printf " "
                                }
                                printf "\n"
                            }
                        }
                    }
                }')
                
                # If awk processing failed, use simpler approach
                if [ -z "$updated_entry" ]; then
                    # Simple approach: just add nodev to the options
                    updated_entry=$(echo "$current_entry" | sed 's/\(defaults,[^[:space:]]*\)/\1,nodev/' 2>/dev/null || echo "$current_entry")
                fi
                
                echo "$updated_entry" >> /etc/fstab.tmp
                
                # Backup original and replace
                cp /etc/fstab /etc/fstab.bak
                mv /etc/fstab.tmp /etc/fstab
                echo " - SUCCESS: Updated /dev/shm entry in /etc/fstab with nodev option"
            fi
        else
            echo " - WARNING: No /dev/shm entry found in /etc/fstab. Please ensure /dev/shm is configured as separate partition first."
            return 1
        fi
    }

    # Function to remount /dev/shm with nodev option
    remount_shm_nodev()
    {
        echo " - Checking /dev/shm mount for nodev option"
        
        # Check if /dev/shm is mounted as separate filesystem
        if mount | grep -q -E '\s/dev/shm\s'; then
            # Get current mount options
            mount_line=$(mount | grep -E '\s/dev/shm\s')
            
            # Check if nodev is already set in current mount
            if echo "$mount_line" | grep -q 'nodev'; then
                echo " - nodev option already set on current /dev/shm mount"
            else
                echo " - Remounting /dev/shm with nodev option"
                # Add nodev to current options and remount
                if mount -o remount,nodev /dev/shm; then
                    echo " - SUCCESS: /dev/shm remounted with nodev option"
                else
                    echo " - WARNING: Could not remount /dev/shm with nodev option"
                    return 1
                fi
            fi
        else
            echo " - WARNING: /dev/shm is not mounted as separate filesystem"
            return 1
        fi
    }

    # Apply remediation steps
    if update_fstab_nodev; then
        remount_shm_nodev
    else
        echo " - Skipping remount due to missing /dev/shm configuration"
    fi

    echo ""
    echo "Remediation of nodev option on /dev/shm partition complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify /dev/shm is mounted as separate filesystem
    echo ""
    echo "1. VERIFYING /dev/shm IS MOUNTED AS SEPARATE FILESYSTEM:"
    echo "-------------------------------------------------------"
    mount_output=$(mount | grep -E '\s/dev/shm\s' || true)
    if [ -n "$mount_output" ]; then
        echo "PASS: /dev/shm is mounted as separate filesystem"
        echo "PROOF (mount output):"
        echo "$mount_output"
    else
        echo "FAIL: /dev/shm is NOT mounted as separate filesystem"
        final_status_pass=false
    fi
    
    # PROOF 2: Verify nodev option in current mount
    echo ""
    echo "2. VERIFYING nodev OPTION IN CURRENT MOUNT:"
    echo "------------------------------------------"
    mount_line=$(mount | grep -E '\s/dev/shm\s' || true)
    if echo "$mount_line" | grep -q 'nodev'; then
        echo "PASS: nodev option set on current /dev/shm mount"
        echo "PROOF (mount output):"
        echo "$mount_line"
    else
        echo "FAIL: nodev option NOT set on current /dev/shm mount - attempting remount"
        if mount -o remount,nodev /dev/shm 2>/dev/null; then
            mount_line=$(mount | grep -E '\s/dev/shm\s' || true)
            if echo "$mount_line" | grep -q 'nodev'; then
                echo "PASS: nodev option now set on /dev/shm mount"
                echo "PROOF (mount output):"
                echo "$mount_line"
            else
                echo "FAIL: Could not set nodev option on /dev/shm mount"
                final_status_pass=false
            fi
        else
            echo "FAIL: Could not remount /dev/shm with nodev option"
            final_status_pass=false
        fi
    fi
    
    # PROOF 3: Verify nodev option in fstab
    echo ""
    echo "3. VERIFYING nodev OPTION IN /etc/fstab:"
    echo "---------------------------------------"
    fstab_entry=$(grep -E '\s/dev/shm\s' /etc/fstab || true)
    if [ -n "$fstab_entry" ]; then
        if echo "$fstab_entry" | grep -q 'nodev'; then
            echo "PASS: nodev option found in /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            echo "$fstab_entry"
        else
            echo "FAIL: nodev option NOT found in /etc/fstab - updating now"
            # Remove existing entry
            grep -v -E '\s/dev/shm\s' /etc/fstab > /etc/fstab.tmp
            # Add nodev to mount options (4th field)
            if echo "$fstab_entry" | grep -q 'defaults,'; then
                updated_entry=$(echo "$fstab_entry" | sed 's/defaults,/defaults,nodev,/' | sed 's/,,/,/g')
            else
                # If no defaults, add nodev to beginning of options
                updated_entry=$(echo "$fstab_entry" | awk '{$4=$4",nodev"; print}')
            fi
            echo "$updated_entry" >> /etc/fstab.tmp
            cp /etc/fstab /etc/fstab.bak
            mv /etc/fstab.tmp /etc/fstab
            echo "PASS: nodev option added to /etc/fstab"
            echo "PROOF (/etc/fstab entry):"
            grep -E '\s/dev/shm\s' /etc/fstab
        fi
    else
        echo "FAIL: No /dev/shm entry found in /etc/fstab"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify mount options are consistent
    echo ""
    echo "4. VERIFYING MOUNT OPTIONS CONSISTENCY:"
    echo "--------------------------------------"
    fstab_has_nodev=$(grep -E '\s/dev/shm\s' /etc/fstab | grep -o 'nodev' | head -1 || true)
    mount_has_nodev=$(mount | grep -E '\s/dev/shm\s' | grep -o 'nodev' | head -1 || true)
    
    if [ -n "$fstab_has_nodev" ] && [ -n "$mount_has_nodev" ]; then
        echo "PASS: nodev option consistent between fstab and current mount"
        echo "PROOF:"
        echo "  fstab options: $(grep -E '\s/dev/shm\s' /etc/fstab | awk '{print $4}')"
        echo "  mount options: $(mount | grep -E '\s/dev/shm\s' | grep -o -E '\([^)]+\)' | tr -d '()')"
    elif [ -n "$fstab_has_nodev" ] && [ -z "$mount_has_nodev" ]; then
        echo "FAIL: nodev in fstab but not in current mount"
        final_status_pass=false
    elif [ -z "$fstab_has_nodev" ] && [ -n "$mount_has_nodev" ]; then
        echo "FAIL: nodev in current mount but not in fstab"
        final_status_pass=false
    else
        echo "FAIL: nodev option missing in both fstab and current mount"
        final_status_pass=false
    fi

    # PROOF 5: Verify no device files in /dev/shm
    echo ""
    echo "5. VERIFYING NO DEVICE FILES IN /dev/shm:"
    echo "-----------------------------------------"
    device_files=$(find /dev/shm -type c -o -type b 2>/dev/null | wc -l)
    if [ "$device_files" -eq 0 ]; then
        echo "PASS: No device files found in /dev/shm"
        echo "PROOF: find /dev/shm -type c -o -type b returned 0 files"
    else
        echo "WARNING: Found $device_files device files in /dev/shm"
        echo "PROOF (first 5 device files):"
        find /dev/shm -type c -o -type b 2>/dev/null | head -5
        echo " - Removing device files from /dev/shm"
        find /dev/shm -type c -o -type b -exec rm -f {} \; 2>/dev/null || true
    fi

    # PROOF 6: Test shared memory functionality
    echo ""
    echo "6. TESTING SHARED MEMORY FUNCTIONALITY:"
    echo "---------------------------------------"
    if command -v ipcs >/dev/null 2>&1; then
        echo "PASS: Shared memory tools available (ipcs)"
        echo "PROOF (ipcs output - first 5 lines):"
        ipcs -m | head -5
    else
        echo "INFO: ipcs command not available, shared memory functionality test skipped"
    fi

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: All remediation steps completed and verified with proofs"
    else
        echo ""
        echo "WARNING: Some issues may require manual intervention"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="