#!/usr/bin/env bash
# Script: 1.3.3.sh
# Item: 1.3.3 Ensure authentication required for single user mode (Automated)
set -euo pipefail
SCRIPT_NAME="1.3.3.sh"
ITEM_NAME="1.3.3 Ensure authentication required for single user mode (Automated)"
DESCRIPTION="This remediation ensures authentication required for single user mode by editing rescue.service and emergency.service."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking current status..."
    for service in rescue.service emergency.service; do
        file="/usr/lib/systemd/system/$service"
        if [ -f "$file" ]; then
            exec_line=$(grep '^ExecStart=' "$file" || true)
            if echo "$exec_line" | grep -q '/sbin/sulogin' || echo "$exec_line" | grep -q '/usr/sbin/sulogin'; then
                echo "PASS: Correct ExecStart in $file"
                echo "PROOF: $exec_line"
            else
                echo "FAIL: Incorrect ExecStart in $file"
                echo "PROOF: $exec_line"
                return 1
            fi
        else
            echo "FAIL: $file not found"
            return 1
        fi
    done
    return 0
}
# Function to fix services
fix_services() {
    echo "Applying fix..."
    target_line='ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"'
    for service in rescue.service emergency.service; do
        file="/usr/lib/systemd/system/$service"
        if [ -f "$file" ]; then
            sed -i '/^ExecStart=/d' "$file"
            echo "$target_line" >> "$file"
            echo " - Fixed $file"
        fi
    done
    systemctl daemon-reload
}
# Main remediation
{
    if check_current_status; then
        echo "No fix needed"
    else
        fix_services
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: Authentication required"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="