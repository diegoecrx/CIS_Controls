#!/bin/bash
# fix-rcu-stalls.sh - Fix RCU kernel stalls and tune system parameters

set -euo pipefail

echo "=== Fixing RCU Kernel Stalls ==="
echo "Start time: $(date)"
echo

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Function to diagnose current RCU status
diagnose_rcu() {
    echo "=== Current RCU Status ==="
    
    # Check kernel messages for RCU issues
    echo "Recent RCU messages in kernel log:"
    dmesg | grep -i "rcu" | tail -20
    
    echo ""
    
    # Check current RCU parameters
    echo "Current RCU kernel parameters:"
    for param in /proc/sys/kernel/rcu*; do
        if [ -f "$param" ]; then
            echo "$(basename $param): $(cat $param)"
        fi
    done 2>/dev/null || echo "No RCU parameters found"
    
    echo ""
}

# Function to tune kernel parameters for RCU
tune_kernel_parameters() {
    echo "=== Tuning Kernel Parameters ==="
    
    # Backup current sysctl configuration
    cp /etc/sysctl.conf /etc/sysctl.conf.backup.$(date +%Y%m%d_%H%M%S)
    
    # Add RCU tuning parameters
    cat >> /etc/sysctl.conf << 'EOF'

# ===========================================
# RCU (Read-Copy-Update) Tuning
# ===========================================

# Increase RCU stall timeout (default 60 seconds)
kernel.rcu_cpu_stall_timeout = 300

# Reduce RCU grace period for expedited operations
kernel.rcu_expedited = 0

# Normal RCU callback processing
kernel.rcu_normal = 1

# RCU callback queue length
kernel.rcu_cb_max_blimit = 10000

# ===========================================
# General Kernel Tuning for Stability
# ===========================================

# Increase PID limit
kernel.pid_max = 4194304

# Increase system-wide maximum number of threads
kernel.threads-max = 524288

# Increase maximum memory map areas per process
vm.max_map_count = 262144

# Increase file handles
fs.file-max = 2097152
fs.nr_open = 1048576

# Increase socket buffer sizes
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.core.optmem_max = 20480
net.core.netdev_max_backlog = 5000

# Increase connection tracking
net.netfilter.nf_conntrack_max = 524288
net.netfilter.nf_conntrack_tcp_timeout_established = 86400

# Increase inotify watches
fs.inotify.max_user_watches = 524288
fs.inotify.max_user_instances = 1024

# Increase message queues
kernel.msgmax = 8192
kernel.msgmnb = 65536

# Increase shared memory
kernel.shmmax = 68719476736
kernel.shmall = 4294967296

# ===========================================
# Virtual Memory Tuning
# ===========================================

# Reduce swapping tendency
vm.swappiness = 10
vm.vfs_cache_pressure = 50
vm.dirty_ratio = 10
vm.dirty_background_ratio = 5

# Increase dirty writeback time
vm.dirty_writeback_centisecs = 5000
vm.dirty_expire_centisecs = 30000

EOF
    
    # Apply sysctl changes
    sysctl -p >/dev/null 2>&1
    
    echo "Kernel parameters tuned for RCU stability"
    echo ""
}

# Function to tune CPU scheduler and interrupts
tune_cpu_scheduler() {
    echo "=== Tuning CPU Scheduler ==="
    
    # Disable CPU frequency scaling for stability
    if command -v cpupower &>/dev/null; then
        echo "Setting CPU governor to performance..."
        cpupower frequency-set -g performance >/dev/null 2>&1 || true
    fi
    
    # Set CPU scaling governor via sysfs
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        if [ -f "$cpu" ]; then
            echo "performance" > "$cpu" 2>/dev/null || true
        fi
    done
    
    # Increase RCU priority for kthreads
    echo "Setting RCU kthread priority..."
    for rcu_thread in /sys/kernel/rcu*/rcu*/rcu*; do
        if [ -d "$rcu_thread" ]; then
            echo "Setting high priority for RCU threads"
            # Try to set nice value
            pids=$(ps -eLf | grep rcu | awk '{print $4}' | sort -u)
            for pid in $pids; do
                renice -n -20 -p "$pid" 2>/dev/null || true
            done
        fi
    done 2>/dev/null || true
    
    echo "CPU scheduler tuned"
    echo ""
}

# Function to check and fix potential causes of RCU stalls
check_rcu_causes() {
    echo "=== Checking Potential RCU Stall Causes ==="
    
    # 1. Check for softlockups
    echo "1. Checking for CPU softlockups..."
    if dmesg | grep -q "softlockup"; then
        echo "   WARNING: Softlockups detected"
        # Increase softlockup threshold
        echo 30 > /proc/sys/kernel/watchdog_thresh 2>/dev/null || true
        echo "kernel.watchdog_thresh = 30" >> /etc/sysctl.conf
    else
        echo "   OK: No softlockups detected"
    fi
    
    # 2. Check CPU load
    echo "2. Checking CPU load..."
    load=$(uptime | awk -F'load average:' '{print $2}')
    echo "   Current load: $load"
    
    # 3. Check memory pressure
    echo "3. Checking memory pressure..."
    free -h
    echo ""
    
    # 4. Check I/O wait
    echo "4. Checking I/O wait..."
    iostat -x 1 2 | tail -5
    echo ""
    
    # 5. Check for kernel tasks stuck in D state
    echo "5. Checking for processes in D state (uninterruptible sleep)..."
    ps aux | awk '$8 ~ /D/ {print $0}' | head -10
    if ps aux | grep -q " D "; then
        echo "   WARNING: Processes in D state detected"
    else
        echo "   OK: No processes in D state"
    fi
    echo ""
}

# Function to optimize system services
optimize_services() {
    echo "=== Optimizing System Services ==="
    
    # Temporarily stop unnecessary services during tuning
    echo "Temporarily stopping non-critical services..."
    
    # List of services to temporarily stop (adjust based on your needs)
    SERVICES_TO_STOP=""
    
    # Check what's running and might be causing issues
    echo "Top CPU-consuming processes:"
    ps aux --sort=-%cpu | head -10
    echo ""
    
    echo "Top memory-consuming processes:"
    ps aux --sort=-%mem | head -10
    echo ""
    
    # Restart auditd with better configuration if it's causing issues
    if systemctl is-active auditd >/dev/null 2>&1; then
        echo "Reconfiguring auditd service..."
        
        # Create optimized auditd config
        cat > /etc/audit/auditd.conf << 'EOF'
log_file = /var/log/audit/audit.log
log_format = RAW
log_group = root
priority_boost = 4
flush = INCREMENTAL_ASYNC
freq = 100
num_logs = 5
disp_qos = lossy
dispatcher = /sbin/audispd
name_format = NONE
max_log_file = 50
max_log_file_action = ROTATE
space_left = 100
space_left_action = SYSLOG
action_mail_acct = root
admin_space_left = 50
admin_space_left_action = SUSPEND
disk_full_action = SUSPEND
disk_error_action = SUSPEND
tcp_listen_queue = 5
tcp_max_per_addr = 1
tcp_client_max_idle = 0
enable_krb5 = no
EOF
        
        systemctl restart auditd
        echo "Auditd reconfigured"
    fi
    
    echo "Services optimized"
    echo ""
}

# Function to create monitoring and recovery script
create_rcu_monitor() {
    echo "=== Creating RCU Monitoring Script ==="
    
    cat > /usr/local/bin/monitor-rcu.sh << 'EOF'
#!/bin/bash
# RCU System Monitor

echo "=== RCU System Monitor ==="
echo "Time: $(date)"
echo "Uptime: $(uptime)"
echo

# Check RCU stalls in kernel log
echo "Recent RCU messages in dmesg:"
dmesg | tail -100 | grep -i "rcu" | tail -10
echo

# Check current RCU parameters
echo "Current RCU parameters:"
for param in /proc/sys/kernel/rcu*; do
    if [ -f "$param" ]; then
        echo "  $(basename $param): $(cat $param 2>/dev/null)"
    fi
done 2>/dev/null || echo "  No RCU parameters found"
echo

# Check system load
echo "System Load:"
echo "  $(uptime)"
echo "  Load average: $(cat /proc/loadavg)"
echo

# Check CPU states
echo "CPU States:"
mpstat 1 1 | tail -2
echo

# Check memory
echo "Memory:"
free -h
echo

# Check processes in D state
echo "Processes in D state (uninterruptible sleep):"
ps aux | awk '$8 ~ /D/ {count++} END {print "  Count: " count}'
if ps aux | grep -q " D "; then
    echo "  Processes:"
    ps aux | awk '$8 ~ /D/ {print "    " $0}'
fi
echo

# Check RCU kthreads
echo "RCU kthreads status:"
ps -eLf | grep -E "rcu|kthread" | grep -v grep | head -10
echo

# Check for potential issues
echo "Potential Issues Check:"
echo -n "  RCU stalls in last hour: "
dmesg --since="-1 hour" | grep -c "rcu.*stall"
echo -n "  Softlockups in last hour: "
dmesg --since="-1 hour" | grep -c "softlockup"
echo -n "  Hardlockups in last hour: "
dmesg --since="-1 hour" | grep -c "hardlockup"

EOF
    
    chmod +x /usr/local/bin/monitor-rcu.sh
    
    # Create emergency recovery script
    cat > /usr/local/bin/emergency-rcu-fix.sh << 'EOF'
#!/bin/bash
# Emergency RCU Recovery

echo "=== Emergency RCU Recovery ==="
echo "Time: $(date)"

# 1. Increase RCU stall timeout immediately
echo 600 > /proc/sys/kernel/rcu_cpu_stall_timeout 2>/dev/null || true

# 2. Trigger RCU grace period
echo 1 > /sys/kernel/debug/rcu/rcu_panic 2>/dev/null || true

# 3. Wake up RCU kthreads
for pid in $(ps -eLf | grep rcu | awk '{print $4}' | sort -u); do
    kill -CONT $pid 2>/dev/null || true
done

# 4. Reset CPU scheduler
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu" ] && echo "performance" > "$cpu" 2>/dev/null || true
done

# 5. Sync filesystems
sync

# 6. Drop caches (carefully)
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "Recovery actions completed"
echo "Check system with: monitor-rcu.sh"

EOF
    
    chmod +x /usr/local/bin/emergency-rcu-fix.sh
    
    echo "Monitoring scripts created:"
    echo "  /usr/local/bin/monitor-rcu.sh"
    echo "  /usr/local/bin/emergency-rcu-fix.sh"
    echo ""
}

# Function to update kernel if necessary
update_kernel_if_needed() {
    echo "=== Checking Kernel Version ==="
    
    current_kernel=$(uname -r)
    echo "Current kernel: $current_kernel"
    
    # Check if we're running an old kernel
    if [[ "$current_kernel" =~ ^2\. ]] || [[ "$current_kernel" =~ ^3\. ]]; then
        echo "WARNING: Running an older kernel version"
        echo "Consider updating to a newer kernel for better RCU handling"
        echo ""
        echo "To update kernel on RHEL/CentOS:"
        echo "  yum update kernel -y"
        echo "  reboot"
    else
        echo "Kernel version appears recent"
    fi
    
    echo ""
}

# Main execution
main() {
    echo "Starting comprehensive RCU stall fix..."
    echo
    
    # Step 1: Diagnose current state
    diagnose_rcu
    
    # Step 2: Check potential causes
    check_rcu_causes
    
    # Step 3: Tune kernel parameters
    tune_kernel_parameters
    
    # Step 4: Tune CPU scheduler
    tune_cpu_scheduler
    
    # Step 5: Optimize services
    optimize_services
    
    # Step 6: Create monitoring scripts
    create_rcu_monitor
    
    # Step 7: Check kernel version
    update_kernel_if_needed
    
    echo "=== Fix Complete ==="
    echo ""
    echo "Summary of actions taken:"
    echo "1. Increased RCU stall timeout to 300 seconds"
    echo "2. Tuned kernel parameters for better RCU performance"
    echo "3. Optimized CPU scheduler"
    echo "4. Created monitoring and emergency recovery scripts"
    echo ""
    echo "Recommended next steps:"
    echo "1. Monitor system: monitor-rcu.sh"
    echo "2. Reboot if problems persist"
    echo "3. Check for hardware issues if RCU stalls continue"
    echo ""
    echo "If RCU stalls continue after reboot, consider:"
    echo "- Running hardware diagnostics"
    echo "- Reducing system load"
    echo "- Disabling unnecessary kernel modules"
    echo "- Updating to latest kernel"
    echo ""
}

# Run main function
main

echo "Script completed at: $(date)"
echo "Reboot recommended for changes to take full effect"
echo ""
echo "To reboot:"
echo "  systemctl reboot"