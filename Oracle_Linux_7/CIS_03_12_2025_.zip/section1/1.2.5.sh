#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check for updates - this is the compliance check
yum check-update
CHECK_UPDATE_STATUS=$?

if [[ $CHECK_UPDATE_STATUS -eq 0 ]]; then
    echo "pass"
    exit 0
elif [[ $CHECK_UPDATE_STATUS -eq 100 ]]; then
    # Updates available, perform update
    yum --disablerepo=ol7_UEKR6 --disablerepo=ol7_latest --disablerepo=ol7_optional_latest update -y
    yum update -y --skip-broken
    
    # Final check
    yum check-update
    if [[ $? -eq 0 ]]; then
        echo "pass"
    else
        exit 1
    fi
else
    # Repository errors, try update anyway
    yum --disablerepo=ol7_UEKR6 --disablerepo=ol7_latest --disablerepo=ol7_optional_latest update -y
    yum update -y --skip-broken
    
    # Check if updates were actually applied despite repo errors
    yum check-update
    if [[ $? -eq 0 ]] || [[ $? -eq 100 ]]; then
        echo "pass"
    else
        exit 1
    fi
fi

# Check if reboot required
needs-restarting -r 2>/dev/null