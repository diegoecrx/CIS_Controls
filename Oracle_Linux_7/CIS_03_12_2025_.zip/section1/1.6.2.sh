#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

echo "=== /etc/issue Configuration Compliance Fix ==="
echo "Policy: 1.6.2 Ensure local login warning banner is configured properly"
echo ""

# Show current issue content that's failing
echo "CURRENT /etc/issue CONTENT (CAUSING FAILURE):"
echo "----------------------------------------"
cat /etc/issue
echo "----------------------------------------"
echo ""

echo "COMPLIANCE ERROR: 'All activities may be' != 'All activities performed on'"
echo "The checker expects EXACT text: 'All activities performed on'"
echo ""

# Remove existing content and create new issue file with compliance-approved content
echo "1. Creating new /etc/issue with exact compliance-approved content..."
echo "All activities performed on this system will be monitored." > /etc/issue

# Set proper permissions
chmod 644 /etc/issue
chown root:root /etc/issue

echo ""
echo "=== VERIFICATION ==="

# Verify the exact content match
REQUIRED_FIRST_LINE="All activities performed on this system will be monitored."
ACTUAL_FIRST_LINE=$(head -n1 /etc/issue)

echo "REQUIRED FIRST LINE: '$REQUIRED_FIRST_LINE'"
echo "ACTUAL FIRST LINE:   '$ACTUAL_FIRST_LINE'"
echo ""

if [[ "$ACTUAL_FIRST_LINE" == "$REQUIRED_FIRST_LINE" ]]; then
    echo "✓ CRITICAL FIX: First line now matches compliance requirement"
else
    echo "✗ FAILED: First line still doesn't match"
    exit 1
fi

# Check line count
LINE_COUNT=$(wc -l < /etc/issue)
if [[ $LINE_COUNT -eq 1 ]]; then
    echo "✓ Single line only (no extra content)"
else
    echo "✗ Multiple lines detected: $LINE_COUNT"
    exit 1
fi

# Check for prohibited content
if ! grep -q "\\[mrsv]" /etc/issue; then
    echo "✓ No prohibited [mrsv] content"
else
    echo "✗ Prohibited [mrsv] content found"
    exit 1
fi

# Verify permissions
PERMISSIONS=$(stat -c %a /etc/issue)
OWNERSHIP=$(stat -c %U:%G /etc/issue)

if [[ $PERMISSIONS == "644" ]]; then
    echo "✓ Correct permissions: 644"
else
    echo "✗ Incorrect permissions: $PERMISSIONS"
    exit 1
fi

if [[ $OWNERSHIP == "root:root" ]]; then
    echo "✓ Correct ownership: root:root"
else
    echo "✗ Incorrect ownership: $OWNERSHIP"
    exit 1
fi

echo ""
echo "=== NEW /etc/issue CONTENT ==="
echo "----------------------------------------"
cat /etc/issue
echo "----------------------------------------"
echo ""

echo "=== COMPLIANCE CHECK SIMULATION ==="
echo "PASSED - mrsv not included in /etc/issue"
echo "The following file(s) do not contain \"\\[mrsv]\": "
echo "      /etc/issue"
echo ""
echo "PASSED - banner text"
echo "First line: 'All activities performed on this system will be monitored.'"

echo ""
echo "=== RESULT ==="
echo "pass"