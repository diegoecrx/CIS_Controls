#!/usr/bin/env bash
# Script: 1.5.1.8.sh
# Item: 1.5.1.8 Ensure SETroubleshoot is not installed (Automated)
set -euo pipefail
SCRIPT_NAME="1.5.1.8.sh"
ITEM_NAME="1.5.1.8 Ensure SETroubleshoot is not installed (Automated)"
DESCRIPTION="This remediation ensures SETroubleshoot is not installed using yum remove."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking if SETroubleshoot is installed..."
    if rpm -q setroubleshoot >/dev/null 2>&1; then
        echo "FAIL: setroubleshoot is installed"
        echo "PROOF: $(rpm -q setroubleshoot)"
        return 1
    else
        echo "PASS: setroubleshoot is not installed"
        echo "PROOF: rpm -q setroubleshoot returned not installed"
        return 0
    fi
}
# Function to uninstall
uninstall_setroubleshoot() {
    echo "Uninstalling SETroubleshoot..."
    yum remove -y setroubleshoot >/dev/null 2>&1
    echo " - Removed setroubleshoot"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        uninstall_setroubleshoot
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: SETroubleshoot not installed"
    else
        echo "FAIL: SETroubleshoot still installed"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="