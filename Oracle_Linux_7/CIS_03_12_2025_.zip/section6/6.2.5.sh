#!/usr/bin/env bash
# Script: 6.2.5.sh
# Item: 6.2.5 Ensure no duplicate GIDs exist (Automated)
set -euo pipefail
SCRIPT_NAME="6.2.5.sh"
ITEM_NAME="6.2.5 Ensure no duplicate GIDs exist (Automated)"
DESCRIPTION="This remediation ensures no duplicate GIDs exist in /etc/group."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check for duplicate GIDs
check_duplicate_gids() {
    echo "Checking for duplicate GIDs in /etc/group..."
    duplicate_gids=""
    
    # Extract all GIDs and find duplicates
    gid_list=$(cut -d: -f3 /etc/group | sort -n)
    while read -r gid; do
        # Count occurrences of this GID
        count=$(cut -d: -f3 /etc/group | grep -c "^$gid$" || true)
        if [ "$count" -gt 1 ]; then
            # Get all groups with this GID
            groups_with_gid=$(awk -F: -v g="$gid" '$3 == g {print $1}' /etc/group | tr '\n' ',')
            duplicate_gids="$duplicate_gids\n - GID: $gid appears in groups: $groups_with_gid"
        fi
    done <<< "$gid_list"
    
    if [ -z "$duplicate_gids" ]; then
        echo "PASS: No duplicate GIDs found"
        echo "PROOF: All GIDs are unique in /etc/group"
        return 0
    else
        echo "FAIL: Found duplicate GIDs:"
        echo -e "$duplicate_gids"
        return 1
    fi
}
# Function to fix duplicate GIDs
fix_duplicate_gids() {
    echo "Fixing duplicate GIDs..."
    
    # Get the next available GID starting from the highest current GID
    max_gid=$(cut -d: -f3 /etc/group | sort -n | tail -1)
    next_gid=$((max_gid + 1))
    
    # Find all duplicate GIDs
    gid_list=$(cut -d: -f3 /etc/group | sort -n -u)
    while read -r gid; do
        count=$(cut -d: -f3 /etc/group | grep -c "^$gid$" || true)
        if [ "$count" -gt 1 ]; then
            # Get all groups with this duplicate GID
            duplicate_groups=$(awk -F: -v g="$gid" '$3 == g {print $1}' /etc/group)
            
            # Keep the first group, reassign others to new GIDs
            first=true
            while read -r group_name; do
                if [ "$first" = true ]; then
                    echo " - Keeping group \"$group_name\" with GID $gid"
                    first=false
                else
                    echo " - Reassigning group \"$group_name\" from GID $gid to GID $next_gid"
                    groupmod -g "$next_gid" "$group_name"
                    next_gid=$((next_gid + 1))
                fi
            done <<< "$duplicate_groups"
        fi
    done <<< "$gid_list"
}
# Main remediation
{
    gid_ok=true
    if ! check_duplicate_gids; then
        gid_ok=false
    fi
    if [ "$gid_ok" = true ]; then
        echo "No remediation needed"
    else
        fix_duplicate_gids
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    final_pass=true
    if ! check_duplicate_gids; then
        final_pass=false
    fi
    if [ "$final_pass" = true ]; then
        echo "SUCCESS: No duplicate GIDs exist"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
