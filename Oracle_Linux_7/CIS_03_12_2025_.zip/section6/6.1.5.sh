#!/usr/bin/env bash
# Script: 6.1.5.sh
# Item: 6.1.5 Ensure permissions on /etc/shadow are configured (Automated)
set -euo pipefail

SCRIPT_NAME="6.1.5.sh"
ITEM_NAME="6.1.5 Ensure permissions on /etc/shadow are configured (Automated)"
DESCRIPTION="This remediation ensures permissions on /etc/shadow are configured correctly (0000 root:root)."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status
check_current_status() {
    echo "Checking /etc/shadow permissions and ownership..."
    
    # Check if /etc/shadow exists
    if [ ! -f /etc/shadow ]; then
        echo "FAIL: /etc/shadow does not exist"
        echo "PROOF: File /etc/shadow not found"
        return 1
    fi
    
    # Get current permissions, owner, and group
    current_perms=$(stat -c "%a" /etc/shadow)
    current_owner=$(stat -c "%U" /etc/shadow)
    current_group=$(stat -c "%G" /etc/shadow)
    
    # Check permissions (should be 0000 - stat shows as 0 without leading zeros)
    if [ "$current_perms" != "0" ] && [ "$current_perms" != "000" ] && [ "$current_perms" != "0000" ]; then
        echo "FAIL: /etc/shadow has incorrect permissions"
        echo "PROOF: Current permissions are $current_perms (should be 0000)"
        return 1
    fi
    
    # Check owner (should be root)
    if [ "$current_owner" != "root" ]; then
        echo "FAIL: /etc/shadow has incorrect owner"
        echo "PROOF: Current owner is $current_owner (should be root)"
        return 1
    fi
    
    # Check group (should be root)
    if [ "$current_group" != "root" ]; then
        echo "FAIL: /etc/shadow has incorrect group"
        echo "PROOF: Current group is $current_group (should be root)"
        return 1
    fi
    
    echo "PASS: /etc/shadow permissions and ownership properly configured"
    echo "PROOF: Access: (0000/----------) Uid: (0/root) Gid: (0/root)"
    return 0
}

# Function to fix
fix_shadow_permissions() {
    echo "Applying fix..."
    
    # Check if /etc/shadow exists
    if [ ! -f /etc/shadow ]; then
        echo " - ERROR: /etc/shadow does not exist - this is a critical system file"
        return 1
    fi
    
    # Get current status for reporting
    current_perms=$(stat -c "%a" /etc/shadow)
    current_owner=$(stat -c "%U" /etc/shadow)
    current_group=$(stat -c "%G" /etc/shadow)
    
    echo " - Current status: permissions=$current_perms owner=$current_owner group=$current_group"
    
    # Fix ownership first (must be done before changing permissions to 0000)
    if [ "$current_owner" != "root" ] || [ "$current_group" != "root" ]; then
        echo " - Setting correct ownership on /etc/shadow"
        chown root:root /etc/shadow
    else
        echo " - Ownership already correct (root:root)"
    fi
    
    # Fix permissions (set to 0000 - no access for anyone except root via ownership)
    if [ "$current_perms" != "0" ] && [ "$current_perms" != "000" ] && [ "$current_perms" != "0000" ]; then
        echo " - Setting correct permissions on /etc/shadow"
        chmod 0000 /etc/shadow
    else
        echo " - Permissions already correct (0000)"
    fi
    
    # Verify changes
    new_perms=$(stat -c "%a" /etc/shadow)
    new_owner=$(stat -c "%U" /etc/shadow)
    new_group=$(stat -c "%G" /etc/shadow)
    
    echo " - New status: permissions=$new_perms owner=$new_owner group=$new_group"
    echo " - /etc/shadow permissions and ownership configuration completed"
}

# Main remediation
{
    echo "Initial Status Check:"
    echo "====================="
    if check_current_status; then
        echo "✓ No remediation needed - system is already compliant"
    else
        echo ""
        echo "Remediation Required:"
        echo "===================="
        fix_shadow_permissions
    fi
    
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo ""
        echo "SUCCESS: /etc/shadow permissions and ownership properly configured"
        echo ""
        echo "Summary:"
        echo "  ✓ /etc/shadow permissions: 0000 (---------)"
        echo "  ✓ /etc/shadow owner: root"
        echo "  ✓ /etc/shadow group: root"
        echo "  ✓ Shadow file is properly secured"
    else
        echo ""
        echo "WARNING: Some issues may require manual attention"
        echo ""
        echo "Manual commands:"
        echo "  chown root:root /etc/shadow"
        echo "  chmod 0000 /etc/shadow"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="