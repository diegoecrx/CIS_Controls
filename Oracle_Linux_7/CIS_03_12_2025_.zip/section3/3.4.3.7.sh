#!/usr/bin/env bash
# Script: 3.4.3.7.sh
# Item: 3.4.3.7 Ensure nftables default deny firewall policy (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.7.sh"
ITEM_NAME="3.4.3.7 Ensure nftables default deny firewall policy (Automated)"
DESCRIPTION="This remediation ensures nftables default deny firewall policy is configured for input, forward, and output chains."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking nftables default deny policy configuration..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    fi
    
    # Find inet table
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo "FAIL: No inet table found"
        echo "PROOF: No inet table exists"
        return 1
    fi
    
    # Check policies for each chain
    table_info=$(nft list table inet "$table_name" 2>/dev/null)
    
    # Check input chain policy
    if echo "$table_info" | grep -A2 "chain input" | grep -q "policy accept"; then
        echo "FAIL: Input chain has accept policy instead of drop"
        echo "PROOF: Input chain policy is accept"
        return 1
    fi
    
    # Check forward chain policy
    if echo "$table_info" | grep -A2 "chain forward" | grep -q "policy accept"; then
        echo "FAIL: Forward chain has accept policy instead of drop"
        echo "PROOF: Forward chain policy is accept"
        return 1
    fi
    
    # Check output chain policy
    if echo "$table_info" | grep -A2 "chain output" | grep -q "policy accept"; then
        echo "FAIL: Output chain has accept policy instead of drop"
        echo "PROOF: Output chain policy is accept"
        return 1
    fi
    
    # Verify all chains have drop policy
    if ! echo "$table_info" | grep -A2 "chain input" | grep -q "policy drop"; then
        echo "FAIL: Input chain does not have drop policy"
        echo "PROOF: Input chain policy is not drop"
        return 1
    fi
    
    if ! echo "$table_info" | grep -A2 "chain forward" | grep -q "policy drop"; then
        echo "FAIL: Forward chain does not have drop policy"
        echo "PROOF: Forward chain policy is not drop"
        return 1
    fi
    
    if ! echo "$table_info" | grep -A2 "chain output" | grep -q "policy drop"; then
        echo "FAIL: Output chain does not have drop policy"
        echo "PROOF: Output chain policy is not drop"
        return 1
    fi
    
    echo "PASS: nftables default deny policy properly configured"
    echo "PROOF: All chains (input, forward, output) have drop policy in table $table_name"
    return 0
}
# Function to fix
fix_nftables_default_deny() {
    echo "Applying fix..."
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo " - Installing nftables package first"
        yum install -y nftables
    fi
    
    # Find or create an inet table
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}')
    if [ -z "$table_name" ]; then
        echo " - Creating inet filter table"
        nft create table inet filter
        table_name="filter"
    fi
    
    # Ensure all base chains exist
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo " - Creating input base chain"
        nft create chain inet "$table_name" input '{ type filter hook input priority 0 ; }'
    fi
    
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain forward"; then
        echo " - Creating forward base chain"
        nft create chain inet "$table_name" forward '{ type filter hook forward priority 0 ; }'
    fi
    
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain output"; then
        echo " - Creating output base chain"
        nft create chain inet "$table_name" output '{ type filter hook output priority 0 ; }'
    fi
    
    echo " - Setting default deny policy for all chains in table: $table_name"
    
    # Set drop policy for input chain
    echo " - Setting drop policy for input chain"
    nft chain inet "$table_name" input '{ policy drop ; }'
    
    # Set drop policy for forward chain
    echo " - Setting drop policy for forward chain"
    nft chain inet "$table_name" forward '{ policy drop ; }'
    
    # Set drop policy for output chain
    echo " - Setting drop policy for output chain"
    nft chain inet "$table_name" output '{ policy drop ; }'
    
    # Update configuration file to make persistent
    if [ -f /etc/nftables.conf ]; then
        # Backup existing config
        cp /etc/nftables.conf /etc/nftables.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    fi
    
    # Save current ruleset to configuration file
    echo " - Saving configuration to /etc/nftables.conf"
    cat > /etc/nftables.conf << EOF
#!/usr/sbin/nft -f

flush ruleset

$(nft list ruleset)
EOF
    
    echo " - nftables default deny policy configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_default_deny
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables default deny policy properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="