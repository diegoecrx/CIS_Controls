#!/usr/bin/env bash
# Script: 3.4.4.3.6.sh
# Item: 3.4.4.3.6 Ensure ip6tables is enabled and active (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.4.3.6.sh"
ITEM_NAME="3.4.4.3.6 Ensure ip6tables is enabled and active (Automated)"
DESCRIPTION="This remediation ensures ip6tables service is enabled and active."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking ip6tables service status..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo "PASS: IPv6 is not enabled on the system"
        echo "PROOF: /proc/sys/net/ipv6 directory does not exist"
        return 0
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo "FAIL: iptables package is not installed"
        echo "PROOF: rpm -q iptables returned no package found"
        return 1
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo "FAIL: iptables-services package is not installed"
        echo "PROOF: rpm -q iptables-services returned no package found"
        return 1
    fi
    
    # Check if ip6tables service is masked
    if systemctl is-masked ip6tables.service >/dev/null 2>&1; then
        echo "FAIL: ip6tables service is masked"
        echo "PROOF: systemctl is-masked ip6tables.service shows masked"
        return 1
    fi
    
    # Check if ip6tables service is enabled
    if ! systemctl is-enabled ip6tables.service >/dev/null 2>&1; then
        echo "FAIL: ip6tables service is not enabled"
        echo "PROOF: systemctl is-enabled ip6tables.service shows disabled"
        return 1
    fi
    
    # Check if ip6tables service is running
    if ! systemctl is-active ip6tables.service >/dev/null 2>&1; then
        echo "FAIL: ip6tables service is not running"
        echo "PROOF: systemctl is-active ip6tables.service shows inactive"
        return 1
    fi
    
    echo "PASS: ip6tables service properly enabled and active"
    echo "PROOF: ip6tables.service is enabled and active"
    return 0
}
# Function to fix
fix_ip6tables_service() {
    echo "Applying fix..."
    
    # Check if IPv6 is enabled
    if [ ! -d /proc/sys/net/ipv6 ]; then
        echo " - IPv6 is not enabled, no configuration needed"
        return
    fi
    
    # Check if iptables package is installed
    if ! rpm -q iptables >/dev/null 2>&1; then
        echo " - Installing iptables package"
        yum install -y iptables
    fi
    
    # Check if iptables-services package is installed
    if ! rpm -q iptables-services >/dev/null 2>&1; then
        echo " - Installing iptables-services package"
        yum install -y iptables-services
    fi
    
    # Unmask ip6tables service if masked
    if systemctl is-masked ip6tables.service >/dev/null 2>&1; then
        echo " - Unmasking ip6tables service"
        systemctl unmask ip6tables.service
    fi
    
    # Enable and start ip6tables service
    if ! systemctl is-enabled ip6tables.service >/dev/null 2>&1 || ! systemctl is-active ip6tables.service >/dev/null 2>&1; then
        echo " - Enabling and starting ip6tables service"
        systemctl --now enable ip6tables.service
    fi
    
    echo " - ip6tables service configuration completed"
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_ip6tables_service
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: ip6tables service properly enabled and active"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="