#!/usr/bin/env bash
# Script: 3.4.3.5.sh
# Item: 3.4.3.5 Ensure nftables loopback traffic is configured (Automated)
set -euo pipefail
SCRIPT_NAME="3.4.3.5.sh"
ITEM_NAME="3.4.3.5 Ensure nftables loopback traffic is configured (Automated)"
DESCRIPTION="This remediation ensures nftables loopback traffic is properly configured for both IPv4 and IPv6."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to execute and show commands
execute_command() {
    local cmd="$1"
    local description="$2"
    
    echo "COMMAND: $cmd"
    echo "DESCRIPTION: $description"
    echo "OUTPUT:"
    eval "$cmd"
    local exit_code=$?
    echo "EXIT CODE: $exit_code"
    echo ""
    return $exit_code
}

# Function to check current status
check_current_status() {
    echo "Checking nftables loopback traffic configuration..."
    echo ""
    
    # Check if nftables package is installed
    echo "COMMAND: rpm -q nftables"
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "OUTPUT: Package not installed"
        echo "FAIL: nftables package is not installed"
        echo "PROOF: rpm -q nftables returned no package found"
        return 1
    else
        nft_version=$(rpm -q nftables --queryformat '%{VERSION}-%{RELEASE}')
        echo "OUTPUT: Package installed - $nft_version"
    fi
    
    # Check if nft command works
    echo "COMMAND: nft list tables"
    if ! nft list tables 2>/dev/null; then
        echo "OUTPUT: Error listing tables"
        echo "FAIL: Cannot list nftables tables"
        echo "PROOF: nft list tables command failed"
        return 1
    fi
    
    # Find inet table
    echo "COMMAND: nft list tables | grep 'table inet' | head -1"
    table_info=$(nft list tables 2>/dev/null | grep "table inet" | head -1)
    if [ -z "$table_info" ]; then
        echo "OUTPUT: No inet table found"
        echo "FAIL: No inet table found"
        echo "PROOF: No inet table exists"
        return 1
    else
        table_name=$(echo "$table_info" | awk '{print $3}')
        echo "OUTPUT: Found table: $table_info"
        echo "Table name: $table_name"
    fi
    
    # Check if input chain exists
    echo "COMMAND: nft list table inet $table_name 2>/dev/null | grep -q 'chain input'"
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo "OUTPUT: Input chain not found"
        echo "FAIL: Input chain does not exist in table $table_name"
        echo "PROOF: No input chain found"
        return 1
    else
        echo "OUTPUT: Input chain exists"
    fi
    
    # Get current ruleset for the input chain
    echo "COMMAND: nft list chain inet $table_name input"
    input_rules=$(nft list chain inet "$table_name" input 2>/dev/null)
    echo "OUTPUT:"
    echo "$input_rules"
    
    # Check for loopback interface accept rule
    echo "COMMAND: Check for 'iif lo accept' rule"
    if ! echo "$input_rules" | grep -q "iif.*lo.*accept"; then
        echo "OUTPUT: Rule not found"
        echo "FAIL: Loopback interface accept rule not found"
        echo "PROOF: No 'iif lo accept' rule in input chain"
        return 1
    else
        echo "OUTPUT: Rule found"
    fi
    
    # Check for IPv4 loopback source address drop rule
    echo "COMMAND: Check for 'ip saddr 127.0.0.0/8 drop' rule"
    if ! echo "$input_rules" | grep -q "ip saddr 127.0.0.0/8.*drop"; then
        echo "OUTPUT: Rule not found"
        echo "FAIL: IPv4 loopback source address drop rule not found"
        echo "PROOF: No 'ip saddr 127.0.0.0/8 drop' rule in input chain"
        return 1
    else
        echo "OUTPUT: Rule found"
    fi
    
    # Check IPv6 loopback rule if IPv6 is enabled
    echo "COMMAND: Check if IPv6 is enabled - test -d /proc/sys/net/ipv6"
    if [ -d /proc/sys/net/ipv6 ]; then
        echo "OUTPUT: IPv6 is enabled"
        echo "COMMAND: Check for 'ip6 saddr ::1 drop' rule"
        if ! echo "$input_rules" | grep -q "ip6 saddr ::1.*drop"; then
            echo "OUTPUT: Rule not found"
            echo "FAIL: IPv6 loopback source address drop rule not found"
            echo "PROOF: No 'ip6 saddr ::1 drop' rule in input chain"
            return 1
        else
            echo "OUTPUT: Rule found"
        fi
    else
        echo "OUTPUT: IPv6 is not enabled - skipping IPv6 check"
    fi
    
    echo "PASS: nftables loopback traffic properly configured"
    echo "PROOF: All required loopback rules exist in table $table_name"
    return 0
}

# Function to fix
fix_nftables_loopback() {
    echo "Applying fix..."
    echo ""
    
    # Check if nftables package is installed
    if ! rpm -q nftables >/dev/null 2>&1; then
        echo "Installing nftables package first..."
        execute_command "yum install -y nftables" "Install nftables package"
    fi
    
    # Find or create an inet table
    echo "Finding or creating inet table..."
    table_name=$(nft list tables 2>/dev/null | grep "table inet" | head -1 | awk '{print $3}' || echo "")
    if [ -z "$table_name" ]; then
        echo "Creating inet filter table..."
        execute_command "nft create table inet filter" "Create inet filter table"
        table_name="filter"
    else
        echo "Using existing table: $table_name"
    fi
    
    # Ensure input chain exists
    echo "Checking input chain..."
    if ! nft list table inet "$table_name" 2>/dev/null | grep -q "chain input"; then
        echo "Creating input base chain..."
        execute_command "nft create chain inet '$table_name' input '{ type filter hook input priority 0 ; }'" "Create input chain"
    else
        echo "Input chain already exists"
    fi
    
    echo "Configuring loopback rules in table: $table_name"
    echo ""
    
    # Get current rules to avoid duplicates
    input_rules=$(nft list chain inet "$table_name" input 2>/dev/null)
    
    # Add loopback interface accept rule if not present
    if ! echo "$input_rules" | grep -q "iif.*lo.*accept"; then
        echo "Adding loopback interface accept rule..."
        execute_command "nft add rule inet '$table_name' input iif lo accept" "Add loopback interface accept rule"
    else
        echo "Loopback interface accept rule already exists"
    fi
    
    # Add IPv4 loopback source address drop rule if not present
    if ! echo "$input_rules" | grep -q "ip saddr 127.0.0.0/8.*drop"; then
        echo "Adding IPv4 loopback source address drop rule..."
        execute_command "nft add rule inet '$table_name' input ip saddr 127.0.0.0/8 counter drop" "Add IPv4 loopback source drop rule"
    else
        echo "IPv4 loopback source address drop rule already exists"
    fi
    
    # Add IPv6 loopback rule if IPv6 is enabled and rule not present
    if [ -d /proc/sys/net/ipv6 ]; then
        if ! echo "$input_rules" | grep -q "ip6 saddr ::1.*drop"; then
            echo "Adding IPv6 loopback source address drop rule..."
            execute_command "nft add rule inet '$table_name' input ip6 saddr ::1 counter drop" "Add IPv6 loopback source drop rule"
        else
            echo "IPv6 loopback source address drop rule already exists"
        fi
    else
        echo "IPv6 not enabled - skipping IPv6 loopback rule"
    fi
    
    # Update configuration file to make persistent
    echo "Saving configuration to make it persistent..."
    if [ -f /etc/nftables.conf ]; then
        execute_command "cp /etc/nftables.conf /etc/nftables.conf.backup.$(date +%Y%m%d_%H%M%S)" "Backup existing nftables configuration"
    fi
    
    # Save current ruleset to configuration file
    echo "Saving current ruleset to /etc/nftables.conf..."
    execute_command "nft list ruleset > /etc/nftables.conf" "Save current ruleset to configuration file"
    
    echo "nftables loopback configuration completed"
}

# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_nftables_loopback
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: nftables loopback traffic properly configured"
    else
        echo "FAIL: Issues remain"
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="