#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Get active zone and firewall configuration
echo "Checking firewalld configuration:"
ACTIVE_ZONE=$(firewall-cmd --get-default-zone 2>/dev/null)
if [[ -z "$ACTIVE_ZONE" ]]; then
    ACTIVE_ZONE=$(firewall-cmd --list-all | awk '/\(active\)/ { print $1 }' | head -1)
fi

echo "Active zone: $ACTIVE_ZONE"

# Get full firewall configuration for evidence
FIREWALL_CONFIG=$(firewall-cmd --list-all --zone="$ACTIVE_ZONE" 2>/dev/null)
echo "Firewall configuration for zone '$ACTIVE_ZONE':"
echo "$FIREWALL_CONFIG"

# Extract services and ports
SERVICES=$(echo "$FIREWALL_CONFIG" | awk -F: '/services:/ {print $2}' | xargs)
PORTS=$(echo "$FIREWALL_CONFIG" | awk -F: '/ports:/ {print $2}' | xargs)

echo ""
echo "Current services: '$SERVICES'"
echo "Current ports: '$PORTS'"

# Verification and result
if [[ "$SERVICES" =~ ^ssh$ || "$SERVICES" =~ ^ssh\ dhcpv6-client$ ]] && [[ -z "$PORTS" ]]; then
    echo "PASS: Firewalld configured with only necessary services (ssh, dhcpv6-client) and no unnecessary ports"
    echo "EVIDENCE: services='$SERVICES', ports='$PORTS'"
    exit 0
else
    echo "FAIL: Firewalld has unnecessary services or ports - manual review required"
    echo "EVIDENCE: services='$SERVICES', ports='$PORTS'"
    echo ""
    echo "Required action: Remove unnecessary services and ports, then run:"
    echo "  # firewall-cmd --runtime-to-permanent"
    exit 1
fi