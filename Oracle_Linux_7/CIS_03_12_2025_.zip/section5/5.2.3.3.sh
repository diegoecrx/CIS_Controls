#!/bin/bash

# 5.2.3.3 Ensure events that modify the sudo log file are collected
set -euo pipefail

echo "=== 5.2.3.3 Ensure events that modify the sudo log file are collected ==="
echo "Starting check at: $(date)"
echo

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Function to get the actual sudo log file path from sudoers
get_sudo_log_file() {
    # Try multiple methods to find sudo log file
    local log_file
    
    # Method 1: Check Defaults logfile in sudoers
    log_file=$(grep -r "logfile" /etc/sudoers* 2>/dev/null | \
               grep -v "^#" | \
               sed -n 's/.*logfile\s*=\s*"\{0,1\}\([^",]\{1,\}\)"\{0,1\}.*/\1/p' | \
               head -1)
    
    # Method 2: Check for Defaults syslog (old style)
    if [ -z "$log_file" ]; then
        log_file=$(grep -r "syslog" /etc/sudoers* 2>/dev/null | \
                   grep -v "^#" | \
                   grep "Defaults" | \
                   head -1)
        if [ -n "$log_file" ]; then
            # If using syslog, sudo logs go to /var/log/secure (RHEL/CentOS) or /var/log/auth.log (Debian)
            if [ -f "/var/log/secure" ]; then
                log_file="/var/log/secure"
            elif [ -f "/var/log/auth.log" ]; then
                log_file="/var/log/auth.log"
            else
                log_file="/var/log/secure"  # Default assumption for RHEL
            fi
        fi
    fi
    
    # Method 3: Default if nothing found
    if [ -z "$log_file" ]; then
        if [ -f "/var/log/secure" ]; then
            log_file="/var/log/secure"
        else
            log_file="/var/log/sudo.log"
        fi
    fi
    
    echo "$log_file"
}

# Function to escape path for regex
escape_path() {
    echo "$1" | sed 's|/|\\/|g'
}

# Function to check if audit rule exists
check_audit_rule() {
    local log_file="$1"
    local escaped_path
    
    escaped_path=$(escape_path "$log_file")
    
    # Check in audit rules files
    echo "Checking audit rules files for: $log_file"
    local rule_found=false
    
    for rules_file in /etc/audit/rules.d/*.rules; do
        if [ -f "$rules_file" ]; then
            if grep -qE "^-w[[:space:]]+$escaped_path[[:space:]]+-p[[:space:]]+wa[[:space:]]+-k[[:space:]]+" "$rules_file" 2>/dev/null; then
                echo "✓ Rule found in: $rules_file"
                grep -E "^-w[[:space:]]+$escaped_path[[:space:]]+-p[[:space:]]+wa[[:space:]]+-k[[:space:]]+" "$rules_file"
                rule_found=true
            fi
        fi
    done
    
    # Check in loaded audit rules
    echo "Checking loaded audit rules..."
    if auditctl -l 2>/dev/null | grep -qE "^-w[[:space:]]+$escaped_path[[:space:]]+-p[[:space:]]+wa[[:space:]]+-k[[:space:]]+"; then
        echo "✓ Rule loaded in auditctl"
        auditctl -l | grep -E "^-w[[:space:]]+$escaped_path[[:space:]]+-p[[:space:]]+wa[[:space:]]+-k[[:space:]]+"
        rule_found=true
    fi
    
    if $rule_found; then
        echo "✓ Audit rule exists for: $log_file"
        return 0
    else
        echo "✗ No audit rule found for: $log_file"
        return 1
    fi
}

# Function to add audit rule
add_audit_rule() {
    local log_file="$1"
    local rules_file="/etc/audit/rules.d/50-sudo-log.rules"
    local key_name="sudo_log_file"
    
    echo "Adding audit rule for: $log_file"
    
    # Create backup
    if [ -f "$rules_file" ]; then
        cp "$rules_file" "${rules_file}.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Remove any existing rules for this file
    for rules_file_path in /etc/audit/rules.d/*.rules; do
        if [ -f "$rules_file_path" ]; then
            sed -i "\|^-w[[:space:]]*$log_file[[:space:]]|d" "$rules_file_path" 2>/dev/null || true
        fi
    done
    
    # Add the new rule
    echo "# Monitor sudo log file for write and attribute changes" > "$rules_file"
    echo "-w $log_file -p wa -k $key_name" >> "$rules_file"
    
    # Make sure file has correct permissions
    chmod 0640 "$rules_file"
    chown root:root "$rules_file"
    
    echo "Rule added to: $rules_file"
    echo "Content of $rules_file:"
    cat "$rules_file"
    
    # Reload audit rules
    echo "Reloading audit rules..."
    augenrules --load
    
    # Check if rule is loaded
    sleep 2
    if auditctl -l | grep -qE "^-w[[:space:]]+$log_file[[:space:]]+-p[[:space:]]+wa[[:space:]]+-k[[:space:]]+$key_name"; then
        echo "✓ Audit rule successfully loaded"
        return 0
    else
        echo "✗ Failed to load audit rule"
        return 1
    fi
}

# Main execution
main() {
    echo "=== Identifying sudo log file ==="
    
    # Get the actual sudo log file
    SUDO_LOG_FILE=$(get_sudo_log_file)
    
    if [ -z "$SUDO_LOG_FILE" ]; then
        echo "ERROR: Could not determine sudo log file path"
        exit 1
    fi
    
    echo "Detected sudo log file: $SUDO_LOG_FILE"
    
    # Check if the file exists
    if [ ! -e "$SUDO_LOG_FILE" ]; then
        echo "WARNING: Sudo log file does not exist: $SUDO_LOG_FILE"
        echo "Creating file with appropriate permissions..."
        touch "$SUDO_LOG_FILE"
        chmod 0640 "$SUDO_LOG_FILE"
        chown root:root "$SUDO_LOG_FILE"
    fi
    
    echo ""
    echo "=== Checking current audit configuration ==="
    
    if check_audit_rule "$SUDO_LOG_FILE"; then
        echo ""
        echo "✓ PASS: Sudo log audit rule is properly configured"
        echo ""
        echo "=== Verification output ==="
        echo "Rules files:"
        for rules_file in /etc/audit/rules.d/*.rules; do
            if [ -f "$rules_file" ]; then
                if grep -q "$SUDO_LOG_FILE" "$rules_file" 2>/dev/null; then
                    echo "- $rules_file:"
                    grep "$SUDO_LOG_FILE" "$rules_file"
                fi
            fi
        done
        echo ""
        echo "Loaded rules:"
        auditctl -l | grep "$SUDO_LOG_FILE" 2>/dev/null || echo "(none loaded)"
    else
        echo ""
        echo "✗ FAIL: Sudo log audit rule is missing or incorrect"
        echo ""
        echo "=== Applying remediation ==="
        
        if add_audit_rule "$SUDO_LOG_FILE"; then
            echo ""
            echo "✓ Remediation completed successfully"
            
            # Verify the fix
            echo ""
            echo "=== Final verification ==="
            if check_audit_rule "$SUDO_LOG_FILE"; then
                echo "✓ Verification passed"
            else
                echo "✗ Verification failed"
                exit 1
            fi
        else
            echo "✗ Remediation failed"
            exit 1
        fi
    fi
    
    echo ""
    echo "=== Summary ==="
    echo "Sudo log file: $SUDO_LOG_FILE"
    echo "Status: $(check_audit_rule "$SUDO_LOG_FILE" >/dev/null && echo "COMPLIANT" || echo "NON-COMPLIANT")"
    echo "Completed at: $(date)"
}

# Run the main function
main