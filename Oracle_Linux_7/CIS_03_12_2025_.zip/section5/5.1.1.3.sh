#!/bin/bash

# 5.1.1.3 Ensure journald is configured to send logs to rsyslog
# Remediation script - FIXED VERSION

set -euo pipefail

JOURNALD_CONF="/etc/systemd/journald.conf"
REQUIRED_SETTING="ForwardToSyslog=yes"

# Function to check current status
check_status() {
    echo "Checking current journald configuration..."
    echo "-------------------------"
    
    # Check /etc/systemd/journald.conf
    if [[ -f "$JOURNALD_CONF" ]]; then
        # Check with case-insensitive regex and allow whitespace
        if grep -Pi '^\s*ForwardToSyslog\s*=\s*yes\s*$' "$JOURNALD_CONF" 2>/dev/null; then
            current_setting=$(grep -Pi '^\s*ForwardToSyslog\s*=\s*yes\s*$' "$JOURNALD_CONF" | tail -1 | tr -d '[:space:]')
            echo "PASSED - $JOURNALD_CONF"
            echo "Compliant file(s):"
            echo "      $JOURNALD_CONF - contains '$REQUIRED_SETTING'"
            echo "      Current setting: $current_setting"
        elif grep -Pi '^\s*ForwardToSyslog\s*=' "$JOURNALD_CONF" 2>/dev/null; then
            current_setting=$(grep -Pi '^\s*ForwardToSyslog\s*=' "$JOURNALD_CONF" | tail -1)
            echo "FAILED - $JOURNALD_CONF"
            echo "Non-compliant file(s):"
            echo "      $JOURNALD_CONF - contains incorrect setting"
            echo "      Current: $current_setting"
            echo "      Required: $REQUIRED_SETTING"
        else
            echo "FAILED - $JOURNALD_CONF"
            echo "The following file(s) do not contain \"^[\\s]*ForwardToSyslog[\\s]*=\":"
            echo "      $JOURNALD_CONF"
        fi
    else
        echo "FAILED - $JOURNALD_CONF"
        echo "Configuration file does not exist:"
        echo "      $JOURNALD_CONF"
    fi
    
    echo ""
    
    # Check for drop-in configurations
    echo "Checking for drop-in configurations..."
    if [[ -d /etc/systemd/journald.conf.d ]]; then
        dropin_found=false
        for dropin in /etc/systemd/journald.conf.d/*.conf; do
            if [[ -f "$dropin" ]]; then
                dropin_found=true
                if grep -Pi '^\s*ForwardToSyslog\s*=\s*yes\s*$' "$dropin" 2>/dev/null; then
                    echo "PASSED - Drop-in: $dropin contains '$REQUIRED_SETTING'"
                elif grep -Pi '^\s*ForwardToSyslog\s*=' "$dropin" 2>/dev/null; then
                    current_setting=$(grep -Pi '^\s*ForwardToSyslog\s*=' "$dropin" | tail -1)
                    echo "FAILED - Drop-in: $dropin contains '$current_setting' (should be '$REQUIRED_SETTING')"
                fi
            fi
        done
        if [[ "$dropin_found" == false ]]; then
            echo "No drop-in configurations found in /etc/systemd/journald.conf.d/"
        fi
    fi
    
    echo ""
    
    # Check systemd-journald.service status
    if systemctl is-active systemd-journald.service >/dev/null 2>&1; then
        echo "PASSED - systemd-journald.service"
        echo "The command 'systemctl is-active systemd-journald.service' returned:"
        echo "      $(systemctl is-active systemd-journald.service)"
    else
        echo "FAILED - systemd-journald.service"
        echo "Service is not active:"
        echo "      systemd-journald.service"
    fi
    
    echo ""
    
    # Check rsyslog.service status
    if systemctl is-active rsyslog.service >/dev/null 2>&1; then
        echo "PASSED - rsyslog.service"
        echo "The command 'systemctl is-active rsyslog.service' returned:"
        echo "      $(systemctl is-active rsyslog.service)"
    else
        echo "FAILED - rsyslog.service"
        echo "Service is not active:"
        echo "      rsyslog.service"
    fi
    
    echo "-------------------------"
}

# Function to remediate journald configuration
remediate_journald_conf() {
    echo "Remediating $JOURNALD_CONF..."
    
    # Create directory if it doesn't exist
    mkdir -p "$(dirname "$JOURNALD_CONF")"
    
    # Backup original file if it exists
    if [[ -f "$JOURNALD_CONF" ]]; then
        cp "$JOURNALD_CONF" "${JOURNALD_CONF}.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Create or update the configuration file
    cat > "$JOURNALD_CONF" << 'EOF'
#  This file is part of systemd.
#
#  systemd is free software; you can redistribute it and/or modify it
#  under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation; either version 2.1 of the License, or
#  (at your option) any later version.
#
# Entries in this file show the compile time defaults.
# You can change settings by editing this file.
# Defaults can be restored by simply deleting this file.
#
# See journald.conf(5) for details.

[Journal]
#Storage=auto
#Compress=yes
#Seal=yes
#SplitMode=uid
#SyncIntervalSec=5m
#RateLimitInterval=30s
#RateLimitBurst=1000
#SystemMaxUse=
#SystemKeepFree=
#SystemMaxFileSize=
#SystemMaxFiles=100
#RuntimeMaxUse=
#RuntimeKeepFree=
#RuntimeMaxFileSize=
#RuntimeMaxFiles=100
#MaxRetentionSec=
#MaxFileSec=1month
#ForwardToSyslog=yes
#ForwardToKMsg=no
#ForwardToConsole=no
#ForwardToWall=yes
#TTYPath=/dev/console
#MaxLevelStore=debug
#MaxLevelSyslog=debug
#MaxLevelKMsg=notice
#MaxLevelConsole=info
#MaxLevelWall=emerg
#LineMax=48K

EOF
    
    # Now add the required setting
    echo "$REQUIRED_SETTING" >> "$JOURNALD_CONF"
    
    # Verify the change
    if grep -Pi "^\s*ForwardToSyslog\s*=\s*yes\s*$" "$JOURNALD_CONF" 2>/dev/null; then
        echo "SUCCESS: $JOURNALD_CONF updated with '$REQUIRED_SETTING'"
        return 0
    else
        echo "ERROR: Failed to update $JOURNALD_CONF"
        return 1
    fi
}

# Function to remove conflicting drop-in configurations
remove_conflicting_dropins() {
    echo "Checking for conflicting drop-in configurations..."
    
    if [[ -d /etc/systemd/journald.conf.d ]]; then
        for dropin in /etc/systemd/journald.conf.d/*.conf; do
            if [[ -f "$dropin" ]]; then
                if grep -Pi '^\s*ForwardToSyslog\s*=' "$dropin" 2>/dev/null; then
                    echo "Removing conflicting drop-in: $dropin"
                    mv "$dropin" "${dropin}.backup.$(date +%Y%m%d_%H%M%S)"
                fi
            fi
        done
    fi
}

# Function to force systemd daemon reload
force_daemon_reload() {
    echo "Forcing systemd daemon reload..."
    
    # Reload systemd manager configuration
    systemctl daemon-reload
    
    # Restart journald service
    systemctl restart systemd-journald.service
    
    # Verify service is running
    sleep 2
    if systemctl is-active systemd-journald.service >/dev/null 2>&1; then
        echo "SUCCESS: systemd-journald.service is active after restart"
        return 0
    else
        echo "ERROR: systemd-journald.service failed to start"
        return 1
    fi
}

# Function to create a test drop-in configuration for verification
create_test_config() {
    echo "Creating test configuration to verify..."
    
    # Create a test drop-in to ensure settings are applied
    TEST_DROPIN="/etc/systemd/journald.conf.d/99-cis-test.conf"
    mkdir -p "$(dirname "$TEST_DROPIN")"
    cat > "$TEST_DROPIN" << EOF
# CIS compliance test drop-in
[Journal]
$REQUIRED_SETTING
EOF
    
    echo "Created test drop-in: $TEST_DROPIN"
}

# Function to verify the configuration is actually applied
verify_runtime_config() {
    echo "Verifying runtime configuration..."
    
    # Check the current runtime configuration
    if systemctl show systemd-journald.service --property=ForwardToSyslog 2>/dev/null | grep -qi "yes"; then
        echo "SUCCESS: Runtime configuration shows ForwardToSyslog=yes"
        return 0
    else
        echo "WARNING: Runtime configuration does not show ForwardToSyslog=yes"
        echo "Checking journalctl configuration..."
        journalctl --system | head -5
        return 1
    fi
}

# Main execution
main() {
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        echo "ERROR: This script must be run as root" >&2
        exit 1
    fi
    
    echo "=== 5.1.1.3 Ensure journald is configured to send logs to rsyslog ==="
    echo "Required setting: $REQUIRED_SETTING"
    echo ""
    
    # Show current status
    check_status
    
    echo ""
    echo "This script will:"
    echo "1. Completely rewrite $JOURNALD_CONF with proper defaults"
    echo "2. Add $REQUIRED_SETTING"
    echo "3. Remove any conflicting drop-in configurations"
    echo "4. Force systemd daemon reload"
    echo "5. Restart systemd-journald.service"
    echo "6. Create test drop-in configuration"
    echo "7. Verify runtime configuration"
    echo ""
    echo "WARNING: This will overwrite $JOURNALD_CONF!"
    echo "A backup will be created first."
    echo ""
    echo "Do you want to proceed with remediation? (yes/no)"
    read -r response
    
    if ! [[ "$response" =~ ^[Yy]([Ee][Ss])?$ ]]; then
        echo "Remediation cancelled."
        exit 0
    fi
    
    # Remove conflicting drop-ins first
    remove_conflicting_dropins
    
    # Remediate journald configuration
    if ! remediate_journald_conf; then
        echo "ERROR: Failed to remediate $JOURNALD_CONF"
        exit 1
    fi
    
    # Create test drop-in
    create_test_config
    
    # Force daemon reload
    if ! force_daemon_reload; then
        echo "ERROR: Failed to reload systemd daemon"
        exit 1
    fi
    
    # Verify runtime configuration
    verify_runtime_config
    
    echo ""
    echo "=== Remediation Complete ==="
    echo ""
    
    # Wait a moment for changes to take effect
    echo "Waiting 5 seconds for changes to propagate..."
    sleep 5
    
    # Show final status
    check_status
    
    echo ""
    echo "NOTE:"
    echo "1. Original configuration backed up to: ${JOURNALD_CONF}.backup.*"
    echo "2. Conflicting drop-ins backed up with .backup extension"
    echo "3. Test drop-in created at: /etc/systemd/journald.conf.d/99-cis-test.conf"
    echo "4. Systemd daemon reloaded and journald service restarted"
    echo ""
    echo "IMPORTANT: Run the CIS scanner again after this script completes."
}

# Execute main function
main "$@"