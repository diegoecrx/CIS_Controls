#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-login.rules"

[ "$EUID" -eq 0 ] || exit 1

# Create rules file
{
    echo "-w /var/log/lastlog -p wa -k logins"
    echo "-w /var/run/faillock -p wa -k logins"
} > "$RULES_FILE"

echo "Created rules file:"
cat "$RULES_FILE"

# Load rules
echo "---"
echo "Loading rules:"
augenrules --load
auditctl -R "$RULES_FILE"

# Show proof
echo "---"
echo "Current loaded rules:"
auditctl -l | grep -E "(lastlog|faillock).*logins"