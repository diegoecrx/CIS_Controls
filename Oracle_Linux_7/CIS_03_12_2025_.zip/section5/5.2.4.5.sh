#!/usr/bin/env bash
# Script: 5.2.4.5.sh
# Item: 5.2.4.5 Ensure audit configuration files are 640 or more restrictive (Automated)
set -euo pipefail
SCRIPT_NAME="5.2.4.5.sh"
ITEM_NAME="5.2.4.5 Ensure audit configuration files are 640 or more restrictive (Automated)"
DESCRIPTION="This remediation ensures audit configuration files have permissions of 640 or more restrictive."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check current status using the exact same command as the compliance checker
check_current_status() {
    echo "Checking audit configuration files permissions..."
    
    # Use the exact same command as the compliance checker
    result=$(find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec stat -Lc "%n %a" {} + 2>/dev/null | grep -Pv -- '^\h*\H+\h*([0,2,4,6][0,4]0)\h*$' | awk '{print} END { if(NR==0) print "pass" ; else print "fail"}')
    
    if [ "$result" = "pass" ]; then
        echo "PASS: All audit configuration files have permissions 640 or more restrictive"
        echo "PROOF: No files found with permissions more permissive than 640"
        return 0
    else
        echo "FAIL: Found audit configuration files with improper permissions"
        echo "PROOF: Files with permissions more permissive than 640:"
        find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec stat -Lc "%n %a" {} + 2>/dev/null | grep -Pv -- '^\h*\H+\h*([0,2,4,6][0,4]0)\h*$'
        return 1
    fi
}

# Function to fix audit configuration files permissions
fix_audit_config_files_permissions() {
    echo "Applying fix..."
    
    # Check if audit package is installed
    if ! rpm -q audit >/dev/null 2>&1; then
        echo " - Installing audit package"
        yum install -y audit >/dev/null 2>&1
    fi
    
    # Ensure /etc/audit directory exists
    if [ ! -d /etc/audit ]; then
        echo " - Creating /etc/audit directory"
        mkdir -p /etc/audit
        chmod 750 /etc/audit
        chown root:root /etc/audit
    fi
    
    echo " - Checking audit configuration files permissions in /etc/audit/"
    
    # Find all audit configuration files
    config_files=()
    while IFS= read -r -d '' file; do
        config_files+=("$file")
    done < <(find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -print0 2>/dev/null)
    
    if [ ${#config_files[@]} -eq 0 ]; then
        echo " - No audit configuration files found"
        return
    fi
    
    echo " - Found ${#config_files[@]} audit configuration files"
    
    # Show current permissions before fixing
    echo " - Current permissions of audit configuration files:"
    find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec stat -Lc "%a %n" {} + 2>/dev/null | sort
    
    # Run the exact command from the benchmark solution
    echo " - Running comprehensive permissions fix: find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec chmod u-x,g-wx,o-rwx {} +"
    find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec chmod u-x,g-wx,o-rwx {} + 2>/dev/null
    
    # Verify the fix was applied
    echo " - New permissions after fix:"
    find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec stat -Lc "%a %n" {} + 2>/dev/null | sort
    
    # Count how many files still have improper permissions
    improper_count=$(find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec stat -Lc "%a" {} + 2>/dev/null | grep -Pv '([0,2,4,6][0,4]0)' | wc -l)
    
    if [ "$improper_count" -eq 0 ]; then
        echo " - SUCCESS: All audit configuration files now have proper permissions (640 or more restrictive)"
    else
        echo " - WARNING: $improper_count files still have improper permissions"
    fi
    
    # Ensure proper ownership for all audit configuration files
    echo " - Ensuring proper ownership for audit configuration files"
    find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec chown root:root {} + 2>/dev/null
    
    echo " - Audit configuration files permissions configuration completed"
}

# Main remediation
{
    echo "Initial Status Check:"
    echo "===================="
    if check_current_status; then
        echo "No remediation needed"
    else
        echo ""
        echo "Remediation Steps:"
        echo "=================="
        fix_audit_config_files_permissions
    fi
    
    echo ""
    echo "Final Verification:"
    echo "=================="
    if check_current_status; then
        echo "SUCCESS: Audit configuration files permissions properly configured"
        echo ""
        echo "Final Proof - All audit configuration files:"
        find /etc/audit/ -type f \( -name '*.conf' -o -name '*.rules' \) -exec stat -Lc "%a %U %G %n" {} + 2>/dev/null | sort
    else
        echo "FAIL: Issues remain with audit configuration files permissions"
        exit 1
    fi
}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="