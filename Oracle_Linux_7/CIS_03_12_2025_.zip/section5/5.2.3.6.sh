#!/bin/bash
set -euo pipefail

UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
AUDIT_RULE_FILE="/etc/audit/rules.d/50-privileged.rules"
NEW_DATA=()

for PARTITION in $(findmnt -n -l -k -it $(awk '/nodev/ { print $2 }' /proc/filesystems | paste -sd,) | grep -Pv "noexec|nosuid" | awk '{print $1}'); do
    while IFS= read -r -d '' file; do
        NEW_DATA+=("-a always,exit -F path=$file -F perm=x -F auid>=$UID_MIN -F auid!=unset -k privileged")
    done < <(find "${PARTITION}" -xdev -perm /6000 -type f -print0 2>/dev/null)
done

printf '%s\n' "${NEW_DATA[@]}" | sort -u > "${AUDIT_RULE_FILE}"

augenrules --load

if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi