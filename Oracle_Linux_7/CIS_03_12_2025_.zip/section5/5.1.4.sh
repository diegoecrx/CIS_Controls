#!/bin/bash

set -euo pipefail

echo "=== 5.1.4 Ensure all logfiles have appropriate access configured ==="
echo "Starting remediation at: $(date)"
echo

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: This script must be run as root" >&2
    exit 1
fi

# Function to safely change permissions
safe_chmod() {
    local target="$1"
    local desired_perm="$2"
    local current_perm
    
    if [ -e "$target" ]; then
        current_perm=$(stat -c "%a" "$target" 2>/dev/null || echo "N/A")
        echo "Checking: $target"
        echo "  Current permissions: $current_perm (desired: $desired_perm)"
        
        if [[ "$current_perm" =~ ^[0-9]+$ ]] && [ "$current_perm" -gt "$desired_perm" ]; then
            echo "  ** FIXING **: Changing permissions from $current_perm to $desired_perm"
            chmod "$desired_perm" "$target"
            
            # Verify the change
            new_perm=$(stat -c "%a" "$target" 2>/dev/null || echo "N/A")
            if [ "$new_perm" = "$desired_perm" ]; then
                echo "  ** SUCCESS **: Permissions updated to $new_perm"
            else
                echo "  ** WARNING **: Failed to update permissions (still $new_perm)"
            fi
        else
            echo "  ** OK **: Permissions are already appropriate"
        fi
        echo
    fi
}

# Fix specific problematic files identified in the output
echo "=== Fixing specific problematic files ==="

# Fix /var/log/test_exec_8778.sh (0750 -> 0640)
if [ -f "/var/log/test_exec_8778.sh" ]; then
    safe_chmod "/var/log/test_exec_8778.sh" 640
fi

# Fix /var/log/dmesg (0644 -> 0640)
if [ -f "/var/log/dmesg" ]; then
    safe_chmod "/var/log/dmesg" 640
fi

# Fix /var/log/tuned/tuned.log (0644 -> 0640)
if [ -f "/var/log/tuned/tuned.log" ]; then
    safe_chmod "/var/log/tuned/tuned.log" 640
fi

# Fix /var/log directory permissions (0755 -> 0750)
# Note: Directories need execute bits for cd/ls
safe_chmod "/var/log" 750

# Fix /var/log/audit directory (0700 -> 0750)
if [ -d "/var/log/audit" ]; then
    safe_chmod "/var/log/audit" 750
fi

# Fix all log files in /var/log
echo "=== Fixing all log files in /var/log ==="
find /var/log -type f -name "*.log" -o -name "dmesg" -o -name "messages" -o -name "secure" -o -name "cron" -o -name "maillog" -o -name "spooler" -o -name "boot.log" -o -name "*.sh" 2>/dev/null | while read logfile; do
    if [ -f "$logfile" ]; then
        current_perm=$(stat -c "%a" "$logfile" 2>/dev/null || echo "0")
        if [[ "$current_perm" =~ ^[0-9]+$ ]] && [ "$current_perm" -gt 640 ]; then
            echo "Fixing: $logfile (permissions: $current_perm -> 640)"
            chmod 640 "$logfile" 2>/dev/null || echo "  Warning: Could not change permissions"
        fi
    fi
done

# Also fix other common log files
echo "=== Fixing other common log files ==="
COMMON_LOGS="/var/log/wtmp /var/log/btmp /var/log/lastlog /var/log/faillog"
for log in $COMMON_LOGS; do
    if [ -f "$log" ]; then
        safe_chmod "$log" 640
    fi
done

# Fix log directories under /var/log
echo "=== Fixing log directories ==="
find /var/log -type d 2>/dev/null | while read logdir; do
    if [ -d "$logdir" ]; then
        current_perm=$(stat -c "%a" "$logdir" 2>/dev/null || echo "0")
        # Directories should be 750 or more restrictive
        if [[ "$current_perm" =~ ^[0-9]+$ ]] && [ "$current_perm" -gt 750 ]; then
            echo "Fixing directory: $logdir (permissions: $current_perm -> 750)"
            chmod 750 "$logdir" 2>/dev/null || echo "  Warning: Could not change permissions"
        fi
    fi
done

# Create post-remediation audit
echo "=== Post-remediation audit ==="
echo "Checking previously problematic files:"
echo

PROBLEM_FILES="/var/log/test_exec_8778.sh /var/log/dmesg /var/log/tuned/tuned.log /var/log /var/log/audit"
all_fixed=true

for file in $PROBLEM_FILES; do
    if [ -e "$file" ]; then
        current_perm=$(stat -c "%a" "$file" 2>/dev/null || echo "N/A")
        echo "File: $file"
        echo "  Current permissions: $current_perm"
        
        if [ -d "$file" ]; then
            # Directory check
            if [[ "$current_perm" =~ ^[0-9]+$ ]] && [ "$current_perm" -le 750 ]; then
                echo "  ** PASS **: Directory permissions are appropriate"
            else
                echo "  ** FAIL **: Directory permissions should be 750 or more restrictive"
                all_fixed=false
            fi
        else
            # File check
            if [[ "$current_perm" =~ ^[0-9]+$ ]] && [ "$current_perm" -le 640 ]; then
                echo "  ** PASS **: File permissions are appropriate"
            else
                echo "  ** FAIL **: File permissions should be 640 or more restrictive"
                all_fixed=false
            fi
        fi
        echo
    fi
done

# Final verification
echo "=== Final verification ==="
echo "Running comprehensive check..."

# Check the specific files that were failing
FAILING_FILES=(
    "/var/log/test_exec_8778.sh:0750:0640"
    "/var/log/dmesg:0644:0640"
    "/var/log/tuned/tuned.log:0644:0640"
)

echo "Verifying specific file fixes:"
for entry in "${FAILING_FILES[@]}"; do
    file=$(echo "$entry" | cut -d: -f1)
    old_perm=$(echo "$entry" | cut -d: -f2)
    desired_perm=$(echo "$entry" | cut -d: -f3)
    
    if [ -e "$file" ]; then
        current_perm=$(stat -c "%a" "$file" 2>/dev/null || echo "missing")
        if [ "$current_perm" = "$desired_perm" ]; then
            echo "✓ $file: $old_perm -> $current_perm (FIXED)"
        else
            echo "✗ $file: $current_perm (should be $desired_perm)"
            all_fixed=false
        fi
    else
        echo "? $file: File does not exist"
    fi
done

echo
echo "=== Summary ==="
echo "Remediation completed at: $(date)"
if $all_fixed; then
    echo "✓ All identified issues have been resolved"
else
    echo "✗ Some issues may still need manual attention"
    exit 1
fi