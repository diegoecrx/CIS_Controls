#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-system_locale.rules"

{
    echo "-a always,exit -F arch=b64 -S sethostname,setdomainname -k system-locale"
    echo "-a always,exit -F arch=b32 -S sethostname,setdomainname -k system-locale"
    echo "-w /etc/issue -p wa -k system-locale"
    echo "-w /etc/issue.net -p wa -k system-locale"
    echo "-w /etc/hosts -p wa -k system-locale"
    echo "-w /etc/sysconfig/network -p wa -k system-locale"
    echo "-w /etc/sysconfig/network-scripts/ -p wa -k system-locale"
} > "$RULES_FILE"

augenrules --load

if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
    echo "Reboot required to load rules"
fi