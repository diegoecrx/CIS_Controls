#!/bin/bash

# Enforce CIS 5.2.1.2 - Ensure auditing for processes that start prior to auditd is enabled
echo "Enforcing CIS 5.2.1.2 - Enable auditing for processes before auditd..."

# Update GRUB configuration with audit=1
echo "Updating GRUB configuration with audit=1..."

# Update kernel command line using grubby
if command -v grubby >/dev/null 2>&1; then
    grubby --update-kernel ALL --args 'audit=1'
    echo "Updated kernel command line with audit=1 using grubby"
else
    echo "WARNING: grubby command not found, updating /etc/default/grub directly"
fi

# Ensure audit=1 is in /etc/default/grub
echo "Configuring /etc/default/grub..."

# Backup original file
if [ ! -f /etc/default/grub.bak ]; then
    cp /etc/default/grub /etc/default/grub.bak
    echo "Backed up /etc/default/grub to /etc/default/grub.bak"
fi

# Check if GRUB_CMDLINE_LINUX exists and add/update audit=1
if grep -q '^GRUB_CMDLINE_LINUX=' /etc/default/grub; then
    # Remove existing audit parameter if present
    sed -i 's/GRUB_CMDLINE_LINUX="\([^"]*\)"/GRUB_CMDLINE_LINUX="\1"/' /etc/default/grub
    sed -i '/^GRUB_CMDLINE_LINUX=/s/audit=[0-9]*//g' /etc/default/grub
    
    # Add audit=1 to the existing parameters
    sed -i '/^GRUB_CMDLINE_LINUX=/s/"\(.*\)"/"\1 audit=1"/' /etc/default/grub
    echo "Added audit=1 to existing GRUB_CMDLINE_LINUX in /etc/default/grub"
else
    # Add GRUB_CMDLINE_LINUX line if it doesn't exist
    echo 'GRUB_CMDLINE_LINUX="audit=1"' >> /etc/default/grub
    echo "Added GRUB_CMDLINE_LINUX with audit=1 to /etc/default/grub"
fi

# Clean up any duplicate spaces that may have been introduced
sed -i '/^GRUB_CMDLINE_LINUX=/s/  / /g' /etc/default/grub

# Rebuild GRUB configuration
echo "Rebuilding GRUB configuration..."
if command -v grub2-mkconfig >/dev/null 2>&1; then
    grub2-mkconfig -o /boot/grub2/grub.cfg
    echo "Rebuilt GRUB configuration using grub2-mkconfig"
elif command -v grub-mkconfig >/dev/null 2>&1; then
    grub-mkconfig -o /boot/grub/grub.cfg
    echo "Rebuilt GRUB configuration using grub-mkconfig"
else
    echo "WARNING: Could not find grub-mkconfig command"
fi

# Verify configuration
echo "Verifying audit configuration..."

# Check /etc/default/grub
if grep -q '^GRUB_CMDLINE_LINUX=.*audit=1' /etc/default/grub; then
    echo "SUCCESS: audit=1 configured in /etc/default/grub"
    echo "Current GRUB_CMDLINE_LINUX: $(grep '^GRUB_CMDLINE_LINUX=' /etc/default/grub)"
else
    echo "ERROR: audit=1 not found in /etc/default/grub"
    exit 1
fi

# Check current kernel command line using grubby if available
if command -v grubby >/dev/null 2>&1; then
    if grubby --info=ALL | grep -q '\baudit=1\b'; then
        echo "SUCCESS: audit=1 found in kernel command line via grubby"
    else
        echo "ERROR: audit=1 not found in kernel command line via grubby"
        exit 1
    fi
fi

# Check /proc/cmdline for current boot (will only show audit=1 after reboot)
if grep -q '\baudit=1\b' /proc/cmdline; then
    echo "SUCCESS: audit=1 is active in current kernel command line"
else
    echo "WARNING: audit=1 is not active in current kernel command line (requires reboot)"
    echo "Current kernel command line: $(cat /proc/cmdline)"
fi

echo "CIS 5.2.1.2 remediation completed successfully"
echo "NOTE: A system reboot is required for audit=1 to take effect"