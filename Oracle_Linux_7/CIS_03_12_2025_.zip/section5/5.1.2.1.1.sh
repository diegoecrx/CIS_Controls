#!/usr/bin/env bash

# Script: 5.1.2.1.1.sh
# Item: 5.1.2.1.1 Ensure systemd-journal-remote is installed (Automated)
# Description: Ensure systemd-journal-remote is installed for remote journal logging

set -euo pipefail

SCRIPT_NAME="5.1.2.1.1.sh"
ITEM_NAME="5.1.2.1.1 Ensure systemd-journal-remote is installed (Automated)"
DESCRIPTION="Ensure systemd-journal-remote is installed for remote journal logging"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to check if systemd-journal-remote is installed
check_journal_remote_installed() {
    echo "Checking if systemd-journal-remote is installed..."
    
    if rpm -q systemd-journal-gateway >/dev/null 2>&1; then
        echo "systemd-journal-gateway package is installed"
        return 0
    elif rpm -q systemd-journal-remote >/dev/null 2>&1; then
        echo "systemd-journal-remote package is installed"
        return 0
    else
        echo "systemd-journal-remote is not installed"
        return 1
    fi
}

# Function to enable required repositories
enable_repositories() {
    echo "Enabling required repositories..."
    
    # Enable optional repository which often contains systemd-journal-gateway
    if yum repolist enabled | grep -q "ol7_optional_latest"; then
        echo "Optional repository already enabled"
    else
        echo "Enabling optional repository..."
        yum-config-manager --enable ol7_optional_latest >/dev/null 2>&1 || true
    fi
    
    # Refresh repository cache
    echo "Refreshing repository cache..."
    yum makecache fast >/dev/null 2>&1 || true
}

# Function to find and install available package
install_journal_remote() {
    echo "Searching for available systemd-journal remote packages..."
    
    # Search for available packages
    local available_packages=()
    
    if yum list available systemd-journal-gateway 2>/dev/null | grep -q systemd-journal-gateway; then
        available_packages+=("systemd-journal-gateway")
    fi
    
    if yum list available systemd-journal-remote 2>/dev/null | grep -q systemd-journal-remote; then
        available_packages+=("systemd-journal-remote")
    fi
    
    if [ ${#available_packages[@]} -eq 0 ]; then
        echo "No systemd-journal remote packages found in repositories"
        return 1
    fi
    
    echo "Available packages: ${available_packages[*]}"
    
    # Install the first available package
    for package in "${available_packages[@]}"; do
        echo "Installing package: $package"
        if yum install -y "$package" >/dev/null 2>&1; then
            echo "Successfully installed $package"
            return 0
        else
            echo "Failed to install $package, trying next available package..."
        fi
    done
    
    return 1
}

# Function to locate binaries and services
locate_binaries_and_services() {
    echo "Locating installed binaries and services..."
    
    # Find binaries in common locations
    local binary_locations=(
        "/usr/bin/systemd-journal-gateway"
        "/usr/bin/systemd-journal-remote"
        "/usr/lib/systemd/systemd-journal-gateway"
        "/usr/lib/systemd/systemd-journal-remote"
        "/usr/libexec/systemd/systemd-journal-gateway"
        "/usr/libexec/systemd/systemd-journal-remote"
    )
    
    for binary in "${binary_locations[@]}"; do
        if [ -x "$binary" ]; then
            echo "Found binary: $binary"
            return 0
        fi
    done
    
    # Check if binaries are in PATH but not directly executable
    if command -v systemd-journal-gateway >/dev/null 2>&1; then
        echo "Found binary in PATH: $(command -v systemd-journal-gateway)"
        return 0
    fi
    
    if command -v systemd-journal-remote >/dev/null 2>&1; then
        echo "Found binary in PATH: $(command -v systemd-journal-remote)"
        return 0
    fi
    
    echo "No binaries found in common locations or PATH"
    return 1
}

# Function to check service files
check_service_files() {
    echo "Checking for service files..."
    
    local service_files=(
        "/usr/lib/systemd/system/systemd-journal-gateway.service"
        "/usr/lib/systemd/system/systemd-journal-remote.service"
        "/etc/systemd/system/systemd-journal-gateway.service"
        "/etc/systemd/system/systemd-journal-remote.service"
    )
    
    for service_file in "${service_files[@]}"; do
        if [ -f "$service_file" ]; then
            echo "Found service file: $service_file"
            return 0
        fi
    done
    
    echo "No service files found"
    return 1
}

# Function to verify functionality
verify_functionality() {
    echo "Verifying remote journal functionality..."
    
    # Check if the package provides any remote journal capabilities
    local package_files=$(rpm -ql systemd-journal-gateway 2>/dev/null | head -20)
    
    if [ -n "$package_files" ]; then
        echo "Package provides the following files:"
        echo "$package_files" | head -10
        return 0
    fi
    
    # Check if there are any journal-related binaries
    if find /usr -name "*journal*" -type f -executable 2>/dev/null | grep -q .; then
        echo "Found journal-related executables:"
        find /usr -name "*journal*" -type f -executable 2>/dev/null | head -5
        return 0
    fi
    
    return 1
}

# Main remediation
main() {
    echo "Starting automated remediation for systemd-journal-remote installation..."
    echo ""
    
    # Check if already installed
    if check_journal_remote_installed; then
        echo "systemd-journal-remote is already installed"
        echo ""
        locate_binaries_and_services
        echo ""
        check_service_files
        echo ""
        verify_functionality
        return 0
    fi
    
    echo "systemd-journal-remote not found, proceeding with installation..."
    echo ""
    
    # Enable repositories
    enable_repositories
    echo ""
    
    # Install package
    if install_journal_remote; then
        echo "Installation completed successfully"
        echo ""
        locate_binaries_and_services
        echo ""
        check_service_files
        echo ""
        verify_functionality
    else
        echo "Unable to install systemd-journal-remote packages"
        echo "This system may not support remote journal logging"
    fi
}

# Execute main function
main

echo ""
echo "==================================================================="
echo "Final Verification with Proofs:"
echo "==================================================================="
echo ""

# Final verification
final_status_pass=true

echo "1. VERIFYING PACKAGE INSTALLATION:"
echo "----------------------------------"
if rpm -q systemd-journal-gateway >/dev/null 2>&1; then
    echo "PASS: systemd-journal-gateway is installed"
    echo "PROOF:"
    rpm -q systemd-journal-gateway
    echo ""
    echo "Package version and architecture confirmed"
elif rpm -q systemd-journal-remote >/dev/null 2>&1; then
    echo "PASS: systemd-journal-remote is installed"
    echo "PROOF:"
    rpm -q systemd-journal-remote
    echo ""
    echo "Package version and architecture confirmed"
else
    echo "FAIL: No systemd-journal remote packages installed"
    echo "PROOF: Package not found in rpm database"
    final_status_pass=false
fi
echo ""

echo "2. VERIFYING BINARY AVAILABILITY:"
echo "---------------------------------"
# Check both PATH and common binary locations
binary_found=false

if command -v systemd-journal-gateway >/dev/null 2>&1; then
    echo "PASS: systemd-journal-gateway binary is available in PATH"
    echo "PROOF: $(command -v systemd-journal-gateway)"
    binary_found=true
elif command -v systemd-journal-remote >/dev/null 2>&1; then
    echo "PASS: systemd-journal-remote binary is available in PATH"
    echo "PROOF: $(command -v systemd-journal-remote)"
    binary_found=true
else
    # Check common binary locations
    if [ -x "/usr/bin/systemd-journal-gateway" ]; then
        echo "PASS: systemd-journal-gateway binary found in /usr/bin/"
        echo "PROOF: /usr/bin/systemd-journal-gateway exists and is executable"
        binary_found=true
    elif [ -x "/usr/bin/systemd-journal-remote" ]; then
        echo "PASS: systemd-journal-remote binary found in /usr/bin/"
        echo "PROOF: /usr/bin/systemd-journal-remote exists and is executable"
        binary_found=true
    elif [ -x "/usr/lib/systemd/systemd-journal-gateway" ]; then
        echo "PASS: systemd-journal-gateway binary found in /usr/lib/systemd/"
        echo "PROOF: /usr/lib/systemd/systemd-journal-gateway exists and is executable"
        binary_found=true
    elif [ -x "/usr/lib/systemd/systemd-journal-remote" ]; then
        echo "PASS: systemd-journal-remote binary found in /usr/lib/systemd/"
        echo "PROOF: /usr/lib/systemd/systemd-journal-remote exists and is executable"
        binary_found=true
    else
        echo "INFO: No binaries found in PATH or common locations"
        echo "PROOF: Checking package contents for binaries..."
        # Show what files the package actually installed
        if rpm -q systemd-journal-gateway >/dev/null 2>&1; then
            echo "Package files:"
            rpm -ql systemd-journal-gateway | grep -E "(bin|lib|exec)" | head -10
        fi
    fi
fi
echo ""

echo "3. VERIFYING FUNCTIONALITY:"
echo "---------------------------"
# Check what the package actually provides
if rpm -q systemd-journal-gateway >/dev/null 2>&1; then
    echo "PASS: systemd-journal-gateway package is installed and provides remote journal capabilities"
    echo "PROOF: Package installation verified - provides HTTP gateway for journal events"
    echo ""
    echo "Installed files proof:"
    rpm -ql systemd-journal-gateway | head -5
elif rpm -q systemd-journal-remote >/dev/null 2>&1; then
    echo "PASS: systemd-journal-remote package is installed and provides remote journal capabilities"
    echo "PROOF: Package installation verified - provides remote journal reception"
    echo ""
    echo "Installed files proof:"
    rpm -ql systemd-journal-remote | head -5
else
    echo "FAIL: No remote journal functionality packages installed"
    echo "PROOF: No systemd-journal remote packages in rpm database"
    final_status_pass=false
fi
echo ""

echo "4. VERIFYING SERVICE AVAILABILITY:"
echo "----------------------------------"
# Check for service files in standard locations
service_found=false

if [ -f "/usr/lib/systemd/system/systemd-journal-gateway.service" ]; then
    echo "PASS: systemd-journal-gateway service file exists"
    echo "PROOF: /usr/lib/systemd/system/systemd-journal-gateway.service"
    service_found=true
elif [ -f "/usr/lib/systemd/system/systemd-journal-remote.service" ]; then
    echo "PASS: systemd-journal-remote service file exists"
    echo "PROOF: /usr/lib/systemd/system/systemd-journal-remote.service"
    service_found=true
elif [ -f "/etc/systemd/system/systemd-journal-gateway.service" ]; then
    echo "PASS: systemd-journal-gateway service file exists in etc"
    echo "PROOF: /etc/systemd/system/systemd-journal-gateway.service"
    service_found=true
elif [ -f "/etc/systemd/system/systemd-journal-remote.service" ]; then
    echo "PASS: systemd-journal-remote service file exists in etc"
    echo "PROOF: /etc/systemd/system/systemd-journal-remote.service"
    service_found=true
else
    echo "INFO: No dedicated service files found"
    echo "PROOF: Service files not in standard locations"
    # Show what service files the package installed
    if rpm -q systemd-journal-gateway >/dev/null 2>&1; then
        echo "Package service files:"
        rpm -ql systemd-journal-gateway | grep "service" | head -5
    fi
fi

# Check if service is actually available in systemd
if systemctl list-unit-files | grep -q "systemd-journal-gateway"; then
    echo "PASS: systemd-journal-gateway service is registered with systemd"
    echo "PROOF: Service appears in systemd unit files"
elif systemctl list-unit-files | grep -q "systemd-journal-remote"; then
    echo "PASS: systemd-journal-remote service is registered with systemd"
    echo "PROOF: Service appears in systemd unit files"
fi
echo ""

if [ "$final_status_pass" = true ]; then
    echo "SUCCESS: systemd-journal-remote functionality is installed"
    echo "PROOF: Package installation verified - systemd-journal-gateway provides remote journal logging capabilities"
else
    echo "FAIL: systemd-journal-remote installation incomplete"
    echo "PROOF: Package installed but functionality verification failed"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="