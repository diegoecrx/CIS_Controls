#!/bin/bash

# fix-auditd-compliance-v2.sh
# Improved script to fix auditd permissions and ensure compliance
# Handles existing rules and service startup issues

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root"
        exit 1
    fi
}

# Completely stop and reset audit service
reset_audit_service() {
    log "Stopping and resetting audit service..."
    
    # Stop service
    systemctl stop auditd 2>/dev/null || true
    
    # Kill any remaining processes
    pkill -f auditd 2>/dev/null || true
    pkill -f audispd 2>/dev/null || true
    
    # Clear all existing rules
    auditctl -D 2>/dev/null || true
    
    # Remove PID file
    rm -f /var/run/auditd.pid
    
    sleep 2
}

# Fix SELinux contexts for audit directories
fix_selinux_contexts() {
    log "Fixing SELinux contexts for audit directories..."
    
    # Ensure directories exist
    mkdir -p /var/log/audit
    mkdir -p /etc/audit/rules.d
    
    # Create audit log file if it doesn't exist
    touch /var/log/audit/audit.log
    
    # Set correct SELinux contexts
    restorecon -R -v /var/log/audit/ || {
        warn "restorecon failed, applying manual context..."
        semanage fcontext -a -t auditd_log_t "/var/log/audit(/.*)?" 2>/dev/null || true
        restorecon -R -v /var/log/audit/
    }
    
    restorecon -R -v /etc/audit/ || {
        warn "restorecon failed for /etc/audit/, applying manual context..."
        semanage fcontext -a -t etc_t "/etc/audit(/.*)?" 2>/dev/null || true
        restorecon -R -v /etc/audit/
    }
    
    log "SELinux contexts fixed"
}

# Fix file permissions and ownership
fix_permissions() {
    log "Fixing file permissions and ownership..."
    
    # Audit log directory permissions (5.2.4.1)
    chmod 750 /var/log/audit
    chown root:root /var/log/audit
    
    # Audit log files permissions (5.2.4.2)
    chmod 640 /var/log/audit/audit.log
    chown root:root /var/log/audit/audit.log
    
    # Configuration files
    chmod 640 /etc/audit/auditd.conf 2>/dev/null || true
    chmod 640 /etc/audit/audit.rules 2>/dev/null || true
    chmod 640 /etc/audit/rules.d/*.rules 2>/dev/null || true
    
    chown root:root /etc/audit/auditd.conf 2>/dev/null || true
    chown root:root /etc/audit/audit.rules 2>/dev/null || true
    chown root:root /etc/audit/rules.d/*.rules 2>/dev/null || true
    
    log "File permissions fixed"
}

# Create minimal working audit configuration
create_audit_config() {
    log "Creating comprehensive audit configuration..."
    
    # First, create a clean rules file
    cat > /etc/audit/rules.d/audit.rules << 'EOF'
## Remove any existing rules
-D

## Buffer size
-b 8192

## Failure mode
-f 1

## 5.2.3.12 Ensure login and logout events are collected
-w /var/log/faillog -p wa -k logins
-w /var/log/lastlog -p wa -k logins
-w /var/log/tallylog -p wa -k logins

## 5.2.3.13 Ensure file deletion events by users are collected
-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=-1 -F key=delete
-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=-1 -F key=delete

## 5.2.3.14 Ensure events that modify the system's Mandatory Access Controls are collected
-w /etc/selinux/ -p wa -k MAC-policy
-w /usr/share/selinux/ -p wa -k MAC-policy

## 5.2.3.15 Ensure successful and unsuccessful attempts to use the chcon command are recorded
-a always,exit -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=-1 -F key=perm_chng

## 5.2.3.16 Ensure successful and unsuccessful attempts to use the setfacl command are recorded
-a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=-1 -F key=perm_chng

## 5.2.3.17 Ensure successful and unsuccessful attempts to use the chacl command are recorded
-a always,exit -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=-1 -F key=perm_chng

## 5.2.3.18 Ensure successful and unsuccessful attempts to use the usermod command are recorded
-a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=-1 -F key=identity

## 5.2.3.19 Ensure kernel module loading unloading and modification is collected
-w /sbin/insmod -p x -k modules
-w /sbin/rmmod -p x -k modules
-w /sbin/modprobe -p x -k modules
-a always,exit -F arch=b64 -S init_module -S delete_module -k modules

## 5.2.3.20 Ensure actions as another user are always logged
-a always,exit -F arch=b64 -S execve -C auid!=euid -F key=execpriv
-a always,exit -F arch=b32 -S execve -C auid!=euid -F key=execpriv

## 5.2.3.21 Ensure events that modify the system's network environment are collected
-w /etc/issue -p wa -k system-locale
-w /etc/issue.net -p wa -k system-locale
-w /etc/hosts -p wa -k system-locale
-w /etc/sysconfig/network -p wa -k system-locale

## 5.2.3.22 Ensure events that modify date and time information are collected
-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change
-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
-a always,exit -F arch=b64 -S clock_settime -k time-change
-a always,exit -F arch=b32 -S clock_settime -k time-change
-w /etc/localtime -p wa -k time-change

## 5.2.3.23 Ensure events that modify the system's network environment are collected
-w /etc/sysconfig/network-scripts/ -p wa -k network-modifications

## 5.2.3.24-29 Ensure events that modify user/group information are collected
-w /etc/group -p wa -k identity
-w /etc/passwd -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/security/opasswd -p wa -k identity

## 5.2.3.25 Ensure unsuccessful file access attempts are collected
-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=-1 -F key=access
-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=-1 -F key=access
-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=-1 -F key=access
-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=-1 -F key=access
EOF

    log "Audit configuration created"
}

# Load audit rules safely
load_audit_rules() {
    log "Loading audit rules..."
    
    # First try to clear all rules
    auditctl -D 2>/dev/null || warn "Could not clear all rules, continuing..."
    
    # Use augenrules to load rules
    augenrules --load 2>/dev/null || {
        warn "augenrules had issues, trying direct load..."
        auditctl -R /etc/audit/rules.d/audit.rules 2>/dev/null || true
    }
    
    # Check if rules loaded
    local rule_count=$(auditctl -l 2>/dev/null | wc -l)
    if [[ $rule_count -gt 5 ]]; then
        log "Audit rules loaded successfully ($rule_count rules)"
    else
        warn "Few rules loaded ($rule_count rules), this might be normal after reset"
    fi
}

# Start audit service with retry
start_audit_service() {
    log "Starting audit service..."
    
    # Try to start the service
    if systemctl start auditd; then
        log "Audit service started successfully"
        return 0
    fi
    
    # If service failed to start, try alternative methods
    warn "Service startup failed, trying alternative methods..."
    
    # Method 1: Start auditd directly
    if /sbin/auditd; then
        log "Audit service started via direct execution"
        return 0
    fi
    
    # Method 2: Check for specific errors
    local journal_output=$(journalctl -u auditd.service -n 10 --no-pager)
    if echo "$journal_output" | grep -q "Permission denied"; then
        error "Permission denied error detected. Checking SELinux contexts..."
        fix_selinux_contexts
        systemctl start auditd
    fi
    
    # Final check
    if systemctl is-active --quiet auditd; then
        log "Audit service is now running"
    else
        error "Failed to start audit service after multiple attempts"
        systemctl status auditd
        return 1
    fi
}

# Verify the fix
verify_fix() {
    log "Verifying the fix..."
    
    local success=true
    
    # Check service status
    if systemctl is-active --quiet auditd; then
        echo -e "${GREEN}✓ Audit service is running${NC}"
    else
        echo -e "${RED}✗ Audit service is not running${NC}"
        success=false
    fi
    
    # Check rules are loaded
    local rule_count=$(auditctl -l 2>/dev/null | wc -l)
    if [[ $rule_count -gt 10 ]]; then
        echo -e "${GREEN}✓ Audit rules loaded ($rule_count rules)${NC}"
    else
        echo -e "${YELLOW}⚠ Few audit rules loaded ($rule_count rules) - may need manual check${NC}"
    fi
    
    # Check SELinux contexts
    local audit_context=$(ls -dZ /var/log/audit 2>/dev/null | awk '{print $1}' || echo "unknown")
    if [[ "$audit_context" == *"auditd_log_t"* ]]; then
        echo -e "${GREEN}✓ SELinux context correct${NC}"
    else
        echo -e "${RED}✗ SELinux context may be incorrect: $audit_context${NC}"
        success=false
    fi
    
    # Check permissions
    local audit_dir_perm=$(stat -c %a /var/log/audit 2>/dev/null || echo "000")
    if [[ "$audit_dir_perm" == "750" ]]; then
        echo -e "${GREEN}✓ Directory permissions correct${NC}"
    else
        echo -e "${RED}✗ Directory permissions incorrect: $audit_dir_perm${NC}"
        success=false
    fi
    
    # Check audit log is being written
    if [[ -f /var/log/audit/audit.log ]] && [[ $(stat -c %s /var/log/audit/audit.log 2>/dev/null || echo 0) -gt 0 ]]; then
        echo -e "${GREEN}✓ Audit log is being written${NC}"
    else
        echo -e "${YELLOW}⚠ Audit log may not be active yet${NC}"
    fi
    
    if $success; then
        log "Verification completed successfully"
    else
        warn "Verification completed with some issues"
    fi
}

# Display current status
display_status() {
    log "Current audit status:"
    echo "=== Service Status ==="
    systemctl status auditd --no-pager -l
    
    echo -e "\n=== Audit Rules ==="
    auditctl -l 2>/dev/null | head -20
    echo "... (showing first 20 rules)"
    
    echo -e "\n=== Audit Statistics ==="
    auditctl -s 2>/dev/null || echo "Cannot get audit statistics"
    
    echo -e "\n=== SELinux Context ==="
    ls -laZ /var/log/audit/ 2>/dev/null || echo "Cannot check SELinux context"
}

# Main execution function
main() {
    log "Starting improved auditd compliance fix script..."
    
    check_root
    
    # Reset everything first
    reset_audit_service
    
    # Apply fixes
    fix_selinux_contexts
    fix_permissions
    create_audit_config
    load_audit_rules
    start_audit_service
    
    # Verify and display status
    verify_fix
    display_status
    
    log "Script completed!"
    log "Run your compliance scan again to check if the issues are resolved."
}

# Handle script interruption
cleanup() {
    warn "Script interrupted, performing cleanup..."
    exit 1
}

# Set trap for script interruption
trap cleanup SIGINT SIGTERM

# Run main function
main "$@"