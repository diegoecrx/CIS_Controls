#!/bin/bash

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check if auditd.conf exists
if [ ! -f /etc/audit/auditd.conf ]; then
    echo "auditd.conf not found" >&2
    exit 1
fi

# Get audit log directory from auditd.conf
log_dir=$(awk -F "=" '/^\s*log_file/ {print $2}' /etc/audit/auditd.conf | xargs)
log_dir=$(dirname "$log_dir")

# Check if log directory exists
if [ ! -d "$log_dir" ]; then
    echo "Audit log directory $log_dir not found" >&2
    exit 1
fi

# Fix audit log files not owned by adm or root group
find "$log_dir" -type f \( ! -group adm -a ! -group root \) -exec chgrp root {} +

# Ensure audit log directory is owned by root group
chgrp root "$log_dir"

# Configure log_group parameter in auditd.conf
sed -ri 's/^\s*#?\s*log_group\s*=\s*\S+(\s*#.*)?.*$/log_group = root\1/' /etc/audit/auditd.conf

# Restart audit daemon to reload configuration
systemctl restart auditd

# Verify remediation
result1=$(stat -c "%n %G" "$log_dir"/* 2>/dev/null | grep -Pv '^\h*\H+\h+(adm|root)\b' | awk '{print} END { if(NR==0) print "pass" ; else print "fail"}')

result2=$(grep -E '^\s*log_group\s*=\s*(root|adm)' /etc/audit/auditd.conf >/dev/null && echo "pass" || echo "fail")

if [ "$result1" = "pass" ] && [ "$result2" = "pass" ]; then
    echo "Compliance achieved: Audit log files are owned by authorized groups (root or adm)"
else
    echo "Remediation incomplete."
    if [ "$result1" != "pass" ]; then
        echo "Some audit log files have unauthorized group ownership:"
        stat -c "%n %G" "$log_dir"/* 2>/dev/null | grep -Pv '^\h*\H+\h+(adm|root)\b'
    fi
    if [ "$result2" != "pass" ]; then
        echo "log_group parameter not properly configured in auditd.conf"
    fi
    exit 1
fi