#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Check logrotate configuration with evidence
echo "Checking logrotate configuration:"

# Check if main configuration file exists
if [ -f /etc/logrotate.conf ]; then
    echo "PASS: /etc/logrotate.conf exists"
    echo "EVIDENCE: $(ls -la /etc/logrotate.conf)"
else
    echo "FAIL: /etc/logrotate.conf missing"
    echo "EVIDENCE: File /etc/logrotate.conf not found"
    exit 1
fi

# Check if configuration directory exists
if [ -d /etc/logrotate.d ]; then
    echo "PASS: /etc/logrotate.d directory exists"
    echo "EVIDENCE: $(ls -la /etc/logrotate.d/ | head -5)"
else
    echo "FAIL: /etc/logrotate.d directory missing"
    echo "EVIDENCE: Directory /etc/logrotate.d not found"
    exit 1
fi

# Check if logrotate package is installed
if rpm -q logrotate >/dev/null 2>&1; then
    echo "PASS: logrotate package is installed"
    echo "EVIDENCE: $(rpm -q logrotate)"
else
    echo "FAIL: logrotate package not installed"
    echo "EVIDENCE: rpm -q logrotate returned package not found"
    exit 1
fi

# Count configuration files for additional evidence
CONFIG_COUNT=$(find /etc/logrotate.d -type f 2>/dev/null | wc -l)
echo "EVIDENCE: $CONFIG_COUNT configuration files in /etc/logrotate.d/"

# Final verification
if [ -f /etc/logrotate.conf ] && [ -d /etc/logrotate.d ] && rpm -q logrotate >/dev/null 2>&1; then
    echo "PASS: logrotate is properly configured"
    echo "EVIDENCE: All required components present"
    exit 0
else
    echo "FAIL: logrotate configuration incomplete"
    echo "EVIDENCE: Missing required components"
    exit 1
fi