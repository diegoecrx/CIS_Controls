#!/bin/bash
set -euo pipefail

RULES_FILE="/etc/audit/rules.d/50-usermod.rules"
UID_MIN=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)

if [ -n "${UID_MIN}" ]; then
    echo "-a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=${UID_MIN} -F auid!=unset -k usermod" > "$RULES_FILE"
    
    augenrules --load
    
    if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
        echo "Reboot required to load rules"
    fi
else
    echo "ERROR: Variable 'UID_MIN' is unset."
    exit 1
fi