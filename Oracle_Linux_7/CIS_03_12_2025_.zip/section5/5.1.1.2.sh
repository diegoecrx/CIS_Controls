#!/usr/bin/env bash

# Script: 5.1.1.2.sh
# Item: 5.1.1.2 Ensure rsyslog service is enabled (Manual)
# Description: "Run the following command to enable rsyslog:
# # systemctl --now enable rsyslog"
# Default Value: n/a
# Profile Applicability: • Level 1 - Server • Level 1 - Workstation

set -euo pipefail

SCRIPT_NAME="5.1.1.2.sh"
ITEM_NAME="5.1.1.2 Ensure rsyslog service is enabled (Manual)"
DESCRIPTION="Ensure rsyslog service is enabled and active for system logging"
PROFILE_APPLICABILITY="• Level 1 - Server • Level 1 - Workstation"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Profile Applicability: $PROFILE_APPLICABILITY"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Main remediation function
{
    echo "Checking current rsyslog service status..."
    echo ""

    # Display current rsyslog status
    echo "Current rsyslog service status:"
    echo "==============================="
    
    # Check if rsyslog is installed
    if ! command -v rsyslogd >/dev/null 2>&1 && ! systemctl list-unit-files | grep -q rsyslog; then
        echo "rsyslog is NOT INSTALLED on this system"
        echo "Checking for alternative logging systems..."
        
        # Check for syslog-ng
        if command -v syslog-ng >/dev/null 2>&1; then
            echo "ALTERNATIVE: syslog-ng is installed"
            systemctl status syslog-ng --no-pager -l 2>/dev/null | head -5 || echo "Unable to get syslog-ng status"
        fi
        
        # Check for other logging daemons
        if systemctl list-unit-files | grep -E '(syslog|logging)' | grep -v rsyslog; then
            echo "Other logging services found:"
            systemctl list-unit-files | grep -E '(syslog|logging)' | grep -v rsyslog | head -5
        fi
        
        echo ""
        echo "This control specifically requires rsyslog - installation may be required"
        exit 0
    fi
    
    echo "rsyslog installation status:"
    echo "----------------------------"
    if command -v rsyslogd >/dev/null 2>&1; then
        rsyslogd --version 2>/dev/null | head -1 || echo "rsyslog is installed"
    else
        echo "rsyslog command not found, checking service..."
    fi
    
    echo ""
    
    # Check service status
    echo "rsyslog service status:"
    echo "-----------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "ACTIVE"
        rsyslog_active=true
    else
        echo "INACTIVE"
        rsyslog_active=false
    fi
    
    if systemctl is-enabled rsyslog >/dev/null 2>&1; then
        echo "ENABLED at boot"
        rsyslog_enabled=true
    else
        echo "DISABLED at boot"
        rsyslog_enabled=false
    fi
    
    echo ""
    
    # Show detailed service status
    echo "Detailed service status:"
    echo "------------------------"
    systemctl status rsyslog --no-pager -l 2>/dev/null | head -10 || echo "Unable to get detailed service status"
    
    echo ""
    
    # Check if rsyslog is actually running
    echo "rsyslog process status:"
    echo "-----------------------"
    if pgrep -x rsyslogd >/dev/null 2>&1; then
        echo "RUNNING - Process ID(s): $(pgrep -x rsyslogd | tr '\n' ' ')"
        echo ""
        echo "Process details:"
        ps -p $(pgrep -x rsyslogd | head -1) -o pid,user,command 2>/dev/null || echo "Unable to get process details"
    else
        echo "NOT RUNNING - No rsyslogd processes found"
    fi
    
    echo ""
    
    # Check configuration file
    echo "rsyslog configuration:"
    echo "----------------------"
    if [ -f /etc/rsyslog.conf ]; then
        echo "Main configuration file: /etc/rsyslog.conf exists"
        # Check for included configs
        if [ -d /etc/rsyslog.d ]; then
            echo "Additional config directory: /etc/rsyslog.d exists ($(ls /etc/rsyslog.d/*.conf 2>/dev/null | wc -l || echo 0) config files)"
        fi
    else
        echo "WARNING: /etc/rsyslog.conf does not exist"
    fi
    
    echo ""
    echo "Applying remediation..."

    # Remediation functions
    check_service_status()
    {
        echo " - Checking rsyslog service status..."
        
        if [ "$rsyslog_active" = true ]; then
            echo " - SUCCESS: rsyslog service is ACTIVE"
        else
            echo " - WARNING: rsyslog service is INACTIVE"
        fi
        
        if [ "$rsyslog_enabled" = true ]; then
            echo " - SUCCESS: rsyslog service is ENABLED at boot"
        else
            echo " - WARNING: rsyslog service is DISABLED at boot"
        fi
    }

    check_alternative_logging()
    {
        echo " - Checking for alternative logging systems..."
        
        alternatives_found=false
        
        # Check for systemd journal only
        if systemctl is-active systemd-journald >/dev/null 2>&1; then
            echo " - INFO: systemd-journald is active (expected with rsyslog)"
        fi
        
        # Check for syslog-ng
        if command -v syslog-ng >/dev/null 2>&1; then
            if systemctl is-active syslog-ng >/dev/null 2>&1; then
                echo " - WARNING: syslog-ng is active and may conflict with rsyslog"
                alternatives_found=true
            fi
        fi
        
        # Check for other syslog implementations
        if systemctl list-unit-files | grep -E '^(rsyslog|syslog-ng|syslog)' | grep -v rsyslog | grep enabled; then
            echo " - WARNING: Other logging services are enabled"
            alternatives_found=true
        fi
        
        if [ "$alternatives_found" = false ]; then
            echo " - OK: No conflicting logging services found"
        fi
    }

    check_logging_functionality()
    {
        echo " - Checking logging functionality..."
        
        # Test if logging is working by sending a test message
        test_message="TEST-MESSAGE-$(date +%s)-rsyslog-test-$(hostname)"
        
        if logger "$test_message" 2>/dev/null; then
            echo " - SUCCESS: Test message sent via logger command"
            
            # Try to verify the message was logged (this may not work in all environments)
            if [ -d /var/log ] && ls /var/log/*log 2>/dev/null | head -1 >/dev/null; then
                echo " - INFO: Log directory /var/log is accessible"
            fi
        else
            echo " - WARNING: Could not send test message via logger"
        fi
    }

    provide_remediation_guidance()
    {
        echo " - Providing rsyslog remediation guidance..."
        
        echo ""
        echo "RSYSLOG REMEDIATION GUIDANCE:"
        echo "============================="
        echo ""
        
        if [ "$rsyslog_active" = false ]; then
            echo "START RSYSLOG SERVICE:"
            echo "  systemctl start rsyslog"
            echo ""
        fi
        
        if [ "$rsyslog_enabled" = false ]; then
            echo "ENABLE RSYSLOG AT BOOT:"
            echo "  systemctl enable rsyslog"
            echo ""
        fi
        
        echo "ENABLE AND START RSYSLOG (combined command):"
        echo "  systemctl --now enable rsyslog"
        echo ""
        
        if [ "$rsyslog_active" = true ] && [ "$rsyslog_enabled" = true ]; then
            echo "RESTART RSYSLOG (if configuration changes were made):"
            echo "  systemctl restart rsyslog"
            echo ""
        fi
        
        echo "VERIFY SERVICE STATUS:"
        echo "  systemctl is-active rsyslog"
        echo "  systemctl is-enabled rsyslog"
        echo "  systemctl status rsyslog"
        echo ""
        echo "CHECK LOGGING FUNCTIONALITY:"
        echo "  logger \"Test message from $(hostname) at $(date)\""
        echo "  tail -f /var/log/messages /var/log/syslog 2>/dev/null | grep \"Test message\""
        echo ""
        echo "VIEW CONFIGURATION:"
        echo "  rsyslogd -N 1    # Validate configuration syntax"
        echo "  cat /etc/rsyslog.conf"
    }

    # Apply remediation steps
    remediation_applied=false
    
    echo ""
    echo "Checking service status..."
    check_service_status
    remediation_applied=true
    
    echo ""
    echo "Checking for alternative logging systems..."
    check_alternative_logging
    remediation_applied=true
    
    echo ""
    echo "Testing logging functionality..."
    check_logging_functionality
    remediation_applied=true

    echo ""
    provide_remediation_guidance

    if [ "$remediation_applied" = false ]; then
        echo ""
        echo "No rsyslog installation detected"
    fi

    echo ""
    echo "Remediation of rsyslog service configuration complete"

    # Verify and enforce final status with PROOFS
    echo ""
    echo "==================================================================="
    echo "Final Status Verification with Proofs:"
    echo "==================================================================="
    
    # Final verification and enforcement
    final_status_pass=true
    
    # PROOF 1: Verify rsyslog service is active
    echo ""
    echo "1. VERIFYING RSYSLOG SERVICE IS ACTIVE:"
    echo "---------------------------------------"
    if systemctl is-active rsyslog >/dev/null 2>&1; then
        echo "PASS: rsyslog service is ACTIVE"
        echo "PROOF (systemctl is-active rsyslog): active"
        echo ""
        echo "Detailed status:"
        systemctl status rsyslog --no-pager -l 2>/dev/null | head -5
    else
        echo "FAIL: rsyslog service is INACTIVE"
        echo "PROOF (systemctl is-active rsyslog): inactive"
        final_status_pass=false
        
        # Attempt to start the service for verification
        echo ""
        echo "Attempting to start rsyslog service..."
        if systemctl start rsyslog 2>/dev/null; then
            echo "SUCCESS: rsyslog service started"
            if systemctl is-active rsyslog >/dev/null 2>&1; then
                echo "PASS: rsyslog service is now ACTIVE"
                final_status_pass=true
            fi
        else
            echo "WARNING: Could not start rsyslog service"
        fi
    fi
    
    # PROOF 2: Verify rsyslog service is enabled at boot
    echo ""
    echo "2. VERIFYING RSYSLOG SERVICE IS ENABLED AT BOOT:"
    echo "------------------------------------------------"
    if systemctl is-enabled rsyslog >/dev/null 2>&1; then
        echo "PASS: rsyslog service is ENABLED at boot"
        echo "PROOF (systemctl is-enabled rsyslog): enabled"
        echo ""
        echo "Service enablement details:"
        systemctl list-unit-files | grep rsyslog | head -2
    else
        echo "FAIL: rsyslog service is DISABLED at boot"
        echo "PROOF (systemctl is-enabled rsyslog): disabled"
        final_status_pass=false
        
        # Attempt to enable the service for verification
        echo ""
        echo "Attempting to enable rsyslog service..."
        if systemctl enable rsyslog 2>/dev/null; then
            echo "SUCCESS: rsyslog service enabled at boot"
            if systemctl is-enabled rsyslog >/dev/null 2>&1; then
                echo "PASS: rsyslog service is now ENABLED at boot"
                final_status_pass=true
            fi
        else
            echo "WARNING: Could not enable rsyslog service"
        fi
    fi
    
    # PROOF 3: Verify rsyslog process is running
    echo ""
    echo "3. VERIFYING RSYSLOG PROCESS IS RUNNING:"
    echo "----------------------------------------"
    if pgrep -x rsyslogd >/dev/null 2>&1; then
        echo "PASS: rsyslog process is RUNNING"
        echo "PROOF (pgrep -x rsyslogd): $(pgrep -x rsyslogd | tr '\n' ' ')"
        echo ""
        echo "Process details:"
        ps -p $(pgrep -x rsyslogd | head -1) -o pid,user,pcpu,pmem,vsz,rss,command 2>/dev/null | head -2
    else
        echo "FAIL: rsyslog process is NOT RUNNING"
        echo "PROOF (pgrep -x rsyslogd): no output"
        final_status_pass=false
    fi
    
    # PROOF 4: Verify configuration files exist
    echo ""
    echo "4. VERIFYING CONFIGURATION FILES:"
    echo "---------------------------------"
    config_ok=true
    if [ -f /etc/rsyslog.conf ]; then
        echo "PASS: /etc/rsyslog.conf exists"
        echo "PROOF (ls -la /etc/rsyslog.conf):"
        ls -la /etc/rsyslog.conf 2>/dev/null | head -1
    else
        echo "FAIL: /etc/rsyslog.conf does not exist"
        config_ok=false
        final_status_pass=false
    fi
    
    if [ -d /etc/rsyslog.d ]; then
        echo "PASS: /etc/rsyslog.d directory exists"
        echo "PROOF (number of config files): $(ls /etc/rsyslog.d/*.conf 2>/dev/null | wc -l || echo 0)"
    else
        echo "INFO: /etc/rsyslog.d directory does not exist"
    fi
    
    # PROOF 5: Test logging functionality
    echo ""
    echo "5. TESTING LOGGING FUNCTIONALITY:"
    echo "---------------------------------"
    test_message="RSYSLOG-TEST-$(date +%Y%m%d-%H%M%S)-$(hostname)"
    if logger "RSYSLOG-TEST: $test_message" 2>/dev/null; then
        echo "PASS: Test message sent successfully via logger"
        echo "PROOF (logger command): exit code 0"
        echo "Test message: $test_message"
    else
        echo "WARNING: Could not send test message via logger"
        echo "PROOF (logger command): non-zero exit code"
    fi
    
    # PROOF 6: Manual verification steps reminder
    echo ""
    echo "6. MANUAL VERIFICATION REQUIRED:"
    echo "-------------------------------"
    echo "This is a MANUAL control item. Additional verification required:"
    echo "• Verify logs are being written to appropriate files"
    echo "• Check log rotation is functioning correctly"
    echo "• Ensure sufficient disk space for log files"
    echo "• Test log forwarding if configured"
    echo "• Verify log file permissions and ownership"
    echo "• Monitor log entries for system activity"
    echo ""
    echo "RSYSLOG MANAGEMENT COMMANDS:"
    echo "============================"
    echo ""
    echo "SERVICE MANAGEMENT:"
    echo "  systemctl status rsyslog      # Check service status"
    echo "  systemctl start rsyslog       # Start service"
    echo "  systemctl stop rsyslog        # Stop service"
    echo "  systemctl restart rsyslog     # Restart service"
    echo "  systemctl enable rsyslog      # Enable at boot"
    echo "  systemctl disable rsyslog     # Disable at boot"
    echo ""
    echo "CONFIGURATION:"
    echo "  rsyslogd -N 1                 # Validate configuration"
    echo "  vi /etc/rsyslog.conf          # Edit main configuration"
    echo "  systemctl reload rsyslog      # Reload configuration"
    echo ""
    echo "LOGGING TESTING:"
    echo "  logger \"Test message\"        # Send test message"
    echo "  tail -f /var/log/syslog       # Monitor logs (Debian/Ubuntu)"
    echo "  tail -f /var/log/messages     # Monitor logs (RHEL/CentOS)"

    if [ "$final_status_pass" = true ]; then
        echo ""
        echo "SUCCESS: rsyslog service verification completed"
        echo "NOTE: Manual review required to verify logging functionality"
    else
        echo ""
        echo "WARNING: rsyslog service issues detected - manual remediation required"
    fi

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="