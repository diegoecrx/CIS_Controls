#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

chown root:root /etc/cron.daily
chmod 700 /etc/cron.daily

ls -ld /etc/cron.daily
stat -c "%U %G %a" /etc/cron.daily

if [[ $(stat -c "%U" /etc/cron.daily) == "root" && \
      $(stat -c "%G" /etc/cron.daily) == "root" && \
      $(stat -c "%a" /etc/cron.daily) == "700" ]]; then
    echo "pass"
else
    echo "FAIL: /etc/cron.daily permissions configuration failed"
    exit 1
fi