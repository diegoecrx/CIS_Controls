#!/usr/bin/env bash
# Script: 4.2.15.sh
# Item: 4.2.15 Ensure sshd MACs are configured (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.15.sh"
ITEM_NAME="4.2.15 Ensure sshd MACs are configured (Automated)"
DESCRIPTION="This remediation ensures sshd MACs are configured properly in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    desired="hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256"
    conf_line=$(grep -i '^MACs' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -q "$desired"; then
        echo "PASS: Correct MACs set"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: Incorrect or missing MACs"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_macs() {
    echo "Applying fix..."
    sed -i '/^MACs/d' /etc/ssh/sshd_config
    echo "MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256" >> /etc/ssh/sshd_config
    echo " - Set MACs"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_macs
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: MACs configured"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="