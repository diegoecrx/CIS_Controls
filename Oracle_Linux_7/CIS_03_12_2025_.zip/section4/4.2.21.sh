#!/usr/bin/env bash
# Script: 4.2.21.sh
# Item: 4.2.21 Ensure sshd PermitUserEnvironment is disabled (Automated)
set -euo pipefail
SCRIPT_NAME="4.2.21.sh"
ITEM_NAME="4.2.21 Ensure sshd PermitUserEnvironment is disabled (Automated)"
DESCRIPTION="This remediation ensures sshd PermitUserEnvironment is disabled by setting to no in sshd_config."
# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi
echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""
# Function to check current status
check_current_status() {
    echo "Checking /etc/ssh/sshd_config..."
    conf_line=$(grep -i '^PermitUserEnvironment' /etc/ssh/sshd_config | head -n1 || true)
    if [ -n "$conf_line" ] && echo "$conf_line" | grep -qi 'no'; then
        echo "PASS: PermitUserEnvironment no set"
        echo "PROOF: $conf_line"
        return 0
    else
        echo "FAIL: PermitUserEnvironment not no"
        echo "PROOF: $conf_line"
        return 1
    fi
}
# Function to fix
fix_permituserenvironment() {
    echo "Applying fix..."
    sed -i '/^PermitUserEnvironment/d' /etc/ssh/sshd_config
    echo "PermitUserEnvironment no" >> /etc/ssh/sshd_config
    echo " - Set PermitUserEnvironment no"
    systemctl reload sshd 2>/dev/null || true
}
# Main remediation
{
    if check_current_status; then
        echo "No remediation needed"
    else
        fix_permituserenvironment
    fi
    echo ""
    echo "==================================================================="
    echo "Final Verification with Proofs:"
    echo "==================================================================="
    if check_current_status; then
        echo "SUCCESS: PermitUserEnvironment disabled"
    else
        echo "FAIL: Issues remain"
    fi
}
echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="