#!/bin/bash

# Enforce CIS 4.4.2.2.7 - Ensure password dictionary check is enabled
echo "Enforcing CIS 4.4.2.2.7 - Password dictionary check configuration..."

# Configure dictcheck in pwquality.conf
echo "Configuring dictcheck in /etc/security/pwquality.conf..."

# Backup original file
if [ ! -f /etc/security/pwquality.conf.bak ]; then
    cp /etc/security/pwquality.conf /etc/security/pwquality.conf.bak
    echo "Backed up /etc/security/pwquality.conf to /etc/security/pwquality.conf.bak"
fi

# Remove any dictcheck = 0 setting and ensure dictcheck is enabled (default is 1)
sed -ri 's/^(\s*)dictcheck\s*=\s*0.*/# &/' /etc/security/pwquality.conf

# Remove dictcheck parameter from pam_pwquality.so lines in PAM files
echo "Removing dictcheck parameter from PAM files..."
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        # Backup PAM file
        if [ ! -f "/etc/pam.d/${pam_file}.bak" ]; then
            cp "/etc/pam.d/${pam_file}" "/etc/pam.d/${pam_file}.bak"
        fi
        
        # Remove dictcheck parameter from pam_pwquality.so lines
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+dictcheck\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        echo "Cleaned dictcheck parameter from /etc/pam.d/${pam_file}"
    fi
done

# Verify configuration
echo "Verifying dictionary check configuration..."

# Check that dictcheck is not set to 0 in pwquality.conf
if ! grep -q "^dictcheck\s*=\s*0" /etc/security/pwquality.conf; then
    echo "SUCCESS: dictcheck is not disabled (set to 0) in /etc/security/pwquality.conf"
else
    echo "ERROR: dictcheck is disabled in /etc/security/pwquality.conf"
    exit 1
fi

# Verify dictcheck parameter is not in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if ! grep -q "pam_pwquality\.so.*dictcheck" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: dictcheck parameter removed from /etc/pam.d/${pam_file}"
        else
            echo "ERROR: dictcheck parameter still present in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Verify pam_pwquality is still properly configured in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if grep -q "^password.*requisite.*pam_pwquality\.so.*try_first_pass.*local_users_only" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: pam_pwquality properly configured in /etc/pam.d/${pam_file}"
        else
            echo "ERROR: pam_pwquality configuration broken in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/security/pwquality.conf ] && [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: Configuration files are readable and properly configured"
    else
        echo "ERROR: Configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.2.7 remediation completed successfully"
echo "Password dictionary check is enabled (default behavior)"