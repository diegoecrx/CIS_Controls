#!/bin/bash
if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this program." >&2
    exit 1
fi

# Backup original files
echo "Creating backups of original files..."
cp /etc/profile /etc/profile.backup.$(date +%Y%m%d_%H%M%S)
cp /etc/bashrc /etc/bashrc.backup.$(date +%Y%m%d_%H%M%S)

# Fix /etc/profile - line 61
echo "Fixing /etc/profile..."
sed -i '61s/.*/    export HISTCONTROL=ignoreboth/' /etc/profile

# Fix /etc/bashrc - line 72  
echo "Fixing /etc/bashrc..."
sed -i '72s/.*/        . "$i" >\/dev\/null/' /etc/bashrc

# Verify fixes
echo "Verifying fixes..."
echo "Checking /etc/profile syntax:"
bash -n /etc/profile && echo "✓ /etc/profile syntax is now correct" || echo "✗ /etc/profile still has syntax errors"

echo "Checking /etc/bashrc syntax:"
bash -n /etc/bashrc && echo "✓ /etc/bashrc syntax is now correct" || echo "✗ /etc/bashrc still has syntax errors"

# Apply changes
echo "Applying changes to current session..."
source /etc/profile
source /etc/bashrc

echo "Fix completed. The syntax errors should be resolved."