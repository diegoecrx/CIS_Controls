#!/bin/bash

# Enforce CIS 4.2.5 - Ensure sshd Banner is configured
echo "Enforcing CIS 4.2.5 - SSH Banner configuration..."

# Backup original sshd_config
if [ ! -f /etc/ssh/sshd_config.bak ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    echo "Backed up /etc/ssh/sshd_config to /etc/ssh/sshd_config.bak"
fi

# Ensure the banner file exists with proper content
if [ ! -f /etc/issue.net ]; then
    echo "Authorized users only. All activity may be monitored and reported." > /etc/issue.net
    echo "Created /etc/issue.net with compliant banner content"
fi

# Set proper permissions on banner file
chmod 644 /etc/issue.net
chown root:root /etc/issue.net

# Check if Banner is already set
if grep -q "^Banner" /etc/ssh/sshd_config; then
    # Update existing setting to /etc/issue.net
    sed -i 's|^Banner.*|Banner /etc/issue.net|' /etc/ssh/sshd_config
    echo "Updated existing Banner setting to '/etc/issue.net'"
else
    # Add new setting at the beginning (above any Match entries)
    sed -i '1iBanner /etc/issue.net' /etc/ssh/sshd_config
    echo "Added Banner /etc/issue.net to /etc/ssh/sshd_config"
fi

# Restart sshd service to apply changes
echo "Restarting sshd service..."
systemctl restart sshd

# Verify configuration
echo "Verifying SSH Banner configuration..."

# Check if setting is correctly configured in file
if grep -q "^Banner /etc/issue.net" /etc/ssh/sshd_config; then
    echo "SUCCESS: Banner set to '/etc/issue.net' in /etc/ssh/sshd_config"
else
    echo "ERROR: Banner not properly set in /etc/ssh/sshd_config"
    exit 1
fi

# Check if banner file exists and has content
if [ -f /etc/issue.net ] && [ -s /etc/issue.net ]; then
    echo "SUCCESS: Banner file /etc/issue.net exists and has content"
else
    echo "ERROR: Banner file /etc/issue.net missing or empty"
    exit 1
fi

# Check banner file permissions
if [ "$(stat -c %a /etc/issue.net)" = "644" ] && [ "$(stat -c %U:%G /etc/issue.net)" = "root:root" ]; then
    echo "SUCCESS: Banner file has correct permissions and ownership"
else
    echo "ERROR: Banner file has incorrect permissions or ownership"
    exit 1
fi

# Check if sshd service is running
if systemctl is-active sshd > /dev/null 2>&1; then
    echo "SUCCESS: sshd service is running"
else
    echo "ERROR: sshd service is not running"
    exit 1
fi

# Test sshd configuration syntax
if sshd -t > /dev/null 2>&1; then
    echo "SUCCESS: sshd configuration syntax is valid"
else
    echo "ERROR: sshd configuration syntax is invalid"
    exit 1
fi

echo "CIS 4.2.5 remediation completed successfully"