#!/bin/bash

# Enforce CIS 4.4.2.2.2 - Ensure password number of changed characters is configured
echo "Enforcing CIS 4.4.2.2.2 - Password changed characters configuration..."

# Configure difok in pwquality.conf
echo "Configuring difok in /etc/security/pwquality.conf..."

# Backup original file
if [ ! -f /etc/security/pwquality.conf.bak ]; then
    cp /etc/security/pwquality.conf /etc/security/pwquality.conf.bak
    echo "Backed up /etc/security/pwquality.conf to /etc/security/pwquality.conf.bak"
fi

# Remove existing difok setting and add new one
sed -ri 's/^(\s*)difok\s*=.*/# &/' /etc/security/pwquality.conf
echo "difok = 2" >> /etc/security/pwquality.conf

# Remove difok parameter from pam_pwquality.so lines in PAM files
echo "Removing difok parameter from PAM files..."
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        # Backup PAM file
        if [ ! -f "/etc/pam.d/${pam_file}.bak" ]; then
            cp "/etc/pam.d/${pam_file}" "/etc/pam.d/${pam_file}.bak"
        fi
        
        # Remove difok parameter from pam_pwquality.so lines
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+difok\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        echo "Cleaned difok parameter from /etc/pam.d/${pam_file}"
    fi
done

# Verify configuration
echo "Verifying password changed characters configuration..."

# Check difok setting in pwquality.conf
if grep -q "^difok\s*=\s*2" /etc/security/pwquality.conf; then
    echo "SUCCESS: difok = 2 configured in /etc/security/pwquality.conf"
else
    echo "ERROR: difok not properly configured in /etc/security/pwquality.conf"
    exit 1
fi

# Verify difok parameter is not in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if ! grep -q "pam_pwquality\.so.*difok" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: difok parameter removed from /etc/pam.d/${pam_file}"
        else
            echo "ERROR: difok parameter still present in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Verify pam_pwquality is still properly configured in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if grep -q "^password.*requisite.*pam_pwquality\.so.*try_first_pass.*local_users_only" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: pam_pwquality properly configured in /etc/pam.d/${pam_file}"
        else
            echo "ERROR: pam_pwquality configuration broken in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/security/pwquality.conf ] && [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: Configuration files are readable and properly configured"
    else
        echo "ERROR: Configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.2.2 remediation completed successfully"
echo "Password policy requires at least 2 changed characters from old password"