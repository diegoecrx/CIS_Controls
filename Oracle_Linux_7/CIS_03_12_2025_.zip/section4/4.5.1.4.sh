#!/bin/bash
set -euo pipefail

REQUIRED_INACTIVE_DAYS=30
DEFAULT_PASSWORD="@Real2014NewYeah_"

[ "$EUID" -eq 0 ] || { echo "Must be run as root" >&2; exit 1; }

echo "=== Setting Inactive Password Lock to $REQUIRED_INACTIVE_DAYS days ==="

# Set default for new users
useradd -D -f "$REQUIRED_INACTIVE_DAYS"
echo "Default for new users set to $REQUIRED_INACTIVE_DAYS days"
echo ""

# Process users
users_changed=0
for user in $(awk -F: '$2 !~ /^[!*]/ && $2 != "" {print $1}' /etc/shadow); do
    echo "--- Processing: $user ---"
    
    # Get current inactive setting
    inactive=$(chage -l "$user" 2>/dev/null | grep "Inactive" | awk -F: '{print $2}' | tr -d ' ' || echo "not set")
    
    if [[ "$inactive" == "$REQUIRED_INACTIVE_DAYS" ]]; then
        echo "Already compliant: $REQUIRED_INACTIVE_DAYS days"
        echo ""
        continue
    fi
    
    echo "Current inactive: ${inactive} days"
    echo "Required: $REQUIRED_INACTIVE_DAYS days"
    
    # Set password automatically
    echo "Setting password for $user..."
    if echo "$user:$DEFAULT_PASSWORD" | chpasswd; then
        echo "✓ Password changed successfully"
        chage --inactive "$REQUIRED_INACTIVE_DAYS" "$user"
        echo "✓ Inactive lock set to $REQUIRED_INACTIVE_DAYS days"
        ((users_changed++))
    else
        echo "✗ Password change failed. Inactive lock NOT applied."
        echo "User $user will keep current settings."
    fi
    
    echo ""
done

echo "=== Summary ==="
for user in $(awk -F: '$2 !~ /^[!*]/ && $2 != "" {print $1}' /etc/shadow); do
    inactive=$(chage -l "$user" 2>/dev/null | grep "Inactive" | awk -F: '{print $2}' | tr -d ' ' || echo "not set")
    printf "%-20s: %s days\n" "$user" "$inactive"
done

echo ""
echo "Summary: Changed passwords for $users_changed user(s)"