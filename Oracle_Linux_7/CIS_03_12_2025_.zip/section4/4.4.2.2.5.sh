#!/bin/bash

# Enforce CIS 4.4.2.2.5 - Ensure password same consecutive characters is configured
echo "Enforcing CIS 4.4.2.2.5 - Password consecutive characters configuration..."

# Configure maxrepeat in pwquality.conf
echo "Configuring maxrepeat in /etc/security/pwquality.conf..."

# Backup original file
if [ ! -f /etc/security/pwquality.conf.bak ]; then
    cp /etc/security/pwquality.conf /etc/security/pwquality.conf.bak
    echo "Backed up /etc/security/pwquality.conf to /etc/security/pwquality.conf.bak"
fi

# Remove existing maxrepeat setting and add new one
sed -ri 's/^(\s*)maxrepeat\s*=.*/# &/' /etc/security/pwquality.conf
echo "maxrepeat = 3" >> /etc/security/pwquality.conf

# Remove maxrepeat parameter from pam_pwquality.so lines in PAM files
echo "Removing maxrepeat parameter from PAM files..."
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        # Backup PAM file
        if [ ! -f "/etc/pam.d/${pam_file}.bak" ]; then
            cp "/etc/pam.d/${pam_file}" "/etc/pam.d/${pam_file}.bak"
        fi
        
        # Remove maxrepeat parameter from pam_pwquality.so lines
        sed -ri 's/(^\s*password\s+(requisite|required|sufficient)\s+pam_pwquality\.so.*)(\s+maxrepeat\s*=\s*\S+)(.*$)/\1\4/' "/etc/pam.d/${pam_file}"
        echo "Cleaned maxrepeat parameter from /etc/pam.d/${pam_file}"
    fi
done

# Verify configuration
echo "Verifying consecutive characters configuration..."

# Check maxrepeat setting in pwquality.conf
if grep -q "^maxrepeat\s*=\s*3" /etc/security/pwquality.conf; then
    echo "SUCCESS: maxrepeat = 3 configured in /etc/security/pwquality.conf"
else
    echo "ERROR: maxrepeat not properly configured in /etc/security/pwquality.conf"
    exit 1
fi

# Verify maxrepeat parameter is not in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if ! grep -q "pam_pwquality\.so.*maxrepeat" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: maxrepeat parameter removed from /etc/pam.d/${pam_file}"
        else
            echo "ERROR: maxrepeat parameter still present in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Verify pam_pwquality is still properly configured in PAM files
for pam_file in system-auth password-auth; do
    if [ -f "/etc/pam.d/${pam_file}" ]; then
        if grep -q "^password.*requisite.*pam_pwquality\.so.*try_first_pass.*local_users_only" "/etc/pam.d/${pam_file}"; then
            echo "SUCCESS: pam_pwquality properly configured in /etc/pam.d/${pam_file}"
        else
            echo "ERROR: pam_pwquality configuration broken in /etc/pam.d/${pam_file}"
            exit 1
        fi
    fi
done

# Test PAM configuration syntax
if pam-config --validate > /dev/null 2>&1; then
    echo "SUCCESS: PAM configuration syntax is valid"
else
    echo "WARNING: Unable to validate PAM configuration with pam-config"
    # Manual validation
    if [ -r /etc/security/pwquality.conf ] && [ -r /etc/pam.d/system-auth ] && [ -r /etc/pam.d/password-auth ]; then
        echo "SUCCESS: Configuration files are readable and properly configured"
    else
        echo "ERROR: Configuration files issue detected"
        exit 1
    fi
fi

echo "CIS 4.4.2.2.5 remediation completed successfully"
echo "Password policy now limits consecutive identical characters to 3"