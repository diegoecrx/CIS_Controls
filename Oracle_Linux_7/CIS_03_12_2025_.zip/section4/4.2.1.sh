#!/usr/bin/env bash

# Script: 4.2.1.sh
# Item: 4.2.1 Ensure permissions on /etc/ssh/sshd_config are configured (Automated)

set -euo pipefail

SCRIPT_NAME="4.2.1.sh"
ITEM_NAME="4.2.1 Ensure permissions on /etc/ssh/sshd_config are configured (Automated)"
DESCRIPTION="This remediation ensures /etc/ssh/sshd_config and files in /etc/ssh/sshd_config.d have correct ownership and permissions configured."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

echo "Checking current SSH configuration file permissions..."
echo ""

# Display current status
if [ -e /etc/ssh/sshd_config ]; then
  echo "Current /etc/ssh/sshd_config permissions:"
  ls -l /etc/ssh/sshd_config
  stat /etc/ssh/sshd_config
else
  echo "WARNING: /etc/ssh/sshd_config does not exist"
fi

echo ""

if [ -d /etc/ssh/sshd_config.d ]; then
  echo "Files in /etc/ssh/sshd_config.d directory:"
  ls -la /etc/ssh/sshd_config.d/ 2>/dev/null || echo "Directory exists but is empty or inaccessible"
else
  echo "NOTE: /etc/ssh/sshd_config.d directory does not exist"
fi

echo ""
echo "Applying remediation..."
echo ""

# Set permissions on main sshd_config file
if [ -e /etc/ssh/sshd_config ]; then
  echo " - Setting permissions on /etc/ssh/sshd_config to 600 (u-x,og-rwx)"
  chmod u-x,og-rwx /etc/ssh/sshd_config
  
  echo " - Setting ownership on /etc/ssh/sshd_config to root:root"
  chown root:root /etc/ssh/sshd_config
else
  echo " - WARNING: /etc/ssh/sshd_config does not exist - skipping"
fi

# Set permissions on files in sshd_config.d directory
if [ -d /etc/ssh/sshd_config.d ]; then
  echo " - Processing files in /etc/ssh/sshd_config.d directory"
  
  file_count=0
  while IFS= read -r -d $'\0' l_file; do
    if [ -e "$l_file" ]; then
      echo "   - Processing: $l_file"
      chmod u-x,og-rwx "$l_file"
      chown root:root "$l_file"
      ((file_count++))
    fi
  done < <(find /etc/ssh/sshd_config.d -type f -print0 2>/dev/null)
  
  echo "   - Processed $file_count file(s) in /etc/ssh/sshd_config.d"
else
  echo " - /etc/ssh/sshd_config.d directory does not exist - no additional files to process"
fi

echo ""
echo " - SUCCESS: Applied ownership and permissions"
echo ""

echo "Remediation of SSH configuration permissions complete"

# Verify and enforce final status with PROOFS
echo ""
echo "==================================================================="
echo "Final Status Verification with Proofs:"
echo "==================================================================="

# Final verification and enforcement
final_status_pass=true

# PROOF 1: Verify /etc/ssh/sshd_config exists and has correct ownership
if [ -e /etc/ssh/sshd_config ]; then
  echo ""
  echo "1. VERIFYING /etc/ssh/sshd_config OWNERSHIP IS root:root:"
  echo "---------------------------------------------------------"
  current_owner=$(stat -c '%U' /etc/ssh/sshd_config)
  current_group=$(stat -c '%G' /etc/ssh/sshd_config)

  if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
    echo "PASS: /etc/ssh/sshd_config is owned by root:root"
    echo "PROOF (stat output):"
    stat /etc/ssh/sshd_config | grep -E '(Uid|Gid)'
  else
    echo "FAIL: /etc/ssh/sshd_config ownership is NOT root:root - fixing now"
    chown root:root /etc/ssh/sshd_config
    
    current_owner=$(stat -c '%U' /etc/ssh/sshd_config)
    current_group=$(stat -c '%G' /etc/ssh/sshd_config)
    
    if [ "$current_owner" = "root" ] && [ "$current_group" = "root" ]; then
      echo "PASS: /etc/ssh/sshd_config ownership corrected to root:root"
      echo "PROOF (stat output):"
      stat /etc/ssh/sshd_config | grep -E '(Uid|Gid)'
    else
      echo "FAIL: Could not set ownership to root:root"
      final_status_pass=false
    fi
  fi

  # PROOF 2: Verify /etc/ssh/sshd_config permissions are 600 or more restrictive
  echo ""
  echo "2. VERIFYING /etc/ssh/sshd_config PERMISSIONS ARE 600 OR MORE RESTRICTIVE:"
  echo "-------------------------------------------------------------------------"
  current_perms=$(stat -c '%a' /etc/ssh/sshd_config)

  if [ "$current_perms" = "600" ] || [ "$current_perms" = "400" ]; then
    echo "PASS: /etc/ssh/sshd_config has permissions $current_perms (600 or more restrictive)"
    echo "PROOF (stat output):"
    stat -c 'Access: (%a/%A)' /etc/ssh/sshd_config
  else
    echo "FAIL: /etc/ssh/sshd_config permissions are $current_perms (expected 600 or more restrictive) - fixing now"
    chmod 600 /etc/ssh/sshd_config
    
    current_perms=$(stat -c '%a' /etc/ssh/sshd_config)
    
    if [ "$current_perms" = "600" ]; then
      echo "PASS: /etc/ssh/sshd_config permissions corrected to 600"
      echo "PROOF (stat output):"
      stat -c 'Access: (%a/%A)' /etc/ssh/sshd_config
    else
      echo "FAIL: Could not set permissions to 600"
      final_status_pass=false
    fi
  fi
else
  echo ""
  echo "WARNING: /etc/ssh/sshd_config does not exist - cannot verify"
  final_status_pass=false
fi

# PROOF 3: Verify files in /etc/ssh/sshd_config.d have correct permissions
if [ -d /etc/ssh/sshd_config.d ]; then
  echo ""
  echo "3. VERIFYING FILES IN /etc/ssh/sshd_config.d HAVE CORRECT PERMISSIONS:"
  echo "----------------------------------------------------------------------"
  
  config_files_ok=true
  file_count=0
  
  while IFS= read -r -d $'\0' l_file; do
    if [ -e "$l_file" ]; then
      ((file_count++))
      echo ""
      echo "Checking: $l_file"
      
      current_owner=$(stat -c '%U' "$l_file")
      current_group=$(stat -c '%G' "$l_file")
      current_perms=$(stat -c '%a' "$l_file")
      
      if [ "$current_owner" != "root" ] || [ "$current_group" != "root" ]; then
        echo "FAIL: Ownership is $current_owner:$current_group (expected root:root) - fixing now"
        chown root:root "$l_file"
        config_files_ok=false
      else
        echo "PASS: Ownership is root:root"
      fi
      
      if [ "$current_perms" != "600" ] && [ "$current_perms" != "400" ]; then
        echo "FAIL: Permissions are $current_perms (expected 600 or more restrictive) - fixing now"
        chmod 600 "$l_file"
        config_files_ok=false
      else
        echo "PASS: Permissions are $current_perms (600 or more restrictive)"
      fi
      
      echo "PROOF (stat output):"
      stat "$l_file"
    fi
  done < <(find /etc/ssh/sshd_config.d -type f -print0 2>/dev/null)
  
  if [ $file_count -eq 0 ]; then
    echo "No configuration files found in /etc/ssh/sshd_config.d"
  elif [ "$config_files_ok" = true ]; then
    echo ""
    echo "PASS: All $file_count file(s) in /etc/ssh/sshd_config.d have correct permissions"
  else
    echo ""
    echo "WARNING: Some files required correction"
  fi
else
  echo ""
  echo "3. /etc/ssh/sshd_config.d directory does not exist - no additional files to verify"
fi

# PROOF 4: Display complete stat output for main config file
if [ -e /etc/ssh/sshd_config ]; then
  echo ""
  echo "4. COMPLETE FILE STATUS FOR /etc/ssh/sshd_config:"
  echo "------------------------------------------------"
  echo "PROOF (full stat output):"
  stat /etc/ssh/sshd_config
fi

if [ "$final_status_pass" = true ]; then
  echo ""
  echo "SUCCESS: All remediation steps completed and verified with proofs"
else
  echo ""
  echo "WARNING: Some issues may require manual intervention"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
