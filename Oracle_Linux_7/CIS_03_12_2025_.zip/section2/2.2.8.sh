#!/usr/bin/env bash

# Script: 2.2.8.sh
# Item: 2.2.8 Ensure message access server services are not in use (Automated) - FORCE VERSION
# Profile Applicability: Level 1 - Server, Level 1 - Workstation
# Description: This remediation ensures message access server services (dovecot, cyrus-imapd) are not in use by removing or masking the services. FORCE VERSION - Comprehensive removal/masking.

set -euo pipefail

SCRIPT_NAME="2.2.8.sh"
ITEM_NAME="2.2.8 Ensure message access server services are not in use (Automated)"
DESCRIPTION="This remediation ensures message access server services (dovecot, cyrus-imapd) are not in use by removing or masking the services."

# --- METADATA AND ROOT CHECK ---
if [ "$EUID" -ne 0 ]; then
  echo "Error: This script must be run as root" >&2
  exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# --- UTILITY FUNCTIONS ---

detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then echo "yum";
    elif command -v dnf >/dev/null 2>&1; then echo "dnf";
    elif command -v apt-get >/dev/null 2>&1; then echo "apt";
    elif command -v zypper >/dev/null 2>&1; then echo "zypper";
    else echo "unknown"; fi
}

# --- CHECK/AUDIT FUNCTION ---

check_imap_status() {
    echo "Checking IMAP server status..."
    local services=("dovecot" "cyrus-imapd")
    local packages=("dovecot" "cyrus-imapd")
    
    for pkg in "${packages[@]}"; do
        if rpm -q "$pkg" >/dev/null 2>&1; then
            echo " - Package '$pkg' is installed."
        fi
    done

    for svc in "${services[@]}"; do
        if systemctl is-active "$svc.service" >/dev/null 2>&1; then
            echo " - Service '$svc.service' is running."
        fi
        if systemctl is-enabled "$svc.service" >/dev/null 2>&1; then
            echo " - Service '$svc.service' is enabled."
        fi
    done
    
    if ss -tulpn 2>/dev/null | grep -E ':143|:993' >/dev/null; then
        echo " - IMAP ports (143, 993) are listening."
    fi
}

# --- REMEDIATION FUNCTIONS ---

stop_imap_services() {
    echo "Stopping IMAP server services..."
    local services=("dovecot.service" "dovecot.socket" "cyrus-imapd.service")
    for svc in "${services[@]}"; do
        if systemctl list-units --type=service --all | grep -q "$svc"; then
            echo " - Stopping $svc..."
            systemctl stop "$svc" 2>/dev/null || true
        fi
    done
    pkill -TERM dovecot 2>/dev/null || true
    pkill -KILL dovecot 2>/dev/null || true
    pkill -TERM cyrus 2>/dev/null || true
    pkill -KILL cyrus 2>/dev/null || true
    echo " - All targeted IMAP services and processes stopped."
}

remove_imap_packages() {
    local pkg_mgr="$1"
    echo "Removing IMAP server packages..."
    local packages=("dovecot" "cyrus-imapd")

    if [ "$pkg_mgr" = "yum" ] || [ "$pkg_mgr" = "dnf" ]; then
        for pkg in "${packages[@]}"; do
            if rpm -q "$pkg" >/dev/null 2>&1; then
                echo " - Removing $pkg..."
                "$pkg_mgr" remove -y "$pkg" 2>/dev/null || echo " - WARNING: Failed to remove $pkg. It might be a dependency."
            fi
        done
        "$pkg_mgr" autoremove -y 2>/dev/null || true
    else
        echo " - WARNING: Unsupported package manager '$pkg_mgr'. Skipping package removal."
        return 1
    fi
    return 0
}

mask_imap_services() {
    echo "Masking IMAP server services..."
    local services=("dovecot.service" "dovecot.socket" "cyrus-imapd.service")
    for svc in "${services[@]}"; do
        if systemctl list-units --type=service --all | grep -q "$svc"; then
            echo " - Masking $svc..."
            systemctl mask "$svc" 2>/dev/null || true
        fi
    done
    echo " - Service masking complete."
}

# --- VERIFICATION FUNCTION ---

verify_imap_removal() {
    echo "Verifying IMAP server remediation..."
    local failed=false
    local services=("dovecot.service" "dovecot.socket" "cyrus-imapd.service")
    local packages=("dovecot" "cyrus-imapd")

    for pkg in "${packages[@]}"; do
        if rpm -q "$pkg" >/dev/null 2>&1; then
            echo "FAIL: Package '$pkg' is still installed."
            failed=true
        fi
    done

    for svc in "${services[@]}"; do
        if systemctl list-units --type=service --all | grep -q "$svc"; then
            if ! systemctl is-enabled "$svc" 2>/dev/null | grep -q "masked"; then
                echo "FAIL: Service '$svc' is not masked."
                failed=true
            fi
        fi
    done
    
    if ss -tulpn 2>/dev/null | grep -E ':143|:993' >/dev/null; then
        echo "FAIL: IMAP ports are still listening."
        failed=true
    fi
    
    if [ "$failed" = "true" ]; then
        return 1
    else
        return 0
    fi
}

# --- MAIN EXECUTION LOGIC ---

check_imap_status
echo ""

PKG_MGR=$(detect_package_manager)
echo "Detected package manager: $PKG_MGR"
echo ""

echo "==================================================================="
echo "FORCE MODE: REMOVING OR DISABLING IMAP SERVER SERVICES"
echo "==================================================================="
echo ""

stop_imap_services
remove_imap_packages "$PKG_MGR"
mask_imap_services

echo ""
echo "==================================================================="
echo "Final Verification:"
echo "==================================================================="
echo ""

if verify_imap_removal; then
    echo "SUCCESS: IMAP server services have been successfully remediated."
    echo ""
    echo "REMEDIATION SUMMARY:"
    echo "==================="
    echo "✓ IMAP services stopped and processes terminated."
    echo "✓ IMAP packages removed or services masked."
    echo "✓ Services will not start at boot."
else
    echo "WARNING: IMAP server remediation may not be complete."
    echo "Please perform a manual review."
    echo ""
    echo "RECOMMENDED MANUAL ACTIONS:"
    echo "==========================="
    echo "1. Verify packages are removed: rpm -qa | grep -E 'dovecot|cyrus-imapd'"
    echo "2. Ensure services are masked: systemctl list-unit-files | grep -E 'dovecot|cyrus-imapd'"
    echo "3. Check for listening ports: ss -tulpn | grep -E ':143|:993'"
fi

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="
