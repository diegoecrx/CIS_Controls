#!/usr/bin/env bash

# Script: 2.2.5.sh
# Item: 2.2.5 Ensure dnsmasq services are not in use (Automated) - FORCE VERSION

set -euo pipefail

SCRIPT_NAME="2.2.5.sh"
ITEM_NAME="2.2.5 Ensure dnsmasq services are not in use (Automated)"
DESCRIPTION="This remediation ensures dnsmasq services are not in use by removing or masking the services. FORCE VERSION - Comprehensive dnsmasq removal/masking."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

echo "==================================================================="
echo "Item Name: $ITEM_NAME"
echo "Description: $DESCRIPTION"
echo "Script: $SCRIPT_NAME"
echo "==================================================================="
echo ""

# Function to detect_package_manager
detect_package_manager() {
    if command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

# Function to check_dnsmasq_status
check_dnsmasq_status() {
    echo "Checking dnsmasq status..."
    
    dnsmasq_installed=false
    dnsmasq_running=false
    dnsmasq_enabled=false
    dnsmasq_masked=false
    
    # Check if dnsmasq package is installed
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q dnsmasq >/dev/null 2>&1; then
            dnsmasq_installed=true
            echo " - dnsmasq package is installed"
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l dnsmasq >/dev/null 2>&1; then
            dnsmasq_installed=true
            echo " - dnsmasq package is installed"
        fi
    else
        # Fallback: check if dnsmasq command exists
        if command -v dnsmasq >/dev/null 2>&1; then
            dnsmasq_installed=true
            echo " - dnsmasq appears to be installed"
        fi
    fi
    
    # Check for dnsmasq processes
    if pgrep dnsmasq >/dev/null 2>&1; then
        dnsmasq_running=true
        echo " - dnsmasq processes running:"
        pgrep dnsmasq | xargs ps -o pid,user,command -p 2>/dev/null
    fi
    
    # Check for dnsmasq service
    if systemctl list-unit-files | grep -q "^dnsmasq.service"; then
        # Check if service is running
        if systemctl is-active dnsmasq >/dev/null 2>&1; then
            dnsmasq_running=true
            echo " - dnsmasq.service is running"
        fi
        
        # Check if service is enabled
        if systemctl is-enabled dnsmasq >/dev/null 2>&1; then
            dnsmasq_enabled=true
            echo " - dnsmasq.service is enabled"
        fi
        
        # Check if service is masked
        if systemctl is-enabled dnsmasq 2>/dev/null | grep -q masked; then
            dnsmasq_masked=true
            echo " - dnsmasq.service is masked"
        fi
    fi
    
    # Check for dnsmasq network services
    if netstat -tulpn 2>/dev/null | grep dnsmasq | grep -v grep; then
        echo " - WARNING: dnsmasq network services detected:"
        netstat -tulpn 2>/dev/null | grep dnsmasq
    fi
    
    # Check for DNS/DHCP ports in use by dnsmasq
    if ss -tulpn 2>/dev/null | grep -E ':53 |:67 |:68 ' | grep dnsmasq; then
        echo " - WARNING: dnsmasq using DNS/DHCP ports:"
        ss -tulpn 2>/dev/null | grep -E ':53 |:67 |:68 ' | grep dnsmasq
    fi
    
    # Check for configuration files
    dnsmasq_configs=("/etc/dnsmasq.conf" "/etc/dnsmasq.d")
    for config in "${dnsmasq_configs[@]}"; do
        if [ -e "$config" ]; then
            echo " - dnsmasq configuration found: $config"
        fi
    done
    
    # Check if dnsmasq is used as local DNS resolver
    if grep -q "nameserver 127.0.0.1" /etc/resolv.conf 2>/dev/null && \
       pgrep dnsmasq >/dev/null 2>&1; then
        echo " - WARNING: dnsmasq is configured as local DNS resolver"
    fi
    
    return 0
}

# Function to stop_dnsmasq_services
stop_dnsmasq_services() {
    echo "Stopping dnsmasq services..."
    
    # Stop dnsmasq processes first
    if pgrep dnsmasq >/dev/null 2>&1; then
        echo " - Stopping dnsmasq processes..."
        pkill -TERM dnsmasq 2>/dev/null || true
        sleep 2
        
        # Force kill if still running
        if pgrep dnsmasq >/dev/null 2>&1; then
            echo " - Force stopping dnsmasq processes..."
            pkill -KILL dnsmasq 2>/dev/null || true
            sleep 1
        fi
    fi
    
    # Stop dnsmasq service using systemctl
    if systemctl list-unit-files | grep -q "^dnsmasq.service" && systemctl is-active dnsmasq >/dev/null 2>&1; then
        echo " - Stopping dnsmasq.service..."
        if systemctl stop dnsmasq 2>&1; then
            echo "   - dnsmasq.service stopped"
        else
            echo "   - WARNING: Could not stop dnsmasq.service via systemctl"
        fi
    fi
    
    # Additional stop for any dnsmasq related services
    systemctl list-unit-files | grep dnsmasq | awk '{print $1}' | while read -r service; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            echo " - Stopping $service..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
    
    # Verify no dnsmasq processes are running
    if pgrep dnsmasq >/dev/null 2>&1; then
        echo " - CRITICAL: dnsmasq processes still running after stop attempts"
        return 1
    else
        echo " - No dnsmasq processes running"
    fi
    
    # Kill any remaining dnsmasq processes
    pkill -9 dnsmasq 2>/dev/null || true
    
    return 0
}

# Function to remove_dnsmasq_packages
remove_dnsmasq_packages() {
    local pkg_mgr="$1"
    
    echo "Removing dnsmasq packages..."
    
    # List of dnsmasq-related packages
    dnsmasq_packages=("dnsmasq" "dnsmasq-utils" "dnsmasq-base")
    
    case "$pkg_mgr" in
        yum|dnf)
            echo " - Using $pkg_mgr to remove dnsmasq packages..."
            for pkg in "${dnsmasq_packages[@]}"; do
                if $pkg_mgr list installed "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if $pkg_mgr remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        apt)
            echo " - Using apt to remove dnsmasq packages..."
            export DEBIAN_FRONTEND=noninteractive
            for pkg in "${dnsmasq_packages[@]}"; do
                if dpkg -l "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if apt-get remove -y "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        zypper)
            echo " - Using zypper to remove dnsmasq packages..."
            for pkg in "${dnsmasq_packages[@]}"; do
                if zypper search --installed-only "$pkg" >/dev/null 2>&1; then
                    echo "   - Removing $pkg..."
                    if zypper --non-interactive remove "$pkg" 2>&1; then
                        echo "     - $pkg removed successfully"
                    else
                        echo "     - WARNING: Failed to remove $pkg"
                    fi
                fi
            done
            ;;
        *)
            echo " - WARNING: Unknown package manager, cannot remove dnsmasq packages"
            return 1
            ;;
    esac
    
    # Clean up package cache and dependencies
    case "$pkg_mgr" in
        yum|dnf)
            $pkg_mgr autoremove -y 2>/dev/null || true
            ;;
        apt)
            apt-get autoremove -y 2>/dev/null || true
            ;;
    esac
    
    echo " - Package removal completed"
    return 0
}

# Function to mask_dnsmasq_services
mask_dnsmasq_services() {
    echo "Masking dnsmasq services..."
    
    # Mask the main dnsmasq service
    if systemctl list-unit-files | grep -q "^dnsmasq.service"; then
        if ! systemctl is-enabled dnsmasq 2>/dev/null | grep -q masked; then
            if systemctl mask dnsmasq 2>&1; then
                echo " - dnsmasq.service masked"
            else
                echo " - WARNING: Could not mask dnsmasq.service"
            fi
        else
            echo " - dnsmasq.service already masked"
        fi
    fi
    
    # Mask any other dnsmasq related services
    systemctl list-unit-files | grep dnsmasq | awk '{print $1}' | while read -r service; do
        if ! systemctl is-enabled "$service" 2>/dev/null | grep -q masked; then
            systemctl mask "$service" 2>/dev/null && echo " - $service masked" || true
        fi
    done
    
    return 0
}

# Function to disable_dnsmasq_services
disable_dnsmasq_services() {
    echo "Disabling dnsmasq services..."
    
    # Disable the main dnsmasq service
    if systemctl list-unit-files | grep -q "^dnsmasq.service"; then
        if systemctl is-enabled dnsmasq >/dev/null 2>&1; then
            if systemctl disable dnsmasq 2>&1; then
                echo " - dnsmasq.service disabled"
            else
                echo " - WARNING: Could not disable dnsmasq.service"
            fi
        else
            echo " - dnsmasq.service already disabled"
        fi
    fi
    
    # Disable any other dnsmasq related services
    systemctl list-unit-files | grep dnsmasq | awk '{print $1}' | while read -r service; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            systemctl disable "$service" 2>/dev/null && echo " - $service disabled" || true
        fi
    done
    
    return 0
}

# Function to cleanup_dnsmasq_configs
cleanup_dnsmasq_configs() {
    echo "Cleaning up dnsmasq configuration files..."
    
    # List of dnsmasq configuration files to remove or disable
    config_files=(
        "/etc/dnsmasq.conf"
        "/etc/dnsmasq.d"
        "/etc/init.d/dnsmasq"
        "/etc/default/dnsmasq"
        "/etc/sysconfig/dnsmasq"
        "/var/lib/dnsmasq"
    )
    
    for config_file in "${config_files[@]}"; do
        if [ -e "$config_file" ]; then
            if [ -f "$config_file" ]; then
                # Create backup and disable
                backup_file="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp "$config_file" "$backup_file"
                echo " - Backed up $config_file to $backup_file"
                
                # Comment out all active configurations
                sed -i 's/^\([^#]\)/# REMEDIATED: \1/' "$config_file" 2>/dev/null || true
                echo " - Disabled configurations in $config_file"
            elif [ -d "$config_file" ]; then
                # For directories, backup and disable contents
                backup_dir="${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
                cp -r "$config_file" "$backup_dir" 2>/dev/null || true
                echo " - Backed up $config_file to $backup_dir"
                
                # Disable all configuration files in directory
                find "$config_file" -type f -name "*.conf" -exec sh -c 'echo "# REMEDIATED: $(cat {})" > {}' \; 2>/dev/null || true
                echo " - Disabled configuration files in $config_file"
            fi
        fi
    done
    
    # Remove dnsmasq from NetworkManager configurations
    if [ -f "/etc/NetworkManager/NetworkManager.conf" ]; then
        if grep -q "dnsmasq" /etc/NetworkManager/NetworkManager.conf; then
            cp /etc/NetworkManager/NetworkManager.conf "/etc/NetworkManager/NetworkManager.conf.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i 's/dnsmasq/# REMEDIATED: dnsmasq/' /etc/NetworkManager/NetworkManager.conf 2>/dev/null || true
            echo " - Disabled dnsmasq in NetworkManager"
        fi
    fi
    
    # Remove dnsmasq from DHCP configurations
    if [ -f "/etc/dhcp/dhclient.conf" ]; then
        if grep -q "dnsmasq" /etc/dhcp/dhclient.conf; then
            cp /etc/dhcp/dhclient.conf "/etc/dhcp/dhclient.conf.backup.$(date +%Y%m%d_%H%M%S)"
            sed -i 's/dnsmasq/# REMEDIATED: dnsmasq/' /etc/dhcp/dhclient.conf 2>/dev/null || true
            echo " - Removed dnsmasq from dhclient configuration"
        fi
    fi
    
    # Remove any dnsmasq related cron jobs
    if [ -d "/etc/cron.d" ]; then
        for cron_file in /etc/cron.d/*; do
            if [ -f "$cron_file" ] && grep -q dnsmasq "$cron_file" 2>/dev/null; then
                sed -i '/dnsmasq/d' "$cron_file" 2>/dev/null || true
                echo " - Removed dnsmasq references from $cron_file"
            fi
        done
    fi
    
    # Clean up dnsmasq runtime files
    if [ -d "/var/run/dnsmasq" ]; then
        rm -rf /var/run/dnsmasq/* 2>/dev/null || true
        echo " - Cleaned up dnsmasq runtime files"
    fi
    
    if [ -f "/var/run/dnsmasq.pid" ]; then
        rm -f /var/run/dnsmasq.pid 2>/dev/null || true
        echo " - Removed dnsmasq PID file"
    fi
    
    return 0
}

# Function to block_dnsmasq_ports
block_dnsmasq_ports() {
    echo "Blocking dnsmasq network ports..."
    
    # dnsmasq uses DNS (53) and DHCP (67,68) ports
    if command -v firewall-cmd >/dev/null 2>&1; then
        # firewalld
        if firewall-cmd --state >/dev/null 2>&1; then
            echo " - Configuring firewalld to block dnsmasq ports..."
            firewall-cmd --permanent --remove-service=dns 2>/dev/null || true
            firewall-cmd --permanent --remove-service=dhcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=53/tcp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=53/udp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=67/udp 2>/dev/null || true
            firewall-cmd --permanent --remove-port=68/udp 2>/dev/null || true
            firewall-cmd --reload 2>/dev/null || true
            echo " - firewalld configured to block dnsmasq ports"
        fi
    fi
    
    # Additional iptables rules for non-firewalld systems
    if command -v iptables >/dev/null 2>&1; then
        echo " - Adding iptables rules to block dnsmasq..."
        # Block DNS server ports
        iptables -I INPUT -p tcp --dport 53 -j DROP 2>/dev/null || true
        iptables -I INPUT -p udp --dport 53 -j DROP 2>/dev/null || true
        # Block DHCP server ports
        iptables -I INPUT -p udp --dport 67 -j DROP 2>/dev/null || true
        iptables -I INPUT -p udp --dport 68 -j DROP 2>/dev/null || true
        echo " - iptables rules added (if supported)"
    fi
    
    return 0
}

# Function to update_resolver_config
update_resolver_config() {
    echo "Updating DNS resolver configuration..."
    
    # Check if dnsmasq was used as local resolver
    if [ -f "/etc/resolv.conf" ] && grep -q "nameserver 127.0.0.1" /etc/resolv.conf 2>/dev/null; then
        echo " - dnsmasq was configured as local DNS resolver"
        cp /etc/resolv.conf "/etc/resolv.conf.backup.$(date +%Y%m%d_%H%M%S)"
        
        # Replace localhost with public DNS servers
        if grep -q "nameserver 127.0.0.1" /etc/resolv.conf; then
            # Use common public DNS servers as fallback
            sed -i 's/^nameserver 127.0.0.1/# REMEDIATED: nameserver 127.0.0.1\nnameserver 8.8.8.8\nnameserver 1.1.1.1/' /etc/resolv.conf 2>/dev/null || true
            echo " - Updated /etc/resolv.conf with public DNS servers"
        fi
    fi
    
    # Check for systemd-resolved configuration
    if [ -f "/etc/systemd/resolved.conf" ]; then
        if grep -q "DNSStubListener=yes" /etc/systemd/resolved.conf 2>/dev/null; then
            echo " - systemd-resolved DNS stub listener is enabled"
        fi
    fi
    
    return 0
}

# Function to verify_dnsmasq_removal
verify_dnsmasq_removal() {
    echo "Verifying dnsmasq remediation..."
    
    verification_passed=true
    
    # Check if dnsmasq packages are installed
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q dnsmasq >/dev/null 2>&1; then
            echo "FAIL: dnsmasq package is still installed"
            verification_passed=false
        else
            echo "PASS: dnsmasq package is not installed"
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l dnsmasq >/dev/null 2>&1; then
            echo "FAIL: dnsmasq package is still installed"
            verification_passed=false
        else
            echo "PASS: dnsmasq package is not installed"
        fi
    else
        echo "INFO: Could not verify package removal (unknown package manager)"
    fi
    
    # Check if dnsmasq service is running
    if systemctl list-unit-files | grep -q "^dnsmasq.service" && systemctl is-active dnsmasq >/dev/null 2>&1; then
        echo "FAIL: dnsmasq.service is running"
        verification_passed=false
    else
        echo "PASS: dnsmasq.service is not running"
    fi
    
    # Check if dnsmasq service is enabled or masked
    if systemctl list-unit-files | grep -q "^dnsmasq.service"; then
        if systemctl is-enabled dnsmasq >/dev/null 2>&1; then
            if systemctl is-enabled dnsmasq 2>/dev/null | grep -q masked; then
                echo "PASS: dnsmasq.service is masked"
            else
                echo "FAIL: dnsmasq.service is enabled"
                verification_passed=false
            fi
        else
            echo "PASS: dnsmasq.service is not enabled"
        fi
    fi
    
    # Check for dnsmasq processes
    if pgrep dnsmasq >/dev/null 2>&1; then
        echo "FAIL: dnsmasq processes are running"
        verification_passed=false
    else
        echo "PASS: No dnsmasq processes running"
    fi
    
    # Check for dnsmasq network services
    if ss -tulpn 2>/dev/null | grep dnsmasq; then
        echo "FAIL: dnsmasq network services detected"
        verification_passed=false
    else
        echo "PASS: No dnsmasq network services detected"
    fi
    
    # Check if dnsmasq ports are still in use (by any process)
    if ss -tulpn 2>/dev/null | grep -E ':53 |:67 |:68 ' | grep -v dnsmasq; then
        echo "INFO: DNS/DHCP ports in use by other services (not dnsmasq)"
    else
        echo "PASS: DNS/DHCP ports not in use"
    fi
    
    return $([ "$verification_passed" = true ] && echo 0 || echo 1)
}

# Main remediation function
{
    echo "Checking current dnsmasq status..."
    echo ""

    # Check current dnsmasq status
    check_dnsmasq_status
    echo ""

    # Detect package manager
    pkg_mgr=$(detect_package_manager)
    echo "Detected package manager: $pkg_mgr"
    echo ""

    # FORCE MODE: Remove or disable dnsmasq
    echo "==================================================================="
    echo "FORCE MODE: REMOVING OR DISABLING DNSMASQ SERVICES"
    echo "==================================================================="
    echo ""

    # Stop dnsmasq services first
    if ! stop_dnsmasq_services; then
        echo " - WARNING: Some issues stopping dnsmasq services"
    fi
    echo ""

    # Try to remove dnsmasq packages
    if remove_dnsmasq_packages "$pkg_mgr"; then
        echo " - Package removal attempted"
        removal_method="removed"
    else
        echo " - Package removal failed or not attempted, masking services instead"
        removal_method="masked"
    fi
    echo ""

    # Mask and disable services (especially if package removal failed)
    if [ "$removal_method" = "masked" ]; then
        if mask_dnsmasq_services; then
            echo " - Service masking successful"
        else
            echo " - WARNING: Service masking had issues"
        fi
        
        if disable_dnsmasq_services; then
            echo " - Service disabling successful"
        fi
    fi
    echo ""

    # Cleanup configuration files
    cleanup_dnsmasq_configs
    echo ""

    # Update resolver configuration
    update_resolver_config
    echo ""

    # Block network ports
    block_dnsmasq_ports
    echo ""

    # Final verification
    echo "==================================================================="
    echo "Final Verification:"
    echo "==================================================================="
    echo ""

    if verify_dnsmasq_removal; then
        echo ""
        echo "SUCCESS: dnsmasq services have been successfully remediated"
        echo ""
        echo "REMEDIATION SUMMARY:"
        echo "==================="
        if [ "$removal_method" = "removed" ]; then
            echo "✓ dnsmasq packages removed"
        else
            echo "✓ dnsmasq services masked and disabled"
        fi
        echo "✓ dnsmasq services stopped"
        echo "✓ dnsmasq processes terminated"
        echo "✓ Configuration files disabled"
        echo "✓ Network ports blocked"
        echo "✓ DNS resolver configuration updated"
        echo "✓ Service will not start at boot"
    else
        echo ""
        echo "WARNING: dnsmasq remediation may not be complete"
        echo "Some dnsmasq components may still be present or active."
        echo ""
        echo "RECOMMENDED MANUAL ACTIONS:"
        echo "==========================="
        echo "1. Check for any remaining dnsmasq processes: ps aux | grep dnsmasq"
        echo "2. Verify dnsmasq services are masked: systemctl list-unit-files | grep dnsmasq"
        echo "3. Manually remove dnsmasq packages if needed"
        echo "4. Check network ports: ss -tulpn | grep -E ':53|:67|:68'"
        echo "5. Verify no dnsmasq configuration files remain in /etc/dnsmasq*"
        echo "6. Update /etc/resolv.conf to use external DNS servers if needed"
    fi

    # Show current status summary
    echo ""
    echo "CURRENT STATUS SUMMARY:"
    echo "======================"
    echo "Package installed: $(if command -v rpm >/dev/null && rpm -q dnsmasq >/dev/null 2>&1; then echo "YES"; elif command -v dpkg >/dev/null && dpkg -l dnsmasq >/dev/null 2>&1; then echo "YES"; else echo "NO"; fi)"
    echo "Service running: $(systemctl is-active dnsmasq 2>/dev/null || echo "NO")"
    echo "Service enabled: $(systemctl is-enabled dnsmasq 2>/dev/null || echo "NO")"
    echo "Processes running: $(pgrep dnsmasq 2>/dev/null | wc -l)"
    echo "Network port 53: $(ss -tulpn 2>/dev/null | grep -c ':53 ' || echo "0")"
    echo "Network port 67: $(ss -tulpn 2>/dev/null | grep -c ':67 ' || echo "0")"
    echo "Localhost DNS: $(grep -c "nameserver 127.0.0.1" /etc/resolv.conf 2>/dev/null || echo "0")"

}

echo ""
echo "==================================================================="
echo "Remediation completed for: $ITEM_NAME"
echo "==================================================================="